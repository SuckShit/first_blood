 xswap 性能优化版本demo，由svn迁移到git
2017/06/07 
