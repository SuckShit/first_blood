/***
Created on June 29, 2017
@author: Gao.Liu
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _USR_ROLE_
#define _USR_ROLE_

#include "gtest/gtest.h"
#include "UsrDb.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/
 
 
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define USR_NAME_MAX_LENGTH     100
#define ROLE_ID_MAX_COUNT       8


/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef struct usrRoleBaseInfo
{
    char  usrNm[USR_NAME_MAX_LENGTH];            /*用户登录名*/
    int32 roleId[10];                /*usr role表id*/
    char  crtTm[50];
    char  crtUsrNm[100];
    char  updTm[50];
    char  updUsrNm[100];
    int32  orgId;
    int32 pos;
} UsrRoleBaseInfoT, *pUsrRoleBaseInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*judge whether role id exists*/
ResCodeT IrsRoleInfoLoadFromDb(int32 connid);

/*judge whether role id exists*/
ResCodeT IrsUsrRoleUpdateByDl(int32 connId, char* usrName, int32 roleId, int32 newRoleId);
/*judge whether role id exists*/
ResCodeT IrsRoleInfoGetByName(char* roleName, pUsrRoleBaseInfoT pRole);
/*judge whether role id exists*/
ResCodeT IrsRoleInfoGetByNameExt(char* roleName, pUsrRoleBaseInfoT* pRole);
/*judge whether role id exists*/
ResCodeT IrsRoleInfoGetByPos(uint64 rolePos, pUsrRoleBaseInfoT pRole);
/*judge whether role id exists*/
ResCodeT IrsRoleInfoGetByPosExt(uint64 rolePos, pUsrRoleBaseInfoT* pRole);
ResCodeT IrsRoleInfoDetachFromShm(void);

/*judge whether role id exists*/
ResCodeT IrsUsrRoleIdIsExist(char* usrName, int roleId, BOOL *status);

#endif
