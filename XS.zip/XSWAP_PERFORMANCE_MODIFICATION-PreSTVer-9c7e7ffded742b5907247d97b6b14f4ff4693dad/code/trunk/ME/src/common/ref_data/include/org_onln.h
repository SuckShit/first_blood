/***
Created on Aug 30, 2017
@author: XiaoPing Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _ORG_ONLN_
#define _ORG_ONLN_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "common_hash.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/




/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 在线机构信息 */
typedef struct OrgOnlineS {
    uint64          orgId;          /* 机构标识 6位      */
    uint64          usrCnt;         /* 已登录的用户数 */
    uint64          pos;            /* 在内存Hash结构中的位置 */
} OrgOnlineT, *pOrgOnlineT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/* Create the hashtable that contains the online organizations. */
ResCodeT OrgOnlnCreate(uint64 size);

/* Add organization into the hashtable by specifying the orgId. */
ResCodeT OrgOnlnAddById(uint64 orgId);

/* Delete organization from the hashtable by specifying the orgId. */
ResCodeT OrgOnlnDeleteById(uint64 orgId);

/* for iteration use. */
ResCodeT OrgOnlnIterExt(uint64 *orgOnlnPos, pOrgOnlineT *ppOrgOnln);
 
/* Search the online organization by specifying the orgId. */
ResCodeT OrgOnlnGetById(uint64 orgId, pOrgOnlineT pOrgOnln);

/* Search the online organization by specifying the orgId. 
   The return value ppOrgOnln is the direct address of org info in the Hash shared memory. */
ResCodeT OrgOnlnGetByIdExt(uint64 orgId, pOrgOnlineT *ppOrgOnln);

/* Search the online organization by specifying the position of org info in the hashtable. */
ResCodeT OrgOnlnGetByPos(uint32 orgPos, pOrgOnlineT pOrgOnln);

/* Search the online organization by specifying the position of org info in the hashtable. 
   The return value ppOrgOnln is the direct address of org info in the Hash shared memory. */
ResCodeT OrgOnlnGetByPosExt(uint32 orgPos, pOrgOnlineT *ppOrgOnln);

/* Attach to the shared memory. */
ResCodeT OrgOnlnAttachToShm();

/* Detach from the shared memory. */
ResCodeT OrgOnlnDetachFromShm();

ResCodeT IterOnlOrg( uint32 curOrgPos, uint32 *nxtOrgPos );
ResCodeT UpdtLstBrdgOrg( uint32 orgOnlnPos );
ResCodeT GetLstBrdgOrg( uint32 *onlnOrgPos );

#endif /* _ORG_ONLN_ */
