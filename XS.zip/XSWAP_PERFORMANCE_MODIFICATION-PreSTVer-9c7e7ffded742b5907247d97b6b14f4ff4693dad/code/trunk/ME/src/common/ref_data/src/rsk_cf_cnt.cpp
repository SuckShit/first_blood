/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "common_hash.h"
#include "rsk_cf_cnt.h"
#include "RskCfcntDb.h"
#include "shm.h"
#include "uti_tool.h"
#include "pck_irs_dicdata.h"

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/
#define ROLE_PRVLG_HASH_KEY_DELIMITER            '&'

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static CmnHashHndlT rskCfCntInfoHashHndl;
static char delimiter[1] = {ROLE_PRVLG_HASH_KEY_DELIMITER};

/***********************************************************************************************
**
**   Functiona Declaration                                                                           
**
************************************************************************************************/
ResCodeT IrsRskCfCntKeyMerge(char* cntrctNm, int32 orgId, char *pHashKey);


/***********************************************************************************************
**
**   Functiona Implementation                                                                           
**
************************************************************************************************/
/******************************************************************************
* Description:   load risk coff count info from DB to hash 
* Parameters:
*      pInQHndl    IN  
*      N/A         OUT 
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT IrsRskCfCntLoadFromDb(int32 connid)
{
    BEGIN_FUNCTION("IrsRskCfCntLoadFromDb");
    HashTableRecInfoT recRskCofCntInfo;
    RskCfCntInfoT rskCfCntInfo;
    uint32 pos = 0;
    int32 rskCfCntInfoCount = 0;
    BOOL exist = FALSE;
    BOOL selFlag = TRUE;
    RskCfcnt rskCfCntInfoData;
    RskCfcnt data;
    void *pRt;    
    ResCodeT rc = NO_ERR;
    int32 i = 0;
    
    /*create user info memory*/
    rc = GetResultCntOfRskCfcnt(connid, &rskCfCntInfoCount);
    if (NOTOK(rc)){
        TRACE("get risk coff count failure");
        THROW_RESCODE(rc);
    }

    recRskCofCntInfo.recSize = sizeof(RskCfCntInfoT);
    recRskCofCntInfo.recCnt = rskCfCntInfoCount + 10;
    recRskCofCntInfo.keyOffset = offsetof(RskCfCntInfoT, hashKey);
    recRskCofCntInfo.keySize = 60;

    /*create hash table for user info*/
    rc = CmnHashTblCreate(GetShmNm((char*)SHM_IRS_RISK_CF_CNT_NAME), recRskCofCntInfo,1, &pRt, &rskCfCntInfoHashHndl);
    //RAISE_ERR(rc, RTN);
    if (NOTOK(rc)){
        TRACE("create hash failure");
        THROW_RESCODE(rc);
    }

    /*fetch user info from DB*/
    for(i=0; i<rskCfCntInfoCount; i++){        
        memset(&rskCfCntInfoData, 0, sizeof(RskCfcnt));
        memset(&rskCfCntInfo, 0, sizeof(RskCfCntInfoT));
        rc = FetchNextRskCfcnt(&selFlag, connid, &rskCfCntInfoData);
        if (NOTOK(rc)){
            TRACE("fetch next risk coff count info failure");
            THROW_RESCODE(rc);
        }
        strcpy(rskCfCntInfo.cntrctNm, rskCfCntInfoData.cntrctNm);
        rskCfCntInfo.rskCfcntVl = rskCfCntInfoData.rskCfcntVl;
        rskCfCntInfo.orgId = rskCfCntInfoData.orgId;
        strcpy(rskCfCntInfo.updUsrNm, rskCfCntInfoData.updUsrNm);

        /* Generate the key to be hashed. The key will be created by combining the rsrcId and sysStId */
        IrsRskCfCntKeyMerge(rskCfCntInfo.cntrctNm, rskCfCntInfo.orgId, rskCfCntInfo.hashKey);

        rc = CmnHashCheckData(rskCfCntInfoHashHndl, (void*)rskCfCntInfo.hashKey, &exist, &pos, (void*)&data);
        if (NOTOK(rc)){
            TRACE("check data failure");
            THROW_RESCODE(rc);
        }
        rskCfCntInfo.pos = pos;
        
        if (FALSE == exist){
            rc = CmnHashLogData(rskCfCntInfoHashHndl, (void*)&rskCfCntInfo, pos, 1, 1);
            if (NOTOK(rc)){
                TRACE("update hash data failure");
                THROW_RESCODE(rc);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRskCfCntGetByTwoKey(char* cntrctNm, int32 orgId, pRskCfCntInfoT pRsk)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByTwoKey");
    ResCodeT rc = NO_ERR;
    pRskCfCntInfoT pData;
    
    /* Call IrsCntrctInfoGetByNameExt to get the IRS contract info. */
    rc = IrsRskCfCntGetByNameExt(cntrctNm, orgId,&pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRsk, pData, sizeof(RskCfCntInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsRskCfCntKeyMerge(char* cntrctNm, int32 orgId, char *pHashKey)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByTwoKey");

    memcpy(pHashKey, &orgId, sizeof(uint32));
    pHashKey = pHashKey + sizeof(uint32);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    memcpy(pHashKey, cntrctNm, 50);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsRskCfCntGetByNameExt(char* cntrctNm, int32 orgId, pRskCfCntInfoT* pRsk)
{
    BEGIN_FUNCTION("IrsRskCfCntGetByNameExt");
    uint32 pos = 0;
    char keyInfo[60];
    ResCodeT rc = NO_ERR;
    BOOL exist = FALSE;

    memset(keyInfo, 0, 60);
    IrsRskCfCntKeyMerge(cntrctNm, orgId, keyInfo);
    
    rc = CmnHashCheckDataExt(rskCfCntInfoHashHndl, keyInfo, &exist, &pos, (void**)pRsk);
    RAISE_ERR(rc, RTN);

    if (FALSE == exist){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IrsRskCfCntGetByPos(uint64 UsrPos, pRskCfCntInfoT pRsk)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByPos");
    ResCodeT rc = NO_ERR;
    pRskCfCntInfoT tmpData;
    
    rc = IrsRskCfCntGetByPosExt(UsrPos, &tmpData);
    RAISE_ERR(rc , RTN);

    memcpy(pRsk, tmpData, sizeof(RskCfCntInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT IrsRskCfCntGetByPosExt(uint64 UsrPos, pRskCfCntInfoT* pRsk)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByPosExt");
    ResCodeT rc = NO_ERR;

    rc = CmnHashReadDataAddrByPos(rskCfCntInfoHashHndl, UsrPos, (void**)pRsk);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsRskCfCntAttachToShm(void)
{

    BEGIN_FUNCTION("IrsRskCfCntAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_IRS_RISK_CF_CNT_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    rskCfCntInfoHashHndl = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRskCfCntDetachFromShm(void)
{
    BEGIN_FUNCTION("IrsRskCfCntDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_IRS_RISK_CF_CNT_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

