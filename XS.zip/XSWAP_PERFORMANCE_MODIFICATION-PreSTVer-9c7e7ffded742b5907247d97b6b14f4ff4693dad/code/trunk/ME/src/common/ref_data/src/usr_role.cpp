/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "common_hash.h"
#include "usr_role.h"
#include "usr.h"
#include "uti_tool.h"
#include "UsrRoleDb.h"
#include "shm.h"
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
CmnHashHndlT usrRoleHashHndl;
static CmnHashHndlT irsHashHandler;

/***********************************************************************************************
**
**   Functiona Declaration                                                                           
**
************************************************************************************************/


/***********************************************************************************************
**
**   Functiona Implementation                                                                           
**
************************************************************************************************/
/******************************************************************************
* Description:   load role info from DB to hash 
* Parameters:
*      pInQHndl    IN  
*      N/A         OUT 
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT IrsRoleInfoLoadFromDb(int32 connid)
{
    BEGIN_FUNCTION("IrsUsrInfoLoadFromDb");
    HashTableRecInfoT recRoleInfo;
    UsrRoleBaseInfoT usrRoleInfo;
    uint32 pos = 0;
    int32 usrRoleCount = 0;
    BOOL exist = FALSE;
    UsrRole usrRoleData, data;
    void *pRt;
    alignTypeT type;
    ResCodeT rc = NO_ERR;
    int i = 0;
    BOOL    bFrstFlg = TRUE;

    /*create user info memory*/
    rc = GetResultCntOfUsrRole(connid, &usrRoleCount);
    if (NOTOK(rc)){
        TRACE("get user count failure");
        THROW_RESCODE(rc);
    }

    recRoleInfo.recSize = sizeof(UsrRoleBaseInfoT);
    recRoleInfo.recCnt = usrRoleCount + 10;
    recRoleInfo.keyOffset = offsetof(UsrRoleBaseInfoT, usrNm);
    recRoleInfo.keySize = 100;

    /*create hash table for user info*/
    rc = CmnHashTblCreate(GetShmNm((char*)SHM_IRS_USR_ROLE_NAME), recRoleInfo,1, &pRt, &usrRoleHashHndl);
    //RAISE_ERR(rc, RTN);
    if (NOTOK(rc)){
        TRACE("create hash failure");
        THROW_RESCODE(rc);
    }


    /*fetch user info from DB*/
    for(i=0; i<usrRoleCount; i++){        
        memset(&usrRoleData, 0, sizeof(UsrRole));
        memset(&usrRoleInfo, 0, sizeof(UsrRoleBaseInfoT));
        rc = FetchNextUsrRole(&bFrstFlg, connid, &usrRoleData);
        if (NOTOK(rc)){
            TRACE("fetch next usr failure");
            THROW_RESCODE(rc);
        }
        strcpy(usrRoleInfo.usrNm, usrRoleData.usrNm);
        type = alignInc;
        rc = IrsUsrStrtok(usrRoleData.roleId, usrRoleInfo.roleId, type);
        if (NOTOK(rc)){
            TRACE("strtok roleid failure");
            THROW_RESCODE(rc);
        }
        strcpy(usrRoleInfo.crtTm, usrRoleData.crtTm);
        strcpy(usrRoleInfo.crtUsrNm, usrRoleData.crtUsrNm);
        strcpy(usrRoleInfo.updTm, usrRoleData.updTm);
        strcpy(usrRoleInfo.updUsrNm, usrRoleData.updUsrNm);
        usrRoleInfo.orgId = usrRoleData.orgId;
        
        rc = CmnHashCheckData(usrRoleHashHndl, (void*)&usrRoleInfo.usrNm, &exist, &pos, (void*)&data);
        if (NOTOK(rc)){
            TRACE("check data failure");
            THROW_RESCODE(rc);
        }
        usrRoleInfo.pos = pos;
        if (FALSE == exist){
            rc = CmnHashLogData(usrRoleHashHndl, (void*)&usrRoleInfo, pos, 1, 1);
            if (NOTOK(rc)){
                TRACE("update hash data failure");
                THROW_RESCODE(rc);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

/******************************************************************************
 **
 ** UpdateUsrRole
 **
 ******************************************************************************/
ResCodeT IrsUsrRoleUpdateByDl(
            int32               connId,
            char*    usrName,
            int32    roleId,   
            int32    newRoleId
            )
{
    BEGIN_FUNCTION( "IrsUsrRoleUpdate" );
    ResCodeT rc = NO_ERR;

    UsrRole keyData;
    UsrRoleInsert valData;
    vectorT  keyVct[GET_BIT_VECT_LEN(7)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(7)] = {0};

    memset(&keyData, 0, sizeof(UsrRole));
    memset(&valData, 0, sizeof(UsrRole));
    strcpy(keyData.usrNm, usrName);
    sprintf(keyData.roleId, "%ld",  roleId);
    
    valData.roleId = newRoleId;

    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( keyVct, 1 );
    
    DbCmmnSetColBit( datVct, 1 );

    rc = UpdateUsrRoleByKeyRpt( connId, &keyData, &valData, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IrsRoleInfoGetByName(char* roleName, pUsrRoleBaseInfoT pRole)
{
    BEGIN_FUNCTION("IrsRoleInfoGetByName");
    ResCodeT rc = NO_ERR;
    pUsrRoleBaseInfoT pData;
    
    /* Call IrsRoleInfoGetByNameExt to get the IRS role info. */
    rc = IrsRoleInfoGetByNameExt(roleName, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRole, pData, sizeof(UsrRoleBaseInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsRoleInfoGetByNameExt(char* roleName, pUsrRoleBaseInfoT* pRole)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByNameExt");
    uint32 pos = 0;
    ResCodeT rc = NO_ERR;
    BOOL exist = FALSE;
    char keyNm[100];


    memset(keyNm, 0, 100);
    strcpy(keyNm, roleName);

    rc = CmnHashCheckDataExt(usrRoleHashHndl, keyNm, &exist, &pos, (void**)pRole);
    RAISE_ERR(rc, RTN);

    if (FALSE == exist){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IrsRoleInfoGetByPos(uint64 rolePos, pUsrRoleBaseInfoT pRole)
{
    BEGIN_FUNCTION("IrsRoleInfoGetByPos");
    ResCodeT rc = NO_ERR;
    pUsrRoleBaseInfoT tmpData;
    
    rc = IrsRoleInfoGetByPosExt(rolePos, &tmpData);
    RAISE_ERR(rc , RTN);

    memcpy(pRole, tmpData, sizeof(UsrRoleBaseInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT IrsRoleInfoGetByPosExt(uint64 rolePos, pUsrRoleBaseInfoT* pRole)
{
    BEGIN_FUNCTION("IrsRoleInfoGetByPosExt");
    ResCodeT rc = NO_ERR;

    rc = CmnHashReadDataAddrByPos(usrRoleHashHndl, rolePos, (void**)pRole);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsRoleInfoAttachToShm(void)
{

    BEGIN_FUNCTION("IrsRoleInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_IRS_USR_ROLE_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    irsHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRoleInfoDetachFromShm(void)
{
    BEGIN_FUNCTION("IrsRoleInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_IRS_USR_ROLE_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT IrsUsrRoleIdIsExist(char* usrName, int roleId, BOOL *status)
{
    BEGIN_FUNCTION("IrsUsrRoleIdIsExist");
    UsrBaseInfoT usr_info;
    BOOL role_exist = FALSE;
    int i = 0;
    ResCodeT rc = NO_ERR;

    memset(&usr_info, 0, sizeof(UsrBaseInfoT));
    rc = IrsUsrInfoGetByName(usrName, &usr_info);
    RAISE_ERR(rc, RTN);
    
    if (usr_info.roleId[roleId-1] == 1){
        role_exist = TRUE;
    }    
    
    *status = role_exist;

    EXIT_BLOCK();
    RETURN_RESCODE;

}

