/***
Created on Aug 17, 2017
@author: Jiawang.Xie
@version $Id
***/

#ifndef _ACTIVE_INFO_H_
#define _ACTIVE_INFO_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */
#include "data_type.h"
#include "common_hash.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define MAX_HOST_LEN            20
#define MAX_HA_TIME_LEN         10


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct ActiveInfoHeadS
{
    vectorT     allSetIds[GET_BIT_VECT_LEN(MAX_SET_CNT)];   /* ��Ʒ����Ż��� */
} ActiveInfoHeadT, *pActiveInfoHeadT;

typedef struct ActiveInfoS
{
    int64       setId;                      /* ��Ʒ����� */
    char        primaryHost[MAX_HOST_LEN];  /* �������� */
    char        backupHost[MAX_HOST_LEN];   /* �������� */
    char        haTime[MAX_HA_TIME_LEN];    /* ��������ʱ�� */
} ActiveInfoT, *pActiveInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Create shared memory. */
ResCodeT ActiveInfoShmCreate();

/* Attach to the shared memory. */
ResCodeT ActiveInfoShmAttach();

/* Detach from the shared memory. */
ResCodeT ActiveInfoShmDetach();

/* Delete shared memory. */
ResCodeT ActiveInfoShmDelete();


/* Read data from Table [ACTIVE_INFO] and load these data into shared memory.
   Call this method before calling other methods. Or call this method to
   reload data from DB. */
ResCodeT ActiveInfoLoadFromDB(int32 connId);

/* Search the ActiveInfo by specifying the setId. */
ResCodeT ActiveInfoGetById(uint64 setId, pActiveInfoT pActiveInfo);

/* Search the ActiveInfo by specifying the setId.
   The return value ppActiveInfo is the direct address of active info in the Hash shared memory. */
ResCodeT ActiveInfoGetByIdExt(uint64 setId, pActiveInfoT *ppActiveInfo);

/* Get the active info header. */
ResCodeT GetActiveHead(ActiveInfoHeadT * head);

/* Get all set id ptr. */
ResCodeT GetAllSetIdsPtr(vectorT ** pAllSetIds);

/* Get all active info ptr. */
ResCodeT GetAllActiveInfoPtr(pActiveInfoT* pAllActiveInfo);


#endif /* _ACTIVE_INFO_H_ */
