﻿/***
Created on June 28, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _CREDIT_TYPE_
#define _CREDIT_TYPE_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define FIGURES_OF_RISK_COEFFICIENCY_IRS         5         /* IRS市场风险系数的小数位数 */
#define FIGURES_OF_RISK_COEFFICIENCY_SIRS        5         /* SIRS市场风险系数的小数位数 */

#define FIGURES_OF_CREDIT_AMOUNT                 3         /* 授信额度的小数位数 */ 
#define FIGURES_OF_BRDG_FEE                      5         /* 桥费用的小数位数 */

//#define CONTRCT_NAME_LENGTH                      56
#define CONTRCT_CODE_LENGTH                      50

#define CREDIT_HASH_KEY_LENGTH                   56
#define CREDIT_BRDG_HASH_KEY_LENGTH              56
#define CREDIT_RELATION_FLAG_LENGTH              1
#define RISK_CFCNT_HASH_KEY_LENGTH               64
#define RISK_CFCNT_SIRS_HASH_KEY_LENGTH          64
#define CREDIT_HASH_KEY_DELIMITER                '&'


// TODO: these two error codes should be moved to err_cod.h
#define ERR_CREDIT_STATUS_INVALID                60001
#define ERR_RISK_COEFFICIENCY_STATUS_INVALID     60002

#define CREDIT_STATUS_VALID                      1
#define RISK_COEFFICIENCY_STATUS_VALID           1

#define keyRiskCfcnt_orgId                       keyRiskCfcnt.orgId
#define keyRiskCfcnt_cntrctName                  keyRiskCfcnt.cntrctName
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 授信额度 */
typedef struct CreditS
{
    char            hashKey[CREDIT_HASH_KEY_LENGTH];              /* 授信信息的HashKey,由 授信机构标识+被授信机构标识 组成 */
    uint32          crdtOrgId;                                    /* 授信机构标识        */    
    uint32          crdtdOrgId;                                   /* 被授信机构标识   */         
    uint64          intlCrdtAmnt;                                 /* 初始授信额度     */         
    char            crdtRlFlag[CREDIT_RELATION_FLAG_LENGTH];      /* 授信关系标识 枚举： 0 无关系 1 有关系 （机构表的授信方式是关系授信时填写，额度授信时是null）    */    
    uint64          usedCrdtAmnt;                                 /* 累计已使用授信额度  */          
    uint64          rmnCrdtAmnt;                                  /* 当前剩余授信额度    */        
    uint32          crdtTerm;                                     /* 最长期限（年）      */    
    short           st;                                           /* 授信状态 0-禁用；1-启用  */  
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} CreditT, *pCreditT;


/* 桥机构授信 */
typedef struct CreditBrdgS
{
    char            hashKey[CREDIT_BRDG_HASH_KEY_LENGTH];    /* 桥授信信息的HashKey,由 桥机构ID+机构ID 组成 */
    uint32          brdgOrgId;                               /* 桥机构ID  */
    uint32          orgId;                                   /* 机构ID    */    
    short           st;                                      /* 桥授信状态，枚举值：0-禁用，1-启用    */
    short           brdgRlFlag;                              /* 桥关系，枚举值：0-无关系，1-有关系    */
    uint64          brdgFee;                                 /* 桥费用（BP）   */        
    uint32          crdtTerm;                                /* 最长期限（年） */       
    uint64          pos;                                     /* 在内存Hash结构中的位置 */
} CreditBrdgT, *pCreditBrdgT;

typedef struct PrimKeyRiskCfcntS
{
    uint32          orgId;                                  /* 机构系列号  */
    uint32          uFiller;                                /* 填充位  */  
    char            cntrctName[CONTRCT_CODE_LENGTH];        /* 合约系列号  */
    char            cFiller[FILL_6_LEN];                    /* 填充位 */
} PrimKeyRiskCfcntT, *pPrimKeyRiskCfcntT;

/* 授信额度风险系数(利率互换市场) */
typedef struct RiskCfcntS
{
    PrimKeyRiskCfcntT keyRiskCfcnt;                         /* 利率互换市场授信额度风险系数信息的HashKey */       
    uint64          rskCfcntVal;                            /* 风险系数    */       
    uint64          pos;                                    /* 在内存Hash结构中的位置 */
    short           st;                                     /* 风险系数状态 0-禁用；1-启用； */
    char            cFiller[FILL_6_LEN];                    /* 填充位 */
} RiskCfcntT, *pRiskCfcntT;


/* 授信额度风险系数(标准利率互换市场) */
typedef struct RiskCfcntSirsS
{
    char            hashKey[RISK_CFCNT_SIRS_HASH_KEY_LENGTH];    /* 标准利率互换市场授信额度风险系数信息的HashKey,由 机构ID+合约代码 组成 */
    uint32          orgId;                                       /* 机构ID号  */      
    char            cntrctCode[CONTRCT_CODE_LENGTH];             /* 合约代码，格式：合约前缀_合约月份  */        
    uint64          rskCfcntVal;                                 /* 风险系数    */       
    short           st;                                          /* 风险系数状态 0-禁用；1-启用； */    
    uint64          pos;                                         /* 在内存Hash结构中的位置 */
} RiskCfcntSirsT, *pRiskCfcntSirsT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read data from Table [RSK_CFCNT] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT IrsRiskCfcntLoadFromDB(int32 connId);

/* Get the IRS risk coefficiency value returned in pRskCfcnt by specifying org id and the IRS contract name. */
ResCodeT IrsRiskCfcntGetByKey(uint32 orgId, char *cntrctName, pRiskCfcntT pRskCfcnt);

/* Get the IRS risk coefficiency value returned in ppRskCfcnt by specifying org id and the IRS contract name. 
   The return value ppRskCfcnt is the direct address of risk coefficient info in the Hash shared memory. */
ResCodeT IrsRiskCfcntGetByKeyExt(uint32 orgId, char *cntrctName, pRiskCfcntT *ppRskCfcnt);

/* Get the IRS risk coefficiency value returned in pRskCfcnt by specifying the position in the hash table. */
ResCodeT IrsRiskCfcntGetByPos(uint64 rskPos, pRiskCfcntT pRskCfcnt);

/* Get the IRS risk coefficiency value returned in ppRskCfcnt by specifying the position in the hash table. 
   The return value ppRskCfcnt is the direct address of risk coefficient info in the Hash shared memory. */
ResCodeT IrsRiskCfcntGetByPosExt(uint64 rskPos, pRiskCfcntT *ppRskCfcnt);

/* Attach to the shared memory. */
ResCodeT IrsRiskCfcntAttachToShm();

/* Detach from the shared memory. */
ResCodeT IrsRiskCfcntDetachFromShm();




/* Read data from Table [RSK_CFCNT_SIRS] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT SirsRiskCfcntLoadFromDB(int32 connId);

/* Get the SIRS risk coefficiency value returned in riskCfcntVal by specifying org id and the SIRS contract code. */
ResCodeT SirsRiskCfcntGetByKey(uint32 orgId, char *cntrctCode, pRiskCfcntSirsT pRskCfcntSirs);

/* Get the SIRS risk coefficiency value returned in riskCfcntVal by specifying org id and the SIRS contract code. 
   The return value ppRskCfcntSirs is the direct address of SIRS risk coefficient info in the Hash shared memory. */
ResCodeT SirsRiskCfcntGetByKeyExt(uint32 orgId, char *cntrctCode, pRiskCfcntSirsT *ppRskCfcntSirs);

/* Get the SIRS risk coefficiency value returned in riskCfcntVal by specifying the position in the hash table. */
ResCodeT SirsRiskCfcntGetByPos(uint64 rskPos, pRiskCfcntSirsT pRskCfcntSirs);

/* Get the SIRS risk coefficiency value returned in riskCfcntVal by specifying the position in the hash table. 
   The return value ppRskCfcntSirs is the direct address of SIRS risk coefficient info in the Hash shared memory. */
ResCodeT SirsRiskCfcntGetByPosExt(uint64 rskPos, pRiskCfcntSirsT *ppRskCfcntSirs);

/* Attach to the shared memory. */
ResCodeT SirsRiskCfcntAttachToShm();

/* Detach from the shared memory. */
ResCodeT SirsRiskCfcntDetachFromShm();




/* Read data from Table [CRDT] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT CreditInfoLoadFromDB(int32 connId);

/* Get credit info by specifying org id and counterparty org id. */
ResCodeT CreditInfoGetByKey(uint32 orgId, uint32 partyOrgId, pCreditT pCrdtInfo);

/* Get credit info by specifying org id and counterparty org id.
   The return value ppCrdtInfo is the direct address of credit info in the Hash shared memory. */
ResCodeT CreditInfoGetByKeyExt(uint32 orgId, uint32 partyOrgId, pCreditT *ppCrdtInfo);

/* Get credit info by specifying the position in the hash table. */
ResCodeT CreditInfoGetByPos(uint64 crdtPos, pCreditT pCrdtInfo);

/* Get credit info by specifying the position in the hash table.
   The return value ppCrdtInfo is the direct address of credit info in the Hash shared memory. */
ResCodeT CreditInfoGetByPosExt(uint64 crdtPos, pCreditT *ppCrdtInfo);

/* Update the UsedCreditAmount and RemainedCreditAmount of credit info. */
ResCodeT CreditInfoUpdateByKey(pCreditT pCrdtInfo);

/* Update the UsedCreditAmount and RemainedCreditAmount of credit info. */
ResCodeT CreditInfoUpdateByPos(uint64 crdtPos, pCreditT pCrdtInfo);

/* Save all the data into DB. */
ResCodeT CreditInfoSaveToDB();

/* update the shared memory. */
ResCodeT CreditInfoUpdateByOrgId(uint32 orgId, uint32 partyOrgId, pCreditT pCrdtInfo);

ResCodeT CreditInfoUpdateByPos(uint64 creditPos, pCreditT pCrdtInfo);

/* Attach to the shared memory. */
ResCodeT CreditInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT CreditInfoDetachFromShm();

ResCodeT CreditInfoIterExt(uint32 * pos, pCreditT *ppData);

/* Read data from Table [CRDT_BRDG] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT BridgeCreditInfoLoadFromDB(int32 connId);

/* Get bridge credit info by specifying bridge org id and org id. */
ResCodeT BridgeCreditInfoGetByKey(uint32 brdgOrgId, uint32 orgId, pCreditBrdgT pBrdgCrdtInfo);

/* Get bridge credit info by specifying bridge org id and org id. 
   The return value ppBrdgCrdtInfo is the direct address of bridge credit info in the Hash shared memory. */
ResCodeT BridgeCreditInfoGetByKeyExt(uint32 brdgOrgId, uint32 orgId, pCreditBrdgT *ppBrdgCrdtInfo);

/* Get bridge credit info by specifying the position in the hash table. */
ResCodeT BridgeCreditInfoGetByPos(uint64 brdgOrgPos, pCreditBrdgT pBrdgCrdtInfo);

/* Get bridge credit info by specifying the position in the hash table. 
   The return value ppBrdgCrdtInfo is the direct address of bridge credit info in the Hash shared memory. */
ResCodeT BridgeCreditInfoGetByPosExt(uint64 brdgOrgPos, pCreditBrdgT *ppBrdgCrdtInfo);

/* Get an array of Bridge Credit Info that is has the lowest Bridge Fee.
   These Bridge Credit Info should meet the following conditions:
       * the bridge org should have bridge credit relations with both offer side and bid side.
       * the contract term is smaller than either credit term of both sides.
   The return result is one CreditBrdgT offering the lowest bridge fee. 
   Or an array of CreditBrdgT that all have the same lowest fee. 
   */
/* Memo: when implementing this method,in order to find the bridge org that has the lowest bridge fee quickly,
         maybe a sorted array should be kept. Sort key of this array is the orgid. 
         the sorted array can be created in the method of Load method. */
ResCodeT GetBestBridgeFee(uint32 offerOrgId, uint32 bidOrgId, uint32 contractTerm, pCreditBrdgT crdtBrdgArray);

/* Attach to the shared memory. */
ResCodeT BridgeCreditInfoAttachToShm();

/* Clear the data stored in the shared memory and free the shared memory. */
ResCodeT BridgeCreditInfoDetachFromShm();





#endif /* _CREDIT_TYPE_ */
