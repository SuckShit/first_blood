/***
Created on Aug 30, 2017
@author: XiaoPing Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>

/* Project Header File */
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "shm.h"
#include "uti_tool.h"
#include "org_onln.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define ORG_ONLN_ITER_CTRL       0
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT orgOnlnHashHandler;
static BOOL orgOnlnHashLoadFlag = FALSE;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT OrgOnlnCreate(uint64 size)
{
    BEGIN_FUNCTION("OrgOnlnCreate");

    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    void *pShmRoot = NULL;
    OrgOnlineT orgOnlnData = {0};
    OrgOnlineT data;
    BOOL existFlag = FALSE;
    uint32 pos;

    /* If the org online load flag is FALSE, creation of the hashtable is necessary. */
    if (orgOnlnHashLoadFlag == FALSE) 
    {
        recInfo.recSize = sizeof(OrgOnlineT);
        recInfo.keyOffset = offsetof(OrgOnlineT, orgId);
        recInfo.keySize = sizeof(uint64);

        recInfo.recCnt = size;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_ORG_ONLN_NAME), 
                                recInfo, TRUE, &pShmRoot, &orgOnlnHashHandler);
        if (NOTOK(rc)) {
            THROW_RESCODE(rc);
        }

        /* Add a special data for saving iterate pos */
        memset(&orgOnlnData, 0x00, sizeof(OrgOnlineT));
        orgOnlnData.orgId = ORG_ONLN_ITER_CTRL;

        rc = CmnHashCheckData(orgOnlnHashHandler, &orgOnlnData.orgId, &existFlag, &pos, (void*)&data);
        RAISE_ERR(rc, RTN);
        
        if (existFlag == TRUE){
            /* If the ordId already exists in the hashtable, throw the error. */
            THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
        }

        orgOnlnData.pos = CMN_LIST_NULL_NODE;

        rc = CmnHashLogData(orgOnlnHashHandler, &orgOnlnData, pos, TRUE, TRUE);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        /* If the org online hashtable has already been created, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    
    orgOnlnHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    orgOnlnHashLoadFlag = FALSE;
    RETURN_RESCODE;
}

ResCodeT OrgOnlnAddById( uint64 orgId )
{
    BEGIN_FUNCTION("OrgOnlnAddById");
    
    ResCodeT rc = NO_ERR;
    OrgOnlineT orgOnlnData;
    OrgOnlineT data;
    BOOL existFlag = FALSE;
    uint32 pos;

    memset(&orgOnlnData, 0x00, sizeof(OrgOnlineT));

    orgOnlnData.orgId = orgId;

    rc = CmnHashCheckData(orgOnlnHashHandler, &orgOnlnData.orgId, &existFlag, &pos, (void*)&data);
    RAISE_ERR(rc, RTN);
    
    if (existFlag == TRUE){
        /* If the orgId already exists in the hashtable */
        /* It means there's a new user of the org logon */
        orgOnlnData.usrCnt = data.usrCnt + 1;
        orgOnlnData.pos = pos;

        rc = CmnHashUpdateData( orgOnlnHashHandler, &orgOnlnData, pos );
        RAISE_ERR(rc, RTN);
    }
    else
    {
        orgOnlnData.usrCnt = 1;
        orgOnlnData.pos = pos;

        rc = CmnHashLogData( orgOnlnHashHandler, &orgOnlnData, pos, TRUE, TRUE );
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT OrgOnlnDeleteById( uint64 orgId )
{
    BEGIN_FUNCTION("OrgOnlnDeleteById");
    
    ResCodeT rc = NO_ERR;
    OrgOnlineT data;
    BOOL existFlag = FALSE;
    uint32 pos;
    
    rc = CmnHashCheckData(orgOnlnHashHandler, &orgId, &existFlag, &pos, (void*)&data);
    RAISE_ERR(rc, RTN);
    
    if (existFlag == FALSE){
        /* If the ordId doesn't exist in the hashtable, throw the error. */
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    if ( data.usrCnt > 1 )
    {
        data.usrCnt--;

        rc = CmnHashUpdateData( orgOnlnHashHandler, &data, pos );
        RAISE_ERR(rc, RTN);
    }
    else
    {
        rc = CmnHashDeleteData(orgOnlnHashHandler, pos);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT OrgOnlnIterExt(uint32 *orgOnlnPos, pOrgOnlineT *ppOrgOnln)
{
    BEGIN_FUNCTION("OrgOnlnIterExt");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    pOrgOnlineT pOrgOnln = NULL;
    
    rc = CmnHashIterDataExt(orgOnlnHashHandler, orgOnlnPos, (void **)ppOrgOnln);
    RAISE_ERR(rc, RTN);

    /* If Iterate ORG_ONLN_ITER_CTRL, jump to next */
    pOrgOnln = *ppOrgOnln;
    if ( pOrgOnln->orgId == ORG_ONLN_ITER_CTRL )
    {
        rc = CmnHashIterDataExt(orgOnlnHashHandler, orgOnlnPos, (void **)ppOrgOnln);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgOnlnGetById(uint64 orgId, pOrgOnlineT pOrgOnln)
{    
    ResCodeT rc = NO_ERR;
    pOrgOnlineT pData;
    
    BEGIN_FUNCTION("OrgOnlnGetById");
    /* Call OrgOnlnGetByIdExt to get the org online info. */
    rc = OrgOnlnGetByIdExt(orgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pOrgOnln, pData, sizeof(OrgOnlineT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgOnlnGetByIdExt(uint64 orgId, pOrgOnlineT *ppOrgOnln)
{    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    uint64 keyId;
    
    BEGIN_FUNCTION("OrgOnlnGetByIdExt");
    /* Check if the org info exists in the hash table. */
    keyId = orgId;
    rc = CmnHashCheckDataExt(orgOnlnHashHandler, &keyId, &isExist, &nodePos, (void**)ppOrgOnln);
    RAISE_ERR(rc, RTN);
    
    /* If the org info doesn't exist, throw the error code. */
    if (isExist == FALSE) {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgOnlnGetByPos(uint32 orgPos, pOrgOnlineT pOrgOnln)
{
    ResCodeT rc = NO_ERR;
    pOrgOnlineT pData;
    
    BEGIN_FUNCTION("OrgOnlnGetByPos");
    rc = OrgOnlnGetByPosExt(orgPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pOrgOnln, pData, sizeof(OrgOnlineT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgOnlnGetByPosExt(uint32 orgPos, pOrgOnlineT *ppOrgOnln)
{    
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION("OrgOnlnGetByPosExt");
    rc = CmnHashReadDataAddrByPos(orgOnlnHashHandler, orgPos, (void**)ppOrgOnln);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OrgOnlnAttachToShm(){

    BEGIN_FUNCTION("OrgOnlnAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_ORG_ONLN_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    orgOnlnHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT OrgOnlnDetachFromShm()
{
    ResCodeT rc = NO_ERR;

    BEGIN_FUNCTION("OrgOnlnDetachFromShm");
    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_ORG_ONLN_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IterOnlOrg( uint32 curOrgPos, uint32 *nxtOrgPos )
{
    BEGIN_FUNCTION("IterOnlOrg");
    ResCodeT rc = NO_ERR;

    uint32 pos;
    uint32 nxtPos = 0;

    OrgOnlineT orgOnlnNxtData = {0};

    rc = CmnHashLstNxtData( orgOnlnHashHandler, &curOrgPos, &nxtPos, (void *)&orgOnlnNxtData );
    RAISE_ERR(rc, RTN);

    if ( nxtPos == CMN_LIST_NULL_NODE )
    {
        *nxtOrgPos = CMN_LIST_NULL_NODE;
        THROW_RESCODE( NO_ERR );
    }

    if ( orgOnlnNxtData.orgId == ORG_ONLN_ITER_CTRL )
    {
        pos = nxtPos;
        memset(&orgOnlnNxtData, 0x00, sizeof(OrgOnlineT));
        rc = CmnHashLstNxtData( orgOnlnHashHandler, &pos, &nxtPos, (void *)&orgOnlnNxtData );
        RAISE_ERR(rc, RTN);
    }

    if ( nxtPos == CMN_LIST_NULL_NODE )
    {
        *nxtOrgPos = CMN_LIST_NULL_NODE;
        THROW_RESCODE( NO_ERR );
    }
    else
    {
        *nxtOrgPos = orgOnlnNxtData.pos;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdtLstBrdgOrg( uint32 onlnOrgPos )
{
    BEGIN_FUNCTION("UpdtLstBrdgOrg");
    ResCodeT rc = NO_ERR;

    uint32 pos;
    OrgOnlineT data;
    OrgOnlineT orgOnlnData;
    BOOL existFlag = FALSE;

    pOrgOnlineT pOrgOnln = NULL;

    memset(&orgOnlnData, 0x00, sizeof(OrgOnlineT));
    orgOnlnData.orgId = ORG_ONLN_ITER_CTRL;

    rc = CmnHashCheckData( orgOnlnHashHandler, &orgOnlnData.orgId,
                                &existFlag, &pos, (void*)&data );
    RAISE_ERR(rc, RTN);

    if ( existFlag == FALSE )
    {
        /* If it isn't exists in the hashtable, throw error. */
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    orgOnlnData.pos = onlnOrgPos;

    rc = CmnHashUpdateData( orgOnlnHashHandler, (void*)&orgOnlnData, pos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetLstBrdgOrg( uint32 *onlnOrgPos )
{
    BEGIN_FUNCTION("GetLstBrdgOrg");
    ResCodeT rc = NO_ERR;

    uint32 pos;
    OrgOnlineT data;
    OrgOnlineT orgOnlnData;
    BOOL existFlag = FALSE;

    memset(&orgOnlnData, 0x00, sizeof(OrgOnlineT));
    orgOnlnData.orgId = ORG_ONLN_ITER_CTRL;

    rc = CmnHashCheckData(orgOnlnHashHandler, &orgOnlnData.orgId,
                                &existFlag, &pos, (void*)&data);
    RAISE_ERR(rc, RTN);

    if ( existFlag == FALSE )
    {
        /* If it isn't exists in the hashtable, throw error. */
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    //rc = CmnHashReadDataByPos( orgOnlnHashHandler, pos, (void *)&data );
    //RAISE_ERR(rc, RTN);

    if ( data.pos == CMN_LIST_NULL_NODE )
    {
        *onlnOrgPos = CMN_LIST_NULL_NODE;
        THROW_RESCODE(NO_ERR);
    }

    *onlnOrgPos = data.pos;

    EXIT_BLOCK();
    RETURN_RESCODE;
}