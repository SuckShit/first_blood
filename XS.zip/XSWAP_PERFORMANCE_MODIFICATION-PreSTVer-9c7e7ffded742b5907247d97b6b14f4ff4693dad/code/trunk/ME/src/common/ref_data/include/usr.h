/***
Created on June 29, 2017
@author: Gao.Liu
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _USR_
#define _USR_

#include "gtest/gtest.h"
#include "UsrDb.h"
#include "common_hash.h"
#include "shm_name.h"
#include "usr_role.h"
/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define USR_NAME_MAX_LENGTH    100
#define NAME_DESC_MAX_LENGTH    100
#define NORMAL_DATA_LENGTH        8
#define SESN_ID_MAX_LENGTH        100
#define LOG_ON_TIME_DATA_MAX_LENGTH    30
#define ORDR_SUBMIT_USR_EMG         "-"
#define ORDR_OPER_BY_SYS_USR        "SYSTEM"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef struct usrBaseInfo
{
    char  usrLgnNm[USR_NAME_MAX_LENGTH];            /*用户登录名*/
    char  nmDesc[NAME_DESC_MAX_LENGTH];
    int64  orgId;                    /*机构号*/
    char  usrSt[NORMAL_DATA_LENGTH];                    /*用户状态：-1-作废；0-锁定；1-启用； */
    char  sysSrc[NORMAL_DATA_LENGTH];                /*用户来源系统：1-本币*/
    char  apiF[NORMAL_DATA_LENGTH];                        /*API用户标志，枚举值：0-否，1-是 */
    char  ordrPrvlgF[NORMAL_DATA_LENGTH];                /*提单权限标志_IRS，枚举值：1-客户端，2-API  */
    char  ordrPrvlgMdfyF[NORMAL_DATA_LENGTH];            /*提单权限修改标志_IRS（前台用户是否可以修改），枚举值：0-否，1-是   */
    char  ordrPrvlgFSirs[NORMAL_DATA_LENGTH];            /*提单权限标志_SIRS，枚举值：1-客户端，2-API     */
    char  ordrPrvlgMdfyFSirs[NORMAL_DATA_LENGTH];        /*提单权限修改标志_SIRS（前台用户是否可以修改），枚举值：0-否，1-是  */
    char  ordrPrvlgFSbfccp[NORMAL_DATA_LENGTH];            /*提单权限标志_SBFCCP，枚举值：1-客户端，2-API     */
    char  ordrPrvlgMdfyFSbfccp[NORMAL_DATA_LENGTH];        /*提单权限修改标志_SBFCCP（前台用户是否可以修改），枚举值：0-否，1-是*/
    BOOL usrOnlnStatus;                /*usr onln登录状态*/
    int32 roleId[ROLE_ID_MAX_COUNT];                /*usr role表id*/
    char sesnId[SESN_ID_MAX_LENGTH];                /*usr onln 表 sesn id*/
    int32 lgnTp;                    /*usr onln 表 log on Tp*/
    char lgnTm[LOG_ON_TIME_DATA_MAX_LENGTH];                    /*usr onln 表登录时间*/
    int16 filler;
    int32 pos;                        /*usr data 地址*/
    int32    mktTp[8];              /*市场号*/
    int32    mktSt[8];              /*市场状态*/
    int32    ocoOrdCnt;             /* OCO order counter */
    SubNodeT        usrListNode;
    SubNodeT    usrMrkPrgListNode;
}UsrBaseInfoT, *pUsrBaseInfoT;


typedef enum{
    alignInc = 0,
    alignNor,
    alignMax
}alignTypeT;
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Read data from Table [Usr] and load these data into shared memory.
Call this method before calling other methods. Or call this method to reload data from DB. */
ResCodeT IrsUsrInfoLoadFromDb(int32 connid);
/* get usr info by name */
ResCodeT IrsUsrInfoGetByName(char* usrName, pUsrBaseInfoT pUsr);
/* get usr info by name ext */
ResCodeT IrsUsrInfoGetByNameExt(char* usrName, pUsrBaseInfoT* pUsr);
/* get usr info by pos */
ResCodeT IrsUsrInfoGetByPos(uint64 UsrPos, pUsrBaseInfoT pUsr);
/* get usr info by pos ext. */
ResCodeT IrsUsrInfoGetByPosExt(uint64 UsrPos, pUsrBaseInfoT* pUsr);
/*attach usr info with share memory*/
ResCodeT IrsUsrInfoAttachToShm(void);
/*detach usr info from share memory*/
ResCodeT IrsUsrInfoDetachFromShm(void);
/*split usr string by ','*/
ResCodeT IrsUsrStrtok(char* string, int* token, alignTypeT type);
/*get use market status*/
ResCodeT IrsUsrMktStatusGet(char* usrName, int mktTp, BOOL *status);
ResCodeT UserDelete(uint64 pos);
ResCodeT UserAdd(UsrBaseInfoT* pUsr);
ResCodeT OnUserAndUsrRoleUpdateByOrgIdFreeze(uint64 orgIdx, int16 reqType);
ResCodeT UpdateUsrMrkPrvlg(uint64 usrPos, int32 market, int32* pPrvlg);
ResCodeT UpdateUsrMrkPrvlgByUsr(int64 usrPos, int32 market, int32* pPrvlg);
ResCodeT IrsUsrInfoGetCnt(uint64 * ttlCnt, uint64 * pUsedCnt);
ResCodeT IrsUsrInfoIterExt(uint32 * usrPos, pUsrBaseInfoT * ppData);
#endif
