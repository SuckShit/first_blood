/***
Created on July 25, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_macro.h"
#include "db_comm.h"
#include "cfg_lib.h"
#include "../include/ref_data.h"
#include "../include/contract_info.h"
#include "../include/base_param.h"
#include "../include/base_param_api.h"
#include "../include/usr.h"
#include "../include/usr_role.h"
#include "../include/usr_onln.h"
#include "../include/credit_info.h"
#include "../include/credit_info_sbfccp.h"
#include "../include/org_info.h"
#include "../include/prdct_info.h"
#include "../include/active_info.h"
#include "../include/sys_st_rsrc.h"
#include "../include/role_prvlg.h"
#include "../include/mkt_st_cfg.h"
#include "../include/acnt_info.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT RefDataLoadFromDB()
{

    BEGIN_FUNCTION("RefDataLoadFromDB");
    ResCodeT rc = NO_ERR;
    int32 connId;
    struct cfgValueS cfgValue = {0};

    /* Get config value for the system  */
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnInit();
    RAISE_ERR(rc, RTN);
    // get the DB connection
    rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &connId);
    RAISE_ERR(rc, RTN);

    /* Load the organization info */
    rc = OrgInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the bridge organization info */
    rc = BrdgOrgInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the IRS contract info */
    rc = IrsCntrctInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /*load Usr info*/
    rc = IrsUsrInfoLoadFromDb(connId);
    RAISE_ERR(rc, RTN);

    /*load usr role info*/
    rc = IrsRoleInfoLoadFromDb(connId);
    RAISE_ERR(rc, RTN);

    /*load usr online info*/
    rc = IrsUsrOnlnInfoLoadFromDb(connId);
    RAISE_ERR(rc, RTN);

    /* Load the base parameters info */
    rc = BaseParamLoadFromDB(connId);
    RAISE_ERR(rc, RTN);
    
    /* Load the api base parameters info */
    rc = BaseParamApiLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the credit info */
    rc = CreditInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the bridge credit info */
    rc = BridgeCreditInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the risk coefficient info */
    rc = IrsRiskCfcntLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the SIRS risk coefficient info */
    rc = SirsRiskCfcntLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the product info */
    rc = PrdctInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the IrsCntrct info */
//    rc = IrsCntrctInfoLoadFromDB(connId);
//    RAISE_ERR(rc, RTN);

    /* Load the active info */
    rc = ActiveInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the system status resource info */
    rc = SysStRsrcLoadFromDB(connId);
    RAISE_ERR(rc, RTN);

    /* Load the role privilege info */
    rc = RolePrvlgLoadFromDB(connId);
    RAISE_ERR(rc, RTN);
    
    /* Load the market status config info */
    rc = MktStCfgLoadFromDB(connId);
    RAISE_ERR(rc, RTN);
    
    /* Load the SBFCCP credit info */
    rc = CreditSbfCcpInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);
    
    /* Load the SBFCCP contract position info */
    rc = CntrctPstnSbfCcpLoadFromDB(connId);
    RAISE_ERR(rc, RTN);
	
	/* Load the account info */
    rc = AcntInfoLoadFromDB(connId);
    RAISE_ERR(rc, RTN);
	
	/* Load the SBF deposit account info */
    rc = DpstAcntInfoSbfLoadFromDB(connId);
    RAISE_ERR(rc, RTN);


    rc = DbCmmnDisconnect(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT RefDataDetachFromShm(){

    BEGIN_FUNCTION("RefDataDetachFromShm");

    ResCodeT rc = NO_ERR;

    /* Detach the IRS contract info from the shared memory. */
    rc = IrsCntrctInfoDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the base parameters info from the shared memory. */
    rc = BaseParamDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the api base parameters info from the shared memory. */
    rc = BaseParamApiDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the organization info from the shared memory. */
    rc = OrgInfoDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the bridge organization info from the shared memory. */
    rc = BrdgOrgInfoDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the credit info from the shared memory. */
    rc = CreditInfoDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the bridge credit info from the shared memory. */
    rc = BridgeCreditInfoDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the IRS risk coefficient info from the shared memory. */
    rc = IrsRiskCfcntDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the SIRS risk coefficient info from the shared memory. */
    rc = SirsRiskCfcntDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the product info from the shared memory. */
    rc = PrdctInfoDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the active info from the shared memory. */
    rc = ActiveInfoShmDetach();
    RAISE_ERR(rc, RTN);
    
    /* Detach the market status config info from the shared memory. */
    rc = MktStCfgDetachFromShm();
    RAISE_ERR(rc, RTN);
    
    /* Detach the SBFCCP credit info from the shared memory. */
    rc = CreditSbfCcpInfoDetachFromShm();
    RAISE_ERR(rc, RTN);
    
    /* Detach the SBFCCP contract position info from the shared memory. */
    rc = CntrctPstnSbfCcpDetachFromShm();
    RAISE_ERR(rc, RTN);
	
	/* Detach the account info from the shared memory. */
    rc = AcntInfoDetachFromShm();
    RAISE_ERR(rc, RTN);
	
	/* Detach the SBF deposit account info from the shared memory. */
    rc = DpstAcntInfoSbfDetachFromShm();
    RAISE_ERR(rc, RTN);

    /* Detach the user info from the shared memory. */
    // rc = IrsCntrctInfoLoadFromDB();
    // RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}
