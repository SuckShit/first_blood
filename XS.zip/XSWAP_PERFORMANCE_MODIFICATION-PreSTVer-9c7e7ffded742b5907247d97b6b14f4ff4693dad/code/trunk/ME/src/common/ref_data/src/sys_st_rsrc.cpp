﻿/***
Created on Aug 19, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "sys_st_rsrc.h"
#include "SysStRsrcDb.h"



/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT sysStRsrcHashHandler;


static BOOL sysStRsrcHashLoadFlag = FALSE;

static char delimiter[1] = {SYS_ST_RSRC_HASH_KEY_DELIMITER};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static void GenerateSysStRsrcHashKey(uint64 rsrcId, uint32 sysStId, char *pHashKey){

    memcpy(pHashKey, &rsrcId, sizeof(uint64));
    pHashKey = pHashKey + sizeof(uint64);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    memcpy(pHashKey, &sysStId, sizeof(uint32));
}
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT SysStRsrcLoadFromDB(int32 connId)
{

    BEGIN_FUNCTION("SysStRsrcLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    SysStRsrcT sysStRsrc;
    BOOL existFlag;
    uint32 pos;
    SysStRsrcT pData;
    SysStRsrc dbData;
    BOOL    bFrstFlg = TRUE;
    
    /* If the system status resource info load flag is FALSE, creation of the hashtable is necessary. */
    if (sysStRsrcHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [SYS_ST_RSRC] */
        rc = GetResultCntOfSysStRsrc(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(SysStRsrcT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(SysStRsrcT, hashKey);
        recInfo.keySize = SYS_ST_RSRC_HASH_KEY_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_SYS_ST_RSRC_NAME), 
                                recInfo, FALSE, &pShmRoot, &sysStRsrcHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextSysStRsrc(&bFrstFlg,connId, &dbData))){
    
            memset(&sysStRsrc, 0x00, sizeof(SysStRsrcT));
            memset(sysStRsrc.hashKey, 0x00, SYS_ST_RSRC_HASH_KEY_LENGTH);
            
            // Copy the retun value of fetchNextData into SysStRsrcT
            sysStRsrc.sysStId = dbData.sysStId;   
            sysStRsrc.rsrcId = dbData.rsrcId;  
       
            
            /* Generate the key to be hashed. The key will be created by combining the rsrcId and sysStId */
            GenerateSysStRsrcHashKey(sysStRsrc.rsrcId, sysStRsrc.sysStId, sysStRsrc.hashKey);
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(sysStRsrcHashHandler, (void*)sysStRsrc.hashKey, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            sysStRsrc.pos = pos;          
            
            rc = CmnHashLogData(sysStRsrcHashHandler, &sysStRsrc, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    sysStRsrcHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    sysStRsrcHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT SysStRsrcGetByKey(uint64 rsrcId, uint32 sysStId, pSysStRsrcT pSysStRsrc){

    BEGIN_FUNCTION("SysStRsrcGetByKey");
    
    ResCodeT rc = NO_ERR;
    pSysStRsrcT pData;
    
    /* Call SysStRsrcGetByKeyExt to get the system status resource info. */
    rc = SysStRsrcGetByKeyExt(rsrcId, sysStId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pSysStRsrc, pData, sizeof(SysStRsrcT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SysStRsrcGetByKeyExt(uint64 rsrcId, uint32 sysStId, pSysStRsrcT *ppSysStRsrc){

    BEGIN_FUNCTION("SysStRsrcGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[SYS_ST_RSRC_HASH_KEY_LENGTH];
    
    memset(key, 0x00, SYS_ST_RSRC_HASH_KEY_LENGTH);
    /* combine rsrcId and sysStId as the key to be hashed. */
    GenerateSysStRsrcHashKey(rsrcId, sysStId, key);
        

    /* Check if the system status resource info exists in the hash table. */
    rc = CmnHashCheckDataExt(sysStRsrcHashHandler, key, &isExist, &nodePos, (void**)ppSysStRsrc);
    RAISE_ERR(rc, RTN);
    
    /* If the credit info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SysStRsrcGetByPos(uint64 rsrcPos, pSysStRsrcT pSysStRsrc){

    BEGIN_FUNCTION("SysStRsrcGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pSysStRsrcT pData;
    
    rc = SysStRsrcGetByPosExt(rsrcPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pSysStRsrc, pData, sizeof(SysStRsrcT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SysStRsrcGetByPosExt(uint64 rsrcPos, pSysStRsrcT *ppSysStRsrc){

    BEGIN_FUNCTION("SysStRsrcGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(sysStRsrcHashHandler, rsrcPos, (void**)ppSysStRsrc);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT SysStRsrcAttachToShm(){

    BEGIN_FUNCTION("SysStRsrcAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_SYS_ST_RSRC_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    sysStRsrcHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SysStRsrcDetachFromShm(){

    BEGIN_FUNCTION("SysStRsrcDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_SYS_ST_RSRC_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}
