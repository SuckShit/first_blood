/***
Created on June 28, 2017
@author: Dongwei Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _ORG_INFO_
#define _ORG_INFO_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "common_hash.h"
#include "shm_name.h"
#include "org_def_ref.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define ORG_CODE_LENGTH                  56
#define ORG_NAME_CN_LENGTH               100
#define ORG_FULLNAME_CN_LENGTH           300
#define ORG_NAME_EN_LENGTH               100
#define ORG_TYPE_LENGTH                  300
#define CREDIT_OPERATOR_LENGTH           100
#define MARKET_TYPE_STATUS_LENGTH        5

#define USER_LOGON_NAME                  100

#define ORG_ST_ACTIVE                    1
#define BRDG_ORG_ST_ACTIVE               1
#define MARKET_TYPE_STATUS_ACTIVE        '1'


#define BRDG_ORG_CTRL_BODY_CNT          (sizeof(BrdgOrgInfoT)/sizeof(uint32) -2)


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 机构基础信息 */
typedef struct OrgInfoS {
    uint64          orgId;                                    /* 机构标识 6位      */
    char            orgCd[ORG_CODE_LENGTH];                   /* 机构编码 21位  */
    char            orgNmCn[ORG_NAME_CN_LENGTH];              /* 机构中文简称      */
    char            orgFullNmCn[ORG_FULLNAME_CN_LENGTH];      /* 机构中文全称      */
    char            orgNmEn[ORG_NAME_EN_LENGTH];              /* 机构英文简称      */
    short           orgSt;                                    /* 机构状态(0禁用、1活动) */    
    char            orgType[ORG_TYPE_LENGTH];                 /* 机构类型    */
    short           orgIrsSt;                                 /* IRS撮合系统机构状态(0禁用、1活动 2 删除)    */
    short           crdtMthd;                                 /* 授信方式 1 机构关系  0 授信额度授信    */
    short           crdtUpdMthd;                              /* 额度更新方式：0 使用初始额度 1 使用剩余初始额度    */
    short           crdtVldOrgFlag;                           /* 授信有效机构标识 0 无效 1 有效    */
    short           crdtOprtngSt;                             /* 授信操作状态 0 无操作 1正在操作    */
    char            crdtOprtr[CREDIT_OPERATOR_LENGTH];        /* 授信操作人 填写用户登录名 */
    short           brdgOrdrRfrshFlag;                        /* 桥订单刷新标志，枚举值：0-未刷新，1-需要刷新，2-已刷新 */
    int32           mktTypeSt[MARKET_TYPE_STATUS_LENGTH];     /* 各市场类型所对应的权限状态 0-禁用，1-启用  
                                                                 int32[0]-IRS，int32[1]-SIRS，int32[2]-SBF，int32[3]-SIRSCCP，int32[4]-SBFCCP */
    uint32          pos;                                      /* 在内存Hash结构中的位置 */
    MstrHdrT        usrListNode;
	int64           dfltAcntPos;                              /* 该机构的[默认资金账户信息]在[资金账户内存Hash]中的位置 */
	int64           dfltDpstAcntSbfPos;                       /* 该机构的[托管账户信息(SBF)]在[托管账户(SBF)内存Hash]中的位置 */
//    int32           crdtdOrgCnt;                              /* 该机构的有效对手方个数 */
} OrgInfoT, *pOrgInfoT;

/* 机构代码索引信息 */
typedef struct OrgCdPosInfoS {
    uint32          orgId;                                    /* 机构标识 6位      */
    char            orgCd[ORG_CODE_LENGTH];                   /* 机构编码 21位  */
    uint64          pos;                                      /* 在内存Hash结构中的位置 */
} OrgCdPosInfoT, *pOrgCdPosInfoT;

/* 桥机构信息 */
typedef struct BrdgOrgInfoS {
    uint32          orgId;                                    /* 机构ID */   
    short           brdgOrgSt;                                /* 桥机构状态，枚举值：0-禁用，1-启用 */
    uint64          brdgOrgOrdr;                              /* 桥机构顺序  */  
    short           brdgIntntnFlag;                           /* 桥意愿标志（机构本身是否愿意成为桥机构），枚举值：0-否，1-是 */
    short           brdgPrvlgFlag;                            /* 桥权限标志（场务是否允许成为桥机构），枚举值：0-否，1-是 */   
    short           brdgPrvlgFlagNext;                        /* 隔日生效的桥权限标志，枚举值：0-否，1-是  */  
    short           mdfySt;                                   /* 修改状态，枚举值：1-已修改，2-已生效  */  
    char            usrLgnNm[USER_LOGON_NAME];                /* 默认交易员 */    
    short           crdtOprtngSt;                             /* 授信操作状态，枚举值：0-无操作，1-正在操作 */
    char            crdtOprtr[CREDIT_OPERATOR_LENGTH];        /* 授信操作人，填写USR.USR_LGN_NM  */
    uint64          pos;                                      /* 在内存Hash结构中的位置 */
    MstrHdrT        usrMrkPrgListNode;
} BrdgOrgInfoT, *pBrdgOrgInfoT;


/* 桥机构信息 */
typedef struct BrdgOrgCtrlS {
    uint32          orgId;                                    /* 机构ID */   
    uint32          brdgOrgCnt;
    uint32          brdgOrg[BRDG_ORG_CTRL_BODY_CNT];
} BrdgOrgCtrlT, *pBrdgOrgCtrlT;

typedef struct OrgFreezeStS {
    int32           intOrgId;
    int32           intOrgSt;
    int32           intOldLgnTp;
    int32           intNewLgnTp;
    int32           intOldRoleId;
    int32           intNewRoleId;
} OrgFreezeStT, *pOrgFreezeStT;



typedef enum {
    IRS = 1,
    SIRS,
    SBF,
    SIRSCCP,
    SBFCCP
} MarketType;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Read data from Table [ORG_INFO] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT OrgInfoLoadFromDB(int32 connId);

/* Search the OrgInfo by specifying the orgId. */
ResCodeT OrgInfoGetById(uint64 orgId, pOrgInfoT pOrgInfo);

/* Search the OrgInfo by specifying the orgId. 
   The return value ppOrgInfo is the direct address of org info in the Hash shared memory. */
ResCodeT OrgInfoGetByIdExt(uint64 orgId, pOrgInfoT *ppOrgInfo);

/* Search the OrgInfo by specifying the position of org info in the hashtable. */
ResCodeT OrgInfoGetByPos(uint64 orgPos, pOrgInfoT pOrgInfo);

/* Search the OrgInfo by specifying the position of org info in the hashtable. 
   The return value ppOrgInfo is the direct address of org info in the Hash shared memory. */
ResCodeT OrgInfoGetByPosExt(uint64 orgPos, pOrgInfoT *ppOrgInfo);

/* Check if the OrgInfo specified by orgId has authorization in the market specified by mktType. */
ResCodeT IsAuthorizedInMarket(uint64 orgId, uint32 mktType, BOOL *isEntitled);

/* Attach to the shared memory. */
ResCodeT OrgInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT OrgInfoDetachFromShm();


/* Read data from Table [ORG_INFO_BRDG] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT BrdgOrgInfoLoadFromDB(int32 connId);

/* Search the OrgInfo by specifying the orgId. */
ResCodeT BrdgOrgInfoGetById(uint64 orgId, pBrdgOrgInfoT pBrdgOrgInfo);

/* Search the OrgInfo by specifying the orgId. 
   The return value ppOrgInfo is the direct address of org info in the Hash shared memory. */
ResCodeT BrdgOrgInfoGetByIdExt(uint64 orgId, pBrdgOrgInfoT *ppBrdgOrgInfo);

/* Search the OrgInfo by specifying the position of org info in the hashtable. */
ResCodeT BrdgOrgInfoGetByPos(uint64 orgPos, pBrdgOrgInfoT pBrdgOrgInfo);

/* Search the OrgInfo by specifying the position of org info in the hashtable. 
   The return value ppOrgInfo is the direct address of org info in the Hash shared memory. */
ResCodeT BrdgOrgInfoGetByPosExt(uint64 orgPos, pBrdgOrgInfoT *ppBrdgOrgInfo);

/* Check if the OrgInfo specified by orgId is a Bridge Organization. */
ResCodeT IsBridgeOrg(uint64 orgId, BOOL *isBrdg);

/* Get the next bridge organization. This method should be called when bridge function wants 
   to find the next available bridge organization. All the available bridge organizations are 
   stored in a link list and orders of these organizations are specified
   by the variable [brdgOrgOrdr] defined in the struct BrdgOrgInfoS. 
    */
ResCodeT GetNextBridgeOrg(pBrdgOrgInfoT pBrdgOrgInfo);

/* Attach to the shared memory. */
ResCodeT BrdgOrgInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT BrdgOrgInfoDetachFromShm();

ResCodeT OnOrgInfoStatus(short orgSt, int16 rqstType, pOrgFreezeStT pOrgFreeze);


ResCodeT UpdateOrgMrkPrvlg(uint64 orgPos, int32 market, int32*  pPrvlg);
ResCodeT IsOldBridgeOrg(uint64 orgPos, int32* pOldBridge);
ResCodeT IsNewBridgeOrg(uint64 orgPos, int32* pNewBridge);
ResCodeT UpdateOrgBrdg(uint64 orgPos, int32 newBridge);

ResCodeT BrdgOrgInfoIterExt(uint32 * pBrdgOrgPos, pBrdgOrgInfoT * ppData);
ResCodeT BrdgOrgAddCtrl();
ResCodeT BrdgOrgGetCtrl(pBrdgOrgCtrlT * ppBrdgOrgCtrl);

ResCodeT OrgIdGetByCode(char *orgCode, OrgCdPosInfoT *ppOrgCd);

#endif /* _ORG_INFO_ */
