﻿/***
Created on July 17, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "internal_base_def.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "prdct_info.h"
#include "CntrctBaseInfoDb.h"
#include "CntrctInfoSirsDb.h"
#include "CntrctInfoSbfccpDb.h"
#include "order_book.h"
#include "bit_lib.h"
#include "contract_info.h"
#include "CntrctRefPrcDb.h"
#include "CntrctRefPrcSirsDb.h"
#include "CntrctRefPrcSbfccpDb.h"
#include "cfg_lib.h"
#include "pck_irs_dicdata.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define HALF_HOUR   30 * 60 * 1000000

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT prdctHashHandler;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 ResCodeT LoadIrsPrdtData(int32 connId);
 ResCodeT LoadSirsPrdtData(int32 connId);
 ResCodeT LoadSbfccpPrdtData(int32 connId);
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT PrdctInfoLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("PrdctInfoLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;

    int32   totCount;
    int32   irsCount = 0;
    int32   sirsCount = 0;
    int32   sbfccpCount = 0;

    void        *pShmRoot;
    PrdctInfoT  prdctInfo;

    /* First,need to get the count of records in Table [CNTRCT_BASE_INFO] */
    rc = GetResultCntOfCntrctBaseInfo(connId, &irsCount);
    RAISE_ERR(rc, RTN);

    rc = GetResultCntOfCntrctInfoSirs(connId, &sirsCount);
    RAISE_ERR(rc, RTN);

    rc = GetResultCntOfCntrctInfoSbfccp(connId, &sbfccpCount);
    RAISE_ERR(rc, RTN);

    totCount = irsCount + sirsCount + sbfccpCount;

    recInfo.recSize = sizeof(PrdctInfoT);
    recInfo.keyOffset = offsetof(PrdctInfoT, prdctName);
    recInfo.keySize = PRDCT_NAME_LENGTH;
    recInfo.recCnt = totCount + 10;     /* For safe, 10 is added to the totCount */
    recInfo.bNeedTimeList = FALSE;
 
    rc = CmnHashTblCreate( GetShmNm((char*)SHM_PRODUCT_INFO_NAME), 
                            recInfo, TRUE, &pShmRoot, &prdctHashHandler );
    if (NOTOK(rc)){
        THROW_RESCODE(rc);
    }
    
    /* Read the data from DB, and load them into the hash table. */
    rc = LoadIrsPrdtData(connId);
    RAISE_ERR(rc, RTN);

    rc = LoadSirsPrdtData(connId);
    RAISE_ERR(rc, RTN);

    rc = LoadSbfccpPrdtData(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT PrdctInfoGetByNameExt(char *prdctName, pPrdctInfoT *ppPrdctInfo){

    BEGIN_FUNCTION("PrdctInfoGetByNameExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos = -1;
    char key[PRDCT_NAME_LENGTH];
    
    /* Check if the product exists in the hash table. */
    memset(key, 0x00, PRDCT_NAME_LENGTH);
    strcpy(key, prdctName);
    rc = CmnHashCheckDataExt(prdctHashHandler, key, &isExist, &nodePos, (void**)ppPrdctInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the product doesn't exist, throw the error code. */
    if (isExist == FALSE){
        LOG_DEBUG("Prdct %d for %s", nodePos, key);
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT PrdctInfoGetByPosExt(uint32 prdctPos, pPrdctInfoT *ppPrdctInfo){

    BEGIN_FUNCTION("PrdctInfoGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(prdctHashHandler, prdctPos, (void**)ppPrdctInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT PrdctInfoUpdateByName(char *prdctName, pPrdctInfoT pPrdctInfo){

    BEGIN_FUNCTION("PrdctInfoUpdateByName");
    
    ResCodeT rc = NO_ERR;
    pPrdctInfoT pPrdctInHash;
    uint32 pos;
    
    rc = PrdctInfoGetByNameExt(prdctName, &pPrdctInHash);
    RAISE_ERR(rc, RTN);
    
    /* Backup the position value. */
    pos = pPrdctInHash->pos;
    
    memcpy(pPrdctInHash, pPrdctInfo, sizeof(PrdctInfoT));
    
    /* Restore the position value. */
    pPrdctInHash->pos = pos;
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT PrdctInfoUpdateByPos(uint32 prdctPos, pPrdctInfoT pPrdctInfo){

    BEGIN_FUNCTION("PrdctInfoUpdateByPos");
    
    ResCodeT rc = NO_ERR;
    pPrdctInfoT pPrdctInHash;
    uint64 pos;

    rc = PrdctInfoGetByPosExt(prdctPos, &pPrdctInHash);
    RAISE_ERR(rc, RTN);
    
    /* Backup the position value. */
    pos = pPrdctInHash->pos;
    
    memcpy(pPrdctInHash, pPrdctInfo, sizeof(PrdctInfoT));
    
    /* Restore the position value. */
    pPrdctInHash->pos = pos;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrdctInfoAttachToShm(){

    BEGIN_FUNCTION("PrdctInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_PRODUCT_INFO_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    prdctHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT PrdctInfoDetachFromShm(){

    BEGIN_FUNCTION("PrdctInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_PRODUCT_INFO_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

/******************************************************************************
 * Description:   check if it is need to update mktinfo
 * Parameters:
 *  set         IN  Set Id.
 * Return Value:
 *  TRUE  need to do update operation.
 *  FALSE not need.
 *****************************************************************************/
BOOL NeedUpdMktInfo( int32 setId )
{
    BEGIN_FUNCTION("NeedUpdMktInfo");
    ResCodeT        rc = NO_ERR;

    return ( OrdBkChkUpdMktInfo( setId ) );
}

/******************************************************************************
 * Description:   set mkt info update vector
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
void SetMktInfoUpdVec( int32 setId, int32 prdctId )
{
    BEGIN_FUNCTION("SetMktInfoUpdVec");
    ResCodeT        rc = NO_ERR;

    OrdBkSetMktUpdVec( setId, prdctId );

}

/******************************************************************************
 * Description:   reset mkt info update vector
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
void ResetMktInfoUpdVec( int32 setId )
{
    BEGIN_FUNCTION("ResetMktInfoUpdVec");
    ResCodeT        rc = NO_ERR;

    OrdBkResetMktUpdVec( setId );

}

/******************************************************************************
 * Description:   refill mkt info in product
 * Parameters:
 *      ordMask     IN order mask
 *      prdctInfo   IN pointer of a product
 *      treeType    IN 
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT PrdctInfoRefill( int32 setId, int16 ordMask, pPrdctInfoT prdctInfo, int16 treeType )
{
    BEGIN_FUNCTION("PrdctInfoRefill");
    
    ResCodeT rc = NO_ERR;

    int         i = 0;

    pOrder4PrcLeadT curPrcLdr = NULL;
    pOrder4PrcLeadT nxtPrcLdr = NULL;

    /* get price leader from the begining */
    rc = GetNxtPrcLeader( setId, ordMask, prdctInfo->pos, curPrcLdr, &nxtPrcLdr );
    if ( rc == ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR(rc, RTN);

    if ( nxtPrcLdr && !nxtPrcLdr->orderF.ordrExePrc )
    {
        ( &prdctInfo->baseInfo.mktBidQty )[ordMask] = 
            ( &nxtPrcLdr->orderF.totUnrAuO )[treeType];
        ( &prdctInfo->baseInfo.mktBidOrdrNum )[ordMask] = 
            ( &nxtPrcLdr->orderF.cntUnrAuO )[treeType];

        curPrcLdr = nxtPrcLdr;
        rc = GetNxtPrcLeader( setId, ordMask, prdctInfo->pos, curPrcLdr, &nxtPrcLdr );
        if ( rc == ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER )
        {
            THROW_RESCODE( NO_ERR );
        }
        RAISE_ERR(rc, RTN);
    }
    else 
    {
        ( &prdctInfo->baseInfo.mktBidQty )[ordMask] = 0;
        ( &prdctInfo->baseInfo.mktBidOrdrNum )[ordMask] = 0;
    }

    while ( nxtPrcLdr && i < BST_MKTINFO_GRP_MAX )
    {
        if ( (&nxtPrcLdr->orderF.cntUnrAuO)[treeType] )
        {
            ( &prdctInfo->bstMktInfoGrp[i].bstBidPrc )[ordMask] = 
                nxtPrcLdr->orderF.ordrExePrc;
            ( &prdctInfo->bstMktInfoGrp[i].numOrdrBid )[ordMask] = 
                (&nxtPrcLdr->orderF.cntUnrAuO)[treeType];
            ( &prdctInfo->bstMktInfoGrp[i].bstBidQty )[ordMask] = 
                ( &nxtPrcLdr->orderF.totUnrAuO )[treeType];

            curPrcLdr = nxtPrcLdr;
            rc = GetNxtPrcLeader( setId, ordMask, prdctInfo->pos, curPrcLdr, &nxtPrcLdr );
            if ( rc == ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER )
            {
                THROW_RESCODE( NO_ERR );
            }
            RAISE_ERR(rc, RTN);

            if ( nxtPrcLdr && nxtPrcLdr->orderF.ordrExePrc ==
                    ( &prdctInfo->bstMktInfoGrp[i].bstBidPrc )[ordMask] )
            {
                ( &prdctInfo->bstMktInfoGrp[i].bstBidQty )[ordMask] +=
                    ( &nxtPrcLdr->orderF.totUnrAuO )[treeType];
                ( &prdctInfo->bstMktInfoGrp[i].numOrdrBid )[ordMask] += 
                    (&nxtPrcLdr->orderF.cntUnrAuO)[treeType];

                curPrcLdr = nxtPrcLdr;
                rc = GetNxtPrcLeader( setId, ordMask, prdctInfo->pos, curPrcLdr, &nxtPrcLdr );
                if ( rc == ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER )
                {
                    THROW_RESCODE( NO_ERR );
                }
                RAISE_ERR(rc, RTN);
            }
            
            i++;
        }
        else
        {
            /* get next price leader */
            curPrcLdr = nxtPrcLdr;
            rc = GetNxtPrcLeader( setId, ordMask, prdctInfo->pos, curPrcLdr, &nxtPrcLdr );
            if ( rc == ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER )
            {
                THROW_RESCODE( NO_ERR );
            }
            RAISE_ERR(rc, RTN);
        }
    }

    /* if can't get more price leader, set 0 for the least */
    if ( i < BST_MKTINFO_GRP_MAX )
    {
        if ( ordMask == ORDR_SIDE_BUY )
        {
            for ( ; i < BST_MKTINFO_GRP_MAX; i++ )
            {
                prdctInfo->bstMktInfoGrp[i].bstBidPrc = 0;
                prdctInfo->bstMktInfoGrp[i].bstBidQty = 0;
                prdctInfo->bstMktInfoGrp[i].numOrdrBid = 0;
            }
        }
        else
        {
            for ( ; i < BST_MKTINFO_GRP_MAX; i++ )
            {
                prdctInfo->bstMktInfoGrp[i].bstAskPrc = 0;
                prdctInfo->bstMktInfoGrp[i].bstAskQty = 0;
                prdctInfo->bstMktInfoGrp[i].numOrdrAsk = 0;
            }
        }
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


/******************************************************************************
 * Description:   refresh mkt info in product
 * Parameters:
 *      prdctId         IN product pos in its share mem
 *      prdctMktSts     IN 
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT RefreshPrdctMktInfo( int32 setId, uint64 prdctId, int64 timestamp  )
{

    BEGIN_FUNCTION("RefreshPrdctMktInfo");
    ResCodeT rc = NO_ERR;

    int treeType = 0;
    pPrdctInfoT prdctInfo = NULL;

    rc = PrdctInfoGetByPosExt( prdctId, &prdctInfo );
    RAISE_ERR(rc, RTN);

    switch ( prdctInfo->baseInfo.prcsSts )
    {
        case PROD_STAT_TRADE:
            treeType = 0;
            break;


        default:
            break;
    }
    
    rc = PrdctInfoRefill( setId, ORDR_SIDE_BUY, prdctInfo, treeType );
    RAISE_ERR(rc, RTN);

    rc = PrdctInfoRefill( setId, ORDR_SIDE_SELL, prdctInfo, treeType );
    RAISE_ERR(rc, RTN);

    prdctInfo->baseInfo.lstUpdateTim = timestamp;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   refresh mkt info in of all exchanged product
 * Parameters:
 *      prdctId         IN product pos in its share mem
 *      prdctMktSts     IN 
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT UpdInsideMktInfo( int32 setId, int64 timestamp )
{
    BEGIN_FUNCTION("UpdInsideMktInfo");
    ResCodeT rc = NO_ERR;

    int prdctIdx = 0;
    int maxPrdct = 0;
    pVectorT pMktUpdVec = NULL;

    OrdBkGetMktUpdVec( setId, &pMktUpdVec, &maxPrdct );

    while ( TRUE )
    {
        BitFindFS(pMktUpdVec, prdctIdx + 1, maxPrdct, &prdctIdx);
        if (prdctIdx == -1)
        {
            break;
        }

        rc = RefreshPrdctMktInfo( setId, prdctIdx, timestamp );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   update wghtTotPrc and wghtTotQty in product
 * Parameters:
 *      pPrdctInfo      IN product info in share mem
 *      exePrc          IN trade price
 *      exeQty          IN trade qutanty
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
void UpdWghtPrcAndQty( pPrdctInfoT pPrdctInfo, int64 exePrc, int64 exeQty )
{

    BEGIN_FUNCTION("UpdWghtPrcAndQty");
    ResCodeT rc = NO_ERR;

    pPrdctInfo->baseInfo.wghtTotPrc += exePrc * exeQty;
    pPrdctInfo->baseInfo.wghtTotQty += exeQty;

}

/******************************************************************************
 * Description:   refresh mkt info in of all exchanged product
 * Parameters:
 *      prdctId         IN product pos in its share mem
 *      prdctMktSts     IN 
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CalcIntradayRefPrc( pPrdRefPrcUpdT pRefPrcUpd )
{
    BEGIN_FUNCTION("CalcIntradayRefPrc");
    ResCodeT rc = NO_ERR;

    uint32  contractPos = CMN_LIST_NULL_NODE;
    int64   refPrcUpdTime = 0;
    int32   iNode = 0;

    pPrdctInfoT      pPrdctInfo = NULL;
    //pCntrctBaseInfoT pCntrctInfo = NULL;
    pCntrctListInfoT pCntrctInfo = NULL;

    if ( pRefPrcUpd->iterPos != CMN_LIST_NULL_NODE )
    {
        contractPos = pRefPrcUpd->iterPos;
    }

    refPrcUpdTime = pRefPrcUpd->refPrcUpdTime;

    while ( TRUE )
    {
        //rc = IrsCntrctInfoIterExt( &contractPos, &pCntrctInfo );
        rc = IrsCntrctListIter( &contractPos, &pCntrctInfo );
        if ( contractPos == CMN_LIST_NULL_NODE )
        {
            pRefPrcUpd->iterPos = contractPos;
            break;
        }
        RAISE_ERR(rc, RTN);

        rc = PrdctInfoGetByNameExt( pCntrctInfo->cntrctName, &pPrdctInfo );
        RAISE_ERR(rc, RTN);
        
        if ( refPrcUpdTime - pPrdctInfo->baseInfo.lstRefPrcUpdTim >= HALF_HOUR )
        {
            pRefPrcUpd->refPrcNode[iNode].prdctId = pPrdctInfo->pos;

            /* trade */
            if ( pPrdctInfo->baseInfo.lstTrdDatTim > pPrdctInfo->baseInfo.lstRefPrcUpdTim &&
                    pPrdctInfo->baseInfo.wghtTotQty != 0 )
            {
                pRefPrcUpd->refPrcNode[iNode].prdctId = pPrdctInfo->baseInfo.wghtTotPrc / 
                                                        pPrdctInfo->baseInfo.wghtTotQty;
            }

            /* best bid and best ask */
            else if ( (pPrdctInfo->baseInfo.lstTrdDatTim < pPrdctInfo->baseInfo.lstRefPrcUpdTim) &&
                        pPrdctInfo->bstMktInfoGrp[0].bstBidPrc > 0 && 
                        pPrdctInfo->bstMktInfoGrp[0].bstAskPrc > 0 )
            {
                pRefPrcUpd->refPrcNode[iNode].prdctId = ( pPrdctInfo->bstMktInfoGrp[0].bstBidPrc + 
                                            pPrdctInfo->bstMktInfoGrp[0].bstAskPrc ) / 2;
            }

            /* only best bid */
            else if ( (pPrdctInfo->baseInfo.lstTrdDatTim < pPrdctInfo->baseInfo.lstRefPrcUpdTim) &&
                        pPrdctInfo->bstMktInfoGrp[0].bstBidPrc > 0 && 
                        pPrdctInfo->bstMktInfoGrp[0].bstAskPrc == 0 )
            {
                pRefPrcUpd->refPrcNode[iNode].prdctId = pPrdctInfo->bstMktInfoGrp[0].bstBidPrc;
            }

            /* only best ask */
            else if ( (pPrdctInfo->baseInfo.lstTrdDatTim < pPrdctInfo->baseInfo.lstRefPrcUpdTim) &&
                        pPrdctInfo->bstMktInfoGrp[0].bstBidPrc == 0 && 
                        pPrdctInfo->bstMktInfoGrp[0].bstAskPrc > 0 )
            {
                pRefPrcUpd->refPrcNode[iNode].prdctId = pPrdctInfo->bstMktInfoGrp[0].bstAskPrc;
            }

            /* no best bid or best ask */
            else
            {
                continue;   /* continue to next product */
            }

            iNode++;
            pRefPrcUpd->updCnt++;
        }

        if ( pRefPrcUpd->updCnt == REFPRC_NODE_NUM_MAX )
        {
            pRefPrcUpd->iterPos = contractPos;
            break;
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   refresh mkt info in of all exchanged product
 * Parameters:
 *      prdctId         IN product pos in its share mem
 *      prdctMktSts     IN 
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT UpdIntradayRefPrc( pPrdRefPrcUpdT pRefPrcUpd )
{
    BEGIN_FUNCTION("UpdIntradayRefPrc");
    ResCodeT rc = NO_ERR;

    pPrdctInfoT      pPrdctInfo = NULL;

    for ( int i = 0; i < pRefPrcUpd->updCnt; i++ )
    {
        rc = PrdctInfoGetByPosExt( pRefPrcUpd->refPrcNode[i].prdctId, &pPrdctInfo );
        RAISE_ERR(rc, RTN);

        pPrdctInfo->baseInfo.lstRefPrcUpdTim = pRefPrcUpd->refPrcUpdTime;
        pPrdctInfo->baseInfo.lstUpdateTim = pRefPrcUpd->refPrcUpdTime;
        pPrdctInfo->baseInfo.wghtTotPrc = pRefPrcUpd->refPrcNode[i].intraRefPrc;

        pPrdctInfo->baseInfo.wghtTotPrc = 0;
        pPrdctInfo->baseInfo.wghtTotQty = 0;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   refresh mkt info in of all exchanged product
 * Parameters:
 *      prdctId         IN product pos in its share mem
 *      prdctMktSts     IN 
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT UpdRefPrcToDb( int32 connId, pPrdRefPrcUpdT pRefPrcUpd )
{
    BEGIN_FUNCTION("UpdIntradayRefPrc");
    ResCodeT rc = NO_ERR;

    uint32  contractPos = CMN_LIST_NULL_NODE;

    pPrdctInfoT      pPrdctInfo = NULL;
    pCntrctBaseInfoT pCntrctInfo = NULL;

    CntrctRefPrc        refPrcInfoIrs = {0};
    CntrctRefPrcSirs    refPrcInfoSirs = {0};
    CntrctRefPrcSbfccp  refPrcInfoSbfccp = {0};
    vectorT  keyVec[GET_BIT_VECT_LEN(8)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(8)] = {0};

    /* Always update following characters */
    DbCmmnSetColBit(keyVec, 1);
    DbCmmnSetColBit(datVec, 3);
    DbCmmnSetColBit(datVec, 6);

    while ( TRUE )
    {
        rc = IrsCntrctInfoIterExt( &contractPos, &pCntrctInfo );
        if ( contractPos == CMN_LIST_NULL_NODE )
        {
            break;
        }
        RAISE_ERR(rc, RTN);

        rc = PrdctInfoGetByNameExt( pCntrctInfo->cntrctName, &pPrdctInfo );
        RAISE_ERR(rc, RTN);

        /* set value */
        switch ( pPrdctInfo->setId )
        {
            case SET_MKT_IRS:
                strcpy( refPrcInfoIrs.cntrctNm, pCntrctInfo->cntrctName );
                refPrcInfoIrs.refPrc = pPrdctInfo->baseInfo.intraRefPrc * 1.0 / PRICE_BASE;

                rc = GetStrDateTimeByFormat( pRefPrcUpd->refPrcUpdTime, refPrcInfoIrs.updTm );
                RAISE_ERR( rc, RTN );

                /* update database */
                rc = UpdateCntrctRefPrcByKey( connId, &refPrcInfoIrs, keyVec, datVec );
                RAISE_ERR(rc, RTN);
                break;

            case SET_MKT_SIRS:
                strcpy( refPrcInfoSirs.cntrctCd, pCntrctInfo->cntrctName );
                refPrcInfoSirs.refPrc = pPrdctInfo->baseInfo.intraRefPrc * 1.0 / PRICE_BASE;

                rc = GetStrDateTimeByFormat( pRefPrcUpd->refPrcUpdTime, refPrcInfoIrs.updTm );
                RAISE_ERR( rc, RTN );

                /* update database */
                rc = UpdateCntrctRefPrcSirsByKey( connId, &refPrcInfoSirs, keyVec, datVec );
                RAISE_ERR(rc, RTN);
                break;

            case SET_MKT_SBFCCP:
                strcpy( refPrcInfoSbfccp.cntrctCd, pCntrctInfo->cntrctName );
                refPrcInfoSbfccp.refPrc = pPrdctInfo->baseInfo.intraRefPrc * 1.0 / PRICE_BASE;

                rc = GetStrDateTimeByFormat( pRefPrcUpd->refPrcUpdTime, refPrcInfoSbfccp.updTm );
                RAISE_ERR( rc, RTN );

                /* update database */
                rc = UpdateCntrctRefPrcSbfccpByKey( connId, &refPrcInfoSbfccp, keyVec, datVec );
                RAISE_ERR(rc, RTN);
                break;
            default:
                break;
        }
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT PrdctInfoIterExt(uint32 * prdctPos, pPrdctInfoT * ppData)
{
    BEGIN_FUNCTION("PrdctInfoIterExt");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    
    rc = CmnHashIterDataExt(prdctHashHandler, prdctPos,(void **)ppData);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CalcSprdCntrctDealPrc(uint64 prdctPos, int64 * pDealPrc)
{
    BEGIN_FUNCTION("CalcSprdCntrctDealPrc");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    
    pPrdctInfoT         pPrdctInfo = NULL;
    pPrdctInfoT         pPrdctInfoSht = NULL;
    pPrdctInfoT         pPrdctInfoLng = NULL;

    pCntrctBaseInfoT    pCntrctInfo = NULL;

    rc = PrdctInfoGetByPosExt( prdctPos, &pPrdctInfo );
    RAISE_ERR(rc, RTN);

    /* Only works in SIRS and SBFCCP */
    if ( pPrdctInfo->setId != SET_MKT_IRS )
    {
        THROW_RESCODE(NO_ERR);
    }

    rc = IrsCntrctInfoGetByNameExt( pPrdctInfo->prdctName, &pCntrctInfo );
    RAISE_ERR(rc, RTN);

    /* Only Spread contract */
    if ( pCntrctInfo->cntrctType == C_CONTRACT_TYPE_IRS )
    {
        THROW_RESCODE(NO_ERR);
    }

    /* get short side and long side product info */
    rc = PrdctInfoGetByNameExt( pCntrctInfo->shrtCntrctName, &pPrdctInfoSht );
    RAISE_ERR(rc, RTN);

    rc = PrdctInfoGetByNameExt( pCntrctInfo->lngCntrctName, &pPrdctInfoLng );
    RAISE_ERR(rc, RTN);

    if ( pPrdctInfo->bstMktInfoGrp[0].bstBidPrc > 0 )


    EXIT_BLOCK();
    RETURN_RESCODE;
    
}
ResCodeT LoadIrsPrdtData(int32 connId)
{
    BEGIN_FUNCTION("LoadIrsPrdtData");
    ResCodeT            rc = NO_ERR;

    uint32              pos;
    PrdctInfoT          pData;
    PrdctInfoT          prdctInfo;
    HashTableRecInfoT   recInfo;

    BOOL    bFrstFlg = TRUE;
    BOOL    existFlag = FALSE;
    CntrctBaseInfo      dbData;

    int64   frstUpdTimeStamp = 0;
    CntrctRefPrc        cntrctRefPrc;

    /* Read the data from DB, and load them into the hash table. */
    while (OK(FetchNextCntrctBaseInfo(&bFrstFlg, connId, &dbData))){
    
        memset(&prdctInfo, 0x00, sizeof(PrdctInfoT));
    
        // Copy the retun value of fetchNextData into PrdctInfoT
        prdctInfo.setId = SET_MKT_IRS;
        strcpy(prdctInfo.prdctName, dbData.cntrctNm);
        prdctInfo.baseInfo.prcsSts = PROD_STAT_TRADE;
        
        
        memset(&cntrctRefPrc, 0x00, sizeof(CntrctRefPrc));
        /* Get the position in the Hashtable that will be used to store the product. */
        rc = FetchCntrctRefPrcByName(connId, prdctInfo.prdctName,&cntrctRefPrc);
        if ( rc == ERR_DB_COMMON_FETCH_END )
        {
            rc = NO_ERR;
        }
        RAISE_ERR(rc, RTN);

        rc = DateTimeToTimestamp ( cntrctRefPrc.updTm, &frstUpdTimeStamp );
        RAISE_ERR(rc, RTN);

        CnvtDoubleToIntnlVal(cntrctRefPrc.refPrc, &prdctInfo.baseInfo.intraRefPrc);
        prdctInfo.baseInfo.lstRefPrcUpdTim = frstUpdTimeStamp;

        /* Get the position in the Hashtable that will be used to store the product. */
        rc = CmnHashCheckData(prdctHashHandler, prdctInfo.prdctName, &existFlag, &pos, (void*)&pData);
        RAISE_ERR(rc, RTN);

        /* Save the position value */
        prdctInfo.pos = pos;
        
        rc = CmnHashLogData(prdctHashHandler, &prdctInfo, pos, TRUE, TRUE);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT LoadSirsPrdtData(int32 connId)
{
    BEGIN_FUNCTION("LoadSirsPrdtData");
    ResCodeT            rc = NO_ERR;

    uint32             pos;
    PrdctInfoT          pData;
    PrdctInfoT          prdctInfo;
    HashTableRecInfoT   recInfo;

    BOOL    bFrstFlg = TRUE;
    BOOL    existFlag = FALSE;
    CntrctInfoSirs      dbData;

    int64   frstUpdTimeStamp = 0;
    CntrctRefPrcSirs    cntrctRefPrc;

    /* Read the data from DB, and load them into the hash table. */
    while (OK(FetchNextCntrctInfoSirs(&bFrstFlg, connId, &dbData)))
    {
        memset(&prdctInfo, 0x00, sizeof(PrdctInfoT));
    
        // Copy the retun value of fetchNextData into PrdctInfoT
        prdctInfo.setId = SET_MKT_SIRS;
        strcpy(prdctInfo.prdctName, dbData.cntrctCd);
        prdctInfo.baseInfo.prcsSts = PROD_STAT_TRADE;

        memset(&cntrctRefPrc, 0x00, sizeof(CntrctRefPrcSirs));
        /* Get the position in the Hashtable that will be used to store the product. */
        rc = FetchCntrctRefPrcSirsByName(connId, prdctInfo.prdctName,&cntrctRefPrc);
        if ( rc == ERR_DB_COMMON_FETCH_END )
        {
            rc = NO_ERR;
        }
        RAISE_ERR(rc, RTN);

        rc = DateTimeToTimestamp ( cntrctRefPrc.updTm, &frstUpdTimeStamp );
        RAISE_ERR(rc, RTN);

        CnvtDoubleToIntnlVal(cntrctRefPrc.refPrc, &prdctInfo.baseInfo.intraRefPrc);
        prdctInfo.baseInfo.lstRefPrcUpdTim = frstUpdTimeStamp;

        /* Get the position in the Hashtable that will be used to store the product. */
        rc = CmnHashCheckData(prdctHashHandler, prdctInfo.prdctName, &existFlag, &pos, (void*)&pData);
        RAISE_ERR(rc, RTN);

        /* Save the position value */
        prdctInfo.pos = pos;          
        
        rc = CmnHashLogData(prdctHashHandler, &prdctInfo, pos, TRUE, TRUE);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT LoadSbfccpPrdtData(int32 connId)
{
    BEGIN_FUNCTION("LoadSbfccpPrdtData");
    ResCodeT            rc = NO_ERR;

    uint32              pos;
    PrdctInfoT          pData;
    PrdctInfoT          prdctInfo;
    HashTableRecInfoT   recInfo;

    BOOL    bFrstFlg = TRUE;
    BOOL    existFlag = FALSE;
    CntrctInfoSbfccp    dbData;

    int64   frstUpdTimeStamp = 0;
    CntrctRefPrcSbfccp  cntrctRefPrc;

    /* Read the data from DB, and load them into the hash table. */
    while (OK(FetchNextCntrctInfoSbfccp(&bFrstFlg, connId, &dbData)))
    {
        memset(&prdctInfo, 0x00, sizeof(PrdctInfoT));
    
        // Copy the retun value of fetchNextData into PrdctInfoT
        prdctInfo.setId = SET_MKT_SBFCCP;
        strcpy(prdctInfo.prdctName, dbData.cntrctCd);
        prdctInfo.baseInfo.prcsSts = PROD_STAT_TRADE;

        memset(&cntrctRefPrc, 0x00, sizeof(CntrctRefPrcSbfccp));
        /* Get the position in the Hashtable that will be used to store the product. */
        rc = FetchCntrctRefPrcSbfccpByName(connId, prdctInfo.prdctName,&cntrctRefPrc);
        if ( rc == ERR_DB_COMMON_FETCH_END )
        {
            rc = NO_ERR;
        }
        RAISE_ERR(rc, RTN);

        rc = DateTimeToTimestamp ( cntrctRefPrc.updTm, &frstUpdTimeStamp );
        RAISE_ERR(rc, RTN);

        CnvtDoubleToIntnlVal(cntrctRefPrc.refPrc, &prdctInfo.baseInfo.intraRefPrc);
        prdctInfo.baseInfo.lstRefPrcUpdTim = frstUpdTimeStamp;

        /* Get the position in the Hashtable that will be used to store the product. */
        rc = CmnHashCheckData(prdctHashHandler, prdctInfo.prdctName, &existFlag, &pos, (void*)&pData);
        RAISE_ERR(rc, RTN);

        /* Save the position value */
        prdctInfo.pos = pos;          
        
        rc = CmnHashLogData(prdctHashHandler, &prdctInfo, pos, TRUE, TRUE);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
