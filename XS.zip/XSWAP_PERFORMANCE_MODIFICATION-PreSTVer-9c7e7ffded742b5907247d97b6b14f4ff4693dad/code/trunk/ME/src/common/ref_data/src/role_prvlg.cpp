﻿/***
Created on Aug 21, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "role_prvlg.h"
#include "RolePrvlgDb.h"



/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT rolePrvlgHashHandler;


static BOOL rolePrvlgHashLoadFlag = FALSE;

static char delimiter[1] = {ROLE_PRVLG_HASH_KEY_DELIMITER};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static void GenerateRolePrvlgHashKey(uint64 rsrcId, uint32 roleId, char *pHashKey){

    memcpy(pHashKey, &rsrcId, sizeof(uint64));
    pHashKey = pHashKey + sizeof(uint64);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    memcpy(pHashKey, &roleId, sizeof(uint32));
}
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT RolePrvlgLoadFromDB(int32 connId)
{

    BEGIN_FUNCTION("RolePrvlgLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    RolePrvlgT rolePrvlg;
    BOOL existFlag;
    uint32 pos;
    RolePrvlgT pData;
    RolePrvlg dbData;
    BOOL    bFrstFlg = TRUE;
    
    /* If the role privilege info load flag is FALSE, creation of the hashtable is necessary. */
    if (rolePrvlgHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [ROLE_PRVLG] */
        rc = GetResultCntOfRolePrvlg(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(RolePrvlgT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(RolePrvlgT, hashKey);
        recInfo.keySize = ROLE_PRVLG_HASH_KEY_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_ROLE_PRVLG_NAME), 
                                recInfo, FALSE, &pShmRoot, &rolePrvlgHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextRolePrvlg(&bFrstFlg, connId, &dbData))){
    
            memset(&rolePrvlg, 0x00, sizeof(RolePrvlgT));
            memset(rolePrvlg.hashKey, 0x00, ROLE_PRVLG_HASH_KEY_LENGTH);
            
            // Copy the retun value of fetchNextData into RolePrvlgT
            rolePrvlg.roleId = dbData.roleId;   
            rolePrvlg.rsrcId = dbData.rsrcId;  
       
            
            /* Generate the key to be hashed. The key will be created by combining the rsrcId and roleId */
            GenerateRolePrvlgHashKey(rolePrvlg.rsrcId, rolePrvlg.roleId, rolePrvlg.hashKey);
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(rolePrvlgHashHandler, (void*)rolePrvlg.hashKey, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            rolePrvlg.pos = pos;          
            
            rc = CmnHashLogData(rolePrvlgHashHandler, &rolePrvlg, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    rolePrvlgHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    rolePrvlgHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT RolePrvlgGetByKey(uint64 rsrcId, uint32 roleId, pRolePrvlgT pRolePrvlg){

    BEGIN_FUNCTION("RolePrvlgGetByKey");
    
    ResCodeT rc = NO_ERR;
    pRolePrvlgT pData;
    
    /* Call RolePrvlgGetByKeyExt to get the role privilege info. */
    rc = RolePrvlgGetByKeyExt(rsrcId, roleId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRolePrvlg, pData, sizeof(RolePrvlgT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT RolePrvlgGetByKeyExt(uint64 rsrcId, uint32 roleId, pRolePrvlgT *ppRolePrvlg){

    BEGIN_FUNCTION("RolePrvlgGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[ROLE_PRVLG_HASH_KEY_LENGTH];
    
    memset(key, 0x00, ROLE_PRVLG_HASH_KEY_LENGTH);
    /* combine rsrcId and roleId as the key to be hashed. */
    GenerateRolePrvlgHashKey(rsrcId, roleId, key);
        

    /* Check if the role privilege info exists in the hash table. */
    rc = CmnHashCheckDataExt(rolePrvlgHashHandler, key, &isExist, &nodePos, (void**)ppRolePrvlg);
    RAISE_ERR(rc, RTN);
    
    /* If the role privilege info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT RolePrvlgGetByPos(uint64 rsrcPos, pRolePrvlgT pRolePrvlg){

    BEGIN_FUNCTION("RolePrvlgGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pRolePrvlgT pData;
    
    rc = RolePrvlgGetByPosExt(rsrcPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRolePrvlg, pData, sizeof(RolePrvlgT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT RolePrvlgGetByPosExt(uint64 rsrcPos, pRolePrvlgT *ppRolePrvlg){

    BEGIN_FUNCTION("RolePrvlgGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(rolePrvlgHashHandler, rsrcPos, (void**)ppRolePrvlg);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT RolePrvlgAttachToShm(){

    BEGIN_FUNCTION("RolePrvlgAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_ROLE_PRVLG_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    rolePrvlgHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT RolePrvlgDetachFromShm(){

    BEGIN_FUNCTION("RolePrvlgDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_ROLE_PRVLG_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}



ResCodeT RolePrvlgAdd(uint64 rsrcId, uint32 roleId, pRolePrvlgT *ppRolePrvlg)
{
    BEGIN_FUNCTION("RolePrvlgAdd");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    uint32 nodePos;
    RolePrvlgT rolePrvlg;
    
    memset(&rolePrvlg, 0x00, sizeof(RolePrvlgT));
    memset(rolePrvlg.hashKey, 0x00, ROLE_PRVLG_HASH_KEY_LENGTH);
    
    rolePrvlg.roleId = roleId;   
    rolePrvlg.rsrcId = rsrcId;
    
    /* Generate the key to be hashed. The key will be created by combining the rsrcId and roleId */
    GenerateRolePrvlgHashKey(rolePrvlg.rsrcId, rolePrvlg.roleId, rolePrvlg.hashKey);
    
    rc = CmnHashCheckDataExt(rolePrvlgHashHandler, (void*)rolePrvlg.hashKey, &isExist, &nodePos, (void**)ppRolePrvlg);
    RAISE_ERR(rc, RTN);
   
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
   
    rc = CmnHashLogData(rolePrvlgHashHandler, &rolePrvlg, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
