/***
Created on June 29, 2017
@author: Gao.Liu
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _USR_ONLN_
#define _USR_ONLN_

/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/

#include "common_hash.h"
#include "shm_name.h"
#include "usr.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define USR_NAME_MAX_LENGTH         100

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef struct usrOnlnBaseInfo
{
    char    usrNm[USR_NAME_MAX_LENGTH];     /*用户登录名*/
    int32   lgnTp;
    int32   pos;
} UsrOnlnBaseInfoT, *pUsrOnlnBaseInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*judge whether role id exists*/
ResCodeT IrsUsrOnlnInfoLoadFromDb(int32 connid);

/* Add online user into the hashtable by specifying the orgId. */
ResCodeT UsrOnlnAddByName(pUsrBaseInfoT pUsrInfo);
/* Delete online user from the hashtable by specifying the orgId. */
ResCodeT UsrOnlnDeleteByName(char* usrNm);

/*judge whether role id exists*/
ResCodeT IrsUsrOnlnUpdateByName(int32 connId, char* name, int32 lgnTp);
/*judge whether role id exists*/
ResCodeT IrsUsrOnlnInfoGetByName(char* onlnName, pUsrOnlnBaseInfoT pRole);
/*judge whether role id exists*/
ResCodeT IrsUsrOnlnInfoGetByNameExt(char* onlnName, pUsrOnlnBaseInfoT* pRole);
/*judge whether role id exists*/
ResCodeT IrsUsrOnlnInfoGetByPos(uint64 onlnPos, pUsrOnlnBaseInfoT pRole);
/*judge whether role id exists*/
ResCodeT IrsUsrOnlnInfoGetByPosExt(uint64 onlnPos, pUsrOnlnBaseInfoT* pRole);
/*judge whether role id exists*/
ResCodeT IrsUsrOnlnInfoDetachFromShm(void);
ResCodeT UsrOnlnIterExt(uint32 * pstnPos, pUsrOnlnBaseInfoT *ppData);

#endif
