﻿/***
Created on Aug 19, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _SYS_ST_RSRC_
#define _SYS_ST_RSRC_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define SYS_ST_RSRC_HASH_KEY_LENGTH              32
#define SYS_ST_RSRC_HASH_KEY_DELIMITER           '&'


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 系统状态资源 */
typedef struct SysStRsrcS
{
    char            hashKey[SYS_ST_RSRC_HASH_KEY_LENGTH];         /* 系统状态资源的HashKey,由 资源标识+系统状态ID 组成 */
    uint32          sysStId;                                      /* 系统状态ID 枚举值:0-等待,1-开市,2-开盘,3-休市,4-收盘,5-闭市*/         
    uint64          rsrcId;                                       /* 资源标识 */    
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} SysStRsrcT, *pSysStRsrcT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read data from Table [SYS_ST_RSRC] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT SysStRsrcLoadFromDB(int32 connId);

/* Get the system status of resource returned in pSysStRsrc by specifying resource id and system status id. */
ResCodeT SysStRsrcGetByKey(uint64 rsrcId, uint32 sysStId, pSysStRsrcT pSysStRsrc);

/* Get the  system status of resource returned in pSysStRsrc by specifying resource id and system status id. 
   The return value ppSysStRsrc is the direct address of system status info in the Hash shared memory. */
ResCodeT SysStRsrcGetByKeyExt(uint64 rsrcId, uint32 sysStId, pSysStRsrcT *ppSysStRsrc);

/* Get the  system status of resource returned in pRskCfcnt by specifying the position in the hash table. */
ResCodeT SysStRsrcGetByPos(uint64 rsrcPos, pSysStRsrcT pSysStRsrc);

/* Get the system status of resource returned in ppSysStRsrc by specifying the position in the hash table. 
   The return value ppSysStRsrc is the direct address of system status info in the Hash shared memory. */
ResCodeT SysStRsrcGetByPosExt(uint64 rsrcPos, pSysStRsrcT *ppSysStRsrc);

/* Attach to the shared memory. */
ResCodeT SysStRsrcAttachToShm();

/* Detach from the shared memory. */
ResCodeT SysStRsrcDetachFromShm();


#endif /* _SYS_ST_RSRC_ */
