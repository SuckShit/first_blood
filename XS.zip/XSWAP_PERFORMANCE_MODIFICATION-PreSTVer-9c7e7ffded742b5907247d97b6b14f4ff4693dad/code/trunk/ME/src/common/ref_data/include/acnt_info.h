﻿/***
Created on Oct 27, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _ACNT_INFO_TYPE_
#define _ACNT_INFO_TYPE_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define ACNT_NO_LENGTH                              100
#define SETTLEMENT_BANK_CODE_LENGTH                 100
#define DPST_ACNT_NO_LENGTH                         200

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 资金账户信息 */
typedef struct AcntInfoS
{
    int64           acntSrno;                                     /* 账户序列号 */
    uint64          acntId;                                       /* 账号ID */
    uint64          orgId;                                        /* 机构ID */
    char            acntNo[ACNT_NO_LENGTH];                       /* 账号 */
    char            stlmntBnkCd[SETTLEMENT_BANK_CODE_LENGTH];     /* 支付系统行号 */
    uint16          dfltAcnt;                                     /* 默认账号：0 否、1 是 */
    uint16          st;                                           /* 账户状态：1 活动、2 禁用、3 待处理、4 删除 */
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} AcntInfoT, *pAcntInfoT;


/* 托管账户信息(SBF市场) */
typedef struct DpstAcntInfoSbfS
{
    uint64          dpstAcntSrno;                                 /* 托管账户序列号 */
    uint64          dpstAcntId;                                   /* 托管账户ID */
    char            dpstAcntNo[DPST_ACNT_NO_LENGTH];              /* 托管账号 */
    uint64          orgId;                                        /* 账户所属机构ID */
    int64           acntSrno;                                     /* 关联的资金账户序列号 */
    uint16          dfltAcnt;                                     /* 默认账号:0-否,1-是 */
    uint16          st;                                           /* 账号状态:1-活动,2-禁用,3-待处理,4-删除 */
    uint16          sysSrc;                                       /* 用户来源系统:1-本币,2-XSWAP维护 */
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} DpstAcntInfoSbfT, *pDpstAcntInfoSbfT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Read data from Table [ACNT_INFO] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT AcntInfoLoadFromDB(int32 connId);

/* Get SBF deposit account info by specifying account id. */
ResCodeT AcntInfoGetByKey(uint64 acntId, pAcntInfoT pAcntInfo);

/* Get SBF deposit account info by specifying account id.
   The return value ppAcntInfo is the direct address of account info in the Hash shared memory. */
ResCodeT AcntInfoGetByKeyExt(uint64 acntId, pAcntInfoT *ppAcntInfo);

/* Get SBF deposit account info by specifying the position in the hash table. */
ResCodeT AcntInfoGetByPos(uint64 acntPos, pAcntInfoT pAcntInfo);

/* Get SBF deposit account info by specifying the position in the hash table.
   The return value ppAcntInfo is the direct address of account info in the Hash shared memory. */
ResCodeT AcntInfoGetByPosExt(uint64 acntPos, pAcntInfoT *ppAcntInfo);

/* Attach to the shared memory. */
ResCodeT AcntInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT AcntInfoDetachFromShm();





/* Read data from Table [DPST_ACNT_INFO_SBF] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT DpstAcntInfoSbfLoadFromDB(int32 connId);

/* Get SBF deposit account info by specifying account id. */
ResCodeT DpstAcntInfoSbfGetByKey(uint64 acntId, pDpstAcntInfoSbfT pAcntInfo);

/* Get SBF deposit account info by specifying account id.
   The return value ppAcntInfo is the direct address of account info in the Hash shared memory. */
ResCodeT DpstAcntInfoSbfGetByKeyExt(uint64 acntId, pDpstAcntInfoSbfT *ppAcntInfo);

/* Get SBF deposit account info by specifying the position in the hash table. */
ResCodeT DpstAcntInfoSbfGetByPos(uint64 acntPos, pDpstAcntInfoSbfT pAcntInfo);

/* Get SBF deposit account info by specifying the position in the hash table.
   The return value ppAcntInfo is the direct address of account info in the Hash shared memory. */
ResCodeT DpstAcntInfoSbfGetByPosExt(uint64 acntPos, pDpstAcntInfoSbfT *ppAcntInfo);

/* Attach to the shared memory. */
ResCodeT DpstAcntInfoSbfAttachToShm();

/* Detach from the shared memory. */
ResCodeT DpstAcntInfoSbfDetachFromShm();


#endif /* _ACNT_INFO_TYPE_ */
