﻿/***
Created on Oct 27, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "org_info.h"
#include "acnt_info.h"
#include "AcntInfoDb.h"
#include "DpstAcntInfoSbfDb.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT acntHashHandler;
static CmnHashHndlT dpstAcntHashHandler;

static BOOL acntHashLoadFlag = FALSE;
static BOOL dpstAcntHashLoadFlag = FALSE;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT AcntInfoLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("AcntInfoLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    AcntInfoT acntInfo;
    BOOL existFlag;
    uint32 pos;
    AcntInfoT pData;
    AcntInfo dbData;
    BOOL bFrstFlg = TRUE;
	pOrgInfoT pOrgData;
    
    /* If the account info load flag is FALSE, creation of the hashtable is necessary. */
    if (acntHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [ACNT_INFO] */
        rc = GetResultCntOfAcntInfo(connId, &dataCount);
        RAISE_ERR(rc, RTN);

    
        recInfo.recSize = sizeof(AcntInfoT);
        recInfo.keyOffset = offsetof(AcntInfoT, acntId);
        recInfo.keySize = sizeof(uint64);
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_ACNT_INFO_NAME), 
                                recInfo, FALSE, &pShmRoot, &acntHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextAcntInfo(&bFrstFlg, connId, &dbData))){
    
            memset(&acntInfo, 0x00, sizeof(AcntInfoT));
            
            // Copy the retun value of fetchNextData into AcntInfoT
            acntInfo.acntSrno = dbData.acntSrno;
			acntInfo.acntId = dbData.acntId;
			acntInfo.orgId = dbData.orgId;
			strcpy(acntInfo.acntNo, dbData.acntNo);
			strcpy(acntInfo.stlmntBnkCd, dbData.stlmntBnkCd);
			acntInfo.dfltAcnt = atoi(dbData.dfltAcnt);
			acntInfo.st = atoi(dbData.st);

            
            /* Get the position in the Hashtable that will be used to store the account info. */
            rc = CmnHashCheckData(acntHashHandler, &acntInfo.acntId, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            acntInfo.pos = pos;          
            
            rc = CmnHashLogData(acntHashHandler, &acntInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
			
			/* If the account is active and is the default account of the org, 
			   set the pos of this account in the org info. */
			if (acntInfo.st == 1 && acntInfo.dfltAcnt == 1){
			    /* Get the org info by the org id in account info. */
				rc = OrgInfoGetByIdExt(acntInfo.orgId, &pOrgData);
				if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
				    /* The orgId in the account info does not exist, just do nothing */
				}else{
				    RAISE_ERR(rc, RTN);
				}
				
				/* Set the position of the account in the org info */
				/* According to the business rules, there should be only one default account for one organization */
				pOrgData->dfltAcntPos = pos;
			}
        }
        
    } else {
        /* If the account info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    acntHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    acntHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT AcntInfoGetByKey(uint64 acntId, pAcntInfoT pAcntInfo){

    BEGIN_FUNCTION("AcntInfoGetByKey");
    
    ResCodeT rc = NO_ERR;
    pAcntInfoT pData;
    
    /* Call AcntInfoGetByKeyExt to get the credit info. */
    rc = AcntInfoGetByKeyExt(acntId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pAcntInfo, pData, sizeof(AcntInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT AcntInfoGetByKeyExt(uint64 acntId, pAcntInfoT *ppAcntInfo){

    BEGIN_FUNCTION("AcntInfoGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    uint64 keyId;

	keyId = acntId;
    /* Check if the account info exists in the hash table. */
    rc = CmnHashCheckDataExt(acntHashHandler, &keyId, &isExist, &nodePos, (void**)ppAcntInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the account info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT AcntInfoGetByPos(uint64 acntPos, pAcntInfoT pAcntInfo){

    BEGIN_FUNCTION("AcntInfoGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pAcntInfoT pData;
    
    rc = AcntInfoGetByPosExt(acntPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pAcntInfo, pData, sizeof(AcntInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT AcntInfoGetByPosExt(uint64 acntPos, pAcntInfoT *ppAcntInfo){

    BEGIN_FUNCTION("AcntInfoGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(acntHashHandler, acntPos, (void**)ppAcntInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT AcntInfoAttachToShm(){

    BEGIN_FUNCTION("AcntInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_ACNT_INFO_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    acntHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT AcntInfoDetachFromShm(){

    BEGIN_FUNCTION("AcntInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_ACNT_INFO_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}




/****************************** The implementation of SBF deposit account info ************************************************/

ResCodeT DpstAcntInfoSbfLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("DpstAcntInfoSbfLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    DpstAcntInfoSbfT acntInfo;
    BOOL existFlag;
    uint32 pos;
    DpstAcntInfoSbfT pData;
    DpstAcntInfoSbf dbData;
    BOOL bFrstFlg = TRUE;
	pOrgInfoT pOrgData;
    
    /* If the SBF deposit account info load flag is FALSE, creation of the hashtable is necessary. */
    if (dpstAcntHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [DPST_ACNT_INFO_SBF] */
        rc = GetResultCntOfDpstAcntInfoSbf(connId, &dataCount);
        RAISE_ERR(rc, RTN);

    
        recInfo.recSize = sizeof(DpstAcntInfoSbfT);
        recInfo.keyOffset = offsetof(DpstAcntInfoSbfT, dpstAcntId);
        recInfo.keySize = sizeof(uint64);
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_DPST_ACNT_INFO_SBF_NAME), 
                                recInfo, FALSE, &pShmRoot, &dpstAcntHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextDpstAcntInfoSbf(&bFrstFlg, connId, &dbData))){
    
            memset(&acntInfo, 0x00, sizeof(DpstAcntInfoSbfT));
            
            // Copy the retun value of fetchNextData into DpstAcntInfoSbfT
			acntInfo.dpstAcntSrno = dbData.dpstAcntSrno;
			acntInfo.dpstAcntId = dbData.dpstAcntId;
			strcpy(acntInfo.dpstAcntNo, dbData.dpstAcntNo);
			acntInfo.orgId = dbData.orgId;
			acntInfo.acntSrno = dbData.acntSrno;
			acntInfo.dfltAcnt = atoi(dbData.dfltAcnt);
			acntInfo.st = atoi(dbData.st);
			acntInfo.sysSrc = atoi(dbData.sysSrc);

            
            /* Get the position in the Hashtable that will be used to store the SBF deposit account info. */
            rc = CmnHashCheckData(dpstAcntHashHandler, &acntInfo.dpstAcntId, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            acntInfo.pos = pos;          
            
            rc = CmnHashLogData(dpstAcntHashHandler, &acntInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
			
			/* If the account is active and is the default account of the org, 
			   set the pos of this account in the org info. */
			if (acntInfo.st == 1 && acntInfo.dfltAcnt == 1){
			    /* Get the org info by the org id in account info. */
				rc = OrgInfoGetByIdExt(acntInfo.orgId, &pOrgData);
				if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
				    /* The orgId in the account info does not exist, just do nothing */
				}else{
				    RAISE_ERR(rc, RTN);
				}
				
				/* Set the position of the account in the org info */
				/* According to the business rules, there should be only one default SBF deposit account for one organization */
				pOrgData->dfltDpstAcntSbfPos = pos;
			}
        }
        
    } else {
        /* If the SBF deposit account info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    dpstAcntHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    dpstAcntHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT DpstAcntInfoSbfGetByKey(uint64 acntId, pDpstAcntInfoSbfT pAcntInfo){

    BEGIN_FUNCTION("DpstAcntInfoSbfGetByKey");
    
    ResCodeT rc = NO_ERR;
    pDpstAcntInfoSbfT pData;
    
    /* Call DpstAcntInfoSbfGetByKeyExt to get the credit info. */
    rc = DpstAcntInfoSbfGetByKeyExt(acntId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pAcntInfo, pData, sizeof(DpstAcntInfoSbfT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT DpstAcntInfoSbfGetByKeyExt(uint64 acntId, pDpstAcntInfoSbfT *ppAcntInfo){

    BEGIN_FUNCTION("DpstAcntInfoSbfGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    uint64 keyId;

	keyId = acntId;
    /* Check if the SBF deposit account info exists in the hash table. */
    rc = CmnHashCheckDataExt(dpstAcntHashHandler, &keyId, &isExist, &nodePos, (void**)ppAcntInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the SBF deposit account info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT DpstAcntInfoSbfGetByPos(uint64 acntPos, pDpstAcntInfoSbfT pAcntInfo){

    BEGIN_FUNCTION("DpstAcntInfoSbfGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pDpstAcntInfoSbfT pData;
    
    rc = DpstAcntInfoSbfGetByPosExt(acntPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pAcntInfo, pData, sizeof(DpstAcntInfoSbfT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT DpstAcntInfoSbfGetByPosExt(uint64 acntPos, pDpstAcntInfoSbfT *ppAcntInfo){

    BEGIN_FUNCTION("DpstAcntInfoSbfGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(dpstAcntHashHandler, acntPos, (void**)ppAcntInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT DpstAcntInfoSbfAttachToShm(){

    BEGIN_FUNCTION("DpstAcntInfoSbfAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_DPST_ACNT_INFO_SBF_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    dpstAcntHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT DpstAcntInfoSbfDetachFromShm(){

    BEGIN_FUNCTION("DpstAcntInfoSbfDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_DPST_ACNT_INFO_SBF_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


