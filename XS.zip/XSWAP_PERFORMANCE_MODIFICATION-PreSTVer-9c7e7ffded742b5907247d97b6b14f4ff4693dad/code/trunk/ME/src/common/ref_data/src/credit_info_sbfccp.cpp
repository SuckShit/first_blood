﻿/***
Created on Oct 18, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "credit_info_sbfccp.h"
#include "CrdtSbfccpDb.h"
#include "CntrctPstnSbfccpDb.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT crdtSbfCcpHashHandler;
static CmnHashHndlT cntrctPstnSbfCcpHashHandler;

static BOOL crdtSbfCcpHashLoadFlag = FALSE;
static BOOL cntrctPstnSbfCcpHashLoadFlag = FALSE;

static char delimiter[1] = {CREDIT_SBFCCP_HASH_KEY_DELIMITER};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

static void GenerateCntrctPstnHashKey(uint32 orgId, char *cntrctCode, char *pHashKey){

    memcpy(pHashKey, &orgId, sizeof(uint32));
    pHashKey = pHashKey + sizeof(uint32);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    strcpy(pHashKey, cntrctCode);
}
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT CreditSbfCcpInfoLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("CreditSbfCcpInfoLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    CreditSbfCcpT crdtInfo;
    BOOL existFlag;
    uint32 pos;
    CreditSbfCcpT pData;
    CrdtSbfccp dbData;
    BOOL bFrstFlg = TRUE;
    
    /* If the sbfccp credit info load flag is FALSE, creation of the hashtable is necessary. */
    if (crdtSbfCcpHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [CRDT_SBFCCP] */
        rc = GetResultCntOfCrdtSbfccp(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(CreditSbfCcpT);
        recInfo.keyOffset = offsetof(CreditSbfCcpT, orgId);
        recInfo.keySize = sizeof(uint32);
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_CRDT_SBFCCP_NAME), 
                                recInfo, FALSE, &pShmRoot, &crdtSbfCcpHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextCrdtSbfccp(&bFrstFlg, connId, &dbData))){
    
            memset(&crdtInfo, 0x00, sizeof(CreditSbfCcpT));
            
            crdtInfo.orgId = dbData.orgId;      
			crdtInfo.clsPstnFlag = atoi(dbData.clsPstnF);
			crdtInfo.lmtPstnFlag = atoi(dbData.lmtPstnF);
			crdtInfo.st = atoi(dbData.st);         
			crdtInfo.intlAmnt = dbData.intlAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);   
			crdtInfo.bidIntlAmnt = dbData.bidIntlAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
            crdtInfo.bidUsedAmnt = dbData.bidUsedAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
            crdtInfo.bidHoldAmnt = dbData.bidHoldAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
            crdtInfo.bidRmnAmnt = dbData.bidRmnAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT); 
            crdtInfo.ofrIntlAmnt = dbData.ofrIntlAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
            crdtInfo.ofrUsedAmnt = dbData.ofrUsedAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
            crdtInfo.ofrHoldAmnt = dbData.ofrHoldAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
            crdtInfo.ofrRmnAmnt = dbData.ofrRmnAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT); 
        
            
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(crdtSbfCcpHashHandler, &crdtInfo.orgId, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            crdtInfo.pos = pos;          
            
            rc = CmnHashLogData(crdtSbfCcpHashHandler, &crdtInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    crdtSbfCcpHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    crdtSbfCcpHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT CreditSbfCcpInfoGetByKey(uint32 orgId, pCreditSbfCcpT pCrdtInfo){

    BEGIN_FUNCTION("CreditSbfCcpInfoGetByKey");
    
    ResCodeT rc = NO_ERR;
    pCreditSbfCcpT pData;
    
    /* Call CreditSbfCcpInfoGetByKeyExt to get the credit info. */
    rc = CreditSbfCcpInfoGetByKeyExt(orgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pCrdtInfo, pData, sizeof(CreditSbfCcpT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditSbfCcpInfoGetByKeyExt(uint32 orgId, pCreditSbfCcpT *ppCrdtInfo){

    BEGIN_FUNCTION("CreditSbfCcpInfoGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    uint32 keyId;

    /* Check if the credit info exists in the hash table. */
	keyId = orgId;
    rc = CmnHashCheckDataExt(crdtSbfCcpHashHandler, &keyId, &isExist, &nodePos, (void**)ppCrdtInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the credit info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditSbfCcpInfoGetByPos(uint64 crdtPos, pCreditSbfCcpT pCrdtInfo){

    BEGIN_FUNCTION("CreditSbfCcpInfoGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    pCreditSbfCcpT pData;
    
    rc = CreditSbfCcpInfoGetByPosExt(crdtPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pCrdtInfo, pData, sizeof(CreditSbfCcpT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditSbfCcpInfoGetByPosExt(uint64 crdtPos, pCreditSbfCcpT *ppCrdtInfo){

    BEGIN_FUNCTION("CreditSbfCcpInfoGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(crdtSbfCcpHashHandler, crdtPos, (void**)ppCrdtInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditSbfCcpInfoAttachToShm(){

    BEGIN_FUNCTION("CreditSbfCcpInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_CRDT_SBFCCP_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    crdtSbfCcpHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditSbfCcpInfoDetachFromShm(){

    BEGIN_FUNCTION("CreditSbfCcpInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_CRDT_SBFCCP_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}




/****************************** The implementation of SBFCCP Contract Position  ************************************************/
ResCodeT CntrctPstnSbfCcpLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("CntrctPstnSbfCcpLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    CntrctPstnSbfCcpT cntrctPstnInfo;
    BOOL existFlag;
    uint32 pos;
    CntrctPstnSbfCcpT pData;
    CntrctPstnSbfccp dbData;
    BOOL    bFrstFlg = TRUE;
    
    /* If the SBFCCP Contract Position info load flag is FALSE, creation of the hashtable is necessary. */
    if (cntrctPstnSbfCcpHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [CNTRCT_PSTN_SBFCCP] */
        rc = GetResultCntOfCntrctPstnSbfccp(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

        recInfo.recSize = sizeof(CntrctPstnSbfCcpT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(CntrctPstnSbfCcpT, hashKey);
        recInfo.keySize = CNTRCT_PSTN_SBFCCP_HASH_KEY_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_CNTRCT_PSTN_SBFCCP_NAME), 
                                recInfo, TRUE, &pShmRoot, &cntrctPstnSbfCcpHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextCntrctPstnSbfccp(&bFrstFlg, connId, &dbData))){
    
            memset(&cntrctPstnInfo, 0x00, sizeof(CntrctPstnSbfCcpT));
            memset(cntrctPstnInfo.hashKey, 0x00, CNTRCT_PSTN_SBFCCP_HASH_KEY_LENGTH);

            // Copy the retun value of fetchNextData into CntrctPstnSbfCcpT
			cntrctPstnInfo.orgId = dbData.orgId;      
			strcpy(cntrctPstnInfo.cntrctCd, dbData.cntrctCd);
			cntrctPstnInfo.netPstn = dbData.netPstn * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);    
			cntrctPstnInfo.bidHoldAmnt = dbData.bidHoldAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
			cntrctPstnInfo.ofrHoldAmnt = dbData.ofrHoldAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
 

            /* Generate the key to be hashed. The key will be created by combining the orgId and cntrctCd */
            GenerateCntrctPstnHashKey(cntrctPstnInfo.orgId, cntrctPstnInfo.cntrctCd, cntrctPstnInfo.hashKey);
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(cntrctPstnSbfCcpHashHandler, (void*)cntrctPstnInfo.hashKey, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            cntrctPstnInfo.pos = pos;          
            
            rc = CmnHashLogData(cntrctPstnSbfCcpHashHandler, &cntrctPstnInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the SBFCCP Contract Position info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    cntrctPstnSbfCcpHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    cntrctPstnSbfCcpHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpGetByKey(uint32 orgId, char* cntrctCode, pCntrctPstnSbfCcpT pCntrctPstnInfo){

    BEGIN_FUNCTION("CntrctPstnSbfCcpGetByKey");
    
    ResCodeT rc = NO_ERR;
    pCntrctPstnSbfCcpT pData;
    
    /* Call CntrctPstnSbfCcpGetByKeyExt to get the SBFCCP contract position info. */
    rc = CntrctPstnSbfCcpGetByKeyExt(orgId, cntrctCode, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pCntrctPstnInfo, pData, sizeof(CntrctPstnSbfCcpT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpGetByKeyExt(uint32 orgId, char* cntrctCode, pCntrctPstnSbfCcpT *ppCntrctPstnInfo){

    BEGIN_FUNCTION("CntrctPstnSbfCcpGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[CNTRCT_PSTN_SBFCCP_HASH_KEY_LENGTH];
    
    memset(key, 0x00, CNTRCT_PSTN_SBFCCP_HASH_KEY_LENGTH);
    /* combine orgId and contract name as the key to be hashed. */
    GenerateCntrctPstnHashKey(orgId, cntrctCode, key);
        

    /* Check if the SBFCCP contract position info exists in the hash table. */
    rc = CmnHashCheckDataExt(cntrctPstnSbfCcpHashHandler, key, &isExist, &nodePos, (void**)ppCntrctPstnInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the SBFCCP contract position info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpGetByPos(uint32 pstnPos, pCntrctPstnSbfCcpT pCntrctPstnInfo){

    BEGIN_FUNCTION("CntrctPstnSbfCcpGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    pCntrctPstnSbfCcpT pData;
    
    rc = CntrctPstnSbfCcpGetByPosExt(pstnPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pCntrctPstnInfo, pData, sizeof(CntrctPstnSbfCcpT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpGetByPosExt(uint32 pstnPos, pCntrctPstnSbfCcpT *ppCntrctPstnInfo){

    BEGIN_FUNCTION("CntrctPstnSbfCcpGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(cntrctPstnSbfCcpHashHandler, pstnPos, (void**)ppCntrctPstnInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpIterExt(uint32 * pstnPos, pCntrctPstnSbfCcpT *ppData)
{

    BEGIN_FUNCTION("CntrctPstnSbfCcpIterExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterDataExt(cntrctPstnSbfCcpHashHandler, pstnPos, (void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpAttachToShm(){

    BEGIN_FUNCTION("CntrctPstnSbfCcpAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_CNTRCT_PSTN_SBFCCP_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    cntrctPstnSbfCcpHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CntrctPstnSbfCcpDetachFromShm(){

    BEGIN_FUNCTION("CntrctPstnSbfCcpDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_CNTRCT_PSTN_SBFCCP_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}