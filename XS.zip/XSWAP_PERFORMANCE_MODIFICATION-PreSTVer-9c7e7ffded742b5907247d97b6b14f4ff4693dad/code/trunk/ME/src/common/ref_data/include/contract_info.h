/***
Created on June 29, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _CONTRACT_INFO_
#define _CONTRACT_INFO_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define FIGURES_OF_AMOUNT_RATIO         5         /* 合约面值比例尺的小数位数 */

#define FIGURES_OF_CONTRCT_FACE_VAL     2         /* 合约面值的小数位数 */
#define FIGURES_OF_AMNT_PER_UNIT        2         /* 单位报价量的小数位数 */
#define FIGURES_OF_INTREST_SPREAD       5         /* 固定利率收取方_利差的小数位数 */
#define FIGURES_OF_CONVERT_RATE         6         /* 额度转换系数的小数位数 */
#define FIGURES_OF_PRICE_LIMIT          3         /* 跌涨幅限制的小数位数 */
#define FIGURES_OF_COUPON_RATE          5         /* 票面利率的小数位数 */
#define FIGURES_OF_BENCHMARK_RATE       5         /* 挂牌基准利率的小数位数 */

#define CONTRCT_NAME_LENGTH             50
#define SHORT_CONTRCT_NAME_LENGTH       50
#define LONG_CONTRCT_NAME_LENGTH        50
#define TERM_STRING_LENGTH              50

#define CONTRCT_NAME_EN_LENGTH          50
#define CONTRCT_MONTH_LENGTH            8
#define TRADING_END_TIME_LENGTH         10

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 合约信息(IRS,SIRS,SBFCCP) */
typedef struct CntrctBaseInfoS
{
    /* -------- 所有合约类型共有字段 ---------------- */
    char            cntrctName[CONTRCT_NAME_LENGTH];                /* 合约名       IRS: 对应于表字段cntrct_nm; SIRS & SBFCCP: 对应于表字段cntrct_cd */   
    uint16          mktId;                                          /* 市场标识  1 IRS、2 SIRS、3 SBF、4 SIRSCCP、5 SBFCCP */
    uint16          st;                                             /* 合约状态  IRS           : 0 禁用、1 启用、2 待确认 
                                                                                 SIRS & SBFCCP : 0 待上市、1 交易中、2 已退市、3 交易结束、4 已暂停  */
    uint16          term;                                           /* 合约期限(月) */   
    uint32          maxAmntPerDeal;                                 /* 单笔最大报价量(单位：手) */     
    uint32          minAmntPerDeal;                                 /* 单笔最小报价量(单位：手) */   
    uint64          pos;                                            /* 在内存Hash结构中的位置 */
    uint32          setId;                                          /* 合约所属的撮合引擎的SETID    亦等价于 市场标识
                                                                       市场标识  1 IRS、2 SIRS、3 SBF、4 SIRSCCP、5 SBFCCP  */

    
    /* -------- IRS和SIRS合约共有字段 ---------------- */
    uint16          dealPrcUnit;                                    /* 订单报价单位 枚举：0  BP值   1 百分比值  期差合约时是BP值  */

    
    /* -------- SIRS和SBFCCP合约共有字段 ---------------- */
    char            cntrctNameEn[CONTRCT_NAME_EN_LENGTH];           /* 合约种类(合约英文名) */
    char            cntrctMth[CONTRCT_MONTH_LENGTH];                /* 合约月份，形式为YYMM */
    uint64          cntrctFaceVal;                                  /* 合约面值（元） */
    char            dlvryDate[MAX_DATETIME_LEN];                    /* 交割日 */
    char            actvDate[MAX_DATETIME_LEN];                     /* 上架日期(上市交易日) */
    char            exprdDate[MAX_DATETIME_LEN];                    /* 下架日期(最后交易日) */
    uint64          amntPerUnit;                                    /* 单位报价量(元) */
    uint64          bnchmkRate;                                     /* 挂牌基准利率(%) */
    char            trdngEndTm[TRADING_END_TIME_LENGTH];            /* 最后交易日交易结束时间，格式：HH:MM:SS */
    uint16          emgcyFlag;                                      /* 应急下架标志：1 恢复、2 暂停 */
    uint16          settleType;                                     /* 清算方式：1 双边自行清算、2 上海清算所清算 */


    /* -------- IRS合约特有字段 ---------------- */
    uint16          cntrctType;                                     /* 合约类型 枚举：0 直接合约 1 期差合约 2 基准互换合约  */
    char            shrtCntrctName[SHORT_CONTRCT_NAME_LENGTH];      /* 短端合约名 【期差合约短端】【期差合约时填写】 */
    char            lngCntrctName[LONG_CONTRCT_NAME_LENGTH];        /* 长端合约名【期差合约长端】【期差合约时填写】  */  
    char            termStrng[TERM_STRING_LENGTH];                  /* 期限字符串 */
    uint16          brdgSort;                                       /* 搭桥顺序   */
    uint32          shrtAmntRatio;                                  /* 短端合约面值比例尺  */  
    uint32          lngAmntRatio;                                   /* 长端合约面值比例尺  */  
    uint64          dealUnit;                                       /* 交易单位 每手量  */  

    
    /* -------- SIRS合约特有字段 ---------------- */
    char            intrstStartDate[MAX_DATETIME_LEN];              /* 计息期首日 */
    char            intrstEndDate[MAX_DATETIME_LEN];                /* 计息期尾日(到期日) */  
    char            intrstDate[MAX_DATETIME_LEN];                   /* 起息日 */
    char            frstIntrstDate[MAX_DATETIME_LEN];               /* 首期起息日 */
    uint16          intrstDaysAdj;                                  /* 计息天数调整：1 不调整、2 实际天数 */
    uint16          pymntDateAdj;                                   /* 支付日调整：1 上一营业日、2 下一营业日、3 经调整的下一营业日 */
    char            fxdIntrstBidDlvryDate[MAX_DATETIME_LEN];        /* 固定利率支付方_首期定期支付日  */   
    uint16          fxdIntrstBidPymntPeriod;                        /* 固定利率支付方_支付周期：1 到期、2 天、3 周、4 两周、5 月、6 季、7 半年、8 年  */
    uint16          fxdIntrstBidIntrstBnchmk;                       /* 固定利率支付方_计息基准：1 实际/365、2 实际/360、3 实际/实际、4 30E/360、5 实际/365F  */   
    uint16          fxdIntrstBidIntrstType;                         /* 固定利率支付方_计息方式：1 复利、2 单利  */   
    char            refCntrct[CONTRCT_NAME_LENGTH];                 /* 固定利率收取方_参考利率(参考合约)  */   
    uint16          intrstType;                                     /* 固定利率收取方_计息方式：1 复利、2 单利  */
    char            fxdIntrstOfrDlvryDay[MAX_DATETIME_LEN];         /* 固定利率收取方_首期定期支付日 */    
    char            frstIntrstCnfrmDate[MAX_DATETIME_LEN];          /* 固定利率收取方_首次利率确定日  */   
    uint64          intrstSpread;                                   /* 固定利率收取方_利差(%) */    
    uint16          fxdIntrstOfrPymntPeriod;                        /* 固定利率收取方_支付周期：1 到期、2 天、3 周、4 两周、5 月、6 季、7 半年、8 年   */
    uint16          resetRate;                                      /* 固定利率收取方_重置频率：1 天、2 周、3 两周、4 月、5 季、6 半年、7 年   */  
    uint16          fxdIntrstOfrIntrstBnchmk;                       /* 固定利率收取方_计息基准：1 实际/365、2 实际/360、3 实际/实际、4 30E/360、5 实际/365F  */

    
    /* -------- SBFCCP合约特有字段 ---------------- */
    uint16          cntrctUndrlyng;                                 /* 合约标的:1-票面利率为3%的3年期虚拟记账式国债,2-票面利率为3%的7年期虚拟记账式国债,3-票面利率为3%的3年期虚拟国开债,4-票面利率为3%的5年期虚拟国开债,5-票面利率为3%的10年期虚拟国开债 */
    uint64          cnvrtRate;                                      /* 额度转换系数 */
    uint64          prcLimit;                                       /* 跌涨幅限制（%） */
    uint64          cpnRate;                                        /* 票面利率 */
    uint16          chkSt;                                          /* 复核状态，枚举值：1-新增待复核，2-删除待复核，3-复核成功 */
    char            filler[6];
    
} CntrctBaseInfoT, *pCntrctBaseInfoT;


typedef struct CntrctListInfoS
{
    char            cntrctName[CONTRCT_NAME_LENGTH];   
    uint32          pos;
} CntrctListInfoT, *pCntrctListInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read data from Table [CNTRCT_BASE_INFO] & [CNTRCT_INFO_SIRS] & [CNTRCT_INFO_SBFCCP],
   load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT IrsCntrctInfoLoadFromDB(int32 connId);

/* Search the IRS Contract Info by specifying the contract name. */
ResCodeT IrsCntrctInfoGetByName(char *cntrctName, pCntrctBaseInfoT pIrsCntrctInfo);

/* Search the IRS Contract Info by specifying the contract name.
   The return value ppIrsCntrctInfo is the direct address of contract info in the Hash shared memory. */
ResCodeT IrsCntrctInfoGetByNameExt(char *cntrctName, pCntrctBaseInfoT *ppIrsCntrctInfo);

/* Get the IRS Contract Info by specifying the position in the hash table. */
ResCodeT IrsCntrctInfoGetByPos(uint64 cntrctPos, pCntrctBaseInfoT pIrsCntrctInfo);

/* Get the IRS Contract Info by specifying the position in the hash table. 
   The return value ppIrsCntrctInfo is the direct address of contract info in the Hash shared memory. */
ResCodeT IrsCntrctInfoGetByPosExt(uint64 cntrctPos, pCntrctBaseInfoT *ppIrsCntrctInfo);

/* Attach to the shared memory. */
ResCodeT IrsCntrctInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT IrsCntrctInfoDetachFromShm();

/* for iterate contract use. */
ResCodeT IrsCntrctInfoIterExt(uint32 * cntrctPos, pCntrctBaseInfoT * ppData);
ResCodeT IrsCntrctInfoGetCnt(uint64 * ttlCnt, uint64 * pUsedCnt);

ResCodeT IrsCntrctListIter(uint32 *pCntrctPos, pCntrctListInfoT * ppData);
ResCodeT SirsCntrctListIter(uint32 *pCntrctPos, pCntrctListInfoT * ppData);
ResCodeT SbfccpCntrctListIter(uint32 *pCntrctPos, pCntrctListInfoT * ppData);
#endif /* _CONTRACT_INFO_ */
