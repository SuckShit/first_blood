/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "common_hash.h"
#include "UsrDb.h"
#include "usr.h"
#include "shm.h"
#include "uti_tool.h"
#include "org_info.h"
#include "pck_irs_dicdata.h"
#include "usr_role.h"

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
#define  ONE_ORG_MAX_USR_CNT    100
/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
CmnHashHndlT usrInfoHashHndl;
BOOL flag = FALSE;

/***********************************************************************************************
**
**   Functiona Declaration                                                                           
**
************************************************************************************************/
ResCodeT IrsUsrStrtok(char* string, int* token, alignTypeT type);


/***********************************************************************************************
**
**   Functiona Implementation                                                                           
**
************************************************************************************************/
/******************************************************************************
* Description:   load user info from DB to hash 
* Parameters:
*      pInQHndl    IN  
*      N/A         OUT 
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT IrsUsrInfoLoadFromDb(int32 connid)
{
    BEGIN_FUNCTION("IrsUsrInfoLoadFromDb");
    HashTableRecInfoT recUsrInfo;
    UsrBaseInfoT usrInfo;
    BrdgOrgInfoT*  pBrdgOrg;
    uint32 pos = 0;
    int32 usrInfoCount = 0;
    BOOL exist = FALSE;
    UsrJoin usrInfoData;
    UsrJoin data;
    void *pRt;    
    alignTypeT type;
    ResCodeT rc = NO_ERR;
    int i = 0;

    OrgInfoT* pOrg;
    UsrBaseInfoT* pPreUser;
    SubNodeT* pSub = NULL;
    uint32   subPos;    
    BOOL    bFrst = TRUE;
    
    /*create user info memory*/
    rc = GetResultCntOfUsr(connid, &usrInfoCount);
    if (NOTOK(rc)){
        TRACE("get user count failure");
        THROW_RESCODE(rc);
    }

    recUsrInfo.recSize = sizeof(UsrBaseInfoT);
    recUsrInfo.recCnt = usrInfoCount + 10;
    recUsrInfo.keyOffset = offsetof(UsrBaseInfoT, usrLgnNm);
    recUsrInfo.keySize = 100;

    /*create hash table for user info*/
    rc = CmnHashTblCreate(GetShmNm((char*)SHM_IRS_USR_NAME), recUsrInfo,1, &pRt, &usrInfoHashHndl);
    //RAISE_ERR(rc, RTN);
    if (NOTOK(rc)){
        TRACE("create hash failure");
        THROW_RESCODE(rc);
    }
    
    /*fetch user info from DB*/
    for(i=0; i<usrInfoCount; i++){        
        memset(&usrInfoData, 0, sizeof(UsrJoin));
        memset(&usrInfo, 0, sizeof(UsrBaseInfoT));
        rc = FetchNextUsrJoin(&bFrst, connid, &usrInfoData);
        if (NOTOK(rc)){
            TRACE("fetch next usr failure");
            THROW_RESCODE(rc);
        }
        strcpy(usrInfo.usrLgnNm, usrInfoData.usrLgnNm);
        usrInfo.orgId = usrInfoData.orgId;
        strcpy(usrInfo.usrSt, usrInfoData.usrSt);
        strcpy(usrInfo.sysSrc, usrInfoData.sysSrc);
        strcpy(usrInfo.apiF ,usrInfoData.apiF);
        strcpy(usrInfo.ordrPrvlgF ,usrInfoData.ordrPrvlgF);
        strcpy(usrInfo.ordrPrvlgMdfyF ,usrInfoData.ordrPrvlgMdfyF);
        strcpy(usrInfo.ordrPrvlgFSirs ,usrInfoData.ordrPrvlgFSirs);
        strcpy(usrInfo.ordrPrvlgMdfyFSirs ,usrInfoData.ordrPrvlgMdfyFSirs);
        strcpy(usrInfo.ordrPrvlgFSbfccp ,usrInfoData.ordrPrvlgFSbfccp);
        strcpy(usrInfo.ordrPrvlgMdfyFSbfccp ,usrInfoData.ordrPrvlgMdfyFSbfccp);
        strcpy(usrInfo.sesnId, usrInfoData.sesnId);
        if (0 != strcmp(usrInfo.sesnId, " ")){
            usrInfo.usrOnlnStatus = TRUE;
        }
        usrInfo.lgnTp = usrInfoData.lgnTp;
        strcpy(usrInfo.lgnTm, usrInfoData.lgnTm);
        type = alignInc;
        rc = IrsUsrStrtok(usrInfoData.roleId, usrInfo.roleId, type);
        if (NOTOK(rc)){
            TRACE("strtok roleid failure");
            THROW_RESCODE(rc);
        }
        rc = IrsUsrStrtok(usrInfoData.mktTp, usrInfo.mktTp, type);
        if (NOTOK(rc)){
            TRACE("strtok mktTp failure");
            THROW_RESCODE(rc);
        }
        type = alignNor;
        rc = IrsUsrStrtok(usrInfoData.mktSt, usrInfo.mktSt, type);
        if (NOTOK(rc)){
            TRACE("strtok mktSt failure");
            THROW_RESCODE(rc);
        }
        strcpy(usrInfo.nmDesc, usrInfoData.nmDesc);
        
        usrInfo.ocoOrdCnt = 0;

        rc = CmnHashCheckData(usrInfoHashHndl, (void*)&usrInfo.usrLgnNm, &exist, &pos, (void*)&data);
        if (NOTOK(rc)){
            TRACE("check data failure");
            THROW_RESCODE(rc);
        }
        usrInfo.pos = pos;
        
        //get org info
        pSub = NULL;
        rc = OrgInfoGetByIdExt(usrInfo.orgId, &pOrg);
        if (rc == NO_ERR)    
        {
            if (pOrg->usrListNode.lstPos != -1)
            {    
                rc = IrsUsrInfoGetByPosExt(pOrg->usrListNode.lstPos, &pPreUser);
                RAISE_ERR(rc, RTN);

                pSub  = &pPreUser->usrListNode;
                subPos = pPreUser->pos;            
            }
        
            rc = CommHashAddFrNode(&pOrg->usrListNode, pos, &usrInfo.usrListNode, subPos, pSub );
            RAISE_ERR(rc, RTN);   
        }        
        
        //get BrdgOrg info
        pSub = NULL;
        rc = BrdgOrgInfoGetByIdExt(usrInfo.orgId, &pBrdgOrg);
        if (rc == NO_ERR)    
        {
            if (pBrdgOrg->usrMrkPrgListNode.lstPos != -1)
            {    
                rc = IrsUsrInfoGetByPosExt(pBrdgOrg->usrMrkPrgListNode.lstPos, &pPreUser);
                RAISE_ERR(rc, RTN);

                pSub  = &pPreUser->usrMrkPrgListNode;
                subPos = pPreUser->pos;            
            }
        
            rc = CommHashAddFrNode(&pBrdgOrg->usrMrkPrgListNode, pos, &usrInfo.usrMrkPrgListNode, subPos, pSub );
            RAISE_ERR(rc, RTN);   
        }
        
        if (FALSE == exist){
            rc = CmnHashLogData(usrInfoHashHndl, (void*)&usrInfo, pos, 1, 1);
            if (NOTOK(rc)){
                TRACE("update hash data failure");
                THROW_RESCODE(rc);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}



ResCodeT IrsUsrInfoGetCnt(uint64 * ttlCnt, uint64 * pUsedCnt)
{
    BEGIN_FUNCTION("IrsUsrInfoGetCnt");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashTblGetRecTotal(usrInfoHashHndl, pUsedCnt);
    RAISE_ERR(rc, RTN);
    rc = CmnHashTblGetRecAll(usrInfoHashHndl, ttlCnt);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}




ResCodeT IrsUsrInfoIterExt(uint32 * usrPos, pUsrBaseInfoT * ppData)
{

    BEGIN_FUNCTION("IrsUsrInfoIterExt");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterDataExt(usrInfoHashHndl,usrPos,(void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT IrsUsrInfoGetByName(char* usrName, pUsrBaseInfoT pUsr)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByName");
    ResCodeT rc = NO_ERR;
    pUsrBaseInfoT pData;
    
    /* Call IrsCntrctInfoGetByNameExt to get the IRS contract info. */
    rc = IrsUsrInfoGetByNameExt(usrName, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pUsr, pData, sizeof(UsrBaseInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrInfoGetByNameExt(char* usrName, pUsrBaseInfoT* pUsr)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByNameExt");
    uint32 pos = 0;
    ResCodeT rc = NO_ERR;
    BOOL exist = FALSE;
    char keyNm[100];


    memset(keyNm, 0, 100);
    strcpy(keyNm, usrName);

    rc = CmnHashCheckDataExt(usrInfoHashHndl, keyNm, &exist, &pos, (void**)pUsr);
    RAISE_ERR(rc, RTN);

    if (FALSE == exist){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IrsUsrInfoGetByPos(uint64 UsrPos, pUsrBaseInfoT pUsr)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByPos");
    ResCodeT rc = NO_ERR;
    pUsrBaseInfoT tmpData;
    
    rc = IrsUsrInfoGetByPosExt(UsrPos, &tmpData);
    RAISE_ERR(rc , RTN);

    memcpy(pUsr, tmpData, sizeof(UsrBaseInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT IrsUsrInfoGetByPosExt(uint64 UsrPos, pUsrBaseInfoT* pUsr)
{
    BEGIN_FUNCTION("IrsUsrInfoGetByPosExt");
    ResCodeT rc = NO_ERR;

    rc = CmnHashReadDataAddrByPos(usrInfoHashHndl, UsrPos, (void**)pUsr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrInfoAttachToShm(void)
{

    BEGIN_FUNCTION("IrsUsrInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_IRS_USR_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    usrInfoHashHndl = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsUsrInfoDetachFromShm(void)
{
    BEGIN_FUNCTION("IrsUsrInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_IRS_USR_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT IrsUsrStrtok(char* string, int* token, alignTypeT type)
{
    BEGIN_FUNCTION("IrsUsrStrtok");
    int32 i = 0, j = 0, k = 0,temp = 0;
    int* tokenTemp = token;
    char tokenData[10];    
    char* strToken;
    char stringTemp[10];

    memset(stringTemp, 0, sizeof(tokenData));
    strcpy(stringTemp, string);
    memset(tokenData, 0, sizeof(tokenData));
    strToken = strtok(stringTemp, ",");
    while (strToken){
        strcpy(&tokenData[j], strToken);
        temp = atoi(&tokenData[j]);
        if (alignInc == type){
            for(k=1;k<=10;k++){
                if (k == temp){
                    *(tokenTemp+k-1) = 1;
                    break;
                }
            }
        }
        else if (alignNor == type){
            *(tokenTemp+i) = temp;
            i++;
        }
        else{
            /*do nothing*/
        }
        
        strToken = strtok(NULL, "");
        strToken = strtok(strToken, ",");
        j++;
    }
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT IrsUsrMktStatusGet(char* usrName, int mktTp, BOOL *status)
{
    BEGIN_FUNCTION("IrsUsrMktStatusGet");
    UsrBaseInfoT usr_info;
    BOOL mktStatus = FALSE;
    int i = 0;
    ResCodeT rc = NO_ERR;

    memset(&usr_info, 0, sizeof(UsrBaseInfoT));
    rc = IrsUsrInfoGetByName(usrName, &usr_info);
    RAISE_ERR(rc, RTN);

    if (1 == usr_info.mktSt[mktTp - 1]){
        mktStatus = TRUE;
    }
    else{
        mktStatus = FALSE;
    }

    *status = mktStatus;
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT SetIrsUsrRoleId(char* usrName, int roleId, BOOL status)
{
    BEGIN_FUNCTION("SetIrsUsrRoleId");
    UsrBaseInfoT usr_info;
    BOOL role_exist = FALSE;
    int i = 0;
    ResCodeT rc = NO_ERR;

    memset(&usr_info, 0, sizeof(UsrBaseInfoT));
    rc = IrsUsrInfoGetByName(usrName, &usr_info);
    RAISE_ERR(rc, RTN);
    
    if (TRUE == status)
    {
        usr_info.roleId[roleId-1] == 1;
    }else
    {
        usr_info.roleId[roleId-1] == 0;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//after DB delete 
ResCodeT UserDelete(uint32 pos)
{
    BEGIN_FUNCTION("UserDelete");
    UsrBaseInfoT usr;
    UsrBaseInfoT* pPreUsr;
    UsrBaseInfoT* pNxtUsr;
    OrgInfoT* pOrg;
    ResCodeT rc = NO_ERR;

    SubNodeT* pPreNode = NULL;
    SubNodeT* pNxtNode = NULL;
    uint32  prePos = -1;
    uint32  nxtPos = -1;
    
    rc = IrsUsrInfoGetByPos(pos, &usr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByIdExt(usr.orgId, &pOrg);
    RAISE_ERR(rc, RTN);
    
    if (usr.usrListNode.prePos != -1)
    {
        prePos = usr.usrListNode.prePos;

        rc = IrsUsrInfoGetByPosExt(usr.usrListNode.prePos, &pPreUsr);
        RAISE_ERR(rc, RTN);

        pPreNode = &pPreUsr->usrListNode;
    }
    
    if (usr.usrListNode.nxtPos != -1)
    {
        nxtPos = usr.usrListNode.nxtPos;

        rc = IrsUsrInfoGetByPosExt(usr.usrListNode.nxtPos, &pNxtUsr);
        RAISE_ERR(rc, RTN);

        pNxtNode = &pNxtUsr->usrListNode;
    }
    
    rc = CommHashSubDel(pPreNode, prePos, pNxtNode, nxtPos, &(pOrg->usrListNode));
    RAISE_ERR(rc, RTN);
    
    rc = CmnHashDeleteData(usrInfoHashHndl, pos);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

//after DB insert
ResCodeT UserAdd(UsrBaseInfoT* pUsr)
{
    BEGIN_FUNCTION("UserAdd");
    ResCodeT rc = NO_ERR;
    UsrBaseInfoT tmpUsr;
    UsrBaseInfoT* pLastUsr;
    OrgInfoT* pOrg;
    BOOL  exist;
    uint32 pos;
 
    SubNodeT* pLastNode = NULL;
    uint64 lastNodePos = -1;
 
 
    rc = CmnHashCheckData(usrInfoHashHndl, (void*)pUsr->usrLgnNm, &exist, &pos, (void*)&tmpUsr);    
    RAISE_ERR(rc, RTN);

    if (FALSE == exist)
    {
        //RAISE_ERR(rc, RTN);
    }
    
    rc = OrgInfoGetByIdExt(pUsr->orgId, &pOrg);
    RAISE_ERR(rc, RTN);
    
    if (pOrg->usrListNode.lstPos != -1)
    {
        rc = IrsUsrInfoGetByPosExt(pOrg->usrListNode.lstPos, &pLastUsr);
        RAISE_ERR(rc, RTN);
        pLastNode = &pLastUsr->usrListNode;
        lastNodePos = pOrg->usrListNode.lstPos;
    }
    
    rc = CommHashSubAdd(&pUsr->usrListNode, pos, pLastNode, lastNodePos, &pOrg->usrListNode);
    RAISE_ERR(rc, RTN);
    
    rc = CmnHashLogData(usrInfoHashHndl, (void*)pUsr, pos, 1, 1);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnUserAndUsrRoleUpdateByOrgIdFreeze(uint64 orgIdx, int16 reqType)
{
    BEGIN_FUNCTION("OnUserAndUsrRoleUpdateByOrgIdFreeze");
    ResCodeT rc = NO_ERR;
    uint64  tmpPos;
    UsrBaseInfoT* pUsr;
    OrgInfoT* pOrg;
    BOOL status = FALSE;

    int32 fromRole, toRole;
    if (reqType == C_REQUEST_FORBID)
    {
        fromRole = C_USER_ROLE_FRONT;
        toRole = C_USER_ROLE_LIMIT_FRONT;
    }else
    {
        fromRole = C_USER_ROLE_LIMIT_FRONT;
        toRole = C_USER_ROLE_FRONT;
    }    
    
    rc = OrgInfoGetByPosExt(orgIdx, &pOrg);
    RAISE_ERR(rc, RTN);
    
    tmpPos = pOrg->usrListNode.frstPos;
    
    while ( TRUE )
    {
        rc = IrsUsrInfoGetByPosExt(tmpPos, &pUsr);    
        RAISE_ERR(rc, RTN);
        
        if (pUsr->lgnTp == fromRole)
        {
            pUsr->lgnTp = toRole;
        }
        
        rc = IrsUsrRoleIdIsExist(pUsr->usrLgnNm, fromRole, &status);
        if (status == TRUE)
        {
            SetIrsUsrRoleId(pUsr->usrLgnNm, fromRole, 0);
            SetIrsUsrRoleId(pUsr->usrLgnNm, toRole, 1);
        }

        if (tmpPos == pOrg->usrListNode.lstPos)
        {
            break;
        }
        
        //next node
        tmpPos = pUsr->usrListNode.nxtPos;
    }
    
    //update the DB.
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateUsrMrkPrvlg(uint64 orgPos, int32 market, int32* pPrvlg)
{
    BEGIN_FUNCTION("UpdateUsrMrkPrvlg");
    ResCodeT rc = NO_ERR;
    UsrBaseInfoT* pUsr;
    OrgInfoT* pOrg;
    int32 i;
    int64 tmpPos;

    rc = OrgInfoGetByPosExt(orgPos, &pOrg);
    RAISE_ERR(rc, RTN);
        
    tmpPos = pOrg->usrListNode.frstPos;
    while ( TRUE )
    {
        rc = IrsUsrInfoGetByPosExt(tmpPos, &pUsr);    
        RAISE_ERR(rc, RTN);    

        for(i = 0; i < 5; i++)
        {
            if (pUsr->mktTp[i] == market)
            {
                pUsr->mktSt[i] = *pPrvlg;
                break;
            }
        }
        
        if (tmpPos == pOrg->usrListNode.lstPos)
        {
            break;
        }
        
        tmpPos = pUsr->usrListNode.nxtPos;        
    }    
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT UpdateUsrMrkPrvlgByUsr(int64 usrPos, int32 market, int32* pPrvlg)
{
    BEGIN_FUNCTION("UpdateUsrMrkPrvlgByUsr");
    ResCodeT rc = NO_ERR;

    UsrBaseInfoT* pUsr;
    int32 i;
    int32 pTmpPrvlg[5];
    BOOL  flg = FALSE;
    uint64  tmpPos;
    
    rc = IrsUsrInfoGetByPosExt(usrPos, &pUsr);
    RAISE_ERR(rc, RTN);

    for(i = 0; i < 5; i++)
    {
        if (pUsr->mktTp[i] == market)
        {
            pUsr->mktSt[i] = *pPrvlg;
            break;
        }
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

