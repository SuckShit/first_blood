/***
Created on Aug 17, 2017
@author: Jiawang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files*/
#include "err_lib.h"
#include "common_macro.h"
#include "uti_tool.h"
#include "bit_lib.h"
#include "shm.h"

#include "active_info.h"
#include "ActiveInfoDb.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct ActiveShmAcsS
{
    void*               pRoot;
    pActiveInfoHeadT    pActiveHead;
    pActiveInfoT        pActiveInfo;
} ActiveShmAcsT, *pActiveShmAcsT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

static ActiveShmAcsT    g_sActiveShmAcs;
static BOOL             g_blActiveLoadFlag = FALSE;
static int32            g_iSetCount = -1;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 **
 ** Function Implementation
 **
 ******************************************************************************/

/******************************************************************************
 **
 ** ActiveInfoLoadFromDB
 **     load active info from database
 **
 ******************************************************************************/
ResCodeT ActiveInfoLoadFromDB(int32 connId)
{
    BEGIN_FUNCTION("ActiveInfoLoadFromDB");
    ResCodeT        rc = NO_ERR;
    BOOL            bFrstFlg = TRUE;
    ActiveInfo      dbData;

    // connId is invalid, return error.
    if (connId == DB_INVALID_CONN_ID) {
        // error.
        //RAISE_ERR(rc, RTN);
        RETURN_RESCODE;
    }

    /* If the active info load flag is FALSE, load active info from database. */
    if (FALSE == g_blActiveLoadFlag)
    {
        /* First, need to get the count of records in Table [ACTIVE_INFO] */
        rc = GetResultCntOfActiveInfo(connId, &g_iSetCount);
        RAISE_ERR(rc, RTN);

        if (-1 == g_iSetCount)
        {
            THROW_RESCODE(ERR_HA_GET_SETCOUNT_FAILED);
        }

        rc = ActiveInfoShmCreate();
        if (NOTOK(rc))
        {
            THROW_RESCODE(rc);
        }

        memset(&dbData, 0, sizeof(ActiveInfo));
        /* Read the data from DB, and load them into the shared memory. */
        while (OK(FetchNextActiveInfo(&bFrstFlg,connId, &dbData)))
        {
            BitSet(g_sActiveShmAcs.pActiveHead->allSetIds, dbData.setId);

            // Copy the retun value of fetchNextData into ActiveInfoT
            g_sActiveShmAcs.pActiveInfo[dbData.setId].setId = dbData.setId;
            strcpy(g_sActiveShmAcs.pActiveInfo[dbData.setId].primaryHost, dbData.primaryHost);
            strcpy(g_sActiveShmAcs.pActiveInfo[dbData.setId].backupHost, dbData.backupHost);
            strcpy(g_sActiveShmAcs.pActiveInfo[dbData.setId].haTime, dbData.haTime);

            memset(&dbData, 0, sizeof(ActiveInfo));
        }
    }
    else
    {
        /* If the active info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }

    g_blActiveLoadFlag = TRUE;

    SET_RESCODE(rc);
    RETURN_RESCODE;

    // error operation
    EXIT_BLOCK();

    g_blActiveLoadFlag = FALSE;

    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** MapActiveShmAcs
 **
 ******************************************************************************/
static ResCodeT MapActiveShmAcs(void* pRoot, pActiveShmAcsT pShmAcs)
{
    BEGIN_FUNCTION("MapActiveShmAcs");
    ResCodeT    rc = NO_ERR;

    pShmAcs->pRoot = pRoot;
    pShmAcs->pActiveHead = (pActiveInfoHeadT)pRoot;
    pShmAcs->pActiveInfo = (pActiveInfoT)ADDRESS_ADD_OFFSET(pShmAcs->pActiveHead, sizeof(ActiveInfoHeadT));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveInfoShmCreate
 ** Description:   Create active info share memeory.
 ** Parameters:
 **      N/A         OUT
 **      NO_ERR:     Successful
 **      ERR_<DSCR>: fail to create the share memory.
 **
 ******************************************************************************/
ResCodeT ActiveInfoShmCreate()
{
    BEGIN_FUNCTION("ActiveInfoShmCreate");
    ResCodeT    rc = NO_ERR;

    void *      pShmRoot = NULL;
    int64       ttlMemSize = 0;

    ttlMemSize = sizeof(ActiveInfoHeadT) + sizeof(ActiveInfoT)*(g_iSetCount+1);

    rc = ShmCreate(GetShmNm((char*)SHM_ACTIVE_INFO_NAME), ttlMemSize, (int64 **)&pShmRoot);
    RAISE_ERR(rc, RTN);

    memset(pShmRoot, 0, ttlMemSize);

    /* Map the share memory access global array */
    rc = MapActiveShmAcs(pShmRoot, &g_sActiveShmAcs);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveInfoShmAttach
 **
 ******************************************************************************/
ResCodeT ActiveInfoShmAttach()
{
    BEGIN_FUNCTION("ActiveInfoShmAttach");
    ResCodeT rc = NO_ERR;

    void*   pShmRoot = NULL;
    int64   ttlMemSize = 0;

    ttlMemSize = sizeof(ActiveInfoHeadT) + sizeof(ActiveInfoT)*(g_iSetCount+1);

    /* Attach to the shared memory. */
    rc = ShmAttach(GetShmNm((char*)SHM_ACTIVE_INFO_NAME), (int64 **)&pShmRoot);
    RAISE_ERR(rc, RTN);

    memset(pShmRoot, 0, ttlMemSize);

    /* Map the share memory access global array */
    rc = MapActiveShmAcs(pShmRoot, &g_sActiveShmAcs);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveInfoShmDetach
 **
 ******************************************************************************/
ResCodeT ActiveInfoShmDetach()
{
    BEGIN_FUNCTION("ActiveInfoShmDetach");
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_ACTIVE_INFO_NAME));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveInfoShmDelete
 **
 ******************************************************************************/
ResCodeT ActiveInfoShmDelete()
{
    BEGIN_FUNCTION("ActiveInfoShmDelete");
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDelete(GetShmNm((char*)SHM_ACTIVE_INFO_NAME));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveInfoGetById
 **
 ******************************************************************************/
ResCodeT ActiveInfoGetById(uint64 setId, pActiveInfoT pActiveInfo)
{
    BEGIN_FUNCTION("ActiveInfoGetById");
    ResCodeT rc = NO_ERR;

    if (setId > g_iSetCount)
    {
        THROW_RESCODE(ERR_HA_INPUT_SET_ID);
    }

    pActiveInfoT pData;

    /* Call ActiveInfoGetByIdExt to get the active info. */
    rc = ActiveInfoGetByIdExt(setId, &pData);
    RAISE_ERR(rc, RTN);

    /* If there is no error, copy the data into output parameter  */
    memcpy(pActiveInfo, pData, sizeof(ActiveInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveInfoGetByIdExt
 **
 ******************************************************************************/
ResCodeT ActiveInfoGetByIdExt(uint64 setId, pActiveInfoT *ppActiveInfo)
{
    BEGIN_FUNCTION("ActiveInfoGetByIdExt");
    ResCodeT rc = NO_ERR;

    if (setId > g_iSetCount)
    {
        THROW_RESCODE(ERR_HA_INPUT_SET_ID);
    }

    *ppActiveInfo = g_sActiveShmAcs.pActiveInfo + setId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetActiveHead
 **
 ******************************************************************************/
ResCodeT GetActiveHead(ActiveInfoHeadT * head)
{
    BEGIN_FUNCTION("GetActiveHead");
    ResCodeT rc = NO_ERR;

    memcpy(head, g_sActiveShmAcs.pActiveHead, sizeof(ActiveInfoHeadT));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetAllSetIdsPtr
 **
 ******************************************************************************/
ResCodeT GetAllSetIdsPtr(vectorT ** pAllSetIds)
{
    BEGIN_FUNCTION( "GetAllSetIdsPtr" );
    ResCodeT rc = NO_ERR;

    *pAllSetIds = g_sActiveShmAcs.pActiveHead->allSetIds;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetAllActiveInfoPtr
 **
 ******************************************************************************/
ResCodeT GetAllActiveInfoPtr(pActiveInfoT *pAllActiveInfo)
{
    BEGIN_FUNCTION( "GetAllActiveInfoPtr" );
    ResCodeT rc = NO_ERR;

    *pAllActiveInfo = g_sActiveShmAcs.pActiveInfo;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
