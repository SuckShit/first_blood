/***
Created on Sep 29, 2017
@author: Jiawang Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _BASE_PARAM_API_
#define _BASE_PARAM_API_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define PARAM_NAME_LENGTH               100
#define PARAM_VALUE_LENGTH              100



/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 基本参数 */
typedef struct BaseParamApiS
{
    char            paramName[PARAM_NAME_LENGTH];           /* 参数名 */
    char            paramValue[PARAM_VALUE_LENGTH];         /* 参数值 */
    uint64          pos;                                    /* 在内存Hash结构中的位置 */
} BaseParamApiT, *pBaseParamApiT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Read data from Table [BASE_PARAM_API] and load these data into shared memory.
   Call this method before calling other methods. Or call this method to
   reload data from DB. */
ResCodeT BaseParamApiLoadFromDB(int32 connId);

/* Search the Base Parameter by specifying the parameter name. */
ResCodeT BaseParamApiGetByName(char *paramName, pBaseParamApiT pBaseParamApi);

/* Search the Base Parameter by specifying the parameter name.
   The return value ppBaseParamApi is the direct address of base parameter in the Hash shared memory. */
ResCodeT BaseParamApiGetByNameExt(char *paramName, pBaseParamApiT *ppBaseParamApi);

/* Get the Base Parameter by specifying the position in the hash table. */
ResCodeT BaseParamApiGetByPos(uint64 paramPos, pBaseParamApiT pBaseParamApi);

/* Get the Base Parameter by specifying the position in the hash table.
   The return value ppBaseParamApi is the direct address of base parameter in the Hash shared memory. */
ResCodeT BaseParamApiGetByPosExt(uint64 paramPos, pBaseParamApiT *ppBaseParamApi);

/* Attach to the shared memory. */
ResCodeT BaseParamApiAttachToShm();

/* Detach from the shared memory. */
ResCodeT BaseParamApiDetachFromShm();

#endif /* _BASE_PARAM_API_ */
