﻿/***
Created on Sep 12, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _MKT_ST_CFG_
#define _MKT_ST_CFG_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MKT_ST_CFG_START_TIME_LENGTH              8



/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 系统状态资源 */
typedef struct MktStCfgS
{
    uint64          mktStCfgId;                                   /* 市场状态配置ID */         
    uint64          mktSt;                                        /* 市场状态，枚举值：1-开市，2-开盘，3-休市，4-收盘，5-闭市 */    
    char            strtTm[MKT_ST_CFG_START_TIME_LENGTH];         /* 状态开始时间，格式：HH:MI */
    char            nextStrtTm[MKT_ST_CFG_START_TIME_LENGTH];     /* 状态开始时间（隔日生效），格式：HH:MI */
    int16           sendFlag;                                     /* 发送标志，枚举值：0-未发送，1-已发送 */
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} MktStCfgT, *pMktStCfgT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read data from Table [MKT_ST_CFG] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT MktStCfgLoadFromDB(int32 connId);

/* Get the market status config data returned in pMktStCfg by specifying resource id and system status id. */
ResCodeT MktStCfgGetByKey(uint64 cfgId, pMktStCfgT pMktStCfg);

/* Get the market status config data returned in pMktStCfg by specifying resource id and system status id. 
   The return value ppMktStCfg is the direct address of system status info in the Hash shared memory. */
ResCodeT MktStCfgGetByKeyExt(uint64 cfgId, pMktStCfgT *ppMktStCfg);

/* Get the market status config data returned in pMktStCfg by specifying the position in the hash table. */
ResCodeT MktStCfgGetByPos(uint64 cfgPos, pMktStCfgT pMktStCfg);

/* Get the market status config data returned in ppMktStCfg by specifying the position in the hash table. 
   The return value ppMktStCfg is the direct address of system status info in the Hash shared memory. */
ResCodeT MktStCfgGetByPosExt(uint64 cfgPos, pMktStCfgT *ppMktStCfg);

/* Attach to the shared memory. */
ResCodeT MktStCfgAttachToShm();

/* Detach from the shared memory. */
ResCodeT MktStCfgDetachFromShm();


#endif /* _MKT_ST_CFG_ */
