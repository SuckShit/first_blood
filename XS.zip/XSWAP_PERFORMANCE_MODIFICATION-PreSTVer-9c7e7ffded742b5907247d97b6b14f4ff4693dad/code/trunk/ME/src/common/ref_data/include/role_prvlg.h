﻿/***
Created on Aug 19, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _ROLE_PRVLG_
#define _ROLE_PRVLG_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define ROLE_PRVLG_HASH_KEY_LENGTH               32
#define ROLE_PRVLG_HASH_KEY_DELIMITER            '&'


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 角色权限 */
typedef struct RolePrvlgS
{
    char            hashKey[ROLE_PRVLG_HASH_KEY_LENGTH];          /* 角色权限的HashKey,由 资源标识+角色标识 组成 */
    uint64          rsrcId;                                       /* 资源标识 */    
    uint32          roleId;                                       /* 角色标识 */         
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} RolePrvlgT, *pRolePrvlgT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read data from Table [ROLE_PRVLG] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT RolePrvlgLoadFromDB(int32 connId);

/* Get the role privilege returned in pRolePrvlg by specifying resource id and role id. */
ResCodeT RolePrvlgGetByKey(uint64 rsrcId, uint32 roleId, pRolePrvlgT pRolePrvlg);

/* Get the role privilege returned in ppRolePrvlg by specifying resource id and role id. 
   The return value ppRolePrvlg is the direct address of role privilege info in the Hash shared memory. */
ResCodeT RolePrvlgGetByKeyExt(uint64 rsrcId, uint32 roleId, pRolePrvlgT *ppRolePrvlg);

/* Get the role privilege returned in pRskCfcnt by specifying the position in the hash table. */
ResCodeT RolePrvlgGetByPos(uint64 rsrcPos, pRolePrvlgT pRolePrvlg);

/* Get the role privilege returned in ppRolePrvlg by specifying the position in the hash table. 
   The return value ppRolePrvlg is the direct address of role privilege info in the Hash shared memory. */
ResCodeT RolePrvlgGetByPosExt(uint64 rsrcPos, pRolePrvlgT *ppRolePrvlg);

/* Attach to the shared memory. */
ResCodeT RolePrvlgAttachToShm();

/* Detach from the shared memory. */
ResCodeT RolePrvlgDetachFromShm();

/* Insert */
ResCodeT RolePrvlgAdd(uint64 rsrcId, uint32 roleId, pRolePrvlgT *ppRolePrvlg);

#endif /* _ROLE_PRVLG_ */
