/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _PRDCT_INFO_T_
#define _PRDCT_INFO_T_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define TRD_RES_TYP_COD_LEN             2
#define TRAN_TYP_COD_LEN                3

#define PRDCT_NAME_LENGTH               50
#define BST_MKTINFO_GRP_MAX             10

#define REFPRC_NODE_NUM_MAX             ((int32)120)

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct BstMktInfoGrpS
{
    int64   bstBidPrc;
    int64   bstAskPrc;
    int64   bstBidQty;
    int64   bstAskQty;
    uint64  numOrdrBid;
    uint64  numOrdrAsk;

} BstMktInfoGrpT, *pBstMktInfoGrpT;

typedef struct PrdctBaseInfoS
{
    int64               mktBidQty;
    int64               mktAskQty;
    int64               mktBidOrdrNum;
    int64               mktAskOrdrNum;
    int64               auctOpenPrc;
    int64               lstTrdPrc;
    int64               lstTrdQty;
    int64               dlyHghPrc;
    int64               dlyLowPrc;
    int64               opnPrc;
    int64               intraRefPrc;
    int64               wghtTotPrc;
    int64               wghtTotQty;
    int64               totTrdQty;
    int64               lstTrdDatTim;
    int64               lstUpdateTim;
    int64               lstRefPrcUpdTim;
    int16               prcsSts;
    char                filler[6];

} PrdctBaseInfoT, *pPrdctBaseInfoT;

typedef struct PrdctInfoS
{
    int16               setId;
    int32               filler;
    char                prdctName[PRDCT_NAME_LENGTH];
    BstMktInfoGrpT      bstMktInfoGrp[BST_MKTINFO_GRP_MAX];
    PrdctBaseInfoT      baseInfo;
    uint64              pos;
    
} PrdctInfoT, *pPrdctInfoT;

typedef struct RefPrcNodeS
{
    uint64              prdctId;
    int64               intraRefPrc;
} RefPrcNodeT, *pRefPrcNodeT;

typedef struct PrdRefPrcUpdS
{
    int64               refPrcUpdTime;
    int32               updCnt;
    uint32              iterPos;
    RefPrcNodeT         refPrcNode[REFPRC_NODE_NUM_MAX];
} PrdRefPrcUpdT, *pPrdRefPrcUpdT;

/* Read data from Table [CNTRCT_BASE_INFO] and load the corresponding productInfo data into shared memory. 
   Call this method before calling other methods. */
ResCodeT PrdctInfoLoadFromDB(int32 connId);

/* Search the IRS PrdctInfo by specifying the product code. 
   The return value ppPrdctInfo is the direct address of IRS product info in the Hash shared memory. */
ResCodeT PrdctInfoGetByNameExt(char *prdctName, pPrdctInfoT *ppPrdctInfo);

/* Search the PrdctInfo by specifying the position of product in hash table.  
   The return value ppPrdctInfo is the direct address of IRS product info in the Hash shared memory. */
ResCodeT PrdctInfoGetByPosExt(uint32 prdctPos, pPrdctInfoT *ppPrdctInfo);

/* Update the IRS PrdctInfo by specifying the product code. */
ResCodeT PrdctInfoUpdateByName(char *prdctName, pPrdctInfoT pPrdctInfo);

/* Update the IRS PrdctInfo by specifying the position of product in hash table. */
ResCodeT PrdctInfoUpdateByPos(uint64 prdctPos, pPrdctInfoT pPrdctInfo);

/* Attach to the shared memory. */
ResCodeT PrdctInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT PrdctInfoDetachFromShm();

BOOL NeedUpdMktInfo( int32 setId );
void SetMktInfoUpdVec( int32 setId, int32 prdctId );
void ResetMktInfoUpdVec( int32 setId );
ResCodeT UpdInsideMktInfo( int32 setId, int64 timestamp );

void UpdWghtPrcAndQty( pPrdctInfoT pPrdctInfo, int64 exePrc, int64 exeQty );
ResCodeT CalcIntradayRefPrc( pPrdRefPrcUpdT pRefPrcUpd );
ResCodeT UpdIntradayRefPrc( pPrdRefPrcUpdT pRefPrcUpd );
ResCodeT UpdRefPrcToDb( int32 connId, pPrdRefPrcUpdT pRefPrcUpd );
ResCodeT PrdctInfoIterExt(uint32 * prdctPos, pPrdctInfoT * ppData);
#endif /* _PRDCT_INFO_T_ */
