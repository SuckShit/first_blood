/***
Created on June 29, 2017
@author: Gao.Liu
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _RSKCFCNT_
#define _RSKCFCNT_

/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/
 #include "shm_name.h"
 
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Type Defination
 ** 
 *****************************************************************************/
typedef struct rskCfCntInfo
{
    double  rskCfcntVl;
    char hashKey[100];
    int32  orgId;
    char  cntrctNm[50];    
    char  updUsrNm[100];
    char  updTm[50];
    int32 pos;
}RskCfCntInfoT, *pRskCfCntInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Read data from Table [Usr] and load these data into shared memory.    
Call this method before calling other methods. Or call this method to reload data from DB. */
ResCodeT IrsRskCfCntLoadFromDb(int32 connid);
ResCodeT IrsRskCfCntGetByTwoKey(char* cntrctNm, int32 orgId, pRskCfCntInfoT pRsk);
ResCodeT IrsRskCfCntGetByNameExt(char* cntrctNm, int32 orgId, pRskCfCntInfoT* pRsk);
ResCodeT IrsRskCfCntGetByPosExt(uint64 UsrPos, pRskCfCntInfoT* pRsk);
ResCodeT IrsRskCfCntAttachToShm(void);
ResCodeT IrsRskCfCntDetachFromShm(void);

#endif

