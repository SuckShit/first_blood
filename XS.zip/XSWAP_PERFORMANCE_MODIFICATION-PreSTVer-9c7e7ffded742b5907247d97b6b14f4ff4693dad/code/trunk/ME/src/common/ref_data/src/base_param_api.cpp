/***
Created on Sep 29, 2017
@author: Jiawang Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "shm.h"
#include "uti_tool.h"
#include "base_param_api.h"
#include "BaseParamApiDb.h"
#include "cfg_lib.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT paramHashHandler;
static BOOL paramHashLoadFlag = FALSE;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT BaseParamApiLoadFromDB(int32 connId)
{

    BEGIN_FUNCTION("BaseParamApiLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    BaseParamApiT paramInfo;
    BOOL existFlag;
    uint32 pos;
    BaseParamApiT pData;
    BaseParamApi dbData;
    BOOL            bFrstFlg = TRUE;
    //cfgValueS cfgValue = {0};
    /* If the base parameter load flag is FALSE, creation of the hashtable is necessary. */
    if (paramHashLoadFlag == FALSE){
        // /* Get the DB connection */
        //char prcsName[] = "";
        //PrcsInit(prcsName); 
        //
        //rc = GetCfgValue(&cfgValue);
        //EXPECT_EQ(rc,NO_ERR);
        
        // rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        // RAISE_ERR(rc, RTN);

        /* First,need to get the count of records in Table [BASE_PARAM] */
        rc = GetResultCntOfBaseParamApi(connId, &dataCount);
        RAISE_ERR(rc, RTN);



        recInfo.recSize = sizeof(BaseParamApiT);
        recInfo.keyOffset = offsetof(BaseParamApiT, paramName);
        recInfo.keySize = PARAM_NAME_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = FALSE;

        rc = CmnHashTblCreate(GetShmNm((char*)SHM_BASE_PARAM_API_NAME),
                                recInfo, FALSE, &pShmRoot, &paramHashHandler);

        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }

        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextBaseParamApi(&bFrstFlg,connId, &dbData))){

            memset(&paramInfo, 0x00, sizeof(BaseParamApiT));

            // Copy the retun value of fetchNextData into BaseParamApiT
            strcpy(paramInfo.paramName, dbData.paramNm);
            strcpy(paramInfo.paramValue, dbData.paramVl);


            /* Get the position in the Hashtable that will be used to store the IRS Contract. */
            rc = CmnHashCheckData(paramHashHandler, paramInfo.paramName, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            paramInfo.pos = pos;

            rc = CmnHashLogData(paramHashHandler, &paramInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }

    } else {
        /* If the base parameter datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }


    paramHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;

    EXIT_BLOCK();
    paramHashLoadFlag = FALSE;
    // if (connId != DB_INVALID_CONN_ID){
        // /* When error occurs, if the connection to DB has already been created, call Disconnect to release it. */
        // DbCmmnDisConnect(connId);
    // }
    RETURN_RESCODE;

}


ResCodeT BaseParamApiGetByName(char *paramName, pBaseParamApiT pBaseParamApi){

    BEGIN_FUNCTION("BaseParamApiGetByName");

    ResCodeT rc = NO_ERR;
    pBaseParamApiT pData;

    /* Call BaseParamApiGetByNameExt to get the IRS contract info. */
    rc = BaseParamApiGetByNameExt(paramName, &pData);
    RAISE_ERR(rc, RTN);

    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pBaseParamApi, pData, sizeof(BaseParamApiT));

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT BaseParamApiGetByNameExt(char *paramName, pBaseParamApiT *ppBaseParamApi){

    BEGIN_FUNCTION("BaseParamApiGetByNameExt");

    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[PARAM_NAME_LENGTH];

    /* Check if the base parameter exists in the hash table. */
    memset(key, 0x00, PARAM_NAME_LENGTH);
    strcpy(key, paramName);
    rc = CmnHashCheckDataExt(paramHashHandler, key, &isExist, &nodePos, (void**)ppBaseParamApi);
    RAISE_ERR(rc, RTN);

    /* If the base parameter doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT BaseParamApiGetByPos(uint64 paramPos, pBaseParamApiT pBaseParamApi){

    BEGIN_FUNCTION("BaseParamApiGetByPos");

    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pBaseParamApiT pData;

    rc = BaseParamApiGetByPosExt(paramPos, &pData);
    RAISE_ERR(rc, RTN);

    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pBaseParamApi, pData, sizeof(BaseParamApiT));

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT BaseParamApiGetByPosExt(uint64 paramPos, pBaseParamApiT *ppBaseParamApi){

    BEGIN_FUNCTION("BaseParamApiGetByPosExt");

    ResCodeT rc = NO_ERR;

    rc = CmnHashReadDataAddrByPos(paramHashHandler, paramPos, (void**)ppBaseParamApi);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT BaseParamApiAttachToShm(){

    BEGIN_FUNCTION("BaseParamApiAttachToShm");

    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_BASE_PARAM_API_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    paramHashHandler = hashHandler;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT BaseParamApiDetachFromShm(){

    BEGIN_FUNCTION("BaseParamApiDetachFromShm");

    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_BASE_PARAM_API_NAME));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
