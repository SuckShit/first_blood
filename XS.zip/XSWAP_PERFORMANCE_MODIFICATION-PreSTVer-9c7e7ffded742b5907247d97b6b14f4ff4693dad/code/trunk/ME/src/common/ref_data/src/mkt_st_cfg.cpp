﻿/***
Created on Sep 12, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "mkt_st_cfg.h"
#include "MktStCfgDb.h"



/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT mktStCfgHashHandler;

static BOOL mktStCfgHashLoadFlag = FALSE;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT MktStCfgLoadFromDB(int32 connId)
{

    BEGIN_FUNCTION("MktStCfgLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    MktStCfgT mktStCfg;
    BOOL existFlag;
    uint32 pos;
    MktStCfgT pData;
    MktStCfg dbData;
    BOOL    bFrstFlg = TRUE;
    
    /* If the market status config data load flag is FALSE, creation of the hashtable is necessary. */
    if (mktStCfgHashLoadFlag == FALSE){    
    
        /* First,need to get the count of records in Table [MKT_ST_CFG] */
        rc = GetResultCntOfMktStCfg(connId, &dataCount);
        RAISE_ERR(rc, RTN);

    
        recInfo.recSize = sizeof(MktStCfgT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(MktStCfgT, mktStCfgId);
        recInfo.keySize = sizeof(uint64);
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_MKT_ST_CFG_NAME), 
                                recInfo, FALSE, &pShmRoot, &mktStCfgHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextMktStCfg(&bFrstFlg,connId, &dbData))){
    
            memset(&mktStCfg, 0x00, sizeof(MktStCfgT));
            
            // Copy the retun value of fetchNextData into MktStCfgT
            mktStCfg.mktStCfgId = dbData.mktStCfgId;   
            mktStCfg.mktSt = atoi(dbData.mktSt);
            strcpy(mktStCfg.strtTm, dbData.strtTm);
            strcpy(mktStCfg.nextStrtTm, dbData.nextStrtTm);  
            mktStCfg.sendFlag = atoi(dbData.sendF);
    
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(mktStCfgHashHandler, (void*)&mktStCfg.mktStCfgId, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            mktStCfg.pos = pos;          
            
            rc = CmnHashLogData(mktStCfgHashHandler, &mktStCfg, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    mktStCfgHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    mktStCfgHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT MktStCfgGetByKey(uint64 cfgId, pMktStCfgT pMktStCfg){

    BEGIN_FUNCTION("MktStCfgGetByKey");
    
    ResCodeT rc = NO_ERR;
    pMktStCfgT pData;
    
    /* Call MktStCfgGetByKeyExt to get the system status resource info. */
    rc = MktStCfgGetByKeyExt(cfgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pMktStCfg, pData, sizeof(MktStCfgT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT MktStCfgGetByKeyExt(uint64 cfgId, pMktStCfgT *ppMktStCfg){

    BEGIN_FUNCTION("MktStCfgGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    

    /* Check if the market status config info exists in the hash table. */
    rc = CmnHashCheckDataExt(mktStCfgHashHandler, (void*)&cfgId, &isExist, &nodePos, (void**)ppMktStCfg);
    RAISE_ERR(rc, RTN);
    
    /* If the info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT MktStCfgGetByPos(uint64 cfgPos, pMktStCfgT pMktStCfg){

    BEGIN_FUNCTION("MktStCfgGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pMktStCfgT pData;
    
    rc = MktStCfgGetByPosExt(cfgPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pMktStCfg, pData, sizeof(MktStCfgT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT MktStCfgGetByPosExt(uint64 cfgPos, pMktStCfgT *ppMktStCfg){

    BEGIN_FUNCTION("MktStCfgGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(mktStCfgHashHandler, cfgPos, (void**)ppMktStCfg);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT MktStCfgAttachToShm(){

    BEGIN_FUNCTION("MktStCfgAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_MKT_ST_CFG_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    mktStCfgHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT MktStCfgDetachFromShm(){

    BEGIN_FUNCTION("MktStCfgDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_MKT_ST_CFG_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}
