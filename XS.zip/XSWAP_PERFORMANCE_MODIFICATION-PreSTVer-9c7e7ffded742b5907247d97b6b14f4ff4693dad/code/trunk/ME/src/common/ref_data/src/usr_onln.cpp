/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "common_macro.h"
#include "common_hash.h"

#include "usr_onln.h"
#include "UsrDb.h"
#include "UsrOnlnDb.h"
#include "shm.h"

/***********************************************************************************************
**
**   Macro
**
************************************************************************************************/

/***********************************************************************************************
**
**   Type Defination
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable
**
************************************************************************************************/
CmnHashHndlT usrOnlnHashHndl;
static CmnHashHndlT irsHashHandler;

/***********************************************************************************************
**
**   Functiona Declaration
**
************************************************************************************************/

/***********************************************************************************************
**
**   Functiona Implementation
**
************************************************************************************************/

/******************************************************************************
* Description:   load role info from DB to hash
* Parameters:
*      pInQHndl    IN
*      N/A         OUT
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT IrsUsrOnlnInfoLoadFromDb(int32 connid)
{
    BEGIN_FUNCTION("IrsUsrOnlnInfoLoadFromDb");
    HashTableRecInfoT recOnlnInfo;
    UsrOnlnBaseInfoT usrOnlnInfo;
    uint32 pos = 0;
    int32 usrOnlnCount = 0;
    int32 usrInfoCount = 0;
    BOOL exist = FALSE;
    UsrOnln usrOnlnData, data;
    void *pRt;
    ResCodeT rc = NO_ERR;
    int i = 0;
    BOOL   bFrstFlg = TRUE;
    /*create user info memory*/
    rc = GetResultCntOfUsrOnln(connid, &usrOnlnCount);
    if (NOTOK(rc)){
        TRACE("get user count failure");
        THROW_RESCODE(rc);
    }

    rc = GetResultCntOfUsr(connid, &usrInfoCount);
    if (NOTOK(rc)){
        TRACE("get user count failure");
        THROW_RESCODE(rc);
    }

    recOnlnInfo.recSize = sizeof(UsrOnlnBaseInfoT);
    recOnlnInfo.recCnt = usrInfoCount;
    recOnlnInfo.keyOffset = offsetof(UsrOnlnBaseInfoT, usrNm);
    recOnlnInfo.keySize = 100;

    /*create hash table for user info*/
    rc = CmnHashTblCreate(GetShmNm((char*)SHM_IRS_USR_ONLN_NAME), recOnlnInfo,1, &pRt, &usrOnlnHashHndl);
    //RAISE_ERR(rc, RTN);
    if (NOTOK(rc)){
        TRACE("create hash failure");
        THROW_RESCODE(rc);
    }


    /*fetch user info from DB*/
    for(i=0; i<usrOnlnCount; i++){
        memset(&usrOnlnData, 0, sizeof(UsrOnln));
        memset(&usrOnlnInfo, 0, sizeof(UsrOnlnBaseInfoT));
        rc = FetchNextUsrOnln(&bFrstFlg, connid, &usrOnlnData);
        if (NOTOK(rc)){
            TRACE("fetch next usr failure");
            THROW_RESCODE(rc);
        }
        strcpy(usrOnlnInfo.usrNm, usrOnlnData.usrNm);
        usrOnlnInfo.lgnTp = usrOnlnData.lgnTp;

        rc = CmnHashCheckData(usrOnlnHashHndl, usrOnlnInfo.usrNm, &exist, &pos, (void*)&data);
        if (NOTOK(rc)){
            TRACE("check data failure");
            THROW_RESCODE(rc);
        }
        usrOnlnInfo.pos = pos;
        if (FALSE == exist){
            rc = CmnHashLogData(usrOnlnHashHndl, (void*)&usrOnlnInfo, pos, 1, 1);
            if (NOTOK(rc)){
                TRACE("update hash data failure");
                THROW_RESCODE(rc);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrOnlnUpdateByName(int32 connId, char* name, int32 lgnTp)
{
    BEGIN_FUNCTION("IrsUsrOnlnUpdateByName");
    UsrOnln onlnUpdateData;
    ResCodeT rc = NO_ERR;
    memset(&onlnUpdateData, 0, sizeof(UsrOnln));

    vectorT  keyVec[GET_BIT_VECT_LEN(6)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(6)] = {0};

    DbCmmnSetColBit(keyVec, 0);

    DbCmmnSetColBit(datVec, 2);

    strcpy(onlnUpdateData.usrNm, name);
    onlnUpdateData.lgnTp = lgnTp;

    rc = UpdateUsrOnlnByKey(connId, &onlnUpdateData, keyVec, datVec);
    RAISE_ERR(rc, RTN);
    rc = DbCmmnCommit(connId);
    RAISE_ERR(rc,NO_ERR);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrOnlnInfoGetByName(char* onlnName, pUsrOnlnBaseInfoT pRole)
{
    BEGIN_FUNCTION("IrsUsrOnlnInfoGetByName");
    ResCodeT rc = NO_ERR;
    pUsrOnlnBaseInfoT pData;

    /* Call IrsRoleInfoGetByNameExt to get the IRS role info. */
    rc = IrsUsrOnlnInfoGetByNameExt(onlnName, &pData);
    RAISE_ERR(rc, RTN);

    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRole, pData, sizeof(UsrOnlnBaseInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrOnlnInfoGetByNameExt(char* onlnName, pUsrOnlnBaseInfoT* pRole)
{
    BEGIN_FUNCTION("IrsUsrOnlnInfoGetByNameExt");
    uint32 pos = 0;
    ResCodeT rc = NO_ERR;
    BOOL exist = FALSE;
    char keyNm[100];


    memset(keyNm, 0, 100);
    strcpy(keyNm, onlnName);

    rc = CmnHashCheckDataExt(usrOnlnHashHndl, keyNm, &exist, &pos, (void**)pRole);
    RAISE_ERR(rc, RTN);

    if (FALSE == exist){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IrsUsrOnlnInfoGetByPos(uint64 OnlnPos, pUsrOnlnBaseInfoT pRole)
{
    BEGIN_FUNCTION("IrsUsrOnlnInfoGetByPos");
    ResCodeT rc = NO_ERR;
    pUsrOnlnBaseInfoT tmpData;

    rc = IrsUsrOnlnInfoGetByPosExt(OnlnPos, &tmpData);
    RAISE_ERR(rc , RTN);

    memcpy(pRole, tmpData, sizeof(UsrOnlnBaseInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrOnlnInfoGetByPosExt(uint64 onlnPos, pUsrOnlnBaseInfoT* pRole)
{
    BEGIN_FUNCTION("IrsUsrOnlnInfoGetByPosExt");
    ResCodeT rc = NO_ERR;

    rc = CmnHashReadDataAddrByPos(usrOnlnHashHndl, onlnPos, (void**)pRole);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsUsrOnlnInfoAttachToShm(void)
{

    BEGIN_FUNCTION("IrsUsrOnlnInfoAttachToShm");

    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_IRS_USR_ONLN_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    irsHashHandler = hashHandler;

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT IrsUsrOnlnInfoDetachFromShm(void)
{
    BEGIN_FUNCTION("IrsUsrOnlnInfoDetachFromShm");

    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_IRS_USR_ONLN_NAME));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT UsrOnlnAddByName(pUsrBaseInfoT pUsrInfo)
{
    BEGIN_FUNCTION("UsrOnlnAddByName");

    ResCodeT rc = NO_ERR;
    UsrOnlnBaseInfoT usrOnlnData;
    UsrOnlnBaseInfoT data;
    BOOL existFlag = FALSE;
    uint32 pos;
    char keyNm[100];

    memset(keyNm, 0, 100);
    strcpy(keyNm, pUsrInfo->usrLgnNm);

    memset(&usrOnlnData, 0x00, sizeof(UsrOnlnBaseInfoT));

    strcpy(usrOnlnData.usrNm, pUsrInfo->usrLgnNm);

    rc = CmnHashCheckData(usrOnlnHashHndl, keyNm, &existFlag, &pos, (void*)&data);
    RAISE_ERR(rc, RTN);

    if (existFlag == TRUE){
        /* If the usrNm already exists in the hashtable */
        /* It means there's a new user of the usr logon */
        usrOnlnData.pos   = pUsrInfo->pos;
        usrOnlnData.lgnTp = pUsrInfo->lgnTp;

        rc = CmnHashUpdateData( usrOnlnHashHndl, &usrOnlnData, pos );
        RAISE_ERR(rc, RTN);
    }
    else
    {
        usrOnlnData.pos   = pUsrInfo->pos;
        usrOnlnData.lgnTp = pUsrInfo->lgnTp;

        rc = CmnHashLogData( usrOnlnHashHndl, &usrOnlnData, pos, TRUE, TRUE );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UsrOnlnDeleteByName( char* usrNm )
{
    BEGIN_FUNCTION("UsrOnlnDeleteByName");

    ResCodeT rc = NO_ERR;
    UsrOnlnBaseInfoT data;
    BOOL existFlag = FALSE;
    uint32 pos;

    char keyNm[100];

    memset(keyNm, 0, 100);
    strcpy(keyNm, usrNm);

    rc = CmnHashCheckData(usrOnlnHashHndl, keyNm, &existFlag, &pos, (void*)&data);
    RAISE_ERR(rc, RTN);

    if (existFlag == FALSE)
    {
        /* If the ordId doesn't exist in the hashtable, throw the error. */
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    rc = CmnHashDeleteData(usrOnlnHashHndl, pos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UsrOnlnIterExt(uint32 * pstnPos, pUsrOnlnBaseInfoT *ppData)
{

    BEGIN_FUNCTION("UsrOnlnIterExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterDataExt(usrOnlnHashHndl, pstnPos, (void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}