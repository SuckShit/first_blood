/***
Created on July 03, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "contract_info.h"
#include "CntrctBaseInfoDb.h"
#include "CntrctInfoSirsDb.h"
#include "CntrctInfoSbfccpDb.h"
#include "internal_base_def.h"
#include "pck_irs_dicdata.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT irsHashHandler;
static CmnHashHndlT irsListHashHhl;
static CmnHashHndlT sirsListHashHhl;
static CmnHashHndlT sbfccpListHashHhl;
static BOOL irsHashLoadFlag     = FALSE;
static BOOL irsListShmFlag      = FALSE;
static BOOL sirsListShmFlag     = FALSE;
static BOOL sbfccpListShmFlag   = FALSE;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static ResCodeT LoadIrsContractData(int32 connId);
static ResCodeT LoadSirsContractData(int32 connId);
static ResCodeT LoadSbfCcpContractData(int32 connId);
static ResCodeT CreateCntrctListShm(char *pShmName, CmnHashHndlT* pCmnHdl, uint32 recCnt);
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT IrsCntrctInfoLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("IrsCntrctInfoLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
	int32 dataTotalCount;
	int32 irsCount;
	int32 sirsCount;
	int32 sbfccpCount;
    void *pShmRoot;
    
    /* If the IRS contract info load flag is FALSE, creation of the hashtable is necessary. */
    if (irsHashLoadFlag == FALSE){    
    
        /* Get the count of records in Table [CNTRCT_BASE_INFO] */
        rc = GetResultCntOfCntrctBaseInfo(connId, &irsCount);
        RAISE_ERR(rc, RTN);
		dataTotalCount = irsCount;
		
		/* Get the count of records in Table [CNTRCT_INFO_SIRS] */
        rc = GetResultCntOfCntrctInfoSirs(connId, &sirsCount);
        RAISE_ERR(rc, RTN);
		dataTotalCount += sirsCount;
		
		/* Get the count of records in Table [CNTRCT_INFO_SBFCCP] */
        rc = GetResultCntOfCntrctInfoSbfccp(connId, &sbfccpCount);
        RAISE_ERR(rc, RTN);
		dataTotalCount += sbfccpCount;


        recInfo.recSize = sizeof(CntrctBaseInfoT);
        recInfo.keyOffset = offsetof(CntrctBaseInfoT, cntrctName);
        recInfo.keySize = CONTRCT_NAME_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataTotalCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_IRS_CONTRACT_INFO_NAME), 
                                recInfo, TRUE, &pShmRoot, &irsHashHandler);
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
		
        /* Create irs contrct list hash shm */
        if (!irsHashLoadFlag)
        {
            rc = CreateCntrctListShm((char*)SHM_IRS_CONTRACT_LIST_NAME, &irsListHashHhl, irsCount);
            RAISE_ERR(rc, RTN);
        }
        irsHashLoadFlag = TRUE;
        
        if (!sirsListShmFlag)
        {
            rc = CreateCntrctListShm((char*)SHM_SIRS_CONTRACT_LIST_NAME, &sirsListHashHhl, sirsCount);
            RAISE_ERR(rc, RTN);
        }
        sirsListShmFlag = TRUE;
        
        if (!sbfccpListShmFlag)
        {
            rc = CreateCntrctListShm((char*)SHM_SBFCCP_CONTRACT_LIST_NAME, &sbfccpListHashHhl, sbfccpCount);
            RAISE_ERR(rc, RTN);
        }
		

		/* Load the data of table [CNTRCT_BASE_INFO] into Hashtable */
		rc = LoadIrsContractData(connId);
		RAISE_ERR(rc, RTN);
		
		/* Load the data of table [CNTRCT_INFO_SIRS] into Hashtable */
		rc = LoadSirsContractData(connId);
		RAISE_ERR(rc, RTN);
		
		/* Load the data of table [CNTRCT_INFO_SBFCCP] into Hashtable */
        rc = LoadSbfCcpContractData(connId);
        RAISE_ERR(rc, RTN);
        
    } else {
        /* If the IRS contract datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    
    irsHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    irsHashLoadFlag = FALSE;
    RETURN_RESCODE;
    
}


ResCodeT IrsCntrctInfoGetByName(char *cntrctName, pCntrctBaseInfoT pIrsCntrctInfo){

    BEGIN_FUNCTION("IrsCntrctInfoGetByName");
    
    ResCodeT rc = NO_ERR;
    pCntrctBaseInfoT pData;
    
    /* Call IrsCntrctInfoGetByNameExt to get the IRS contract info. */
    rc = IrsCntrctInfoGetByNameExt(cntrctName, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pIrsCntrctInfo, pData, sizeof(CntrctBaseInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsCntrctInfoGetCnt(uint64 * ttlCnt, uint64 * pUsedCnt)
{
    BEGIN_FUNCTION("IrsCntrctInfoGetCnt");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashTblGetRecTotal(irsHashHandler, pUsedCnt);
    RAISE_ERR(rc, RTN);
    rc = CmnHashTblGetRecAll(irsHashHandler, ttlCnt);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT IrsCntrctInfoGetByNameExt(char *cntrctName, pCntrctBaseInfoT *ppIrsCntrctInfo){

    BEGIN_FUNCTION("IrsCntrctInfoGetByNameExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[CONTRCT_NAME_LENGTH];
    
    /* Check if the IRS contract exists in the hash table. */
    memset(key, 0x00, CONTRCT_NAME_LENGTH);
    strcpy(key, cntrctName);
    rc = CmnHashCheckDataExt(irsHashHandler, key, &isExist, &nodePos, (void**)ppIrsCntrctInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the IRS contract doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsCntrctInfoGetByPos(uint64 cntrctPos, pCntrctBaseInfoT pIrsCntrctInfo){

    BEGIN_FUNCTION("IrsCntrctInfoGetByNameExt");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    pCntrctBaseInfoT pData;
    
    rc = IrsCntrctInfoGetByPosExt(cntrctPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pIrsCntrctInfo, pData, sizeof(CntrctBaseInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsCntrctInfoGetByPosExt(uint64 cntrctPos, pCntrctBaseInfoT *ppIrsCntrctInfo){

    BEGIN_FUNCTION("IrsCntrctInfoGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(irsHashHandler, cntrctPos, (void**)ppIrsCntrctInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsCntrctInfoAttachToShm(){

    BEGIN_FUNCTION("IrsCntrctInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_IRS_CONTRACT_INFO_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    irsHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsCntrctInfoDetachFromShm(){

    BEGIN_FUNCTION("IrsCntrctInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_IRS_CONTRACT_INFO_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

static ResCodeT LoadContractListData(CntrctBaseInfoT* pCntrctBase, CmnHashHndlT hashHandler)
{
    BEGIN_FUNCTION("LoadIrsContractData");
    
    ResCodeT                rc = NO_ERR;
    BOOL                    existFlag;
    uint32                  pos;
    CntrctListInfoT         pData;
    CntrctListInfoT         listData;
    BOOL                    bFrstFlg = TRUE;    
	
	/* Chect irs list common hash  */
	memset(&listData, 0x00, sizeof(CntrctListInfoT));
	memcpy(listData.cntrctName, pCntrctBase->cntrctName, sizeof(listData.cntrctName));
	listData.pos    = pCntrctBase->pos;
	
	rc = CmnHashCheckData(hashHandler, pCntrctBase->cntrctName, &existFlag, &pos, (void*)&pData);
	RAISE_ERR(rc, RTN);
	
	rc = CmnHashLogData(hashHandler, &listData, pos, TRUE, TRUE);
	RAISE_ERR(rc, RTN);	

    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT LoadIrsContractData(int32 connId)
{
    BEGIN_FUNCTION("LoadIrsContractData");
    
    ResCodeT rc = NO_ERR;
	CntrctBaseInfoT irsCntrctInfo;
    BOOL existFlag;
    uint32 pos;
    CntrctBaseInfoT pData;
    CntrctBaseInfo dbData;
    CntrctListInfoT listData;
    CntrctListInfoT listDataOut;
    BOOL bFrstFlg = TRUE;    
	
	/* Read the data from DB, and load them into the hash table. */
	while (OK(FetchNextCntrctBaseInfo(&bFrstFlg,connId, &dbData))){

		memset(&irsCntrctInfo, 0x00, sizeof(CntrctBaseInfoT));
	
		// Copy the retun value of fetchNextData into CntrctBaseInfoT
		strcpy(irsCntrctInfo.cntrctName, dbData.cntrctNm);
		irsCntrctInfo.cntrctType = atoi(dbData.cntrctTp);
		irsCntrctInfo.mktId = atoi(dbData.mktId);      
		strcpy(irsCntrctInfo.shrtCntrctName, dbData.shrtCntrctNm);
		strcpy(irsCntrctInfo.lngCntrctName, dbData.lngCntrctNm);
		irsCntrctInfo.shrtAmntRatio = dbData.shrtAmntRatio * pow10(FIGURES_OF_AMOUNT_RATIO);
		irsCntrctInfo.lngAmntRatio = dbData.lngAmntRatio * pow10(FIGURES_OF_AMOUNT_RATIO);
		irsCntrctInfo.maxAmntPerDeal = dbData.maxAmntPerDl;
		irsCntrctInfo.minAmntPerDeal = dbData.minAmntPerDl;
		irsCntrctInfo.dealUnit = dbData.dlUnit;     
		irsCntrctInfo.dealPrcUnit = atoi(dbData.dlPrcUnit); 
		irsCntrctInfo.term = dbData.term;        
		irsCntrctInfo.st = atoi(dbData.st);          
		strcpy(irsCntrctInfo.termStrng, dbData.termStrng);
		irsCntrctInfo.brdgSort = dbData.brdgSort;
		irsCntrctInfo.setId = SET_MKT_IRS;
	
	
		/* Get the position in the Hashtable that will be used to store the IRS Contract. */
		rc = CmnHashCheckData(irsHashHandler, irsCntrctInfo.cntrctName, &existFlag, &pos, (void*)&pData);
		RAISE_ERR(rc, RTN);

		/* Save the position value */
		irsCntrctInfo.pos = pos;          
		
		rc = CmnHashLogData(irsHashHandler, &irsCntrctInfo, pos, TRUE, TRUE);
		RAISE_ERR(rc, RTN);
		
		/* Chect irs list common hash  */
		rc = LoadContractListData(&irsCntrctInfo, irsListHashHhl);
		RAISE_ERR(rc, RTN);
	}

    EXIT_BLOCK();
    RETURN_RESCODE;

}


static ResCodeT LoadSirsContractData(int32 connId)
{
    BEGIN_FUNCTION("LoadSirsContractData");
    
    ResCodeT rc = NO_ERR;
	CntrctBaseInfoT irsCntrctInfo;
    BOOL existFlag;
    uint32 pos;
    CntrctBaseInfoT pData;
    CntrctInfoSirs dbData;
    BOOL bFrstFlg = TRUE;    
	
	/* Read the data from DB, and load them into the hash table. */
	while (OK(FetchNextCntrctInfoSirs(&bFrstFlg,connId, &dbData))){

		memset(&irsCntrctInfo, 0x00, sizeof(CntrctBaseInfoT));
	
		// Copy the retun value of fetchNextData into CntrctBaseInfoT
		strcpy(irsCntrctInfo.cntrctName, dbData.cntrctCd);
		irsCntrctInfo.mktId = atoi(dbData.mktTp);      
		irsCntrctInfo.st = atoi(dbData.st);          
		irsCntrctInfo.term = dbData.term;        
		irsCntrctInfo.maxAmntPerDeal = dbData.maxAmntPerDl;
		irsCntrctInfo.minAmntPerDeal = dbData.minAmntPerDl;
		irsCntrctInfo.setId = SET_MKT_SIRS;

		irsCntrctInfo.dealPrcUnit = atoi(dbData.dlPrcUnit); 
		
		strcpy(irsCntrctInfo.cntrctNameEn, dbData.cntrctNmEn);
		strcpy(irsCntrctInfo.cntrctMth, dbData.cntrctMth);
		irsCntrctInfo.cntrctFaceVal = dbData.cntrctFaceVl * pow10(FIGURES_OF_CONTRCT_FACE_VAL);
		strcpy(irsCntrctInfo.dlvryDate, dbData.dlvryDt);
		strcpy(irsCntrctInfo.actvDate, dbData.actvDt);
		strcpy(irsCntrctInfo.exprdDate, dbData.exprdDt);
		strcpy(irsCntrctInfo.trdngEndTm, dbData.trdngEndTm);
		irsCntrctInfo.emgcyFlag = atoi(dbData.emgcyF);
		irsCntrctInfo.settleType = atoi(dbData.stleTp);
		irsCntrctInfo.amntPerUnit = dbData.amntPerUnit * pow10(FIGURES_OF_AMNT_PER_UNIT);
		irsCntrctInfo.bnchmkRate = dbData.bnchmkRate * pow10(FIGURES_OF_BENCHMARK_RATE);
		
		strcpy(irsCntrctInfo.intrstStartDate, dbData.intrstStrtDt);
		strcpy(irsCntrctInfo.intrstEndDate, dbData.intrstEndDt);
		strcpy(irsCntrctInfo.intrstDate, dbData.intrstDt);
		strcpy(irsCntrctInfo.frstIntrstDate, dbData.frstIntrstDt);
		irsCntrctInfo.intrstDaysAdj = atoi(dbData.intrstDaysAdj);
		irsCntrctInfo.pymntDateAdj = atoi(dbData.pymntDtAdj);
		strcpy(irsCntrctInfo.fxdIntrstBidDlvryDate, dbData.fxdIntrstBidDlvryDt);
		irsCntrctInfo.fxdIntrstBidPymntPeriod = atoi(dbData.fxdIntrstBidPymntPrd);
		irsCntrctInfo.fxdIntrstBidIntrstBnchmk = atoi(dbData.fxdIntrstBidIntrstBnchmk);
		irsCntrctInfo.fxdIntrstBidIntrstType = atoi(dbData.fxdIntrstBidIntrstTp);
		strcpy(irsCntrctInfo.refCntrct, dbData.refCntrct);
		strcpy(irsCntrctInfo.fxdIntrstOfrDlvryDay, dbData.fxdIntrstOfrDlvryDay);
		strcpy(irsCntrctInfo.frstIntrstCnfrmDate, dbData.frstIntrstCnfrmDt);
		irsCntrctInfo.intrstType = atoi(dbData.intrstTp);
		irsCntrctInfo.intrstSpread = dbData.intrstSprd * pow10(FIGURES_OF_INTREST_SPREAD);
		irsCntrctInfo.fxdIntrstOfrPymntPeriod = atoi(dbData.fxdIntrstOfrPymntPrd);
		irsCntrctInfo.resetRate = atoi(dbData.rstRate);
		irsCntrctInfo.fxdIntrstOfrIntrstBnchmk = atoi(dbData.fxdIntrstOfrIntrstBnchmk);
	
	
		/* Get the position in the Hashtable that will be used to store the IRS Contract. */
		rc = CmnHashCheckData(irsHashHandler, irsCntrctInfo.cntrctName, &existFlag, &pos, (void*)&pData);
		RAISE_ERR(rc, RTN);

		/* Save the position value */
		irsCntrctInfo.pos = pos;          
		
		rc = CmnHashLogData(irsHashHandler, &irsCntrctInfo, pos, TRUE, TRUE);
		RAISE_ERR(rc, RTN);
		
		/* Chect irs list common hash  */
		rc = LoadContractListData(&irsCntrctInfo, sirsListHashHhl);
		RAISE_ERR(rc, RTN);
	}

    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT LoadSbfCcpContractData(int32 connId)
{
    BEGIN_FUNCTION("LoadSbfCcpContractData");
    
    ResCodeT rc = NO_ERR;
	CntrctBaseInfoT irsCntrctInfo;
    BOOL existFlag;
    uint32 pos;
    CntrctBaseInfoT pData;
    CntrctInfoSbfccp dbData;
    BOOL bFrstFlg = TRUE;    
	
	/* Read the data from DB, and load them into the hash table. */
	while (OK(FetchNextCntrctInfoSbfccp(&bFrstFlg,connId, &dbData))){

		memset(&irsCntrctInfo, 0x00, sizeof(CntrctBaseInfoT));
	
		// Copy the retun value of fetchNextData into CntrctBaseInfoT
		strcpy(irsCntrctInfo.cntrctName, dbData.cntrctCd);
		irsCntrctInfo.mktId = C_MKT_TP_SBFCCP;      
		irsCntrctInfo.st = atoi(dbData.st);          
		irsCntrctInfo.term = dbData.term;        
		irsCntrctInfo.maxAmntPerDeal = dbData.maxAmntPerDl;
		irsCntrctInfo.minAmntPerDeal = dbData.minAmntPerDl;
		irsCntrctInfo.setId = SET_MKT_SBFCCP;

		strcpy(irsCntrctInfo.cntrctNameEn, dbData.cntrctNmEn);
		strcpy(irsCntrctInfo.cntrctMth, dbData.cntrctMth);
		irsCntrctInfo.cntrctFaceVal = dbData.cntrctFaceVl * pow10(FIGURES_OF_CONTRCT_FACE_VAL);
		strcpy(irsCntrctInfo.dlvryDate, dbData.dlvryDt);
		strcpy(irsCntrctInfo.actvDate, dbData.actvDt);
		strcpy(irsCntrctInfo.exprdDate, dbData.exprdDt);
		strcpy(irsCntrctInfo.trdngEndTm, dbData.trdngEndTm);
		irsCntrctInfo.emgcyFlag = atoi(dbData.emgcyF);
		irsCntrctInfo.settleType = atoi(dbData.stleTp);
		irsCntrctInfo.amntPerUnit = dbData.amntPerUnit * pow10(FIGURES_OF_AMNT_PER_UNIT);
		irsCntrctInfo.bnchmkRate = dbData.bnchmkRate * pow10(FIGURES_OF_BENCHMARK_RATE);
		
		irsCntrctInfo.cnvrtRate = dbData.cnvrtRate * pow10(FIGURES_OF_CONVERT_RATE);
		irsCntrctInfo.prcLimit = dbData.prcLmt * pow10(FIGURES_OF_PRICE_LIMIT);
		irsCntrctInfo.chkSt = atoi(dbData.chkSt);
		irsCntrctInfo.cpnRate = dbData.cpnRate * pow10(FIGURES_OF_COUPON_RATE);
        irsCntrctInfo.cntrctUndrlyng = atoi(dbData.cntrctUndrlyng);
	
	
		/* Get the position in the Hashtable that will be used to store the IRS Contract. */
		rc = CmnHashCheckData(irsHashHandler, irsCntrctInfo.cntrctName, &existFlag, &pos, (void*)&pData);
		RAISE_ERR(rc, RTN);

		/* Save the position value */
		irsCntrctInfo.pos = pos;          
		
		rc = CmnHashLogData(irsHashHandler, &irsCntrctInfo, pos, TRUE, TRUE);
		RAISE_ERR(rc, RTN);
		
		/* Chect irs list common hash  */
		rc = LoadContractListData(&irsCntrctInfo, sbfccpListHashHhl);
		RAISE_ERR(rc, RTN);
	}

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT CreateCntrctListShm(char *pShmName, CmnHashHndlT* pCmnHdl, uint32 recCnt)
{
    BEGIN_FUNCTION("CreateCntrctListShm");
    ResCodeT            rc = NO_ERR;
    HashTableRecInfoT   recInfo;
    void                *pShmRoot;
    
    /* Create irs contrct list hash shm */
	recInfo.recSize     = sizeof(CntrctListInfoT);
    recInfo.keyOffset   = offsetof(CntrctListInfoT, cntrctName);
    recInfo.keySize     = CONTRCT_NAME_LENGTH;
    recInfo.bNeedTimeList = TRUE;
    recInfo.recCnt      = recCnt + 10;

    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)pShmName), 
                            recInfo, TRUE, &pShmRoot, pCmnHdl);
    if (NOTOK(rc)){
        THROW_RESCODE(rc);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IrsCntrctInfoIterExt(uint32 * cntrctPos, pCntrctBaseInfoT * ppData)
{
    BEGIN_FUNCTION("IrsCntrctInfoIterExt");
    
    ResCodeT rc = NO_ERR;
    rc = CmnHashIterDataExt(irsHashHandler,cntrctPos,(void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;   
}

ResCodeT CntrctListIterExt(CmnHashHndlT cmnHdl, uint32 *pCntrctPos, pCntrctListInfoT *ppData)
{
    BEGIN_FUNCTION("CntrctInfoIterExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterDataExt(cmnHdl, pCntrctPos, (void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;   
}

ResCodeT IrsCntrctListIter(uint32 *pCntrctPos, pCntrctListInfoT *ppData)
{
    BEGIN_FUNCTION("IrsCntrctListIter");
    
    ResCodeT rc = NO_ERR;
    
    rc = CntrctListIterExt(irsListHashHhl, pCntrctPos, ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;   
}

ResCodeT SirsCntrctListIter(uint32 *pCntrctPos, pCntrctListInfoT *ppData)
{
    BEGIN_FUNCTION("SirsCntrctListIter");
    
    ResCodeT rc = NO_ERR;
    
    rc = CntrctListIterExt(sirsListHashHhl, pCntrctPos, ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;   
}

ResCodeT SbfccpCntrctListIter(uint32 *pCntrctPos, pCntrctListInfoT *ppData)
{
    BEGIN_FUNCTION("SbfccpCntrctListIter");
    
    ResCodeT rc = NO_ERR;
    
    rc = CntrctListIterExt(sbfccpListHashHhl, pCntrctPos, ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;   
}
