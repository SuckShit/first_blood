/***
Created on July 24, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _BASE_PARAM_
#define _BASE_PARAM_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define PARAM_NAME_LENGTH             100
#define PARAM_VALUE_LENGTH            100



#define BASE_PARA_BAT_FLG           "BAT_FLAG"
#define BASE_PARA_INIT_FLG          "INIT_FLAG"
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 基本参数 */
typedef struct BaseParamS
{
    char            paramName[PARAM_NAME_LENGTH];           /* 参数名 */   
    char            paramValue[PARAM_VALUE_LENGTH];         /* 参数值 */
    uint64          pos;                                    /* 在内存Hash结构中的位置 */
} BaseParamT, *pBaseParamT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read data from Table [BASE_PARAM] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT BaseParamLoadFromDB(int32 connId);

/* Search the Base Parameter by specifying the parameter name. */
ResCodeT BaseParamGetByName(char *paramName, pBaseParamT pBaseParam);

/* Search the Base Parameter by specifying the parameter name.
   The return value ppBaseParam is the direct address of base parameter in the Hash shared memory. */
ResCodeT BaseParamGetByNameExt(char *paramName, pBaseParamT *ppBaseParam);

/* Get the Base Parameter by specifying the position in the hash table. */
ResCodeT BaseParamGetByPos(uint64 paramPos, pBaseParamT pBaseParam);

/* Get the Base Parameter by specifying the position in the hash table. 
   The return value ppBaseParam is the direct address of base parameter in the Hash shared memory. */
ResCodeT BaseParamGetByPosExt(uint64 paramPos, pBaseParamT *ppBaseParam);

/* Attach to the shared memory. */
ResCodeT BaseParamAttachToShm();

/* Detach from the shared memory. */
ResCodeT BaseParamDetachFromShm();

#endif /* _BASE_PARAM_ */
