/***
Created on July 18, 2017
@author: Dongwei Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>

/* Project Header File */
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"

#include "base_param.h"
#include "contract_info.h"
#include "credit_info.h"

/* DB Common Header File */
#include "CrdtDb.h"
#include "OrgInfoDb.h"
#include "OrgInfoBrdgDb.h"

#include "org_info.h"
#include "org_onln.h"
#include "pck_irs_dicdata.h"
#include "usr.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define     FAKE_ORG_ID_FOR_CTRL            0
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT orgHashHandler;
static CmnHashHndlT orgBrdgHashHandler;
static BOOL orgHashLoadFlag = FALSE;
static BOOL orgBrdgHashLoadFlag = FALSE;
static CmnHashHndlT orgCdHashHandler;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT OrgInfoLoadFromDB(int32 connId)
{
    BEGIN_FUNCTION("OrgInfoLoadFromDB");
    ResCodeT            rc = NO_ERR;
    HashTableRecInfoT   recInfo;
    int32               dataCount = 0;
    void                *pShmRoot = NULL;
    OrgInfoT            orgInfoData;
    OrgInfoT            data;
    BOOL                existFlag = FALSE;
    uint32              pos;
    OrgInfoJoinT        dbData;
    int32               index = 0;
    BOOL                exeFirstFlag = TRUE;

    HashTableRecInfoT   recInfoOrgCd;
    OrgCdPosInfoT       orgCdPosInfo;
    OrgCdPosInfoT       orgCdPosInfoOut;
    uint32             posOrgCd;
    BOOL                existFlagOrgCd = FALSE;
    BOOL                exeFirstFlagOrgCd = TRUE;

    
    //lidongwei add
/*
    Crdt crdtData;
    vectorT  keyVct[GET_BIT_VECT_LEN(18)] = {0};
    char  strCrtUseNm[50];

    pBaseParamT pParamData;
    pCntrctBaseInfoT pCntrctBaseInfo;
    pRiskCfcntT pRiskCfcnt;

    uint64 iRefCrtAmount;
    uint64 iCrtUseRskCof;
    int32 iCrtUseAmount;
    int32 iCrtLmtNum;
*/  
    //lidongwei end

    // connId is invalid, return error.
    if (connId == DB_INVALID_CONN_ID) {
        // error.
        //RAISE_ERR(rc, RTN);
        RETURN_RESCODE;
    }
    
    /* If the org info load flag is FALSE, creation of the hashtable is necessary. */
    if (orgHashLoadFlag == FALSE) {
        /* First, need to get the count of records in Table [ORG_INFO] */
        rc = GetResultCntOfOrgInfoJoinOrgMktPrvlg(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    
        recInfo.recSize = sizeof(OrgInfoT);
        recInfo.keyOffset = offsetof(OrgInfoT, orgId);
        recInfo.keySize = sizeof(uint64);

        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full. So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_ORG_INFO_NAME), 
                                recInfo, FALSE, &pShmRoot, &orgHashHandler);
        
        if (NOTOK(rc)) {
            THROW_RESCODE(rc);
        }
        
        /* Add hashtable record by orgcode */
        recInfoOrgCd.recSize = sizeof(OrgCdPosInfoT);
        recInfoOrgCd.keyOffset = offsetof(OrgCdPosInfoT, orgCd);
        recInfoOrgCd.keySize = sizeof(char)*ORG_CODE_LENGTH;

        recInfoOrgCd.recCnt = dataCount + 10;
        recInfoOrgCd.bNeedTimeList = FALSE;
 
        rc = CmnHashTblCreate(GetShmNm((char*)SHM_ORGCD_POS_NAME), 
                            recInfo, TRUE, &pShmRoot, &orgCdHashHandler);
        RAISE_ERR(rc, RTN);
        
        
        /* Read the data from DB, and load them into the hash table. */
        memset( &dbData, 0x00 , sizeof(OrgInfoJoinT));
        while (OK(FetchNextOrgInfoJoinOrgMktPrvlg(&exeFirstFlag, connId, &dbData))) {
            memset(&orgInfoData, 0x00, sizeof(OrgInfoT));

            // Copy the retun value of fetchNextData into OrgInfoT
            orgInfoData.orgId = dbData.orgId;
            strcpy(orgInfoData.orgCd, dbData.orgCd);
            strcpy(orgInfoData.orgNmCn, dbData.orgNmCn);
            strcpy(orgInfoData.orgFullNmCn, dbData.orgFullNmCn);
            strcpy(orgInfoData.orgNmEn, dbData.orgNmEn);
            orgInfoData.orgSt = atoi(dbData.orgSt);
            strcpy(orgInfoData.orgType, dbData.orgTp);
            orgInfoData.orgIrsSt = atoi(dbData.orgIrsSt);
            orgInfoData.crdtMthd = atoi(dbData.crdtMthd);
            orgInfoData.crdtUpdMthd = atoi(dbData.crdtUpdMthd);
            orgInfoData.crdtVldOrgFlag = atoi(dbData.crdtVldOrgF);
            orgInfoData.crdtOprtngSt = atoi(dbData.crdtOprtngSt);
            strcpy(orgInfoData.crdtOprtr, dbData.crdtOprtr);
            orgInfoData.brdgOrdrRfrshFlag = atoi(dbData.brdgOrdrRfrshF);

            for (index = 0; dbData.mktTp[index] != NULL; index += 2) {
                switch ((int32)dbData.mktTp[index]-48) {
                    case IRS:
                        orgInfoData.mktTypeSt[0] = (int32)dbData.st[index]-48;
                        break;
                    case SIRS:
                        orgInfoData.mktTypeSt[1] = (int32)dbData.st[index]-48;
                        break;
                    case SBF:
                        orgInfoData.mktTypeSt[2] = (int32)dbData.st[index]-48;
                        break;
                    case SIRSCCP:
                        orgInfoData.mktTypeSt[3] = (int32)dbData.st[index]-48;
                        break;
                    case SBFCCP:
                        orgInfoData.mktTypeSt[4] = (int32)dbData.st[index]-48;
                        break;
                    default:
                        // T.B.D.
                        LOG_INFO("this mktType is not support.");
                        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
                        break;
                }
            }
			
			/* Set the initial value of dfltAcntPos & dfltDpstAcntPos, these values will be set 
               during the loading of acnt_info */
			orgInfoData.dfltAcntPos = -1;
			orgInfoData.dfltDpstAcntSbfPos = -1;

/*
            // Credited Org's Cnt add.
            //按关系授信
            if (C_CREDIT_RL == orgInfoData.crdtMthd) {
                memset(&crdtData, 0x00, sizeof(Crdt));
                memset( keyVct, 0x00, sizeof(vectorT) * GET_BIT_VECT_LEN(18) );
                crdtData.crdtOrgId = orgInfoData.orgId;
                sprintf(crdtData.crdtRlF, "%d", C_CREDIT_RL);

                DbCmmnSetColBit( keyVct, 1 );
                DbCmmnSetColBit( keyVct, 5 );

                rc = GetResultCntOfCrdtByKeyRL(connId, &crdtData, keyVct, &orgInfoData.crdtdOrgCnt);
                RAISE_ERR(rc, RTN);
            }
            //按额度授信
            else if (C_CREDIT_AMT == orgInfoData.crdtMthd) {
                //授信参考合约
                memset(strCrtUseNm, 0x00, sizeof(strCrtUseNm));
                rc = BaseParamGetByNameExt(C_CRT_RFCCNTCT, &pParamData);
                RAISE_ERR(rc, RTN);
                strcpy(strCrtUseNm, pParamData->paramValue);

                //授信参考合约对应的风险系数(RSK_CFCNT)
                rc = IrsRiskCfcntGetByKeyExt(orgInfoData.orgId, strCrtUseNm, &pRiskCfcnt);
                if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
                {
                    LOG_INFO("Can't get Risk info of Org[%lld]", orgInfoData.orgId);
                    rc = NO_ERR;
                }
                RAISE_ERR(rc, RTN);
                
                if ( pRiskCfcnt )
                {
                    iCrtUseRskCof = pRiskCfcnt->rskCfcntVal;
    
                    //授信参考合约对应手数
                    rc = BaseParamGetByNameExt((char*)C_CRT_LMT, &pParamData);
                    RAISE_ERR(rc, RTN);
                    iCrtLmtNum = atoi(pParamData->paramValue);
    
                    //取授信参考
                    //rc = IrsCntrctInfoGetByNameExt(strCrtUseNm, &pCntrctBaseInfo);
                    //RAISE_ERR(rc, RTN);
                    //iCrtUseAmount = pCntrctBaseInfo->dealUnit;
    
                    //参考授信
                    //iRefCrtAmount = iCrtLmtNum * iCrtUseAmount * iCrtUseRskCof;
    
                    memset(&crdtData, 0x00, sizeof(Crdt));
                    memset( keyVct, 0x00, sizeof(vectorT) * GET_BIT_VECT_LEN(18) );
                    crdtData.crdtOrgId = orgInfoData.orgId;
                    //crdtData.rmnCrdtAmnt = iRefCrtAmount;
    
                    DbCmmnSetColBit( keyVct, 1 );
                    DbCmmnSetColBit( keyVct, 7 );
    
                    rc = GetResultCntOfCrdtByKeyAmnt(connId, &crdtData, keyVct, &orgInfoData.crdtdOrgCnt);
                    RAISE_ERR(rc, RTN);
                }
            }
            // Credited Org's Cnt end.
*/
                
            /* Get the position in the Hashtable that will be used to store the org info. */
            rc = CmnHashCheckData(orgHashHandler, &orgInfoData.orgId, &existFlag, &pos, (void*)&data);
            if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
            {
                rc = NO_ERR;
            }
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            orgInfoData.pos = pos;

            orgInfoData.usrListNode.frstPos = -1;
            orgInfoData.usrListNode.lstPos = -1;
           
            rc = CmnHashLogData(orgHashHandler, &orgInfoData, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
            
            memset( &dbData, 0x00 , sizeof(OrgInfoJoinT));
            
            
            memset(&orgCdPosInfo, 0x00, sizeof(OrgCdPosInfoT));
            orgCdPosInfo.orgId      = dbData.orgId;
            strcpy(orgCdPosInfo.orgCd, dbData.orgCd);
            orgCdPosInfo.pos = pos;
    
            /* Get the position in the Hashtable that will be used to store the orgcode. */
            rc = CmnHashCheckData(orgCdHashHandler, orgCdPosInfo.orgCd, &existFlagOrgCd, 
                    &posOrgCd, (void*)&orgCdPosInfoOut);
            if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
            {
                rc = NO_ERR;
            }
            RAISE_ERR(rc, RTN);     

            rc = CmnHashLogData(orgCdHashHandler, &orgCdPosInfo, posOrgCd, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
            
        }
        
        /* Also creating the hashtable which indicates if organization is online. */
        rc = OrgOnlnCreate(dataCount + 10);
        RAISE_ERR(rc, RTN);
    }
    else {
        /* If the org info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }

    orgHashLoadFlag = TRUE;
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    // error operation
    EXIT_BLOCK();
    orgHashLoadFlag = FALSE;
    RETURN_RESCODE;
}

ResCodeT OrgInfoGetById(uint64 orgId, pOrgInfoT pOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    pOrgInfoT pData;
    
    BEGIN_FUNCTION("OrgInfoGetById");
    /* Call OrgInfoGetByIdExt to get the org info. */
    rc = OrgInfoGetByIdExt(orgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pOrgInfo, pData, sizeof(OrgInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgInfoGetByIdExt(uint64 orgId, pOrgInfoT *ppOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    uint64 keyId;
    
    BEGIN_FUNCTION("OrgInfoGetByIdExt");
    /* Check if the org info exists in the hash table. */
    keyId = orgId;
    rc = CmnHashCheckDataExt(orgHashHandler, &keyId, &isExist, &nodePos, (void**)ppOrgInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the org info doesn't exist, throw the error code. */
    if (isExist == FALSE) {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgInfoGetByPos(uint64 orgPos, pOrgInfoT pOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    pOrgInfoT pData;
    
    BEGIN_FUNCTION("OrgInfoGetByPos");
    rc = OrgInfoGetByPosExt(orgPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pOrgInfo, pData, sizeof(OrgInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgInfoGetByPosExt(uint64 orgPos, pOrgInfoT *ppOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION("OrgInfoGetByPosExt");
    rc = CmnHashReadDataAddrByPos(orgHashHandler, orgPos, (void**)ppOrgInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IsAuthorizedInMarket(uint64 orgId, uint32 mktType, BOOL *isEntitled)
{    
    ResCodeT rc = NO_ERR;
    OrgInfoT data;
    
    BEGIN_FUNCTION("IsAuthorizedInMarket");
    memset(&data, 0x00, sizeof(OrgInfoT));
    /* Call OrgInfoGetById to get the org info. */
    rc = OrgInfoGetById(orgId, &data);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    switch (mktType) {
        case IRS:
            *isEntitled = (data.mktTypeSt[0]) ? TRUE:FALSE;
            break;
        case SIRS:
            *isEntitled = (data.mktTypeSt[1]) ? TRUE:FALSE;
            break;
        case SBF:
            *isEntitled = (data.mktTypeSt[2]) ? TRUE:FALSE;
            break;
        case SIRSCCP:
            *isEntitled = (data.mktTypeSt[3]) ? TRUE:FALSE;
            break;
        case SBFCCP:
            *isEntitled = (data.mktTypeSt[4]) ? TRUE:FALSE;
            break;
        default :
            // T.B.D.
            LOG_INFO("this mktType is not support.");
            THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
            break;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OrgInfoAttachToShm(){

    BEGIN_FUNCTION("OrgInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_ORG_INFO_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    orgHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT OrgInfoDetachFromShm()
{    
    ResCodeT rc = NO_ERR;

    BEGIN_FUNCTION("OrgInfoDetachFromShm");
    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_ORG_INFO_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT BrdgOrgInfoLoadFromDB(int32 connId)
{
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount = 0;
    void *pShmRoot = NULL;
    BrdgOrgInfoT brdgOrgInfoData;
    BOOL existFlag = FALSE;
    uint32 pos;
    BrdgOrgInfoT data;
    OrgInfoBrdg dbData;
    BOOL            bFrstFlg = TRUE;
    BEGIN_FUNCTION("BrdgOrgInfoLoadFromDB");
    // connId is invalid, return error.
    if (connId == DB_INVALID_CONN_ID) {
        // error.
        RETURN_RESCODE;
    }
    
    if (sizeof(BrdgOrgCtrlT) > sizeof(BrdgOrgInfoT))
    {
        RAISE_ERR(ERR_OUT_OF_MEMORY, RTN);
    }
    
    /* If the brdg org info load flag is FALSE, creation of the hashtable is necessary. */
    if (orgBrdgHashLoadFlag == FALSE) {    
        /* First, need to get the count of records in Table [ORG_INFO_BRDG] */
        rc = GetResultCntOfOrgInfoBrdg(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    
        recInfo.recSize = sizeof(BrdgOrgInfoT);
        recInfo.keyOffset = offsetof(BrdgOrgInfoT, orgId);
        recInfo.keySize = sizeof(uint32);

        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full. So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_BRIDGE_ORG_INFO_NAME), 
                                recInfo, TRUE, &pShmRoot, &orgBrdgHashHandler); 
        
        if (NOTOK(rc)) {
            THROW_RESCODE(rc);
        }
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK( FetchNextOrgInfoBrdg(&bFrstFlg,connId, &dbData) )) {
            memset(&brdgOrgInfoData, 0x00, sizeof(BrdgOrgInfoT));

            // Copy the retun value of fetchNextData into BrdgOrgInfoT
            brdgOrgInfoData.orgId = dbData.orgId;
            brdgOrgInfoData.brdgOrgSt = atoi(dbData.brdgOrgSt);
            brdgOrgInfoData.brdgOrgOrdr = dbData.brdgOrgOrdr;
            brdgOrgInfoData.brdgIntntnFlag = atoi(dbData.brdgIntntnF);
            brdgOrgInfoData.brdgPrvlgFlag = atoi(dbData.brdgPrvlgF);
            brdgOrgInfoData.brdgPrvlgFlagNext = atoi(dbData.brdgPrvlgFNext);
            brdgOrgInfoData.mdfySt = atoi(dbData.mdfySt);
            strcpy(brdgOrgInfoData.usrLgnNm, dbData.usrLgnNm);
            brdgOrgInfoData.crdtOprtngSt = atoi(dbData.crdtOprtngSt);
            strcpy(brdgOrgInfoData.crdtOprtr, dbData.crdtOprtr);
                
            /* Get the position in the Hashtable that will be used to store the brdg org info. */
            rc = CmnHashCheckData(orgBrdgHashHandler, &brdgOrgInfoData.orgId, &existFlag, &pos, (void*)&data);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            brdgOrgInfoData.pos = pos;
            
            if (existFlag)
            {
                continue;
            }
            
            rc = CmnHashLogData(orgBrdgHashHandler, &brdgOrgInfoData, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
    } 
    else {
        /* If the brdg org info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    
    
    rc = BrdgOrgAddCtrl();
    RAISE_ERR(rc, RTN);
    
    
    orgBrdgHashLoadFlag = TRUE;

    // error operation
    EXIT_BLOCK();
    if (NOTOK(GET_RESCODE()))
    {
        orgBrdgHashLoadFlag = FALSE;
    }
    RETURN_RESCODE;
}



ResCodeT BrdgOrgInfoIterExt(uint32 * pBrdgOrgPos, pBrdgOrgInfoT * ppData)
{

    BEGIN_FUNCTION("IrsCntrctInfoIterExt");
    
    ResCodeT rc = NO_ERR;
    rc = CmnHashIterDataExt(orgBrdgHashHandler,pBrdgOrgPos,(void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT BrdgOrgAddCtrl()
{    
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("BrdgOrgAddCtrl");
    BOOL    existFlag;
    uint32  pos = 0;
    BrdgOrgInfoT brdgOrgInfoData = {0};
    pBrdgOrgInfoT pBrdgOrgInfo = NULL;
    
    pBrdgOrgCtrlT pBrdgOrgCtrl = (pBrdgOrgCtrlT)&brdgOrgInfoData;
    
    pBrdgOrgCtrl->orgId = FAKE_ORG_ID_FOR_CTRL;  
    pBrdgOrgCtrl->brdgOrgCnt = 0 ;
        
    /* Get the position in the Hashtable that will be used to store the brdg org info. */
    rc = CmnHashCheckData(orgBrdgHashHandler, &brdgOrgInfoData.orgId, &existFlag, &pos, (void*)&pBrdgOrgInfo);
    RAISE_ERR(rc, RTN);
    
    rc = CmnHashLogData(orgBrdgHashHandler, &brdgOrgInfoData, pos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT BrdgOrgGetCtrl(pBrdgOrgCtrlT * ppBrdgOrgCtrl)
{    
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("BrdgOrgInfoGetById");
    uint64 ctrlOrgId = FAKE_ORG_ID_FOR_CTRL;
    
    pBrdgOrgInfoT pBrdgOrgInfo = NULL;
    
    rc =  BrdgOrgInfoGetByIdExt(ctrlOrgId,&pBrdgOrgInfo);
    RAISE_ERR(rc, RTN);
    
    * ppBrdgOrgCtrl = (pBrdgOrgCtrlT)pBrdgOrgInfo;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrgInfoGetById(uint64 orgId, pBrdgOrgInfoT pBrdgOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    pBrdgOrgInfoT pData;
    
    BEGIN_FUNCTION("BrdgOrgInfoGetById");
    /* Call BrdgOrgInfoGetByIdExt to get the brdg org info. */
    rc = BrdgOrgInfoGetByIdExt(orgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter */
    memcpy(pBrdgOrgInfo, pData, sizeof(BrdgOrgInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrgInfoGetByIdExt(uint64 orgId, pBrdgOrgInfoT *ppBrdgOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    uint64 keyId;
    
    BEGIN_FUNCTION("BrdgOrgInfoGetByIdExt");
    /* Check if the org info exists in the hash table. */
    keyId = orgId;
    rc = CmnHashCheckDataExt(orgBrdgHashHandler, &keyId, &isExist, &nodePos, (void**)ppBrdgOrgInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the brdg org info doesn't exist, throw the error code. */
    if (isExist == FALSE) {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrgInfoGetByPos(uint64 orgPos, pBrdgOrgInfoT pBrdgOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    pBrdgOrgInfoT pData;
    
    BEGIN_FUNCTION("BrdgOrgInfoGetByPos");
    rc = BrdgOrgInfoGetByPosExt(orgPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter */
    memcpy(pBrdgOrgInfo, pData, sizeof(BrdgOrgInfoT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrgInfoGetByPosExt(uint64 orgPos, pBrdgOrgInfoT *ppBrdgOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION("BrdgOrgInfoGetByPosExt");
    rc = CmnHashReadDataAddrByPos(orgBrdgHashHandler, orgPos, (void**)ppBrdgOrgInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT IsBridgeOrg(uint64 orgId, BOOL *isBrdg)
{    
    ResCodeT rc = NO_ERR;
    pBrdgOrgInfoT pData = NULL;
    
    BEGIN_FUNCTION("IsBridgeOrg");
    /* Call BrdgOrgInfoGetByIdExt to get the brdg org info. */
    rc = BrdgOrgInfoGetByIdExt(orgId, &pData);
    RAISE_ERR(rc, RTN);
    
    if (pData) {
        *isBrdg = TRUE;
    }
    else {
        *isBrdg = FALSE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetNextBridgeOrg(pBrdgOrgInfoT pBrdgOrgInfo)
{    
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION("GetNextBridgeOrg");

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT BrdgOrgInfoAttachToShm(){

    BEGIN_FUNCTION("BrdgOrgInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_BRIDGE_ORG_INFO_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    orgBrdgHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrgInfoDetachFromShm()
{    
    ResCodeT rc = NO_ERR;

    BEGIN_FUNCTION("BrdgOrgInfoDetachFromShm");
    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_BRIDGE_ORG_INFO_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT OnOrgInfoStatus(short orgSt, int16 rqstType, pOrgFreezeStT pOrgFreeze)
{
    BEGIN_FUNCTION("OnOrgIdFreeze");

    if (C_REQUEST_FORBID == rqstType)
    {
        if (C_ORG_ST_ACTIVE == orgSt)
        {
            pOrgFreeze->intOrgSt     = C_ORG_ST_FORBID;
            pOrgFreeze->intOldLgnTp  = C_USER_ROLE_FRONT;
            pOrgFreeze->intNewLgnTp  = C_USER_ROLE_LIMIT_FRONT;
            pOrgFreeze->intOldRoleId = C_USER_ROLE_FRONT;
            pOrgFreeze->intNewRoleId = C_USER_ROLE_LIMIT_FRONT;
        }
        else
        {
            RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
        }
    }
    else if (C_REQUEST_ACTIVE == rqstType)
    {
        if (C_ORG_ST_FORBID == orgSt)
        {
            pOrgFreeze->intOrgSt     = C_ORG_ST_ACTIVE;
            pOrgFreeze->intOldLgnTp  = C_USER_ROLE_LIMIT_FRONT;
            pOrgFreeze->intNewLgnTp  = C_USER_ROLE_FRONT;
            pOrgFreeze->intOldRoleId = C_USER_ROLE_LIMIT_FRONT;
            pOrgFreeze->intNewRoleId = C_USER_ROLE_FRONT;
        }
        else
        {
            RAISE_ERR(ERR_CODE_INVLD_ORG_UNFRD, RTN);
        }
    }
    else
    {
         RAISE_ERR(ERR_CODE_INVLD_ORG_FRZ_REQST, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT UpdateOrgMrkPrvlg(uint64 orgPos, int32 market, int32*  pPrvlg)
{
    BEGIN_FUNCTION("UpdateOrgMrkPrvlg");
    ResCodeT rc = NO_ERR;
    OrgInfoT* pOrg;
    
    rc = OrgInfoGetByPosExt(orgPos, &pOrg);
    RAISE_ERR(rc, RTN);

    if ( pOrg->mktTypeSt[market-1] != pPrvlg[market-1])
    {
        pOrg->mktTypeSt[market-1] = pPrvlg[market-1];
    }

    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT IsOldBridgeOrg(uint64 orgPos, int32* pOldBridge)
{
    BEGIN_FUNCTION("IsOldBridgeOrg");
    ResCodeT rc = NO_ERR;
    OrgInfoT org;
    BrdgOrgInfoT* pBrdgOrg;
    
    rc = OrgInfoGetByPos(orgPos, &org);
    RAISE_ERR(rc, RTN);

    rc = BrdgOrgInfoGetByIdExt(org.orgId,  &pBrdgOrg);    
    if (pBrdgOrg == NULL)
    {
        *pOldBridge = 0;
    }else
    {
        *pOldBridge = pBrdgOrg->brdgOrgSt;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT IsNewBridgeOrg(uint64 orgPos, int32* pNewBridge)
{
    BEGIN_FUNCTION("IsNewBridgeOrg");
    ResCodeT rc = NO_ERR;
    OrgInfoT org;
    BrdgOrgInfoT* pBrdgOrg = NULL;
    BOOL flg = FALSE;
    uint64 tmpPos;
    int i;
    UsrBaseInfoT* pUsr;
        
    *pNewBridge = 0; 
    rc = OrgInfoGetByPos(orgPos, &org);
    RAISE_ERR(rc, RTN);

    rc = BrdgOrgInfoGetByIdExt(org.orgId,  &pBrdgOrg);    
    if (pBrdgOrg != NULL)
    {
        if ((pBrdgOrg->brdgIntntnFlag == 1) &&
            (pBrdgOrg->brdgPrvlgFlag == 1)  &&
            (pBrdgOrg->crdtOprtngSt == 0)   &&
            (strcmp(pBrdgOrg->usrLgnNm, " ") == 0) )            
        {
            //irs market(MKT_TP = 1, ST = 1)
            if (org.mktTypeSt[0] == 1)
            {
                tmpPos = pBrdgOrg->usrMrkPrgListNode.frstPos;
                while (flg == FALSE)
                {
                    rc = IrsUsrInfoGetByPosExt(tmpPos, &pUsr);
                    RAISE_ERR(rc, RTN);
                
                    if (strcmp(pUsr->usrLgnNm, pBrdgOrg->usrLgnNm) == 1)
                    {
                        for(i = 0; i < MARKET_TYPE_STATUS_LENGTH; i++)
                        {
                            if (pUsr->mktTp[i] == 1)
                            {
                                break;
                            }
                        }
                        if ((i < MARKET_TYPE_STATUS_LENGTH) &&  (pUsr->mktSt[i] = 1) )
                        {
                            *pNewBridge = 1; 
                        }
                    }
                    if (tmpPos == pBrdgOrg->usrMrkPrgListNode.lstPos)
                    {
                        flg = TRUE;
                    }
                    tmpPos = pUsr->usrMrkPrgListNode.nxtPos;
                }
            }
        }
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT UpdateOrgBrdg(uint64 orgPos, int32 newBridge)
{
    BEGIN_FUNCTION("UpdateOrgBrdg");
    ResCodeT rc = NO_ERR;
    OrgInfoT org;
    BrdgOrgInfoT* pBrdgOrg = NULL;
    
    rc = OrgInfoGetByPos(orgPos, &org);
    RAISE_ERR(rc, RTN);

    rc = BrdgOrgInfoGetByIdExt(org.orgId,  &pBrdgOrg);  
    if (pBrdgOrg != NULL)
    {
        pBrdgOrg->brdgOrgSt = newBridge;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT OrgIdGetByCode(char *orgCode, OrgCdPosInfoT *ppOrgCd)
{
    BEGIN_FUNCTION("PrdctInfoGetByNameExt");
    
    ResCodeT            rc = NO_ERR;
    BOOL                isExist = FALSE;
    uint32              nodePos;
    char                key[ORG_CODE_LENGTH];
    
    /* Check if the orgcode exists in the hash table. */
    memset(key, 0x00, ORG_CODE_LENGTH);
    strcpy(key, orgCode);
    rc = CmnHashCheckDataExt(orgCdHashHandler, key, &isExist, &nodePos, (void**)ppOrgCd);
    RAISE_ERR(rc, RTN);
    
    /* If the orgcode doesn't exist, throw the error code. */
    if (isExist == FALSE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}
