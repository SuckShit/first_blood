﻿/***
Created on July 18, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>


/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "common_hash.h"
#include "common_macro.h"
#include "db_comm.h"
#include "shm.h"
#include "uti_tool.h"
#include "credit_info.h"
#include "CrdtDb.h"
#include "CrdtBrdgDb.h"
#include "RskCfcntDb.h"
#include "RskCfcntSirsDb.h"
#include "cfg_lib.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT crdtHashHandler;
static CmnHashHndlT crdtBrdgHashHandler;
static CmnHashHndlT rskCfcntHashHandler;
static CmnHashHndlT rskCfcntSirsHashHandler;

static BOOL crdtHashLoadFlag = FALSE;
static BOOL crdtBrdgHashLoadFlag = FALSE;
static BOOL rskCfcntHashLoadFlag = FALSE;
static BOOL rskCfcntSirsHashLoadFlag = FALSE;

static char delimiter[1] = {CREDIT_HASH_KEY_DELIMITER};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static void GenerateCrdtHashKey(uint32 orgId, uint32 partyOrgId, char *pHashKey){

    memcpy(pHashKey, &orgId, sizeof(uint32));
    pHashKey = pHashKey + sizeof(uint32);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    memcpy(pHashKey, &partyOrgId, sizeof(uint32));
}

static void GenerateCrdtBrdgHashKey(uint32 brdgOrgId, uint32 orgId, char *pHashKey){

    memcpy(pHashKey, &brdgOrgId, sizeof(uint32));
    pHashKey = pHashKey + sizeof(uint32);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    memcpy(pHashKey, &orgId, sizeof(uint32));
}

static void GenerateRskCfcntHashKey(uint32 orgId, char *cntrctName, PrimKeyRiskCfcntT* pRiskKey){

    memset(pRiskKey, 0x00, sizeof(PrimKeyRiskCfcntT));
    pRiskKey->orgId = orgId;
    strcpy(pRiskKey->cntrctName, cntrctName);
}

static void GenerateRskCfcntSirsHashKey(uint32 orgId, char *cntrctCode, char *pHashKey){

    memcpy(pHashKey, &orgId, sizeof(uint32));
    pHashKey = pHashKey + sizeof(uint32);
    memcpy(pHashKey, delimiter, sizeof(delimiter));
    pHashKey = pHashKey + sizeof(delimiter);
    strcpy(pHashKey, cntrctCode);
}
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT CreditInfoLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("CreditInfoLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    CreditT crdtInfo;
    BOOL existFlag;
    uint32 pos;
    CreditT pData;
    Crdt dbData;
    BOOL bFrstFlg = TRUE;
    //cfgValueS cfgValue = {0};
    
    /* If the credit info load flag is FALSE, creation of the hashtable is necessary. */
    if (crdtHashLoadFlag == FALSE){    
        // /* Get the DB connection */
        
        //char prcsName[] = "";
        //PrcsInit(prcsName); 
        //
        //rc = GetCfgValue(&cfgValue);
        //EXPECT_EQ(rc,NO_ERR);
        
        // rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        // RAISE_ERR(rc, RTN);
    
        /* First,need to get the count of records in Table [CRDT] */
        rc = GetResultCntOfCrdt(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(CreditT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(CreditT, hashKey);
        recInfo.keySize = CREDIT_HASH_KEY_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_CRDT_NAME), 
                                recInfo, TRUE, &pShmRoot, &crdtHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextCrdt(&bFrstFlg, connId, &dbData))){
    
            memset(&crdtInfo, 0x00, sizeof(CreditT));
            memset(crdtInfo.hashKey, 0x00, CREDIT_HASH_KEY_LENGTH);
            
            // Copy the retun value of fetchNextData into CreditT
            crdtInfo.crdtOrgId = dbData.crdtOrgId;   
            crdtInfo.crdtdOrgId = dbData.crdtdOrgId;  
            crdtInfo.intlCrdtAmnt = dbData.intlCrdtAmnt * pow10(FIGURES_OF_CREDIT_AMOUNT);
            strncpy(crdtInfo.crdtRlFlag, dbData.crdtRlF, 1);  
            crdtInfo.usedCrdtAmnt = dbData.usedCrdtAmnt * pow10(FIGURES_OF_CREDIT_AMOUNT);
            crdtInfo.rmnCrdtAmnt = dbData.rmnCrdtAmnt * pow10(FIGURES_OF_CREDIT_AMOUNT);
            crdtInfo.crdtTerm = dbData.crdtTerm;    
            crdtInfo.st = atoi(dbData.st);          
        
            
            /* Generate the key to be hashed. The key will be created by combining the crdtOrgId and crdtdOrgId */
            GenerateCrdtHashKey(crdtInfo.crdtOrgId, crdtInfo.crdtdOrgId, crdtInfo.hashKey);
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(crdtHashHandler, (void*)crdtInfo.hashKey, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            crdtInfo.pos = pos;          
            
            rc = CmnHashLogData(crdtHashHandler, &crdtInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    crdtHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    crdtHashLoadFlag = FALSE;
    // if (connId != DB_INVALID_CONN_ID){
        // /* When error occurs, if the connection to DB has already been created, call Disconnect to release it. */
        // DbCmmnDisConnect(connId);
    // }
    RETURN_RESCODE;
    
}


ResCodeT CreditInfoGetByKey(uint32 orgId, uint32 partyOrgId, pCreditT pCrdtInfo){

    BEGIN_FUNCTION("CreditInfoGetByKey");
    
    ResCodeT rc = NO_ERR;
    pCreditT pData;
    
    /* Call CreditInfoGetByKeyExt to get the credit info. */
    rc = CreditInfoGetByKeyExt(orgId, partyOrgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pCrdtInfo, pData, sizeof(CreditT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditInfoGetByKeyExt(uint32 orgId, uint32 partyOrgId, pCreditT *ppCrdtInfo){

    BEGIN_FUNCTION("CreditInfoGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[CREDIT_HASH_KEY_LENGTH];
    
    memset(key, 0x00, CREDIT_HASH_KEY_LENGTH);
    /* combine orgId and partyOrgId as the key to be hashed. */
    GenerateCrdtHashKey(orgId, partyOrgId, key);
        

    /* Check if the credit info exists in the hash table. */
    rc = CmnHashCheckDataExt(crdtHashHandler, key, &isExist, &nodePos, (void**)ppCrdtInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the credit info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditInfoGetByPos(uint64 crdtPos, pCreditT pCrdtInfo){

    BEGIN_FUNCTION("CreditInfoGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pCreditT pData;
    
    rc = CreditInfoGetByPosExt(crdtPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pCrdtInfo, pData, sizeof(CreditT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditInfoGetByPosExt(uint64 crdtPos, pCreditT *ppCrdtInfo){

    BEGIN_FUNCTION("CreditInfoGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(crdtHashHandler, crdtPos, (void**)ppCrdtInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

/* Add by hly bg */
ResCodeT CreditInfoUpdateByOrgId(uint32 orgId, uint32 partyOrgId, pCreditT pCrdtInfo){

    BEGIN_FUNCTION("CreditInfoUpdateByOrgId");
    
    ResCodeT rc = NO_ERR;
    pCreditT pCrdtInfoNode;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[CREDIT_HASH_KEY_LENGTH];
    
    memset(key, 0x00, CREDIT_HASH_KEY_LENGTH);
    /* combine orgId and partyOrgId as the key to be hashed. */
    GenerateCrdtHashKey(orgId, partyOrgId, key);

    /* Check if the credit info exists in the hash table. */
    rc = CmnHashCheckDataExt(crdtHashHandler, key, &isExist, &nodePos, (void**)&pCrdtInfoNode);
    RAISE_ERR(rc, RTN);

    /* If the credit info doesn't exist, throw the error code. */
    if ( isExist == FALSE ){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    /* Backup the position value. */
    nodePos = pCrdtInfoNode->pos;
    
    memcpy(pCrdtInfoNode, pCrdtInfo, sizeof(CreditT));
    
    /* Restore the position value. */
    pCrdtInfoNode->pos = nodePos;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CreditInfoUpdateByPos(uint64 creditPos, pCreditT pCrdtInfo){

    BEGIN_FUNCTION("CreditInfoUpdateByPos");
    
    ResCodeT rc = NO_ERR;
    uint32 nodePos;
    pCreditT pData;

    rc = CreditInfoGetByPosExt(creditPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* Backup the position value. */
    nodePos = pData->pos;
    
    memcpy(pData, pCrdtInfo, sizeof(CreditT));
    
    /* Restore the position value. */
    pData->pos = nodePos;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/* Add by hly ed */

ResCodeT CreditInfoAttachToShm(){

    BEGIN_FUNCTION("CreditInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_CRDT_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    crdtHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CreditInfoDetachFromShm(){

    BEGIN_FUNCTION("CreditInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_CRDT_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


/****************************** The implementation of Bridge Credit  ************************************************/
ResCodeT BridgeCreditInfoLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("BridgeCreditInfoLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    CreditBrdgT crdtBrdgInfo;
    BOOL existFlag;
    uint32 pos;
    CreditBrdgT pData;
    CrdtBrdg dbData;
    BOOL bFrstFlg = TRUE;
    //cfgValueS cfgValue = {0};
    
    /* If the bridge credit info load flag is FALSE, creation of the hashtable is necessary. */
    if (crdtBrdgHashLoadFlag == FALSE){    
        // /* Get the DB connection */
        
        //char prcsName[] = "";
        //PrcsInit(prcsName); 
        //
        //rc = GetCfgValue(&cfgValue);
        //EXPECT_EQ(rc,NO_ERR);
        
        // rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        // RAISE_ERR(rc, RTN);
    
        /* First,need to get the count of records in Table [CRDT_BRDG] */
        rc = GetResultCntOfCrdtBrdg(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(CreditBrdgT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(CreditBrdgT, hashKey);
        recInfo.keySize = CREDIT_BRDG_HASH_KEY_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_CRDT_BRDG_NAME), 
                                recInfo, FALSE, &pShmRoot, &crdtBrdgHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextCrdtBrdg(&bFrstFlg, connId, &dbData))){
    
            memset(&crdtBrdgInfo, 0x00, sizeof(CreditBrdgT));
            memset(crdtBrdgInfo.hashKey, 0x00, CREDIT_BRDG_HASH_KEY_LENGTH);

            // Copy the retun value of fetchNextData into CreditT
            crdtBrdgInfo.brdgOrgId = dbData.brdgOrgId;   
            crdtBrdgInfo.orgId = dbData.orgId;  
            crdtBrdgInfo.st = atoi(dbData.st);        
            crdtBrdgInfo.brdgRlFlag = atoi(dbData.brdgRlF);
            crdtBrdgInfo.brdgFee = dbData.brdgFee * pow10(FIGURES_OF_BRDG_FEE)/pow10(4);   
            crdtBrdgInfo.crdtTerm = dbData.crdtTerm;  
            
            /* Generate the key to be hashed. The key will be created by combining the crdtOrgId and crdtdOrgId */
            GenerateCrdtBrdgHashKey(crdtBrdgInfo.brdgOrgId, crdtBrdgInfo.orgId, crdtBrdgInfo.hashKey);
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(crdtBrdgHashHandler, (void*)crdtBrdgInfo.hashKey, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            crdtBrdgInfo.pos = pos;          
            
            rc = CmnHashLogData(crdtBrdgHashHandler, &crdtBrdgInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    crdtBrdgHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    crdtBrdgHashLoadFlag = FALSE;
    // if (connId != DB_INVALID_CONN_ID){
        // /* When error occurs, if the connection to DB has already been created, call Disconnect to release it. */
        // DbCmmnDisConnect(connId);
    // }
    RETURN_RESCODE;
    
}


ResCodeT BridgeCreditInfoGetByKey(uint32 brdgOrgId, uint32 orgId, pCreditBrdgT pBrdgCrdtInfo){

    BEGIN_FUNCTION("BridgeCreditInfoGetByKey");
    
    ResCodeT rc = NO_ERR;
    pCreditBrdgT pData;
    
    /* Call BridgeCreditInfoGetByKeyExt to get the bridge credit info. */
    rc = BridgeCreditInfoGetByKeyExt(brdgOrgId, orgId, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pBrdgCrdtInfo, pData, sizeof(CreditBrdgT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT BridgeCreditInfoGetByKeyExt(uint32 brdgOrgId, uint32 orgId, pCreditBrdgT *ppBrdgCrdtInfo){

    BEGIN_FUNCTION("BridgeCreditInfoGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[CREDIT_BRDG_HASH_KEY_LENGTH];
    
    memset(key, 0x00, CREDIT_BRDG_HASH_KEY_LENGTH);
    /* combine brdgOrgId and orgId as the key to be hashed. */
    GenerateCrdtBrdgHashKey(brdgOrgId, orgId, key);
        

    /* Check if the credit info exists in the hash table. */
    rc = CmnHashCheckDataExt(crdtBrdgHashHandler, key, &isExist, &nodePos, (void**)ppBrdgCrdtInfo);
    RAISE_ERR(rc, RTN);
    
    /* If the credit info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT BridgeCreditInfoGetByPos(uint64 brdgOrgPos, pCreditBrdgT pBrdgCrdtInfo){

    BEGIN_FUNCTION("BridgeCreditInfoGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pCreditBrdgT pData;
    
    rc = BridgeCreditInfoGetByPosExt(brdgOrgPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pBrdgCrdtInfo, pData, sizeof(CreditBrdgT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT BridgeCreditInfoGetByPosExt(uint64 brdgOrgPos, pCreditBrdgT *ppBrdgCrdtInfo){

    BEGIN_FUNCTION("BridgeCreditInfoGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(crdtBrdgHashHandler, brdgOrgPos, (void**)ppBrdgCrdtInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT BridgeCreditInfoAttachToShm(){

    BEGIN_FUNCTION("BridgeCreditInfoAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_CRDT_BRDG_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    crdtBrdgHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT BridgeCreditInfoDetachFromShm(){

    BEGIN_FUNCTION("BridgeCreditInfoDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_CRDT_BRDG_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}





/****************************** The implementation of Risk Coefficient  ************************************************/
ResCodeT IrsRiskCfcntLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("IrsRiskCfcntLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    RiskCfcntT rskCfcntInfo;
    BOOL existFlag;
    uint32 pos;
    RiskCfcntT pData;
    RskCfcnt dbData;
    BOOL bFrstFlg = TRUE;
    //cfgValueS cfgValue = {0};
    
    /* If the bridge credit info load flag is FALSE, creation of the hashtable is necessary. */
    if (rskCfcntHashLoadFlag == FALSE){    
        // /* Get the DB connection */
        
        //char prcsName[] = "";
        //PrcsInit(prcsName); 
        //
        //rc = GetCfgValue(&cfgValue);
        //EXPECT_EQ(rc,NO_ERR);
        
        // rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        // RAISE_ERR(rc, RTN);
    
        /* First,need to get the count of records in Table [CRDT_BRDG] */
        rc = GetResultCntOfRskCfcnt(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(RiskCfcntT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(RiskCfcntT, keyRiskCfcnt);
        recInfo.keySize = sizeof(PrimKeyRiskCfcntT);
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_RISK_COEFFICIENCY_IRS_NAME), 
                                recInfo, FALSE, &pShmRoot, &rskCfcntHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextRskCfcnt(&bFrstFlg, connId, &dbData))){
    
            memset(&rskCfcntInfo, 0x00, sizeof(RiskCfcntT));

            // Copy the retun value of fetchNextData into CreditT
            rskCfcntInfo.keyRiskCfcnt_orgId = dbData.orgId;   
            strcpy(rskCfcntInfo.keyRiskCfcnt_cntrctName, dbData.cntrctNm);
            rskCfcntInfo.rskCfcntVal = dbData.rskCfcntVl * pow10(FIGURES_OF_RISK_COEFFICIENCY_IRS);   
            rskCfcntInfo.st = atoi(dbData.st);        

            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(rskCfcntHashHandler, (void*)(&rskCfcntInfo.keyRiskCfcnt), &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            rskCfcntInfo.pos = pos;          
            
            rc = CmnHashLogData(rskCfcntHashHandler, &rskCfcntInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }  
    } 
    else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    rskCfcntHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    rskCfcntHashLoadFlag = FALSE;
    // if (connId != DB_INVALID_CONN_ID){
        // /* When error occurs, if the connection to DB has already been created, call Disconnect to release it. */
        // DbCmmnDisConnect(connId);
    // }
    RETURN_RESCODE;
    
}


ResCodeT IrsRiskCfcntGetByKey(uint32 orgId, char *cntrctName, pRiskCfcntT pRskCfcnt){

    BEGIN_FUNCTION("IrsRiskCfcntGetByKey");
    
    ResCodeT rc = NO_ERR;
    pRiskCfcntT pData;
    
    /* Call IrsRiskCfcntGetByKeyExt to get the risk coefficient info. */
    rc = IrsRiskCfcntGetByKeyExt(orgId, cntrctName, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRskCfcnt, pData, sizeof(RiskCfcntT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRiskCfcntGetByKeyExt(uint32 orgId, char *cntrctName, pRiskCfcntT *ppRskCfcnt){

    BEGIN_FUNCTION("IrsRiskCfcntGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    PrimKeyRiskCfcntT riskKey;
    uint32 nodePos;

    memset(&riskKey, 0x00, sizeof(PrimKeyRiskCfcntT));

    /* combine orgId and contract name as the key to be hashed. */
    GenerateRskCfcntHashKey(orgId, cntrctName, &riskKey);

    /* Check if the risk coefficient info exists in the hash table. */
    rc = CmnHashCheckDataExt(rskCfcntHashHandler, &riskKey, &isExist, &nodePos, (void**)ppRskCfcnt);
    RAISE_ERR(rc, RTN);
    
    /* If the risk coefficient info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRiskCfcntGetByPos(uint64 rskPos, pRiskCfcntT pRskCfcnt){

    BEGIN_FUNCTION("IrsRiskCfcntGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pRiskCfcntT pData;
    
    rc = IrsRiskCfcntGetByPosExt(rskPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRskCfcnt, pData, sizeof(RiskCfcntT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRiskCfcntGetByPosExt(uint64 rskPos, pRiskCfcntT *ppRskCfcnt){

    BEGIN_FUNCTION("IrsRiskCfcntGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(rskCfcntHashHandler, rskPos, (void**)ppRskCfcnt);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRiskCfcntAttachToShm(){

    BEGIN_FUNCTION("IrsRiskCfcntAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_RISK_COEFFICIENCY_IRS_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    rskCfcntHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT IrsRiskCfcntDetachFromShm(){

    BEGIN_FUNCTION("IrsRiskCfcntDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_RISK_COEFFICIENCY_IRS_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}





/****************************** The implementation of SIRS Risk Coefficient  ************************************************/
ResCodeT SirsRiskCfcntLoadFromDB(int32 connId)
{
    
    BEGIN_FUNCTION("SirsRiskCfcntLoadFromDB");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    int32 dataCount;
    void *pShmRoot;
    RiskCfcntSirsT rskCfcntSirsInfo;
    BOOL existFlag;
    uint32 pos;
    RiskCfcntSirsT pData;
    RskCfcntSirs dbData;
    BOOL    bFrstFlg = TRUE;
    //cfgValueS cfgValue = {0};
    
    /* If the SIRS Risk Coefficient info load flag is FALSE, creation of the hashtable is necessary. */
    if (rskCfcntSirsHashLoadFlag == FALSE){    
        // /* Get the DB connection */
        
        //char prcsName[] = "";
        //PrcsInit(prcsName); 
        //
        //rc = GetCfgValue(&cfgValue);
        //EXPECT_EQ(rc,NO_ERR);
        
        // rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        // RAISE_ERR(rc, RTN);
    
        /* First,need to get the count of records in Table [CRDT_BRDG] */
        rc = GetResultCntOfRskCfcntSirs(connId, &dataCount);
        RAISE_ERR(rc, RTN);
    

    
        recInfo.recSize = sizeof(RiskCfcntSirsT);
        // the key should be combined by two column
        recInfo.keyOffset = offsetof(RiskCfcntSirsT, hashKey);
        recInfo.keySize = RISK_CFCNT_SIRS_HASH_KEY_LENGTH;
        /* If the size of the hashtable to be created is equal to the number of the data extracted from DB,
            when method [CmnHashCheckDataExt] in common_hash is called, it will throw an exception indicating that
            the hash table is full.So to avoid throwing the exception, 10 is added to the dataCount. */
        recInfo.recCnt = dataCount + 10;
        recInfo.bNeedTimeList = TRUE;
 
        rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_RISK_COEFFICIENCY_SIRS_NAME), 
                                recInfo, FALSE, &pShmRoot, &rskCfcntSirsHashHandler);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
        
        /* Read the data from DB, and load them into the hash table. */
        while (OK(FetchNextRskCfcntSirs(&bFrstFlg, connId, &dbData))){
    
            memset(&rskCfcntSirsInfo, 0x00, sizeof(RiskCfcntSirsT));
            memset(rskCfcntSirsInfo.hashKey, 0x00, RISK_CFCNT_SIRS_HASH_KEY_LENGTH);

            // Copy the retun value of fetchNextData into CreditT
            rskCfcntSirsInfo.orgId = dbData.orgId;   
            strcpy(rskCfcntSirsInfo.cntrctCode, dbData.cntrctCd);
            rskCfcntSirsInfo.rskCfcntVal = dbData.rskCfcntVl * pow10(FIGURES_OF_RISK_COEFFICIENCY_SIRS);   
            rskCfcntSirsInfo.st = atoi(dbData.st);        
 
            
            /* Generate the key to be hashed. The key will be created by combining the crdtOrgId and crdtdOrgId */
            GenerateRskCfcntSirsHashKey(rskCfcntSirsInfo.orgId, rskCfcntSirsInfo.cntrctCode, rskCfcntSirsInfo.hashKey);
        
            /* Get the position in the Hashtable that will be used to store the credit info. */
            rc = CmnHashCheckData(rskCfcntSirsHashHandler, (void*)rskCfcntSirsInfo.hashKey, &existFlag, &pos, (void*)&pData);
            RAISE_ERR(rc, RTN);

            /* Save the position value */
            rskCfcntSirsInfo.pos = pos;          
            
            rc = CmnHashLogData(rskCfcntSirsHashHandler, &rskCfcntSirsInfo, pos, TRUE, TRUE);
            RAISE_ERR(rc, RTN);
        }
        
    } else {
        /* If the credit info datas have already been loaded, just exit the function. */
        SET_RESCODE(rc);
        RETURN_RESCODE;
    }
    

    rskCfcntSirsHashLoadFlag = TRUE;
    // rc = DbCmmnDisConnect(connId);
    SET_RESCODE(rc);
    RETURN_RESCODE;
    
    EXIT_BLOCK();
    rskCfcntSirsHashLoadFlag = FALSE;
    // if (connId != DB_INVALID_CONN_ID){
        // /* When error occurs, if the connection to DB has already been created, call Disconnect to release it. */
        // DbCmmnDisConnect(connId);
    // }
    RETURN_RESCODE;
    
}


ResCodeT SirsRiskCfcntGetByKey(uint32 orgId, char *cntrctCode, pRiskCfcntSirsT pRskCfcntSirs){

    BEGIN_FUNCTION("SirsRiskCfcntGetByKey");
    
    ResCodeT rc = NO_ERR;
    pRiskCfcntSirsT pData;
    
    /* Call SirsRiskCfcntGetByKeyExt to get the risk coefficient info. */
    rc = SirsRiskCfcntGetByKeyExt(orgId, cntrctCode, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRskCfcntSirs, pData, sizeof(RiskCfcntSirsT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SirsRiskCfcntGetByKeyExt(uint32 orgId, char *cntrctCode, pRiskCfcntSirsT *ppRskCfcntSirs){

    BEGIN_FUNCTION("SirsRiskCfcntGetByKeyExt");
    
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    char key[RISK_CFCNT_SIRS_HASH_KEY_LENGTH];
    
    memset(key, 0x00, RISK_CFCNT_SIRS_HASH_KEY_LENGTH);
    /* combine orgId and contract name as the key to be hashed. */
    GenerateRskCfcntSirsHashKey(orgId, cntrctCode, key);
        

    /* Check if the SIRS risk coefficient info exists in the hash table. */
    rc = CmnHashCheckDataExt(rskCfcntSirsHashHandler, key, &isExist, &nodePos, (void**)ppRskCfcntSirs);
    RAISE_ERR(rc, RTN);
    
    /* If the risk coefficient info doesn't exist, throw the error code. */
    if (isExist == FALSE){
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SirsRiskCfcntGetByPos(uint64 rskPos, pRiskCfcntSirsT pRskCfcntSirs){

    BEGIN_FUNCTION("SirsRiskCfcntGetByPos");
    
    ResCodeT rc = NO_ERR;
    uint64 nodePos;
    pRiskCfcntSirsT pData;
    
    rc = SirsRiskCfcntGetByPosExt(rskPos, &pData);
    RAISE_ERR(rc, RTN);
    
    /* If there is no error, copy the data into ouput parameter  */
    memcpy(pRskCfcntSirs, pData, sizeof(RiskCfcntSirsT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SirsRiskCfcntGetByPosExt(uint64 rskPos, pRiskCfcntSirsT *ppRskCfcntSirs){

    BEGIN_FUNCTION("SirsRiskCfcntGetByPosExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(rskCfcntSirsHashHandler, rskPos, (void**)ppRskCfcntSirs);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SirsRiskCfcntAttachToShm(){

    BEGIN_FUNCTION("SirsRiskCfcntAttachToShm");
    
    ResCodeT rc = NO_ERR;
    CmnHashHndlT hashHandler;
    void* pShmRoot;

    /* Attach to the shared memory. */
    rc = CmnHashTblAttach(GetShmNm((char*)SHM_RISK_COEFFICIENCY_SIRS_NAME), &pShmRoot, &hashHandler);
    RAISE_ERR(rc, RTN);
    rskCfcntSirsHashHandler = hashHandler;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT SirsRiskCfcntDetachFromShm(){

    BEGIN_FUNCTION("SirsRiskCfcntDetachFromShm");
    
    ResCodeT rc = NO_ERR;

    /* Detach from the shared memory. */
    rc = ShmDetach(GetShmNm((char*)SHM_RISK_COEFFICIENCY_SIRS_NAME));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT CreditInfoIterExt(uint32 * pos, pCreditT *ppData)
{
    BEGIN_FUNCTION("CreditInfoIterExt");
    
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterDataExt(crdtHashHandler, pos, (void **)ppData);
    RAISE_ERR(rc, RTN);                    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
