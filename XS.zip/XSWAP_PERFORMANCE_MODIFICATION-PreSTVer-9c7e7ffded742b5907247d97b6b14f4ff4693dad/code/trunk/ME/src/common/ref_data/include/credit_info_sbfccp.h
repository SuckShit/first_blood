﻿/***
Created on Oct 12, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _CREDIT_SBFCCP_TYPE_
#define _CREDIT_SBFCCP_TYPE_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define FIGURES_OF_CREDIT_SBFCCP_AMOUNT            2         /* SBFCCP授信额度的小数位数 */ 

#define CONTRCT_CODE_SBFCCP_PSTN_LENGTH            50

#define CNTRCT_PSTN_SBFCCP_HASH_KEY_LENGTH         64
#define CREDIT_SBFCCP_HASH_KEY_DELIMITER           '&'

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* 授信额度(SBFCCP) */
typedef struct CreditSbfCcpS
{
    uint32          orgId;                                        /* 授信机构标识 */    
	short           clsPstnFlag;                                  /* 强平模式标志，枚举值：0-否，1-是 */
	short           lmtPstnFlag;                                  /* 限仓模式标志，枚举值：0-否，1-是 */
    short           st;                                           /* 授信状态 0-禁用；1-启用  */  
	int64           intlAmnt;                                     /* 初始额度（元） */
	int64           bidIntlAmnt;                                  /* 买方_初始额度（元） */
	int64           bidUsedAmnt;                                  /* 买方_已使用额度（元） */
	int64           bidHoldAmnt;                                  /* 买方_暂扣额度（元） */
	int64           bidRmnAmnt;                                   /* 买方_剩余额度（元） */
	int64           ofrIntlAmnt;                                  /* 卖方_初始额度（元） */
	int64           ofrUsedAmnt;                                  /* 卖方_已使用额度（元） */
	int64           ofrHoldAmnt;                                  /* 卖方_暂扣额度（元） */
	int64           ofrRmnAmnt;                                   /* 卖方_剩余额度（元） */
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} CreditSbfCcpT, *pCreditSbfCcpT;


/* 合约头寸(SBFCCP) */
typedef struct CntrctPstnSbfCcpS
{
    char            hashKey[CNTRCT_PSTN_SBFCCP_HASH_KEY_LENGTH];  /* SBFCCP合约头寸信息的HashKey,由 机构ID+合约代码 组成 */
    uint32          orgId;                                        /* 机构ID */
    char            cntrctCd[CONTRCT_CODE_SBFCCP_PSTN_LENGTH];    /* 合约代码 */
    int64           netPstn;                                      /* 净头寸 */
    int64           bidHoldAmnt;                                  /* 买方_暂扣额度（元） */
    int64           ofrHoldAmnt;                                  /* 卖方_暂扣额度（元） */
    uint64          pos;                                          /* 在内存Hash结构中的位置 */
} CntrctPstnSbfCcpT, *pCntrctPstnSbfCcpT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/* Read data from Table [CRDT_SBFCCP] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT CreditSbfCcpInfoLoadFromDB(int32 connId);

/* Get sbfccp credit info by specifying org id. */
ResCodeT CreditSbfCcpInfoGetByKey(uint32 orgId, pCreditSbfCcpT pCrdtInfo);

/* Get sbfccp credit info by specifying org id.
   The return value ppCrdtInfo is the direct address of credit info in the Hash shared memory. */
ResCodeT CreditSbfCcpInfoGetByKeyExt(uint32 orgId, pCreditSbfCcpT *ppCrdtInfo);

/* Get sbfccp credit info by specifying the position in the hash table. */
ResCodeT CreditSbfCcpInfoGetByPos(uint64 crdtPos, pCreditSbfCcpT pCrdtInfo);

/* Get sbfccp credit info by specifying the position in the hash table.
   The return value ppCrdtInfo is the direct address of credit info in the Hash shared memory. */
ResCodeT CreditSbfCcpInfoGetByPosExt(uint64 crdtPos, pCreditSbfCcpT *ppCrdtInfo);

/* Attach to the shared memory. */
ResCodeT CreditSbfCcpInfoAttachToShm();

/* Detach from the shared memory. */
ResCodeT CreditSbfCcpInfoDetachFromShm();




/* Read data from Table [CNTRCT_PSTN_SBFCCP] and load these data into shared memory. 
   Call this method before calling other methods. Or call this method to 
   reload data from DB. */
ResCodeT CntrctPstnSbfCcpLoadFromDB(int32 connId);

/* Get sbfccp contract position info by specifying org id and contract code. */
ResCodeT CntrctPstnSbfCcpGetByKey(uint32 orgId, char* cntrctCode, pCntrctPstnSbfCcpT pCntrctPstnInfo);

/* Get sbfccp contract position info by specifying org id and contract code.
   The return value ppCntrctPstnInfo is the direct address of contract position info in the Hash shared memory. */
ResCodeT CntrctPstnSbfCcpGetByKeyExt(uint32 orgId, char* cntrctCode, pCntrctPstnSbfCcpT *ppCntrctPstnInfo);

/* Get sbfccp contract position info by specifying the position in the hash table. */
ResCodeT CntrctPstnSbfCcpGetByPos(uint32 pstnPos, pCntrctPstnSbfCcpT pCntrctPstnInfo);

/* Get sbfccp contract position info by specifying the position in the hash table.
   The return value ppCntrctPstnInfo is the direct address of contract position info in the Hash shared memory. */
ResCodeT CntrctPstnSbfCcpGetByPosExt(uint32 pstnPos, pCntrctPstnSbfCcpT *ppCntrctPstnInfo);

/* for iterate use. */
ResCodeT CntrctPstnSbfCcpIterExt(uint32 * pstnPos, pCntrctPstnSbfCcpT *ppData);

/* Attach to the shared memory. */
ResCodeT CntrctPstnSbfCcpAttachToShm();

/* Detach from the shared memory. */
ResCodeT CntrctPstnSbfCcpDetachFromShm();


#endif /* _CREDIT_SBFCCP_TYPE_ */
