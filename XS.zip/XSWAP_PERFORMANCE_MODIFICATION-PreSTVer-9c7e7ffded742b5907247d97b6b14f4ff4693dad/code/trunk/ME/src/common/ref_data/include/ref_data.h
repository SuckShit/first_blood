/***
Created on July 25, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _REF_DATA_
#define _REF_DATA_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/* Read all the reference data from Tables and load these data into shared memory respectively. 
   Call this method before referring to any data in shared memory. */
ResCodeT RefDataLoadFromDB();

/* Detach all the reference data from the shared memory. */
ResCodeT RefDataDetachFromShm();


#endif /* _REF_DATA_ */
