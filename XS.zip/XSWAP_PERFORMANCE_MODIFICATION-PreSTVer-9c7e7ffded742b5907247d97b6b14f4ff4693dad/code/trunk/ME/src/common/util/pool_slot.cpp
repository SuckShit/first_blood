/***
Created on May 08, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "../include/err_lib.h"
#include "../include/pool_slot.h"
#include "../include/common_macro.h"

/*****************************************************************************
 **
 **  Marco
 **
 *****************************************************************************/
#ifndef THROW_RESCODE_ON_COND
#define THROW_RESCODE_ON_COND(errCode, cond)\
    if (cond)\
    {\
        THROW_RESCODE(errCode); \
    }
#endif
/*****************************************************************************
 **
 **  Function Implementation
 **
 *****************************************************************************/
ResCodeT InitPoolSlot(pPoolSlotT poolSlot,
                        const int32 poolSize)
{
    BEGIN_FUNCTION("InitPoolSlot");
    
    void *ptr = NULL;
    
    THROW_RESCODE_ON_COND(ERR_OBK_NULL_POINTER, !poolSlot);
    
    ASSERT(poolSlot);

    poolSlot->poolSize = poolSize;
    
    MALLOC(ptr, (poolSize + 1) * sizeof (int32) * 2);

    if (!ptr)
    {
        RAISE_ERR(ERR_OUT_OF_MEMORY, RTN);
    }

    poolSlot->inBuffer = (int32*)ptr;
    poolSlot->outBuffer = (int32*)((int64)ptr + sizeof (int32) * (poolSize + 1));
    poolSlot->inBuffer[0] = -1;
    poolSlot->inBufIndex = poolSlot->inBuffer;
    poolSlot->outBuffer[poolSize] = -1;
    poolSlot->outBufIndex = poolSlot->outBuffer;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT RequestPoolSlot(pPoolSlotT poolSlot,
                        int32 *slotNo)
{
    BEGIN_FUNCTION("RequestPoolSlot");
    ASSERT(poolSlot);

    /* check input parameter */
    if (-1 == *poolSlot->inBufIndex)
    {
        /* all slots have been used! */
        return ERR_OBK_NOT_ENOUGH_BUFFER;
    }
    *slotNo = *poolSlot->inBufIndex;
    poolSlot->inBufIndex--;

    EXIT_BLOCK();
    return NO_ERR;
}

ResCodeT FreePoolSlot(pPoolSlotT poolSlot,
                        const int32 slotNo)
{
    BEGIN_FUNCTION("FreePoolSlot");
    ASSERT(poolSlot);

    if (-1 == *poolSlot->outBufIndex)
    {
        return ERR_OBK_NOT_ENOUGH_BUFFER;
    }
    *poolSlot->outBufIndex = slotNo;
    poolSlot->outBufIndex++;

    EXIT_BLOCK();
    return NO_ERR;
}

ResCodeT AllocPoolSlot(pPoolSlotT poolSlot,
                const int32 slotNo)
{
    BEGIN_FUNCTION("AllocPoolSlot");
    ASSERT(poolSlot);

    if ((poolSlot->inBufIndex + 1) == poolSlot->outBuffer)
    {
        return ERR_OBK_NOT_ENOUGH_BUFFER;
    }
    poolSlot->inBufIndex++;
    *poolSlot->inBufIndex = slotNo;

    EXIT_BLOCK();
    return NO_ERR;
}

ResCodeT DeallocPoolSlot(pPoolSlotT poolSlot,
                int32 *slotNo)
{
    BEGIN_FUNCTION("DeallocPoolSlot");
    ASSERT(poolSlot);

    if (poolSlot->outBufIndex == poolSlot->outBuffer)
    {
        return ERR_OBK_NOT_ENOUGH_BUFFER;
    }
    poolSlot->outBufIndex--;
    *slotNo = *poolSlot->outBufIndex;

    EXIT_BLOCK();
    return NO_ERR;
}
