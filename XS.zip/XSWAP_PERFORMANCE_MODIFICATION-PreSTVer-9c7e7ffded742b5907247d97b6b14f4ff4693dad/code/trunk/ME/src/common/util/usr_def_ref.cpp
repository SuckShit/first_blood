﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "data_type.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "mem_txn.h"
#include "common_macro.h"
#include "mem_txn_elem.h"
#include "cfg_lib.h"
#include "usr_def_ref.h"
#include "api_common.h"

#include "usr.h"
#include "trade.h"
#include "trade_mgmt.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "internal_base_def.h"
#include "../../app/HPMTS/service/credit_position_sbfccp.h"

// database
#include "db_comm.h"
#include "OrgInfoDb.h"
#include "CrdtDb.h"
#include "CrdtDlAmntDb.h"
#include "OrgInfoBrdgDb.h"
#include "BaseParamDb.h"
#include "MktStCfgDb.h"
#include "CrdtBrdgDb.h"
#include "RskCfcntDb.h"
#include "QtSbscrptnApiDb.h"
#include "CrdtSbfccpDb.h"
#include "CntrctPstnSbfccpDb.h"
#include "RskCfcntSirsDb.h"
#include "CntrctRefPrcSirsDb.h"
#include "CntrctRefPrcSbfccpDb.h"
#include "CntrctRefPrcHstrySirsDb.h"
#include "CntrctRefPrcHstrySbfccpDb.h"
#include "DlDb.h"

// share_memory
#include "org_info.h"
#include "credit_info.h"
#include "credit_common.h"
#include "base_param.h"
#include "mkt_st_cfg.h"
#include "credit_info_sbfccp.h"

#include "internal_base_def.h"
#include "pck_irs_dicdata.h"
#include "usr_def_ref.h"
#include "org_onln.h"
#include "prdct_info.h"
#include "usr_onln.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* Share memory control section */

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/******* CreditModify *******/
/*Main Function*/
ResCodeT CrdtModifyMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT CrdtModifyDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT CrdtModifyPrintCallback(void *pData, int32 dataLen);
/*DataBase Update*/
ResCodeT UpdateOrgInfoDbForCrtOperating(int32 connId, CreditUpdateDataT* pData);
/*ShareMemory Update*/
ResCodeT UpdateShareMemoryOfOrgInfoForCrdtModify(CreditUpdateDataT* pData);

/******* CreditUpdate *******/
/*Main Function*/
ResCodeT CrdtUpdateMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT CrdtUpdateDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT CrdtUpdatePrintCallback(void *pData, int32 dataLen);

/*DataBase Update*/
ResCodeT UpdateOrgInfoForCrdtMthd(int32 connId, CreditUpdateDataT* pData);
ResCodeT UpdateCrdtInfoForAmnt(int32 connId, CreditUpdateDataT* pData);
ResCodeT UpdateOrgInfoForUpdateUnlock(int32 connId, CreditUpdateDataT* pData);
/*ShareMemory Update*/
ResCodeT UpdateOrgInfoShareMemoryForCrdtMthd(CreditUpdateDataT* pData);
ResCodeT UpdateCrdtShareMemoryForAmnt(CreditUpdateDataT* pData);
ResCodeT UpdateOrgInfoShareMemoryForCrdtUpdateUnlock(CreditUpdateDataT* pData);

/******* CreditUnlock *******/
/*Main Function*/
ResCodeT CrdtUnlockMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT CrdtUnlockDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT CrdtUnlockPrintCallback(void *pData, int32 dataLen);
/*DataBase Update*/
ResCodeT UpdateOrgInfoDbForCrdtUnlock(int32 connId, CreditUpdateDataT* pData);
/*ShareMemory Update*/
ResCodeT UpdateOrgInfoShareMemoryForCrdtUnlock(CreditUpdateDataT* pData);
/*ShareMemory Update*/
ResCodeT UpdateRskCfCntShareMemoryForRskCof(RiskUpdateDataT* pData);

/******* CreditRefreshMethodUpdate *******/
/*Main Function*/
ResCodeT CrdtRefMthdUpdMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT CrdtRefMthdUpdDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT CrdtRefMthdUpdPrintCallback(void *pData, int32 dataLen);
/*DataBase Update*/
ResCodeT UpdateOrgInfoDbForUpdMthd(int32 connId, CreditUpdateDataT* pData);
/*ShareMemory Update*/
ResCodeT UpdateOrgInfoShareMemoryForCrdtUpdMthd(CreditUpdateDataT* pData);

ResCodeT RiskUpdateMem(RiskUpdateDataT* pData);
ResCodeT RiskUpdateDb(int32 connId, RiskUpdateDataT* pData);
ResCodeT RiskUpdatePrint(void *pData, int32 dataLen);

ResCodeT BrdgOrgMemUnlockByOprtr(char* newOprtrId, char* oldOprtrId);

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** InsertUserLoginHistory
 **
 ******************************************************************************/
ResCodeT InsertUserLoginHistory(int32 connId, UsrLgnHstry* pUserLoginHistory)
{
    BEGIN_FUNCTION( "UpdateUserLoginHistory" );
    ResCodeT rc = NO_ERR;

    rc = InsertUsrLgnHstry(connId, pUserLoginHistory);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** InsertUserOnline
 **
 ******************************************************************************/
ResCodeT InsertUserOnline(int32 connId, UsrOnln* pData)
{
    BEGIN_FUNCTION( "InsertUserOnline" );
    ResCodeT rc = NO_ERR;

    rc = InsertUsrOnln(connId, pData);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DeleteUserOnline
 **
 ******************************************************************************/
ResCodeT DeleteUserOnline(int32 connId, char* pData)
{
    BEGIN_FUNCTION( "DeleteUserOnline" );
    ResCodeT rc = NO_ERR;

    UsrOnlnKey key;
    memset(&key, 0, sizeof(key));

    strcpy(key.usrNm, pData);

    rc = DeleteUsrOnln(connId, &key);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateUserOnline
 **
 ******************************************************************************/
ResCodeT UpdateUserOnline(int32 connId, UsrOnln* pData)
{
    BEGIN_FUNCTION( "UpdateUserOnline" );
    ResCodeT rc = NO_ERR;


    vectorT  keyVec[GET_BIT_VECT_LEN(6)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(6)] = {0};

    DbCmmnSetColBit(keyVec, 0);
    DbCmmnSetColBit(datVec, 1);
    DbCmmnSetColBit(datVec, 2);
    DbCmmnSetColBit(datVec, 3);

    rc = UpdateUsrOnlnByKey(connId, pData, keyVec, datVec);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoBrdg
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoBrdg(
            int32               connId,
            UserMemDataRefT*    pRefData
            )
{
    BEGIN_FUNCTION( "UpdateOrgInfoBrdg" );
    ResCodeT rc = NO_ERR;

    OrgInfoBrdg keyData;
    OrgInfoBrdg valData;
    vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};

    memset(&keyData, 0, sizeof(OrgInfoBrdg));
    memset(&valData, 0, sizeof(OrgInfoBrdg));
    strcpy(keyData.crdtOprtr, pRefData->strUserName);
    itoa(C_CRT_NONE, valData.crdtOprtngSt, 10);
    strcpy(valData.crdtOprtr, pRefData->strCWUsrNm);
    strcpy(valData.updTm, pRefData->oprtTm);
    strcpy(valData.updUsrNm, pRefData->strCWUsrNm);

    DbCmmnSetColBit( keyVct, 14 );
    DbCmmnSetColBit( datVct, 13 );
    DbCmmnSetColBit( datVct, 14 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoBrdgByKeyRpt( connId, &keyData, &valData, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateApiUserOnline
 **
 ******************************************************************************/
ResCodeT UpdateApiUserOnline(int32 connId, UsrOnln* pData)
{
    BEGIN_FUNCTION( "UpdateApiUserOnline" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVec[GET_BIT_VECT_LEN(6)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(6)] = {0};

    DbCmmnSetColBit(keyVec, 0);
    DbCmmnSetColBit(datVec, 1);
    DbCmmnSetColBit(datVec, 3);

    rc = UpdateUsrOnlnByKey(connId, pData, keyVec, datVec);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(connId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ClearAllOnlnApiStatus
 **
 ******************************************************************************/
ResCodeT ClearAllOnlnApiStatus(int32 connId)
{
    BEGIN_FUNCTION( "ClearAllOnlnApiStatus" );
    ResCodeT rc = NO_ERR;

    BOOL    bFrstFlg = TRUE;
    int32   iApiCnt;
    char    apiF[MAX_APIF_LENTH];
    memset(apiF, 0, sizeof(apiF));
    itoa(C_API_USRFLAG, apiF, 10);
    rc = GetCntByApiF(connId, apiF, &iApiCnt);
    RAISE_ERR(rc, RTN);

    if (iApiCnt > 0)
    {
        int32   iApiF;
        UsrOnln dbData;
        memset(&dbData, 0, sizeof(UsrOnln));
        /* Read the data from DB, and load them into the shared memory. */
        while (OK(FetchNextUsrOnln(&bFrstFlg, connId, &dbData)))
        {
            iApiF = atoi(dbData.apiF);
            if (iApiF == C_API_USRFLAG)
            {
                pUsrBaseInfoT pUserInfo;
                rc = IrsUsrInfoGetByNameExt(dbData.usrNm, &pUserInfo);
                RAISE_ERR(rc, RTN);

                if (TRUE == pUserInfo->usrOnlnStatus)
                {
                    rc = UsrOnlnDeleteByName(dbData.usrNm);
                    RAISE_ERR(rc, RTN);
                }

                pUserInfo->usrOnlnStatus = FALSE;

                memset(&dbData, 0, sizeof(UsrOnln));
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateUsrDb
 **
 ******************************************************************************/
ResCodeT UpdateUsrDb(
            int32               connId,
            char*               strUser,
            char*               strCWUsr,
            int32               iUserState,
            char*               strUpdateTime
            )
{
    BEGIN_FUNCTION( "UpdateUsrDb" );
    ResCodeT rc = NO_ERR;

    Usr data;
    vectorT  keyVct[GET_BIT_VECT_LEN(22)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(22)] = {0};

    memset(&data, 0, sizeof(Usr));
    strcpy(data.usrLgnNm, strUser);
    itoa(iUserState, data.usrSt, 10);
    strcpy(data.updTm, strUpdateTime);
    strcpy(data.updUsrNm, strCWUsr);

    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );

    rc = UpdateUsrByKey( connId, &data, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateSubscribe
 **
 ******************************************************************************/
ResCodeT UpdateSubscribe(
            int32               connId,
            QtSbscrptnApi*      pData
            )
{
    BEGIN_FUNCTION( "UpdateSubscribe" );
    ResCodeT rc = NO_ERR;

    QtSbscrptnApi data;
    vectorT  keyVct[GET_BIT_VECT_LEN(12)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(12)] = {0};

    memset(&data, 0, sizeof(QtSbscrptnApi));

    strcpy(data.usrLgnNm, pData->usrLgnNm);
    strcpy(data.mktTp, pData->mktTp);
    strcpy(data.cntrctCd, pData->cntrctCd);
    strcpy(data.qtTp, pData->qtTp);
    strcpy(data.lvl, pData->lvl);
    strcpy(data.instrctnSendTm, pData->instrctnSendTm);
    strcpy(data.rqstId, pData->rqstId);

    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( keyVct, 4 );
    DbCmmnSetColBit( keyVct, 7 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 8 );
    DbCmmnSetColBit( datVct, 9 );

    rc = UpdateQtSbscrptnApiByKey( connId, &data, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DeserializeUsrRefData
 **
 ******************************************************************************/
ResCodeT DeserializeUsrRefData(
                UserMemDataRefT* pRefData,
                UsrOnln* pUsrOnln,
                UsrLgnHstry* pUsrHstry,
                CreditUpdateDataT* pCrdt
                )
{
    BEGIN_FUNCTION( "DeserializeUsrRefData" );
    ResCodeT rc = NO_ERR;

    memset(pUsrOnln, 0, sizeof(UsrOnln));
    memset(pUsrHstry, 0, sizeof(UsrLgnHstry));

    strcpy(pUsrOnln->usrNm, pRefData->strUserName);
    strcpy(pUsrOnln->sesnId, pRefData->sesnId);
    pUsrOnln->lgnTp = pRefData->lgnTp;
    strcpy(pUsrOnln->lgnTm, pRefData->oprtTm);
    strcpy(pUsrOnln->lgnIp, pRefData->lgnIp);
    strcpy(pUsrOnln->apiF, pRefData->apiF);

    strcpy(pUsrHstry->usrNm, pRefData->strUserName);
    strcpy(pUsrHstry->oprtTp, pRefData->oprtTp);
    strcpy(pUsrHstry->lgnIp, pRefData->lgnIp);
    strcpy(pUsrHstry->oprtTm, pRefData->oprtTm);

    pCrdt->intOrgId = pRefData->intOrgId;
    strcpy(pCrdt->strUserId, pRefData->strUserName);
    strcpy(pCrdt->strUpdTm, pRefData->oprtTm);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UserMemRef
 **     for ref_dat_updt
 **
 ******************************************************************************/
ResCodeT UserMemRef(void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UserMemRef" );
    ResCodeT rc = NO_ERR;

    UserMemDataRefT* pRefData = (UserMemDataRefT*)pData;

    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pRefData->strUserName, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }

    UsrOnln userData;
    UsrLgnHstry sHistory;
    CreditUpdateDataT sCrdt;

    rc = DeserializeUsrRefData(pRefData, &userData, &sHistory, &sCrdt);
    RAISE_ERR(rc, RTN);

    switch (pRefData->eMessageType)
    {
    case MSG_TYPE_USER_LOGIN:
    case MSG_TYPE_API_LOGIN:
        pUserInfo->usrOnlnStatus = TRUE;
        pUserInfo->lgnTp = pRefData->lgnTp;
        strcpy(pUserInfo->sesnId, pRefData->sesnId);
        strcpy(pUserInfo->lgnTm, pRefData->oprtTm);

        rc = UsrOnlnAddByName(pUserInfo);
        RAISE_ERR(rc, RTN);

        rc = OrgOnlnAddById(pUserInfo->orgId);
        RAISE_ERR(rc, RTN);
        break;

    case MSG_TYPE_USER_LOGOUT:
    case MSG_TYPE_API_LOGOUT:
        if (TRUE == pUserInfo->usrOnlnStatus)
        {
            rc = UsrOnlnDeleteByName(pRefData->strUserName);
            RAISE_ERR(rc, RTN);
        }

        pUserInfo->usrOnlnStatus = FALSE;

        rc = OrgOnlnDeleteById(pUserInfo->orgId);
        RAISE_ERR(rc, RTN);
        break;

    case MSG_TYPE_REMOVE_ONLINE_USER:
        if (TRUE == pUserInfo->usrOnlnStatus)
        {
            rc = UsrOnlnDeleteByName(pRefData->strUserName);
            RAISE_ERR(rc, RTN);
        }

        pUserInfo->usrOnlnStatus = FALSE;

        rc = UpdateOrgInfoShareMemoryForCrdtUnlock(&sCrdt);
        RAISE_ERR(rc, RTN);

        rc = BrdgOrgMemUnlockByOprtr(pRefData->strCWUsrNm, pRefData->strUserName);
        RAISE_ERR(rc, RTN);

        break;

    case MSG_TYPE_API_USER_REMOVE:
        if (strcmp(pRefData->strUserName, "") != 0)
        {
            if (TRUE == pUserInfo->usrOnlnStatus)
            {
                rc = UsrOnlnDeleteByName(pRefData->strUserName);
                RAISE_ERR(rc, RTN);
            }

            pUserInfo->usrOnlnStatus = FALSE;

            // 获取用户类型，每个API用户仅对应一种权限
            int32       iUserRole;
            rc = CheckApiUserRole(pUserInfo->roleId, iUserRole);
            RAISE_ERR(rc, RTN);

            if (C_APIUSER_ROLE_CRDT == iUserRole)
            {
                rc = UpdateOrgInfoShareMemoryForCrdtUnlock(&sCrdt);
                RAISE_ERR(rc, RTN);
            }
        }
        break;

    case MSG_TYPE_API_USER_FREEZE:
        int32 usrSt;
        usrSt = atoi(pUserInfo->usrSt);
        if (usrSt == C_USR_ST_ACTIVE)
        {
            itoa(C_USR_ST_LOCK, pUserInfo->usrSt, 10);

            if (TRUE == pUserInfo->usrOnlnStatus)
            {
                rc = UsrOnlnDeleteByName(pRefData->strUserName);
                RAISE_ERR(rc, RTN);
            }

            pUserInfo->usrOnlnStatus = FALSE;
        }
        else if (usrSt == C_USR_ST_LOCK)
        {
            itoa(C_USR_ST_ACTIVE, pUserInfo->usrSt, 10);
        }
        break;

    default:
        break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UserDbtRef(int32 connId, void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UserDbtRef" );
    ResCodeT rc = NO_ERR;

    UserMemDataRefT* pRefData = (UserMemDataRefT*)pData;

    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pRefData->strUserName, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }

    UsrOnln userData;
    UsrLgnHstry sHistory;
    CreditUpdateDataT sCrdt;

    rc = DeserializeUsrRefData(pRefData, &userData, &sHistory, &sCrdt);
    RAISE_ERR(rc, RTN);

    switch (pRefData->eMessageType)
    {
    case MSG_TYPE_USER_LOGIN:
        if (TRUE == pUserInfo->usrOnlnStatus)
        {
            rc = UpdateUserOnline(connId, &userData);
        }
        else
        {
            rc = InsertUserOnline(connId, &userData);
        }
        RAISE_ERR(rc, RTN);

        rc = InsertUserLoginHistory(connId, &sHistory);
        RAISE_ERR(rc, RTN);

        break;

    case MSG_TYPE_USER_LOGOUT:
        rc = DeleteUserOnline(connId, pRefData->strUserName);
        RAISE_ERR(rc, RTN);

        rc = InsertUserLoginHistory(connId, &sHistory);
        RAISE_ERR(rc, RTN);

        break;

    case MSG_TYPE_REMOVE_ONLINE_USER:
        if (pUserInfo->usrOnlnStatus)
        {
            rc = DeleteUserOnline(connId, pRefData->strUserName);
            RAISE_ERR(rc, RTN);

            rc = InsertUserLoginHistory(connId, &sHistory);
            RAISE_ERR(rc, RTN);
        }

        rc = UpdateOrgInfoDbForCrdtUnlock(connId, &sCrdt);
        RAISE_ERR(rc, RTN);

        rc = UpdateOrgInfoBrdg(connId, pRefData);
        RAISE_ERR(rc, RTN);

        break;

    case MSG_TYPE_API_LOGIN:
        if (!pUserInfo->usrOnlnStatus)
        {
            rc = InsertUserOnline(connId, &userData);
            RAISE_ERR(rc, RTN);
        }
        else
        {
            rc = UpdateApiUserOnline(connId, &userData);
            RAISE_ERR(rc, RTN);

            rc = InsertUserLoginHistory(connId, &sHistory);
            RAISE_ERR(rc, RTN);

            // 获取用户类型，每个API用户仅对应一种权限
            int32       iUserRole;
            rc = CheckApiUserRole(pUserInfo->roleId, iUserRole);
            RAISE_ERR(rc, RTN);

            if (C_APIUSER_ROLE_QUOT == iUserRole)
            {
                // 撤销行情订阅
                QtSbscrptnApi key;
                strcpy(key.usrLgnNm, pRefData->strUserName);
                rc = DeleteQtSbscrptnApi(connId, &key);
            }
        }
        break;

    case MSG_TYPE_API_LOGOUT:
        rc = DeleteUserOnline(connId, pRefData->strUserName);
        RAISE_ERR(rc, RTN);

        rc = InsertUserLoginHistory(connId, &sHistory);
        RAISE_ERR(rc, RTN);

        // 获取用户类型，每个API用户仅对应一种权限
        int32       iUserRole;
        rc = CheckApiUserRole(pUserInfo->roleId, iUserRole);
        RAISE_ERR(rc, RTN);

        if (C_APIUSER_ROLE_QUOT == iUserRole)
        {
            // 撤销行情订阅
            QtSbscrptnApi key;
            strcpy(key.usrLgnNm, pRefData->strUserName);
            rc = DeleteQtSbscrptnApi(connId, &key);
        }

        break;

    case MSG_TYPE_API_USER_REMOVE:
        if (strcmp(pRefData->strUserName, "") == 0)
        {
            rc = InsertUserLoginHistory(connId, &sHistory);
            RAISE_ERR(rc, RTN);

            rc = DeleteApiUsrByFlag(connId, C_API_USRFLAG);
            RAISE_ERR(rc, RTN);

            rc = DeleteAllQtSbscrptnApi(connId);
            RAISE_ERR(rc, RTN);

            rc = ClearAllOnlnApiStatus(connId);
            RAISE_ERR(rc, RTN);
        }
        else
        {
            rc = DeleteApiUsrByNameAndFlag(connId, pRefData->strUserName, C_API_USRFLAG);
            RAISE_ERR(rc, RTN);

            rc = InsertUserLoginHistory(connId, &sHistory);
            RAISE_ERR(rc, RTN);

            // 获取用户类型，每个API用户仅对应一种权限
            int32       iUserRole;
            rc = CheckApiUserRole(pUserInfo->roleId, iUserRole);
            RAISE_ERR(rc, RTN);

            if (C_APIUSER_ROLE_QUOT == iUserRole)
            {
                // 撤销行情订阅
                QtSbscrptnApi key;
                strcpy(key.usrLgnNm, pRefData->strUserName);
                rc = DeleteQtSbscrptnApi(connId, &key);
            }
            else if (C_APIUSER_ROLE_CRDT == iUserRole)
            {
                // 将正在授信状态改为无操作
                rc = UpdateOrgInfoDbForCrdtUnlock(connId, &sCrdt);
                RAISE_ERR(rc, RTN);
            }
        }
        break;

    case MSG_TYPE_API_USER_FREEZE:
        int32 usrSt;
        usrSt = atoi(pUserInfo->usrSt);
        if (usrSt == C_USR_ST_ACTIVE)
        {
            rc = UpdateUsrDb(connId, pRefData->strUserName, pRefData->strCWUsrNm, C_USR_ST_LOCK, pRefData->oprtTm);
            RAISE_ERR(rc, RTN);

            int iCnt;
            // get the user online count
            rc = GetCntByUsrNm(connId, pRefData->strUserName, &iCnt);
            RAISE_ERR(rc, RTN);
            if (iCnt >= 1)
            {
                // delete the old user
                rc = DeleteUserOnline(connId, pRefData->strUserName);
                RAISE_ERR(rc, RTN);

                rc = InsertUserLoginHistory(connId, &sHistory);
                RAISE_ERR(rc, RTN);
            }

            int32       iUserRole;
            rc = CheckApiUserRole(pUserInfo->roleId, iUserRole);
            RAISE_ERR(rc, RTN);

            if (iUserRole == C_APIUSER_ROLE_QUOT)
            {
                // 撤销行情订阅
                QtSbscrptnApi key;
                strcpy(key.usrLgnNm, pRefData->strUserName);
                rc = DeleteQtSbscrptnApi(connId, &key);
            }
        }
        else if (usrSt == C_USR_ST_LOCK)
        {
            rc = UpdateUsrDb(connId, pRefData->strUserName, pRefData->strCWUsrNm, C_USR_ST_ACTIVE, pRefData->oprtTm);
            RAISE_ERR(rc, RTN);
        }

        break;

    default:
        break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UserDataPrint
 **
 ******************************************************************************/
ResCodeT UserDataPrint(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UserDataPrint" );
    ResCodeT rc = NO_ERR;

    UserMemDataRefT* pRefData = (UserMemDataRefT*)pData;

    printf("UserMemDataRefT: eMessageType=%d, strUserName=%s, strCWUsrNm=%s, intOrgId=%d, sesnId=%s, lgnTp=%d, apiF=%s, oprtTp=%s, lgnIp=%s, oprtTm=%s.\n",
            pRefData->eMessageType, pRefData->strUserName, pRefData->strCWUsrNm, pRefData->intOrgId,
            pRefData->sesnId, pRefData->lgnTp, pRefData->apiF,
            pRefData->oprtTp, pRefData->lgnIp, pRefData->oprtTm);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DeserializeUsrRefData
 **
 ******************************************************************************/
ResCodeT DeserializeApiSbRefData(
                ApiSubscribeDataRefT*   pRefData,
                QtSbscrptnApi*          data
                )
{
    BEGIN_FUNCTION( "DeserializeUsrRefData" );
    ResCodeT rc = NO_ERR;

    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pRefData->strUserName, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }

    pOrgInfoT pOrgData;
    rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgData);
    RAISE_ERR(rc, RTN);


    memset(data, 0, sizeof(QtSbscrptnApi));
    strcpy(data->usrLgnNm, pRefData->strUserName);
    data->orgId = pUserInfo->orgId;
    strcpy(data->orgCd, pOrgData->orgCd);
    itoa(pRefData->mktTp, data->mktTp, 10);
    if (pRefData->mktTp = SET_MKT_IRS || pRefData->mktTp == SET_MKT_SIRS)
    {
        strcpy(data->stlTp, "1");
    }
    else if (pRefData->mktTp = SET_MKT_SBFCCP)
    {
        strcpy(data->stlTp, "2");
    }
    if (pRefData->mktTp == SET_MKT_IRS)
    {
        strcpy(data->cntrctCd, pRefData->strCntRctCd);
    }
    else if (pRefData->mktTp = SET_MKT_SIRS || pRefData->mktTp == SET_MKT_SBFCCP)
    {
        strcpy(data->cntrctCd, "-");
    }
    itoa(pRefData->iMdBookType, data->qtTp, 10);
    itoa(pRefData->iMarketDepth, data->lvl, 10);
    strcpy(data->instrctnSendTm, pRefData->oprtTm);
    strcpy(data->crtTm, pRefData->oprtTm);
    itoa(pRefData->iReqId, data->rqstId, 10);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ApiSubscribeMemRef
 **
 ******************************************************************************/
ResCodeT ApiSubscribeMemRef(void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "ApiSubscribeMemRef" );
    ResCodeT rc = NO_ERR;


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ApiSubscribeDbtRef
 **
 ******************************************************************************/
ResCodeT ApiSubscribeDbtRef(int32 connId, void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "ApiSubscribeDbtRef" );
    ResCodeT rc = NO_ERR;

    ApiSubscribeDataRefT* pRefData = (ApiSubscribeDataRefT*)pData;

    switch (pRefData->eMessageType)
    {
    case MSG_TYPE_API_SUBSCRIBE:
        {
            QtSbscrptnApi sQtSbsApi;
            rc = DeserializeApiSbRefData(pRefData, &sQtSbsApi);
            RAISE_ERR(rc, RTN);

            char temp[10];
            int32 iIrsApiCnt = 0;
            // get the irs api cnt
            rc = GetResultCntByUsrAndQttp(connId, pRefData->strUserName, (char*)C_MKT_TP_IRS, itoa(pRefData->iMdBookType, temp, 10), &iIrsApiCnt);
            RAISE_ERR(rc, RTN);

            if (pRefData->iRequestType == 1)
            {
                if (iIrsApiCnt > 0)
                {
                    // update QT_SBSCRPTN_API
                    rc = UpdateSubscribe(connId, &sQtSbsApi);
                    RAISE_ERR(rc, RTN);
                }
                else
                {
                    // insert QT_SBSCRPTN_API
                    rc = InsertQtSbscrptnApi(connId, &sQtSbsApi);
                    RAISE_ERR(rc, RTN);
                }
            }
            else
            {
                if (iIrsApiCnt > 0)
                {
                    // delete QT_SBSCRPTN_API
                    rc = DeleteQtSbscrptnByUsrAndQttp(connId, pRefData->strUserName, (char*)C_MKT_TP_IRS, itoa(pRefData->iMdBookType, temp, 10));
                    RAISE_ERR(rc, RTN);
                }
                else
                {
                    RAISE_ERR(APIERR_CODE_INVLD_DUP_UNSUBQT, RTN);
                }
            }
        }
        break;

    case MSG_TYPE_API_UNSUBSCRIBE_ALL:
        // 取消全部订阅
        rc = DeleteAllQtSbscrptnApi(connId);
        RAISE_ERR(rc, RTN);
        break;

    default:
        break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ApiSubscribeDataPrint
 **
 ******************************************************************************/
ResCodeT ApiSubscribeDataPrint(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "ApiSubscribeDataPrint" );
    ResCodeT rc = NO_ERR;

    ApiSubscribeDataRefT* pRefData = (ApiSubscribeDataRefT*)pData;

    printf("ApiSubscribeDataRefT: eMessageType=%d, strUserName=%s, iRequestType=%d, mktTp=%d, strCntRctCd=%s, iMdBookType=%d, iMarketDepth=%d, oprtTm=%s, iReqId=%lld.\n",
            pRefData->eMessageType, pRefData->strUserName, pRefData->iRequestType,
            pRefData->mktTp, pRefData->strCntRctCd, pRefData->iMdBookType, pRefData->iMarketDepth,
            pRefData->oprtTm, pRefData->iReqId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateUsrFlag(
            int32       connId,
            Usr*        pUsrData
            )
{
    BEGIN_FUNCTION( "UpdateUsrFlag" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(22)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(22)] = {0};

    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 20 );

    rc = UpdateUsrByKey( connId, pUsrData, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateUsrFlagAndMdfy(
            int32       connId,
            Usr*        pUsrData
            )
{
    BEGIN_FUNCTION( "UpdateUsrFlagAndMdfy" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(22)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(22)] = {0};

    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 19 );
    DbCmmnSetColBit( datVct, 20 );
    DbCmmnSetColBit( datVct, 21 );

    rc = UpdateUsrByKey( connId, pUsrData, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DeserializeUsrRefData
 **
 ******************************************************************************/
ResCodeT DeserializeTrdConfRefData(
                TrdPrvlConfDataRefT*    pRefData,
                Usr*                    pUsrData,
                int&                    iAppId
                )
{
    BEGIN_FUNCTION( "DeserializeUsrRefData" );
    ResCodeT rc = NO_ERR;

    memset(pUsrData, 0, sizeof(Usr));

    strcpy(pUsrData->usrLgnNm, pRefData->strTrdId);
    strcpy(pUsrData->updTm, pRefData->oprtTm);
    strcpy(pUsrData->updUsrNm, pRefData->strUsrId);

    if (BitCheck(pRefData->allPrvls, 0))
    {
        iAppId = 1;
    }
    else
    {
        iAppId = 2;
    }

    if (BitCheck(pRefData->allPrvls, 1))
    {
        strcpy(pUsrData->ordrPrvlgF, "1");
    }
    else
    {
        strcpy(pUsrData->ordrPrvlgF, "2");
    }
    if (BitCheck(pRefData->allPrvls, 2))
    {
        strcpy(pUsrData->ordrPrvlgMdfyF, "1");
    }
    else
    {
        strcpy(pUsrData->ordrPrvlgMdfyF, "0");
    }
    if (BitCheck(pRefData->allPrvls, 3))
    {
        strcpy(pUsrData->ordrPrvlgFSirs, "1");
    }
    else
    {
        strcpy(pUsrData->ordrPrvlgFSirs, "2");
    }
    if (BitCheck(pRefData->allPrvls, 4))
    {
        strcpy(pUsrData->ordrPrvlgMdfyFSirs, "1");
    }
    else
    {
        strcpy(pUsrData->ordrPrvlgMdfyFSirs, "0");
    }
    if (BitCheck(pRefData->allPrvls, 5))
    {
        strcpy(pUsrData->ordrPrvlgFSbfccp, "1");
    }
    else
    {
        strcpy(pUsrData->ordrPrvlgFSbfccp, "2");
    }
    if (BitCheck(pRefData->allPrvls, 6))
    {
        strcpy(pUsrData->ordrPrvlgMdfyFSbfccp, "1");
    }
    else
    {
        strcpy(pUsrData->ordrPrvlgMdfyFSbfccp, "0");
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** TrdPrvlConfMemRef
 **
 ******************************************************************************/
ResCodeT TrdPrvlConfMemRef(void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "TrdPrvlConfMemRef" );
    ResCodeT rc = NO_ERR;

    TrdPrvlConfDataRefT* pRefData = (TrdPrvlConfDataRefT*)pData;

    Usr data;
    int32 iAppId;

    rc = DeserializeTrdConfRefData(pRefData, &data, iAppId);
    RAISE_ERR(rc, RTN);

    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pRefData->strTrdId, &pUserInfo);

    if (iAppId == C_DWS)
    {
        // 如果是前台发起的操作
        strcpy(pUserInfo->ordrPrvlgF, data.ordrPrvlgF);
        strcpy(pUserInfo->ordrPrvlgFSirs, data.ordrPrvlgFSirs);
        strcpy(pUserInfo->ordrPrvlgFSbfccp, data.ordrPrvlgFSbfccp);
    }
    else if (iAppId == C_MBO)
    {
        // 如果是中后台发起的操作
        strcpy(pUserInfo->ordrPrvlgF, data.ordrPrvlgF);
        strcpy(pUserInfo->ordrPrvlgMdfyF, data.ordrPrvlgMdfyF);
        strcpy(pUserInfo->ordrPrvlgFSirs, data.ordrPrvlgFSirs);
        strcpy(pUserInfo->ordrPrvlgMdfyFSirs, data.ordrPrvlgMdfyFSirs);
        strcpy(pUserInfo->ordrPrvlgFSbfccp, data.ordrPrvlgFSbfccp);
        strcpy(pUserInfo->ordrPrvlgMdfyFSbfccp, data.ordrPrvlgMdfyFSbfccp);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** TrdPrvlConfDbRef
 **
 ******************************************************************************/
ResCodeT TrdPrvlConfDbRef(int32 connId, void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "TrdPrvlConfDbRef" );
    ResCodeT rc = NO_ERR;


    TrdPrvlConfDataRefT* pRefData = (TrdPrvlConfDataRefT*)pData;

    Usr data;
    int32 iAppId;

    rc = DeserializeTrdConfRefData(pRefData, &data, iAppId);
    RAISE_ERR(rc, RTN);


    if (iAppId == C_DWS)
    {
        // 如果是前台发起的操作
        rc = UpdateUsrFlag(connId, &data);
        RAISE_ERR(rc, RTN);
    }
    else if (iAppId == C_MBO)
    {
        // 如果是中后台发起的操作
        rc = UpdateUsrFlagAndMdfy(connId, &data);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** TrdPrvlConfDataPrint
 **
 ******************************************************************************/
ResCodeT TrdPrvlConfDataPrint(void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "TrdPrvlConfDataPrint" );
    ResCodeT rc = NO_ERR;

    TrdPrvlConfDataRefT* pRefData = (TrdPrvlConfDataRefT*)pData;

    printf("TrdPrvlConfDataRefT: strUsrId=%s, strTrdId=%s, oprtTm=%s, allPrvls=%lld.\n",
            pRefData->strUsrId, pRefData->strTrdId, pRefData->oprtTm, pRefData->allPrvls);

    EXIT_BLOCK();
    RETURN_RESCODE;
}





/******************************************************************************
 **
 ** CreditMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT CreditMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CreditMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;
    switch (pCrdtUpdData->eMessageType) {
        case MSG_TYPE_CREDIT_MODIFY:
            rc = CrdtModifyMemUpdateCallback(pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_UPDATE:
        case MSG_TYPE_API_CREDIT_UPDATE:
            rc = CrdtUpdateMemUpdateCallback(pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_UNLOCK:
            rc = CrdtUnlockMemUpdateCallback(pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE:
            rc = CrdtRefMthdUpdMemUpdateCallback(pCrdtUpdData, dataLen);
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CreditDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT CreditDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CreditDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;
    switch (pCrdtUpdData->eMessageType) {
        case MSG_TYPE_CREDIT_MODIFY:
            rc = CrdtModifyDbUpdateCallback(connId, pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_UPDATE:
        case MSG_TYPE_API_CREDIT_UPDATE:
            rc = CrdtUpdateDbUpdateCallback(connId, pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_UNLOCK:
            rc = CrdtUnlockDbUpdateCallback(connId, pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE:
            rc = CrdtRefMthdUpdDbUpdateCallback(connId, pCrdtUpdData, dataLen);
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CreditPrintCallback
 **
 ******************************************************************************/
ResCodeT CreditPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CreditPrintCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;
    switch (pCrdtUpdData->eMessageType) {
        case MSG_TYPE_CREDIT_MODIFY:
            rc = CrdtModifyPrintCallback(pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_UPDATE:
        case MSG_TYPE_API_CREDIT_UPDATE:
            rc = CrdtUpdatePrintCallback(pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_UNLOCK:
            rc = CrdtUnlockPrintCallback(pCrdtUpdData, dataLen);
            break;
        case MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE:
            rc = CrdtRefMthdUpdPrintCallback(pCrdtUpdData, dataLen);
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtUpdateMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtUpdateMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtUpdateMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoShareMemoryForCrdtMthd(pCrdtUpdData);
    RAISE_ERR(rc, RTN);

    rc = UpdateCrdtShareMemoryForAmnt(pCrdtUpdData);
    RAISE_ERR(rc, RTN);

    rc = UpdateOrgInfoShareMemoryForCrdtUpdateUnlock(pCrdtUpdData);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtUpdateDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtUpdateDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtUpdateDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoForCrdtMthd(connId, pCrdtUpdData);
    RAISE_ERR(rc, RTN);

    rc = UpdateCrdtInfoForAmnt(connId, pCrdtUpdData);
    RAISE_ERR(rc, RTN);

    rc = UpdateOrgInfoForUpdateUnlock(connId, pCrdtUpdData);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtUpdatePrintCallback
 **
 ******************************************************************************/
ResCodeT CrdtUpdatePrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtUpdatePrintCallback" );
    ResCodeT rc = NO_ERR;
    int32 index;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    // 输入信息打印日志打印
    LOG_INFO("[IN]Condition: strUserId = %s",          pCrdtUpdData->strUserId);
    LOG_INFO("[IN]Condition: intOrgId = %d",           pCrdtUpdData->intOrgId);
    LOG_INFO("[IN]Condition: strUpdTm = %s",           pCrdtUpdData->strUpdTm);
    LOG_INFO("[IN]Condition: intCount = %d",           pCrdtUpdData->intCount);
    LOG_INFO("[IN]Condition: intCrdtMthd = %d",        pCrdtUpdData->intCrdtMthd);
    for (index = 0; index < pCrdtUpdData->intCount; index++) {
        LOG_INFO("[IN]Condition: CreditInfo[%d].intCrdtedOrgId = %d",  index, pCrdtUpdData->crdtInfo[index].intCrdtedOrgId);
        LOG_INFO("[IN]Condition: CreditInfo[%d].intCrdtRlf = %d",      index, pCrdtUpdData->crdtInfo[index].intCrdtRlf);
        LOG_INFO("[IN]Condition: CreditInfo[%d].intIntlCrdtAmnt = %d", index, pCrdtUpdData->crdtInfo[index].intIntlCrdtAmnt);
        LOG_INFO("[IN]Condition: CreditInfo[%d].intCrdtTerm = %d",     index, pCrdtUpdData->crdtInfo[index].intCrdtTerm);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtUnlockMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtUnlockMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtUnlockMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUnlockData;
    pCrdtUnlockData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoShareMemoryForCrdtUnlock(pCrdtUnlockData);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtUnlockDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtUnlockDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtUnlockDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUnlockData;
    pCrdtUnlockData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoDbForCrdtUnlock(connId, pCrdtUnlockData);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtUnlockPrintCallback
 **
 ******************************************************************************/
ResCodeT CrdtUnlockPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtUnlockPrintCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUnlockData;
    pCrdtUnlockData = (CreditUpdateDataT*)pData;

    // 输入信息打印日志打印
    LOG_INFO("[IN]Condition: strUserId = %s", pCrdtUnlockData->strUserId);
    LOG_INFO("[IN]Condition: intOrgId = %d",  pCrdtUnlockData->intOrgId);
    LOG_INFO("[IN]Condition: strUpdTm = %d",  pCrdtUnlockData->strUpdTm);
    if (pCrdtUnlockData->intCheckOrg == 1) {
        LOG_INFO("[IN]Condition: intCrdtVldOrgFlag = %d", pCrdtUnlockData->intCrdtVldOrgFlag);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtRefMthdUpdMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtRefMthdUpdMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtRefMthdUpdMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoShareMemoryForCrdtUpdMthd(pCrdtUpdData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtRefMthdUpdDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtRefMthdUpdDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtRefMthdUpdDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoDbForUpdMthd(connId, pCrdtUpdData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtRefMthdUpdPrintCallback
 **
 ******************************************************************************/
ResCodeT CrdtRefMthdUpdPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtRefMthdUpdPrintCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    // 输入信息打印日志打印
    LOG_INFO("[IN]Condition: strUserId = %s",  pCrdtUpdData->strUserId);
    LOG_INFO("[IN]Condition: intOrgId = %d",   pCrdtUpdData->intOrgId);
    LOG_INFO("[IN]Condition: strUpdTm = %s",   pCrdtUpdData->strUpdTm);
    LOG_INFO("[IN]Condition: intUpdMthd = %d", pCrdtUpdData->intUpdMthd);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtModifyMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtModifyMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtModifyMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    rc = UpdateShareMemoryOfOrgInfoForCrdtModify(pCrdtUpdData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtModifyDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT CrdtModifyDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtModifyDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    rc = UpdateOrgInfoDbForCrtOperating(connId, pCrdtUpdData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CrdtModifyPrintCallback
 **
 ******************************************************************************/
ResCodeT CrdtModifyPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CrdtModifyPrintCallback" );
    ResCodeT rc = NO_ERR;

    CreditUpdateDataT* pCrdtUpdData;
    pCrdtUpdData = (CreditUpdateDataT*)pData;

    // 输入信息打印日志打印
    LOG_INFO("[IN]Condition: strUserId = %s",       pCrdtUpdData->strUserId);
    LOG_INFO("[IN]Condition: intOrgId = %d",        pCrdtUpdData->intOrgId);
    LOG_INFO("[IN]Condition: strUpdTm = %s",        pCrdtUpdData->strUpdTm);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/*=============================================================================
**=============================================================================
** Private Function
**=============================================================================
=============================================================================*/

/******************************************************************************
 **
 ** UpdateOrgInfoDbForCrtOperating(CreditModify)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoDbForCrtOperating(int32 connId, CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoDbForCrtOperating" );
    ResCodeT rc = NO_ERR;

    OrgInfo data;
    vectorT  keyVec[GET_BIT_VECT_LEN(29)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(29)] = {0};

    // set key value.
    data.orgId = pData->intOrgId;
    DbCmmnSetColBit(keyVec, 1);

    // set data value.
    sprintf(data.crdtOprtngSt, "%d", C_CRT_OPERATING);
    strcpy(data.crdtOprtr, pData->strUserId);
    strcpy(data.updUsrNm,  pData->strUserId);
    strcpy(data.updTm,     pData->strUpdTm);

    DbCmmnSetColBit(datVec, 15);
    DbCmmnSetColBit(datVec, 16);
    DbCmmnSetColBit(datVec, 17);
    DbCmmnSetColBit(datVec, 18);

    rc = UpdateOrgInfoByKey(connId, &data, keyVec, datVec);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 **
 ** UpdateShareMemoryOfOrgInfoForCrdtModify(CreditModify)
 **
 ******************************************************************************/
ResCodeT UpdateShareMemoryOfOrgInfoForCrdtModify(CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateShareMemoryOfOrgInfoForCrdtModify" );
    ResCodeT rc = NO_ERR;
    OrgInfoT *pOrgInfoData = NULL;

    // update share memory.
    rc = OrgInfoGetByIdExt(pData->intOrgId, &pOrgInfoData);
    RAISE_ERR(rc, RTN);
    if (!pOrgInfoData) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    pOrgInfoData->crdtOprtngSt = C_CRT_OPERATING;
    strcpy(pOrgInfoData->crdtOprtr, pData->strUserId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoForCrdtMthd(CreditUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoForCrdtMthd(int32 connId, CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoForCrdtMthd" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(29)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(29)] = {0};

    OrgInfo data;
    memset(&data, 0x00, sizeof(OrgInfo));

    // set key value.
    data.orgId = pData->intOrgId;
    DbCmmnSetColBit( keyVct, 1 );

    // set data value.
    sprintf(data.crdtMthd, "%d", pData->intCrdtMthd);
    strcpy(data.updUsrNm, pData->strUserId);
    strcpy(data.updTm, pData->strUpdTm);

    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 15 );

    rc = UpdateOrgInfoByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateCrdtInfoForAmnt(CreditUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateCrdtInfoForAmnt(int32 connId, CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateCrdtInfoForAmnt" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(18)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(18)] = {0};

    Crdt data;
    int32 index;

    for (index = 0; index < pData->intCount; index++) {
        memset(&data, 0x00, sizeof(Crdt));
        if (C_CREDIT_RL == pData->intCrdtMthd){
            //按关系授信
            // set data value.
            sprintf(data.crdtRlF, "%d", pData->crdtInfo[index].intCrdtRlf);
            data.intlCrdtAmnt = 0;
            data.usedCrdtAmnt = 0;
            data.rmnCrdtAmnt = 0;
            data.crdtTerm = 0;
            strcpy(data.updUsrNm, pData->strUserId);
//            strcpy(data.updTm, pData->strUpdTm);
            strcpy(data.usrUpdTm, pData->strUpdTm);
        }
        else if (C_CREDIT_AMT == pData->intCrdtMthd) {
            //按额度授信
            if ( pData->crdtInfo[index].intIntlCrdtAmnt < 0 ||
                pData->crdtInfo[index].intIntlCrdtAmnt > C_MAX_CRDT_AMNT ) {
                RAISE_ERR(ERR_CODE_INVLD_INVLID_AMNT, RTN);
            }
            // set data value.
            strcpy(data.crdtRlF, "");
            data.intlCrdtAmnt = pData->crdtInfo[index].intIntlCrdtAmnt;
            data.usedCrdtAmnt = 0;
            data.rmnCrdtAmnt = pData->crdtInfo[index].intIntlCrdtAmnt;
            data.crdtTerm = pData->crdtInfo[index].intCrdtTerm;
            strcpy(data.updUsrNm, pData->strUserId);
//            strcpy(data.updTm, pData->strUpdTm);
            strcpy(data.usrUpdTm, pData->strUpdTm);
        }
        else{
            // T.B.D
            continue;
        }

        // set data flag.
        DbCmmnSetColBit( datVct, 3 );
        DbCmmnSetColBit( datVct, 5 );
        DbCmmnSetColBit( datVct, 6 );
        DbCmmnSetColBit( datVct, 7 );
        DbCmmnSetColBit( datVct, 8 );
//        DbCmmnSetColBit( datVct, 12 );
        DbCmmnSetColBit( datVct, 13 );
        DbCmmnSetColBit( datVct, 14 );

        // set key value.
        data.crdtOrgId  = pData->intOrgId;
        data.crdtdOrgId = pData->crdtInfo[index].intCrdtedOrgId;
        // set key flag.
        DbCmmnSetColBit( keyVct, 1 );
        DbCmmnSetColBit( keyVct, 2 );

        rc = UpdateCrdtByKey(connId, &data, keyVct, datVct);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoForUpdateUnlock(CreditUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoForUpdateUnlock(int32 connId, CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoForUpdateUnlock" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(29)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(29)] = {0};

    OrgInfo data;
    memset(&data, 0x00, sizeof(OrgInfo));

    // set key value.
    data.orgId = pData->intOrgId;
    DbCmmnSetColBit( keyVct, 1 );

    // set data value.
    sprintf(data.crdtOprtngSt, "%d", C_CRT_NONE);
    sprintf(data.crdtVldOrgF,  "%d", pData->intCrdtVldOrgFlag);
    strcpy(data.crdtOprtr, pData->strUserId);
    strcpy(data.updUsrNm, C_SYSTEM);
    strcpy(data.updTm, pData->strUpdTm);

    DbCmmnSetColBit( datVct, 12 );
    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoShareMemoryForCrdtMthd(CreditUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoShareMemoryForCrdtMthd(CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoShareMemoryForCrdtMthd" );
    ResCodeT rc = NO_ERR;
    OrgInfoT *pOrgInfoData = NULL;

    // update share memory.
    rc = OrgInfoGetByIdExt(pData->intOrgId, &pOrgInfoData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    if (!pOrgInfoData) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    pOrgInfoData->crdtMthd = pData->intCrdtMthd;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateCrdtShareMemoryForAmnt(CreditUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateCrdtShareMemoryForAmnt(CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateCrdtShareMemoryForAmnt" );
    ResCodeT rc = NO_ERR;
    CreditT *pCreditData;
    int32 index;

    // update share memory.
    for (index = 0; index < pData->intCount; index++) {
        pCreditData = NULL;
        if (C_CREDIT_RL == pData->intCrdtMthd){
            //按关系授信
            rc = CreditInfoGetByKeyExt(pData->intOrgId, pData->crdtInfo[index].intCrdtedOrgId, &pCreditData);
            RAISE_ERR(rc, RTN);
            if (!pCreditData) {
                RAISE_ERR(ERR_INVLD_POINTER, RTN);
            }

            sprintf(pCreditData->crdtRlFlag, "%d", pData->crdtInfo[index].intCrdtRlf);
            pCreditData->intlCrdtAmnt = 0;
            pCreditData->usedCrdtAmnt = 0;
            pCreditData->rmnCrdtAmnt = 0;
            pCreditData->crdtTerm = 0;
        }
        else if (C_CREDIT_AMT == pData->intCrdtMthd) {
            //按额度授信
            rc = CreditInfoGetByKeyExt(pData->intOrgId, pData->crdtInfo[index].intCrdtedOrgId, &pCreditData);
            RAISE_ERR(rc, RTN);
            if (!pCreditData) {
                RAISE_ERR(ERR_INVLD_POINTER, RTN);
            }

            strcpy(pCreditData->crdtRlFlag, "");
            pCreditData->intlCrdtAmnt = pData->crdtInfo[index].intIntlCrdtAmnt;
            pCreditData->usedCrdtAmnt = 0;
            pCreditData->rmnCrdtAmnt = pData->crdtInfo[index].intIntlCrdtAmnt;
            pCreditData->crdtTerm = pData->crdtInfo[index].intCrdtTerm;
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoShareMemoryForCrdtUpdateUnlock(CreditUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoShareMemoryForCrdtUpdateUnlock(CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoShareMemoryForCrdtUpdateUnlock" );
    ResCodeT rc = NO_ERR;
    OrgInfoT *pOrgInfoData = NULL;

    // update share memory.
    rc = OrgInfoGetByIdExt(pData->intOrgId, &pOrgInfoData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    if (!pOrgInfoData) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    pOrgInfoData->crdtOprtngSt = C_CRT_NONE;
    pOrgInfoData->crdtVldOrgFlag = pData->intCrdtVldOrgFlag;
    strcpy(pOrgInfoData->crdtOprtr, pData->strUserId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoDbForCrdtUnlock(CreditUnlock)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoDbForCrdtUnlock(int32 connId, CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoDbForCrdtUnlock" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(29)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(29)] = {0};

    OrgInfo data;
    memset(&data, 0x00, sizeof(OrgInfo));

    // set key value.
    data.orgId = pData->intOrgId;
    DbCmmnSetColBit( keyVct, 1 );

    // set data value.
    sprintf(data.crdtOprtngSt, "%d", C_CRT_NONE);
    strcpy(data.crdtOprtr, "");
    strcpy(data.updUsrNm, pData->strUserId);
    strcpy(data.updTm, pData->strUpdTm);
    if (pData->intCheckOrg == 1) {
        sprintf(data.crdtVldOrgF, "%d", pData->intCrdtVldOrgFlag);
        strcpy(data.updUsrNm, C_SYSTEM);
        DbCmmnSetColBit( datVct, 12 );
    }

    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoShareMemoryForCrdtUnlock(CreditUnlock)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoShareMemoryForCrdtUnlock(CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoShareMemoryForCrdtUnlock" );
    ResCodeT rc = NO_ERR;
    OrgInfoT *pOrgInfoData = NULL;

    // update share memory.
    rc = OrgInfoGetByIdExt(pData->intOrgId, &pOrgInfoData);
    RAISE_ERR(rc, RTN);
    if (!pOrgInfoData) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    pOrgInfoData->crdtOprtngSt = C_CRT_NONE;
    strcpy(pOrgInfoData->crdtOprtr, "");
    if (pData->intCheckOrg == 1) {
        pOrgInfoData->crdtVldOrgFlag = pData->intCrdtVldOrgFlag;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoDbForUpdMthd(CreditRefreshMethodUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoDbForUpdMthd(int32 connId, CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoDbForUpdMthd" );
    ResCodeT rc = NO_ERR;

    OrgInfo data;
    vectorT  keyVec[GET_BIT_VECT_LEN(29)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(29)] = {0};

    // set key value.
    data.orgId = pData->intOrgId;
    DbCmmnSetColBit(keyVec, 1);

    // set data value.
    sprintf(data.crdtUpdMthd, "%d", pData->intUpdMthd);
    strcpy(data.updUsrNm, pData->strUserId);
    strcpy(data.updTm, pData->strUpdTm);

    DbCmmnSetColBit(datVec, 11);
    DbCmmnSetColBit(datVec, 16);
    DbCmmnSetColBit(datVec, 15);

    rc = UpdateOrgInfoByKey(connId, &data, keyVec, datVec);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoShareMemoryForCrdtUpdMthd(CreditRefreshMethodUpdate)
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoShareMemoryForCrdtUpdMthd(CreditUpdateDataT* pData)
{
    BEGIN_FUNCTION( "UpdateOrgInfoShareMemoryForCrdtUpdMthd" );
    ResCodeT rc = NO_ERR;
    OrgInfoT *pOrgInfoData = NULL;

    // update share memory.
    rc = OrgInfoGetByIdExt(pData->intOrgId, &pOrgInfoData);
    RAISE_ERR(rc, RTN);
    if (!pOrgInfoData) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    pOrgInfoData->crdtUpdMthd = pData->intUpdMthd;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   refresh mkt info in of all exchanged product
 * Parameters:
 *      prdctId         IN product pos in its share mem
 *      prdctMktSts     IN
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT RefPrcUpdCallback( void * pData, int32 dataSize )
{
    BEGIN_FUNCTION("RefPrcUpdCallback");
    ResCodeT rc = NO_ERR;

    pPrdRefPrcUpdT   pRefPrcUpdInfo = NULL;

    pRefPrcUpdInfo = (pPrdRefPrcUpdT)pData;

    rc = UpdIntradayRefPrc( pRefPrcUpdInfo );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   refresh ref prc into database
 * Parameters:
 *      connId          IN DB connection id
 *      pData           IN new data
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT RefPrcUpdDbCallback( int32 connId, void * pData, int32 dataSize )
{
    BEGIN_FUNCTION("RefPrcUpdDbCallback");
    ResCodeT rc = NO_ERR;

    pPrdRefPrcUpdT   pRefPrcUpdInfo = NULL;

    pRefPrcUpdInfo = (pPrdRefPrcUpdT)pData;

    rc = UpdRefPrcToDb( connId, pRefPrcUpdInfo );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   print mentxn info of ref prc
 * Parameters:
 *      pData           IN new data
 *      dataSize        IN data size
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT RefPrcPrintCallback( void * pData, int32 dataSize )
{
    BEGIN_FUNCTION("RefPrcPrintCallback");
    ResCodeT rc = NO_ERR;

    pPrdRefPrcUpdT   pRefPrcUpdInfo = NULL;

    pRefPrcUpdInfo = (pPrdRefPrcUpdT)pData;

    printf( "PrdRefPrcUpdT: refPrcUpdTime=%lld Total:%lld\n",
                                    pRefPrcUpdInfo->refPrcUpdTime,
                                    pRefPrcUpdInfo->updCnt );

    //for ( int i = 0; i < pRefPrcUpdInfo->updCnt; i++ )
    //{
    //    printf( "prdct[%llu] refprc: %lld, ",
    //                                pRefPrcUpdInfo->refPrcNode[i].prdctId,
    //                                pRefPrcUpdInfo->refPrcNode[i].intraRefPrc );
    //    if ( !((i+1) % 4) )
    //    {
    //        printf("\n");
    //    }
    //}

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/*------------------------- Bridge Organization Update ------------------------------*/
/******************************************************************************
 **
 ** BridgeMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT BridgeMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    BridgeUpdateDataRefT* pBrdgUpdData;
    pBrdgOrgInfoT pBrdgOrgData;

    pBrdgUpdData = (BridgeUpdateDataRefT*)pData;

    rc = BrdgOrgInfoGetByIdExt(pBrdgUpdData->intOrgId, &pBrdgOrgData);
    RAISE_ERR(rc, RTN);

    switch (pBrdgUpdData->eMessageType) {
        case MSG_TYPE_BRIDGE_DEALER_UPDATE:

            pBrdgOrgData->brdgIntntnFlag = pBrdgUpdData->intBrdgPrvlgSt;
            strcpy(pBrdgOrgData->usrLgnNm, pBrdgUpdData->strDealerId);
            pBrdgOrgData->brdgOrgSt = pBrdgUpdData->intBrdgOrgSt;

            break;
        case MSG_TYPE_BRIDGE_CREDIT_MODIFY:

            pBrdgOrgData->crdtOprtngSt = C_CRT_OPERATING;
            strcpy(pBrdgOrgData->crdtOprtr, pBrdgUpdData->strUserId);
            pBrdgOrgData->brdgOrgSt = 0;

            break;
        default:
            break;
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT BridgeDealerUpdate(int32 connId, BridgeUpdateDataRefT* pRefData)
{
    BEGIN_FUNCTION( "BridgeDealerUpdate" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};
    OrgInfoBrdg orgInfoBrdgData = {0};

    orgInfoBrdgData.orgId = pRefData->intOrgId;

    DbCmmnSetColBit( keyVct, 1 );

    sprintf(orgInfoBrdgData.brdgIntntnF, "%d", pRefData->intBrdgPrvlgSt);
    strcpy(orgInfoBrdgData.usrLgnNm, pRefData->strDealerId);
    strcpy(orgInfoBrdgData.dlrUpdTm, pRefData->strSysTime);
    strcpy(orgInfoBrdgData.dlrUpdUsrNm, pRefData->strUserId);
    strcpy(orgInfoBrdgData.updTm, pRefData->strSysTime);
    strcpy(orgInfoBrdgData.updUsrNm, pRefData->strUserId);
    sprintf(orgInfoBrdgData.brdgOrgSt, "%d", pRefData->intBrdgOrgSt);

    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 12 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 2 );

    rc = UpdateOrgInfoBrdgByKey(connId, &orgInfoBrdgData,keyVct, datVct);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}


static ResCodeT BridgeCreditModify(int32 connId, BridgeUpdateDataRefT* pRefData)
{
    BEGIN_FUNCTION( "BridgeCreditModify" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};
    OrgInfoBrdg orgInfoBrdgData = {0};

    orgInfoBrdgData.orgId = pRefData->intOrgId;

    DbCmmnSetColBit( keyVct, 1 );

    sprintf(orgInfoBrdgData.crdtOprtngSt, "%d", C_CRT_OPERATING);
    strcpy(orgInfoBrdgData.crdtOprtr, pRefData->strUserId);
    sprintf(orgInfoBrdgData.brdgOrgSt, "%d", 0);
    strcpy(orgInfoBrdgData.updTm, pRefData->strSysTime);
    strcpy(orgInfoBrdgData.updUsrNm, pRefData->strUserId);

    DbCmmnSetColBit( datVct, 13 );
    DbCmmnSetColBit( datVct, 14 );
    DbCmmnSetColBit( datVct, 2 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoBrdgByKey(connId, &orgInfoBrdgData, keyVct, datVct);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** BridgeDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT BridgeDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    BridgeUpdateDataRefT* pBrdgUpdData;

    pBrdgUpdData = (BridgeUpdateDataRefT*)pData;

    switch (pBrdgUpdData->eMessageType) {
        case MSG_TYPE_BRIDGE_DEALER_UPDATE:
            rc = BridgeDealerUpdate(connId, pBrdgUpdData);
            break;
        case MSG_TYPE_BRIDGE_CREDIT_MODIFY:
            rc = BridgeCreditModify(connId, pBrdgUpdData);
            break;
    default:
            break;
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** BridgePrintCallback
 **
 ******************************************************************************/
ResCodeT BridgePrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgePrintCallback" );
    ResCodeT rc = NO_ERR;

    BridgeUpdateDataRefT* pRefData;

    pRefData = (BridgeUpdateDataRefT*)pData;

    printf("BridgeUpdateDataRefT: eMessageType=%d, strUserId=%s, intOrgId=%d, strDealerId=%s, intBrdgOrgSt=%d, intBrdgPrvlgSt=%d, strSysTime=%s.\n",
            pRefData->eMessageType, pRefData->strUserId,
            pRefData->intOrgId, pRefData->strDealerId, pRefData->intBrdgOrgSt,
            pRefData->intBrdgPrvlgSt, pRefData->strSysTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** BridgeParamMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT BridgeParamMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeParamMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    BridgeCwDataRefT* pBrdgUpdData;
    pBaseParamT pBaseParamData;

    pBrdgUpdData = (BridgeCwDataRefT*)pData;

    rc = BaseParamGetByNameExt((char*)C_BRDG_BRIDGEFLAG, &pBaseParamData);
    RAISE_ERR(rc, RTN);
    strcpy(pBaseParamData->paramValue, pBrdgUpdData->strBrdgFlag);

    rc = BaseParamGetByNameExt((char*)C_BRDG_BRIDGEPERCENT, &pBaseParamData);
    RAISE_ERR(rc, RTN);
    strcpy(pBaseParamData->paramValue, pBrdgUpdData->strBrdgPercentage);

    rc = BaseParamGetByNameExt((char*)C_BRDG_BRIDGETIME, &pBaseParamData);
    RAISE_ERR(rc, RTN);
    strcpy(pBaseParamData->paramValue, pBrdgUpdData->strBrdgTime);


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** BridgeParamDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT BridgeParamDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeParamDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    BridgeCwDataRefT* pBrdgUpdData;

    vectorT  keyVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    vectorT  datVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    BaseParam updData = {0};

    pBrdgUpdData = (BridgeCwDataRefT*)pData;

    /* First, update the values in the DB */
    DbCmmnSetColBit( keyVctBaseParam, 1 );

    DbCmmnSetColBit( datVctBaseParam, 2 );
    DbCmmnSetColBit( datVctBaseParam, 5 );
    DbCmmnSetColBit( datVctBaseParam, 6 );

    /* 搭桥开关 */
    memset(&updData, 0x00, sizeof(BaseParam));

    strcpy(updData.paramNm, C_BRDG_BRIDGEFLAG);
    strcpy(updData.paramVl, pBrdgUpdData->strBrdgFlag);
    strcpy(updData.updUsrNm, C_EMERGENCY);
    strcpy(updData.updTm, pBrdgUpdData->strSysTime);

    rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
    RAISE_ERR(rc, RTN);

    /* 搭桥百分比 */
    memset(&updData, 0x00, sizeof(BaseParam));

    strcpy(updData.paramNm, C_BRDG_BRIDGEPERCENT);
    strcpy(updData.paramVl, pBrdgUpdData->strBrdgPercentage);
    strcpy(updData.updUsrNm, C_EMERGENCY);
    strcpy(updData.updTm, pBrdgUpdData->strSysTime);

    rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
    RAISE_ERR(rc, RTN);

    /* 搭桥持续时间 */
    memset(&updData, 0x00, sizeof(BaseParam));

    strcpy(updData.paramNm, C_BRDG_BRIDGETIME);
    strcpy(updData.paramVl, pBrdgUpdData->strBrdgTime);
    strcpy(updData.updUsrNm, C_EMERGENCY);
    strcpy(updData.updTm, pBrdgUpdData->strSysTime);

    rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** BridgeParamPrintCallback
 **
 ******************************************************************************/
ResCodeT BridgeParamPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeParamPrintCallback" );
    ResCodeT rc = NO_ERR;

    BridgeCwDataRefT* pRefData;

    pRefData = (BridgeCwDataRefT*)pData;

    printf("BridgeCwDataRefT: strBrdgFlag=%s, strBrdgPercentage=%s, strBrdgTime=%s, strSysTime=%s.\n",
            pRefData->strBrdgFlag, pRefData->strBrdgPercentage, pRefData->strBrdgTime, pRefData->strSysTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** BridgeCreditMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT BridgeCreditMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeCreditMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    pCreditBrdgT pCrdtBrdgData;
    int32 infoSize;
    int32 index;
    pBrdgOrgInfoT pBrdgOrgData;

    BridgeCreditDataRefT* pBrdgCrdtUpdData;

    pBrdgCrdtUpdData = (BridgeCreditDataRefT*)pData;


    /* 桥授信相关内存数据更新 */
    infoSize = pBrdgCrdtUpdData->intInfoCount;
    for (index = 0; index < infoSize; index++){

        if (strlen(pBrdgCrdtUpdData->brdgCrdtDetail[index].strBrdgFee) == 0){
            RAISE_ERR(ERR_CODE_INVLD_BRDG_FEE, RTN);
        }

        rc = BridgeCreditInfoGetByKeyExt(pBrdgCrdtUpdData->intOrgId,
                pBrdgCrdtUpdData->brdgCrdtDetail[index].intOpOrgId,
                &pCrdtBrdgData);
        RAISE_ERR(rc, RTN);

        pCrdtBrdgData->brdgRlFlag = pBrdgCrdtUpdData->brdgCrdtDetail[index].intCrdtRlf;
        pCrdtBrdgData->brdgFee = atof(pBrdgCrdtUpdData->brdgCrdtDetail[index].strBrdgFee)*pow10(FIGURES_OF_BRDG_FEE);
        pCrdtBrdgData->crdtTerm = pBrdgCrdtUpdData->brdgCrdtDetail[index].intTerm;

    }


    /* 桥授信解锁相关内存数据更新 */
    rc = BrdgOrgInfoGetByIdExt(pBrdgCrdtUpdData->intOrgId, &pBrdgOrgData);
    RAISE_ERR(rc, RTN);

    pBrdgOrgData->crdtOprtngSt = C_CRT_NONE;
    if (pBrdgCrdtUpdData->intModifyFlag == 0){
        memset(pBrdgOrgData->crdtOprtr, 0x00, CREDIT_OPERATOR_LENGTH);
    }else{
        memset(pBrdgOrgData->crdtOprtr, 0x00, CREDIT_OPERATOR_LENGTH);
        strcpy(pBrdgOrgData->crdtOprtr, pBrdgCrdtUpdData->strUserId);
    }
    pBrdgOrgData->brdgOrgSt = pBrdgCrdtUpdData->intBrdgSt;


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** BridgeCreditDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT BridgeCreditDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeCreditDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVctCrdtBrdg[GET_BIT_VECT_LEN(11)] = {0};
    vectorT  datVctCrdtBrdg[GET_BIT_VECT_LEN(11)] = {0};
    CrdtBrdg crdtBrdgData;
    int32 infoSize;
    int32 index;

    vectorT  keyVctOrgInfoBrdg[GET_BIT_VECT_LEN(23)] = {0};
    vectorT  datVctOrgInfoBrdg[GET_BIT_VECT_LEN(23)] = {0};
    OrgInfoBrdg orgInfoBrdgData;

    BridgeCreditDataRefT* pBrdgCrdtUpdData;

    pBrdgCrdtUpdData = (BridgeCreditDataRefT*)pData;

    /* 桥授信记录更新 */
    DbCmmnSetColBit( keyVctCrdtBrdg, 1 );
    DbCmmnSetColBit( keyVctCrdtBrdg, 2 );

    DbCmmnSetColBit( datVctCrdtBrdg, 4 );
    DbCmmnSetColBit( datVctCrdtBrdg, 5 );
    DbCmmnSetColBit( datVctCrdtBrdg, 6 );
    DbCmmnSetColBit( datVctCrdtBrdg, 9 );
    DbCmmnSetColBit( datVctCrdtBrdg, 10 );

    infoSize = pBrdgCrdtUpdData->intInfoCount;
    for (index = 0; index < infoSize; index++){
        /* Update the data in table CRDT_BRDG */
        memset(&crdtBrdgData, 0x00, sizeof(CrdtBrdg));

        if (strlen(pBrdgCrdtUpdData->brdgCrdtDetail[index].strBrdgFee) == 0){
            RAISE_ERR(ERR_CODE_INVLD_BRDG_FEE, RTN);
        }

        crdtBrdgData.brdgOrgId = pBrdgCrdtUpdData->intOrgId;
        crdtBrdgData.orgId = pBrdgCrdtUpdData->brdgCrdtDetail[index].intOpOrgId;

        sprintf(crdtBrdgData.brdgRlF, "%d", pBrdgCrdtUpdData->brdgCrdtDetail[index].intCrdtRlf);
        crdtBrdgData.brdgFee = atof(pBrdgCrdtUpdData->brdgCrdtDetail[index].strBrdgFee);
        crdtBrdgData.crdtTerm = pBrdgCrdtUpdData->brdgCrdtDetail[index].intTerm;
        strcpy(crdtBrdgData.updTm, pBrdgCrdtUpdData->strSysTime);
        strcpy(crdtBrdgData.updUsrNm, pBrdgCrdtUpdData->strUserId);

        rc = UpdateCrdtBrdgByKey(connId, &crdtBrdgData, keyVctCrdtBrdg, datVctCrdtBrdg);
        RAISE_ERR(rc, RTN);

    }


    /* 桥授信解锁 */
    memset(&orgInfoBrdgData, 0x00, sizeof(OrgInfoBrdg));

    DbCmmnSetColBit( keyVctOrgInfoBrdg, 1 );

    DbCmmnSetColBit( datVctOrgInfoBrdg, 13 );
    DbCmmnSetColBit( datVctOrgInfoBrdg, 14 );
    DbCmmnSetColBit( datVctOrgInfoBrdg, 2 );
    DbCmmnSetColBit( datVctOrgInfoBrdg, 17 );
    DbCmmnSetColBit( datVctOrgInfoBrdg, 18 );


    orgInfoBrdgData.orgId = pBrdgCrdtUpdData->intOrgId;

    sprintf(orgInfoBrdgData.crdtOprtngSt, "%d", C_CRT_NONE);
    if (pBrdgCrdtUpdData->intModifyFlag == 0){
        memset(orgInfoBrdgData.crdtOprtr, 0x00, 100);
    }else{
        strcpy(orgInfoBrdgData.crdtOprtr, pBrdgCrdtUpdData->strUserId);
    }
    sprintf(orgInfoBrdgData.brdgOrgSt, "%d", pBrdgCrdtUpdData->intBrdgSt);
    strcpy(orgInfoBrdgData.updUsrNm, pBrdgCrdtUpdData->strUserId);
    strcpy(orgInfoBrdgData.updTm, pBrdgCrdtUpdData->strSysTime);

    rc = UpdateOrgInfoBrdgByKey(connId, &orgInfoBrdgData, keyVctOrgInfoBrdg, datVctOrgInfoBrdg);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** BridgeCreditPrintCallback
 **
 ******************************************************************************/
ResCodeT BridgeCreditPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "BridgeCreditPrintCallback" );
    ResCodeT rc = NO_ERR;

    BridgeCreditDataRefT* pRefData;

    pRefData = (BridgeCreditDataRefT*)pData;

    printf("BridgeCreditDataRefT: strUserId=%s, intInfoCount=%d, intModifyFlag=%d, strSysTime=%s.\n",
            pRefData->strUserId, pRefData->intInfoCount,
            pRefData->intModifyFlag, pRefData->strSysTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** BrdgOrgMemUnlockByOprtr
 **
 ******************************************************************************/
ResCodeT BrdgOrgMemUnlockByOprtr(char* newOprtrId, char* oldOprtrId)
{
    BEGIN_FUNCTION( "BrdgOrgMemUnlockByOprtr" );
    ResCodeT rc = NO_ERR;

    uint32 brdgOrgPos;
    pBrdgOrgInfoT pBrdgOrgData;

    brdgOrgPos = CMN_HASH_ITER_START;

    /* Loop the data of bridge organization stored in shared memory */
    while (TRUE)
    {
        /* Get the next available node of bridge organization */
        rc = BrdgOrgInfoIterExt(&brdgOrgPos, &pBrdgOrgData);
        RAISE_ERR(rc, RTN);

        if ( CMN_LIST_NULL_NODE == brdgOrgPos )
        {
            break;
        }

        if (strcmp(pBrdgOrgData->crdtOprtr, oldOprtrId) == 0){
            /* The credit operator of the current node matches the id that need to be updated */

            /* Update the value of credit operating status and credit operator */
            pBrdgOrgData->crdtOprtngSt = C_CRT_NONE;

            memset(pBrdgOrgData->crdtOprtr, 0x00, CREDIT_OPERATOR_LENGTH);
            strcpy(pBrdgOrgData->crdtOprtr, newOprtrId);
        }

    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/*------------------------- Base Parameters Update ------------------------------*/
/******************************************************************************
 **
 ** MarketInfoCfgMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT MarketInfoCfgMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MarketInfoCfgMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    MarketInfoCfgDataRefT* pMktInfoCfgData;
    pMktStCfgT pMktStCfg;

    pMktInfoCfgData = (MarketInfoCfgDataRefT*)pData;

    rc = MktStCfgGetByKeyExt(pMktInfoCfgData->intMktStCfgId , &pMktStCfg);
    RAISE_ERR(rc, RTN);

    memset(pMktStCfg->strtTm, 0x00, MKT_ST_CFG_START_TIME_LENGTH);
    strcpy(pMktStCfg->strtTm, pMktInfoCfgData->strTime);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** MarketInfoCfgDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT MarketInfoCfgDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MarketInfoCfgDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    MarketInfoCfgDataRefT* pMktInfoCfgData;

    vectorT  keyVct[GET_BIT_VECT_LEN(11)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(11)] = {0};
    MktStCfg mktStCfgData = {0};

    pMktInfoCfgData = (MarketInfoCfgDataRefT*)pData;

    mktStCfgData.mktStCfgId = pMktInfoCfgData->intMktStCfgId;

    DbCmmnSetColBit( keyVct, 0 );

    strcpy(mktStCfgData.updTm, pMktInfoCfgData->strSysTime);
    strcpy(mktStCfgData.updUsrNm, C_SYSTEM);
    strcpy(mktStCfgData.nextStrtTm, pMktInfoCfgData->strTime);

    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );

    rc = UpdateMktStCfgByKey(connId, &mktStCfgData, keyVct, datVct);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** MarketInfoCfgPrintCallback
 **
 ******************************************************************************/
ResCodeT MarketInfoCfgPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MarketInfoCfgPrintCallback" );
    ResCodeT rc = NO_ERR;

    MarketInfoCfgDataRefT* pRefData;

    pRefData = (MarketInfoCfgDataRefT*)pData;

    printf("MarketInfoCfgDataRefT: intMktStCfgId=%lld, strTime=%s, strSysTime=%s.\n",
            pRefData->intMktStCfgId, pRefData->strTime, pRefData->strSysTime);


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** MktInfoMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT MktInfoMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MktInfoMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    MktInfoDataRefT* pMktInfoData;
    char strOpenClsId[2];
    pBaseParamT pBaseParamData;
    pMktStCfgT pMktStCfgData;


    pMktInfoData = (MktInfoDataRefT*)pData;

    /* 市场状态配置数据是否需要更新 */
    if (pMktInfoData->intMktStCfgUpdFlag == 1){

        rc = MktStCfgGetByKeyExt(pMktInfoData->intMktStCfgId, &pMktStCfgData);
        RAISE_ERR(rc, RTN);

        pMktStCfgData->sendFlag = 1;

    }

    /* 基本参数数据是否需要更新 */
    if (pMktInfoData->intBaseParamUpdFlag == 1){
        /* Update the values in the shared memory */

        memset(strOpenClsId, 0x00, sizeof(strOpenClsId));
        sprintf(strOpenClsId, "%d", pMktInfoData->intOpenClsId);

        /* 市场状态 */
        if (pMktInfoData->intOpenClsId != C_MKT_ST_CLOSEQT_IRS){
            rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pBaseParamData);
            RAISE_ERR(rc, RTN);
            strcpy(pBaseParamData->paramValue, strOpenClsId);
        }

        /* 市场状态 */
        if (pMktInfoData->intOpenClsId != C_MKT_ST_CLOSEQT){
            rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pBaseParamData);
            RAISE_ERR(rc, RTN);
            strcpy(pBaseParamData->paramValue, strOpenClsId);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** MktInfoDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT MktInfoDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MktInfoDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    MktInfoDataRefT* pMktInfoData;

    vectorT  keyVct[GET_BIT_VECT_LEN(11)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(11)] = {0};
    MktStCfg mktStCfgData = {0};

    vectorT  keyVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    vectorT  datVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    BaseParam updData = {0};
    char strOpenClsId[2];


    pMktInfoData = (MktInfoDataRefT*)pData;

    /* 市场状态配置数据是否需要更新 */
    if (pMktInfoData->intMktStCfgUpdFlag == 1){
        memset(&mktStCfgData, 0x00, sizeof(MktStCfg));

        mktStCfgData.mktStCfgId = pMktInfoData->intMktStCfgId;

        DbCmmnSetColBit( keyVct, 0 );

        strcpy(mktStCfgData.updTm, pMktInfoData->strSysTime);
        mktStCfgData.sendF[0] = '1';

        DbCmmnSetColBit( datVct, 5 );
        DbCmmnSetColBit( datVct, 8 );

        rc = UpdateMktStCfgByKey(connId, &mktStCfgData, keyVct, datVct);
        RAISE_ERR(rc, RTN);
    }

    /* 基本参数数据是否需要更新 */
    if (pMktInfoData->intBaseParamUpdFlag == 1){
        /* Update the table BASE_PARAM */
        /* Init the variables used to update the DB */
        memset(strOpenClsId, 0x00, sizeof(strOpenClsId));

        sprintf(strOpenClsId, "%d", pMktInfoData->intOpenClsId);

        /* Update the values in the DB */
        DbCmmnSetColBit( keyVctBaseParam, 1 );

        DbCmmnSetColBit( datVctBaseParam, 2 );
        DbCmmnSetColBit( datVctBaseParam, 5 );
        DbCmmnSetColBit( datVctBaseParam, 6 );

        /* Set the update information */
        /* 市场状态 */
        if (pMktInfoData->intOpenClsId != C_MKT_ST_CLOSEQT_IRS){
            memset(&updData, 0x00, sizeof(BaseParam));

            strcpy(updData.paramVl, strOpenClsId);
            strcpy(updData.paramNm, C_MKT_ST);
            strcpy(updData.updUsrNm, C_SYSTEM);
            strcpy(updData.updTm, pMktInfoData->strSysTime);

            rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
            RAISE_ERR(rc, RTN);
        }

        /* 市场状态 */
        if (pMktInfoData->intOpenClsId != C_MKT_ST_CLOSEQT){
            memset(&updData, 0x00, sizeof(BaseParam));

            strcpy(updData.paramVl, strOpenClsId);
            strcpy(updData.paramNm, C_MKT_ST_IRS);
            strcpy(updData.updUsrNm, C_SYSTEM);
            strcpy(updData.updTm, pMktInfoData->strSysTime);

            rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** MktInfoPrintCallback
 **
 ******************************************************************************/
ResCodeT MktInfoPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MktInfoPrintCallback" );
    ResCodeT rc = NO_ERR;

    MktInfoDataRefT* pRefData;

    pRefData = (MktInfoDataRefT*)pData;

    printf("MktInfoDataRefT: intMktStCfgId=%lld, intOpenClsId=%d, strSysTime=%s, intMktStCfgUpdFlag=%d, intBaseParamUpdFlag=%d.\n",
            pRefData->intMktStCfgId, pRefData->intOpenClsId, pRefData->strSysTime,
            pRefData->intMktStCfgUpdFlag, pRefData->intBaseParamUpdFlag);


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** RiskMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT RiskMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskMemUpdateCallback" );
    ResCodeT            rc = NO_ERR;
    ResCodeT            rcLck = NO_ERR;
    CreditUpdateDataT   crdtData;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData            = (RiskUpdateDataT*)pData;
    memset(&crdtData, 0x00, sizeof(CreditUpdateDataT));
    crdtData.intOrgId       = pRiskUpdData->riskDataBase.intOrgId;
    crdtData.intCheckOrg    = 1;
    crdtData.intCrdtVldOrgFlag = pRiskUpdData->riskDataBase.intCrdtVldOrgFlag;

    rc      = RiskUpdateMem(pRiskUpdData);
    rcLck   = UpdateOrgInfoShareMemoryForCrdtUnlock(&crdtData);
    RAISE_ERR(rc, RTN);

    RAISE_ERR(rc, RTN);
    RAISE_ERR(rcLck, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** RiskDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT RiskDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskDbUpdateCallback" );
    ResCodeT            rc = NO_ERR;
    ResCodeT            rcLck = NO_ERR;
    CreditUpdateDataT   crdtData;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;

    memset(&crdtData, 0x00, sizeof(CreditUpdateDataT));
    crdtData.intOrgId       = pRiskUpdData->riskDataBase.intOrgId;
    memcpy(crdtData.strUserId, pRiskUpdData->riskDataBase.strUpdUsrNm,
        sizeof(crdtData.strUserId));
    rc = GetStrDateTimeByFormat(pRiskUpdData->riskDataBase.timestamp, crdtData.strUpdTm);
    RAISE_ERR(rc, RTN);
    crdtData.intCheckOrg    = 1;
    crdtData.intCrdtVldOrgFlag = pRiskUpdData->riskDataBase.intCrdtVldOrgFlag;

    rc      = RiskUpdateDb(connId, pRiskUpdData);
    rcLck = UpdateOrgInfoDbForCrdtUnlock(connId, &crdtData);

    RAISE_ERR(rc, RTN);
    RAISE_ERR(rcLck, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** RiskUpdatePrintCallback
 **
 ******************************************************************************/
ResCodeT RiskUpdatePrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskUpdatePrintCallback" );
    ResCodeT rc = NO_ERR;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;

    rc = RiskUpdatePrint(pRiskUpdData, dataLen);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** RiskUpdateMem
 **
 ******************************************************************************/
ResCodeT RiskUpdateMem(RiskUpdateDataT* pData)
{
    BEGIN_FUNCTION( "RiskUpdateMem" );
    ResCodeT            rc = NO_ERR;
    RiskCfcntT*         pRiskCfcnt = NULL;
    RiskCfcntSirsT*     pRiskCfcntSirs = NULL;
    int32 index;

    for (index = 0; index < pData->intCount; index++)
    {
        pRiskCfcnt = NULL;
        switch (pData->riskDataBase.setId)
        {
            case SET_MKT_IRS:
            {
                rc = IrsRiskCfcntGetByKeyExt(pData->riskDataBase.intOrgId,
                    pData->riskData[index].strCntrctNm, &pRiskCfcnt);
                RAISE_ERR(rc, RTN);
                pRiskCfcnt->rskCfcntVal = pData->riskData[index].intRiskCfcnt;

                rc = SirsRiskCfcntGetByKeyExt(pData->riskDataBase.intOrgId,
                    pData->riskData[index].strCntrctNm, &pRiskCfcntSirs);
                RAISE_ERR(rc, RTN);
                pRiskCfcntSirs->rskCfcntVal = pData->riskData[index].intRiskCfcnt;
            }
            break;
            case SET_MKT_SIRS:
            {
                rc = SirsRiskCfcntGetByKeyExt(pData->riskDataBase.intOrgId,
                    pData->riskData[index].strCntrctNm, &pRiskCfcntSirs);
                RAISE_ERR(rc, RTN);
                pRiskCfcntSirs->rskCfcntVal = pData->riskData[index].intRiskCfcnt;
            }
            default:
            {
                RAISE_ERR(ERR_CODE_INVLD_PARAM_CRDT_NUM, RTN);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 **  RiskUpdateDb
 **
 ******************************************************************************/
ResCodeT RiskUpdateDb(int32 connId, RiskUpdateDataT* pData)
{
    BEGIN_FUNCTION( "RiskUpdateDb" );
    ResCodeT        rc = NO_ERR;
    vectorT         keyVct[GET_BIT_VECT_LEN(11)] = {0};
    vectorT         datVct[GET_BIT_VECT_LEN(11)] = {0};
    RskCfcnt        data = {0};
    RskCfcntSirs    dataSirs = {0};
    int32           index;

    data.orgId      = pData->riskDataBase.intOrgId;
    memcpy(data.updUsrNm, pData->riskDataBase.strUpdUsrNm, sizeof(data.updUsrNm));
    rc = GetStrDateTimeByFormat(pData->riskDataBase.timestamp, data.updTm);
    RAISE_ERR(rc, RTN);

    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( keyVct, 2 );
    DbCmmnSetColBit( datVct, 3 );
    DbCmmnSetColBit( datVct, 8 );
    DbCmmnSetColBit( datVct, 10 );

    for (index = 0; index < pData->intCount; index++)
    {
        if ( pData->riskData[index].intRiskCfcnt >= C_RISK_MIN_UNIT &&
            pData->riskData[index].intRiskCfcnt <= C_RISK_MAX_UNIT )
        {
            data.rskCfcntVl = (double)(pData->riskData[index].intRiskCfcnt)/(double)PRICE_BASE;
            memcpy(data.cntrctNm, pData->riskData[index].strCntrctNm, MAX_CNTRCT_NM);
        }
        else
        {
            RAISE_ERR(ERR_CODE_INVLD_RCKCNF_OR, RTN);
        }

        memcpy(&dataSirs, &data, sizeof(RskCfcntSirs));

        switch (pData->riskDataBase.setId)
        {
            case SET_MKT_IRS:
            {
                rc = UpdateRskCfcntByKey(connId, &data, keyVct, datVct);
                RAISE_ERR(rc, RTN);
                rc = UpdateRskCfcntSirsByKey(connId, &dataSirs, keyVct, datVct);
                RAISE_ERR(rc, RTN);
            }
            break;
            case SET_MKT_SIRS:
            {
                rc = UpdateRskCfcntSirsByKey(connId, &dataSirs, keyVct, datVct);
                RAISE_ERR(rc, RTN);
            }
            default:
            {
                RAISE_ERR(ERR_CODE_INVLD_PARAM_CRDT_NUM, RTN);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** RiskUpdatePrint
 **
 ******************************************************************************/
ResCodeT RiskUpdatePrint(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskUpdatePrint" );
    ResCodeT    rc = NO_ERR;
    int32       index;
    char        strUpdTm[MAX_TIME_LENGTH] = {0};

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;
    rc = GetStrDateTimeByFormat(pRiskUpdData->riskDataBase.timestamp, strUpdTm);
    RAISE_ERR(rc, RTN);

    printf("RiskUpdate: intOrgId = %d, strUpdUsrNm = %.*s, strUpdTm = %.*s,\
intCount = %d\n",
        pRiskUpdData->riskDataBase.intOrgId,
        MAX_USR_ID_LENTH,
        pRiskUpdData->riskDataBase.strUpdUsrNm,
        MAX_TIME_LENGTH, strUpdTm,
        pRiskUpdData->intCount
        );

    for (index = 0; index < pRiskUpdData->intCount; index++)
    {
        printf("    riskData[%d].intRiskCfcnt = %d",  index,
            pRiskUpdData->riskData[index].intRiskCfcnt);
        printf("    riskData[%d].strCntrctNm = %d",   index,
            pRiskUpdData->riskData[index].strCntrctNm);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** RiskUnlockDb
 **
 ******************************************************************************/
ResCodeT RiskUnlockDb(int32 connId, void *pData)
{
    BEGIN_FUNCTION( "RiskUnlockDb" );
    ResCodeT rc = NO_ERR;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;

    vectorT  keyVct[GET_BIT_VECT_LEN(29)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(29)] = {0};

    OrgInfo data;
    memset(&data, 0x00, sizeof(OrgInfo));

    // set key value.
    data.orgId = pRiskUpdData->riskDataBase.intOrgId;
    DbCmmnSetColBit( keyVct, 1 );

    // set data value.
    sprintf(data.crdtOprtngSt, "%d", C_CRT_NONE);
    strcpy(data.crdtOprtr, "");
    strcpy(data.updUsrNm, pRiskUpdData->riskDataBase.strUpdUsrNm);
    rc = GetStrDateTimeByFormat(pRiskUpdData->riskDataBase.timestamp, data.updTm);
    RAISE_ERR(rc, RTN);

    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** RiskMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT RiskMemUnlockCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskMemUpdateCallback" );
    ResCodeT            rc = NO_ERR;
    CreditUpdateDataT   crdtData;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;

    memset(&crdtData, 0x00, sizeof(CreditUpdateDataT));
    crdtData.intOrgId       = pRiskUpdData->riskDataBase.intOrgId;
    crdtData.intCheckOrg    = 1;
    crdtData.intCrdtVldOrgFlag = pRiskUpdData->riskDataBase.intCrdtVldOrgFlag;

    rc = UpdateOrgInfoShareMemoryForCrdtUnlock(&crdtData);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** RiskDbUnlockCallback
 **
 ******************************************************************************/
ResCodeT RiskDbUnlockCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskDbUnlockCallback" );
    ResCodeT            rc = NO_ERR;
    CreditUpdateDataT   crdtData;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;

    memset(&crdtData, 0x00, sizeof(CreditUpdateDataT));
    crdtData.intOrgId       = pRiskUpdData->riskDataBase.intOrgId;
    memcpy(crdtData.strUserId, pRiskUpdData->riskDataBase.strUpdUsrNm,
        sizeof(crdtData.strUserId));
    rc = GetStrDateTimeByFormat(pRiskUpdData->riskDataBase.timestamp, crdtData.strUpdTm);
    RAISE_ERR(rc, RTN);
    crdtData.intCheckOrg    = 1;
    crdtData.intCrdtVldOrgFlag = pRiskUpdData->riskDataBase.intCrdtVldOrgFlag;

    rc = UpdateOrgInfoDbForCrdtUnlock(connId, &crdtData);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** RiskUpdatePrintCallback
 **
 ******************************************************************************/
ResCodeT RiskUnlockPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "RiskUpdatePrintCallback" );
    ResCodeT rc = NO_ERR;

    RiskUpdateDataT* pRiskUpdData = NULL;
    pRiskUpdData = (RiskUpdateDataT*)pData;

    rc = RiskUpdatePrint(pRiskUpdData, dataLen);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** SetlPrcMemModifyCallback
 **
 ******************************************************************************/
ResCodeT SetlPrcMemModifyCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SetlPrcMemModifyCallback" );
    ResCodeT            rc = NO_ERR;
    pSetlPrcDataRefT    pSetlPrc = NULL;
    pPrdctInfoT         pPrdctInfo = NULL;

    pSetlPrc  = (pSetlPrcDataRefT)pData;
    rc = PrdctInfoGetByNameExt( pSetlPrc->strCntrctNm, &pPrdctInfo );
    RAISE_ERR(rc, RTN);

    pPrdctInfo->baseInfo.intraRefPrc    = pSetlPrc->stlPrice;
    pPrdctInfo->baseInfo.lstUpdateTim   = pSetlPrc->timestamp;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** SirsSetlPrcDbModify
 **
 ******************************************************************************/
ResCodeT SirsSetlPrcDbModify(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SirsSetlPrcDbModify" );
    ResCodeT            rc = NO_ERR;
    pSetlPrcDataRefT    pSetlPrc = NULL;
    vectorT             keyVct[GET_BIT_VECT_LEN(11)] = {0};
    vectorT             datVct[GET_BIT_VECT_LEN(11)] = {0};
    char                dateTime[MAX_DATETIME_LEN] = {0};
    CntrctRefPrcSirs    data;
    CntrctRefPrcHstrySirs  dataHstry;

    memset(&data, 0x00, sizeof(CntrctRefPrcSirs));
    memset(&dataHstry, 0x00, sizeof(CntrctRefPrcHstrySirs));

    pSetlPrc = (pSetlPrcDataRefT)pData;
    data.refPrc = (double)(pSetlPrc->stlPrice)/(double)PRICE_BASE;
    dataHstry.refPrc = data.refPrc;
    memcpy(data.updUsrNm, pSetlPrc->strUserId, sizeof(data.updUsrNm));
    memcpy(dataHstry.updUsrNm, pSetlPrc->strUserId, sizeof(dataHstry.updUsrNm));
    rc = GetStrDateTimeByFormat(pSetlPrc->timestamp, data.updTm);
    RAISE_ERR(rc, RTN);
    memcpy(dataHstry.updTm, data.updTm, sizeof(dataHstry.updTm));

    memcpy(data.cntrctCd, pSetlPrc->strCntrctNm, sizeof(data.cntrctCd));
    memcpy(dataHstry.cntrctCd, pSetlPrc->strCntrctNm, sizeof(dataHstry.cntrctCd));

    GetStrDateTimeByFormat(pSetlPrc->timestamp, dateTime);
    memcpy(data.refPrcDt, dateTime, sizeof(data.refPrcDt));
    memcpy(dataHstry.refPrcDt, dateTime, sizeof(dataHstry.refPrcDt));

    /*  Update  sirscntrct table  */
    DbCmmnSetColBit( keyVct, 2 );
    DbCmmnSetColBit( keyVct, 3 );
    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 9 );
    DbCmmnSetColBit( datVct, 11 );

    rc = UpdateCntrctRefPrcSirsByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    /*  Update history sirscntrct table  */
    DbCmmnSetColBit( keyVct, 4 );
    DbCmmnSetColBit( keyVct, 5 );
    DbCmmnSetColBit( datVct, 7 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 13 );

    rc = UpdateCntrctRefPrcHstrySirsByKey(connId, &dataHstry, keyVct, datVct);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** SbfCCPSetlPrcDbModify
 **
 ******************************************************************************/
ResCodeT SbfCCPSetlPrcDbModify(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SbfCCPSetlPrcDbModify" );
    ResCodeT            rc = NO_ERR;
    pSetlPrcDataRefT    pSetlPrc = NULL;
    vectorT             keyVct[GET_BIT_VECT_LEN(11)] = {0};
    vectorT             datVct[GET_BIT_VECT_LEN(11)] = {0};
    char                dateTime[MAX_DATETIME_LEN] = {0};
    CntrctRefPrcSbfccp  data;
    CntrctRefPrcHstrySbfccp  dataHstry;

    memset(&data, 0x00, sizeof(CntrctRefPrcSbfccp));
    memset(&dataHstry, 0x00, sizeof(CntrctRefPrcHstrySbfccp));
    
    pSetlPrc = (pSetlPrcDataRefT)pData;
    data.refPrc = (double)(pSetlPrc->stlPrice)/(double)PRICE_BASE;
    dataHstry.refPrc = data.refPrc;
    memcpy(data.updUsrNm, pSetlPrc->strUserId, sizeof(data.updUsrNm));
    memcpy(dataHstry.updUsrNm, pSetlPrc->strUserId, sizeof(dataHstry.updUsrNm));
    rc = GetStrDateTimeByFormat(pSetlPrc->timestamp, data.updTm);
    RAISE_ERR(rc, RTN);
    memcpy(dataHstry.updTm, data.updTm, sizeof(dataHstry.updTm));

    memcpy(data.cntrctCd, pSetlPrc->strCntrctNm, sizeof(data.cntrctCd));
    memcpy(dataHstry.cntrctCd, pSetlPrc->strCntrctNm, sizeof(dataHstry.cntrctCd));

    GetStrDateTimeByFormat(pSetlPrc->timestamp, dateTime);
    memcpy(data.refPrcDt, dateTime, sizeof(data.refPrcDt));
    memcpy(dataHstry.refPrcDt, dateTime, sizeof(dataHstry.refPrcDt));

    /*  Update sbfccpcntrct table  */
    DbCmmnSetColBit( keyVct, 2 );
    DbCmmnSetColBit( keyVct, 3 );
    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 9 );
    DbCmmnSetColBit( datVct, 11 );

    rc = UpdateCntrctRefPrcSbfccpByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    /*  Update history sbfccpcntrct table  */
    DbCmmnSetColBit( keyVct, 4 );
    DbCmmnSetColBit( keyVct, 5 );
    DbCmmnSetColBit( datVct, 7 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 13 );

    rc = UpdateCntrctRefPrcHstrySbfccpByKey(connId, &dataHstry, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 **
 ** SetlPrcDbModifyCallback
 **
 ******************************************************************************/
ResCodeT SetlPrcDbModifyCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SetlPrcDbModifyCallback" );
    ResCodeT            rc = NO_ERR;
    pSetlPrcDataRefT    pSetlPrc = NULL;

    pSetlPrc = (pSetlPrcDataRefT)pData;

    if (SET_MKT_SIRS == pSetlPrc->setId)
    {
        rc = SirsSetlPrcDbModify(connId, pData, dataLen);
        RAISE_ERR(rc, RTN);
    }
    else if (SET_MKT_SBFCCP == pSetlPrc->setId)
    {
        rc = SbfCCPSetlPrcDbModify(connId, pData, dataLen);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** SetlPrcModifyPrintCallback
 **
 ******************************************************************************/
ResCodeT SetlPrcModifyPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SetlPrcModifyPrintCallback" );
    ResCodeT            rc = NO_ERR;
    pSetlPrcDataRefT    pSetlPrc = NULL;
    pPrdctInfoT         pPrdctInfo = NULL;

    pSetlPrc  = (pSetlPrcDataRefT)pData;

    printf("SetlPrcModify: stlPrice = %lld, timestamp = %lld, setId = %d,"
"strUserId=%.*s, strCntrctNm=%.*s, strPriceDate=%.*s\n",
        pSetlPrc->stlPrice, pSetlPrc->timestamp, pSetlPrc->setId,
        MAX_USR_ID_LENTH, pSetlPrc->strUserId,
        MAX_CNTRCT_NM, pSetlPrc->strCntrctNm,
        MAX_TIME_LENGTH, pSetlPrc->strPriceDate);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CCPCrdtMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT CCPCrdtMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CCPCrdtMemUpdateCallback" );
    ResCodeT            rc = NO_ERR;
    pCCPCreditDataRefT  pCCPCrdt = NULL;
    CreditSbfCcpT       crdtData;
    int64               tmpCrdtAmnt = 0;  /*  */
    int64               tmpBidTotl = 0;   /* 买方总额度 */
    int64               tmpOfrTotl = 0;   /* 卖方总额度 */
    int64               tmpBidRmn  = 0;   /* 买方剩余额度 */
    int64               tmpOfrRmn  = 0;   /* 卖方剩余额度 */
//    NewOrderSingleRspT  orderRsp;
    pOrgInfoT           pOrgInfo = NULL;
    UsrBaseInfoT        user;
    ClrHoldCrdtResultT  clrHldCrdtData;
    uint64              pstnPos = CMN_LIST_NULL_NODE;
    pCntrctPstnSbfCcpT  pCntrctPstnData;

#if 0
    pCCPCrdt = (pCCPCreditDataRefT)pData;

    if (pCCPCrdt->crdtAmnt > MAX_CCP_CRDT_AMNT || pCCPCrdt->crdtAmnt < 0)
    {
        RAISE_ERR(ERR_CODE_INVLD_CRDT_PSTN, RTN);
    }

    memset(&crdtData, 0x00, sizeof(CreditSbfCcpT));
    rc = CreditSbfCcpInfoGetByKey(pCCPCrdt->intOrgId, &crdtData);
    RAISE_ERR(rc, RTN);

    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(pCCPCrdt->intOrgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    memset(&user, 0x00, sizeof(UsrBaseInfoT));
    rc = IrsUsrInfoGetByName((char*)SYSTEM_USR_NAME, &user);
    RAISE_ERR(rc, RTN);

    if (C_SHCH_LMTPSTN_ON == crdtData.lmtPstnFlag )
    {
        tmpCrdtAmnt = pCCPCrdt->crdtAmnt/2;
        if (tmpCrdtAmnt > crdtData.intlAmnt && tmpCrdtAmnt > crdtData.bidUsedAmnt &&
            (-1*tmpCrdtAmnt < crdtData.ofrUsedAmnt))
        {
            /* 限仓模式解除 */
            memset(&clrHldCrdtData, 0x00, sizeof(ClrHoldCrdtResultT));
            rc = ClearHoldCredit(pCCPCrdt->intOrgId, &clrHldCrdtData);
            RAISE_ERR(rc, RTN);

            
            if ((clrHldCrdtData.bidUsedAmnt <= crdtData.bidIntlAmnt && clrHldCrdtData.ofrUsedAmnt > crdtData.ofrIntlAmnt) ||
                (clrHldCrdtData.bidUsedAmnt < crdtData.bidIntlAmnt && clrHldCrdtData.ofrUsedAmnt >= crdtData.ofrIntlAmnt) ||
                (0 == clrHldCrdtData.bidUsedAmnt && 0 == crdtData.bidIntlAmnt && 
                0 == clrHldCrdtData.ofrUsedAmnt && 0 == crdtData.ofrIntlAmnt))
            {
                crdtData.lmtPstnFlag = C_SHCH_LMTPSTN_OFF;
            }
            
            /*  需要确认用户是有效的*/
  /*  UPDATE OCO_ORDR_SBFCCP
       SET ST         = PCK_IRS_DICDATA.C_ORD_STATUS_FROZEN,
           UPD_TM     = CURRENT_TIMESTAMP,
           UPD_USR_NM = 'SYSTEM'
     WHERE TRDR_NM IN (SELECT USR_LGN_NM FROM USR WHERE ORG_ID = IN_ORGID);
     */
            
            /* 更新客户端订单状态为冻结 */
            memset(&orderRsp, 0x00, sizeof(NewOrderSingleRspT));
            rc = MtchrPrcsFreezeOrgOrdrBySet(pCCPCrdt->setId, pCCPCrdt->intOrgId, 
                pCCPCrdt->timestamp, &orderRsp);
            RAISE_ERR(rc, RTN);

            /* 更新API订单状态为撤销 */
            memset(&orderRsp, 0x00, sizeof(NewOrderSingleRspT));
            rc = MtchrPrcsOrdrCnclByUser(pCCPCrdt->setId, pCCPCrdt->timestamp, user.pos, pOrgInfo->pos, &orderRsp);
                    RAISE_ERR(rc, RTN);   
    
        }
        else
        {
            ;/* 持仓额度更新 */
        }
    }
    else
    {
        tmpBidTotl = crdtData.bidHoldAmnt+ crdtData.bidUsedAmnt;
        tmpOfrTotl = crdtData.ofrHoldAmnt+ crdtData.ofrUsedAmnt;
        if ((tmpCrdtAmnt > crdtData.intlAmnt) ||
            (tmpCrdtAmnt > tmpBidTotl && -1*tmpCrdtAmnt < tmpOfrTotl))
        {
            ; /* 持仓额度更新 */
        }
        else
        {
            /* 进入限仓模式*/
            memset(&clrHldCrdtData, 0x00, sizeof(ClrHoldCrdtResultT));
            rc = ClearHoldCredit(pCCPCrdt->intOrgId, &clrHldCrdtData);
            RAISE_ERR(rc, RTN);

            
            if ((clrHldCrdtData.bidUsedAmnt > crdtData.bidIntlAmnt ||
                 clrHldCrdtData.ofrUsedAmnt < crdtData.ofrIntlAmnt) ||
                (clrHldCrdtData.bidUsedAmnt == crdtData.bidIntlAmnt && clrHldCrdtData.ofrUsedAmnt == crdtData.ofrIntlAmnt))
            {
                crdtData.lmtPstnFlag = C_SHCH_LMTPSTN_ON;
            }
            
            /*  需要确认用户是有效的*/
  /*  UPDATE OCO_ORDR_SBFCCP
       SET ST         = PCK_IRS_DICDATA.C_ORD_STATUS_FROZEN,
           UPD_TM     = CURRENT_TIMESTAMP,
           UPD_USR_NM = 'SYSTEM'
     WHERE TRDR_NM IN (SELECT USR_LGN_NM FROM USR WHERE ORG_ID = IN_ORGID);
     */
            
            /* 更新客户端订单状态为冻结 */
            memset(&orderRsp, 0x00, sizeof(NewOrderSingleRspT));
            rc = MtchrPrcsFreezeOrgOrdrBySet(pCCPCrdt->setId, pCCPCrdt->intOrgId, 
                pCCPCrdt->timestamp, &orderRsp);
            RAISE_ERR(rc, RTN);

            /* 更新API订单状态为撤销 */
            memset(&orderRsp, 0x00, sizeof(NewOrderSingleRspT));
            rc = MtchrPrcsOrdrCnclByUser(pCCPCrdt->setId, pCCPCrdt->timestamp, user.pos, pOrgInfo->pos, &orderRsp);
                    RAISE_ERR(rc, RTN);   


            if (tmpCrdtAmnt > crdtData.bidUsedAmnt && (-1*tmpCrdtAmnt < crdtData.ofrUsedAmnt))
            {
                ; /* '持仓额度更新' */
            }
            else
            {
                ; /* 进入限仓模式 */
            }     
        }
    }

    crdtData.bidHoldAmnt = 0;
    crdtData.bidUsedAmnt = clrHldCrdtData.bidUsedAmnt;
    crdtData.bidRmnAmnt  = clrHldCrdtData.bidRmnAmnt;
    crdtData.ofrHoldAmnt = 0;
    crdtData.ofrUsedAmnt = clrHldCrdtData.ofrUsedAmnt;
    crdtData.ofrRmnAmnt  = clrHldCrdtData.ofrRmnAmnt;

    while (TRUE)
    {    
        rc = CntrctPstnSbfCcpIterExt(&pstnPos, &pCntrctPstnData);
        RAISE_ERR(rc,RTN);
        
        if ( CMN_LIST_NULL_NODE == pstnPos )
        {
            break;
        }
        
        if (pCntrctPstnData->orgId == pCCPCrdt->intOrgId)
        {
            pCntrctPstnData->bidHoldAmnt = 0;
            pCntrctPstnData->ofrHoldAmnt = 0;
        }
    }

#endif
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CCPCrdtDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT CCPCrdtDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CCPCrdtDbUpdateCallback" );
    ResCodeT            rc = NO_ERR;
    vectorT             keyVct[GET_BIT_VECT_LEN(20)] = {0};
    vectorT             datVct[GET_BIT_VECT_LEN(20)] = {0};
    CrdtSbfccp          data;
    pCCPCreditDataRefT  pCCPCrdt = NULL;
    CreditSbfCcpT       crdtData;
    int64               tmpCrdtAmnt = 0;  /*  */
    int64               tmpBidTotl = 0;   /* 买方总额度 */
    int64               tmpOfrTotl = 0;   /* 卖方总额度 */
    int64               tmpBidRmn  = 0;   /* 买方剩余额度 */
    int64               tmpOfrRmn  = 0;   /* 卖方剩余额度 */
#if 0
    ClrHoldCrdtResultT  clrHldCrdtData;


    pCCPCrdt = (pCCPCreditDataRefT)pData;    

    if (pCCPCrdt->crdtAmnt > MAX_CCP_CRDT_AMNT || pCCPCrdt->crdtAmnt < 0)
    {
        RAISE_ERR(ERR_CODE_INVLD_CRDT_PSTN, RTN);
    }

    memset(&crdtData, 0x00, sizeof(CreditSbfCcpT));
    rc = CreditSbfCcpInfoGetByKey(pCCPCrdt->intOrgId, &crdtData);
    RAISE_ERR(rc, RTN);
    memset(&data, 0x00, sizeof(CrdtSbfccp));

    if (C_SHCH_LMTPSTN_ON == crdtData.lmtPstnFlag )
    {
        tmpCrdtAmnt = pCCPCrdt->crdtAmnt/2;
        if (tmpCrdtAmnt > crdtData.intlAmnt && tmpCrdtAmnt > crdtData.bidUsedAmnt &&
            (-1*tmpCrdtAmnt < crdtData.ofrUsedAmnt))
        {
            /* 限仓模式解除 */
            memset(&clrHldCrdtData, 0x00, sizeof(ClrHoldCrdtResultT));
            rc = ClearHoldCredit(pCCPCrdt->intOrgId, &clrHldCrdtData);
            RAISE_ERR(rc, RTN);

            
            if ((clrHldCrdtData.bidUsedAmnt <= crdtData.bidIntlAmnt && clrHldCrdtData.ofrUsedAmnt > crdtData.ofrIntlAmnt) ||
                (clrHldCrdtData.bidUsedAmnt < crdtData.bidIntlAmnt && clrHldCrdtData.ofrUsedAmnt >= crdtData.ofrIntlAmnt) ||
                (0 == clrHldCrdtData.bidUsedAmnt && 0 == crdtData.bidIntlAmnt && 
                0 == clrHldCrdtData.ofrUsedAmnt && 0 == crdtData.ofrIntlAmnt))
            {
                crdtData.lmtPstnFlag = C_SHCH_LMTPSTN_OFF;
                snprintf(data.lmtPstnF, sizeof(data.lmtPstnF), "%d", C_SHCH_LMTPSTN_OFF);
            }
            
            /*  需要确认用户是有效的*/
  /*  UPDATE OCO_ORDR_SBFCCP
       SET ST         = PCK_IRS_DICDATA.C_ORD_STATUS_FROZEN,
           UPD_TM     = CURRENT_TIMESTAMP,
           UPD_USR_NM = 'SYSTEM'
     WHERE TRDR_NM IN (SELECT USR_LGN_NM FROM USR WHERE ORG_ID = IN_ORGID);
     */  
        }
        else
        {
            ;/* 持仓额度更新 */
        }
    }
    else
    {
        tmpBidTotl = crdtData.bidHoldAmnt+ crdtData.bidUsedAmnt;
        tmpOfrTotl = crdtData.ofrHoldAmnt+ crdtData.ofrUsedAmnt;
        if ((tmpCrdtAmnt > crdtData.intlAmnt) ||
            (tmpCrdtAmnt > tmpBidTotl && -1*tmpCrdtAmnt < tmpOfrTotl))
        {
            ; /* 持仓额度更新 */
        }
        else
        {
            /* 进入限仓模式*/
            memset(&clrHldCrdtData, 0x00, sizeof(ClrHoldCrdtResultT));
            rc = ClearHoldCredit(pCCPCrdt->intOrgId, &clrHldCrdtData);
            RAISE_ERR(rc, RTN);

            
            if ((clrHldCrdtData.bidUsedAmnt > crdtData.bidIntlAmnt ||
                 clrHldCrdtData.ofrUsedAmnt < crdtData.ofrIntlAmnt) ||
                (clrHldCrdtData.bidUsedAmnt == crdtData.bidIntlAmnt && clrHldCrdtData.ofrUsedAmnt == crdtData.ofrIntlAmnt))
            {
                crdtData.lmtPstnFlag = C_SHCH_LMTPSTN_ON;
                snprintf(data.lmtPstnF, sizeof(data.lmtPstnF), "%d", C_SHCH_LMTPSTN_ON);
            }
            
            /*  需要确认用户是有效的*/
  /*  UPDATE OCO_ORDR_SBFCCP
       SET ST         = PCK_IRS_DICDATA.C_ORD_STATUS_FROZEN,
           UPD_TM     = CURRENT_TIMESTAMP,
           UPD_USR_NM = 'SYSTEM'
     WHERE TRDR_NM IN (SELECT USR_LGN_NM FROM USR WHERE ORG_ID = IN_ORGID);
     */
            if (tmpCrdtAmnt > crdtData.bidUsedAmnt && (-1*tmpCrdtAmnt < crdtData.ofrUsedAmnt))
            {
                ; /* '持仓额度更新' */
            }
            else
            {
                ; /* 进入限仓模式 */
            }          
        }
    }

    tmpBidRmn = tmpCrdtAmnt - crdtData.bidUsedAmnt;
    tmpOfrRmn = -1*tmpCrdtAmnt - crdtData.ofrUsedAmnt;

    tmpBidRmn = (tmpBidRmn < 0) ? 0 : tmpBidRmn;
    tmpOfrRmn = (tmpOfrRmn > 0) ? 0 : tmpOfrRmn;


    /* 更新限额 */

    data.intlAmnt = (double)pCCPCrdt->crdtAmnt;
    data.bidIntlAmnt = (double)pCCPCrdt->crdtAmnt/(double)(2*PRICE_BASE);
    data.ofrIntlAmnt = (-1.0) * data.bidIntlAmnt;
    data.orgId    = pCCPCrdt->intOrgId;

    data.bidRmnAmnt = (double)tmpBidRmn/(double)PRICE_BASE;
    data.ofrRmnAmnt = (double)tmpBidRmn/(double)PRICE_BASE;
    data.orgId  = pCCPCrdt->intOrgId;
    memcpy(data.updUsrNm, pCCPCrdt->timestamp;
    memcpy(data.updUsrNm, C_SHCH, sizeof(data.updUsrNm));
    rc = GetStrDateTimeByFormat(pCCPCrdt->timestamp, data.updTm);
    RAISE_ERR(rc, RTN);

 //   if (crdtData.lmtPstnFlag == C_SHCH_LMTPSTN_ON)
    data.lmtPstnF = (double)pCCPCrdt->crdtAmnt;

    DbCmmnSetColBit( keyVct, 2 );

    DbCmmnSetColBit( datVct, 3 );    /* lmtPstnF */
    
    DbCmmnSetColBit( datVct, 6 );    /* bidIntlAmnt */
    DbCmmnSetColBit( datVct, 7 );    /* bidUsedAmnt */
    DbCmmnSetColBit( datVct, 11 );   /* ofrUsedAmnt */

    DbCmmnSetColBit( datVct, 10 );   /* ofrIntlAmnt  */
    DbCmmnSetColBit( datVct, 14 );   /* ofrRmnAmnt  */
    DbCmmnSetColBit( datVct, 18 );   /* updTm  */
    DbCmmnSetColBit( datVct, 20 );   /* updUsrNm  */

    rc = UpdateCrdtSbfccpByKey(connId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);
#endif
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CCPCrdtUpdatePrintCallback
 **
 ******************************************************************************/
ResCodeT CCPCrdtUpdatePrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CCPCrdtUpdatePrintCallback" );
    ResCodeT            rc = NO_ERR;
    pCCPCreditDataRefT  pCCPCrdt = NULL;
    OrgInfoT            orgInfo = {0};

    pCCPCrdt = (pCCPCreditDataRefT)pData;

    rc = OrgInfoGetById(pCCPCrdt->intOrgId, &orgInfo);
    RAISE_ERR(rc, RTN);

    printf("CCPCrdtUpdate: OrgCode = %.*s, strUpdUsrNm = %lld, setId = %d\n",
        ORG_CODE_LENGTH, orgInfo.orgCd, pCCPCrdt->crdtAmnt, pCCPCrdt->setId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** SbfCcpCrdtLimitMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT SbfCcpCrdtLimitMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SbfCcpCrdtLimitMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    pCreditSbfCcpT pCrdtData;
    pCntrctPstnSbfCcpT pPstnData;
    SbfCcpCrdtLimitDataRefT* pRefData;
    uint32 pstnPos = CMN_LIST_NULL_NODE;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    rc = CreditSbfCcpInfoGetByKeyExt(pRefData->intOrgId, &pCrdtData);
    RAISE_ERR(rc, RTN);

    /* Update the initial amount of CRDT_SBFCCP */
    pCrdtData->intlAmnt = pRefData->intlAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    pCrdtData->bidIntlAmnt = pRefData->bidIntlAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    pCrdtData->ofrIntlAmnt = pRefData->ofrIntlAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);

    /* Update the remain amount of CRDT_SBFCCP */
    pCrdtData->bidRmnAmnt = pRefData->bidRmnAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    pCrdtData->ofrRmnAmnt = pRefData->ofrRmnAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);

    /* Check if it is need to update the hold amount & used amount */
    if (pRefData->ordFrzFlag == TRUE){
        /* Update hold amount & used amount of CRDT_SBFCCP */
        pCrdtData->bidHoldAmnt = pRefData->bidHoldAmnt;
        pCrdtData->bidUsedAmnt = pRefData->bidUsedAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
        pCrdtData->ofrHoldAmnt = pRefData->ofrHoldAmnt;
        pCrdtData->ofrUsedAmnt = pRefData->ofrUsedAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);

        /* Update the hold amount of CNTRCT_PSTN_SBFCCP */
        while (TRUE)
        {
            rc = CntrctPstnSbfCcpIterExt(&pstnPos, &pPstnData);
            RAISE_ERR(rc,RTN);

            if ( CMN_LIST_NULL_NODE == pstnPos )
            {
                break;
            }

            /* Check if the org id is equal to org id in RefData. */
            if (pPstnData->orgId == pRefData->intOrgId){
                /* Set the hold amount of Bid/Offer side to 0 */
                pPstnData->bidHoldAmnt = pRefData->pstnBidHoldAmnt;
                pPstnData->ofrHoldAmnt = pRefData->pstnOfrHoldAmnt;

            }
        }

        /* Check if it's need to update the limit position flag of CRDT_SBFCCP */
        if (pRefData->isLmtPstnUpdated == TRUE){
            pCrdtData->lmtPstnFlag = pRefData->lmtPstnFlagValue;
        }

    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** SbfCcpCrdtLimitDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT SbfCcpCrdtLimitDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SbfCcpCrdtLimitDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVctCrdtSbfCcp[GET_BIT_VECT_LEN(18)] = {0};
    vectorT  datVctCrdtSbfCcp[GET_BIT_VECT_LEN(18)] = {0};
    CrdtSbfccp crdtSbfCcpData;

    vectorT  keyVctCntrctPstn[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVctCntrctPstn[GET_BIT_VECT_LEN(10)] = {0};
    CntrctPstnSbfccp cntrctPstnData;

    SbfCcpCrdtLimitDataRefT* pRefData;


    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    memset(&crdtSbfCcpData, 0x00, sizeof(CrdtSbfccp));
    memset(&cntrctPstnData, 0x00, sizeof(CntrctPstnSbfccp));

    /* Set the update key of CRDT_SBFCCP & CNTRCT_PSTN_SBFCCP */
    DbCmmnSetColBit( keyVctCrdtSbfCcp, 1 );
    DbCmmnSetColBit( keyVctCntrctPstn, 1 );
    crdtSbfCcpData.orgId = pRefData->intOrgId;
    cntrctPstnData.orgId = pRefData->intOrgId;

    /* Update the initial amount of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 5 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 6 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 10 );
    crdtSbfCcpData.intlAmnt = pRefData->intlAmnt;
    crdtSbfCcpData.bidIntlAmnt = pRefData->bidIntlAmnt;
    crdtSbfCcpData.ofrIntlAmnt = pRefData->ofrIntlAmnt;

    /* Update the remain amount of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 9 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 13 );
    crdtSbfCcpData.bidRmnAmnt = pRefData->bidRmnAmnt;
    crdtSbfCcpData.ofrRmnAmnt = pRefData->ofrRmnAmnt;


    /* Check if it is need to update the hold amount & used amount */
    if (pRefData->ordFrzFlag == TRUE){
        /* Update hold amount & used amount of CRDT_SBFCCP */
        DbCmmnSetColBit( datVctCrdtSbfCcp, 7 );
        DbCmmnSetColBit( datVctCrdtSbfCcp, 8 );
        DbCmmnSetColBit( datVctCrdtSbfCcp, 11 );
        DbCmmnSetColBit( datVctCrdtSbfCcp, 12 );
        crdtSbfCcpData.bidHoldAmnt = pRefData->bidHoldAmnt;
        crdtSbfCcpData.bidUsedAmnt = pRefData->bidUsedAmnt;
        crdtSbfCcpData.ofrHoldAmnt = pRefData->ofrHoldAmnt;
        crdtSbfCcpData.ofrUsedAmnt = pRefData->ofrUsedAmnt;


        /* Update the hold amount of CNTRCT_PSTN_SBFCCP */
        DbCmmnSetColBit( datVctCntrctPstn, 4 );
        DbCmmnSetColBit( datVctCntrctPstn, 5 );
        cntrctPstnData.bidHoldAmnt = pRefData->pstnBidHoldAmnt;
        cntrctPstnData.ofrHoldAmnt = pRefData->pstnOfrHoldAmnt;


        /* Check if it's need to update the limit position flag of CRDT_SBFCCP */
        if (pRefData->isLmtPstnUpdated == TRUE){
            DbCmmnSetColBit( datVctCrdtSbfCcp, 3 );
            sprintf(crdtSbfCcpData.lmtPstnF, "%d", pRefData->lmtPstnFlagValue);
        }

    }

    /* Set update user name & update time of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 16 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 17 );
    strcpy(crdtSbfCcpData.updTm, pRefData->strSysTime);
    strcpy(crdtSbfCcpData.updUsrNm, C_SHCH);


    rc = UpdateCrdtSbfccpByKey(connId, &crdtSbfCcpData, keyVctCrdtSbfCcp, datVctCrdtSbfCcp);
    RAISE_ERR(rc, RTN);

    /* Check if it is need to update the hold amount & used amount */
    if (pRefData->ordFrzFlag == TRUE){
        rc = UpdateCntrctPstnSbfccpByKey(connId, &cntrctPstnData, keyVctCntrctPstn, datVctCntrctPstn);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** SbfCcpCrdtLimitPrintCallback
 **
 ******************************************************************************/
ResCodeT SbfCcpCrdtLimitPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "SbfCcpCrdtLimitPrintCallback" );
    ResCodeT rc = NO_ERR;

    SbfCcpCrdtLimitDataRefT* pRefData;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    printf("SbfCcpCrdtLimitDataRefT: intOrgId=%d, intlAmnt=%lf, bidIntlAmnt=%lf, ofrIntlAmnt=%lf, "
           "ordFrzFlag=%d, isLmtPstnUpdated=%d, lmtPstnFlagValue=%d, bidUsedAmnt=%lf, "
           "bidRmnAmnt=%lf, bidHoldAmnt=%lf, ofrUsedAmnt=%lf, ofrRmnAmnt=%lf, "
           "ofrHoldAmnt=%lf, pstnBidHoldAmnt=%lf, pstnOfrHoldAmnt=%lf, strSysTime=%s.\n",
            pRefData->intOrgId, pRefData->intlAmnt, pRefData->bidIntlAmnt, pRefData->ofrIntlAmnt,
            pRefData->ordFrzFlag, pRefData->isLmtPstnUpdated, pRefData->lmtPstnFlagValue, pRefData->bidUsedAmnt,
            pRefData->bidRmnAmnt, pRefData->bidHoldAmnt, pRefData->ofrUsedAmnt, pRefData->ofrRmnAmnt,
            pRefData->ofrHoldAmnt, pRefData->pstnBidHoldAmnt, pRefData->pstnOfrHoldAmnt, pRefData->strSysTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** OrdrCnclByCwMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT OrdrCnclByCwMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrdrCnclByCwMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    pCreditSbfCcpT pCrdtData;
    SbfCcpCrdtLimitDataRefT* pRefData;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    rc = CreditSbfCcpInfoGetByKeyExt(pRefData->intOrgId, &pCrdtData);
    RAISE_ERR(rc, RTN);

    /* Update the info of CRDT_SBFCCP */
    pCrdtData->clsPstnFlag = C_SHCH_CLSPSTN_OFF;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrdrCnclByCwDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT OrdrCnclByCwDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrdrCnclByCwDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVctCrdtSbfCcp[GET_BIT_VECT_LEN(18)] = {0};
    vectorT  datVctCrdtSbfCcp[GET_BIT_VECT_LEN(18)] = {0};
    CrdtSbfccp crdtSbfCcpData;

    SbfCcpCrdtLimitDataRefT* pRefData;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    memset(&crdtSbfCcpData, 0x00, sizeof(CrdtSbfccp));

    /* Set the update key of CRDT_SBFCCP */
    DbCmmnSetColBit( keyVctCrdtSbfCcp, 1 );
    crdtSbfCcpData.orgId = pRefData->intOrgId;

    /* Set the info of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 2 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 16 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 17 );
    sprintf(crdtSbfCcpData.clsPstnF, "%d", C_SHCH_CLSPSTN_OFF);
    strcpy(crdtSbfCcpData.updTm, pRefData->strSysTime);
    strcpy(crdtSbfCcpData.updUsrNm, "SYSTEM");

    rc = UpdateCrdtSbfccpByKey(connId, &crdtSbfCcpData, keyVctCrdtSbfCcp, datVctCrdtSbfCcp);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrdrCnclByCwPrintCallback
 **
 ******************************************************************************/
ResCodeT OrdrCnclByCwPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrdrCnclByCwPrintCallback" );
    ResCodeT rc = NO_ERR;

    SbfCcpCrdtLimitDataRefT* pRefData;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    printf("SbfCcpCrdtLimitDataRefT: intOrgId=%d, strSysTime=%s.\n",
            pRefData->intOrgId, pRefData->strSysTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DealCnclCallback
 **
 ******************************************************************************/
ResCodeT DealCnclCallback( void * pData, int32 dataSize )
{
    BEGIN_FUNCTION("DealCnclCallback");
    ResCodeT rc = NO_ERR;

    TradeDatT * pTradeDat = {0};
    uint32       tradePos = NULL;
    pDealCnclT  pDealCnclInfo = {0};
    TradeKeyT   tradeKey = {0};


    pDealCnclInfo = (pDealCnclT)pData;

    tradeKey.trdNo = pDealCnclInfo->dealNo;
    rc =  TradeChk(pDealCnclInfo->setId, &tradeKey, &pTradeDat, &tradePos);
    if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        RAISE_ERR(rc, RTN);
    }

    pTradeDat->bidTrd.tranDatTim = pDealCnclInfo->updTime;
    pTradeDat->askTrd.tranDatTim = pDealCnclInfo->updTime;
    pTradeDat->bidTrd.trdSts = pDealCnclInfo->dealSt;
    pTradeDat->askTrd.trdSts = pDealCnclInfo->dealSt;


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DealCnclDbCallback
 **
 ******************************************************************************/
ResCodeT DealCnclDbCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION("DealCnclDbCallback");
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(34)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(34)] = {0};

    Dl          dlData = {0};
    pDealCnclT  pDealCnclInfo = {0};
    char        DateTime[MAX_DATETIME_LEN];
    string      prefix;

    pDealCnclInfo = (pDealCnclT)pData;

    memset(&dlData, 0, sizeof(dlData));

    if(pDealCnclInfo->setId == SET_MKT_IRS)
    {
        prefix = IMIX_SECURITY_TYPE_IRS;
        sprintf(dlData.dlId, "%s%lld", (char*)prefix.c_str(), pDealCnclInfo->dealNo);
    }
    else if(pDealCnclInfo->setId == SET_MKT_SIRS)
    {
        prefix = IMIX_SECURITY_TYPE_IRS;
        sprintf(dlData.dlId, "%s%lld", (char*)prefix.c_str(), pDealCnclInfo->dealNo);//checked
    }
    else if(pDealCnclInfo->setId == SET_MKT_SBFCCP)
    {
        prefix = IMIX_SECURITY_TYPE_SBF;
        sprintf(dlData.dlId, "%s%lld", (char*)prefix.c_str(), pDealCnclInfo->dealNo);//checked
    }
    else
    {
        RAISE_ERR(ERR_CODE_INVLD_TRD_NT_EXST, RTN);
    }
    sprintf(dlData.dlSt, "%ld", pDealCnclInfo->dealSt);

    rc = GetStrDateTimeByFormat(pDealCnclInfo->updTime, DateTime);
    RAISE_ERR(rc, RTN);
    strcpy(dlData.updTm, DateTime);

    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 19 );

    rc = UpdateDlByKey(connId, &dlData, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** DealCnclPrintCallback
 **
 ******************************************************************************/
ResCodeT DealCnclPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION("DealCnclPrintCallback");
    ResCodeT rc = NO_ERR;

    pDealCnclT  pDealCnclInfo;

    pDealCnclInfo = (pDealCnclT)pData;

    printf("dealNo:%lld, dealSt:%ld, updTime:%lld setId:%ld \n", pDealCnclInfo->dealNo, pDealCnclInfo->dealSt, pDealCnclInfo->updTime, pDealCnclInfo->setId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrdrSubmitByCwMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT OrdrSubmitByCwMemUpdateCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrdrSubmitByCwMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    pCreditSbfCcpT pCrdtData;
    pCntrctPstnSbfCcpT pPstnData;
    SbfCcpCrdtLimitDataRefT* pRefData;
    uint32 pstnPos = CMN_LIST_NULL_NODE;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    rc = CreditSbfCcpInfoGetByKeyExt(pRefData->intOrgId, &pCrdtData);
    RAISE_ERR(rc, RTN);

    /* Update the cls_pstn_f of CRDT_SBFCCP */
    pCrdtData->clsPstnFlag = C_SHCH_CLSPSTN_ON;

    /* Update the remain amount of CRDT_SBFCCP */
    pCrdtData->bidRmnAmnt = pRefData->bidRmnAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    pCrdtData->ofrRmnAmnt = pRefData->ofrRmnAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);

    /* Update hold amount & used amount of CRDT_SBFCCP */
    pCrdtData->bidHoldAmnt = pRefData->bidHoldAmnt;
    pCrdtData->bidUsedAmnt = pRefData->bidUsedAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    pCrdtData->ofrHoldAmnt = pRefData->ofrHoldAmnt;
    pCrdtData->ofrUsedAmnt = pRefData->ofrUsedAmnt * pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);

    /* Update the hold amount of CNTRCT_PSTN_SBFCCP */
    while (TRUE)
    {
        rc = CntrctPstnSbfCcpIterExt(&pstnPos, &pPstnData);
        RAISE_ERR(rc,RTN);

        if ( CMN_LIST_NULL_NODE == pstnPos )
        {
            break;
        }

        /* Check if the org id is equal to org id in RefData. */
        if (pPstnData->orgId == pRefData->intOrgId){
            /* Set the hold amount of Bid/Offer side to 0 */
            pPstnData->bidHoldAmnt = pRefData->pstnBidHoldAmnt;
            pPstnData->ofrHoldAmnt = pRefData->pstnOfrHoldAmnt;
        }
    }

    /* Check if it's need to update the limit position flag of CRDT_SBFCCP */
    if (pRefData->isLmtPstnUpdated == TRUE){
        pCrdtData->lmtPstnFlag = pRefData->lmtPstnFlagValue;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrdrSubmitByCwDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT OrdrSubmitByCwDbUpdateCallback(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrdrSubmitByCwDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVctCrdtSbfCcp[GET_BIT_VECT_LEN(18)] = {0};
    vectorT  datVctCrdtSbfCcp[GET_BIT_VECT_LEN(18)] = {0};
    CrdtSbfccp crdtSbfCcpData;

    vectorT  keyVctCntrctPstn[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVctCntrctPstn[GET_BIT_VECT_LEN(10)] = {0};
    CntrctPstnSbfccp cntrctPstnData;

    SbfCcpCrdtLimitDataRefT* pRefData;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    memset(&crdtSbfCcpData, 0x00, sizeof(CrdtSbfccp));
    memset(&cntrctPstnData, 0x00, sizeof(CntrctPstnSbfccp));

    /* Set the update key of CRDT_SBFCCP & CNTRCT_PSTN_SBFCCP */
    DbCmmnSetColBit( keyVctCrdtSbfCcp, 1 );
    DbCmmnSetColBit( keyVctCntrctPstn, 1 );
    crdtSbfCcpData.orgId = pRefData->intOrgId;
    cntrctPstnData.orgId = pRefData->intOrgId;

    /* Update the cls_pstn_f of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 2 );
    sprintf(crdtSbfCcpData.clsPstnF, "%d", C_SHCH_CLSPSTN_ON);

    /* Update the remain amount of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 9 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 13 );
    crdtSbfCcpData.bidRmnAmnt = pRefData->bidRmnAmnt;
    crdtSbfCcpData.ofrRmnAmnt = pRefData->ofrRmnAmnt;

    /* Update hold amount & used amount of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 7 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 8 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 11 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 12 );
    crdtSbfCcpData.bidHoldAmnt = pRefData->bidHoldAmnt;
    crdtSbfCcpData.bidUsedAmnt = pRefData->bidUsedAmnt;
    crdtSbfCcpData.ofrHoldAmnt = pRefData->ofrHoldAmnt;
    crdtSbfCcpData.ofrUsedAmnt = pRefData->ofrUsedAmnt;

    /* Update the hold amount of CNTRCT_PSTN_SBFCCP */
    DbCmmnSetColBit( datVctCntrctPstn, 4 );
    DbCmmnSetColBit( datVctCntrctPstn, 5 );
    cntrctPstnData.bidHoldAmnt = pRefData->pstnBidHoldAmnt;
    cntrctPstnData.ofrHoldAmnt = pRefData->pstnOfrHoldAmnt;

    /* Check if it's need to update the limit position flag of CRDT_SBFCCP */
    if (pRefData->isLmtPstnUpdated == TRUE){
        DbCmmnSetColBit( datVctCrdtSbfCcp, 3 );
        sprintf(crdtSbfCcpData.lmtPstnF, "%d", pRefData->lmtPstnFlagValue);
    }

    /* Set update user name & update time of CRDT_SBFCCP */
    DbCmmnSetColBit( datVctCrdtSbfCcp, 16 );
    DbCmmnSetColBit( datVctCrdtSbfCcp, 17 );
    strcpy(crdtSbfCcpData.updTm, pRefData->strSysTime);
    strcpy(crdtSbfCcpData.updUsrNm, C_SYSTEM);

    rc = UpdateCrdtSbfccpByKey(connId, &crdtSbfCcpData, keyVctCrdtSbfCcp, datVctCrdtSbfCcp);
    RAISE_ERR(rc, RTN);

    rc = UpdateCntrctPstnSbfccpByKey(connId, &cntrctPstnData, keyVctCntrctPstn, datVctCntrctPstn);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrdrSubmitByCwPrintCallback
 **
 ******************************************************************************/
ResCodeT OrdrSubmitByCwPrintCallback(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrdrSubmitByCwPrintCallback" );
    ResCodeT rc = NO_ERR;

    SbfCcpCrdtLimitDataRefT* pRefData;

    pRefData = (SbfCcpCrdtLimitDataRefT*)pData;

    printf("SbfCcpCrdtLimitDataRefT: intOrgId=%d, "
           "ordFrzFlag=%d, isLmtPstnUpdated=%d, lmtPstnFlagValue=%d, bidUsedAmnt=%lf, "
           "bidRmnAmnt=%lf, bidHoldAmnt=%lf, ofrUsedAmnt=%lf, ofrRmnAmnt=%lf, "
           "ofrHoldAmnt=%lf, pstnBidHoldAmnt=%lf, pstnOfrHoldAmnt=%lf, strSysTime=%s.\n",
            pRefData->intOrgId,
            pRefData->ordFrzFlag, pRefData->isLmtPstnUpdated, pRefData->lmtPstnFlagValue, pRefData->bidUsedAmnt,
            pRefData->bidRmnAmnt, pRefData->bidHoldAmnt, pRefData->ofrUsedAmnt, pRefData->ofrRmnAmnt,
            pRefData->ofrHoldAmnt, pRefData->pstnBidHoldAmnt, pRefData->pstnOfrHoldAmnt, pRefData->strSysTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
