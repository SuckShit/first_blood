/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>              /* define wait handling functions     */
#include <errno.h>
#include <pthread.h>
/* Project Header File*/
#include "common_macro.h"
#include "app_shl.h"
#include "msg_cache.h"
#include "mem_txn.h"
#include "msg_type.h"
#include "db_comm.h"
#include "cfg_lib.h"
#include "MemTxnTblDb.h"
#include "MemTxnDatTblDb.h"
#include "monitor_thread.h"
#include "perf_stat.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_SEND_2_TDPS_SLOT  1000

#define MAX_PRCS_NAME_LEN   32
#define SHL_THREAD_CNT      20      /* suppose one have 1 writer and 1 reader */
#define SHL_TIME_OUT        10      /* time out time, default 10 ms */

#define RAISE_READ_MSG_ERR(_err_, _bRtn_)\
do\
{\
    if ((_err_) == ERR_MSG_NOT_FOUND)\
    {\
        THROW_RESCODE(_err_);\
    }\
    else\
    {\
        RAISE_ERR(_err_, _bRtn_);\
    }\
} while (0);

#define DB_SUPPORT() (gShlRunInfo.shlCfgInfo.bDbSupport)

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct ShlRunInfoS
{   /* Static Area */
    ShlCfgInfoT         shlCfgInfo;     /* input config, includes the input queue handle and txn size and etc. */
    int32               buffQHndl;      /* output queue handle */
    int32               shlDbHndl;      /* app shl database handle */
    
    int32               setId;          /* process set id */
    AppCallBackT        fAppCallBack;       /* Application process single message function callback */
    AppDoneCallBackT    fAppDoneCallBack;   /* Application txn done function callback */

    int32       WaitFd;
    pthread_t   runThreadId;

    /* Dynamic Area */
    BOOL        bRunFlg;                /* Flag the process thread is running or not */

    BOOL        bNeedTxn;               /* Indicate whether the message require and txn or not */
    BOOL        bNeedCommit;            /* Indicate whether the message need immediately commit or not  */
    int32       prcsMsgCnt;             /* the message count of current txn  */

    int64       txnId;
    int64       timestamp;
    SlotT       reqSlot;

} ShlRunInfoT, *pShlRunInfoT;

typedef struct ShlPrcsCtxS
{
    int32       sendFlg;
    SlotT       rspSlotNo;
} ShlPrcsCtxT, *pShlPrcsCtxT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static ShlRunInfoT gShlRunInfo = {0};
static struct epoll_event gWaitEvent[SHL_Q_TYPE_MAX];

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT PrcsQueueMsg(pShlRunInfoT pRunInfo, int32 msgHndl);
ResCodeT CommitTxn(pShlRunInfoT pRunInfo);
ResCodeT SendAllBuffSlot(pShlRunInfoT pRunInfo);
ResCodeT SendOneSlotRsp(pShlRunInfoT pRunInfo, SlotT slot);
void * ShlRunFunc(void * rtnCode);
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

/******************************************************************************
* Description:   Init working epoll queue
* Parameters:
*      pInQHndl    IN  input queue handle array
*      N/A         OUT
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT ShlInitWaitQueue(int32 * pInQHndl)
{
    BEGIN_FUNCTION( "ShlInitWaitQueue" );
    ResCodeT            rc = NO_ERR;
    int32               queueFd = 0;
    int32               i = 0;

    gShlRunInfo.WaitFd = epoll_create(SHL_Q_TYPE_MAX);
    if (gShlRunInfo.WaitFd < 0)
    {
        RAISE_ERR( ERR_OPEN_ERR_LOG_ERR, RTN );
    }

    for (i = 0; i < SHL_Q_TYPE_MAX; i++)
    {
        if (pInQHndl[i] == 0)
        {
            continue;
        }

        rc = MsgQueueGetFd(pInQHndl[i], &queueFd);
        RAISE_ERR( rc, RTN );



        gWaitEvent[i].events = EPOLLIN| EPOLLRDHUP|EPOLLERR|EPOLLHUP;
        gWaitEvent[i].data.fd = queueFd;
        gWaitEvent[i].data.ptr = (void *)&pInQHndl[i];


        if (epoll_ctl(gShlRunInfo.WaitFd,EPOLL_CTL_ADD, queueFd, &gWaitEvent[i]))
        {
            RAISE_ERR( ERR_APP_EPOLL_ADD_ERR, RTN );
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlInitWaitQueue */

/******************************************************************************
* Description:   Initialize the out buffer queue;
* Parameters:
*      prcsName    IN  process name for share memory name
*      txnSize     IN  queue size
*      itemSize    IN  item size
*      pHndl       OUT handle
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT InitOutBuffQueue(int32 queueSize, int32 itemSize, int32 * pHndl)
{
    BEGIN_FUNCTION( "InitOutBuffQueue" );
    MsgQueueCfgT        msgQCfg;
    ResCodeT            rc = NO_ERR;
    int32               ttlSize = 0;
    void *              pQueueAddr = NULL;

    msgQCfg.type = Q_TYPE_MW1R;
    msgQCfg.itemCnt = queueSize * 2;  /* enlarge the buffer queue */
    msgQCfg.itemSize = itemSize;
    msgQCfg.threadCnt = SHL_THREAD_CNT;

    rc = MsgQueueCalcSize(&msgQCfg, (uint32*)&ttlSize);
    RAISE_ERR( rc, RTN );

    MALLOC(pQueueAddr, ttlSize)

    rc = MsgQueueCreate(&msgQCfg,pHndl,pQueueAddr);
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of InitOutBuffQueue */

/******************************************************************************
 * Description:     read message from input queue
 * Parameters:
 *      N/A         IN
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to shutdown
 ******************************************************************************/
ResCodeT ReadMsgFromQ(pShlRunInfoT pRunInfo, int32 msgHndl, pIntrnlMsgT* ppReq, pIntrnlMsgT* ppRsp, pShlPrcsCtxT pShlPrcsCtx)
{
    BEGIN_FUNCTION( "ReadMsgFromQ" );
    pMsgCacheSlotT pReqMsgSlot = NULL;
    pMsgCacheSlotT pRspMsgSlot = NULL;
    ResCodeT rc = NO_ERR;

    if (pRunInfo->prcsMsgCnt >= pRunInfo->shlCfgInfo.txnSize)
    {
        LOG_DEBUG("Txn Full %lld" $$ pRunInfo->prcsMsgCnt);

        pRunInfo->bNeedCommit = TRUE;
        THROW_RESCODE(ERR_MSG_NOT_FOUND);
    }

    rc = MsgQueueReadSlot(msgHndl, &pRunInfo->reqSlot);
    if (ERCD_ARCH_READ_TRY_AGAIN == rc)
    {
        TRACE("Queue is empty" );
        pRunInfo->bNeedCommit = (pRunInfo->txnId != NULL_TXN_ID) ? TRUE : FALSE;
        THROW_RESCODE(ERR_MSG_NOT_FOUND);
    }
    LOG_DEBUG("Appshl Get message slot %d" $$ pRunInfo->reqSlot);
    rc = MsgGetSlot(pRunInfo->reqSlot, &pReqMsgSlot);
    RAISE_ERR( rc, RTN );
    *ppReq     = (pIntrnlMsgT)&pReqMsgSlot->msgBody;

    rc = MsgGetSlotRsp(pRunInfo->reqSlot, &pRspMsgSlot);
    RAISE_ERR( rc, RTN );
    *ppRsp  = (pIntrnlMsgT)&pRspMsgSlot->msgBody;

    if (CHK_TXN_MSG_TYPE((*ppReq)->msgHdr.msgType) )
    {
        /*set up the txn flag */
        (pRunInfo->prcsMsgCnt)++;

        pRunInfo->bNeedTxn = (pRunInfo->txnId == NULL_TXN_ID) ? TRUE : FALSE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ReadMsgFromQ */

/******************************************************************************
 * Description:   Start a transaction
 * Parameters:
 *      setId       IN  the responseable set of this application shell
 *      pTxnId   IN  process name
 *      timestamp IN  input config information
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT StartTxn(int32 setId, int64 *pTxnId, int64 * timestamp)
{
    BEGIN_FUNCTION( "StartTxn" );
    ResCodeT rc = NO_ERR;

    rc = MemTxnStart(setId, pTxnId, timestamp);
        RAISE_ERR(rc, RTN);

    TRACE("MemTxnStart done <%lld>" $$ *pTxnId);
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of StartTxn */

/******************************************************************************
 * Description:   Read msg and decide wether need a transaction start or not.
 * Parameters:
 *      msgHndl     IN  message handle
 *      pTxnId      IN  process name
 *      timestamp   IN  input config information
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT ReadNextMsg(pShlRunInfoT pRunInfo, int32 msgHndl, pIntrnlMsgT* ppReq, pIntrnlMsgT* ppRsp, pShlPrcsCtxT pShlPrcsCtx)
{
    BEGIN_FUNCTION( "ReadNextMsg" );
    ResCodeT rc = NO_ERR;

    rc = ReadMsgFromQ(pRunInfo, msgHndl, ppReq, ppRsp, pShlPrcsCtx);
    RAISE_READ_MSG_ERR(rc, RTN);


    if (pRunInfo->bNeedTxn == TRUE)
    {
        rc = StartTxn(pRunInfo->setId, &pRunInfo->txnId, &pRunInfo->timestamp);
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ReadNextMsg */

/******************************************************************************
 * Description:     Process the single message
 * Parameters:
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT PrcsSingleMsg(pShlRunInfoT pRunInfo, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, pShlPrcsCtxT pShlPrcsCtx)
{
    BEGIN_FUNCTION( "PrcsSingleMsg" );

    ResCodeT rc = NO_ERR;
    CallBackCtxT ctx;

    //validate the input message
    ctx.sendFlg = 0;

    rc = pRunInfo->fAppCallBack(pReq, pRsp, pRunInfo->timestamp, &ctx);
    RAISE_ERR( rc, NORTN );
    pShlPrcsCtx->sendFlg = ctx.sendFlg;

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of PrcsSingleMsg */

/******************************************************************************
 * Description:     Process the single message
 * Parameters:
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT PrcsLoadMemTxn(int32 set, pShlRunInfoT pRunInfo)
{
    BEGIN_FUNCTION( "PrcsLoadMemTxn" );
    CfgValueT cfgValue = {0};
    ResCodeT rc = NO_ERR;

    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
    
    while (1)
    {
        /**/
        rc = MemTxnLoadDatFromTxnId(set, 0, &pRunInfo->txnId);
        if (rc == ERR_MEM_TXN_ITER_DATA_END)
        {
            LOG_DEBUG(" [%ld] Txn Loaded... after %ld ms ", pRunInfo->txnId,cfgValue.rplyIntrvl );
            SET_RESCODE(NO_ERR);
        }
        else
        {
            RAISE_ERR( rc, RTN );
        }
        
        usleep(cfgValue.rplyIntrvl*1000); /* unit is us */
        
        if (1)//todo
        {
            break;
        }
    }
    
    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of PrcsLoadMemTxn */


/******************************************************************************
 * Description:     Process the single message
 * Parameters:
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT AppShlWriteSlotToBuff(int32 slotId)
{
    BEGIN_FUNCTION( "AppShlWriteSlotToBuff" );
    ResCodeT rc = NO_ERR;
    
    
    LOG_DEBUG("Send slot to AppShl Buffer  [%d]", slotId);

    rc = MsgQueueWriteSlot(gShlRunInfo.buffQHndl,
                            slotId);
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlWriteSlotToBuff */


/******************************************************************************
 * Description:     Process the single message
 * Parameters:
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT WriteSlotToBuff(pShlPrcsCtxT pPrcsCtx, pShlRunInfoT pRunInfo)
{
    BEGIN_FUNCTION( "WriteSlotToBuff" );
    ResCodeT rc = NO_ERR;
    
    LOG_DEBUG("Send slot to AppShl Output Queue [%d]", pRunInfo->reqSlot);


    rc = MsgQueueWriteSlot(pRunInfo->buffQHndl,
                            pRunInfo->reqSlot);
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of WriteSlotToBuff */

/******************************************************************************
 * Description:     Process the queue message
 * Parameters:
 *      queueEvent  IN  give the queue event
 *      queueCnt    IN  tell how many queue event we have.
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to process the queue message.
 ******************************************************************************/
ResCodeT ShlPrcsMsg(struct epoll_event * queueEvent, int32 inputCnt)
{
    BEGIN_FUNCTION( "ShlPrcsMsg" );
    ResCodeT    rc = 0;
    int32 i = 0;
    int32 queueHndl = 0;
    BOOL  disableFlg[SHL_Q_TYPE_MAX] = {0};
    int32 queueCnt = 0;
    /* In order to avoid always read from one queue, we use static to define the queue index */
    int32 queueIdx = 0;

    queueCnt = inputCnt;
    while (queueCnt)
    {
        if (FALSE == disableFlg[queueIdx])
        {
            /* 1. Read the first queue for max txnSize time */
            queueHndl = *((int *)queueEvent[queueIdx].data.ptr);

            for(i=0; i<gShlRunInfo.shlCfgInfo.txnSize; i++)
            {
                rc = PrcsQueueMsg(&gShlRunInfo, queueHndl);
                if (ERR_MSG_NOT_FOUND == rc)
                {
                    queueCnt--;
                    disableFlg[queueIdx] = TRUE;

                    TRACE("Queue %d is disabled, %d queue left " $$ queueIdx $$ queueCnt);
                    /* if we come here, it means there is not more message in this queue, not txn full */


                    break;
                }
                else if (NOTOK(rc))
                {
                    /* some serious problem happened */
                    RAISE_ERR( rc, NORTN );
                    exit(1);
                }

            }
        }
        /* if greater than the input queue cnt, set to 0, start to check the queue again */
        queueIdx = ((queueIdx + 1) >= inputCnt)? 0 : (++queueIdx);
    }

    MonThreadUpt(MON_THREAD_CALLBACK_TYP);

    EXIT_BLOCK();
    SET_RESCODE(NO_ERR);
    RETURN_RESCODE;
}/* End of ShlPrcsMsg */

/******************************************************************************
 * Description:     Process the queue message
 * Parameters:
 *      pRunInfo    IN  run time info
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT PrcsQueueMsg(pShlRunInfoT pRunInfo, int32 msgHndl)
{
    BEGIN_FUNCTION( "PrcsQueueMsg" );
    pIntrnlMsgT pReq = NULL, pRsp = NULL;
    ShlPrcsCtxT     shlPrcsCtx;

    shlPrcsCtx.sendFlg = 0;

    ResCodeT rc = NO_ERR;

    rc = ReadNextMsg(pRunInfo, msgHndl, &pReq, &pRsp, &shlPrcsCtx);
    RAISE_READ_MSG_ERR(rc, RTN);

    rc = PrcsSingleMsg(pRunInfo, pReq, pRsp, &shlPrcsCtx);
    RAISE_ERR( rc, NORTN );
    
    pRunInfo->timestamp++;

    if (shlPrcsCtx.sendFlg)
    {
        if (CHK_TXN_MSG_TYPE(pReq->msgHdr.msgType) )
        {
            rc = WriteSlotToBuff(&shlPrcsCtx, pRunInfo);
            RAISE_ERR( rc, NORTN );
        }
        else
        {
            rc = SendOneSlotRsp(pRunInfo, pRunInfo->reqSlot);
            RAISE_ERR( rc, NORTN );
        }
    }

    EXIT_BLOCK();
    rc = GET_RESCODE();
    /* if it is because of txn full, do not raise the err */
    if ((rc == ERR_MSG_NOT_FOUND) && (pRunInfo->prcsMsgCnt >= pRunInfo->shlCfgInfo.txnSize))
    {
        SET_RESCODE(NO_ERR);
    }


    if (pRunInfo->bNeedCommit)
    {
        rc = CommitTxn(pRunInfo);
        RAISE_ERR( rc, NORTN );
    }


    RETURN_RESCODE;
}/* End of PrcsQueueMsg */



/******************************************************************************
 * Description:     Send the message to TDPS
 * Parameters:
 *      pRunInfo    IN  run time info
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT SplitTdpsTxnData(pRtDatCtrlT pRtDataCtrl, pMemTxnEntryT  pTxnEntry, SlotT * slotArry, int32 * slotCnt)
{
    BEGIN_FUNCTION( "SplitTdpsTxnData" );
    ResCodeT  rc = NO_ERR;
    SlotT slotId;
    pMsgCacheSlotT  pReqSlot;
    pMsgCacheSlotT  pRespSlot;
    pIntrnlMsgT     pReqMsg;
    pIntrnlMsgT     pRespMsg;
    int32           dataIdx = 0; //init to 0 for while loop
    BOOL            bFrstLoop = TRUE;
    int32           maxCnt = 0, usedCnt = 0;
    
    *slotCnt = 0;
    while (bFrstLoop || dataIdx)
    {
        bFrstLoop = FALSE;
        LOG_DEBUG("Reserv Slot in SplitTdpsTxnData");
        rc = MsgRsrvSlotsPaired(&slotArry[*slotCnt], &pReqSlot, &pRespSlot);
        if(NOTOK(rc))
        {
             GetMsgCount(&maxCnt, &usedCnt);
             LOG_DEBUG("left msgcache cnt %d", maxCnt-usedCnt);
        }
        RAISE_ERR( rc, RTN );
        
        if ((*slotCnt + 1) >= MAX_SEND_2_TDPS_SLOT)
        {
            RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
        }
        
        (*slotCnt)++;

        pReqMsg = (pIntrnlMsgT)&pReqSlot->msgBody;
        pRespMsg = (pIntrnlMsgT)&pRespSlot->msgBody;
        
        pRespMsg->msgHdr.msgLen = 0;
        
        rc = FmtTxnMsgBuff(pRtDataCtrl, pTxnEntry, (void *)pRespMsg->msgBody, (int32 *)&pRespMsg->msgHdr.msgLen, &dataIdx);
        RAISE_ERR( rc, RTN );
        
        pRespMsg->msgHdr.msgLen += sizeof(MsgHdrT);
        pRespMsg->msgHdr.msgType = MSG_TYPE_MSG_TO_TDPS;
        pRespMsg->msgHdr.errCode = NO_ERR;
        
        memcpy(&pReqMsg->msgHdr,&pRespMsg->msgHdr, sizeof(sizeof(MsgHdrT)));
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of PrcsQueueMsg */


/******************************************************************************
 * Description:     Send the message to TDPS
 * Parameters:
 *      pRunInfo    IN  run time info
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
//ResCodeT SendTxnToTDPS(pShlRunInfoT pRunInfo, pRtDatCtrlT pRtDataCtrl, pMemTxnEntryT  pTxnEntry)
//{
//    BEGIN_FUNCTION( "SendTxnToTDPS" );
//    ResCodeT  rc = NO_ERR;
//    SlotT slotId;
//    pMsgCacheSlotT  pReqSlot;
//    pMsgCacheSlotT  pRespSlot;
//    pIntrnlMsgT     pReqMsg;
//    pIntrnlMsgT     pRespMsg;
//    int32           dataIdx = 0; //init to 0 for while loop
//    BOOL            bFrstLoop = TRUE;
//    int32           maxCnt = 0, usedCnt = 0;
//    while (bFrstLoop || dataIdx)
//    {
//        bFrstLoop = FALSE;
//        
//        rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot, &pRespSlot);
//        if(NOTOK(rc))
//        {
//             GetMsgCount(&maxCnt, &usedCnt);
//             LOG_DEBUG("left msgcache cnt %d", maxCnt-usedCnt);
//        }
//        RAISE_ERR( rc, RTN );
//        
//        pReqMsg = (pIntrnlMsgT)&pReqSlot->msgBody;
//        pRespMsg = (pIntrnlMsgT)&pRespSlot->msgBody;
//        
//        pRespMsg->msgHdr.msgLen = 0;
//        
//        rc = FmtTxnMsgBuff(pRtDataCtrl, pTxnEntry, (void *)pRespMsg->msgBody, (int32 *)&pRespMsg->msgHdr.msgLen, &dataIdx);
//        RAISE_ERR( rc, RTN );
//        
//        pRespMsg->msgHdr.msgLen += sizeof(MsgHdrT);
//        pRespMsg->msgHdr.msgType = MSG_TYPE_MSG_TO_TDPS;
//        pRespMsg->msgHdr.errCode = NO_ERR;
//        
//        memcpy(&pReqMsg->msgHdr,&pRespMsg->msgHdr, sizeof(sizeof(MsgHdrT)));
//        
//        rc = SendOneSlotRsp(pRunInfo, slotId);
//        RAISE_ERR( rc, RTN );
//        
//        PerfStatInc(Snd2TdpsMsg);
//    }
//    
//    EXIT_BLOCK();
//    RETURN_RESCODE;
//}/* End of PrcsQueueMsg */

/******************************************************************************
 * Description:     commit the shell txn
 * Parameters:
 *      N/A         IN  run time info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT CommitTxn(pShlRunInfoT pRunInfo)
{
    BEGIN_FUNCTION( "CommitTxn" );
    ResCodeT rc = NO_ERR;
    BOOL     bDBUpdte = FALSE;
    pMemTxnEntryT  pTxnEntry = NULL;
    RtDatCtrlT dataCtrl;
    int32       i = 0;
    SlotT       slotArry[MAX_SEND_2_TDPS_SLOT];
    int32       slotCnt = 0;
    LOG_DEBUG("CommitTxn start txnSize %d" , pRunInfo->prcsMsgCnt);
    
    
    if (pRunInfo->fAppDoneCallBack)
    {
            rc = pRunInfo->fAppDoneCallBack();
            RAISE_ERR( rc, NORTN );
            LOG_DEBUG("fAppDoneCallBack done");
    }
    
    
    
    if (DB_SUPPORT())
    {
        
        MemTxnGetTxnEntryExt(pRunInfo->setId, pRunInfo->txnId,  &pTxnEntry );
        

        if (pTxnEntry->dataCnt)
        {       
            bDBUpdte = TRUE;
            
            rc = MemTxnGetDataRootAddr(pRunInfo->setId, &dataCtrl, pTxnEntry->frstDataSqno);
            RAISE_ERR( rc, RTN );
            
            rc = SplitTdpsTxnData(&dataCtrl, pTxnEntry, slotArry, &slotCnt);
            RAISE_ERR( rc, NORTN );
        
            
            LOG_DEBUG("TxnId %lld, 1stSqno %ld, datCnt %d",  pRunInfo->txnId,  pTxnEntry->frstDataSqno, pTxnEntry->dataCnt);
            
            rc = BatchInsertMemTxnDatTbl(pRunInfo->shlDbHndl, &dataCtrl, pTxnEntry->dataCnt,pTxnEntry->dataSize);
            RAISE_ERR( rc, RTN );
            
            rc = InsertMemTxnTbl(pTxnEntry);
            RAISE_ERR( rc, RTN );
    
            rc = DbCmmnCommit(pRunInfo->shlDbHndl);
            RAISE_ERR( rc, RTN );
            
            bDBUpdte = FALSE;
            
            LOG_DEBUG("DB insert done");
        }
    }

    if (pTxnEntry->dataCnt)
    {    
        rc = MemTxnCommit(pRunInfo->setId);
        RAISE_ERR( rc, RTN );
        LOG_DEBUG("MemTxnCommit done");
        
        PerfStatInc(TxnCnt);
        
        PerfStatSampleAdd(TxnDatCnt, pTxnEntry->dataCnt);
        
        LOG_DEBUG("Appshl Send to TDPS Start");
        for (i=0;i<slotCnt; i++)
        {
            rc = SendOneSlotRsp(pRunInfo, slotArry[i]);
            RAISE_ERR( rc, NORTN );
        
            PerfStatInc(Snd2TdpsMsg);
        } 
        LOG_DEBUG("Appshl Send to TDPS End");
    }
    
    LOG_DEBUG("Appshl Send response to client Start");
    rc = SendAllBuffSlot(pRunInfo);
    RAISE_ERR( rc, RTN );
    LOG_DEBUG("Appshl Send response to client End");    
    
        
    pRunInfo->prcsMsgCnt = 0;
    pRunInfo->txnId = NULL_TXN_ID;
    pRunInfo->bNeedCommit = FALSE;
    pRunInfo->bNeedTxn = FALSE;


    EXIT_BLOCK();
    if (NOTOK(GET_RESCODE()) && bDBUpdte)
    {
        rc = DbCmmnRollback(pRunInfo->shlDbHndl);
        RAISE_ERR( rc, NORTN );
    }
    RETURN_RESCODE;
}/* End of CommitTxn */

/******************************************************************************
 * Description:   Init the application shell
 * Parameters:
 *      setId       IN  the responseable set of this application shell
 *      pPrcsName   IN  process name
 *      pShlCfgInfo IN  input config information
 *      fAppCallBack IN app callback
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT AppShlInit(int32 setId, char *pPrcsName, pShlCfgInfoT  pShlCfgInfo, AppCallBackT fAppCallBack, AppDoneCallBackT fAppDoneCallBack)
{
    BEGIN_FUNCTION( "AppShlInit" );

    ResCodeT rc = NO_ERR;
    CfgValueT cfgValue = {0};

    CHK_SET_ID(setId);

    if ( NULL == pShlCfgInfo || NULL == fAppCallBack || 0 >= pShlCfgInfo->txnSize)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }

    memcpy(&gShlRunInfo.shlCfgInfo, pShlCfgInfo, sizeof(ShlCfgInfoT));

    /* Initialize Dynamic Area */
    gShlRunInfo.setId = setId;
    gShlRunInfo.bRunFlg = TRUE;
    gShlRunInfo.prcsMsgCnt = 0;
    gShlRunInfo.bNeedTxn = FALSE;
    gShlRunInfo.bNeedCommit = FALSE;
    gShlRunInfo.txnId = NULL_TXN_ID;
    gShlRunInfo.timestamp = 0;
    gShlRunInfo.reqSlot = NULL_SLOT;

    gShlRunInfo.fAppCallBack = fAppCallBack;
    gShlRunInfo.fAppDoneCallBack = fAppDoneCallBack;

    rc = MsgInit();
    RAISE_ERR( rc, RTN );

    rc = MemTxnShmInit(gShlRunInfo.setId);
    RAISE_ERR( rc, RTN );

    rc = ShlInitWaitQueue(gShlRunInfo.shlCfgInfo.inQHndl);
    RAISE_ERR( rc, RTN );

    /* initialize the output queue, increase 4 times for oc/tc data */
    rc = InitOutBuffQueue(gShlRunInfo.shlCfgInfo.txnSize*4, sizeof(SlotT), &gShlRunInfo.buffQHndl);
    RAISE_ERR( rc, RTN );

    /* Get config value for the system  */
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
        
    if (DB_SUPPORT())
    {

        
        rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &gShlRunInfo.shlDbHndl);
        RAISE_ERR(rc, RTN);
        
        rc = InitMemTxnTblSqlQuery(gShlRunInfo.shlDbHndl, gShlRunInfo.setId);
        RAISE_ERR(rc, RTN);
        
        rc = InitMemTxnDatTblSqlQuery(gShlRunInfo.shlDbHndl, gShlRunInfo.setId);
        RAISE_ERR(rc, RTN);
    }
    
    /* start to load mem txn from db*/
    rc = PrcsLoadMemTxn(gShlRunInfo.setId, &gShlRunInfo);
    RAISE_ERR(rc, RTN);
    
    gShlRunInfo.txnId = NULL_TXN_ID;
    
    if (pthread_create(&gShlRunInfo.runThreadId, NULL, ShlRunFunc, (void*)&rc))
    {
        RAISE_ERR( ERR_CREATE_THREAD, RTN );
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlInit */

/******************************************************************************
 * Description:   Read all buffer slot and sent to response queue
 * Parameters:
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT SendAllBuffSlot(pShlRunInfoT pRunInfo)
{
    BEGIN_FUNCTION( "SendAllBuffSlot" );
    ResCodeT    rc = NO_ERR;
    SlotT       slot = NULL_SLOT;

    do
    {
        rc = MsgQueueReadSlot(pRunInfo->buffQHndl,&slot);
        if (NOTOK(rc))
        {
            LOG_DEBUG("!!!! end of response");
            break;
        }
        LOG_DEBUG("SendAllBuffSlot Output Queue [%d]", slot);
        rc = MsgQueueWriteSlot(pRunInfo->shlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT],slot);
        RAISE_ERR( rc, NORTN );
    } while (TRUE);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of SendAllBuffSlot */


/******************************************************************************
 * Description:   Read all buffer slot and sent to response queue
 * Parameters:
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT SendOneSlotRsp(pShlRunInfoT pRunInfo, SlotT       slot)
{
    BEGIN_FUNCTION( "SendOneSlotRsp" );
    ResCodeT    rc = NO_ERR;
    
    LOG_DEBUG("Send slot to AppShl Output Queue [%d]", slot);

    rc = MsgQueueWriteSlot(pRunInfo->shlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT],slot);
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of SendOneSlotRsp */

/******************************************************************************
 * Description:   main call back to run the process logic
 * Parameters:
 *      rtnCode     OUT     function return value
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
void * ShlRunFunc(void * rtnCode)
{
    BEGIN_FUNCTION( "ShlRunFunc" );
    struct epoll_event waitEvent[SHL_Q_TYPE_MAX];
    int32 queueCnt = 0;
    ResCodeT rc = NO_ERR;

    rc = MonThreadReg(MON_THREAD_CALLBACK_TYP);
    RAISE_ERR(rc, NORTN);

    do
    {
        queueCnt = epoll_wait(gShlRunInfo.WaitFd, waitEvent,SHL_Q_TYPE_MAX, SHL_TIME_OUT);

        if (queueCnt<0 && errno != EINTR)
        {

            RAISE_ERR( ERR_APP_EPOLL_WAIT_ERR, RTN );
        }
        else if  (queueCnt<0 && errno == EINTR)
        {
            //RAISE_ERR( ERR_APP_EPOLL_WAIT_ERR, NORTN );
            //usleep(1000000);
            continue;
        }
        else if (queueCnt == 0)
        {
            TRACE("function timeout");
            rc = ShlPrcsMsg(gWaitEvent, SHL_Q_TYPE_MAX);
            RAISE_ERR( rc, NORTN );

            MonThreadUpt(MON_THREAD_CALLBACK_TYP);
        }
        else
        {
            TRACE("activated queue" $$ queueCnt);
            rc = ShlPrcsMsg(waitEvent, queueCnt);
            RAISE_ERR( rc, NORTN );

        }
    } while (gShlRunInfo.bRunFlg);

    EXIT_BLOCK();
    MonThreadSetState(MON_THREAD_CALLBACK_TYP, THREAD_EXIT);

    *((int32 *) rtnCode) = GET_RESCODE();
}/* End of ShlRunFunc */

/******************************************************************************
 * Description:   Init the application shell
 * Parameters:
 *      setId       IN  the responseable set of this application shell
 *      pPrcsName   IN  process name
 *      pShlCfgInfo IN  input config information
 *      fAppCallBack IN app callback
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT AppShlRun()
{
    BEGIN_FUNCTION( "AppShlRun" );

    ResCodeT rc = NO_ERR;

    if (pthread_join(gShlRunInfo.runThreadId,NULL))
    {
        RAISE_ERR( ERR_CREATE_THREAD, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlRun */

/******************************************************************************
 * Description:     shutdown the application shell
 * Parameters:
 *      N/A         IN
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to shutdown
 ******************************************************************************/
ResCodeT AppShlShutDown()
{
    BEGIN_FUNCTION( "AppShlShutDown" );

    ResCodeT rc = NO_ERR;

    rc = MsgQueueDispose(gShlRunInfo.buffQHndl);
    RAISE_ERR( rc, RTN );

    rc = MsgDetach();
    RAISE_ERR( rc, RTN );

    rc = MemTxnShmDetach(); RAISE_ERR( rc, RTN );
    
    rc = DbCmmnDisconnect(gShlRunInfo.shlDbHndl);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlShutDown */

/******************************************************************************
 * Description:   stop the application shell
 * Parameters:
 *      fAppCallBack IN app callback
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT AppShlStop()
{
    BEGIN_FUNCTION( "AppShlStop" );

    gShlRunInfo.bRunFlg = FALSE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlStop */
