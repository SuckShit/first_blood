﻿/***
Created on Aug 10, 2017
@author: Yinsong.Zhao
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "common_hash.h"
#include "shm.h"
#include "ordr_mgmt.h"
#include "order_book.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT gOrdrMgmtHshHdl[MAX_SET_CNT] = { 0 };

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
 

ResCodeT OrdrMgmtShmCreate(int64 rcrdCnt, int32 setId)
{
    BEGIN_FUNCTION("OrdrMgmtShmCreate");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    void *pShmRoot;
    char shmName[SHM_NAME_LEN];
    
    recInfo.recSize = sizeof(OrdrMgmtRcrdT);
    recInfo.keyOffset = offsetof(OrdrMgmtRcrdT, ordrKey);
    recInfo.keySize = sizeof(OrdrMgmtKeyT);
    recInfo.recCnt = rcrdCnt;
    recInfo.bNeedTimeList = TRUE;
    sprintf(shmName, SHM_ORD_MGMT_NAME, setId);
    
    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)shmName), 
                                recInfo, TRUE, &pShmRoot, &gOrdrMgmtHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT OrdrMgmtShmAttach(int32 setId)
{
    BEGIN_FUNCTION("OrdrMgmtShmAttach");
    ResCodeT rc = NO_ERR;
    void *pShmRoot;
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_ORD_MGMT_NAME, setId);
    rc = CmnHashTblAttach(GetShmNm((char*)shmName), &pShmRoot, &gOrdrMgmtHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    
    rc = OrdrBkShmAttach(setId);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrdrMgmtShmDetach(int32 setId)
{
    BEGIN_FUNCTION("OrdrMgmtShmDetach");
    ResCodeT rc = NO_ERR;
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_ORD_MGMT_NAME, setId);
    rc = ShmDetach((char*)shmName);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrdrMgmtShmDelete(int32 setId)
{
    BEGIN_FUNCTION("OrdrMgmtShmDelete");
    ResCodeT rc = NO_ERR;
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_ORD_MGMT_NAME, setId);
    rc = ShmDelete((char*)shmName);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrdrMgmtShmReset(int32 setId)
{
    BEGIN_FUNCTION("OrdrMgmtShmInit");
    ResCodeT rc = NO_ERR;

    
    rc = CmnHashResetTbl(gOrdrMgmtHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OrdrMgmtChk(int32 setId, pOrdrMgmtKeyT pOrdrKey, pOrdrMgmtRcrdT * ppOrdrMgmt, uint32 * pOrdrMgmtPos)
{
    BEGIN_FUNCTION("OrdrMgmtChk");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gOrdrMgmtHshHdl[setId], (void*)pOrdrKey, &isExist, pOrdrMgmtPos, (void**)ppOrdrMgmt);
    RAISE_ERR(rc, RTN);
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




ResCodeT OrdrMgmtLogByPos(int32 setId, uint32 ordrMgmtPos, pOrdrMgmtRcrdT pOrdrMgmt)
{
    BEGIN_FUNCTION("OrdrMgmtLogByPos");
    ResCodeT rc = NO_ERR;

    rc = CmnHashLogData(gOrdrMgmtHshHdl[setId], pOrdrMgmt, ordrMgmtPos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT OrdrMgmtAdd(int32 setId, pOrdrMgmtRcrdT pOrdrMgmt, uint32 * pOrdrMgmtPos)
{
    BEGIN_FUNCTION("OrdrMgmtAdd");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    uint32 nodePos;
    pOrdrMgmtRcrdT  pTempOrdrMgmt;
    
    rc = CmnHashCheckDataExt(gOrdrMgmtHshHdl[setId], (void*)&pOrdrMgmt->ordrKey, &isExist, &nodePos, (void**)&pTempOrdrMgmt);
    RAISE_ERR(rc, RTN);
    
    *pOrdrMgmtPos = nodePos;
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
   
    rc = CmnHashLogData(gOrdrMgmtHshHdl[setId], pOrdrMgmt, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT OrdrMgmtUpdtByPos(int32 setId, uint32 ordrMgmtPos, pOrdrMgmtRcrdT pOrdrMgmt)
{
    BEGIN_FUNCTION("OrdrMgmtUpdtByPos");
    ResCodeT rc = NO_ERR;

    rc = CmnHashUpdateData(gOrdrMgmtHshHdl[setId], (void*) pOrdrMgmt, ordrMgmtPos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT OrdrMgmtGetByNo(int32 setId, pOrdrMgmtKeyT pOrdrKey, pOrdrMgmtRcrdT * ppOrdrMgmt, uint32 * pOrdrMgmtPos)
{
    BEGIN_FUNCTION("OrdrMgmtGetByNo");
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;

    rc = CmnHashCheckDataExt(gOrdrMgmtHshHdl[setId], (void*)pOrdrKey, &isExist, &nodePos, (void**)ppOrdrMgmt );
    *pOrdrMgmtPos = nodePos;
    RAISE_ERR(rc, RTN);
    
    if (isExist == FALSE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrdrMgmtDel(int32 setId, pOrdrMgmtKeyT pOrdrKey)
{
    BEGIN_FUNCTION("OrdrMgmtDel");
    ResCodeT rc = NO_ERR;
    pOrdrMgmtRcrdT  pOrdrMgmt;
    uint32 ordrMgmtPos;
    
    rc = OrdrMgmtGetByNo(setId, pOrdrKey, &pOrdrMgmt, &ordrMgmtPos);
    RAISE_ERR(rc, RTN);
    
    rc = CmnHashDeleteData(gOrdrMgmtHshHdl[setId], ordrMgmtPos);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT OrdrMgmtDelByPos(int32 setId, uint32 ordrMgmtPos)
{
    BEGIN_FUNCTION("OrdrMgmtDelByPos");
    ResCodeT rc = NO_ERR;
    pOrdrMgmtRcrdT * ppOrdrMgmt;
    
    rc = CmnHashDeleteData(gOrdrMgmtHshHdl[setId], ordrMgmtPos);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OrdrMgmtIter(int32 setId, uint32* nodePos, pOrdrMgmtRcrdT  pOrdrMgmt)
{
    BEGIN_FUNCTION("IterMgmt");
    ResCodeT rc = NO_ERR;
    uint32 pos;
    
    rc = CmnHashIterData(gOrdrMgmtHshHdl[setId], &pos, (void*)pOrdrMgmt);
    RAISE_ERR(rc, RTN);
    *nodePos = pos;
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtNrmlUpdt(int32 set, int64 ordrNo, int32 ordrSts, pOrderT pOrder)
{
    BEGIN_FUNCTION( "OrdrMgmtNrmlUpdt" );
    ResCodeT        rc = NO_ERR;
    
    uint32           ordrPos = -1;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    
    OrdrMgmtRcrdT   ordrMgmt;
    
    memset(&ordrMgmt.ordrKey, 0x00, sizeof(OrdrMgmtKeyT));
    
    ordrMgmt.ordrKey.ordrNo = ordrNo;
    ordrMgmt.ordrKey.ordrType = EXT_ORD_TYPE_NORMAL;

    rc = OrdrMgmtChk(set, &ordrMgmt.ordrKey, &pOrdrMgmt, &ordrPos);
    if (ERR_CMN_HASH_LIST_NODE_EXISTED != rc)
    {
        RAISE_ERR( rc, RTN );
    }

    if (ERR_CMN_HASH_LIST_NODE_EXISTED == rc)
    {
        pOrdrMgmt->ordrSts = ordrSts;
        rc = OrdrMgmtUpdtByPos(set, ordrPos, pOrdrMgmt); //do update
    }
    else
    {
        ordrMgmt.ordrSts = ordrSts;
        ordrMgmt.ordrSlot[0] = pOrder->orderT.slotNo;
        ordrMgmt.ordrCnt = 1;
        
        rc = OrdrMgmtLogByPos(set, ordrPos, &ordrMgmt); //do add 
    }
    RAISE_ERR( rc, RTN );
    
    pOrder->orderF.ordrSts = ordrSts;
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtNrmlGet(int32 set, int64 ordrNo, pOrdrMgmtRcrdT * ppOrdrMgmt, pOrderT * ppOrder, uint32 * pOrdrPos)
{
    BEGIN_FUNCTION( "OrdrMgmtNrmlGet" );
    ResCodeT        rc = NO_ERR;
    
    OrdrMgmtKeyT    orderKey = {0};
     
    orderKey.ordrNo = ordrNo;
    orderKey.ordrType = EXT_ORD_TYPE_NORMAL; 
    
    rc = OrdrMgmtGetByNo(set, &orderKey, ppOrdrMgmt, pOrdrPos);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    else
    {
        RAISE_ERR( rc, RTN );
    }
    
    rc = OrdrBkGetOrdr( set, (*ppOrdrMgmt)->ordrSlot[0],  ppOrder);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtBilUpdt(int32 set, int64 bilOrdrNo, int32 ordrSts, pOrderT pBidOrder, pOrderT pAskOrder, SlotT bidSlot, SlotT askSlot)
{
    BEGIN_FUNCTION( "OrdrMgmtBilUpdt" );
    ResCodeT        rc = NO_ERR;
    
    uint32           ordrPos = -1;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    OrdrMgmtRcrdT   ordrMgmt;
    
    memset(&ordrMgmt.ordrKey, 0x00, sizeof(OrdrMgmtKeyT));
    
    ordrMgmt.ordrKey.ordrNo = bilOrdrNo;
    ordrMgmt.ordrKey.ordrType = EXT_ORD_TYPE_BIL;

    rc = OrdrMgmtChk(set, &ordrMgmt.ordrKey, &pOrdrMgmt, &ordrPos);
    if (ERR_CMN_HASH_LIST_NODE_EXISTED != rc)
    {
        RAISE_ERR( rc, RTN );
    }
    
    if (ERR_CMN_HASH_LIST_NODE_EXISTED == rc)
    {   
        pOrdrMgmt->ordrSts = ordrSts;
        rc = OrdrMgmtUpdtByPos(set, ordrPos, pOrdrMgmt); //do update
    }
    else
    {
        ordrMgmt.ordrSts = ordrSts;
        ordrMgmt.ordrSlot[0] = bidSlot;
        ordrMgmt.ordrSlot[1] = askSlot;
        ordrMgmt.ordrCnt = 2;
        
        rc = OrdrMgmtLogByPos(set, ordrPos, &ordrMgmt); //do add 
    }
    RAISE_ERR( rc, RTN );
    
    pBidOrder->orderF.ordrSts = ordrSts;
    pAskOrder->orderF.ordrSts = ordrSts;
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtBilGet(int32 set, int64 bilOrdrNo,pOrdrMgmtRcrdT * ppBilOrdrMgmt, pOrderT * ppBidOrder, pOrderT * ppAskOrder, uint32 * pOrdrPos)
{
    BEGIN_FUNCTION( "OrdrMgmtBilGet" );
    ResCodeT        rc = NO_ERR;
    
    OrdrMgmtKeyT    orderKey = {0};
     
    orderKey.ordrNo = bilOrdrNo;
    orderKey.ordrType = EXT_ORD_TYPE_BIL; 
    
    rc = OrdrMgmtGetByNo(set, &orderKey, ppBilOrdrMgmt, pOrdrPos);
    RAISE_ERR( rc, RTN );
    
    rc = OrdrBkGetOrdr( set, (*ppBilOrdrMgmt)->ordrSlot[0],  ppBidOrder);
    RAISE_ERR( rc, RTN );
    
    rc = OrdrBkGetOrdr( set, (*ppBilOrdrMgmt)->ordrSlot[1],  ppAskOrder);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtOcoUpdt(int32 set, int64 ocoOrdrNo, int32 ordrSts, pOrdrMgmtRcrdT  pOrdrMgmt)
{
    BEGIN_FUNCTION( "OrdrMgmtOcoUpdate" );
    ResCodeT        rc = NO_ERR;
    
    uint32           ordrPos = -1;
    pOrdrMgmtRcrdT  pTmpOrdrMgmt = NULL;
    OrdrMgmtRcrdT   ordrMgmt;
    
    pOrdrMgmt->ordrKey.ordrNo = ocoOrdrNo;
    pOrdrMgmt->ordrKey.ordrType = EXT_ORD_TYPE_OCO;
    pOrdrMgmt->ordrSts = ordrSts; 
    
    memcpy(&ordrMgmt.ordrKey, &pOrdrMgmt->ordrKey, sizeof(OrdrMgmtKeyT));
    
    rc = OrdrMgmtChk(set, &ordrMgmt.ordrKey, &pTmpOrdrMgmt, &ordrPos);
    if (ERR_CMN_HASH_LIST_NODE_EXISTED != rc)
    {
        RAISE_ERR( rc, RTN );
    }
    
    if (ERR_CMN_HASH_LIST_NODE_EXISTED == rc)
    {   
        pTmpOrdrMgmt->ordrSts = pOrdrMgmt->ordrSts;
        
        if (pOrdrMgmt->ordrCnt)
        {   
            pTmpOrdrMgmt->ordrCnt = pOrdrMgmt->ordrCnt;
            memcpy(pTmpOrdrMgmt->ordrSlot, pOrdrMgmt->ordrSlot, sizeof(SlotT) * pTmpOrdrMgmt->ordrCnt );
        }
 
        rc = OrdrMgmtUpdtByPos(set, ordrPos, pTmpOrdrMgmt); //do update
    }
    else
    {
        rc = OrdrMgmtLogByPos(set, ordrPos, pOrdrMgmt); //do add 
    }
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtOcoDatPrpr(int32 ordrSts, pOrdrMgmtRcrdT pOrdrMgmt, pOrderT pOrder)
{
    BEGIN_FUNCTION( "OrdrMgmtOcoDatPrpr" );
    ResCodeT        rc = NO_ERR;

    pOrdrMgmt->ordrSlot[pOrdrMgmt->ordrCnt] = pOrder->orderT.slotNo;
    pOrdrMgmt->ordrCnt++;
    
    //pOrder->orderF.ordrSts = ordrSts;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtOcoGet(int32 set, int64 ocoOrdrNo,pOrdrMgmtRcrdT * ppOcoOrdrMgmt, pOrderT * ppNmrlOrder, int64 * pIter)
{
    BEGIN_FUNCTION( "OrdrMgmtOcoGet" );
    ResCodeT        rc = NO_ERR;
    uint32           ordrPos;
    
    OrdrMgmtKeyT    orderKey = {0};
     
    orderKey.ordrNo = ocoOrdrNo;
    orderKey.ordrType = EXT_ORD_TYPE_OCO; 
    
    rc = OrdrMgmtGetByNo(set, &orderKey, ppOcoOrdrMgmt, &ordrPos);
    RAISE_ERR( rc, RTN );
    
    * pIter = 0;
    
    rc = OrdrBkGetOrdr( set, (*ppOcoOrdrMgmt)->ordrSlot[* pIter],  ppNmrlOrder);
    RAISE_ERR( rc, RTN );
    
    (* pIter) ++;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrMgmtOcoGetNext(int32 set, pOrdrMgmtRcrdT  pOcoOrdrMgmt, pOrderT * ppNmrlOrder, int64 * pIter)
{
    BEGIN_FUNCTION( "OrdrMgmtOcoGetNext" );
    ResCodeT        rc = NO_ERR;
    
    if ((* pIter) >= pOcoOrdrMgmt->ordrCnt)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
    
    rc = OrdrBkGetOrdr( set, pOcoOrdrMgmt->ordrSlot[*pIter],  ppNmrlOrder);
    RAISE_ERR( rc, RTN );
    
    (* pIter) ++;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}