﻿/***
Created on Aug 10, 2017
@author: Pei.Rao
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "err_cod.h"
#include "uti_tool.h"
#include "common_hash.h"
#include "shm.h"
#include "ordr_mgmt.h"
#include "order_book.h"
#include "brdg_ordr_mgmt.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT gBrdgOrdrHshHdl[MAX_SET_CNT] = { 0 };

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
 

ResCodeT BrdgOrdrShmCreate(int64 rcrdCnt, int32 setId)
{
    BEGIN_FUNCTION("BrdgOrdrShmCreate");
    ResCodeT rc = NO_ERR;
    
    HashTableRecInfoT recInfo;
    void *pShmRoot;
    char shmName[SHM_NAME_LEN];
    
    recInfo.recSize = sizeof(BrdgOrdrRcrdT);
    recInfo.keyOffset = offsetof(BrdgOrdrRcrdT, ordrKey);
    recInfo.keySize = sizeof(BrdgOrdrKeyT);
    recInfo.recCnt = rcrdCnt;
    recInfo.bNeedTimeList = TRUE;
    
    sprintf(shmName, SHM_BRDG_ORDR_NAME, setId);
    
    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)shmName), recInfo, TRUE, &pShmRoot, &gBrdgOrdrHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrShmDetach(int32 setId)
{
    BEGIN_FUNCTION("BrdgOrdrShmDetach");
    ResCodeT rc = NO_ERR;
    
    char shmName[SHM_NAME_LEN];
    sprintf(shmName, SHM_BRDG_ORDR_NAME, setId);
    rc = ShmDetach(GetShmNm((char*)shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrShmAttach(int32 setId)
{
    BEGIN_FUNCTION("BrdgOrdrShmAttach");
    ResCodeT rc = NO_ERR;
    
    void *pShmRoot;
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_BRDG_ORDR_NAME, setId);
    rc = CmnHashTblAttach(GetShmNm((char*)shmName), &pShmRoot, &gBrdgOrdrHshHdl[setId]);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrShmDelete(int32 setId)
{
    BEGIN_FUNCTION("BrdgOrdrShmDelete");
    ResCodeT rc = NO_ERR;
    
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_BRDG_ORDR_NAME, setId);
    rc = ShmDetach(GetShmNm((char*)shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrShmReset(int32 setId)
{
    BEGIN_FUNCTION("BrdgOrdrShmReset");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashResetTbl(gBrdgOrdrHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




ResCodeT BrdgOrdrChk(int32 setId, pBrdgOrdrKeyT pBrdgOrdrKey, pBrdgOrdrRcrdT * ppBrdgOrdr, uint32 * pBrdgOrdrPos)
{
    BEGIN_FUNCTION("BrdgOrdrChk");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gBrdgOrdrHshHdl[setId], (void*)pBrdgOrdrKey, &isExist, (uint32*)pBrdgOrdrPos, (void**)ppBrdgOrdr);
    RAISE_ERR(rc, RTN);
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrAdd(int32 setId, pBrdgOrdrRcrdT pBrdgOrdr, uint32 * pBrdgOrdrPos)
{
    BEGIN_FUNCTION("BrdgOrdrAdd");
    ResCodeT rc = NO_ERR;
    
    BOOL              isExist = FALSE;
    uint32             nodePos;
    pBrdgOrdrRcrdT    pTempBrdgOrdr;
    
    rc = CmnHashCheckDataExt(gBrdgOrdrHshHdl[setId], (void*)&pBrdgOrdr->ordrKey, &isExist, &nodePos, (void**)&pTempBrdgOrdr);
    RAISE_ERR(rc, RTN);
    
    *pBrdgOrdrPos = nodePos;
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
    
    rc = CmnHashLogData(gBrdgOrdrHshHdl[setId], pBrdgOrdr, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrGetByPos(int32 setId, pBrdgOrdrKeyT pBrdgOrdrKey, uint32 brdgOrdrPos, pBrdgOrdrRcrdT *ppBrdgOrdr )
{
    BEGIN_FUNCTION("BrdgOrdrGetByPos");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    uint32 nodePos;
    
    rc = CmnHashCheckDataExt(gBrdgOrdrHshHdl[setId], (void*)pBrdgOrdrKey, &isExist, &nodePos, (void**)ppBrdgOrdr );
    RAISE_ERR(rc, RTN);
    
    brdgOrdrPos = nodePos;
    
    if (isExist == FALSE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrDel(int32 setId, pBrdgOrdrKeyT pBrdgOrdrKey)
{
    BEGIN_FUNCTION("BrdgOrdrDel");
    ResCodeT rc = NO_ERR;
    
    BrdgOrdrRcrdT           brdgOrdr;
    uint32                   brdgOrdrPos;
    pBrdgOrdrRcrdT          pBrdgOrdr;
    
    rc = BrdgOrdrChk(setId, pBrdgOrdrKey, &pBrdgOrdr, &brdgOrdrPos);
    if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        RAISE_ERR(ERR_CMN_HASH_LIST_NODE_NOT_EXIST, RTN);
    }
    
    rc = CmnHashDeleteData(gBrdgOrdrHshHdl[setId], brdgOrdrPos);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrDelByPos(int32 setId, uint32 brdgOrdrPos)
{
    BEGIN_FUNCTION("BrdgOrdrDelByPos");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashDeleteData(gBrdgOrdrHshHdl[setId], brdgOrdrPos);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT BrdgOrdrMgmtIter(int32 setId, uint32* pNodePos, pBrdgOrdrRcrdT  pBrdgOrdrRcrd)
{
    BEGIN_FUNCTION("BrdgOrdrMgmtIter");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterData(gBrdgOrdrHshHdl[setId], (uint32*)pNodePos, (void*)pBrdgOrdrRcrd);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrdrMgmtDelAll( int32 setId )
{
    BEGIN_FUNCTION("BrdgOrdrMgmtDelAll");
    ResCodeT rc = NO_ERR;
    
    int64 brdgOrdNode = CMN_LIST_NULL_NODE;
    
    pBrdgOrdrRcrdT pBrdgOrdrRcrd = NULL;
    
    while ( TRUE )
    {
        rc = CmnHashIterData(gBrdgOrdrHshHdl[setId], (uint32*)&brdgOrdNode, (void*)pBrdgOrdrRcrd);
        RAISE_ERR(rc, RTN);

        if ( brdgOrdNode == CMN_LIST_NULL_NODE )
        {
            break;
        }

        rc = CmnHashDeleteData(gBrdgOrdrHshHdl[setId], brdgOrdNode);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrdrMgmtDelAllByOrgId( int32 setId, uint32 orgId )
{
    BEGIN_FUNCTION("BrdgOrdrMgmtDelAllByOrgId");
    ResCodeT rc = NO_ERR;
    
    int64 brdgOrdNode = CMN_LIST_NULL_NODE;
    
    pBrdgOrdrRcrdT pBrdgOrdrRcrd = NULL;
    
    while ( TRUE )
    {
        rc = CmnHashIterData(gBrdgOrdrHshHdl[setId], (uint32*)&brdgOrdNode, (void*)pBrdgOrdrRcrd);
        RAISE_ERR(rc, RTN);

        if ( brdgOrdNode == CMN_LIST_NULL_NODE )
        {
            break;
        }

        if ( pBrdgOrdrRcrd->ordrKey.entyIdxNo == orgId )
        {
            rc = CmnHashDeleteData(gBrdgOrdrHshHdl[setId], brdgOrdNode);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT BrdgOrdrMgmtDelAllByBrdgOrgId( int32 setId, uint32 brdgOrgId )
{
    BEGIN_FUNCTION("BrdgOrdrMgmtDelAllByBrdgOrgId");
    ResCodeT rc = NO_ERR;
    
    int64 brdgOrdNode = CMN_LIST_NULL_NODE;
    
    pBrdgOrdrRcrdT pBrdgOrdrRcrd = NULL;
    
    while ( TRUE )
    {
        rc = CmnHashIterData(gBrdgOrdrHshHdl[setId], (uint32*)&brdgOrdNode, (void*)pBrdgOrdrRcrd);
        RAISE_ERR(rc, RTN);

        if ( brdgOrdNode == CMN_LIST_NULL_NODE )
        {
            break;
        }

        if ( pBrdgOrdrRcrd->brdgOrgId == (int64)brdgOrgId )
        {
            rc = CmnHashDeleteData(gBrdgOrdrHshHdl[setId], brdgOrdNode);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
