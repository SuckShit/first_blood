/***
Created on August 14, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "common_macro.h"
#include "uti_tool.h"

#include "CrdtDb.h"
#include "CntrctBaseInfoDb.h"
#include "CrdtDlAmntDb.h"
#include "OrgInfoDb.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"

#include "base_param.h"
#include "org_info.h"
#include "contract_info.h"
#include "credit_info.h"
#include "usr.h"
#include "usr_role.h"
#include "usr_def_ref.h"
#include "credit_common.h"
#include "order_type.h"
#include "credit_mgmt.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CreditOrgCheck(int32 orgCnt)
{
    BEGIN_FUNCTION("CreditOrgCheck");
    ResCodeT rc = NO_ERR;
    pBaseParamT pParamData;

    //��ȡ��С���ŷ�����
    rc = BaseParamGetByNameExt((char *)C_CRT_MINORGCOUNT, &pParamData);
    RAISE_ERR(rc, RTN);

    if (orgCnt < atoi(pParamData->paramValue)) {
        RAISE_ERR(ERR_CODE_INVLD_CRT_INVLD, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateOrgCrdt(int32 connId, int32 in_orgId)
{
    BEGIN_FUNCTION("UpdateOrgCrdt");
    ResCodeT rc = NO_ERR;
    int32 intOrgId;
    BOOL bFrstFlg = TRUE;
    
    OrgInfoT orgInfo;
    int32 iCrdtMthd;

    CntrctBaseInfo dbCntrctBaseInfo;
    Crdt dbCrdt;
    CrdtDlAmnt dbCrdtDlAmnt;

    vectorT  keyVec[GET_BIT_VECT_LEN(6)] = {0};
    vectorT  datVec[GET_BIT_VECT_LEN(6)] = {0};

    intOrgId = in_orgId;
    memset(&orgInfo, 0x00, sizeof(OrgInfoT));
    rc = OrgInfoGetById(intOrgId, &orgInfo);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    iCrdtMthd = orgInfo.crdtMthd;

    memset(&dbCrdt, 0x00, sizeof(Crdt));
    while (OK(FetchNextCrdtBySt(&bFrstFlg, connId, &dbCrdt))) {
        if (iCrdtMthd == C_CREDIT_RL) {
            memset(&dbCrdtDlAmnt, 0x00, sizeof(CrdtDlAmnt));
            // set key value.
            dbCrdtDlAmnt.crdtOrgId  = intOrgId;
            dbCrdtDlAmnt.crdtdOrgId = dbCrdt.crdtdOrgId;
            DbCmmnSetColBit(keyVec, 2);
            DbCmmnSetColBit(keyVec, 3);

            // set data value. 
            // 1.DL_AMNT.
            if (C_CRT_RL == atoi(dbCrdt.crdtRlF)) {
                dbCrdtDlAmnt.dlAmnt = C_MAX_CRDT_AMNT;
            }
            else {
                dbCrdtDlAmnt.dlAmnt = 0;
            }
            // 2.UPD_TM
            strcpy(dbCrdtDlAmnt.updTm, "");

            DbCmmnSetColBit(datVec, 5);
            DbCmmnSetColBit(datVec, 6);

            rc = UpdateCrdtDlAmntByKey(connId, &dbCrdtDlAmnt, keyVec, datVec);
            RAISE_ERR(rc, RTN);
        }
        else {
            bFrstFlg = TRUE;
            memset(&dbCntrctBaseInfo, 0x00, sizeof(CntrctBaseInfo));
            while (OK(FetchNextCntrctBaseInfoBySt(&bFrstFlg, connId, &dbCntrctBaseInfo))) {
                memset(&dbCrdtDlAmnt, 0x00, sizeof(CrdtDlAmnt));
                // set key value.
                dbCrdtDlAmnt.crdtOrgId  = intOrgId;
                dbCrdtDlAmnt.crdtdOrgId = dbCrdt.crdtdOrgId;
                strcpy(dbCrdtDlAmnt.cntrctNm, dbCntrctBaseInfo.cntrctNm);

                DbCmmnSetColBit(keyVec, 2);
                DbCmmnSetColBit(keyVec, 3);
                DbCmmnSetColBit(keyVec, 4);

                // set data value. 
                // 1.DL_AMNT.
                if (dbCntrctBaseInfo.term > dbCrdt.crdtTerm * 12) {
                    dbCrdtDlAmnt.dlAmnt = 0;
                }
                else {
                    rc = GetCreditAllowance(intOrgId, dbCrdt.crdtdOrgId, dbCntrctBaseInfo.cntrctNm, (uint64*)&dbCrdtDlAmnt.dlAmnt);
                    RAISE_ERR(rc, RTN);
                }
                // 2.UPD_TM
                strcpy(dbCrdtDlAmnt.updTm, "");

                DbCmmnSetColBit(datVec, 5);
                DbCmmnSetColBit(datVec, 6);

                rc = UpdateCrdtDlAmntByKey(connId, &dbCrdtDlAmnt, keyVec, datVec);
                RAISE_ERR(rc, RTN);
            }
        }

    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetCreditAllowance(int32 in_orgId, int32 in_crdtdOrgId, char* in_cntrctNm, uint64* out_Amnt)
{
    BEGIN_FUNCTION("GetCreditAllowance");
    ResCodeT rc = NO_ERR;

    pCreditT pCredit;
    pCntrctBaseInfoT pCntrctBaseInfo;

    uint64 iRmnCrdtAmnt;
    uint64 iAmnt;

    uint64 iShortRishCoef;
    uint64 iLongRishCoef;

    uint64 iShortAmntRatio;
    uint64 iLongAmntRatio;
    uint64 iSpecAmntRatio;
    uint64 iDealUnit;

    rc = CreditInfoGetByKeyExt(in_orgId, in_crdtdOrgId, &pCredit);
    RAISE_ERR(rc, RTN);
    iRmnCrdtAmnt = pCredit->rmnCrdtAmnt;

    // �жϺ�Լ����
    rc = IrsCntrctInfoGetByNameExt(in_cntrctNm, &pCntrctBaseInfo);
    RAISE_ERR(rc, RTN);

    iShortAmntRatio = pCntrctBaseInfo->shrtAmntRatio;
    iLongAmntRatio  = pCntrctBaseInfo->lngAmntRatio;
    iDealUnit = pCntrctBaseInfo->dealUnit;

    if (C_CONTRACT_TYPE_ISP == pCntrctBaseInfo->cntrctType ||
        C_CONTRACT_TYPE_SIC == pCntrctBaseInfo->cntrctType) {
        //�ڲ��Լ����׼������Լ
        rc = GetRiskInfo(in_orgId, pCntrctBaseInfo->shrtCntrctName, &iShortRishCoef);
        RAISE_ERR(rc, RTN);

        rc = GetRiskInfo(in_orgId, pCntrctBaseInfo->lngCntrctName, &iLongRishCoef);
        RAISE_ERR(rc, RTN);

        iAmnt = floor( ( iRmnCrdtAmnt * iLongAmntRatio / 
                ( iShortRishCoef * iShortAmntRatio + iLongRishCoef  * iLongAmntRatio ) ) / 
                iDealUnit ) * iDealUnit;
    }
    else {
        rc = GetRiskInfo(in_orgId, in_cntrctNm, &iSpecAmntRatio);
        RAISE_ERR(rc, RTN);

        iAmnt = floor((iRmnCrdtAmnt / iSpecAmntRatio) / iDealUnit) * iDealUnit;
    }

    *out_Amnt = iAmnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetRiskInfo(int32 in_orgId, char* in_cntrctNm, uint64* out_Amnt)
{
    BEGIN_FUNCTION("GetRiskInfo");
    ResCodeT rc = NO_ERR;

    pRiskCfcntT pRiskCfcnt;
    uint64 iRiskCoef;

    rc = IrsRiskCfcntGetByKeyExt(in_orgId, in_cntrctNm, &pRiskCfcnt);
    if (NOTOK(rc)) {
        *out_Amnt = 100;
        RAISE_ERR(rc, RTN);
    }
    iRiskCoef = pRiskCfcnt->rskCfcntVal;
    *out_Amnt = iRiskCoef;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CreditOrgCheckForRisk(int32 orgId)
{
    BEGIN_FUNCTION("CreditOrgCheckForRisk");
    ResCodeT                rc = NO_ERR;
    pOrgInfoT               pOrgInfoData;
    pBaseParamT             pParamData = NULL;
    pCreditT                pCredit = NULL;
    pCntrctBaseInfoT        pCntrct = NULL;
    pRiskCfcntT             pRiskCfcnt = NULL;
    uint64                  iRefCrtAmount;
    uint64                  iCrtUseRskCof;
    uint32                  crdtPos = CMN_LIST_NULL_NODE;
    int32                   intOrgId;    
    int32                   iCrtMthd;
    uint32                  iMinCrtOrgNum;
    int32                   iCrtUseNum = 0;
    int32                   iCrtUseAmount;
    int32                   iCrtLmtNum;
    char                    strCrtUseNm[MAX_CNTRCT_NM];

    intOrgId        = orgId;
    rc = OrgInfoGetByIdExt(intOrgId, &pOrgInfoData);
    RAISE_ERR(rc, RTN);

    iCrtMthd = pOrgInfoData->crdtMthd;

    /* ��ȡ��С���ŷ�����*/
    rc = BaseParamGetByNameExt((char *)C_CRT_MINORGCOUNT, &pParamData);
    RAISE_ERR(rc, RTN);

    iMinCrtOrgNum = atoi(pParamData->paramValue);

    /* ���������*/
    if (C_CREDIT_AMT == iCrtMthd) 
    {
        /* ���Ųο���Լ*/
        memset(strCrtUseNm, 0x00, sizeof(strCrtUseNm));
        rc = BaseParamGetByNameExt((char *)C_CRT_RFCCNTCT, &pParamData);
        if (NOTOK(rc) && ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc) 
        {
            RAISE_ERR(ERR_CODE_REFCNTRCT_EMPTY, RTN);
        }
        else
        {
            RAISE_ERR(rc, RTN);
        }
        strcpy(strCrtUseNm, pParamData->paramValue);

        /* ���Ųο���Լ��Ӧ�ķ���ϵ��(RSK_CFCNT) */
        rc = IrsRiskCfcntGetByKeyExt(intOrgId, strCrtUseNm, &pRiskCfcnt);
        if (NOTOK(rc) && ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc) 
        {
            RAISE_ERR(ERR_CODE_REFCNTRCT_RSK_EMPTY, RTN);
        }
        else
        {
            RAISE_ERR(rc, RTN);
        }
        
        iCrtUseRskCof = pRiskCfcnt->rskCfcntVal;

        /* ���Ųο���Լ��Ӧ����*/
        rc = BaseParamGetByNameExt((char *)C_CRT_LMT, &pParamData);
        if (NOTOK(rc) && ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc) 
        {
            RAISE_ERR(ERR_CODE_REFCNTRCT_LMT_EMPTY, RTN);
        }
        else
        {
            RAISE_ERR(rc, RTN);
        }
        iCrtLmtNum = atoi(pParamData->paramValue);

        /* ȡ���Ųο�*/
        rc = IrsCntrctInfoGetByNameExt((char *)strCrtUseNm, &pCntrct);
        if (NOTOK(rc) && ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc) 
        {
            RAISE_ERR(ERR_CODE_CNTRCT_DL_UNIT_EMPTY, RTN);
        }
        else
        {
            RAISE_ERR(rc, RTN);
        }
        iCrtUseAmount = pCntrct->dealUnit;

        /* �ο�����*/
        iRefCrtAmount = iCrtLmtNum * (iCrtUseAmount * pow10(FIGURES_OF_CREDIT_AMOUNT)) *
                        (iCrtUseRskCof/(PRICE_BASE));

        iCrtUseNum = 0;
        while (TRUE)
        {
            pCredit = NULL;
            rc = CreditInfoIterExt(&crdtPos, &pCredit);
            if (CMN_LIST_NULL_NODE == crdtPos)
            {
                break;
            }
            RAISE_ERR(rc, RTN);

            if (pCredit->crdtOrgId == intOrgId && pCredit->crdtRlFlag[0] == CREDIT_RELATION_AMNT && 
                pCredit->rmnCrdtAmnt >= iRefCrtAmount)
            {
                iCrtUseNum++;
            }
        }

        if (iCrtUseNum < iMinCrtOrgNum) 
        {
            RAISE_ERR(ERR_CODE_INVLD_CRT_INVLD, RTN);
        }
    }
    else 
    {
        RAISE_ERR(ERR_CODE_INVLD_CRT_INVLD, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}