﻿/***
Created on June 20, 2017
@author: 
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <errno.h>
#include <time.h>

/* Project Header File */
#include "../include/data_type.h"
#include "../include/err_lib.h"
#include "../include/err_cod.h"
#include "../include/cfg_lib.h"
#include "../include/uti_tool.h"
#include "../include/common_macro.h"

/*****************************************************************************
**
** Macro
**
*****************************************************************************/
#define ARRAY_LEN 25
#define TIMESTAMP_LEN 20
#define DATE_OFFESRT_LEN  8
#define STR_TIME_NO_US_LEN 9
#define STR_TIME_US_LEN 12

// 时间格式
static const char C_FORMAT_TIME[]           = "%Y%m%d-%H:%M:%S"; //年月日时分秒 "YYYYMMDD-HH24:MI:SS"


/******************************************************************************
**
**  Structure
**
******************************************************************************/
 
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

/*=============================================================================
**=============================================================================
** Utility Function(SP) 
**=============================================================================
=============================================================================*/
/******************************************************************************
 **
 ** GetSystemTime
 **
 ******************************************************************************/
ResCodeT GetSystemTime(time_t* pTime)
{
    BEGIN_FUNCTION( "GetSystemTime" );
    ResCodeT rc = NO_ERR;

    *pTime = time(NULL); // get current time

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetSystemTime
 **
 ******************************************************************************/
ResCodeT GetStringOfSystemTime(char* pTime)
{
    BEGIN_FUNCTION( "GetSystemTime" );
    ResCodeT rc = NO_ERR;

    time_t curTm;
    rc = GetSystemTime(&curTm);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    rc = ConvertFromTimeToChar(curTm, pTime);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ConvertFromCharToTime
 **
 ******************************************************************************/
ResCodeT ConvertFromCharToTime(char* pString, time_t* pTime)
{
    BEGIN_FUNCTION( "ConvertFromCharToTime" );
    ResCodeT rc = NO_ERR;

    struct tm tmTm;
    char year[5] = { 0 };
    char month[3] = { 0 };
    char day[3] = { 0 };
    char hour[3] = {0};
    char mins[3] = {0};
    char seconds[3] = {0};

    strncpy(year,    pString,    4);
    strncpy(month,   pString+4,  2);
    strncpy(day,     pString+6,  2);
    strncpy(hour,    pString+9,  2);
    strncpy(mins,    pString+12, 2);
    strncpy(seconds, pString+15, 2);
    
    tmTm.tm_year = atoi(year)-1900;
    tmTm.tm_mon  = atoi(month)-1;
    tmTm.tm_mday = atoi(day);
    tmTm.tm_hour = atoi(hour);
    tmTm.tm_min  = atoi(mins);
    tmTm.tm_sec  = atoi(seconds);
    *pTime = mktime(&tmTm);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ConvertFromTimeToChar
 **
 ******************************************************************************/
ResCodeT ConvertFromTimeToChar(time_t iTime, char* pString)
{
    BEGIN_FUNCTION( "ConvertFromTimeToChar" );
    ResCodeT rc = NO_ERR;

    struct tm *tmTm;
    tmTm = localtime(&iTime);
    if (!tmTm) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }
    sprintf(pString, "%04d%02d%02d-%02d:%02d:%02d", 
        tmTm->tm_year+1900, 
        tmTm->tm_mon+1, 
        tmTm->tm_mday, 
        tmTm->tm_hour, 
        tmTm->tm_min, 
        tmTm->tm_sec);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
//SP Used End.



ResCodeT DateTimeToTimestamp(char * dateTime, int64* pTimestamp)
{
    BEGIN_FUNCTION( "DateTimeToTimestamp" );
    ResCodeT rc = NO_ERR;
    int64 timeInSec = 0;
    
    rc = ConvertFromCharToTime(dateTime, &timeInSec);
    RAISE_ERR(rc, RTN);
    
    *pTimestamp = timeInSec * 1000000;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}





ResCodeT GetStrEnvVar(char *varNm,char *pVarValue) {
    BEGIN_FUNCTION("GetStrEnvVar"); 
    ResCodeT rc = NO_ERR;
    char    buffer[MAX_BUFF_LEN] = {0};
    char    postFix[] = "/bin";
    int32   pathLen = 0;
    char *  pVar = NULL;
    //strcpy(pVarValue,getenv(varNm));
    pVar = getenv(varNm);
    if (pVar)
    {
        sprintf(pVarValue,"%s",  pVar);
    }
    else
    {
        sprintf(pVarValue,"%s",  "../cfg/");
    }
    
    
    //getcwd(buffer,MAX_BUFF_LEN);
    
//    char * pPostFix = strstr(buffer, postFix);
//    
//    pathLen = pPostFix - buffer;
//    
   // memcpy(pVarValue,buffer, MAX_BUFF_LEN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetIntEnvVar(char *varNm,int64 *pVarValue) {

    BEGIN_FUNCTION("GetIntEnvVar"); 
    ResCodeT rc = NO_ERR;
    if (atoi(getenv(varNm)) == 0){
        RAISE_ERR(ENV_VAR_CONV_ERR, RTN);
    }
    else {
        *pVarValue = atoi(getenv(varNm));
    }
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetSysTimestamp(int64* timestamp)
{
    BEGIN_FUNCTION("GetSysTimestamp"); 
    ResCodeT rc = NO_ERR;
    struct timeval t_val;
    gettimeofday(&t_val,NULL);
    int64 sec = (int64)t_val.tv_sec;
    int64 us = (int64)t_val.tv_sec*1000000+(int64)t_val.tv_usec;
    *timestamp = us;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetStrTime(int64 timestamp, char * pTime, BOOL uSec)
{
    BEGIN_FUNCTION("GetStrTime");
    ResCodeT rc = NO_ERR;
    int32 ms,us;
    struct tm *ptime;
    char datetime[ARRAY_LEN];
    time_t timeInSec;
    char temp[ARRAY_LEN];
    int32 len =1;
    memset(datetime, 0, sizeof(datetime));    

    timeInSec =(time_t)(timestamp/1000000);
    ptime = localtime(&timeInSec);
    strftime(datetime,30,"%X",ptime);
    
    if (uSec==TRUE)
    {
    us=timestamp%1000;
    ms=(timestamp%1000000)/1000;
    
    sprintf(temp,":%ld:%ld",ms,us);
    strcat(datetime,temp); 
    strcpy(pTime,datetime);
    }
    if (uSec==FALSE)
    {
    strcpy(pTime,datetime);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetStrDateTime(int64 timestamp,char * pDate, char * pTime)
{
    BEGIN_FUNCTION("GetStrDateTime");
    ResCodeT rc = NO_ERR;

    struct tm *pdate;
    char datetime[ARRAY_LEN];
    char temp[ARRAY_LEN];
    char clockTime[ARRAY_LEN];
    time_t timeInSec;
    memset(datetime, 0, sizeof(datetime));
    
    timeInSec =(time_t)(timestamp/1000000);
    pdate = localtime(&timeInSec);
    
    strftime(datetime,30,"%Y%m%d",pdate);
    strcpy(pDate,datetime);
    strftime(clockTime,30,"%X",pdate);
    strcpy(pTime,clockTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetStrDateTimeByFormat(int64 timestamp,char* pDateTime)
{
    BEGIN_FUNCTION("GetStrDateTime");
    ResCodeT rc = NO_ERR;

    struct tm *pdate;
    char datetime[ARRAY_LEN];
    char temp[ARRAY_LEN];
    char clockTime[ARRAY_LEN];
    char timeByformat[ARRAY_LEN];
    time_t timeInSec;
    memset(datetime, 0, sizeof(datetime));
    
    timeInSec =(time_t)(timestamp/1000000);
    pdate = localtime(&timeInSec);
    
    strftime(datetime,30,"%Y%m%d",pdate);
    strftime(clockTime,30,"%X",pdate);

    sprintf(timeByformat,"%s-%s",datetime,clockTime);
    strcpy(pDateTime,timeByformat);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT TimeToSecs(char * pDateTime, int64 * pSec)
{
    BEGIN_FUNCTION("TimeToSecs");
    ResCodeT rc = NO_ERR;
    
    char hour[3] = {0};
    char mins[3] = {0};
    char seconds[3] = {0};
    
    memcpy(hour, &pDateTime[9], 2);
    memcpy(mins, &pDateTime[12], 2);
    memcpy(seconds, &pDateTime[15], 2);
    *pSec = atoi(seconds) + atoi(mins)*60 + atoi(hour)*3600;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SecondsToDateTime(char * pDateTime, int64 seconds, char* pNewTime)
{
    BEGIN_FUNCTION("TimeToSecs");
    ResCodeT rc = NO_ERR;
    
    char year[5];
    char month[3];
    char date[3];
    int32 hour;
    int32 mins;
    int32 sec;

    memcpy(date, &pDateTime[0], 8);
    
    hour = seconds/3600;
    mins = seconds%3600/60;
    sec = seconds%60;
    sprintf(pNewTime,"%d-%02d:%02d:%02d",atoi(date),hour,mins,sec);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ReplaceWord(char *word, char*find,char*replace,char*newWord)
{
    BEGIN_FUNCTION("ReplaceWord");
    ResCodeT rc = NO_ERR;
    
    char* temp;
    temp = (char*)malloc(strlen(word)-strlen(find)+strlen(replace)+1);
    char *ptr;
    strcpy(temp,word);
    ptr = strstr(temp,find);
    if (ptr) {
        memmove(ptr+strlen(replace),ptr+strlen(find),strlen(ptr+strlen(find))+1);
        strncpy(ptr,replace,strlen(replace)); 
    }
    strcpy(newWord,temp);
    EXIT_BLOCK();
    RETURN_RESCODE;
}

char* GetShmNm(char* shmName)
{
    ResCodeT rc = NO_ERR;
    char toRep[MAX_BUFF_LEN];
    static char outFileNmWithPrcsId[MAX_BUFF_LEN] = {0};
    memset(outFileNmWithPrcsId,0,MAX_BUFF_LEN);
    char outFileNm[MAX_BUFF_LEN] = {0};
    memset(outFileNm,0,sizeof(outFileNm));
    char sessionName[] = "default";
    char cfgName[] = "env";
    char splitName[]= "@@";
    struct cfgValueS re;
    rc = GetCfgValue(&re);
    strcpy(toRep,re.envNo);
    if (strcmp(re.envNo,"")==0) 
    {
        strcpy(outFileNm,shmName);
        //return outFileNm;
    }
    if (rc != NO_ERR) {
        strcpy(outFileNm,shmName);
        //return outFileNm;
    }
    
    if (strstr(shmName, splitName) != NULL){
        ReplaceWord(shmName,splitName,toRep,outFileNm);
    }
    else
    {
        strcpy(outFileNm,shmName);
        //return outFileNm;
    }
    
    sprintf(outFileNmWithPrcsId, "%s_P%02d", outFileNm,re.prcsId );
    
    return outFileNmWithPrcsId;
}

ResCodeT PrcsInit(char* rootPath)
{
   
    BEGIN_FUNCTION("PrcsInit");
    ResCodeT rc = NO_ERR;

    RAISE_ERR(CfgInit(rootPath),RTN);
    RAISE_ERR(LogInit(rootPath),RTN);
    RAISE_ERR(ErrDescInit(), RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetCurrentTime
 **
 ******************************************************************************/
ResCodeT GetCurrentTime(char* sUpdateTime)
{
    BEGIN_FUNCTION( "GetCurrentTime" );
    ResCodeT rc = NO_ERR;

    memset(sUpdateTime, 0, sizeof(char)*MAX_TIME_LEN);

    struct tm*  tm_now;
    time_t      now;

    time(&now);
    tm_now = localtime(&now);
    strftime(sUpdateTime, MAX_TIME_LEN, C_FORMAT_TIME, tm_now);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CnvtDoubleToIntnlVal(double input, int64 * pPrice )
{
    BEGIN_FUNCTION("CnvtPriceToIntnlVal");
    ResCodeT                rc = NO_ERR;

    * pPrice = input * PRICE_BASE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
