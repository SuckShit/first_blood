/***
Created on June 13, 2017
@author: No One
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <time.h>  
#include <stdarg.h>  
#include <assert.h>
#include <unistd.h>


/* Project Header File*/
#include "../include/common_macro.h"
#include "../include/data_type.h"
#include "../include/err_lib.h"
#include "../include/uti_tool.h"
#include "../include/cfg_lib.h"
#include "UTILITY/logfile.h"
#include "../include/common_hash.h"
#include "../include/shm_name.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_ERR_INFO 20000
#define MAX_BUFFER_LEN 2048


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/



/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
FILE * fp = NULL;
static CmnHashHndlT gErrDescHshHdl = -1;
static BOOL         bErrInit = FALSE;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
 
ResCodeT GetErrInfo(int32 errCod, pErrInfoT * ppErrInfo)
{
    BEGIN_FUNCTION("GetErrInfo");
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    int64 tmpErrCode = errCod;

    rc = CmnHashCheckDataExt(gErrDescHshHdl, (void*)&tmpErrCode, &isExist, &nodePos, (void**)ppErrInfo );
    RAISE_ERR(rc, RTN);
    if (isExist == FALSE)
    {
        LOG_ERROR(ERR_CMN_HASH_LIST_NODE_NOT_EXIST, "invalid errcode %lld", tmpErrCode);
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetErrMsg(int32 errCod, std::string& errMsg)
{
    BEGIN_FUNCTION("GetErrMsg");
    ResCodeT rc = NO_ERR;
    BOOL isExist = FALSE;
    uint32 nodePos;
    pErrInfoT  pErrInfo = NULL;
    int64 tmpErrCode = errCod;

    rc = CmnHashCheckDataExt(gErrDescHshHdl, (void*)&tmpErrCode, &isExist, &nodePos, (void**)&pErrInfo );
    RAISE_ERR(rc, RTN);
    
    
    if (isExist == FALSE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    errMsg = pErrInfo->errText;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
 
ResCodeT RaiseError(const ResCodeT errorCode, const char *fileName,
                    const int lineNo,const char *fctName,const char *sctName,
                    int parmFlag,...)
{
//fo char tmp[2048+1];
    char buffer[MAX_BUFFER_LEN+1];
    BOOL bHasOtherParm = 0;
    char tmp[MAX_BUFFER_LEN+1];
    std::string errMsg;
    char msg[TEXT_LEN];
    pErrInfoT pErrInfo = NULL;
    
    if (bErrInit)
    {
        GetErrInfo(errorCode, &pErrInfo);
        if (pErrInfo)
        {
            if (pErrInfo->errType == 0)
            {
                return NO_ERR;
            }
            
            errMsg = pErrInfo->errText;
        }
        else
        {
            errMsg = "Unknow error";
        }
    }
    else
    {
        errMsg = "Unknow error";
    }
    
    
    
    
	
    va_list params;
    va_start(params, parmFlag);

    vsprintf(tmp, errMsg.c_str(), params);
    tmp[MAX_BUFFER_LEN] = '\0';
    snprintf(buffer,MAX_BUFFER_LEN, " == %s", tmp );
    buffer[MAX_BUFFER_LEN] = '\0';
    bHasOtherParm = 1;
    va_end(params);
    
    if (!bHasOtherParm)
    {
        LOG_ERR_ERROR(errorCode, buffer,fileName, lineNo); 
    }
    else
    {
        LOG_ERR_ERROR(errorCode,errMsg.c_str(),fileName, lineNo); 
    }
    return NO_ERR;
}

ResCodeT TraceLog( const char *fileName,const int lineNo, const char * fctName,const char * sctName, const char * format, ...)
{
    char tmp[MAX_BUFFER_LEN+1];
    char buffer[MAX_BUFFER_LEN+1];
    va_list params;
    va_start(params, format);
    
    vsprintf(tmp, format, params);
    tmp[MAX_BUFFER_LEN] = '\0';
    snprintf(buffer,MAX_BUFFER_LEN, "%10.10s %5d %15.15s %s",fileName, lineNo,fctName , tmp );
    buffer[MAX_BUFFER_LEN] = '\0';
    
    va_end(params);
    LOG_ERR_INFO(buffer,fileName, lineNo);  

    return NO_ERR;
}



ResCodeT ErrDescInit()
{
    BEGIN_FUNCTION("ErrDescInit");
    ResCodeT rc = NO_ERR;    
    
    char shmName[] = SHM_ERR_DESC_NAME;
    HashTableRecInfoT recInfo;
    void *pShmRoot;
    int32 i = 0;
    BOOL isExist = FALSE;
    uint32 nodePos;
    pErrInfoT pErrInfo = NULL;
    int32 errCnt = 0;
    
    errCnt = sizeof(gErrInfoList)/sizeof(ErrInfoT);
    
    recInfo.recSize = sizeof(ErrInfoT);
    recInfo.keyOffset = offsetof(ErrInfoT, errCode);
    recInfo.keySize = sizeof(int64);
    recInfo.recCnt = errCnt + 10;
    recInfo.bNeedTimeList = FALSE;
    
    if (NO_ERR != CmnHashTblCreate(GetShmNm(shmName), recInfo, FALSE, &pShmRoot, &gErrDescHshHdl))
    {
    
        rc = CmnHashTblAttach(GetShmNm(shmName), &pShmRoot, &gErrDescHshHdl);
        RAISE_ERR(rc, RTN);    
    
    }
    RAISE_ERR(rc, RTN);
    
    for (i = 0; i < errCnt; i++ )
    {

        rc = CmnHashCheckDataExt(gErrDescHshHdl, (void*)&gErrInfoList[i].errCode, &isExist, &nodePos, (void**)&pErrInfo);
        RAISE_ERR(rc, RTN);
    
        if (isExist == TRUE)
        {
            LOG_ERROR(ERR_CMN_HASH_LIST_NODE_EXISTED, "duplicate error code %lld",gErrInfoList[i].errCode);
            RAISE_ERR(ERR_CMN_HASH_LIST_NODE_EXISTED,RTN);
        }
   
        rc = CmnHashLogData(gErrDescHshHdl, &gErrInfoList[i], nodePos, TRUE, TRUE);
        RAISE_ERR(rc, RTN);
    
    }
    
    bErrInit = TRUE;
      
    EXIT_BLOCK();
    RETURN_RESCODE;  
} 

ResCodeT LogInit(char *inPath)
{
    BEGIN_FUNCTION("LogInit");
    ResCodeT rc = NO_ERR;    
    char root[MAX_BUFF_LEN];
    memset(root, 0x00, MAX_BUFF_LEN);
    
    struct cfgValueS reslt;
    rc = GetCfgValue(&reslt);
    RAISE_ERR(rc, RTN); 
    
    
    strcpy(root,reslt.cfgPath);
    strcat(root,CFG_FILE_NM);
    
    LOG_DEBUG("Init Log %s", root);

    LOG_INITCFG(root);

    EXIT_BLOCK();
    RETURN_RESCODE;     
}