/***
Created on June 08, 2017
@author: No One
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <limits.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>

/* Project Header files*/
#include "../include/msg_cache.h"
#include "../include/msg_queue.h"
#include "../include/shm.h"
#include "../include/err_lib.h"
#include "../include/common_macro.h"
#include "../include/thread_id.h"
#include "../include/shm_name.h"
#include "../include/err_cod.h"
#include "../include/uti_tool.h"
#include "../include/cfg_lib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MsgCacheShmAdminTag
{
    /* the size of application administration structure*/
    uint64 adminSize;
    /* the size of each data element to be stored in shared memory*/
    uint64 elemSize;
    /*the amount of elements */
    uint32 frstLevSlotCnt;
    /*the amount of elements */
    uint32 secLevSlotCnt;

    /*mq config  */
    MsgQueueCfgT cfg;
} MsgCacheShmAdminT, *pMsgCacheShmAdminT;

typedef struct ThreadMsgCacheS
{
    int32   secLevAvaSlotCnt;
    int32   secLevReservedSlotFrmIdx;
    int32   secLevReservedSlotEndIdx;
    int32   filter;
    SlotT*  slot;
} ThreadMsgCacheT, *pThreadMsgCacheT;

typedef struct MsgCacheS
{
    char               dataShmName[SHM_NAME_LEN];
    uint32             frstLevAvaSlotCnt;
    uint32             secLevSlotCnt;
    int32              msgCacheHndl;
    int32              filter;
    pMsgCacheShmAdminT pRoot;
    pthread_mutex_t    tLock;
    ThreadMsgCacheT    threadCache[MAX_MSG_CACHE_THREAD_CNT];
    BOOL               bCreate;
} MsgCacheT, *pMsgCacheT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static MsgCacheT*    gMsgCache= NULL;
static int64        gMsgCacheCnt = 0;
static int32        gDfltMsgHndl = -1;
static BOOL         gbInitial = FALSE;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT MsgCacheInit()
{
    BEGIN_FUNCTION("MsgCacheInit");
    ResCodeT rc = NO_ERR;

    struct cfgValueS re;
    GetCfgValue(&re);
    int32 iMaxSecondLevelSlotCnt = re.iMaxSecondLevelSlotCnt;

    memset(gMsgCache, 0, sizeof(MsgCacheT)*MAX_MSG_CACHE_CNT);

    for (int i = 0; i < MAX_MSG_CACHE_CNT; i++)
    {
        for (int j = 0; j < MAX_MSG_CACHE_THREAD_CNT; j++)
        {
            gMsgCache[i].threadCache[j].slot = (SlotT*)malloc(sizeof(SlotT)*(iMaxSecondLevelSlotCnt+1));
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SingleMsgCacheInit(pMsgCacheT pMsgCache)
{
    BEGIN_FUNCTION("SingleMsgCacheInit");
    ResCodeT rc = NO_ERR;

    struct cfgValueS re;
    GetCfgValue(&re);
    int32 iMaxMsgCacheSlotCnt = re.iMaxMsgCacheSlotCnt;

    memset((pMsgCache->dataShmName), 0, sizeof(char)*SHM_NAME_LEN);
    pMsgCache->frstLevAvaSlotCnt = 0;
    pMsgCache->secLevSlotCnt = 0;
    pMsgCache->msgCacheHndl = 0;
    pMsgCache->filter = 0;
    pMsgCache->pRoot = NULL;
    pMsgCache->bCreate = FALSE;
    for (int i = 0; i < MAX_MSG_CACHE_THREAD_CNT; i++)
    {
        pMsgCache->threadCache[i].secLevAvaSlotCnt = 0;
        pMsgCache->threadCache[i].secLevReservedSlotFrmIdx = 0;
        pMsgCache->threadCache[i].secLevReservedSlotEndIdx = 0;
        pMsgCache->threadCache[i].filter = 0;
        memset(pMsgCache->threadCache[i].slot, 0, sizeof(sizeof(SlotT)*iMaxMsgCacheSlotCnt));
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheCreate(char *dataCacheName, MsgCacheConfigT *pMsgConfig, int32 * pMsgCacheIdx)
{
    BEGIN_FUNCTION("MsgCacheCreate");
    ResCodeT rc = NO_ERR;
    int32 i;
    void* pRt = NULL;
    int32 unusedIdx = -1;
    int32 msgCacheIdx;
    void *      	        pRoot = NULL;

    char msgSlotIdShmName[SHM_NAME_LEN];


    uint64 								msgCacheTotalSize;
    MsgCacheShmAdminT 		admin;
    admin.adminSize 		= sizeof(MsgCacheShmAdminT);
    admin.elemSize 			= pMsgConfig->elemSize;
    //Last slot of MsgQueue can not be used
    admin.frstLevSlotCnt = pMsgConfig->frstLevelElemCnt - 1;
    admin.secLevSlotCnt = pMsgConfig->secLevelElemCnt;

    admin.cfg.type = Q_TYPE_MW1R;
    admin.cfg.itemCnt = pMsgConfig->frstLevelElemCnt;
    admin.cfg.itemSize = sizeof(int32);
    admin.cfg.threadCnt = pMsgConfig->threadCnt;

    //msg Data Shm create
    msgCacheTotalSize = admin.adminSize + admin.elemSize * pMsgConfig->frstLevelElemCnt;
    msgCacheTotalSize += sizeof(MsgCacheT)*MAX_MSG_CACHE_CNT;
    rc = ShmCreate(dataCacheName, msgCacheTotalSize, (int64**)&pRoot);
    //rc = ShmCreate(dataCacheName, msgCacheTotalSize, (int64**)&gMsgCache[msgCacheIdx].pRoot);
    RAISE_ERR(rc, RTN);
    
    gMsgCache = (pMsgCacheT)pRoot;

    //init
    if (gMsgCacheCnt == 0)
    {
        MsgCacheInit();
        msgCacheIdx = 0;
    }
    else if (gMsgCacheCnt == MAX_MSG_CACHE_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE, RTN);
    }
    else
    {
        for(i = 0; i < MAX_MSG_CACHE_CNT; i++)
        {
            if (strcmp(dataCacheName, gMsgCache[i].dataShmName) == 0)
            {
                //RAISE_ERR(ERR_MSG_CACHE_CACHE_NAME_DUPLICATE, RTN);
                *pMsgCacheIdx = i;
                RETURN_RESCODE;
            }

            if (strlen(gMsgCache[i].dataShmName) == 0 && unusedIdx == -1)
            {
                unusedIdx = i;
            }
        }
        msgCacheIdx = unusedIdx;

//        memset(&gMsgCache[msgCacheIdx], 0, sizeof(MsgCacheT));
        SingleMsgCacheInit(&gMsgCache[msgCacheIdx]);
    }

    pthread_mutex_init(&gMsgCache[msgCacheIdx].tLock, NULL);

    strcpy(gMsgCache[msgCacheIdx].dataShmName, dataCacheName);
    gMsgCache[msgCacheIdx].secLevSlotCnt = pMsgConfig->secLevelElemCnt;



    gMsgCache[msgCacheIdx].pRoot = pMsgCacheShmAdminT(pRoot + sizeof(MsgCacheT)*MAX_MSG_CACHE_CNT);



    memcpy(gMsgCache[msgCacheIdx].pRoot,  &admin, sizeof(MsgCacheShmAdminT) );
    memset(msgSlotIdShmName, 0, SHM_NAME_LEN);
    strcpy(msgSlotIdShmName, gMsgCache[msgCacheIdx].dataShmName);
    strcat(msgSlotIdShmName, SHM_MSG_CACHE_SLOT_SUFFIX);

    uint32 totalSize;
    rc = MsgQueueCalcSize(&admin.cfg, &totalSize);
    RAISE_ERR(rc, RTN);

    //msg slotId Shm create
    rc = ShmCreate(msgSlotIdShmName, totalSize, (int64**)&pRt);
    RAISE_ERR(rc, RTN);

    rc = MsgQueueCreate(&(admin.cfg), &gMsgCache[msgCacheIdx].msgCacheHndl, (void *)pRt);
    RAISE_ERR(rc, RTN);

    //slot init issue.
    for (i = 1; i <= admin.frstLevSlotCnt; i++)
    {
        rc = MsgQueueWriteSlot(gMsgCache[msgCacheIdx].msgCacheHndl, i);
        RAISE_ERR(rc, RTN);

        gMsgCache[msgCacheIdx].frstLevAvaSlotCnt++;
    }

    *pMsgCacheIdx = msgCacheIdx;
    gMsgCacheCnt++;

    gMsgCache[msgCacheIdx].bCreate = TRUE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheAttach(char *dataCacheName, int32 * pMsgCacheIdx)
{
    BEGIN_FUNCTION("MsgCacheAttach");
    ResCodeT rc = NO_ERR;
    int32 i;
    void* pRt = NULL;
    int32 unusedIdx = -1;
    int32 msgCacheIdx;

    char msgSlotIdShmName[SHM_NAME_LEN];
    void *      		pRoot = NULL;

    rc = ShmAttach(dataCacheName, (int64**)&pRoot);
    RAISE_ERR(rc, RTN);
    gMsgCache = (pMsgCacheT)pRoot;
    

    for (i = 0; i < MAX_MSG_CACHE_CNT; i++)
    {
        if (strcmp(dataCacheName, gMsgCache[i].dataShmName) == 0)
        {
            //RAISE_ERR(ERR_MSG_CACHE_CACHE_NAME_DUPLICATE, RTN);
            *pMsgCacheIdx = i;
            THROW_RESCODE(NO_ERR);
        }

        if (strlen(gMsgCache[i].dataShmName) == 0 && unusedIdx == -1)
        {
            unusedIdx = i;
        }
    }
    msgCacheIdx = unusedIdx;

//        memset(&gMsgCache[msgCacheIdx], 0, sizeof(MsgCacheT));
        SingleMsgCacheInit(&gMsgCache[msgCacheIdx]);


    pthread_mutex_init(&gMsgCache[msgCacheIdx].tLock, NULL);

    strcpy(gMsgCache[msgCacheIdx].dataShmName, dataCacheName);
    gMsgCache[msgCacheIdx].pRoot = pMsgCacheShmAdminT(pRoot + sizeof(MsgCacheT)*MAX_MSG_CACHE_CNT);

    MsgCacheShmAdminT admin;
    memcpy(&admin, gMsgCache[msgCacheIdx].pRoot, sizeof(MsgCacheShmAdminT));

    gMsgCache[msgCacheIdx].frstLevAvaSlotCnt = admin.frstLevSlotCnt;
    gMsgCache[msgCacheIdx].secLevSlotCnt = admin.secLevSlotCnt;

    memset(msgSlotIdShmName, 0, SHM_NAME_LEN);
    strcpy(msgSlotIdShmName, gMsgCache[msgCacheIdx].dataShmName);
    strcat(msgSlotIdShmName, SHM_MSG_CACHE_SLOT_SUFFIX);

    //msg slotId Shm attach
    rc = ShmAttach(msgSlotIdShmName, (int64**)&pRt);
    RAISE_ERR(rc, RTN);

    MsgQueueCfgT  cfg;
    memcpy(&cfg, &admin.cfg, sizeof(MsgQueueCfgT));

    rc = MsgQueueCreate(&cfg, &gMsgCache[msgCacheIdx].msgCacheHndl, (void *)pRt);
    RAISE_ERR(rc, RTN);
    *pMsgCacheIdx = msgCacheIdx;
    gMsgCacheCnt++;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheDestroy(int32 msgCacheIdx)
{
    BEGIN_FUNCTION("MsgCacheDestroy");

    int32 i;
    ResCodeT rc;
    char msgSlotIdShmName[SHM_NAME_LEN];

    if (msgCacheIdx >= MAX_MSG_CACHE_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE, RTN);
    }

    if (strlen(gMsgCache[msgCacheIdx].dataShmName) == 0)
    {
        THROW_RESCODE(NO_ERR);
    }

    rc = MsgQueueDispose(gMsgCache[msgCacheIdx].msgCacheHndl);
    RAISE_ERR(rc, RTN);

    //data shm destroy
    rc = ShmDetach(gMsgCache[msgCacheIdx].dataShmName);
    RAISE_ERR(rc, RTN);

    rc = ShmDelete(gMsgCache[msgCacheIdx].dataShmName);
    RAISE_ERR(rc, RTN);

    //slot shm destroy
    memset(msgSlotIdShmName, 0, SHM_NAME_LEN);
    strcpy(msgSlotIdShmName, gMsgCache[msgCacheIdx].dataShmName);
    strcat(msgSlotIdShmName, SHM_MSG_CACHE_SLOT_SUFFIX);

    rc = ShmDetach(msgSlotIdShmName);
    RAISE_ERR(rc, RTN);

    rc = ShmDelete(msgSlotIdShmName);
    RAISE_ERR(rc, RTN);

    //mutex destroy
    pthread_mutex_destroy(&gMsgCache[msgCacheIdx].tLock);

//    memset(&gMsgCache[msgCacheIdx], 0, sizeof(MsgCacheT));
    SingleMsgCacheInit(&gMsgCache[msgCacheIdx]);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheDetach(int32 msgCacheIdx)
{
    BEGIN_FUNCTION("MsgCacheDetach");

    int32 i;
    ResCodeT rc;
    char msgSlotIdShmName[SHM_NAME_LEN];

    if (msgCacheIdx >= MAX_MSG_CACHE_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE, RTN);
    }

    if (strlen(gMsgCache[msgCacheIdx].dataShmName) == 0)
    {
        THROW_RESCODE(NO_ERR);
    }

    if (gMsgCache[msgCacheIdx].bCreate)
    {
        THROW_RESCODE(NO_ERR);
    }

    rc = MsgQueueDispose(gMsgCache[msgCacheIdx].msgCacheHndl);
    RAISE_ERR(rc, RTN);

    //data shm detach
    rc = ShmDetach(gMsgCache[msgCacheIdx].dataShmName);
    RAISE_ERR(rc, RTN);

    //slot shm detach
    memset(msgSlotIdShmName, 0, SHM_NAME_LEN);
    strcpy(msgSlotIdShmName, gMsgCache[msgCacheIdx].dataShmName);
    strcat(msgSlotIdShmName, SHM_MSG_CACHE_SLOT_SUFFIX);

    rc = ShmDetach(msgSlotIdShmName);
    RAISE_ERR(rc, RTN);

    //mutex destroy
    pthread_mutex_destroy(&gMsgCache[msgCacheIdx].tLock);

//    memset(&gMsgCache[msgCacheIdx], 0, sizeof(MsgCacheT));
    SingleMsgCacheInit(&gMsgCache[msgCacheIdx]);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheResrveSlot(int32 msgCacheIdx, SlotT * pSlot, void ** ppData)
{
    BEGIN_FUNCTION("MsgCacheResrveSlot");
    ResCodeT rc = NO_ERR;

    int32 threadId;
    int32 i;
    int32 revIdx;
    uint64* pData1;
    uint64 offset;
    ThreadMsgCacheT* pthreadCache;

    if (msgCacheIdx >= MAX_MSG_CACHE_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE, RTN);
    }

    GET_THREAD_ID(threadId);

    if (threadId >= MAX_MSG_CACHE_THREAD_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_THREAD_INDEX_OUTRANGE, RTN);
    }

    pthreadCache = &gMsgCache[msgCacheIdx].threadCache[threadId];

    //new thread or not thread to resrve
    if (pthreadCache->secLevAvaSlotCnt == 0)
    {
        pthreadCache->secLevReservedSlotFrmIdx = 0;
        pthreadCache->secLevReservedSlotEndIdx = 0;

        pthread_mutex_lock(&gMsgCache[msgCacheIdx].tLock);
        revIdx = 0;
        while (revIdx < gMsgCache[msgCacheIdx].secLevSlotCnt)
        {
            rc = MsgQueueReadSlot(gMsgCache[msgCacheIdx].msgCacheHndl, &pthreadCache->slot[revIdx]);
            if (rc == NO_ERR)
            {
                revIdx++;
            }
            else if (rc == ERCD_ARCH_READ_TRY_AGAIN)
            {
                if (revIdx > 0)
                {
                    pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                    break;
                }

                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
            else
            {
                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
        }

        gMsgCache[msgCacheIdx].frstLevAvaSlotCnt -= revIdx;

        pthreadCache->secLevAvaSlotCnt = revIdx;
        pthreadCache->secLevReservedSlotEndIdx = revIdx;
        if (pthreadCache->secLevReservedSlotEndIdx >= (gMsgCache[msgCacheIdx].secLevSlotCnt))
        {
            pthreadCache->secLevReservedSlotEndIdx = 0;
        }
        pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
    }

    //reserve 1 slot
    *pSlot = pthreadCache->slot[pthreadCache->secLevReservedSlotFrmIdx];

    pthreadCache->secLevAvaSlotCnt--;
    pthreadCache->secLevReservedSlotFrmIdx++;
    if (pthreadCache->secLevReservedSlotFrmIdx == (gMsgCache[msgCacheIdx].secLevSlotCnt))
    {
        pthreadCache->secLevReservedSlotFrmIdx = 0;
    }

    pData1 = (uint64*)(gMsgCache[msgCacheIdx].pRoot);
    offset = sizeof(MsgCacheShmAdminT) + gMsgCache[msgCacheIdx].pRoot->elemSize*(*pSlot);
    pData1 = (uint64*)ADDRESS_ADD_OFFSET(pData1, offset);

    *ppData = (void*)pData1;

    LOG_DEBUG("New Resrve Slot [%d]", *pSlot );
    
    LOG_DEBUG("New Resrve Slot [%d] Ava %d, Frm %d, End %d Success", *pSlot, pthreadCache->secLevAvaSlotCnt, 
                pthreadCache->secLevReservedSlotFrmIdx,pthreadCache->secLevReservedSlotEndIdx );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheGetSlotAddr(int32 msgCacheIdx, SlotT slot, void ** ppData)
{
    BEGIN_FUNCTION("MsgCacheGetSlotAddr");
    uint64* pData1;
    uint64 offset;

    pData1 = (uint64*)(gMsgCache[msgCacheIdx].pRoot);
    offset = sizeof(MsgCacheShmAdminT) + gMsgCache[msgCacheIdx].pRoot->elemSize*(slot);
    pData1 = (uint64*)ADDRESS_ADD_OFFSET(pData1, offset);

    *ppData = (void*)pData1;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheReleaseSlot(int32 msgCacheIdx, SlotT slot)
{
    BEGIN_FUNCTION("MsgCacheReleaseSlot");
    ResCodeT rc = NO_ERR;

    int32 threadId;
    int32 msgCacheHndl;
    int32 cnt;
    int32 i;
    ThreadMsgCacheT* pthreadCache;

    if (msgCacheIdx >= MAX_MSG_CACHE_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE, RTN);
    }

    GET_THREAD_ID(threadId);
    if (threadId >= MAX_MSG_CACHE_THREAD_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_THREAD_INDEX_OUTRANGE, RTN);
    }

    pthreadCache = &gMsgCache[msgCacheIdx].threadCache[threadId];
    msgCacheHndl = gMsgCache[msgCacheIdx].msgCacheHndl;

    //can not release
    if (pthreadCache->secLevAvaSlotCnt == gMsgCache[msgCacheIdx].secLevSlotCnt)
    {
        pthread_mutex_lock(&gMsgCache[msgCacheIdx].tLock);
        
        for (i = 0; i < pthreadCache->secLevAvaSlotCnt; i++)
        {
            rc = MsgQueueWriteSlot(msgCacheHndl, pthreadCache->slot[i]);
            if (rc != NO_ERR)
            {
                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
        }
        
   
        gMsgCache[msgCacheIdx].frstLevAvaSlotCnt += pthreadCache->secLevAvaSlotCnt;
        pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);

        pthreadCache->secLevReservedSlotFrmIdx = 0;
        pthreadCache->secLevReservedSlotEndIdx = 0;
        pthreadCache->secLevAvaSlotCnt = 0;
    }
    
    pthreadCache->slot[pthreadCache->secLevReservedSlotEndIdx] = slot;
    pthreadCache->secLevReservedSlotEndIdx++;
    pthreadCache->secLevAvaSlotCnt++;
    
    if (pthreadCache->secLevReservedSlotEndIdx >= (gMsgCache[msgCacheIdx].secLevSlotCnt))
    {
        pthreadCache->secLevReservedSlotEndIdx = 0;
    }

//    if (pthreadCache->secLevReservedSlotEndIdx == gMsgCache[msgCacheIdx].secLevSlotCnt)
//    {
//        pthreadCache->secLevReservedSlotEndIdx = 0;
//    }

    LOG_DEBUG("Release Slot [%d] Ava %d, Frm %d, End %d Success", slot, pthreadCache->secLevAvaSlotCnt, 
                pthreadCache->secLevReservedSlotFrmIdx,pthreadCache->secLevReservedSlotEndIdx );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT MsgCachePushBackToFrstLvl(int32 msgCacheIdx)
{
    BEGIN_FUNCTION("MsgCachePushBackToFrstLvl");
    ResCodeT rc = NO_ERR;

    int32 threadId;
    int32 msgCacheHndl;
    int32 cnt;
    int32 i;
    int32 pushCnt = 0;
    ThreadMsgCacheT* pthreadCache;

    if (msgCacheIdx >= MAX_MSG_CACHE_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE, RTN);
    }

    GET_THREAD_ID(threadId);
    if (threadId >= MAX_MSG_CACHE_THREAD_CNT)
    {
        RAISE_ERR(ERR_MSG_CACHE_CACHE_THREAD_INDEX_OUTRANGE, RTN);
    }

    pthreadCache = &gMsgCache[msgCacheIdx].threadCache[threadId];
    msgCacheHndl = gMsgCache[msgCacheIdx].msgCacheHndl;
    
    pthread_mutex_lock(&gMsgCache[msgCacheIdx].tLock);
    
    if (pthreadCache->secLevAvaSlotCnt == gMsgCache[msgCacheIdx].secLevSlotCnt)
    {
        for (i = 0; i < pthreadCache->secLevAvaSlotCnt; i++)
        {
            rc = MsgQueueWriteSlot(msgCacheHndl, pthreadCache->slot[i]);
            if (rc != NO_ERR)
            {
                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
        }
        
   
        gMsgCache[msgCacheIdx].frstLevAvaSlotCnt += pthreadCache->secLevAvaSlotCnt;
        pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);

        pthreadCache->secLevReservedSlotFrmIdx = 0;
        pthreadCache->secLevReservedSlotEndIdx = 0;
        pthreadCache->secLevAvaSlotCnt = 0;
    }
    else if (pthreadCache->secLevReservedSlotFrmIdx <= pthreadCache->secLevReservedSlotEndIdx)
    {
        for(i = pthreadCache->secLevReservedSlotFrmIdx; i < pthreadCache->secLevReservedSlotEndIdx; i++)
        {
            rc = MsgQueueWriteSlot(msgCacheHndl, pthreadCache->slot[i]);
            if (rc != NO_ERR)
            {
                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
            pushCnt++;
        }
    }
    else
    {
        for(i = pthreadCache->secLevReservedSlotFrmIdx; i < gMsgCache[msgCacheIdx].secLevSlotCnt; i++)
        {
            rc = MsgQueueWriteSlot(msgCacheHndl, pthreadCache->slot[i]);
            if (rc != NO_ERR)
            {
                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
            pushCnt++;
        }
        for(i = 0; i < pthreadCache->secLevReservedSlotEndIdx; i++)
        {
            rc = MsgQueueWriteSlot(msgCacheHndl, pthreadCache->slot[i]);
            if (rc != NO_ERR)
            {
                pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);
                RAISE_ERR(rc, RTN);
            }
            pushCnt++;
        }
    }
    
   
    gMsgCache[msgCacheIdx].frstLevAvaSlotCnt += pushCnt;
    pthread_mutex_unlock(&gMsgCache[msgCacheIdx].tLock);

    pthreadCache->secLevReservedSlotFrmIdx = 0;
    pthreadCache->secLevReservedSlotEndIdx = 0;
    pthreadCache->secLevAvaSlotCnt = 0;


    LOG_DEBUG("Push All Slot [%d] back Success", pushCnt );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   create default message cache
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgCreate(SlotT slotNum, int32 secLvlCnt, int32 threadCnt)
{
    BEGIN_FUNCTION("MsgCreate");
    ResCodeT 				rc = NO_ERR;
    MsgCacheConfigT cfg;
    char shmName[] = SHM_MSG_CACHE_NAME;
    cfg.frstLevelElemCnt = slotNum;
    cfg.secLevelElemCnt = secLvlCnt;
    cfg.elemSize  = sizeof(MsgCacheSlotT);
    cfg.threadCnt = threadCnt;

    rc = MsgCacheCreate(GetShmNm(shmName), &cfg, &gDfltMsgHndl);
    RAISE_ERR( rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   attach or init default message cache
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgInit()
{
    BEGIN_FUNCTION("MsgInit");
    ResCodeT rc = NO_ERR;
    char shmName[] = SHM_MSG_CACHE_NAME;
    rc = MsgCacheAttach(GetShmNm(shmName), &gDfltMsgHndl);
    RAISE_ERR( rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   reserve a single slot
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgRsrvSlot(SlotT *  pSlotId, pMsgCacheSlotT * ppSlot)
{
    BEGIN_FUNCTION("MsgRsrvSlot");
    ResCodeT rc = NO_ERR;

    rc = MsgCacheResrveSlot(gDfltMsgHndl, pSlotId, (void **) ppSlot);
    if (ERCD_ARCH_READ_TRY_AGAIN == rc)
    {
        THROW_RESCODE(rc);
    }
    else
    {
        RAISE_ERR( rc, RTN);
    }

    (*ppSlot)->pairedSlotId = NULL_SLOT;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get a single slot
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgGetSlot(SlotT slotId, pMsgCacheSlotT * ppMsg)
{
    BEGIN_FUNCTION("MsgGetSlot");
    ResCodeT rc = NO_ERR;

    rc = MsgCacheGetSlotAddr(gDfltMsgHndl, slotId, (void **) ppMsg);
    RAISE_ERR( rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Get a paired slot
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
static ResCodeT MsgGetPairedSlotId(SlotT orig, SlotT * paired)
{
    /* Result code */
    ResCodeT result = NO_ERR;
    /* Temp slot entry */
    pMsgCacheSlotT pSlotEntry;

    BEGIN_FUNCTION("MsgGetPairedSlotId");
    ASSERT(paired);

    //memset(&pSlotEntry, 0, sizeof(pMsgCacheSlotT));
    if (orig != NULL_SLOT && orig != 0)
    {
        result = MsgGetSlot(orig, &pSlotEntry);
        if (result != NO_ERR)
        {
            return result;
        }
        *paired = pSlotEntry->pairedSlotId;
        return NO_ERR;
    }
    else
    {
        return ERR_ARCH_MSG_EMPTY_SLOT_ERR;
    }
    EXIT_BLOCK();
    return NO_ERR;
} /* End of MsgGetPairedSlotId */

/******************************************************************************
 * Description:   delete a single slot
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgDelete(SlotT slotId)
{
    BEGIN_FUNCTION("MsgDelete");
    ResCodeT rc = NO_ERR;
    /* Temp result code */
    ResCodeT result = NO_ERR;
    SlotT pairedSlotId = NULL_SLOT;

    pMsgCacheSlotT pSlotEntry;

    /* If the input slot ID is not empty, then try to free its paired slot (if
       it has) and the input slot itself, else returns error. */
    TRACE("Try to delete slotId [%d]" $$ slotId);

    if (slotId != NULL_SLOT && slotId != 0)
    {
        /* handle the paired slot */
        result = MsgGetPairedSlotId(slotId, &pairedSlotId);
        if (result == NO_ERR && pairedSlotId != NULL_SLOT)
        {
            /* reset the pairedSlotId value before call ShmFreeSlot */
            result = MsgGetSlot(pairedSlotId, &pSlotEntry);
            if (NOTOK(result))
            {
                RAISE_ERR( result, NORTN);
            }
            /* before processing, validate the slots are paired */
            else if (pSlotEntry->pairedSlotId == slotId)
            {
                pSlotEntry->pairedSlotId = NULL_SLOT;
                result = MsgCacheReleaseSlot(gDfltMsgHndl, pairedSlotId);
                if (NOTOK(result))
                {
                    RAISE_ERR( result, NORTN );
                }
                TRACE("Paired slotId [%d] deleted!" $$ pairedSlotId);
            }
        }

        /* reset the pairedSlotId value before call ShmFreeSlot */
        result = MsgGetSlot(slotId, &pSlotEntry);
        if (NOTOK(result))
        {
            RAISE_ERR( result, NORTN );
        }
        else
        {
            pSlotEntry->pairedSlotId = NULL_SLOT;
            result = MsgCacheReleaseSlot(gDfltMsgHndl, slotId);
            if (result != NO_ERR)
            {
                RAISE_ERR( result, RTN );
            }
            TRACE("SlotId [%d] deleted!" $$ slotId);
        }
    }
    else
    {
        RAISE_ERR( ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get the paried msg
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgGetSlotRsp(SlotT slotId, pMsgCacheSlotT * ppRespSlot)
{
    BEGIN_FUNCTION( "MsgGetSlotRsp" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    ResCodeT rc2    = NO_ERR;
    /* Temp slot ID */
    SlotT pairedSlotId = NULL_SLOT;

    pMsgCacheSlotT pSlotEntry;
    
    LOG_DEBUG("Get Slot %d", slotId);

    if (slotId != NULL_SLOT && slotId != 0)
    {
        result = MsgGetPairedSlotId(slotId, &pairedSlotId);
        RAISE_ERR(result, RTN);
        
        LOG_DEBUG("Get pairedSlotId %d", pairedSlotId);
        
        if (pairedSlotId == NULL_SLOT)
        {
                RAISE_ERR(ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN);
        }

        result = MsgGetSlot(pairedSlotId, &pSlotEntry);
        if (result != NO_ERR)
        {
            RAISE_ERR(ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN);
        }

        *ppRespSlot = pSlotEntry;
    }
    else
    {
        RAISE_ERR(ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get the a pair msgs (two)
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgRsrvSlotsPaired(SlotT * pSlotId, pMsgCacheSlotT * ppReqSlot, pMsgCacheSlotT * ppRespSlot)
{
    BEGIN_FUNCTION( "MsgRsrvSlotsPaired" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    ResCodeT rc2    = NO_ERR;
    /* Temp slot ID */
    SlotT reqSlotId = NULL_SLOT;
    SlotT respSlotId = NULL_SLOT;

    ASSERT(pSlotId && ppReqSlot && ppRespSlot);

    /* Reserve the slots */
    result = MsgRsrvSlot(&reqSlotId, ppReqSlot);
    if (!OK(result))
    {
        RAISE_ERR( result, RTN );
    }
    TRACE("PairedSlot [%d] reserved!" $$ reqSlotId);

    result = MsgRsrvSlot(&respSlotId, ppRespSlot);
    if (result != NO_ERR)
    {
        rc2 = MsgDelete(reqSlotId);
        RAISE_ERR(rc2, NORTN);
        RAISE_ERR( result, RTN );
    }
    TRACE("PairedSlot [%d] reserved!" $$ respSlotId);

    /* Link the pair of slots */
    (*ppReqSlot)->slotId = (int32)reqSlotId;
    (*ppRespSlot)->slotId = (int32)respSlotId;

    (*ppReqSlot)->pairedSlotId = (int32)respSlotId;
    (*ppRespSlot)->pairedSlotId = (int32)reqSlotId;
    TRACE("PairedSlot req[%d]<=>rsp[%d] reserved!" $$ reqSlotId $$ respSlotId);

    /* Return the pointer to the slot ID. */
    *pSlotId = (int32)reqSlotId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get a single slot
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgGetMsg(SlotT slotId, pMsgDataT * ppMsg )
{
    BEGIN_FUNCTION("MsgGetMsg");
    ResCodeT rc = NO_ERR;

    pMsgCacheSlotT  pMsg = NULL;

    rc = MsgCacheGetSlotAddr(gDfltMsgHndl, slotId, (void **) &pMsg);
    RAISE_ERR( rc, RTN);

    * ppMsg = &pMsg->msgBody;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get the a pair msgs (two)
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgDetach()
{
    BEGIN_FUNCTION( "MsgDetach" );

    /* Temp result code */
    ResCodeT rc = NO_ERR;

    rc = MsgCacheDetach(gDfltMsgHndl);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get the a pair msgs (two)
 * Parameters:
 *      slotNum   IN      total slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MsgDestory()
{

    BEGIN_FUNCTION( "MsgDestory" );

    /* Temp result code */
    ResCodeT rc = NO_ERR;

    rc = MsgCacheDestroy(gDfltMsgHndl);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgCacheCalcUsedCnt(int32 msgHndl, int32* levCnt)
{
    BEGIN_FUNCTION("MsgCacheCalcUsedCnt");
    ResCodeT            rc = NO_ERR;
    int32               i,j;
    int32               secLevCnt = 0;

    for (j=0; j<MAX_MSG_CACHE_THREAD_CNT; j++)
    {
        secLevCnt +=  gMsgCache[msgHndl].threadCache[j].secLevAvaSlotCnt;
    }

    LOG_DEBUG("MSGCACHE: secLevCnt=[%d] frstLevAvaSlotCnt=[%d]", secLevCnt, gMsgCache[msgHndl].frstLevAvaSlotCnt);

    *levCnt = secLevCnt + gMsgCache[msgHndl].frstLevAvaSlotCnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT MsgCacheGetMsgCount(int32 msgHndl,int32 * msgCacheMaxCnt, int32 *  msgCacheUsedCnt)
{
    BEGIN_FUNCTION( "MsgCacheGetMsgCount" );
    ResCodeT    rc = NO_ERR;
    int32       msgCacheLevCnt;
    struct      cfgValueS cfgValue;

    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
    
    *msgCacheMaxCnt = cfgValue.iMaxMsgCacheSlotCnt;


    rc = MsgCacheCalcUsedCnt(msgHndl, &msgCacheLevCnt);
    RAISE_ERR(rc,RTN);
    
    *msgCacheUsedCnt = *msgCacheMaxCnt -  msgCacheLevCnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetMsgCount(int32 * maxCnt, int32 * usedCnt)
{
    BEGIN_FUNCTION( "GetMsgCount" );
    ResCodeT rc = NO_ERR;

    
    rc = MsgCacheGetMsgCount(gDfltMsgHndl, maxCnt, usedCnt);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT MsgCacheCleanThread()
{
    BEGIN_FUNCTION( "MsgCacheCleanThread" );
    ResCodeT rc = NO_ERR;

    
    rc = MsgCachePushBackToFrstLvl(gDfltMsgHndl);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

