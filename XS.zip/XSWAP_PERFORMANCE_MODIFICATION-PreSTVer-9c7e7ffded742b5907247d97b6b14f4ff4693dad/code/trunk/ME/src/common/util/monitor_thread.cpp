/***
Created on Sep.23 2017
@author: xuetao.bai
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "msg_cache.h"
#include "mem_txn.h"
#include "cfg_lib.h"
#include "dump_ord.h"
#include "matching_engine.h"
#include "active_info.h"
#include "active_keeper.h"
#include "uti_tool.h"
#include "mkt_init.h"
#include "trade_mgmt.h"
#include "monitor_thread.h"
#include "shm_name.h"
#include "shm.h"
#include "msg_common_value.h"
#include "logfile.h"
#include "common_macro.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static pMonTreadUpdtT   gpMonThreadUpdt = NULL;
static cfgValueS        gCfgValue = {0};

static MonTreadUpdtT    gThreadUpdtMatix[] = 
{
    3,
    {
        MON_TYPE_INIT, 0, 0, 0, 0, 0, 0, "",
        MON_THREAD_CALLBACK_TYP, EXIT_FLAG, 0, 0, 0, THREAD_RUNNING, 0, "ServiceCallback",
        MON_THREAD_DUMP_TYP, EXIT_FLAG, 0, 0, 0, THREAD_RUNNING, 0, "DumptxnThread  ",
        MON_THREAD_RESP_TYP, EXIT_FLAG, 0, 0, 0, THREAD_RUNNING, 0, "ResponseThread"
    }
};



/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 * Description:   Create service thread run status
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT MonThreadShmCreate( )
{
    BEGIN_FUNCTION( "MonThreadShmCreate" );
    ResCodeT    rc = NO_ERR;
    ShmInfoT    shmInfo;
    void *      pRoot = NULL;
    char        shmName[] = SHM_STATE_SRVC_NAME;

    memset(&shmInfo, 0x00, sizeof(ShmInfoT));
    shmInfo.setCnt = 1;
    shmInfo.memTtlSize = sizeof(MonTreadUpdtT);

    rc = ShmCreate(GetShmNm(shmName), sizeof(MonTreadUpdtT), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);

    memcpy(pRoot, gThreadUpdtMatix, sizeof(MonTreadUpdtT));
    gpMonThreadUpdt = (pMonTreadUpdtT)pRoot;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Attach to shm
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT MonThreadShmAttach( )
{
    BEGIN_FUNCTION( "MonThreadShmAttach" );
    ResCodeT    rc = NO_ERR;
    char        shmName[] = SHM_STATE_SRVC_NAME;
    void *      pRoot = NULL;

    rc = ShmAttach(GetShmNm(shmName), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);

    gpMonThreadUpdt = (pMonTreadUpdtT)pRoot;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Register service thread
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT MonThreadReg(MonThreadTypeT monType)
{
    BEGIN_FUNCTION( "MonThreadReg" );
    MonThreadTypeT  threadType;

    if (monType >= MON_TYPE_MAX || monType <= MON_TYPE_INIT)
    {
        RAISE_ERR(ENV_VAR_CONV_ERR, NORTN);
    }
    else
    {
        threadType = gpMonThreadUpdt->monThreadNum[monType].threadType;
        if (threadType != monType)
        {
            gpMonThreadUpdt->monThreadNum[monType].threadType = monType;
            gpMonThreadUpdt->monThreadNum[monType].newCnt++;
            gpMonThreadUpdt->threadCnt++;
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Update thread count
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
void MonThreadUpt(MonThreadTypeT monType)
{
    gpMonThreadUpdt->monThreadNum[monType].newCnt++;
}

/******************************************************************************
 * Description:   Update Retry count
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT MonRetryCntUpt(MonThreadTypeT monType)
{
    BEGIN_FUNCTION( "MonRetryCntUpt" );

    gpMonThreadUpdt->monThreadNum[monType].retryCnt++;

    EXIT_BLOCK();
    return gpMonThreadUpdt->monThreadNum[monType].retryCnt;
}

/******************************************************************************
 * Description:   Update Retry count
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
void MonThreadCntSync(MonThreadTypeT monType, int64 timestamp)
{
    gpMonThreadUpdt->monThreadNum[monType].retryCnt = 0;
    gpMonThreadUpdt->monThreadNum[monType].lastCnt = 
            gpMonThreadUpdt->monThreadNum[monType].newCnt;
    gpMonThreadUpdt->monThreadNum[monType].timestamp = timestamp;

}

/******************************************************************************
 * Description:   Update thread count
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
void MonThreadSetState(MonThreadTypeT monType, int32 status)
{
    if ((gpMonThreadUpdt->monThreadNum[monType].status != THREAD_EXIT) &&
       (gpMonThreadUpdt->monThreadNum[monType].status != THREAD_HALT))
    {
        gpMonThreadUpdt->monThreadNum[monType].status = status;
    }
}

/******************************************************************************
 * Description:   sync service thread timestamp
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT MonThreadSync(int64 timestamp)
{
    BEGIN_FUNCTION( "MonThreadSync" );
    ResCodeT        rc = NO_ERR;
    int32           iCnt;
    MonThreadTypeT  threadType;
    int32           exitFlg;
    int32           retryCnt;
    int64           lastCnt;
    int64           newCnt;
    int64           lastTimeStamp;

    for (iCnt = 1; iCnt < MON_TYPE_MAX; iCnt++)
    {
        if (gpMonThreadUpdt->threadCnt <= 0)
        {
            break;
        }

        lastCnt         = gpMonThreadUpdt->monThreadNum[iCnt].lastCnt;
        newCnt          = gpMonThreadUpdt->monThreadNum[iCnt].newCnt;
        lastTimeStamp   = gpMonThreadUpdt->monThreadNum[iCnt].timestamp;
        threadType      = gpMonThreadUpdt->monThreadNum[iCnt].threadType;
        exitFlg         = gpMonThreadUpdt->monThreadNum[iCnt].exitFlg;

        if (newCnt > lastCnt)
        {
            MonThreadCntSync(threadType, timestamp);
        }
        else
        {
            retryCnt = MonRetryCntUpt(threadType);
            if (retryCnt > MAX_RETRY)
            {
                MonThreadSetState(threadType, THREAD_HALT);
                if (1 == exitFlg)
                {
                    RAISE_ERR(ERCD_ARCH_SERV_THREAD_HALT, RTN);
                    exit(1);
                }
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Monitor service thread
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
void* MonitorServThread(void *pRunFlag)
{
    BEGIN_FUNCTION( "MonitorServThread" );
    ResCodeT        rc = NO_ERR;
    int32 *         pRunMark;
    int64           timestamp;

    pRunMark   = (int32 *)pRunFlag;

    /* Get config value for the system  */
    rc = GetCfgValue(&gCfgValue);
    if (NOTOK(rc))
    {
        LOG_INFO("MonitorServThread: Get cfg parameter error[%d]!Set default value", rc);
        gCfgValue.monSleepTim   = DEFAULT_SLEEP_TIME;
    }

    while ( *pRunMark == MEM_TXN_MON_RUN )
    {
        GetSysTimestamp(&timestamp);
        rc = MonThreadSync(timestamp);
        RAISE_ERR(rc, RTN);

        usleep(gCfgValue.monSleepTim);
    }

    EXIT_BLOCK();
    return NULL;
}

/******************************************************************************
 * Description:   show Monitor service thread
 * Parameters:
 *
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintMonThread( )
{
    BEGIN_FUNCTION( "PrintMonThread" );
    ResCodeT        rc = NO_ERR;
    int32           status;  
    int64           timestamp;
    char            strUpdTm[MAX_TIME_LENGTH] = {0};
    char            strTmp[PRINT_LINE_LENGTH] = {0};
    char            strStatus[][THREAD_NAME_LEN] = {"RUNNING", "HALT", "EXIT"};

    printf("PrintMonThread: ThreadCnt = %lld\n", gpMonThreadUpdt->threadCnt);
    memset(strTmp, '-', sizeof(strTmp));
    printf("%.*s\n", PRINT_LINE_LENGTH, strTmp);
    printf("|%-12s|%-20s|%-15s|%-20s|\n",
        "threadSeq",
        "ThreadName",
        "Status",
        "Time");
    printf("%.*s\n", PRINT_LINE_LENGTH, strTmp);

    for (int32 i=MON_THREAD_CALLBACK_TYP; i<MON_TYPE_MAX; i++)
    {
        timestamp = gpMonThreadUpdt->monThreadNum[i].timestamp;
        rc = GetStrDateTimeByFormat(timestamp, strUpdTm);
        RAISE_ERR(rc, RTN);
        status = gpMonThreadUpdt->monThreadNum[i].status;

        printf("|%-12d|%-20s|%-15s|%-20s|\n", 
            i, 
            gpMonThreadUpdt->monThreadNum[i].threadDesc,
            strStatus[status],
            strUpdTm
            );
        printf("%.*s\n", PRINT_LINE_LENGTH, strTmp);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
