/***
Created on May 08, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "../include/bit_lib.h"




/*****************************************************************************
 **
 **  Function Implementation
 **
 *****************************************************************************/
/******************************************************************************
 *  BitCheck
 * ---------------------------------------------------------------------------
 * This function locates, checks and returns the state of the given bit
 * in the bit vector.
 ******************************************************************************/
int32 BitCheck (vectorT *bits, int32 index)
{
    if (bits[index/VECTOR_BASE] & (((vectorT) 1) << (index % VECTOR_BASE)))
    {
    return 1;
    }
    else
    {
    return 0;
    }
} /* End of BitCheck */



/******************************************************************************
 *  BitCheckus
 * ---------------------------------------------------------------------------
 *  "uint16" wrapper for BitCheckus
 ******************************************************************************/
int32 BitCheckus (vectorT *bits, uint16 index)
{
    return BitCheck(bits, (int32)index);
} /* End of BitCheckus */


/******************************************************************************
 *  BitFindFC
 * ---------------------------------------------------------------------------
 * This function finds the first bit unset in the given bit vector range.
 * First the first non zero element in the range is searched. In the element
 * found the first unset bit is searched and returned.
 * A special check and repeat of the above algorithm must be done to meet
 * also following case:
 *                           |  
 * A bit vector looks like 00000101 00000100 00100000 00000000 ....
 * The first bit of the range is 22 (|). As this element is not zero it is the
 * the one we search for unset bits. But there is no unset bit in the range and
 * we have to repeat but now starting the range with the 0th bit of the
 * next element.
 ******************************************************************************/
void BitFindFC(vectorT *bits, int32 first, int32 last, int32 *index)
{
    int32    elmtIdx, bitIdx;

    *index = BIT_IDX_INVALID; /* set nothing found */

    if (first > last) /* make sure that the range is correct */
    {
    return;
    }

    for (elmtIdx = first/VECTOR_BASE; elmtIdx <= last/VECTOR_BASE; elmtIdx++)
    {
    if (bits[elmtIdx] == VECTOR_MAX)
    {
        continue;
    }

    for (bitIdx = ((elmtIdx == first/VECTOR_BASE) ? first%VECTOR_BASE : 0);
            bitIdx < VECTOR_BASE;
            bitIdx++)
    {
        if (!(bits[elmtIdx] & (((vectorT) 1) << bitIdx)))
        {
        if ((bitIdx + elmtIdx*VECTOR_BASE) <= last)
        {
            *index = bitIdx + elmtIdx*VECTOR_BASE;
        }
        return;
        }
    } /* end bit loop */
    } /* end element loop */
} /* End of BitFindFC */

/******************************************************************************
 *  BitFindFCus
 * ---------------------------------------------------------------------------
 *  "uint16" wrapper for BitFindFC
 ******************************************************************************/
void BitFindFCus(vectorT *bits, uint16 first, uint16 last, 
            uint16 *index)
{
    int32   tmpIdx; 

    BitFindFC(bits, first, last, &tmpIdx);

    *index = (uint16)tmpIdx;

    return;
} /* End of BitFindFCus */



/******************************************************************************
 *  BitFindFS
 * ---------------------------------------------------------------------------
 * This function finds the first bit set in the given bit vector range.
 * The logic used is the same as in BitFindFC.
 ******************************************************************************/
void BitFindFS(vectorT *bits, int32 first, int32 last, int32 *index)
{
    int32    elmtIdx, bitIdx;

    *index = BIT_IDX_INVALID; /* set nothing found */

    if (first > last) /* make sure that the range is correct */
    {
    return;
    }

    for (elmtIdx = first/VECTOR_BASE; elmtIdx <= last/VECTOR_BASE; elmtIdx++)
    {
    if (bits[elmtIdx] == (vectorT) 0)
    {
        continue;
    }

    for (bitIdx = ((elmtIdx == first/VECTOR_BASE) ? first%VECTOR_BASE : 0);
            bitIdx < VECTOR_BASE;
            bitIdx++)
    {
        if (bits[elmtIdx] & (((vectorT) 1) << bitIdx))
        {
        if ((bitIdx + elmtIdx*VECTOR_BASE) <= last)
        {
            *index = bitIdx + elmtIdx*VECTOR_BASE;
        }
        return;
        }
    } /* end bit loop */
    } /* end element loop */
} /* End of BitFindFS */


/******************************************************************************
 *  BitFindFSus
 * ---------------------------------------------------------------------------
 * "uint16" wrapper for BitFindFS
 ******************************************************************************/
void BitFindFSus(vectorT *bits, uint16 first, uint16 last, 
            uint16 *index)
{
    int32   tmpIdx; 

    BitFindFS(bits, first, last, &tmpIdx);

    *index = (uint16)tmpIdx;

    return;

} /* End of BitFindFSus */


/******************************************************************************
 *  BitFindLC
 * ---------------------------------------------------------------------------
 * This function finds the last bit reset in the given bit vector range.
 * The logic used is the same as in BitFindFC.
 ******************************************************************************/
void BitFindLC(vectorT *bits, int32 first, int32 last, int32 *index)
{
    int32    elmtIdx, bitIdx;

    *index = BIT_IDX_INVALID; /* set nothing found */

    if (first > last) /* make sure that the range is correct */
    {
    return;
    }

    for (elmtIdx = last/VECTOR_BASE; elmtIdx >= first/VECTOR_BASE; elmtIdx--)
    {
    if (bits[elmtIdx] == VECTOR_MAX)
    {
        continue;
    }

    for (bitIdx = ((elmtIdx == last/VECTOR_BASE) ?
                        last%VECTOR_BASE : VECTOR_BASE-1);
            bitIdx >= 0;
            bitIdx--)
    {
        if (!(bits[elmtIdx] & (((vectorT) 1) << bitIdx)))
        {
        if ((bitIdx + elmtIdx*VECTOR_BASE) >= first)
        {
            *index = bitIdx + elmtIdx*VECTOR_BASE;
        }
        return;
        }
    } /* end bit loop */
    } /* end element loop */
} /* End of BitFindLC */



/******************************************************************************
 *  BitFindLCus
 * ---------------------------------------------------------------------------
 * "uint16" wrapper for BitFindLC
 ******************************************************************************/
void BitFindLCus(vectorT *bits, uint16 first, uint16 last, 
            uint16 *index)
{
    int32   tmpIdx; 

    BitFindLC(bits, first, last, &tmpIdx);

    *index = (uint16)tmpIdx;

    return;

} /* End of BitFindLCus */


/******************************************************************************
 *  BitFindLS
 * ---------------------------------------------------------------------------
 * This function finds the last bit set in the given bit vector range.
 * The logic used is the same as in BitFindFC.
 ******************************************************************************/
void BitFindLS(vectorT *bits, int32 first, int32 last, int32 *index)
{
    int32    elmtIdx, bitIdx;

    *index = BIT_IDX_INVALID; /* set nothing found */

    if (first > last) /* make sure that the range is correct */
    {
    return;
    }

    for (elmtIdx = last/VECTOR_BASE; elmtIdx >= first/VECTOR_BASE; elmtIdx--)
    {
    if (bits[elmtIdx] == (vectorT) 0)
    {
        continue;
    }

    for (bitIdx = ((elmtIdx == last/VECTOR_BASE) ?
                        last%VECTOR_BASE : VECTOR_BASE-1);
            bitIdx >= 0;
            bitIdx--)
    {
        if (bits[elmtIdx] & (((vectorT) 1) << bitIdx))
        {
        if ((bitIdx + elmtIdx*VECTOR_BASE) >= first)
        {
            *index = bitIdx + elmtIdx*VECTOR_BASE;
        }
        return;
        }
    } /* end bit loop */
    } /* end element loop */
} /* End of BitFindLS */


/******************************************************************************
 *  BitFindLSus
 * ---------------------------------------------------------------------------
 * "uint16" wrapper for BitFindLS
 ******************************************************************************/
void BitFindLSus(vectorT *bits, uint16 first, uint16 last, 
            uint16 *index)
{
    int32   tmpIdx; 

    BitFindLS(bits, first, last, &tmpIdx);

    *index = (uint16)tmpIdx;

    return;

} /* End of BitFindLSus */


/******************************************************************************
 *  BitReset
 * ---------------------------------------------------------------------------
 * This function resets the given bit in the bit vector.
 * This is done by locating the element, where the bit is and masking it
 * with the respective mask.
 ******************************************************************************/
void BitReset(vectorT *bits, int32 index)
{
    bits[index / VECTOR_BASE] &= ~(((vectorT) 1) << (index % VECTOR_BASE));

} /* End of BitReset */



/******************************************************************************
 *  BitResetus
 * ---------------------------------------------------------------------------
 * "uint16" wrapper for BitReset
 ******************************************************************************/
void BitResetus(vectorT *bits, uint16 index)
{
    BitReset(bits, (int32) index);

} /* End of BitResetus */


/******************************************************************************
 *  BitSet
 * ---------------------------------------------------------------------------
 * This function sets the given bit in the bit vector.
 * This is done by locating the element, where the bit is and masking it
 * with the respective mask.
 ******************************************************************************/
void BitSet(vectorT *bits, int32 index)
{
    bits[index / VECTOR_BASE] |= (((vectorT) 1) << (index % VECTOR_BASE));

} /* End of BitSet */


/******************************************************************************
 *  BitSetus
 * ---------------------------------------------------------------------------
 * "uint16" wrapper for BitSet
 ******************************************************************************/
void BitSetus(vectorT *bits, uint16 index)
{
    BitSet(bits, (int32) index); 

} /* End of BitSetus */

