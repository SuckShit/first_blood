﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <optlib.h>

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "optlib.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

static int opt = -1;



int GetTheOpt()
{
    return opt;
}
    
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
char* GetNextOption(int argc, char** argv, OpEntryT options[MAX_OPS][MAX_ENTRY], 
    char** optKey, char** optValue)
{
    static int i = 2;   //命令行第二个参数指针位置
    static int n = 0;   //选项表小项
    
    *optKey = NULL;
    *optValue = NULL;
    BOOL foundFlag = FALSE;
    
    
    
    for (;i<argc;i++)
    {
        if (argv[i][0] == '-')
        {
            *optKey = argv[i]+1;
            i++;
                        
            if (i < argc && argv[i][0] != '-')
            {
                //
                *optValue = argv[i];
                i++;
            }       
            break;
        }
            else
            {
            //严格校验
            printf("should beign with '-'. \n");
            exit(0);
        }
    }
    
    
    //找到对应的参考项，只执行一次
    if (-1 == opt)
    {
        for (int j=0;j<MAX_OPS;j++)
        {
            if (*optKey && options[j][0].key && !strcmp(options[j][0].key, *optKey))
            {
                opt = j;
                break;
            }
        }
        if (-1 == opt)
        {
            opt = 0;
            return NULL;
            exit(0);
        }
    }
    
    //选项表已结尾
    while (!foundFlag)
    {
        //选项列表为空
        if (!options[opt][n].key)
        {
            if (!*optKey)
            {
                foundFlag = TRUE;  
                n++;         
                break;
            }
            else
            {
                //应该不能加选项了
                printf("invalid option for '%s', expect NULL.\n", *optKey);
                exit(0);
            }
        }
        else
        {
            if (!*optKey || strcmp(options[opt][n].key, *optKey))
            {
                if (options[opt][n].mask & MSK_DEF)
                {
                    //可以省略，下一个
                    n++;
                }
                else
                {
                    //选项不正确
                    printf("invalid option for '-%s', expect '-%s'.\n", 
                        *optKey, options[opt][n].key);
                    exit(0);
                }
            }
            else
            {
             //比对成功
            
                if ( (options[opt][n].mask & MSK_VAL && !*optValue) ||
                    (!(options[opt][n].mask & MSK_VAL) && *optValue) )
                {
                    //需要值后者不需要值与配置不符合
                    printf("invalid value set for '-%s'.\n", *optKey);
                    exit(0);
                }                    
                
                foundFlag = TRUE;    
                n++;       
                break;
            }
        }
    }
    
    return *optKey;
}
