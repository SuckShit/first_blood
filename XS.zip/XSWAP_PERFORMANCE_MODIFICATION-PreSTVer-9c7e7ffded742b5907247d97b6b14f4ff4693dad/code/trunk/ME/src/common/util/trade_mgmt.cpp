﻿/***
Created on Aug 10, 2017
@author: Pei.Rao
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "err_cod.h"
#include "uti_tool.h"
#include "common_hash.h"
#include "shm.h"
#include "ordr_mgmt.h"
#include "order_book.h"
#include "trade_mgmt.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT gTradeHshHdl[MAX_SET_CNT] = { 0 };

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
 

ResCodeT TradeShmCreate(int64 rcrdCnt, int32 setId)
{
    BEGIN_FUNCTION("TradeShmCreate");
    ResCodeT rc = NO_ERR;
    
    HashTableRecInfoT recInfo;
    void *pShmRoot;
    char shmName[SHM_NAME_LEN];
    
    recInfo.recSize = sizeof(TradeDatT);
    recInfo.keyOffset = offsetof(TradeDatT, trdKey);
    recInfo.keySize = sizeof(TradeKeyT);
    recInfo.recCnt = rcrdCnt;
    recInfo.bNeedTimeList = TRUE;
    
    sprintf(shmName, SHM_TRADE_NAME, setId);
    
    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)shmName), recInfo, TRUE, &pShmRoot, &gTradeHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT TradeShmDetach(int32 setId)
{
    BEGIN_FUNCTION("TradeShmDetach");
    ResCodeT rc = NO_ERR;
    
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_TRADE_NAME, setId);
    rc = ShmDetach(GetShmNm((char*)shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeShmAttach(int32 setId)
{
    BEGIN_FUNCTION("TradeShmAttach");
    ResCodeT rc = NO_ERR;
    
    void *pShmRoot;
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_TRADE_NAME, setId);
    rc = CmnHashTblAttach(GetShmNm((char*)shmName), &pShmRoot, &gTradeHshHdl[setId]);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeShmDelete(int32 setId)
{
    BEGIN_FUNCTION("TradeShmDelete");
    ResCodeT rc = NO_ERR;
    
    char shmName[SHM_NAME_LEN];
    
    sprintf(shmName, SHM_TRADE_NAME, setId);
    rc = ShmDetach(GetShmNm((char*)shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeShmReset(int32 setId)
{
    BEGIN_FUNCTION("TradeShmReset");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashResetTbl(gTradeHshHdl[setId]);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeChk(int32 setId, pTradeKeyT pTradeKey, pTradeDatT * ppTradeDat, uint32 * pTradePos)
{
    BEGIN_FUNCTION("TradeChk");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gTradeHshHdl[setId], (void*)pTradeKey, &isExist, pTradePos, (void**)ppTradeDat);
    RAISE_ERR(rc, RTN);
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeAdd(int32 setId, pTradeDatT pTradeDat, uint32 * pTradePos)
{
    BEGIN_FUNCTION("TradeAdd");
    ResCodeT rc = NO_ERR;
    
    BOOL              isExist = FALSE;
    uint32             nodePos;
    pTradeDatT          pTempTradeDat;
    
    rc = CmnHashCheckDataExt(gTradeHshHdl[setId], (void*)&pTradeDat->trdKey, &isExist, &nodePos, (void**)&pTempTradeDat);
    RAISE_ERR(rc, RTN);
    
    *pTradePos = nodePos;
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
    
    rc = CmnHashLogData(gTradeHshHdl[setId], pTradeDat, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeGetByPos(int32 setId, pTradeKeyT pTradeKey , uint32 tradePos, pTradeDatT * ppTradeDat )
{
    BEGIN_FUNCTION("TradeGetByPos");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gTradeHshHdl[setId], (void*)pTradeKey, &isExist, &tradePos, (void**)ppTradeDat );
    RAISE_ERR(rc, RTN);
    
    
    if (isExist == FALSE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeUpdtByPos(int32 setId, uint32 tradePos, pTradeDatT pTradeDat)
{
    BEGIN_FUNCTION("TradeUpdtByPos");
    ResCodeT rc = NO_ERR;

    rc = CmnHashUpdateData(gTradeHshHdl[setId], (void*) pTradeDat, tradePos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT TradeMgmtIter(int32 setId, uint32* pTradePos, pTradeDatT  pTradeDat)
{
    BEGIN_FUNCTION("TradeMgmtIter");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashIterData(gTradeHshHdl[setId], pTradePos, (void*)pTradeDat);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}