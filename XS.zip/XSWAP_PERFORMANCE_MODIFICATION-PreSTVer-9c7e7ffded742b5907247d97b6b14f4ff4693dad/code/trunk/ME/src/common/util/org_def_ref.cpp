/***
Created on June 15, 2017
@author: kong
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "data_type.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "mem_txn.h"
#include "common_macro.h"
#include "mem_txn_elem.h"
#include "cfg_lib.h"
#include "org_def_ref.h"

#include "usr.h"
#include "usr_onln.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "UsrRoleDb.h"

// database
#include "db_comm.h"
#include "OrgInfoDb.h"
#include "CrdtDb.h"
#include "CrdtDlAmntDb.h"

// share_memory
#include "org_info.h"

#include "pck_irs_dicdata.h"
#include "usr_def_ref.h"
#include "org_onln.h"

#include "OrgMktPrvlgDb.h"
#include "UsrMktPrvlgDb.h"

#include "OrgInfoBrdgDb.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
// OrgMarketRoleUpdate
ResCodeT OrgMarketRoleUpdMemUpdateCallback(OrgMemDataRefT *pData, int32 dataLen);
ResCodeT OrgMarketRoleUpdDbUpdateCallback(int32 connId, OrgMemDataRefT *pData, int32 dataLen);
ResCodeT OrgMarketRoleUpdPrintCallback(OrgMemDataRefT *pData, int32 dataLen);

ResCodeT UpdateOrgMarketRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen);
ResCodeT UpdateUsrMarketRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen);

ResCodeT UpdateOrgMarketIRSRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen);
ResCodeT UpdateOrgMarketSIRSRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen);
ResCodeT UpdateOrgMarketSBFCCPRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen);

// UsrMarketRoleUpdate
ResCodeT UsrMarketRoleUpdMemUpdateCallback(OrgMemDataRefT *pData, int32 dataLen);
ResCodeT UsrMarketRoleUpdDbUpdateCallback(int32 connId, OrgMemDataRefT *pData, int32 dataLen);
ResCodeT UsrMarketRoleUpdPrintCallback(OrgMemDataRefT *pData, int32 dataLen);



/******************************************************************************
 **
 ** OrgMemFreeze
 **
 ******************************************************************************/
ResCodeT OrgMemFreeze(pOrgMemDataRefT pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgMemFreeze" );
    ResCodeT                rc = NO_ERR;
    OrgMemDataRefT          data;
    pOrgInfoT               pOrgInfo = NULL;
    pUsrOnlnBaseInfoT       pUsrOnln = NULL;
    pUsrBaseInfoT           pUsrInfo = NULL;
    pUsrRoleBaseInfoT       pUsrRoleInfo = NULL;
    OrgFreezeStT            orgFreezeSt;
    uint32                  tmpPos = CMN_LIST_NULL_NODE;
    int32                   oldLgnTp = 0;
    int32                   newLgnTp = 0;
    int32                   oldRoleId = 0;
    int32                   newRoleId = 0;

    memset(&orgFreezeSt, 0x00, sizeof(OrgFreezeStT));
    rc = OrgInfoGetByIdExt(pData->intOrgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    rc = OnOrgInfoStatus(pOrgInfo->orgSt, pData->rqstType, &orgFreezeSt);
    RAISE_ERR(rc, RTN);

    pOrgInfo->orgSt = orgFreezeSt.intOrgSt;
    oldLgnTp  = orgFreezeSt.intOldLgnTp;
    newLgnTp  = orgFreezeSt.intNewLgnTp;
    oldRoleId = orgFreezeSt.intOldRoleId;
    newRoleId = orgFreezeSt.intNewRoleId;

    while ( TRUE )
    {
        rc = UsrOnlnIterExt(&tmpPos, &pUsrOnln);
        if (CMN_LIST_NULL_NODE == tmpPos)
        {
            break;    
        }
        RAISE_ERR(rc, RTN);
        rc = IrsUsrInfoGetByPosExt(pUsrOnln->pos, &pUsrInfo);
        RAISE_ERR(rc, RTN);

        if ((pUsrInfo->orgId == pData->intOrgId) && (pUsrInfo->lgnTp == oldLgnTp))
        {
            pUsrInfo->lgnTp = newLgnTp;
            pUsrOnln->lgnTp = newLgnTp;
        }

        rc = IrsRoleInfoGetByNameExt(pUsrOnln->usrNm, &pUsrRoleInfo);
        RAISE_ERR(rc, RTN);

        if (pUsrRoleInfo->roleId[oldRoleId-1] == 1)
        {
            pUsrRoleInfo->roleId[newRoleId-1] = 1;
            pUsrRoleInfo->roleId[oldRoleId-1] == 0;
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrgDBFreeze
 **
 ******************************************************************************/
ResCodeT OrgDBFreeze(int32 connId, pOrgMemDataRefT pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgDBFreeze" );
    ResCodeT                rc = NO_ERR;
    vectorT                 orgKeyVct[GET_BIT_VECT_LEN(29)] = {0};
    vectorT                 orgDatVct[GET_BIT_VECT_LEN(29)] = {0};
    OrgInfo                 orgInfoData;
    OrgFreezeStT            orgFreezeSt;

    memset(&orgFreezeSt, 0x00, sizeof(OrgFreezeStT));

    if (C_REQUEST_FORBID == pData->rqstType)
    {
        orgFreezeSt.intOrgSt     = C_ORG_ST_FORBID;
        orgFreezeSt.intOldLgnTp  = C_USER_ROLE_FRONT;
        orgFreezeSt.intNewLgnTp  = C_USER_ROLE_LIMIT_FRONT;
        orgFreezeSt.intOldRoleId = C_USER_ROLE_FRONT;
        orgFreezeSt.intNewRoleId = C_USER_ROLE_LIMIT_FRONT;
    }
    else if (C_REQUEST_ACTIVE == pData->rqstType)
    {
        orgFreezeSt.intOrgSt     = C_ORG_ST_ACTIVE;
        orgFreezeSt.intOldLgnTp  = C_USER_ROLE_LIMIT_FRONT;
        orgFreezeSt.intNewLgnTp  = C_USER_ROLE_FRONT;
        orgFreezeSt.intOldRoleId = C_USER_ROLE_LIMIT_FRONT;
        orgFreezeSt.intNewRoleId = C_USER_ROLE_FRONT;
    }
    else
    {
        RAISE_ERR(ERR_CODE_INVLD_ORG_FRZ_REQST, RTN);
    }

    /* update org staus */
    memset(&orgInfoData, 0x00, sizeof(OrgInfo));
    orgInfoData.orgId    = pData->intOrgId;
    snprintf(orgInfoData.orgIrsSt, sizeof(orgInfoData.orgIrsSt), "%d", orgFreezeSt.intOrgSt);
    memcpy(orgInfoData.updTm, pData->strUpdTm, sizeof(orgInfoData.updTm));
    memcpy(orgInfoData.updUsrNm, pData->strUserId, sizeof(orgInfoData.updUsrNm));

    DbCmmnSetColBit( orgKeyVct, 1 );
    DbCmmnSetColBit( orgDatVct, 9 );
    DbCmmnSetColBit( orgDatVct, 16 );
    DbCmmnSetColBit( orgDatVct, 18 );

    rc = UpdateOrgInfoByKey(connId, &orgInfoData, orgKeyVct, orgDatVct );
    RAISE_ERR(rc, RTN);

    /*  update usr_onln staus */
    rc = UpdateUsrOnlnLgnTpl(connId, pData->intOrgId, orgFreezeSt.intOldLgnTp, orgFreezeSt.intNewLgnTp);
    RAISE_ERR(rc, RTN);

    /*  update usr_role staus */
    rc = UpdateUsrRoleId(connId, pData->intOrgId, orgFreezeSt.intOldRoleId, orgFreezeSt.intNewRoleId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 **
 ** OrgMemRef
 **
 ******************************************************************************/
ResCodeT OrgMemRef(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgMemRef" );
    ResCodeT rc = NO_ERR;

    OrgMemDataRefT* pRefData;
    pRefData = (OrgMemDataRefT*)pData;
    switch (pRefData->eMessageType) {
        case MSG_TYPE_ORG_BANK_FREEZE:
            rc = OrgMemFreeze(pRefData, dataLen);
            break;
        case MSG_TYPE_ORG_MARKET_ROLE_UPDATE:
            rc = OrgMarketRoleUpdMemUpdateCallback(pRefData, dataLen);
            break;
        case MSG_TYPE_USR_MARKET_ROLE_UPDATE:
            rc = UsrMarketRoleUpdMemUpdateCallback(pRefData, dataLen);
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrgDbRef
 **
 ******************************************************************************/
ResCodeT OrgDbRef(int32 connId, void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgDbRef" );
    ResCodeT rc = NO_ERR;

    OrgMemDataRefT* pRefData;
    pRefData = (OrgMemDataRefT*)pData;
    switch (pRefData->eMessageType) {
        case MSG_TYPE_ORG_BANK_FREEZE:
            rc = OrgDBFreeze(connId, pRefData, dataLen);
            break;
        case MSG_TYPE_ORG_MARKET_ROLE_UPDATE:
            rc = OrgMarketRoleUpdDbUpdateCallback(connId, pRefData, dataLen);
            break;
        case MSG_TYPE_USR_MARKET_ROLE_UPDATE:
            rc = UsrMarketRoleUpdDbUpdateCallback(connId, pRefData, dataLen);
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrgDataPrintRef
 **
 ******************************************************************************/
ResCodeT OrgDataPrintRef(void *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgDataPrintRef" );
    ResCodeT rc = NO_ERR;

    OrgMemDataRefT* pRefData;
    pRefData = (OrgMemDataRefT*)pData;
    switch (pRefData->eMessageType) {
        case MSG_TYPE_ORG_BANK_FREEZE:
            break;
        case MSG_TYPE_ORG_MARKET_ROLE_UPDATE:    
            rc = OrgMarketRoleUpdPrintCallback(pRefData, dataLen);
            break;
        case MSG_TYPE_USR_MARKET_ROLE_UPDATE:
            rc = UsrMarketRoleUpdPrintCallback(pRefData, dataLen);
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UsrMarketRoleUpdMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT UsrMarketRoleUpdMemUpdateCallback(OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UsrMarketRoleUpdMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    UsrBaseInfoT *pUsrBaseInfo = NULL;

    // update share memory.
    rc = IrsUsrInfoGetByNameExt(pData->strOpUserId, &pUsrBaseInfo);
    RAISE_ERR(rc, RTN);
    if (!pUsrBaseInfo) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    switch (pData->intMktTp){
        case C_MKT_TP_IRS:
            pUsrBaseInfo->mktSt[0] = pData->intSt;
            break;
        case C_MKT_TP_SIRS:
            pUsrBaseInfo->mktSt[1] = pData->intSt;
            break;
        case C_MKT_TP_SBF:
            pUsrBaseInfo->mktSt[2] = pData->intSt;
            break;
        case C_MKT_TP_SIRSCCP:
            pUsrBaseInfo->mktSt[3] = pData->intSt;
            break;
        case C_MKT_TP_SBFCCP:
            pUsrBaseInfo->mktSt[4] = pData->intSt;
            break;
        default:
            break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UsrMarketRoleUpdDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT UsrMarketRoleUpdDbUpdateCallback(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UsrMarketRoleUpdDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    UsrMktPrvlg data;
    vectorT  keyVct[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(10)] = {0};
    
    memset(&data, 0x00, sizeof(UsrMktPrvlg));

    //DataSet
    sprintf(data.st, "%d", pData->intSt);
    strcpy(data.updTm,     pData->strUpdTm);
    strcpy(data.updUsrNm,  pData->strUserId);

    DbCmmnSetColBit(datVct, 3);
    DbCmmnSetColBit(datVct, 6);
    DbCmmnSetColBit(datVct, 7);

    //KeySet
    strcpy(data.usrLgnNm,  pData->strOpUserId);
    sprintf(data.mktTp, "%d", pData->intMktTp);

    DbCmmnSetColBit(keyVct, 1);
    DbCmmnSetColBit(keyVct, 2);

    rc = UpdateUsrMktPrvlgByKey(connId, &data, keyVct, datVct);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UsrMarketRoleUpdPrintCallback
 **
 ******************************************************************************/
ResCodeT UsrMarketRoleUpdPrintCallback(OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UsrMarketRoleUpdPrintCallback" );
    ResCodeT rc = NO_ERR;

    // 输入信息打印日志打印
    LOG_INFO("[IN]Condition: strUserId = %s",       pData->strUserId);
    LOG_INFO("[IN]Condition: strOpUserId = %s",     pData->strOpUserId);
    LOG_INFO("[IN]Condition: intSt = %d",           pData->intSt);
    LOG_INFO("[IN]Condition: intMktTp = %d",        pData->intMktTp);
    LOG_INFO("[IN]Condition: strUpdTm = %s",        pData->strUpdTm);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrgMarketRoleUpdMemUpdateCallback
 **
 ******************************************************************************/
ResCodeT OrgMarketRoleUpdMemUpdateCallback(OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgMarketRoleUpdMemUpdateCallback" );
    ResCodeT rc = NO_ERR;

    OrgInfoT *pOrgInfo = NULL;

    //Update OrgInfo ShareMemory
    rc = OrgInfoGetByIdExt(atoi(pData->strOpOrgId), &pOrgInfo);
    RAISE_ERR(rc, RTN);
    if (!pOrgInfo) {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    switch (pData->intMktTp){
        case C_MKT_TP_IRS:
            pOrgInfo->mktTypeSt[0] = pData->intOrgMktSt[0];
            // Update User ShareMemory
            if (C_USR_MKT_UPDATE_YES == pData->intUpdUsrMktFlg) {
                rc = UpdateUsrMrkPrvlg(pOrgInfo->pos, C_MKT_TP_IRS, &pData->intSt);
            }
            break;
        case C_MKT_TP_SIRS:
            pOrgInfo->mktTypeSt[1] = pData->intOrgMktSt[1];
            // Update User ShareMemory
            if (C_USR_MKT_UPDATE_YES == pData->intUpdUsrMktFlg) {
                rc = UpdateUsrMrkPrvlg(pOrgInfo->pos, C_MKT_TP_SIRS, &pData->intSt);
            }
            break;
        case C_MKT_TP_SBF:
            pOrgInfo->mktTypeSt[2] = pData->intOrgMktSt[2];
            // Update User ShareMemory
            if (C_USR_MKT_UPDATE_YES == pData->intUpdUsrMktFlg) {
                rc = UpdateUsrMrkPrvlg(pOrgInfo->pos, C_MKT_TP_SBF, &pData->intSt);
            }
            break;
        case C_MKT_TP_SIRSCCP:
            pOrgInfo->mktTypeSt[3] = pData->intOrgMktSt[3];
            // Update User ShareMemory
            if (C_USR_MKT_UPDATE_YES == pData->intUpdUsrMktFlg) {
                rc = UpdateUsrMrkPrvlg(pOrgInfo->pos, C_MKT_TP_SIRSCCP, &pData->intSt);
            }
            break;
        case C_MKT_TP_SBFCCP:
            pOrgInfo->mktTypeSt[4] = pData->intOrgMktSt[4];
            // Update User ShareMemory
            if (C_USR_MKT_UPDATE_YES == pData->intUpdUsrMktFlg) {
                rc = UpdateUsrMrkPrvlg(pOrgInfo->pos, C_MKT_TP_SBFCCP, &pData->intSt);
            }
            break;
        default:
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrgMarketRoleUpdDbUpdateCallback
 **
 ******************************************************************************/
ResCodeT OrgMarketRoleUpdDbUpdateCallback(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgMarketRoleUpdDbUpdateCallback" );
    ResCodeT rc = NO_ERR;

    rc = UpdateOrgMarketRole(connId, pData, dataLen);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    if (C_USR_MKT_UPDATE_YES == pData->intUpdUsrMktFlg) {
        rc = UpdateUsrMarketRole(connId, pData, dataLen);
        if (NOTOK(rc)) {
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** OrgMarketRoleUpdPrintCallback
 **
 ******************************************************************************/
ResCodeT OrgMarketRoleUpdPrintCallback(OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "OrgMarketRoleUpdPrintCallback" );
    ResCodeT rc = NO_ERR;

    // 输入信息打印日志打印
    LOG_INFO("[IN]Condition: strUserId = %s",               pData->strUserId);
    LOG_INFO("[IN]Condition: strOpOrgId = %s",              pData->strOpOrgId);
    LOG_INFO("[IN]Condition: intOrgId = %d",                pData->intOrgId);
    LOG_INFO("[IN]Condition: intSt = %d",                   pData->intSt);
    LOG_INFO("[IN]Condition: intMktTp = %d",                pData->intMktTp);
    LOG_INFO("[IN]Condition: strUpdTm = %s",                pData->strUpdTm);
    LOG_INFO("[IN]Condition: intOrgMktSt[IRS] = %d",        pData->intOrgMktSt[0]);
    LOG_INFO("[IN]Condition: intOrgMktSt[SIRS] = %d",       pData->intOrgMktSt[1]);
    LOG_INFO("[IN]Condition: intOrgMktSt[SBF] = %d",        pData->intOrgMktSt[2]);
    LOG_INFO("[IN]Condition: intOrgMktSt[SIRSCCP] = %d",    pData->intOrgMktSt[3]);
    LOG_INFO("[IN]Condition: intOrgMktSt[SBFCCP] = %d",     pData->intOrgMktSt[4]);
    LOG_INFO("[IN]Condition: intUpdUsrMktFlg = %d",         pData->intUpdUsrMktFlg);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgMarketRole
 **
 ******************************************************************************/
ResCodeT UpdateOrgMarketRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UpdateOrgMarketRole" );
    ResCodeT rc = NO_ERR;

    switch (pData->intMktTp){
        case C_MKT_TP_IRS:
            //IRS市场更新(有)
            rc = UpdateOrgMarketIRSRole(connId, pData, dataLen);
            break;
        case C_MKT_TP_SIRS:
            //SIRS市场更新(有)
            rc = UpdateOrgMarketSIRSRole(connId, pData, dataLen);
            break;
        case C_MKT_TP_SBF:
            //SBF市场更新(无)
            break;
        case C_MKT_TP_SIRSCCP:
            //SIRSCCP市场更新(无)
            break;
        case C_MKT_TP_SBFCCP:
            //SBFCCP市场更新(有)
            rc = UpdateOrgMarketSBFCCPRole(connId, pData, dataLen);
            break;
        default :
            break;
    }
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateUsrMarketRole
 **
 ******************************************************************************/
ResCodeT UpdateUsrMarketRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UpdateUsrMarketRole" );
    ResCodeT rc = NO_ERR;

    UsrMktPrvlg data;
    vectorT  keyVct[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(10)] = {0};

    int32 usrCnt = 0;
    int32 intOpOrgId = atoi(pData->strOpOrgId);
    int32 i = 0;
    BOOL bFirstFlg = TRUE;
    char strUsrNm[MAX_USR_NM_LENTH];

    rc = GetResultCntOfUsrWithOrgId(connId, intOpOrgId, &usrCnt);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    if (usrCnt < 0) {
        LOG_INFO(" this OrgId[%d] user count=%d.", intOpOrgId, usrCnt);
        RAISE_ERR(ERR_DB_OCI_GET_RESULTSET_ERR, RTN);
    }

    LOG_INFO(" this OrgId[%d] user count=%d.", intOpOrgId, usrCnt);
    for (i = 0; i < usrCnt; i++) {
        memset(strUsrNm, 0x00, sizeof(strUsrNm));
        rc = FetchNextUsrWithOrgId( &bFirstFlg, connId, intOpOrgId, strUsrNm );
        RAISE_ERR(rc, RTN);

        memset(&data, 0x00, sizeof(UsrMktPrvlg));

        //DataSet
        sprintf(data.st, "%d", pData->intSt);
        strcpy(data.updTm,     pData->strUpdTm);
        strcpy(data.updUsrNm,  pData->strUserId);

        DbCmmnSetColBit(datVct, 3);
        DbCmmnSetColBit(datVct, 6);
        DbCmmnSetColBit(datVct, 7);

        //KeySet
        strcpy(data.usrLgnNm, strUsrNm);
        sprintf(data.mktTp, "%d", pData->intMktTp);

        DbCmmnSetColBit(keyVct, 1);
        DbCmmnSetColBit(keyVct, 2);

        rc = UpdateUsrMktPrvlgByKey(connId, &data, keyVct, datVct);
        if (NOTOK(rc)) {
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgMarketIRSRole
 **
 ******************************************************************************/
ResCodeT UpdateOrgMarketIRSRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UpdateOrgMarketIRSRole" );
    ResCodeT rc = NO_ERR;

    OrgMktPrvlg data;
    vectorT  keyVct[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(10)] = {0};
    
    memset(&data, 0x00, sizeof(OrgMktPrvlg));

    //DataSet
    sprintf(data.st, "%d", pData->intOrgMktSt[0]);
    strcpy(data.updTm,     pData->strUpdTm);
    strcpy(data.updUsrNm,  pData->strUserId);

    DbCmmnSetColBit(datVct, 3);
    DbCmmnSetColBit(datVct, 6);
    DbCmmnSetColBit(datVct, 7);

    //KeySet
    data.orgId = atoi(pData->strOpOrgId);
    sprintf(data.mktTp, "%d", C_MKT_TP_IRS);

    DbCmmnSetColBit(keyVct, 1);
    DbCmmnSetColBit(keyVct, 2);

    rc = UpdateOrgMktPrvlgByKey(connId, &data, keyVct, datVct);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgMarketSIRSRole
 **
 ******************************************************************************/
ResCodeT UpdateOrgMarketSIRSRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UpdateOrgMarketSIRSRole" );
    ResCodeT rc = NO_ERR;

    OrgMktPrvlg data;
    vectorT  keyVct[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(10)] = {0};
    
    memset(&data, 0x00, sizeof(OrgMktPrvlg));

    //DataSet
    sprintf(data.st, "%d", pData->intOrgMktSt[1]);
    strcpy(data.updTm,     pData->strUpdTm);
    strcpy(data.updUsrNm,  pData->strUserId);

    DbCmmnSetColBit(datVct, 3);
    DbCmmnSetColBit(datVct, 6);
    DbCmmnSetColBit(datVct, 7);

    //KeySet
    data.orgId = atoi(pData->strOpOrgId);
    sprintf(data.mktTp, "%d", C_MKT_TP_SIRS);

    DbCmmnSetColBit(keyVct, 1);
    DbCmmnSetColBit(keyVct, 2);

    rc = UpdateOrgMktPrvlgByKey(connId, &data, keyVct, datVct);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgMarketSBFCCPRole
 **
 ******************************************************************************/
ResCodeT UpdateOrgMarketSBFCCPRole(int32 connId, OrgMemDataRefT *pData, int32 dataLen)
{
    BEGIN_FUNCTION( "UpdateOrgMarketSBFCCPRole" );
    ResCodeT rc = NO_ERR;

    OrgMktPrvlg data;
    vectorT  keyVct[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(10)] = {0};
    
    memset(&data, 0x00, sizeof(OrgMktPrvlg));

    //DataSet
    sprintf(data.st, "%d", pData->intOrgMktSt[4]);
    strcpy(data.updTm,     pData->strUpdTm);
    strcpy(data.updUsrNm,  pData->strUserId);

    DbCmmnSetColBit(datVct, 3);
    DbCmmnSetColBit(datVct, 6);
    DbCmmnSetColBit(datVct, 7);

    //KeySet
    data.orgId = atoi(pData->strOpOrgId);
    sprintf(data.mktTp, "%d", C_MKT_TP_SBFCCP);

    DbCmmnSetColBit(keyVct, 1);
    DbCmmnSetColBit(keyVct, 2);

    rc = UpdateOrgMktPrvlgByKey(connId, &data, keyVct, datVct);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
