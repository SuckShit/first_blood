﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/ 

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "shm.h"
#include "nmbr_srvc.h"
#include "mem_txn.h"
#include "uti_tool.h"
#include "match_lib.h"
#include "order_type.h"
#include "order_book.h"
#include "OrdrDb.h"
#include "PrcsTxnIdtblDb.h"
#include "cfg_lib.h"
#include "db_comm.h"
#include "common_macro.h"
#include "contract_info.h"
#include "DlDb.h"
#include "err_cod.h"
#include "contract_info.h"
#include "org_info.h"
#include "usr.h"
#include "ordr_mgmt.h"
#include "dump_ord.h"
#include "ref_dat_updt.h"
#include "CrdtDb.h"
#include "credit_info.h"
#include "credit_mgmt.h"
#include "pck_irs_dicdata.h"
#include "monitor_thread.h"
#include "OcoOrdrDb.h"
#include "OrdrSirsDb.h"
#include "OrdrSbfccpDb.h"
#include "prdct_info.h"
#include "internal_base_def.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define ORD_STS_ORD_ST 1
#define ORD_STS_ORD_ADD 2
#define ORD_STS_TRD_LOG 3
#define ORD_STS_ORD_DEL 4

/* Print Trade Sts*/
#define TRD_STS_TRD_LOG 1


/* Print Ordr Type Name*/
#define ORDR_TYPE_NAME_NORMAL  "R"
#define ORDR_TYPE_NAME_OCO "OCO"
#define ORDR_TYPE_NAME_BIL "BIL"

/* Print Ordr Mask Name*/
#define ORDR_SIDE_NAME_BUY  "B"
#define ORDR_SIDE_NAME_SELL "S"

#define ORDR_TRDRESTR_NAME_OA  "OA"
#define ORDR_TRDRESTR_NAME_AU  "AU"

#define ORDR_TYPE_NAME_LIMIT "LMT"
#define ORDR_TYPE_NAME_MARKT "MARKT"
#define ORDR_TYPE_NAME_MKTOL "MKTOL"

#define ORDR_NAME_NULL "-"
#define DUMP_RETRY_MAX_TIMES    3
#define DUMP_RETRY_MAX_TXNID    (((uint64)-1)>>1)
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static int32 gSetId = -1;
static int32 gConnId = -1;
static int64 gCurrDumpTxnId = 0;


/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT UpdateTxnDumpPrcsTxnIdtbl();

/******************************************************************************
 * Description:   MakeApiRqstId
 * Parameters:
 ******************************************************************************/
ResCodeT MakeApiRqstId(char* strDate, char* strApiUsrNm, int64 iReqId, char* strReqId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("MakeApiRqstId");

    char date[9];
    memset(date, 0x00, sizeof(date));
    memcpy(date, &strDate[0], 8);

    // e.g. ORDE20171025xswapsydd00000009
    sprintf(strReqId, "ORDR%s%s%08lld", date, strApiUsrNm, iReqId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Trans order status (from inside to ouside)
 * Parameters:
 *      ordrSts       IN  inside order status(in order book)
 *      pOrdrSts      OUT outside order status(in database)
 *      NO_ERR:       Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT TransOrdrSts( int16 ordrSts, char * pOrdrSts )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("TransOrdrSts");
    
    int32 value = 0;

    if ( !ordrSts )
    {
        strcpy( pOrdrSts, C_ORD_STATUS_FROZEN );
        THROW_RESCODE(NO_ERR);
    }

    switch ( ordrSts )
    {
        case ORDR_STS_ACTIVE :
            strcpy( pOrdrSts, C_ORD_STATUS_ACTIVE );
            break;
        case ORDR_STS_DEAL :    
            strcpy( pOrdrSts, C_ORD_STATUS_CLOSED );
            break;
        case ORDR_STS_CANCEL :
            strcpy( pOrdrSts, C_ORD_STATUS_CANCELED );
            break;
        case ORDR_STS_FREEZE :
        case ORDR_STS_INACTIVE :
            strcpy( pOrdrSts, C_ORD_STATUS_FROZEN );
            break;
        case ORDR_STS_INVALID :
            strcpy( pOrdrSts, C_ORD_STATUS_INVLD );
            break;
        default:
            RAISE_ERR( ERR_CODE_INVLD_ORDER_STATUS, RTN );
            break;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get order side
 * Parameters:
 *      oMask       IN  order mash value
 *      *side       OUT B-buy,S-sell 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT GetOrderSide(int32 oMask, char *side)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("GetOrderSide");
    
    int32 value = 0;
    value = GET_ORDR_SIDE(oMask);
    if (value == ORDR_SIDE_BUY)
    {
        strcpy(side,ORDR_SIDE_NAME_BUY);
    }
    else if (value == ORDR_SIDE_SELL )
    {
        strcpy(side,ORDR_SIDE_NAME_SELL);
    }
    else
    {
        strcpy(side,ORDR_NAME_NULL);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   get trading restricttion
 * Parameters:
 *      oMask       IN  order mash value
 *      *trdrestr   OUT  
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT GetTradingRestriction(int32 oMask, char *trdrestr)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("GetTradingRestriction");
    
    int32 value = 0;
    value = GET_ORDR_TRDRESTR(oMask);
    if (value == ORDR_TRDRESTR_OA)
    {
        strcpy(trdrestr,ORDR_TRDRESTR_NAME_OA);

    }
    else if (value == ORDR_TRDRESTR_AU)
    {
        strcpy(trdrestr,ORDR_TRDRESTR_NAME_AU);
    }
    else
    {
        strcpy(trdrestr,ORDR_NAME_NULL);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   get Order type
 * Parameters:
 *      oMask       IN  order mash value
 *      *type       OUT  
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT GetOrderType(int32 oMask, char *type)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("GetOrderType");
    
    int32 value = 0;
    
    value = GET_ORDR_EXERESTR(oMask);
    if (value == ORDR_TYPE_LIMIT)
    {
        strcpy(type,ORDR_TYPE_NAME_LIMIT);
    }
    else if (value == ORDR_TYPE_MARKT)
    {
        strcpy(type,ORDR_TYPE_NAME_MARKT);
    }
    else if (value == ORDR_TYPE_MKTOL)
    {
        strcpy(type,ORDR_TYPE_NAME_MKTOL);
    }
    else
    {
        strcpy(type,ORDR_NAME_NULL);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Init dump_ord
 * Parameters:
 *      set         IN  set Id
 *      pConnId     OUT connection Id
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail init
 ******************************************************************************/
ResCodeT DumpOrdInit(int32 set )
{
    BEGIN_FUNCTION( "DumpOrdInit" );
    ResCodeT    rc = NO_ERR;
    
    int32       txnDumpCnt = 0;

    CfgValueT    cfgValue;

    rc = IrsUsrInfoAttachToShm();
    RAISE_ERR(rc,RTN);    
    rc = DbCmmnInit();
    RAISE_ERR(rc,RTN);
    rc = IrsCntrctInfoAttachToShm();
    RAISE_ERR(rc,RTN);
    rc = OrgInfoAttachToShm();
    RAISE_ERR(rc,RTN);
    rc = MemTxnShmInit(set);
    RAISE_ERR(rc,RTN);

    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc,RTN);
    rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &gConnId);
    RAISE_ERR(rc,RTN);
    rc = OrdrMgmtShmAttach(set);
    RAISE_ERR(rc,RTN);

    /* get memtxn dumped no */
    /* if the record doesn't exit, insert a new one  */

    
    rc = SelectPrcsTxnIdtblByKey( gConnId, (PrcsTxnIdtblKey*)&set, &txnDumpCnt);
    if ( rc == ERR_DB_COMMON_FETCH_END )
    {
        PrcsTxnIdtbl prcsTxnIdtblData = {0};
        prcsTxnIdtblData.keyValue = 0;
        prcsTxnIdtblData.setId = set;

        rc = InsertPrcsTxnIdtbl( gConnId, &prcsTxnIdtblData );
        RAISE_ERR(rc, RTN);
        
        rc = DbCmmnCommit( gConnId );
        RAISE_ERR(rc, NO_ERR);
    }
    RAISE_ERR(rc,RTN);

    gSetId = set;
    gCurrDumpTxnId = txnDumpCnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   replace items in structure Ordr
 * Parameters:
 *      pOrderF     IN  structure pOrdrF
 *      pOrdr       OUT structure pOrdr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT ReplaceOrdrF(pOrderFT  pOrderF, Ordr *pOrdr)
{
    BEGIN_FUNCTION( "ReplaceOrdrF" );
    ResCodeT    rc = NO_ERR;
    
    int64           timestamp;
    char            DateTime[MAX_DATETIME_LEN];
    CntrctBaseInfoT IrsCntrctInfo;
    OrgInfoT        OrgInfo;
    char            type[10];
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    pUsrBaseInfoT   pUsr;
    pUsrBaseInfoT   pApiUsr;
    
    rc = OrgInfoGetByPos(pOrderF->entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pOrderF->userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = IrsUsrInfoGetByPosExt(pOrderF->apiLoginUsrIdx, &pApiUsr);
        RAISE_ERR(rc,RTN);
        
//        sprintf(pOrdr->rqstId, "%lld", pOrderF->apiRqstId);
        strcpy(pOrdr->usrLgnNmApi, pApiUsr->usrLgnNm);
        strcpy(pOrdr->updUsrNm, pApiUsr->usrLgnNm);
    }
    else
    {
        strcpy(pOrdr->updUsrNm, pUsr->usrLgnNm);
        strcpy(pOrdr->rqstId, "");
        strcpy(pOrdr->usrLgnNmApi, "");
    }
    
    memset( pOrdr->ordrId, 0, sizeof( pOrdr->ordrId));
    sprintf( pOrdr->ordrId, "%lld",pOrderF->ordrNo);
    pOrdr->orgId = OrgInfo.orgId;
    GetOrderType(pOrderF->ordrMask, type);
    strcpy(pOrdr->ordrSbmtTp, type);
    
    if (pOrderF->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_OCO);
        strcpy(pOrdr->bilId, "");
        sprintf(pOrdr->ocoId, "%s%lld", C_ORD_TYPE_OCO, pOrderF->specOrdrNo);
    }
    else if (pOrderF->extOrdrType == EXT_ORD_TYPE_BIL)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_BIL);
        sprintf(pOrdr->bilId, "%s%lld", C_ORD_TYPE_BIL, pOrderF->specOrdrNo);
        strcpy(pOrdr->ocoId, "");
    }
    else
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_R);
        strcpy(pOrdr->bilId, "");
        strcpy(pOrdr->ocoId, "");
    }
    
    rc = IrsCntrctInfoGetByPos(pOrderF->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->cntrctNm, IrsCntrctInfo.cntrctName);
    pOrdr->ntnlAmnt = (double)pOrderF->remPkQty;//pOrderF->ordrQty;
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;//pOrderF->remPkQty;
    pOrdr->ordrPrc = (double)pOrderF->ordrExePrc/PRICE_BASE;
    pOrdr->ordrAmnt = 0;//(double)pOrderF->ordrExeQty;
    sprintf( pOrdr->dlDir, "%lld", GET_ORDR_SIDE(pOrderF->ordrMask));//strcpy(pOrdr->dlDir, GET_ORDR_SIDE(pOrderF->ordrMask));
    memset(pOrdr->st, 0, sizeof(pOrdr->st));
    strcpy(pOrdr->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->ordrCrtTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrExpTim, DateTime);
    strcpy(pOrdr->ordrExprdTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    strcpy(pOrdr->ordrActvTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->updTm, DateTime);
    
    strcpy(pOrdr->orgFullNmCn, OrgInfo.orgFullNmCn);
    strcpy(pOrdr->vrtlBrdgOrdrF, "");//sprintf(pOrdr->vrtlBrdgOrdrF, "%u", OrgInfo.brdgOrdrRfrshFlag);
    strcpy(pOrdr->orgCd, OrgInfo.orgCd);
    

    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = MakeApiRqstId(pOrdr->ordrCrtTm, pApiUsr->usrLgnNm, pOrderF->apiRqstId, pOrdr->rqstId);
        RAISE_ERR(rc,RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
   
}



/******************************************************************************
 * Description:   replace items in structure OrdrSirs
 * Parameters:
 *      pOrderF     IN  structure pOrdrF
 *      pOrdr       OUT structure pOrdrSirs
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT ReplaceOrdrSirsF(pOrderFT  pOrderF, OrdrSirs *pOrdr)
{
    BEGIN_FUNCTION( "ReplaceOrdrF" );
    ResCodeT    rc = NO_ERR;
    
    int64           timestamp;
    char            DateTime[MAX_DATETIME_LEN];
    CntrctBaseInfoT IrsCntrctInfo;
    OrgInfoT        OrgInfo;
    char            type[10];
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    pUsrBaseInfoT   pUsr;
    pUsrBaseInfoT   pApiUsr;
    
    rc = OrgInfoGetByPos(pOrderF->entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pOrderF->userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = IrsUsrInfoGetByPosExt(pOrderF->apiLoginUsrIdx, &pApiUsr);
        RAISE_ERR(rc,RTN);
        
//        sprintf(pOrdr->rqstId, "%lld", pOrderF->apiRqstId);
        strcpy(pOrdr->usrLgnNmApi, pApiUsr->usrLgnNm);
        strcpy(pOrdr->updUsrNm, pApiUsr->usrLgnNm);
    }
    else
    {
        strcpy(pOrdr->updUsrNm, pUsr->usrLgnNm);
        strcpy(pOrdr->rqstId, "");
        strcpy(pOrdr->usrLgnNmApi, "");
    }
    
    memset( pOrdr->ordrId, 0, sizeof( pOrdr->ordrId));
    sprintf( pOrdr->ordrId, "%lld",pOrderF->ordrNo);
    pOrdr->orgId = OrgInfo.orgId;
    GetOrderType(pOrderF->ordrMask, type);
    strcpy(pOrdr->ordrSbmtTp, type);
    
    if (pOrderF->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_OCO);
        sprintf(pOrdr->ocoId, "%s%lld", C_ORD_TYPE_OCO, pOrderF->specOrdrNo);
    }
    else
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_R);
        strcpy(pOrdr->ocoId, "");
    }
    
    rc = IrsCntrctInfoGetByPos(pOrderF->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->cntrctCd, IrsCntrctInfo.cntrctName);
    pOrdr->ntnlAmnt = (double)pOrderF->remPkQty;//pOrderF->ordrQty;
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;//pOrderF->remPkQty;
    pOrdr->ordrPrc = (double)pOrderF->ordrExePrc/PRICE_BASE;
    pOrdr->ordrAmnt = 0;//(double)pOrderF->ordrExeQty;
    sprintf( pOrdr->dlDir, "%lld", GET_ORDR_SIDE(pOrderF->ordrMask));//strcpy(pOrdr->dlDir, GET_ORDR_SIDE(pOrderF->ordrMask));
    memset(pOrdr->st, 0, sizeof(pOrdr->st));
    strcpy(pOrdr->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->ordrCrtTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrExpTim, DateTime);
    strcpy(pOrdr->ordrExprdTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    strcpy(pOrdr->ordrActvTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->updTm, DateTime);
    
    strcpy(pOrdr->orgFullNmCn, OrgInfo.orgFullNmCn);
    strcpy(pOrdr->orgCd, OrgInfo.orgCd);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = MakeApiRqstId(pOrdr->ordrCrtTm, pApiUsr->usrLgnNm, pOrderF->apiRqstId, pOrdr->rqstId);
        RAISE_ERR(rc,RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;
   
}



/******************************************************************************
 * Description:   replace items in structure OrdrSbfccp
 * Parameters:
 *      pOrderF     IN  structure pOrdrF
 *      pOrdr       OUT structure pOrdrSbfccp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT ReplaceOrdrSbfccpF(pOrderFT  pOrderF, OrdrSbfccp *pOrdr)
{
    BEGIN_FUNCTION( "ReplaceOrdrF" );
    ResCodeT    rc = NO_ERR;
    
    int64           timestamp;
    char            DateTime[MAX_DATETIME_LEN];
    CntrctBaseInfoT IrsCntrctInfo;
    OrgInfoT        OrgInfo;
    char            type[10];
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    pUsrBaseInfoT   pUsr;
    pUsrBaseInfoT   pApiUsr;
    
    rc = OrgInfoGetByPos(pOrderF->entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pOrderF->userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = IrsUsrInfoGetByPosExt(pOrderF->apiLoginUsrIdx, &pApiUsr);
        RAISE_ERR(rc,RTN);
        
//        sprintf(pOrdr->rqstId, "%lld", pOrderF->apiRqstId);
        strcpy(pOrdr->usrLgnNmApi, pApiUsr->usrLgnNm);
        strcpy(pOrdr->updUsrNm, pApiUsr->usrLgnNm);
    }
    else
    {
        strcpy(pOrdr->updUsrNm, pUsr->usrLgnNm);
        strcpy(pOrdr->rqstId, "");
        strcpy(pOrdr->usrLgnNmApi, "");
    }
    
    memset( pOrdr->ordrId, 0, sizeof( pOrdr->ordrId));
    sprintf( pOrdr->ordrId, "%lld",pOrderF->ordrNo);
    pOrdr->orgId = OrgInfo.orgId;
    GetOrderType(pOrderF->ordrMask, type);
    strcpy(pOrdr->ordrSbmtTp, type);
    
    if (pOrderF->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_OCO);
        sprintf(pOrdr->ocoId, "%s%lld", C_ORD_TYPE_OCO, pOrderF->specOrdrNo);
    }
    else
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_R);
        strcpy(pOrdr->ocoId, "");
    }

    rc = IrsCntrctInfoGetByPos(pOrderF->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->cntrctCd, IrsCntrctInfo.cntrctName);
    pOrdr->ntnlAmnt = (double)pOrderF->remPkQty;//pOrderF->ordrQty;
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;//pOrderF->remPkQty;
    pOrdr->ordrPrc = (double)pOrderF->ordrExePrc/PRICE_BASE;
    pOrdr->ordrAmnt = 0;//(double)pOrderF->ordrExeQty;
    sprintf( pOrdr->dlDir, "%lld", GET_ORDR_SIDE(pOrderF->ordrMask));//strcpy(pOrdr->dlDir, GET_ORDR_SIDE(pOrderF->ordrMask));
    memset(pOrdr->st, 0, sizeof(pOrdr->st));
    strcpy(pOrdr->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->ordrCrtTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrExpTim, DateTime);
    strcpy(pOrdr->ordrExprdTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    strcpy(pOrdr->ordrActvTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->updTm, DateTime);
    
    strcpy(pOrdr->orgFullNmCn, OrgInfo.orgFullNmCn);
    strcpy(pOrdr->orgCd, OrgInfo.orgCd);
    strcpy(pOrdr->clsPstnCd, "");
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = MakeApiRqstId(pOrdr->ordrCrtTm, pApiUsr->usrLgnNm, pOrderF->apiRqstId, pOrdr->rqstId);
        RAISE_ERR(rc,RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;
   
}



/******************************************************************************
 * Description:   update ordr tems in structure ordr
 * Parameters:
 *      setId       IN  set Id
 *      pTrade      IN  structure pOrderFT
 *      pOrdr       OUT structure Ordr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT UpdateOrdrF(pOrderFT  pOrderF, Ordr *pOrdr)
{
    BEGIN_FUNCTION( "UpdateOrdrF" );
    ResCodeT    rc = NO_ERR;
    
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    
    int64           timestamp;
    char            DateTime[MAX_DATETIME_LEN];
    CntrctBaseInfoT IrsCntrctInfo;
    OrgInfoT        OrgInfo;
    char            type[10];
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    pUsrBaseInfoT   pUsr;
    pUsrBaseInfoT   pApiUsr;
    
    memset(pOrdr, 0, sizeof(pOrdr));
    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);
    
    rc = OrgInfoGetByPos(pOrderF->entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pOrderF->userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = IrsUsrInfoGetByPosExt(pOrderF->apiLoginUsrIdx, &pApiUsr);
        RAISE_ERR(rc,RTN);
        
//        sprintf(pOrdr->rqstId, "%lld", pOrderF->apiRqstId);
        strcpy(pOrdr->usrLgnNmApi, pApiUsr->usrLgnNm);
        strcpy(pOrdr->updUsrNm, pApiUsr->usrLgnNm);
    }
    else
    {
        strcpy(pOrdr->updUsrNm, pUsr->usrLgnNm);
        strcpy(pOrdr->usrLgnNmApi, "");
        strcpy(pOrdr->rqstId, "");
    }
    
    pOrdr->orgId = OrgInfo.orgId;
    GetOrderType(pOrderF->ordrMask, type);
    strcpy(pOrdr->ordrSbmtTp, type);
    if (pOrderF->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_OCO);
        strcpy(pOrdr->bilId, "");
        sprintf(pOrdr->ocoId, "%s%lld", C_ORD_TYPE_OCO, pOrderF->specOrdrNo);
    }
    else if (pOrderF->extOrdrType == EXT_ORD_TYPE_BIL)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_BIL);
        sprintf(pOrdr->bilId, "%s%lld", C_ORD_TYPE_BIL, pOrderF->specOrdrNo);
        strcpy(pOrdr->ocoId, "");
    }
    else
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_R);
        strcpy(pOrdr->bilId, "");
        strcpy(pOrdr->ocoId, "");
    }

    rc = IrsCntrctInfoGetByPos(pOrderF->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->cntrctNm, IrsCntrctInfo.cntrctName);
    pOrdr->ntnlAmnt = (double)pOrderF->remPkQty;//pOrderF->ordrQty;
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;//pOrderF->remPkQty;
    pOrdr->ordrPrc = (double)pOrderF->ordrExePrc/PRICE_BASE;
    pOrdr->ordrAmnt = 0;//(double)pOrderF->ordrExeQty;
    sprintf( pOrdr->dlDir, "%lld", GET_ORDR_SIDE(pOrderF->ordrMask));//strcpy(pOrdr->dlDir, "NULL");
    
    rc = TransOrdrSts( pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);

    strcpy(pOrdr->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->ordrCrtTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrExpTim, DateTime);
    strcpy(pOrdr->ordrExprdTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    strcpy(pOrdr->ordrActvTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->updTm, DateTime);
    
    strcpy(pOrdr->orgFullNmCn, OrgInfo.orgFullNmCn);
    strcpy(pOrdr->vrtlBrdgOrdrF, "");//sprintf(pOrdr->vrtlBrdgOrdrF, "%u", OrgInfo.brdgOrdrRfrshFlag);
    
    strcpy(pOrdr->orgCd, OrgInfo.orgCd);

    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = MakeApiRqstId(pOrdr->ordrCrtTm, pApiUsr->usrLgnNm, pOrderF->apiRqstId, pOrdr->rqstId);
        RAISE_ERR(rc,RTN);
    }
    
    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 1 );
    DbCmmnSetColBit( datVct, 2 );
    DbCmmnSetColBit( datVct, 3 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );
    DbCmmnSetColBit( datVct, 8 );
    DbCmmnSetColBit( datVct, 9 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 12 );
    DbCmmnSetColBit( datVct, 13 );
    DbCmmnSetColBit( datVct, 14 );
    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 19 );
    DbCmmnSetColBit( datVct, 20 );
    DbCmmnSetColBit( datVct, 21 );
    DbCmmnSetColBit( datVct, 22 );
    DbCmmnSetColBit( datVct, 23 );
    
    rc = UpdateOrdrByKey( gConnId, pOrdr, keyVct, datVct);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   update ordr tems in structure OrdrSirs
 * Parameters:
 *      setId       IN  set Id
 *      pTrade      IN  structure pOrderFT
 *      pOrdr       OUT structure OrdrSirs
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT UpdateOrdrSirsF(pOrderFT  pOrderF, OrdrSirs *pOrdr)
{
    BEGIN_FUNCTION( "UpdateOrdrF" );
    ResCodeT    rc = NO_ERR;
    
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    
    int64           timestamp;
    char            DateTime[MAX_DATETIME_LEN];
    CntrctBaseInfoT IrsCntrctInfo;
    OrgInfoT        OrgInfo;
    char            type[10];
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    pUsrBaseInfoT   pUsr;
    pUsrBaseInfoT   pApiUsr;
    
    memset(pOrdr, 0, sizeof(pOrdr));
    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);
    
    rc = OrgInfoGetByPos(pOrderF->entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pOrderF->userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = IrsUsrInfoGetByPosExt(pOrderF->apiLoginUsrIdx, &pApiUsr);
        RAISE_ERR(rc,RTN);
        
//        sprintf(pOrdr->rqstId, "%lld", pOrderF->apiRqstId);
        strcpy(pOrdr->usrLgnNmApi, pApiUsr->usrLgnNm);
        strcpy(pOrdr->updUsrNm, pApiUsr->usrLgnNm);
    }
    else
    {
        strcpy(pOrdr->updUsrNm, pUsr->usrLgnNm);
        strcpy(pOrdr->rqstId, "");
        strcpy(pOrdr->usrLgnNmApi, "");
    }
    
    pOrdr->orgId = OrgInfo.orgId;
    GetOrderType(pOrderF->ordrMask, type);
    strcpy(pOrdr->ordrSbmtTp, type);
    if (pOrderF->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_OCO);
        sprintf(pOrdr->ocoId, "%s%lld", C_ORD_TYPE_OCO, pOrderF->specOrdrNo);
    }
    else
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_R);
        strcpy(pOrdr->ocoId, "");
    }

    rc = IrsCntrctInfoGetByPos(pOrderF->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->cntrctCd, IrsCntrctInfo.cntrctName);
    pOrdr->ntnlAmnt = (double)pOrderF->remPkQty;//pOrderF->ordrQty;
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;//pOrderF->remPkQty;
    pOrdr->ordrPrc = (double)pOrderF->ordrExePrc/PRICE_BASE;
    pOrdr->ordrAmnt = 0;//(double)pOrderF->ordrExeQty;
    sprintf( pOrdr->dlDir, "%lld", GET_ORDR_SIDE(pOrderF->ordrMask));//strcpy(pOrdr->dlDir, "NULL");
    
    rc = TransOrdrSts( pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);

    strcpy(pOrdr->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->ordrCrtTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrExpTim, DateTime);
    strcpy(pOrdr->ordrExprdTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    strcpy(pOrdr->ordrActvTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->updTm, DateTime);
    
    strcpy(pOrdr->orgFullNmCn, OrgInfo.orgFullNmCn);
    
    strcpy(pOrdr->orgCd, OrgInfo.orgCd);

    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = MakeApiRqstId(pOrdr->ordrCrtTm, pApiUsr->usrLgnNm, pOrderF->apiRqstId, pOrdr->rqstId);
        RAISE_ERR(rc,RTN);
    }
    
    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 1 );
    DbCmmnSetColBit( datVct, 2 );
    DbCmmnSetColBit( datVct, 3 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );
    DbCmmnSetColBit( datVct, 8 );
    DbCmmnSetColBit( datVct, 9 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 12 );
    DbCmmnSetColBit( datVct, 13 );
    DbCmmnSetColBit( datVct, 14 );
    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 19 );
    DbCmmnSetColBit( datVct, 20 );
    DbCmmnSetColBit( datVct, 21 );
    
    rc = UpdateOrdrSirsByKey( gConnId, pOrdr, keyVct, datVct);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   update ordr tems in structure ordr
 * Parameters:
 *      setId       IN  set Id
 *      pTrade      IN  structure pOrderFT
 *      pOrdr       OUT structure Ordr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT UpdateOrdrSbfccpF(pOrderFT  pOrderF, OrdrSbfccp *pOrdr)
{
    BEGIN_FUNCTION( "UpdateOrdrF" );
    ResCodeT    rc = NO_ERR;
    
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    
    int64           timestamp;
    char            DateTime[MAX_DATETIME_LEN];
    CntrctBaseInfoT IrsCntrctInfo;
    OrgInfoT        OrgInfo;
    char            type[10];
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    pUsrBaseInfoT   pUsr;
    pUsrBaseInfoT   pApiUsr;
    
    memset(pOrdr, 0, sizeof(pOrdr));
    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);
    
    rc = OrgInfoGetByPos(pOrderF->entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pOrderF->userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = IrsUsrInfoGetByPosExt(pOrderF->apiLoginUsrIdx, &pApiUsr);
        RAISE_ERR(rc,RTN);
        
//        sprintf(pOrdr->rqstId, "%lld", pOrderF->apiRqstId);
        strcpy(pOrdr->usrLgnNmApi, pApiUsr->usrLgnNm);
        strcpy(pOrdr->updUsrNm, pApiUsr->usrLgnNm);
    }
    else
    {
        strcpy(pOrdr->updUsrNm, pUsr->usrLgnNm);
        strcpy(pOrdr->rqstId, "");
        strcpy(pOrdr->usrLgnNmApi, "");
    }
    
    pOrdr->orgId = OrgInfo.orgId;
    GetOrderType(pOrderF->ordrMask, type);
    strcpy(pOrdr->ordrSbmtTp, type);
    if (pOrderF->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_OCO);
        sprintf(pOrdr->ocoId, "%s%lld", C_ORD_TYPE_OCO, pOrderF->specOrdrNo);
    }
    else
    {
        strcpy(pOrdr->ordrTp, C_ORD_TYPE_R);
        strcpy(pOrdr->ocoId, "");
    }

    rc = IrsCntrctInfoGetByPos(pOrderF->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->cntrctCd, IrsCntrctInfo.cntrctName);
    pOrdr->ntnlAmnt = (double)pOrderF->remPkQty;//pOrderF->ordrQty;
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;//pOrderF->remPkQty;
    pOrdr->ordrPrc = (double)pOrderF->ordrExePrc/PRICE_BASE;
    pOrdr->ordrAmnt = 0;//(double)pOrderF->ordrExeQty;
    sprintf( pOrdr->dlDir, "%lld", GET_ORDR_SIDE(pOrderF->ordrMask));//strcpy(pOrdr->dlDir, "NULL");
    
    rc = TransOrdrSts( pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);

    strcpy(pOrdr->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->ordrCrtTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrExpTim, DateTime);
    strcpy(pOrdr->ordrExprdTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    strcpy(pOrdr->ordrActvTm, DateTime);
    GetStrDateTimeByFormat(pOrderF->ordrEntTim, DateTime);
    strcpy(pOrdr->updTm, DateTime);
    
    strcpy(pOrdr->orgFullNmCn, OrgInfo.orgFullNmCn);
    strcpy(pOrdr->clsPstnCd, "");
    strcpy(pOrdr->orgCd, OrgInfo.orgCd);

    if ( pOrderF->apiLoginUsrIdx != -1 )
    {
        rc = MakeApiRqstId(pOrdr->ordrCrtTm, pApiUsr->usrLgnNm, pOrderF->apiRqstId, pOrdr->rqstId);
        RAISE_ERR(rc,RTN);
    }
    
    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 1 );
    DbCmmnSetColBit( datVct, 2 );
    DbCmmnSetColBit( datVct, 3 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );
    DbCmmnSetColBit( datVct, 8 );
    DbCmmnSetColBit( datVct, 9 );
    DbCmmnSetColBit( datVct, 10 );
    DbCmmnSetColBit( datVct, 11 );
    DbCmmnSetColBit( datVct, 12 );
    DbCmmnSetColBit( datVct, 13 );
    DbCmmnSetColBit( datVct, 14 );
    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 19 );
    DbCmmnSetColBit( datVct, 20 );
    DbCmmnSetColBit( datVct, 21 );
    DbCmmnSetColBit( datVct, 22 );
    
    rc = UpdateOrdrSbfccpByKey( gConnId, pOrdr, keyVct, datVct);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   replace TradBid items in structure Dl
 * Parameters:
 *      setId       IN  set Id
 *      pTrade      IN  structure pTrade
 *      pOrdr       OUT structure pDl
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT ReplaceTradeBid(int32 setId, pTradeT pTrade, Dl *pDl)
{
    BEGIN_FUNCTION( "ReplaceTradeBid" );
    ResCodeT    rc = NO_ERR;

    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    char            DateTime[MAX_DATETIME_LEN];

    uint32          ordrPos = 0;
    pOrderT         pOrder = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;

    UsrBaseInfoT    Usr = {0};
    OrgInfoT        OrgInfo = {0};
    CntrctBaseInfoT IrsCntrctInfo = {0};

    rc = OrdrMgmtNrmlGet( setId, pTrade->ordrNo, 
                            &pOrdrMgmt, &pOrder, &ordrPos );
    RAISE_ERR(rc,RTN);

    rc = OrgInfoGetByPos(pOrder->orderF.entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);

    rc = IrsUsrInfoGetByPos(pOrder->orderF.userIdx, &Usr);
    RAISE_ERR(rc,RTN);
    
    sprintf( pDl->dlId, "%s%lld", C_API_MKTDESC_IRS, pTrade->tranIdNo);
    rc = IrsCntrctInfoGetByPos(pTrade->prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    strcpy(pDl->cntrctNm, IrsCntrctInfo.cntrctName);
    strcpy(pDl->dlTp, "N/A");//pDl->dlTp[0] = pTrade->trdTyp;
    sprintf(pDl->trdngMthd, "%c", C_TRD_TYP_MATCHING);//pDl->trdngMthd[0] = C_TRD_TYP_MATCHING;//pDl->trdngMthd[0] = pTrade->ordrTypCod;
    pDl->fxdIntrstBidOrgId = OrgInfo.orgId;
    
    strcpy(pDl->fxdIntrstBidTrdr, Usr.usrLgnNm);
    strcpy(pDl->fxdIntrstBidTrdrNm, Usr.nmDesc);
    
    sprintf( pDl->fxdIntrstBidOrdrId, "%lld",pTrade->ordrNo);
    pDl->ntnlAmnt = (double)pTrade->ordrExeQty;
    pDl->dlPrc = (double)pTrade->tradMtchPrc/PRICE_BASE;   
    rc = GetStrDateTimeByFormat(pTrade->tranDatTim,DateTime);
    RAISE_ERR(rc,RTN);

    strcpy(pDl->dlDt, DateTime);

    strcpy(pDl->dlTm, DateTime);
    sprintf(pDl->dlSt, "%d", TRD_STS_TRD_LOG);

    strcpy(pDl->crtTm, DateTime);
    //strcpy(pDl->crtUsrNm, Usr.usrLgnNm);

    strcpy(pDl->updTm, DateTime);
    //strcpy(pDl->updUsrNm, Usr.usrLgnNm);
    strcpy(pDl->fxdIntrstBidOrgNmCn, OrgInfo.orgFullNmCn);
    strcpy(pDl->dlDir, "");//pDl->dlDir[8];
    //todo fix this pDl->brdgOrgDlDir[0] = pTrade->ordrResCod;
    pDl->mkrOrgId = OrgInfo.orgId;
    strcpy(pDl->fxdIntrstBidOrgShortNmCn, OrgInfo.orgNmCn);  
    strcpy(pDl->fxdIntrstBidOrgShortNmEn, OrgInfo.orgNmEn);
  
       
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   replace TradAsk items in structure Dl
 * Parameters:
 *      setId       IN  set Id
 *      pTrade      IN  structure pTrade
 *      pOrdr       OUT structure pDl
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT ReplaceTradeAsk(int32 setId, pTradeT pTrade, Dl *pDl)
{
    BEGIN_FUNCTION( "ReplaceTradeAsk" );
    ResCodeT    rc = NO_ERR;
    
    char            date[MAX_DATETIME_LEN];
    char            time[MAX_DATETIME_LEN];
    char            DateTime[MAX_DATETIME_LEN];

    uint32          ordrPos = 0;
    pOrderT         pOrder = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;

    UsrBaseInfoT    Usr = {0};
    OrgInfoT        OrgInfo = {0};
    CntrctBaseInfoT IrsCntrctInfo = {0};

    /* get order info */
    rc = OrdrMgmtNrmlGet( setId, pTrade->ordrNo, 
                            &pOrdrMgmt, &pOrder, &ordrPos );
    RAISE_ERR(rc,RTN);

    rc = OrgInfoGetByPos(pOrder->orderF.entyIdxNo, &OrgInfo);
    RAISE_ERR(rc,RTN);

    rc = IrsUsrInfoGetByPos(pOrder->orderF.userIdx, &Usr);
    RAISE_ERR(rc,RTN);
    
   
    pDl->fxdIntrstOfrOrgId = OrgInfo.orgId;
    strcpy(pDl->fxdIntrstOfrTrdr, Usr.usrLgnNm);
    strcpy(pDl->fxdIntrstOfrTrdrNm, Usr.nmDesc);
    
    sprintf( pDl->fxdIntrstOfrOrdrId, "%lld",pTrade->ordrNo);
    strcpy(pDl->fxdIntrstOfrOrgNmCn, OrgInfo.orgFullNmCn);
    strcpy(pDl->fxdIntrstOfrOrgShortNmCn, OrgInfo.orgNmCn);  
    strcpy(pDl->fxdIntrstOfrOrgShortNmEn, OrgInfo.orgNmEn);

        
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   replace OrdrLog info
 * Parameters:
 *      connId      IN  connection Id
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertOrdrLog( void * pData )
{
    BEGIN_FUNCTION( "InsertOrdrLog" );
    ResCodeT    rc = NO_ERR;
    
    pMLogOrdrT      pLogOrdrAddr;
    Ordr            ordrData;
    OrdrSirs        sirsOrdrData;
    OrdrSbfccp      sbfccpOrdrData;
    BOOL            bExtFlg;
    pPrdctInfoT     pPrdctInfo;
    
    
    pLogOrdrAddr = (pMLogOrdrT)pData;
    rc = PrdctInfoGetByPosExt(pLogOrdrAddr->ordr.prdctId, &pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    if (GET_ACTN_MAINT(pLogOrdrAddr->actnMask) == ACTN_MATCH_MNT)//ACTN_MATCH_MNT
    {
        if( pPrdctInfo->setId == SET_MKT_IRS )
        {
            rc = ReplaceOrdrF(&pLogOrdrAddr->ordr, &ordrData);
            RAISE_ERR(rc,RTN);
        
            sprintf(ordrData.st, "%d", ORD_STS_TRD_LOG);
            
            rc = FetchOrdrByKey( gConnId, ordrData.ordrId, &bExtFlg );
            RAISE_ERR(rc,RTN);
            
            if ( !bExtFlg )
            {
                rc = InsertOrdr(gConnId, &ordrData);
                RAISE_ERR(rc, NO_ERR);
            }
            else
            {
                rc = UpdateOrdrF(&pLogOrdrAddr->ordr, &ordrData);
                RAISE_ERR(rc, NO_ERR);
            }
        }
        else if( pPrdctInfo->setId == SET_MKT_SIRS )
        {
            rc = ReplaceOrdrSirsF(&pLogOrdrAddr->ordr, &sirsOrdrData);
            RAISE_ERR(rc,RTN);
        
            sprintf(sirsOrdrData.st, "%d", ORD_STS_TRD_LOG);
            
            rc = FetchOrdrSirsByKey( gConnId, sirsOrdrData.ordrId, &bExtFlg );//to do, need add this in db.cpp
            RAISE_ERR(rc,RTN);
            
            if ( !bExtFlg )
            {
                rc = InsertOrdrSirs(gConnId, &sirsOrdrData);
                RAISE_ERR(rc, NO_ERR);
            }
            else
            {
                rc = UpdateOrdrSirsF(&pLogOrdrAddr->ordr, &sirsOrdrData);
                RAISE_ERR(rc, NO_ERR);
            }
        }
        else if( pPrdctInfo->setId == SET_MKT_SBFCCP )
        {
            rc = ReplaceOrdrSbfccpF(&pLogOrdrAddr->ordr, &sbfccpOrdrData);
            RAISE_ERR(rc,RTN);
        
            sprintf(sbfccpOrdrData.st, "%d", ORD_STS_TRD_LOG);
            
            rc = FetchOrdrSbfccpByKey( gConnId, sbfccpOrdrData.ordrId, &bExtFlg );//to do, need add this in db.cpp
            RAISE_ERR(rc,RTN);
            
            if ( !bExtFlg )
            {
                rc = InsertOrdrSbfccp(gConnId, &sbfccpOrdrData);
                RAISE_ERR(rc, NO_ERR);
            }
            else
            {
                rc = UpdateOrdrSbfccpF(&pLogOrdrAddr->ordr, &sbfccpOrdrData);
                RAISE_ERR(rc, NO_ERR);
            }
        }
        else
        {
            RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
        }
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   replace OrdrMod info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertOrdMod( void * pData )
{
    BEGIN_FUNCTION( "InsertOrdMod" );
    ResCodeT    rc = NO_ERR;
    
    pMModOrdrT      pModOrdrAddr;
    Ordr            ordrData;
    OrdrSirs        sirsOrdrData;
    OrdrSbfccp      sbfccpOrdrData;
    pPrdctInfoT     pPrdctInfo;

    pModOrdrAddr = (pMModOrdrT)pData;
    rc = PrdctInfoGetByPosExt(pModOrdrAddr->newOrdr.prdctId, &pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    if( pPrdctInfo->setId == SET_MKT_IRS )
    {
        if (pModOrdrAddr->newOrdr.ordrSts == ORDR_STS_FREEZE)
        {
            rc = UpdateOrdrF(&pModOrdrAddr->newOrdr, &ordrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else if (pModOrdrAddr->newOrdr.ordrSts == ORDR_STS_CANCEL)
        {
            rc = UpdateOrdrF(&pModOrdrAddr->newOrdr, &ordrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else
        {
            rc = UpdateOrdrF(&pModOrdrAddr->newOrdr, &ordrData);
            RAISE_ERR(rc, NO_ERR);
        }
    }
    else if( pPrdctInfo->setId == SET_MKT_SIRS )
    {
        if (pModOrdrAddr->newOrdr.ordrSts == ORDR_STS_FREEZE)
        {
            rc = UpdateOrdrSirsF(&pModOrdrAddr->newOrdr, &sirsOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else if (pModOrdrAddr->newOrdr.ordrSts == ORDR_STS_CANCEL)
        {
            rc = UpdateOrdrSirsF(&pModOrdrAddr->newOrdr, &sirsOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else
        {
            rc = UpdateOrdrSirsF(&pModOrdrAddr->newOrdr, &sirsOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
    }
    else if( pPrdctInfo->setId == SET_MKT_SBFCCP)
    {
        if (pModOrdrAddr->newOrdr.ordrSts == ORDR_STS_FREEZE)
        {
            rc = UpdateOrdrSbfccpF(&pModOrdrAddr->newOrdr, &sbfccpOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else if (pModOrdrAddr->newOrdr.ordrSts == ORDR_STS_CANCEL)
        {
            rc = UpdateOrdrSbfccpF(&pModOrdrAddr->newOrdr, &sbfccpOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else
        {
            rc = UpdateOrdrSbfccpF(&pModOrdrAddr->newOrdr, &sbfccpOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   replace OrdrAdd info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertOrdAdd( void * pData )
{
    BEGIN_FUNCTION( "InsertOrdAdd" );
    ResCodeT    rc = NO_ERR;
    
    pMAddOrdrT      pAddOrdrAddr;
    Ordr            ordrData;
    OrdrSirs        sirsOrdrData;
    OrdrSbfccp      sbfccpOrdrData;
    BOOL            bExtFlg;
    pPrdctInfoT     pPrdctInfo;
    
    
    pAddOrdrAddr = (pMAddOrdrT)pData;
    rc = PrdctInfoGetByPosExt(pAddOrdrAddr->ordr.prdctId, &pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    if( pPrdctInfo->setId == SET_MKT_IRS )
    {
        rc = ReplaceOrdrF(&pAddOrdrAddr->ordr, &ordrData);
        RAISE_ERR(rc,RTN);
        
        sprintf(ordrData.st, "%d", ORD_STS_ORD_ADD);
        
        rc = FetchOrdrByKey( gConnId, ordrData.ordrId, &bExtFlg );
        RAISE_ERR(rc,RTN);
        
        if ( !bExtFlg )
        {
            rc = InsertOrdr(gConnId, &ordrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else
        {
            rc = UpdateOrdrF(&pAddOrdrAddr->ordr, &ordrData);
            RAISE_ERR(rc, NO_ERR);
        }
    }
    else if( pPrdctInfo->setId == SET_MKT_SIRS )
    {
        rc = ReplaceOrdrSirsF(&pAddOrdrAddr->ordr, &sirsOrdrData);
        RAISE_ERR(rc,RTN);
        
        sprintf(sirsOrdrData.st, "%d", ORD_STS_ORD_ADD);
        
        rc = FetchOrdrSirsByKey( gConnId, sirsOrdrData.ordrId, &bExtFlg );//to do, need add this in db.cpp
        RAISE_ERR(rc,RTN);
        
        if ( !bExtFlg )
        {
            rc = InsertOrdrSirs(gConnId, &sirsOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else
        {
            rc = UpdateOrdrSirsF(&pAddOrdrAddr->ordr, &sirsOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
    }
    else if( pPrdctInfo->setId == SET_MKT_SBFCCP )
    {
        rc = ReplaceOrdrSbfccpF(&pAddOrdrAddr->ordr, &sbfccpOrdrData);
        RAISE_ERR(rc,RTN);
        
        sprintf(sbfccpOrdrData.st, "%d", ORD_STS_ORD_ADD);
        
        rc = FetchOrdrSbfccpByKey( gConnId, sbfccpOrdrData.ordrId, &bExtFlg );//to do, need add this in db.cpp
        RAISE_ERR(rc,RTN);
        
        if ( !bExtFlg )
        {
            rc = InsertOrdrSbfccp(gConnId, &sbfccpOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
        else
        {
            rc = UpdateOrdrSbfccpF(&pAddOrdrAddr->ordr, &sbfccpOrdrData);
            RAISE_ERR(rc, NO_ERR);
        }
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   delete ordr
 * Parameters:
 *      pOrderF     IN  pOrderFT
 *      pOrdr       OUT Ordr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to updt
 ******************************************************************************/
ResCodeT DelOrdr( pOrderFT  pOrderF, Ordr *pOrdr )
{
    BEGIN_FUNCTION( "DelOrdr" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    
    memset(pOrdr, 0, sizeof(pOrdr));
    
    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);

    rc = TransOrdrSts( pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);
    
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;

    /* If order status is FREEZE or CANCLE, remove active time */
    if ( pOrderF->ordrSts == ORDR_STS_CANCEL ||
            pOrderF->ordrSts == ORDR_STS_FREEZE )
    {
        rc = UpdateCancleOrdr( gConnId, pOrdr );
        RAISE_ERR(rc,RTN);
    }
    else
    {
        DbCmmnSetColBit( keyVct, 0 );
        DbCmmnSetColBit( datVct, 7 );
        DbCmmnSetColBit( datVct, 11 );

        rc = UpdateOrdrByKey( gConnId, pOrdr, keyVct, datVct);
        RAISE_ERR(rc,RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   delete OrdrSirs
 * Parameters:
 *      pOrderF     IN  pOrderFT
 *      pOrdr       OUT OrdrSirs
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to updt
 ******************************************************************************/
ResCodeT DelOrdrSirs( pOrderFT  pOrderF, OrdrSirs *pOrdr )
{
    BEGIN_FUNCTION( "DelOrdrSirs" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    
    memset(pOrdr, 0, sizeof(pOrdr));
    
    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);

    rc = TransOrdrSts( pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);
    
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;

    /* If order status is FREEZE or CANCLE, remove active time */
    if ( pOrderF->ordrSts == ORDR_STS_CANCEL ||
            pOrderF->ordrSts == ORDR_STS_FREEZE )
    {
        rc = UpdateCancleOrdrSirs( gConnId, pOrdr );
        RAISE_ERR(rc,RTN);
    }
    else
    {
        DbCmmnSetColBit( keyVct, 0 );
        DbCmmnSetColBit( datVct, 7 );
        DbCmmnSetColBit( datVct, 11 );

        rc = UpdateOrdrSirsByKey( gConnId, pOrdr, keyVct, datVct);
        RAISE_ERR(rc,RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   delete OrdrSbfccp
 * Parameters:
 *      pOrderF     IN  pOrderFT
 *      pOrdr       OUT OrdrSbfccp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to updt
 ******************************************************************************/
ResCodeT DelOrdrSbfccp( pOrderFT  pOrderF, OrdrSbfccp *pOrdr )
{
    BEGIN_FUNCTION( "DelOrdrSbfccp" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    memset(pOrdr, 0, sizeof(pOrdr));
    
    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);

    rc = TransOrdrSts( pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);
    
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;

    /* If order status is FREEZE or CANCLE, remove active time */
    if ( pOrderF->ordrSts == ORDR_STS_CANCEL ||
            pOrderF->ordrSts == ORDR_STS_FREEZE )
    {
        rc = UpdateCancleOrdrSbfccp( gConnId, pOrdr );
        RAISE_ERR(rc,RTN);
    }
    else
    {
        DbCmmnSetColBit( keyVct, 0 );
        DbCmmnSetColBit( datVct, 7 );
        DbCmmnSetColBit( datVct, 11 );

        rc = UpdateOrdrSbfccpByKey( gConnId, pOrdr, keyVct, datVct);
        RAISE_ERR(rc,RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   replace OrdrDel info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertOrdDel( void * pData)
{
    BEGIN_FUNCTION( "InsertOrdDel" );
    ResCodeT    rc = NO_ERR;
    
    pMDelOrdrT      pDelOrdAddr;
    Ordr            ordrData;
    OrdrSirs        sirsOrdrData;
    OrdrSbfccp      sbfccpOrdrData;
    BOOL            bExtFlg;
    pPrdctInfoT     pPrdctInfo;
    
    pDelOrdAddr = (pMDelOrdrT)pData;
    
    rc = PrdctInfoGetByPosExt(pDelOrdAddr->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    if( pPrdctInfo->setId == SET_MKT_IRS )
    {
        memset(&ordrData, 0, sizeof(ordrData));
        
        rc = DelOrdr(&pDelOrdAddr->orderF, &ordrData);
        RAISE_ERR(rc,RTN);
    }
    else if( pPrdctInfo->setId == SET_MKT_SIRS )
    {
        memset(&sirsOrdrData, 0, sizeof(sirsOrdrData));
        
        rc = DelOrdrSirs(&pDelOrdAddr->orderF, &sirsOrdrData);
        RAISE_ERR(rc,RTN);
    }
    else if( pPrdctInfo->setId == SET_MKT_SBFCCP )
    {
        memset(&sirsOrdrData, 0, sizeof(sbfccpOrdrData));
        
        rc = DelOrdrSbfccp(&pDelOrdAddr->orderF, &sbfccpOrdrData);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   replace TrdLog info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertTrdLog(int32 setId, void * pData)
{
    BEGIN_FUNCTION( "InsertTrdLog" );
    ResCodeT    rc = NO_ERR;
    
    pMLogTrdT       pLogTrdAddr;
    Dl              dlData;
    pOrdrMgmtRcrdT  pOrdrMgmt;
    uint32          ordrPos;
    pOrderT         pOrder = NULL;
    UsrBaseInfoT    Usr = {0};

    pLogTrdAddr = (pMLogTrdT)pData;

    rc = OrdrMgmtNrmlGet( setId, pLogTrdAddr->trade.ordrNo, 
                            &pOrdrMgmt, &pOrder, &ordrPos );
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPos(pOrder->orderF.userIdx, &Usr);
    RAISE_ERR(rc,RTN);

    if (GET_ORDR_SIDE(pOrder->orderF.ordrMask) == ORDR_SIDE_BUY)
    {
        pLogTrdAddr = (pMLogTrdT)pData;
        rc = ReplaceTradeBid(setId, &pLogTrdAddr->trade, &dlData);
        RAISE_ERR(rc,RTN);
        
        strcpy(dlData.crtUsrNm, Usr.usrLgnNm);
        strcpy(dlData.updUsrNm, Usr.usrLgnNm);

        pData = (pMLogTrdT)ADDRESS_ADD_OFFSET(pData, sizeof(MLogTrdT));

        pLogTrdAddr = (pMLogTrdT)pData;
        rc = ReplaceTradeAsk(setId, &pLogTrdAddr->trade, &dlData);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        pLogTrdAddr = (pMLogTrdT)pData;
        rc = ReplaceTradeAsk(setId, &pLogTrdAddr->trade, &dlData);
        RAISE_ERR(rc,RTN);
        
        strcpy(dlData.crtUsrNm, Usr.usrLgnNm);
        strcpy(dlData.updUsrNm, Usr.usrLgnNm);

        pData = (pMLogTrdT)ADDRESS_ADD_OFFSET(pData, sizeof(MLogTrdT));

        pLogTrdAddr = (pMLogTrdT)pData;
        rc = ReplaceTradeBid(setId, &pLogTrdAddr->trade, &dlData);
        RAISE_ERR(rc,RTN);
    }

    rc = InsertDl(gConnId, &dlData);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}





/******************************************************************************
 * Description:   replace ModQty info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT OrdrQtyMod(pOrderFT  pOrderF, Ordr *pOrdr)
{
    BEGIN_FUNCTION( "InsertOrdModQty" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(28)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(28)] = {0};
    
    memset(pOrdr, 0, sizeof(pOrdr));

    sprintf( pOrdr->ordrId, "%lld", pOrderF->ordrNo);
    
    pOrdr->rmngNtnlAmnt = (double)pOrderF->ordrQty;
    
    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 7 );
    
    rc = UpdateOrdrByKey( gConnId, pOrdr, keyVct, datVct);
    RAISE_ERR(rc,RTN)
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   replace ModQty info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertOrdModQty(void * pData)
{
    BEGIN_FUNCTION( "InsertOrdModQty" );
    ResCodeT    rc = NO_ERR;
    
    pMModOrdQtyT    pModOrdQtyAddr;
    Ordr            ordrData;
    OrdrSirs        sirsOrdrData;
    OrdrSbfccp      sbfccpOrdrData;
    pPrdctInfoT     pPrdctInfo;
    
    memset(&ordrData, 0, sizeof(ordrData));
    pModOrdQtyAddr = (pMModOrdQtyT)pData;
    
    rc = PrdctInfoGetByPosExt(pModOrdQtyAddr->oldOrdr.prdctId, &pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    if( pPrdctInfo->setId == SET_MKT_IRS )
    {
        rc = OrdrQtyMod( &pModOrdQtyAddr->oldOrdr, &ordrData);
        RAISE_ERR(rc,RTN);
    }
    else if( pPrdctInfo->setId == SET_MKT_SIRS )
    {
        
        //RAISE_ERR(rc,RTN);
    }
    else if( pPrdctInfo->setId == SET_MKT_SBFCCP )
    {
        
        //RAISE_ERR(rc,RTN);
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   save ordr
 * Parameters:
 *      pOrderFT    IN  orderF
 *      Ordr        OUT ordr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT SaveOrdr( pOrderFT  pOrderF, Ordr *pOrdr )
{
    BEGIN_FUNCTION( "SaveOrdr" );
    ResCodeT    rc = NO_ERR;
    
    BOOL            bExtFlg;
    char            DateTime[MAX_DATETIME_LEN];
    
    rc = ReplaceOrdrF(pOrderF, pOrdr);
    RAISE_ERR(rc,RTN);
    
    sprintf(pOrdr->st, "%d", ORD_STS_ORD_ST);
    rc = GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->ordrActvTm, DateTime);

    rc = TransOrdrSts(pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);

    rc = FetchOrdrByKey( gConnId, pOrdr->ordrId, &bExtFlg );
    RAISE_ERR(rc,RTN);

    if ( !bExtFlg )
    {
        rc = InsertOrdr(gConnId, pOrdr);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        rc = UpdateOrdrF(pOrderF, pOrdr);
        RAISE_ERR(rc, NO_ERR);
    }

    rc = UpdateCancleOrdr( gConnId, pOrdr );
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   save ordrSirs
 * Parameters:
 *      pOrderFT    IN  orderF
 *      Ordr        OUT ordr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT SaveOrdrSirs( pOrderFT  pOrderF, OrdrSirs *pOrdr )
{
    BEGIN_FUNCTION( "SaveOrdrSirs" );
    ResCodeT    rc = NO_ERR;
    
    BOOL            bExtFlg;
    char            DateTime[MAX_DATETIME_LEN];
    
    rc = ReplaceOrdrSirsF(pOrderF, pOrdr);
    RAISE_ERR(rc,RTN);
    
    sprintf(pOrdr->st, "%d", ORD_STS_ORD_ST);
    rc = GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    RAISE_ERR(rc,RTN);
    
    strcpy(pOrdr->ordrActvTm, DateTime);

    rc = TransOrdrSts(pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);

    rc = FetchOrdrSirsByKey( gConnId, pOrdr->ordrId, &bExtFlg );
    RAISE_ERR(rc,RTN);

    if ( !bExtFlg )
    {
        rc = InsertOrdrSirs(gConnId, pOrdr);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        rc = UpdateOrdrSirsF(pOrderF, pOrdr);
        RAISE_ERR(rc, NO_ERR);
    }

    rc = UpdateCancleOrdrSirs( gConnId, pOrdr );
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   save ordrSirs
 * Parameters:
 *      pOrderFT    IN  orderF
 *      Ordr        OUT ordr
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT SaveOrdrSbfccp( pOrderFT  pOrderF, OrdrSbfccp *pOrdr )
{
    BEGIN_FUNCTION( "SaveOrdrSbfccp" );
    ResCodeT    rc = NO_ERR;
    
    BOOL            bExtFlg;
    char            DateTime[MAX_DATETIME_LEN];
    
    rc = ReplaceOrdrSbfccpF(pOrderF, pOrdr);
    RAISE_ERR(rc,RTN);
    
    sprintf(pOrdr->st, "%d", ORD_STS_ORD_ST);
    rc = GetStrDateTimeByFormat(pOrderF->tranTime, DateTime);
    RAISE_ERR(rc,RTN);
    strcpy(pOrdr->ordrActvTm, DateTime);

    rc = TransOrdrSts(pOrderF->ordrSts, pOrdr->st );
    RAISE_ERR(rc,RTN);

    rc = FetchOrdrSbfccpByKey( gConnId, pOrdr->ordrId, &bExtFlg );
    RAISE_ERR(rc,RTN);

    if ( !bExtFlg )
    {
        rc = InsertOrdrSbfccp(gConnId, pOrdr);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        rc = UpdateOrdrSbfccpF(pOrderF, pOrdr);
        RAISE_ERR(rc, NO_ERR);
    }

    rc = UpdateCancleOrdrSbfccp( gConnId, pOrdr );
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   replace OrdrSave info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertOrdSave(void * pData)
{
    BEGIN_FUNCTION( "InsertOrdSave" );
    ResCodeT    rc = NO_ERR;
    
    pMSaveOrdrT pSaveOrdrAddr;
    Ordr            ordrData;
    OrdrSirs        sirsOrdrData;
    OrdrSbfccp      sbfccpOrdrData;
    BOOL            bExtFlg;
    char            DateTime[MAX_DATETIME_LEN];
    pPrdctInfoT     pPrdctInfo;
    
    pSaveOrdrAddr = (pMSaveOrdrT)pData;
    rc = PrdctInfoGetByPosExt(pSaveOrdrAddr->ordrF.prdctId, &pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    if( pPrdctInfo->setId == SET_MKT_IRS )
    {
        rc = SaveOrdr( &pSaveOrdrAddr->ordrF, &ordrData );
        RAISE_ERR(rc,RTN);
    }
    else if( pPrdctInfo->setId == SET_MKT_SIRS )
    {
        rc = SaveOrdrSirs( &pSaveOrdrAddr->ordrF, &sirsOrdrData );
        RAISE_ERR(rc,RTN);
    }
    else if( pPrdctInfo->setId == SET_MKT_SBFCCP )
    {
        rc = SaveOrdrSbfccp( &pSaveOrdrAddr->ordrF, &sbfccpOrdrData );
        RAISE_ERR(rc,RTN);
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
    }

    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   replace BilOrdrSave info
 * Parameters:
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to replace
 ******************************************************************************/
ResCodeT InsertBilOrdSave(void * pData)
{
    BEGIN_FUNCTION( "InsertBilOrdSave" );
    ResCodeT    rc = NO_ERR;
    
    pMSaveBilOrdrT  pSaveBilOrdrAddr;
    Ordr            ordrDataBid;
    Ordr            ordrDataAsk;
    char            DateTime[MAX_DATETIME_LEN];
    BOOL            bExtFlg = FALSE;
    
    /* ordr bid */
    pSaveBilOrdrAddr = (pMSaveBilOrdrT)pData;
    rc = ReplaceOrdrF(&pSaveBilOrdrAddr->bidOrdrF, &ordrDataBid);
    RAISE_ERR(rc,RTN);
    
    sprintf(ordrDataBid.st, "%d", ORD_STS_ORD_ST);
    rc = GetStrDateTimeByFormat(pSaveBilOrdrAddr->bidOrdrF.tranTime, DateTime);
    RAISE_ERR(rc,RTN);
    strcpy(ordrDataBid.ordrActvTm, DateTime);

    rc = FetchOrdrByKey( gConnId, ordrDataBid.ordrId, &bExtFlg );
    RAISE_ERR(rc,RTN);

    if ( !bExtFlg )
    {
        rc = InsertOrdr(gConnId, &ordrDataBid);
        RAISE_ERR(rc, NO_ERR);
    }
    else
    {
        rc = UpdateOrdrF(&pSaveBilOrdrAddr->bidOrdrF, &ordrDataBid);
        RAISE_ERR(rc, NO_ERR);
    }

    rc = UpdateCancleOrdr( gConnId, &ordrDataBid );
    RAISE_ERR(rc,RTN);
    
    /* ordr ask */
    rc = ReplaceOrdrF(&pSaveBilOrdrAddr->askOrdrF, &ordrDataAsk);
    RAISE_ERR(rc,RTN);
    
    sprintf(ordrDataAsk.st, "%d", ORD_STS_ORD_ST);
    strcpy(ordrDataAsk.ordrActvTm, DateTime);

    rc = FetchOrdrByKey( gConnId, ordrDataAsk.ordrId, &bExtFlg );
    RAISE_ERR(rc,RTN);

    if ( !bExtFlg )
    {
        rc = InsertOrdr(gConnId, &ordrDataAsk);
        RAISE_ERR(rc, NO_ERR);
    }
    else
    {
        rc = UpdateOrdrF(&pSaveBilOrdrAddr->askOrdrF, &ordrDataAsk);
        RAISE_ERR(rc, NO_ERR);
    }

    rc = UpdateCancleOrdr( gConnId, &ordrDataAsk );
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT CrdtUpdateByTrd(void * pData)
{
    BEGIN_FUNCTION( "CrdtUpdateByTrd" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(15)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(15)] = {0};
    pMUpdtCrdtByTrdT    pUpdtCrdtByTrdAdrr;
    Crdt                crdtData = {0};

    pOrgInfoT     pIncOrgInfo = NULL;
    pOrgInfoT     pBstOrgInfo = NULL;
    
    pUpdtCrdtByTrdAdrr = (pMUpdtCrdtByTrdT)pData;

    rc = OrgInfoGetByPosExt( pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incEntyIdPos, &pIncOrgInfo );
    RAISE_ERR(rc,RTN);

    rc = OrgInfoGetByPosExt( pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstEntyIdPos, &pBstOrgInfo );
    RAISE_ERR(rc,RTN);

    /* update income order credit info */
    memset(&crdtData, 0, sizeof(crdtData));
    crdtData.crdtOrgId = pIncOrgInfo->orgId;
    crdtData.crdtdOrgId = pBstOrgInfo->orgId;
    crdtData.usedCrdtAmnt = pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incUsedQty / AMNT_BASE;
    crdtData.rmnCrdtAmnt = pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incRmntQty / AMNT_BASE;
    
    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( keyVct, 2 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );
    
    rc = UpdateCrdtByKey(gConnId, &crdtData, keyVct, datVct);
    RAISE_ERR(rc,RTN);

    /* update best order credit info */
    crdtData.crdtOrgId = pBstOrgInfo->orgId;
    crdtData.crdtdOrgId = pIncOrgInfo->orgId;
    crdtData.usedCrdtAmnt = pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstUsedQty / AMNT_BASE;
    crdtData.rmnCrdtAmnt = pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstRmntQty / AMNT_BASE;
    
    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( keyVct, 2 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );
    
    rc = UpdateCrdtByKey(gConnId, &crdtData, keyVct, datVct);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOcoOrdr(pMLogOcoOrdrT pMLogOcoOrdrAddr, OcoOrdr *pOcoOrdrData)
{
    BEGIN_FUNCTION( "UpdateOcoOrdr" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(9)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(9)] = {0};
    
    pOrdrMgmtRcrdT  pOcoOrdrMgmt;
    pOrderT         pNmrlOrder;
    int64           iter;
    pUsrBaseInfoT   pUsr;
    char            DateTime[MAX_DATETIME_LEN];
    
    rc = OrdrMgmtOcoGet(gSetId, pMLogOcoOrdrAddr->specOrdrNo, &pOcoOrdrMgmt, &pNmrlOrder, &iter);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pNmrlOrder->orderF.userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    sprintf(pOcoOrdrData->ocoId, "%s%lld", C_ORD_TYPE_OCO, pMLogOcoOrdrAddr->specOrdrNo);
    if (pMLogOcoOrdrAddr->ordrSts == ORDR_STS_ACTIVE)
    {
        strcpy(pOcoOrdrData->st, "2");
    }
    else
    {
        strcpy(pOcoOrdrData->st, "1");
    }
    strcpy( pOcoOrdrData->trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pNmrlOrder->orderF.ordrEntTim, DateTime);
    strcpy( pOcoOrdrData->crtTm, DateTime);
    strcpy( pOcoOrdrData->crtUsrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pNmrlOrder->orderF.ordrEntTim, DateTime);
    strcpy( pOcoOrdrData->updTm, DateTime);
    strcpy( pOcoOrdrData->updUsrNm, pUsr->usrLgnNm);
    
    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 1 );
    DbCmmnSetColBit( datVct, 2 );
    DbCmmnSetColBit( datVct, 3 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 5 );
    DbCmmnSetColBit( datVct, 6 );
    DbCmmnSetColBit( datVct, 7 );
    
    rc = UpdateOcoOrdrByKey( gConnId, pOcoOrdrData, keyVct, datVct );
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT InsertLogOco( void * pData )
{
    BEGIN_FUNCTION( "InsertLogOco" );
    ResCodeT    rc = NO_ERR;
    
    pMLogOcoOrdrT   pMLogOcoOrdrAddr;
    OcoOrdr         OcoOrdrData = {0};
    pOrdrMgmtRcrdT  pOcoOrdrMgmt;
    pOrderT         pNmrlOrder;
    int64           iter;
    pUsrBaseInfoT   pUsr;
    char            DateTime[MAX_DATETIME_LEN];
    BOOL            bExtFlg;
    
    pMLogOcoOrdrAddr = (pMLogOcoOrdrT)pData;
    
    rc = OrdrMgmtOcoGet(gSetId, pMLogOcoOrdrAddr->specOrdrNo, &pOcoOrdrMgmt, &pNmrlOrder, &iter);
    RAISE_ERR(rc,RTN);
    rc = IrsUsrInfoGetByPosExt(pNmrlOrder->orderF.userIdx, &pUsr);
    RAISE_ERR(rc,RTN);
    
    sprintf(OcoOrdrData.ocoId, "%s%lld", C_ORD_TYPE_OCO, pMLogOcoOrdrAddr->specOrdrNo);
    if (pMLogOcoOrdrAddr->ordrSts == ORDR_STS_ACTIVE)
    {
        strcpy(OcoOrdrData.st, "2");
    }
    else
    {
        strcpy(OcoOrdrData.st, "1");
    }
    strcpy( OcoOrdrData.trdrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pNmrlOrder->orderF.ordrEntTim, DateTime);
    strcpy(OcoOrdrData.crtTm, DateTime);
    strcpy( OcoOrdrData.crtUsrNm, pUsr->usrLgnNm);
    GetStrDateTimeByFormat(pNmrlOrder->orderF.ordrEntTim, DateTime);
    strcpy(OcoOrdrData.updTm, DateTime);
    strcpy( OcoOrdrData.updUsrNm, pUsr->usrLgnNm);
    
    rc = FetchOcoOrdrByKey( gConnId, OcoOrdrData.ocoId, &bExtFlg );
    RAISE_ERR(rc,RTN);
    
    if ( !bExtFlg )
    {
        rc = InsertOcoOrdr(gConnId, &OcoOrdrData);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        rc = UpdateOcoOrdr(pMLogOcoOrdrAddr, &OcoOrdrData);
        RAISE_ERR(rc, NO_ERR);
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Insert items in structure to database
 * Parameters:
 *      setId       IN  set Id
 *      elemType    IN  element type
 *      pData       IN  data in stracture
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT InsertElems(int32 setId, MTElemTypeT elemType, void * pData)
{
    BEGIN_FUNCTION( "InsertElems" );
    ResCodeT    rc = NO_ERR;
    
    void                * pDataIn;
    pMRefDatUpdtT    pMRefDatUpdtAddr;
    
    switch (elemType)
    {
        case MT_TYP_ODR_LOG:
            rc = InsertOrdrLog(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_ODR_ADD:
            rc = InsertOrdAdd(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_ORD_DEL:
            rc = InsertOrdDel(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_TRD_LOG:
            rc = InsertTrdLog(setId, pData); 
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_ODR_MOD:
            rc = InsertOrdMod(pData); 
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_ORD_MOD_QTY:
            rc = InsertOrdModQty(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_ORD_SAVE:
            rc = InsertOrdSave(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_BIL_ORD_SAVE:
            rc = InsertBilOrdSave(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_REF_DAT_UPT:
            pMRefDatUpdtAddr = (pMRefDatUpdtT)pData;
            pDataIn = (void*)ADDRESS_ADD_OFFSET(pData, sizeof(MRefDatUpdtT));
            rc = RefDatDbUpdtCmmn(gConnId, pMRefDatUpdtAddr->updtType, pDataIn, pMRefDatUpdtAddr->dataLen);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_CRDT_UPDT_BY_TRD:
            rc = CrdtUpdateByTrd(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_MKT_DAT_PUSH:
            break;
        case MT_TYP_LOG_OCO:
            rc = InsertLogOco(pData);
            RAISE_ERR(rc,RTN);
            break;
        case MT_TYP_FLUSH_MKT:
            break;
        case MT_TYP_PRDCT_INFO_UPDT:
            break;
        case MT_TYP_BRDG_MKT_DAT_PUSH:
            break;
        case MT_TYP_BRDG_ORD_UPDT:
            break;
        default:
            TRACE("Unknow txn code: %d" $$ elemType);
            break;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Insert data from memtxn to database
 * Parameters:
 *      setId       IN  set Id
 *      fromTxnId   IN  start txn Id
 *      toTxnId     IN  end txn Id
 *      pTxnId      OUT end Txn Id
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert
 ******************************************************************************/
ResCodeT DumpOrdrFromMemTxn(int32 setId, int64 fromTxnId, int64 toTxnId, int32 *pTxnId)
{
    BEGIN_FUNCTION( "DumpOrdrFromMemTxn" );
    ResCodeT    rc = NO_ERR;
    ResCodeT    rtnCode = NO_ERR;
    
    MTElemTypeT  elemType;
    void       * pData;
    int32        dataLen;
    CfgValueT    cfgValue;
    int32        currTxnId;  
    
    currTxnId = fromTxnId;
   
    rc = MemTxnIterElem(setId, fromTxnId, toTxnId, &elemType, &pData, &dataLen);
    RAISE_ERR(rc,RTN);

    rc = InsertElems(setId, elemType, pData);
    RAISE_ERR(rc,RTN);

    

    while (1)
    {
        rc = MemTxnIterElemNext(setId, &currTxnId, &elemType, &pData, &dataLen);
        if (rc == ERR_MEM_TXN_ITER_DATA_END)
        {
            break;
        }
        RAISE_ERR(rc,RTN);   

        /* update db according to what we get from memtxn */
        rc = InsertElems(setId, elemType, pData);
        RAISE_ERR(rc,RTN);
    }

    *pTxnId = currTxnId;


    EXIT_BLOCK();

    /* No matter insert success or not, commit what we have done */
    {
        gCurrDumpTxnId = currTxnId;

        rc = UpdateTxnDumpPrcsTxnIdtbl( );
        RAISE_ERR(rc,RTN);
    }

    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   update dumped number into RPLY table in database
 * Parameters:
 *      NONE
 * Return Value:
 *      NO_ERR  - successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT UpdateTxnDumpPrcsTxnIdtbl( )
{
    BEGIN_FUNCTION( "UpdateTxnDumpPrcsTxnIdtbl" );
    ResCodeT    rc = NO_ERR;
    
    vectorT  keyVct[GET_BIT_VECT_LEN(2)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(2)] = {0};
    
    PrcsTxnIdtbl        prcsTxnIdtblData = {0};


    prcsTxnIdtblData.setId = gSetId;
    
    DbCmmnSetColBit( keyVct, 0 );
    
    prcsTxnIdtblData.keyValue = gCurrDumpTxnId;
    
    DbCmmnSetColBit( datVct, 1 );

    rc = UpdatePrcsTxnIdtblByKey( gConnId, &prcsTxnIdtblData, keyVct, datVct);
    RAISE_ERR(rc,RTN);

    rc = DbCmmnCommit( gConnId );
    RAISE_ERR(rc, NO_ERR);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   dump order info and trade info to data base
 * Parameters:
 *      pRunFlag        IN run flag
 * Return Value:
 *      NO_ERR  successful.
 *      ERR_<DSCR>      error happens.
 *****************************************************************************/
void * MatchingDumptxnThread( void *pRunFlag )
{
    BEGIN_FUNCTION( "MatchingDumptxnThread" );

    ResCodeT    rc = NO_ERR;

    int32           txnId = 0;
    int32 *         pRunMark;

    int64           tmpTxnId = DUMP_RETRY_MAX_TXNID;
    int32           retryTimes = DUMP_RETRY_MAX_TIMES;

    MemTxnCtrlT     TxnCtrl = {0};
    MemTxnEntryT    TxnEntry = {0};

    pRunMark = (int32 *)pRunFlag;

    rc = MonThreadReg(MON_THREAD_DUMP_TYP);
    RAISE_ERR(rc, NO_ERR);

    while ( *pRunMark == MEM_TXN_DUMP_TO_DB_RUN )
    {
        rc = MemTxnGetTxnInfo( gSetId, gCurrDumpTxnId, &TxnCtrl, &TxnEntry );
        if (rc != NO_ERR)
        {
            LOG_INFO("get mem txn info falied errcode =  %lld", rc);
        }

        if ( OK(rc) && TxnCtrl.commitTxnId > gCurrDumpTxnId )
        {
            rc = DumpOrdrFromMemTxn( gSetId, gCurrDumpTxnId + 1, 
                                    TxnCtrl.commitTxnId, &txnId );
            if (rc != NO_ERR)
            {
                LOG_ERROR(rc, "Dump memtxn [%d] falied, errcode = %lld", txnId, rc);
            }
        }

        if ( retryTimes && NOTOK(rc) )
        {
            LOG_ERROR(rc," Retry Dump memtxn [%d] failed, errcode = %lld", txnId, rc);

            tmpTxnId = gCurrDumpTxnId;

            /* Back 1, to retry the wrong memtxn */
            gCurrDumpTxnId--;
            retryTimes--;
        }
        else if ( !retryTimes && NOTOK(rc) )
        {
            LOG_ERROR(rc, "Dump memtxn [%d] failed, exit DUMP THREAD!", txnId );
            *pRunMark == MEM_TXN_DUMP_TO_DB_END;
            return NULL;
        }
        else if ( tmpTxnId < gCurrDumpTxnId )
        {
            LOG_INFO( "Retry works, dump memtxn [%d] OK!", tmpTxnId );

            tmpTxnId = DUMP_RETRY_MAX_TXNID;
            retryTimes = DUMP_RETRY_MAX_TIMES;
        }

        usleep(100000);
    }


    EXIT_BLOCK();
    MonThreadSetState(MON_THREAD_DUMP_TYP, THREAD_EXIT);

    return NULL;
}
