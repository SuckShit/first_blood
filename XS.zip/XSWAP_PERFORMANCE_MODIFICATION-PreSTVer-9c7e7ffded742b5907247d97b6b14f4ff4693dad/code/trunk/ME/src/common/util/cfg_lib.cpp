﻿/***
Created on June 13, 2017
@author: No One
@version $Id
***/
#ifndef _CFG_LIB_
#define _CFG_LIB_

/*****************************************************************************
**
**  Header File
**
*****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

#include "../include/data_type.h"
#include "../include/err_lib.h"
#include "../include/cfg_lib.h"
#include "../include/common_macro.h"
#include "../include/uti_tool.h"
#include "UTILITY/logfile.h"
#include "Utils.h"
#include "UTILITY/ConfigFile.h"


/*****************************************************************************
**
** Type Defination
**
*****************************************************************************/

/*****************************************************************************
**
** Macro
**
*****************************************************************************/

/******************************************************************************
**
**  Type Defination
**
******************************************************************************/



/******************************************************************************
**
**  Global Variable
**
******************************************************************************/
static ConfigFile gCfgFile;
static CfgValueT gCfgValue;
/******************************************************************************
**
**  Type Defination
**
******************************************************************************/

/******************************************************************************
**
** Function Implementation
**
******************************************************************************/
ResCodeT GetStrCfgValue(char* secNm, char* keyNm, char* pValue)
{
    BEGIN_FUNCTION("GetStrCfgValue");
    ResCodeT rc = NO_ERR;

    string temp;
    temp = gCfgFile.ReadString(secNm, keyNm, "");
    if (sizeof(temp) <= 0)
    {
        RAISE_ERR(CFG_FILE_READ_ERR, RTN);
    }
    strcpy(pValue, temp.data());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetIntCfgValue(char* secNm,char* keyNm, int32* pValue)
{
    BEGIN_FUNCTION("GetIntCfgValue");
    ResCodeT rc = NO_ERR;

    *pValue = gCfgFile.ReadInt(secNm, keyNm, 0);
    if (*pValue <= 0)
    {
        RAISE_ERR(CFG_FILE_READ_ERR,RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT LoadCfgValue()
{
    BEGIN_FUNCTION("LoadCfgValue");
    ResCodeT rc = NO_ERR;   

    char value[MAX_BUFF_LEN];
    char secNm[] = "default";
    char keyNm[] = "env";
    GetStrCfgValue(secNm, keyNm, value);
    strcpy(gCfgValue.envNo, value);
    
    GetIntCfgValue((char*)"default", (char*)"prcsId", &(gCfgValue.prcsId));
    GetStrCfgValue((char*)"default", (char*)"prcsRole", &(gCfgValue.prcsRole));
    
    GetIntCfgValue((char*)"default", (char*)"MktDatPushIntrval", &(gCfgValue.iMktDatPushIntrval));
    GetIntCfgValue((char*)"default", (char*)"PerfMonIntrval", &(gCfgValue.iPerfMonIntrval));

    GetIntCfgValue((char*)"message", (char*)"MaxCacheSlotCnt", &(gCfgValue.iMaxMsgCacheSlotCnt));
    GetIntCfgValue((char*)"message", (char*)"MaxSecondLevelSlotCnt", &(gCfgValue.iMaxSecondLevelSlotCnt));
    GetIntCfgValue((char*)"message", (char*)"MaxThreadCnt", &(gCfgValue.iMaxThreadCnt));
    GetIntCfgValue((char*)"message", (char*)"IntrnlQueueSize", &(gCfgValue.iIntrnlQueueSize));


    GetIntCfgValue((char*)"mem_txn", (char*)"setId", &(gCfgValue.setId));
    GetIntCfgValue((char*)"mem_txn", (char*)"nmbrOfTxn", &(gCfgValue.nmbrOfTxn));
    GetIntCfgValue((char*)"mem_txn", (char*)"dataSize", &(gCfgValue.dataSize));
    GetIntCfgValue((char*)"mem_txn", (char*)"shlTxn", &(gCfgValue.shlTxn));
    GetIntCfgValue((char*)"mem_txn", (char*)"rplyIntrvl", &(gCfgValue.rplyIntrvl));
    
    
    GetIntCfgValue((char*)"orderbook", (char*)"TotalOrder", &(gCfgValue.ttlOrdrNmbr));
    GetIntCfgValue((char*)"orderbook", (char*)"TotalProduct", &(gCfgValue.ttlPrdctNmbr));
    GetIntCfgValue((char*)"orderbook", (char*)"TotalEnty", &(gCfgValue.ttlEntyNmbr));
    
    
    GetIntCfgValue((char*)"db", (char*)"needDbSupport", &(gCfgValue.needDbSupport));
    
    char secNm3[] = "db";
    char keyNm3[] = "dbInst";
    memset(value,0x00,MAX_BUFF_LEN);
    GetStrCfgValue(secNm3, keyNm3, value);
    strcpy(gCfgValue.dbInst, value);
    memset(value,0x00,MAX_BUFF_LEN);
    
    char keyNm4[] = "dbName";
    GetStrCfgValue(secNm3, keyNm4, value);
    strcpy(gCfgValue.dbName, value);
    
    memset(value,0x00,MAX_BUFF_LEN);
    char keyNm5[] = "dbPwd";
    GetStrCfgValue(secNm3, keyNm5, value);
    strcpy(gCfgValue.dbPwd, value);
    
    
    GetIntCfgValue((char*)"monitor", (char*)"monSleepTim", &(gCfgValue.monSleepTim));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CfgInit(char* cfgPath)
{
    BEGIN_FUNCTION("CfgInit");
    ResCodeT rc = NO_ERR;
    
    memset(&gCfgValue, 0x00, sizeof(CfgValueT));

    char root[MAX_BUFF_LEN] = {0};
    char path[MAX_BUFF_LEN] = {0};
    if (strcmp(cfgPath, "") == 0)
    {
        GetStrEnvVar((char*)CFG_PATH, path);
        strcpy(root, path);
        strcpy(gCfgValue.cfgPath, root);
        strcat(root, CFG_FILE_NM);
        LOG_DEBUG("Get from %s %s",CFG_PATH, root);
        
    }
    else
    {
        strcpy(root, cfgPath);
        strcat(root, CFG_FILE_NM);
        strcpy(gCfgValue.cfgPath, cfgPath);
        LOG_DEBUG("Get from input %s", root);
    }
    if (!gCfgFile.Load(root))
    { // REASON: can't find file,invalid path
        RAISE_ERR(CFG_FILE_LOAD_ERR,RTN);
    }
    else
    {
        if (!LoadCfgValue())
        {
            RAISE_ERR(CFG_FILE_READ_ERR,RTN);
        }
    }
    
    getcwd(gCfgValue.homePath,sizeof(gCfgValue.homePath));
    
    LOG_DEBUG("homePath %s",gCfgValue.homePath);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetCfgValue(struct cfgValueS *ret)
{
    BEGIN_FUNCTION("GetCfgValue");
    ResCodeT rc = NO_ERR;

    memcpy(ret, &gCfgValue, sizeof(gCfgValue));

    EXIT_BLOCK();
    RETURN_RESCODE;
}
#endif /* _CFG_LIB_ */