﻿/***
Created on Aug 15, 2017
@author: longyun.hao
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <math.h>

#include "../include/err_lib.h"
#include "../include/err_cod.h"
#include "../include/uti_tool.h"

#include "msg_type.h"
#include "pck_irs_dicdata.h"
#include "order_book.h"
#include "order_check.h"
#include "ordr_mgmt.h"

#include "usr.h"
#include "usr_flg.h"
#include "usr_onln.h"
#include "org_info.h"
#include "base_param.h"
#include "contract_info.h"
#include "user_order.h"
#include "order_type.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MIN_UNIT_PRICE_DIR      10
#define MIN_UNIT_PRICE_OTH      -99999000

#define BP_BASE                 100
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
//static creditChkModeT gChkMode = CREDIT_CMODE_NULL;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CheckUsrStatus( int32 usrPos );
ResCodeT CheckOrgStatus( int32 orgPos );

ResCodeT OrderCmmnCheck( void * pInOrder, OrdrChkModeT chkMode );

ResCodeT FmtCnclRqstToOrder(pOrderCancelRequestReqT pCnclOrderReq, pOrderT pOrder)
{
    BEGIN_FUNCTION( "FmtCnclRqstToOrder" );
    ResCodeT rc = NO_ERR;

    pOrder->orderF.ordrNo = pCnclOrderReq->ordId;


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check user status
 * Parameters:
 *  pNewOrder       IN  Incoming order
 *  msgType         IN  Message type
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CheckUsrStatus( int32 usrPos, OrdrChkModeT chkMode )
{
    BEGIN_FUNCTION( "CheckUsrStatus" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    //pNewOrderSingleReqT pNewOrder = NULL;

    UsrBaseInfoT usrInfo = {0};

    if ( COMMN_POS_NULL == usrPos )
    {
        THROW_RESCODE( NO_ERR );
    }

    //todo: if got a pos, a user should be found in share mem
    rc = IrsUsrInfoGetByPos( usrPos, &usrInfo );
    RAISE_ERR(rc, RTN);

    // 校验登录状态
    if ( !usrInfo.usrOnlnStatus )
    {
        RAISE_ERR( ERR_CODE_INVLD_NOT_LOGON, RTN );
    }

    // 校验用户状态 todo:error code is not proper
    switch( atoi(usrInfo.usrSt) )
    {
        case C_USR_ST_ACTIVE:
            THROW_RESCODE( NO_ERR );
            break;

        case C_USR_ST_LOCK:
            RAISE_ERR( ERR_CODE_INVLD_INVALID_USER, RTN );
            break;

        case C_USR_ST_DELETE:
            RAISE_ERR( ERR_CODE_INVLD_INVALID_USER, RTN );
            break;
        default:
            break;
    }

    /* 检查客户端提单权限 */
    if ( atoi(usrInfo.ordrPrvlgF) != C_ORDR_PRVLG_F_CLIENT )
    {
        RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
    }

    /* Not suit for all type */
    switch ( chkMode )
    {
        case ORD_CHK_MODE_SAVE :
        case ORD_CHK_MODE_CNCL :
        case ORD_CHK_MODE_FRZE :

            break;
        case ORD_CHK_MODE_SBMT :
        case ORD_CHK_MODE_ACTV :
            /* 用户市场状态 */
            if ( !usrInfo.mktSt[0] )
            {
                RAISE_ERR( ERR_CODE_INVLD_USRMKT_PRV, RTN );
            }
            break;
        default:
            break;
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check organization status
 * Parameters:
 *  orgPos          IN  orgPos order
 *  msgType         IN  Message type
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CheckOrgStatus( int32 orgPos, OrdrChkModeT chkMode )
{
    BEGIN_FUNCTION( "CheckOrgStatus" );
    ResCodeT rc = NO_ERR;

    pOrgInfoT pOrgInfo = NULL;

    if ( COMMN_POS_NULL == orgPos )
    {
        THROW_RESCODE( NO_ERR );
    }

    rc = OrgInfoGetByPosExt( orgPos, &pOrgInfo );
    RAISE_ERR(rc, RTN);

    /* If it is common check for all type, no need to write into switch */
    if ( pOrgInfo->orgSt == ORG_STATUS_FORBID )
    {
        RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
    }

    if ( pOrgInfo->orgIrsSt == ORG_IRS_ST_FORBID )
    {
        RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
    }
    else if ( pOrgInfo->orgIrsSt == ORG_IRS_ST_DELETE )
    {
        RAISE_ERR(ERR_CODE_INVLD_ORG_DEL, RTN);
    }

    /* Not suit for all order type */
    switch ( chkMode )
    {
        case ORD_CHK_MODE_SAVE :
        case ORD_CHK_MODE_CNCL :
        case ORD_CHK_MODE_FRZE :

            break;
        case ORD_CHK_MODE_SBMT :
        case ORD_CHK_MODE_ACTV :
            /* Org Credit Check */
            if ( !pOrgInfo->crdtVldOrgFlag )
            {
                RAISE_ERR( ERR_CODE_INVLD_CRT_INVLD, RTN );
            }

            /* check org mkt-status */
            //if ( pOrgInfo->mktTypeSt[0] == ORG_MKT_ST_FORBID )
            //{
            //    RAISE_ERR( ERR_CODE_INVLD_ORG_FRD, RTN );
            //}
            break;
        default:
            break;
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when save it
 * Parameters:
 *  pSaveOrder      IN  the order gonna be saved
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderSaveCheck( pNewOrderSingleReqT pSaveOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "OrderSaveCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */


    /* 校验订单有效时间 */
    if ( pSaveOrder->newOrdrInfo.effectTime <= timeStamp )
    {
        RAISE_ERR(ERR_CODE_INVLD_EXPIRE_TIME, RTN);
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pSaveOrder, ORD_CHK_MODE_SAVE );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   order check
 * Parameters:
 *  pNewOrder      IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderSubmitCheck( pNewOrderSingleReqT pNewOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "OrderSubmitCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64 sysTimestamp = 0;

    int64            gapPrc = 0;
    pPrdctInfoT      pPrdctInfo = NULL;
    pBaseParamT      pBaseParam = NULL;
    pCntrctBaseInfoT pCntrctInfo = NULL;

    /* Get contract info */
    rc = IrsCntrctInfoGetByPosExt( pNewOrder->newOrdrInfo.contractPos, &pCntrctInfo );
    RAISE_ERR( rc, RTN );

    /* Get product info */
    rc = PrdctInfoGetByPosExt( pNewOrder->newOrdrInfo.contractPos, &pPrdctInfo );
    RAISE_ERR( rc, RTN );

    rc = BaseParamGetByNameExt( (char*)C_PRCLMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    gapPrc = abs(pNewOrder->newOrdrInfo.prcQtyInfo.price - pPrdctInfo->baseInfo.intraRefPrc );

    /* 校验订单价格 */
    switch ( pCntrctInfo->cntrctType )
    {
        case C_CONTRACT_TYPE_IRS:
            if ( pNewOrder->newOrdrInfo.prcQtyInfo.price < MIN_UNIT_PRICE_DIR )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        case C_CONTRACT_TYPE_ISP :
        case C_CONTRACT_TYPE_SIC :
            if ( pNewOrder->newOrdrInfo.prcQtyInfo.price < MIN_UNIT_PRICE_OTH )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        default:
            RAISE_ERR(ERR_CODE_INVLD_CNTRCT_NOTY, RTN);
            break;
    }

    /* BP limit */
    if ( gapPrc > atoi(pBaseParam->paramValue) * PRICE_BASE / BP_BASE &&
        ( pNewOrder->newOrdrInfo.execInst != EXEC_INST_ORD_ACTIVATE_EXEC &&
            pNewOrder->newOrdrInfo.execInst != EXEC_INST_ORD_NEW_EXEC ) )
    {
        RAISE_ERR( ERR_CODE_PRC_LESS_THAN_REF, RTN );
    }

    /* 校验订单数量 */

    /* 校验订单有效时间 */
    if ( pNewOrder->newOrdrInfo.effectTime <= timeStamp )
    {
        RAISE_ERR(ERR_CODE_INVLD_EXPIRE_TIME, RTN);
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pNewOrder, ORD_CHK_MODE_SBMT );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();

    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when cancle/freeze it
 * Parameters:
 *  pCnclOrder      IN  the order gonna be cancled
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderCancelCheck( int32 setId, pOrderCancelRequestReqT pCnclOrder )
{
    BEGIN_FUNCTION( "OrderCancelCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint32          ordrMgmtPos = 0;
    pOrderT         pInitOrder = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt  = NULL;

    pBaseParamT     pParamData = NULL;

    rc = OrdrMgmtNrmlGet(setId, pCnclOrder->ordId, &pOrdrMgmt, &pInitOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    if ( pInitOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED_NO_C, RTN );
    }
    else if ( pInitOrder->orderF.ordrSts == ORDR_STS_CANCEL )
    {
        RAISE_ERR( ERR_CODE_INVLD_CANCELED, RTN );
    }
    else
    {
        ;
    }

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);

    if ( atoi(pParamData->paramValue) >= C_MKT_ST_CLOSE )
    {
        RAISE_ERR( ERR_CODE_INVLD_CNCL_MKCLS, RTN );
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pInitOrder, ORD_CHK_MODE_CNCL );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when freeze it
 * Parameters:
 *  pFrzOrder       IN  the order gonna be freezed
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderFreezeCheck( int32 setId, pOrderCancelReplaceRequestReqT pFrzOrder )
{
    BEGIN_FUNCTION( "OrderFreezeCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint32           ordrMgmtPos = 0;
    pOrderT         pInitOrder = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt  = NULL;

    pBaseParamT pParamData = NULL;

    rc = OrdrMgmtNrmlGet(setId, pFrzOrder->ordId, &pOrdrMgmt, &pInitOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    if ( pInitOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED, RTN );
    }
    else if ( pInitOrder->orderF.ordrSts == ORDR_STS_FREEZE )
    {
        RAISE_ERR( ERR_CODE_INVLD_ORDER_STATUS, RTN );
    }
    else
    {
        ;
    }

    rc = BaseParamGetByNameExt((char *)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);

    if ( atoi(pParamData->paramValue) >= C_MKT_ST_CLOSE )
    {
        RAISE_ERR( ERR_CODE_INVLD_CNCL_MKCLS, RTN );
    }

    /* Common check */
    //rc = OrderCmmnCheck( (void *)pInitOrder, ORD_CHK_MODE_FRZE );
    //RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when active it
 * Parameters:
 *  pActvOrder      IN  the order gonna be actived
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderActiveCheck( int32 setId, pOrderCancelReplaceRequestReqT pActvOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "OrderActiveCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint32           ordrMgmtPos = 0;
    pOrderT          pInitOrder = NULL;
    pOrdrMgmtRcrdT   pOrdrMgmt  = NULL;

    int64            gapPrc = 0;
    pCntrctBaseInfoT pCntrctInfo = NULL;
    pPrdctInfoT      pPrdctInfo = NULL;
    pBaseParamT      pBaseParam = NULL;


    rc = OrdrMgmtNrmlGet(setId, pActvOrder->ordId, &pOrdrMgmt, &pInitOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    /* Get contract info */
    rc = IrsCntrctInfoGetByPosExt( pInitOrder->orderF.prdctId, &pCntrctInfo );
    RAISE_ERR( rc, RTN );

    /* Get product info */
    rc = PrdctInfoGetByPosExt( pInitOrder->orderF.prdctId, &pPrdctInfo );
    RAISE_ERR( rc, RTN );

    rc = BaseParamGetByNameExt( (char*)C_PRCLMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    gapPrc = abs(pInitOrder->orderF.ordrExePrc - pPrdctInfo->baseInfo.intraRefPrc );

    /* 校验订单价格 */
    switch ( pCntrctInfo->cntrctType )
    {
        case C_CONTRACT_TYPE_IRS:
            if ( pInitOrder->orderF.ordrExePrc < MIN_UNIT_PRICE_DIR )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        case C_CONTRACT_TYPE_ISP :
        case C_CONTRACT_TYPE_SIC :
            if ( pInitOrder->orderF.ordrExePrc < MIN_UNIT_PRICE_OTH )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        default:
            RAISE_ERR(ERR_CODE_INVLD_CNTRCT_NOTY, RTN);
            break;
    }

    /* BP limit */
    if ( gapPrc > atoi(pBaseParam->paramValue) * PRICE_BASE / BP_BASE &&
        ( pActvOrder->execInst != EXEC_INST_ORD_ACTIVATE_EXEC &&
            pActvOrder->execInst != EXEC_INST_ORD_NEW_EXEC ) )
    {
        RAISE_ERR( ERR_CODE_PRC_LESS_THAN_REF, RTN );
    }

    /* 校验订单数量 */



    /* Check effective time */
    if ( pInitOrder->orderF.ordrExpTim <= timeStamp )
    {
        RAISE_ERR(ERR_CODE_INVLD_EXPIRE_TIME, RTN);
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pInitOrder, ORD_CHK_MODE_ACTV );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   check order when save it
 * Parameters:
 *  pSaveOrder      IN  the order gonna be saved
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT BilOrderSaveCheck( pNewOrderSingleReqT pSaveOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "BilOrderSaveCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    BOOL             isSubmit = FALSE;
    UsrFlgKeyT       bilOrdKey ={0};

    bilOrdKey.usrPos = (uint32)pSaveOrder->newOrdrInfo.userIdx;
    bilOrdKey.cntrctPos = (uint32)pSaveOrder->newOrdrInfo.contractPos;
    rc = GetUsrFlg( &bilOrdKey, USR_BIL_ORD_FLG, &isSubmit );
    RAISE_ERR(rc, RTN);

    if ( isSubmit )
    {
        RAISE_ERR( ERR_CODE_BIL_EXISTS, RTN );
    }

    /* 校验订单有效时间 */
    if ( pSaveOrder->newOrdrInfo.effectTime <= timeStamp )
    {
        RAISE_ERR(ERR_CODE_INVLD_EXPIRE_TIME, RTN);
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pSaveOrder, ORD_CHK_MODE_SAVE );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   order check
 * Parameters:
 *  pNewOrder      IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT BilOrderSubmitCheck( pNewOrderSingleReqT pNewOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "OrderCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64 sysTimestamp = 0;

    int64            gapPrcBid = 0;
    int64            gapPrcAsk = 0;
    pPrdctInfoT      pPrdctInfo = NULL;
    pBaseParamT      pBaseParam = NULL;
    pCntrctBaseInfoT pCntrctInfo = NULL;

    BOOL             isSubmit = FALSE;
    UsrFlgKeyT       bilOrdKey ={0};

    bilOrdKey.usrPos = (uint32)pNewOrder->newOrdrInfo.userIdx;
    bilOrdKey.cntrctPos = (uint32)pNewOrder->newOrdrInfo.contractPos;
    rc = GetUsrFlg( &bilOrdKey, USR_BIL_ORD_FLG, &isSubmit );
    RAISE_ERR(rc, RTN);

    if ( isSubmit )
    {
        RAISE_ERR( ERR_CODE_BIL_EXISTS, RTN );
    }

    /* Get contract info */
    rc = IrsCntrctInfoGetByPosExt( pNewOrder->newOrdrInfo.contractPos, &pCntrctInfo );
    RAISE_ERR( rc, RTN );

    /* Get product info */
    rc = PrdctInfoGetByPosExt( pNewOrder->newOrdrInfo.contractPos, &pPrdctInfo );
    RAISE_ERR( rc, RTN );

    /* Get BP limit */
    rc = BaseParamGetByNameExt( (char*)C_PRCLMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    gapPrcBid = abs(pNewOrder->newOrdrInfo.prcQtyInfo.price - pPrdctInfo->baseInfo.intraRefPrc );
    gapPrcAsk = abs(pNewOrder->askPrcQtyInfo.price - pPrdctInfo->baseInfo.intraRefPrc );

    /* 校验订单价格 */
    switch ( pCntrctInfo->cntrctType )
    {
        case C_CONTRACT_TYPE_IRS:
            if ( pNewOrder->newOrdrInfo.prcQtyInfo.price < MIN_UNIT_PRICE_DIR )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            if ( pNewOrder->askPrcQtyInfo.price < MIN_UNIT_PRICE_DIR )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        case C_CONTRACT_TYPE_ISP :
            if ( pNewOrder->newOrdrInfo.prcQtyInfo.price < MIN_UNIT_PRICE_OTH )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            if ( pNewOrder->askPrcQtyInfo.price < MIN_UNIT_PRICE_OTH )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        case C_CONTRACT_TYPE_SIC :
            if ( pNewOrder->newOrdrInfo.prcQtyInfo.price < MIN_UNIT_PRICE_OTH )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            if ( pNewOrder->askPrcQtyInfo.price < MIN_UNIT_PRICE_OTH )
            {
                RAISE_ERR( ERR_CODE_INVLD_ORDR_PRC, RTN );
            }
            break;

        default:
            RAISE_ERR(ERR_CODE_INVLD_CNTRCT_NOTY, RTN);
            break;
    }

    /* Check BP limit */
    if ( (gapPrcBid > atoi(pBaseParam->paramValue) * PRICE_BASE / BP_BASE ||
            gapPrcAsk > atoi(pBaseParam->paramValue) * PRICE_BASE / BP_BASE) &&
        ( pNewOrder->newOrdrInfo.execInst != EXEC_INST_ORD_ACTIVATE_EXEC &&
            pNewOrder->newOrdrInfo.execInst != EXEC_INST_ORD_NEW_EXEC ) )
    {
        RAISE_ERR( ERR_CODE_PRC_LESS_THAN_REF, RTN );
    }

    /* Check effective time */
    if ( pNewOrder->newOrdrInfo.effectTime <= timeStamp )
    {
        RAISE_ERR(ERR_CODE_INVLD_EXPIRE_TIME, RTN);
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pNewOrder, ORD_CHK_MODE_SBMT );
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when cancle/freeze it
 * Parameters:
 *  pCnclOrder      IN  the order gonna be cancled
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT BilOrderCancelCheck( int32 setId, pOrderCancelRequestReqT pCnclOrder )
{
    BEGIN_FUNCTION( "BilOrderCancelCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint32          ordrMgmtPos = 0;
    pOrderT         pCnclBidOrder = NULL;
    pOrderT         pCnclAskOrder = NULL;
    pOrdrMgmtRcrdT  pBilOrdrMgmt  = NULL;

    pBaseParamT     pParamData = NULL;

    rc = OrdrMgmtBilGet(setId, pCnclOrder->ordId, &pBilOrdrMgmt,
                        &pCnclBidOrder, &pCnclAskOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    if ( pCnclBidOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED_NO_C, RTN );
    }
    else if ( pCnclBidOrder->orderF.ordrSts == ORDR_STS_CANCEL )
    {
        RAISE_ERR( ERR_CODE_INVLD_CANCELED, RTN );
    }
    else
    {
        ;
    }

    if ( pCnclAskOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED_NO_C, RTN );
    }
    else if ( pCnclAskOrder->orderF.ordrSts == ORDR_STS_CANCEL )
    {
        RAISE_ERR( ERR_CODE_INVLD_CANCELED, RTN );
    }
    else
    {
        ;
    }

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);

    if ( atoi(pParamData->paramValue) >= C_MKT_ST_CLOSE )
    {
        RAISE_ERR( ERR_CODE_INVLD_CNCL_MKCLS, RTN );
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pCnclBidOrder, ORD_CHK_MODE_CNCL );
    RAISE_ERR( rc, RTN );

    rc = OrderCmmnCheck( (void *)pCnclAskOrder, ORD_CHK_MODE_CNCL );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when freeze it
 * Parameters:
 *  pCnclOrder      IN  the order gonna be cancled
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT BilOrderFreezeCheck( int32 setId, pOrderCancelReplaceRequestReqT pFrzOrder )
{
    BEGIN_FUNCTION( "BilOrderFreezeCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint32          ordrMgmtPos = 0;
    pOrderT         pFrzeBidOrder = NULL;
    pOrderT         pFrzeAskOrder = NULL;
    pOrdrMgmtRcrdT  pBilOrdrMgmt  = NULL;

    pBaseParamT     pParamData = NULL;

    rc = OrdrMgmtBilGet(setId, pFrzOrder->ordId, &pBilOrdrMgmt,
                        &pFrzeBidOrder, &pFrzeAskOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    if ( pFrzeBidOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED, RTN );
    }
    else if ( pFrzeBidOrder->orderF.ordrSts == ORDR_STS_FREEZE )
    {
        RAISE_ERR( ERR_CODE_INVLD_ORDER_STATUS, RTN );
    }
    else
    {
        ;
    }

    if ( pFrzeAskOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED, RTN );
    }
    else if ( pFrzeAskOrder->orderF.ordrSts == ORDR_STS_FREEZE )
    {
        RAISE_ERR( ERR_CODE_INVLD_ORDER_STATUS, RTN );
    }
    else
    {
        ;
    }

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);

    if ( atoi(pParamData->paramValue) >= C_MKT_ST_CLOSE )
    {
        RAISE_ERR( ERR_CODE_INVLD_CNCL_MKCLS, RTN );
    }

    /* Common check */
    //rc = OrderCmmnCheck( (void *)pFrzeBidOrder, ORD_CHK_MODE_FRZE );
    //RAISE_ERR( rc, RTN );

    //rc = OrderCmmnCheck( (void *)pFrzeAskOrder, ORD_CHK_MODE_FRZE );
    //RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check bilorder when active it
 * Parameters:
 *  pActvOrder      IN  the order gonna be cancled
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT BilOrderActiveCheck( int32 setId, pOrderCancelReplaceRequestReqT pActvOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "BilOrderActiveCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint32           ordrMgmtPos = 0;
    pOrderT          pActvBidOrder = NULL;
    pOrderT          pActvAskOrder = NULL;
    pOrdrMgmtRcrdT   pBilOrdrMgmt  = NULL;

    OrderCancelReplaceRequestReqT bidOrdReq = {0};
    OrderCancelReplaceRequestReqT askOrdReq = {0};

    rc = OrdrMgmtBilGet(setId, pActvOrder->ordId, &pBilOrdrMgmt,
                        &pActvBidOrder, &pActvAskOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    /* Check Bid side */
    memcpy( &bidOrdReq, pActvOrder, sizeof(OrderCancelReplaceRequestReqT) );
    bidOrdReq.ordId = pActvBidOrder->orderF.ordrNo;

    rc = OrderActiveCheck( setId, &bidOrdReq, timeStamp );
    RAISE_ERR( rc, RTN );

    /* Check Ask side */
    memcpy( &askOrdReq, pActvOrder, sizeof(OrderCancelReplaceRequestReqT) );
    askOrdReq.ordId = pActvAskOrder->orderF.ordrNo;

    rc = OrderActiveCheck( setId, &askOrdReq, timeStamp );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   OCO order save check
 * Parameters:
 *  pOcoOrderList   IN  Incoming OCO order list
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OCOOrderSaveCheck( pNewOrderListReqT pOcoOrderList, int64 timeStamp )
{
    BEGIN_FUNCTION( "OCOOrderSaveCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int32   totOrdCnt = 0;
    int64   sysTimestamp = 0;

    pBaseParamT         pBaseParam = NULL;
    pNewOrderInfoT      pNewOrder = NULL;
    NewOrderSingleReqT  tmpOrdSnglReq = {0};
    pNewOrderSingleReqT pTmpOrdSnglReq = &tmpOrdSnglReq;

    totOrdCnt = pOcoOrderList->secInfoCnt + pOcoOrderList->secAskInfoCnt;


    /* 逐笔校验订单 */
    for ( int i = 0; i < totOrdCnt; i++ )
    {
        memset( pTmpOrdSnglReq, 0x00, sizeof(NewOrderSingleReqT) );

        if ( i < pOcoOrderList->secInfoCnt )
        {
            pNewOrder = &(pOcoOrderList->secInfo[i]);
        }
        else
        {
            pNewOrder = &(pOcoOrderList->secAskInfo[i-pOcoOrderList->secInfoCnt]);
        }

        memcpy( &(pTmpOrdSnglReq->newOrdrInfo), pNewOrder, sizeof(NewOrderInfoT) );

        rc = OrderSaveCheck( pTmpOrdSnglReq, timeStamp );
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();

    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   OCO order save check
 * Parameters:
 *  pOcoOrderList   IN  Incoming OCO order list
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OCOOrderActiveCheck( int32 setId, pOrderCancelReplaceRequestReqT pActvOrder, int64 timeStamp )
{
    BEGIN_FUNCTION( "OCOOrderActiveCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64           iter = 0;
    int64           ordrMgmtPos = 0;
    pOrderT         pInitOrder = NULL;
    pOrdrMgmtRcrdT  pOcoOrdrMgmt  = NULL;

    pBaseParamT     pBaseParam = NULL;
    pUsrBaseInfoT   pUsrInfo = NULL;
    OrderCancelReplaceRequestReqT  actvOrder = {0};

    /* check oco-order total number */
    rc = IrsUsrInfoGetByPosExt( pActvOrder->userIdx, &pUsrInfo );
    RAISE_ERR( rc, RTN );

    rc = BaseParamGetByNameExt( (char*)C_OCO_MAX, &pBaseParam );
    RAISE_ERR( rc, RTN );

    if ( (pUsrInfo->ocoOrdCnt + 1) > atoi(pBaseParam->paramValue) )
    {
        RAISE_ERR( ERR_CODE_INVLD_OCO_NUM, RTN );
    }

    /* get initial oco-order */
    memcpy( &actvOrder, pActvOrder, sizeof(OrderCancelReplaceRequestReqT) );

    rc = OrdrMgmtOcoGet(setId, pActvOrder->ordId, &pOcoOrdrMgmt, &pInitOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    /* check single order number fo this oco-order */
    rc = BaseParamGetByNameExt( (char*)C_OCO_ODR_MIN_LMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    if ( pOcoOrdrMgmt->ordrCnt < atoi(pBaseParam->paramValue) )
    {
        RAISE_ERR( ERR_CODE_INVLD_OCO_COUNT, RTN );
    }

    rc = BaseParamGetByNameExt( (char*)C_OCO_ODR_MAX_LMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    if ( pOcoOrdrMgmt->ordrCnt > atoi(pBaseParam->paramValue) )
    {
        RAISE_ERR( ERR_CODE_INVLD_OCO_COUNT, RTN );
    }

    /* loop check */
    do
    {
        actvOrder.ordId = pInitOrder->orderF.ordrNo;
        
        rc = OrderActiveCheck( setId, &actvOrder, timeStamp );
        RAISE_ERR( rc, RTN );

        rc = OrdrMgmtOcoGetNext(setId, pOcoOrdrMgmt, &pInitOrder, &iter);
        if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
        {
            RAISE_ERR(rc, RTN);
        }
        else
        {
            break;
        }
    } while (TRUE);

    /* Common check */
    rc = OrderCmmnCheck( (void *)pInitOrder, ORD_CHK_MODE_ACTV );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   OCO order submit check
 * Parameters:
 *  pOcoOrderList   IN  Incoming OCO order list
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OCOOrderSubmitCheck( pNewOrderListReqT pOcoOrderList, int64 timeStamp )
{
    BEGIN_FUNCTION( "OCOOrderSubmitCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int32   totOrdCnt = 0;
    int64   sysTimestamp = 0;

    pUsrBaseInfoT       pUsrInfo = NULL;
    pBaseParamT         pBaseParam = NULL;
    pNewOrderInfoT      pNewOrder = NULL;
    NewOrderSingleReqT  tmpOrdSnglReq = {0};
    pNewOrderSingleReqT pTmpOrdSnglReq = &tmpOrdSnglReq;

    totOrdCnt = pOcoOrderList->secInfoCnt + pOcoOrderList->secAskInfoCnt;
    
    /* check single order number fo this oco-order */
    rc = BaseParamGetByNameExt( (char*)C_OCO_ODR_MIN_LMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    if ( totOrdCnt < atoi(pBaseParam->paramValue) )
    {
        RAISE_ERR( ERR_CODE_INVLD_OCO_COUNT, RTN );
    }

    rc = BaseParamGetByNameExt( (char*)C_OCO_ODR_MAX_LMT, &pBaseParam );
    RAISE_ERR( rc, RTN );

    if ( totOrdCnt > atoi(pBaseParam->paramValue) )
    {
        RAISE_ERR( ERR_CODE_INVLD_OCO_COUNT, RTN );
    }

    /* check oco-order total number */
    rc = IrsUsrInfoGetByPosExt( pOcoOrderList->frstInfo.userIdx, &pUsrInfo );
    RAISE_ERR( rc, RTN );

    rc = BaseParamGetByNameExt( (char*)C_OCO_MAX, &pBaseParam );
    RAISE_ERR( rc, RTN );

    if ( (pUsrInfo->ocoOrdCnt + 1) > atoi(pBaseParam->paramValue) )
    {
        RAISE_ERR( ERR_CODE_INVLD_OCO_NUM, RTN );
    }

    /* 逐笔校验订单 */
    for ( int i = 0; i < totOrdCnt; i++ )
    {
        memset( pTmpOrdSnglReq, 0x00, sizeof(NewOrderSingleReqT) );

        if ( i < pOcoOrderList->secInfoCnt )
        {
            pNewOrder = &(pOcoOrderList->secInfo[i]);
        }
        else
        {
            pNewOrder = &(pOcoOrderList->secAskInfo[i-pOcoOrderList->secInfoCnt]);
        }

        memcpy( &(pTmpOrdSnglReq->newOrdrInfo), pNewOrder, sizeof(NewOrderInfoT) );

        rc = OrderSubmitCheck( pTmpOrdSnglReq, timeStamp );
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();

    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when cancle/freeze it
 * Parameters:
 *  pFrzOrder      IN  the order gonna be cancled
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OCOOrderFreezeCheck( int32 setId, pOrderCancelReplaceRequestReqT pFrzOrder )
{
    BEGIN_FUNCTION( "OCOOrderFreezeCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64           ordrMgmtPos = 0;
    pOrderT         pInitOrder = NULL;
    pOrdrMgmtRcrdT  pOcoOrdrMgmt  = NULL;

    pBaseParamT     pParamData = NULL;

    /* just check one of them */
    rc = OrdrMgmtOcoGet(setId, pFrzOrder->ordId, &pOcoOrdrMgmt, &pInitOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    if ( pInitOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED_NO_C, RTN );
    }
    else if ( pInitOrder->orderF.ordrSts == ORDR_STS_FREEZE )
    {
        RAISE_ERR( ERR_CODE_INVLD_ORDER_STATUS, RTN );
    }
    else
    {
        ;
    }

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);

    if ( atoi(pParamData->paramValue) >= C_MKT_ST_CLOSE )
    {
        RAISE_ERR( ERR_CODE_INVLD_CNCL_MKCLS, RTN );
    }

    /* Common check */
    //rc = OrderCmmnCheck( (void *)pInitOrder, ORD_CHK_MODE_FRZE );
    //RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check order when cancle/freeze it
 * Parameters:
 *  pCnclOrder      IN  the order gonna be cancled
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OCOOrderCancelCheck( int32 setId, pOrderCancelRequestReqT pCnclOrder )
{
    BEGIN_FUNCTION( "OCOOrderCancelCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64           ordrMgmtPos = 0;
    pOrderT         pInitOrder = NULL;
    pOrdrMgmtRcrdT  pOcoOrdrMgmt  = NULL;

    pBaseParamT     pParamData = NULL;

    /* just check one of them */
    rc = OrdrMgmtOcoGet(setId, pCnclOrder->ordId, &pOcoOrdrMgmt, &pInitOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    if ( pInitOrder->orderF.ordrSts == ORDR_STS_DEAL )
    {
        RAISE_ERR( ERR_CODE_ORD_CLOSED_NO_C, RTN );
    }
    else if ( pInitOrder->orderF.ordrSts == ORDR_STS_CANCEL )
    {
        RAISE_ERR( ERR_CODE_INVLD_CANCELED, RTN );
    }
    else
    {
        ;
    }

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);

    if ( atoi(pParamData->paramValue) >= C_MKT_ST_CLOSE )
    {
        RAISE_ERR( ERR_CODE_INVLD_CNCL_MKCLS, RTN );
    }

    /* Common check */
    rc = OrderCmmnCheck( (void *)pInitOrder, ORD_CHK_MODE_CNCL );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   order check
 * Parameters:
 *  pInOrder        IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderCmmnCheck( void * pInOrder, OrdrChkModeT chkMode )
{
    BEGIN_FUNCTION( "OrderCmmnCheck" );
    ResCodeT rc = NO_ERR;

    int32 orgPos = COMMN_POS_NULL;
    int32 usrPos = COMMN_POS_NULL;

    switch ( chkMode )
    {
        case ORD_CHK_MODE_SBMT :
        case ORD_CHK_MODE_SAVE :
            usrPos = (( pNewOrderSingleReqT )pInOrder)->newOrdrInfo.userIdx;
            orgPos = (( pNewOrderSingleReqT )pInOrder)->newOrdrInfo.orgIdx;
            break;
        case ORD_CHK_MODE_CNCL :
        case ORD_CHK_MODE_ACTV :
        case ORD_CHK_MODE_FRZE :
            usrPos = (( pOrderT )pInOrder)->orderF.userIdx;
            orgPos = (( pOrderT )pInOrder)->orderF.entyIdxNo;
            break;
        default:
            break;
    }

    /* check org status */
    rc = CheckOrgStatus( orgPos, chkMode );
    RAISE_ERR( rc, RTN );

    /* check user status */
    rc = CheckUsrStatus( usrPos, chkMode );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:     order price inversion check
 * Parameters:
 *  setId           IN  set id
 *  pOrdReq         IN  require order
 *  pIsInvrsn       OUT TRUE:inversion FALSE:no inversion
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT OrderInvrsnCheck( int32 setId, pNewOrderSingleReqT pOrdReq, BOOL * pIsInvrsn )
{
    BEGIN_FUNCTION( "OrderInvrsnCheck" );
    ResCodeT rc = NO_ERR;

    int16 tempMask;
    int16 tmpOrdSide;

    pOrderT pBkOrdr = NULL;
    pOrderT pNxtOrdr = NULL;

    * pIsInvrsn = FALSE;

    tmpOrdSide = ( pOrdReq->newOrdrInfo.side == ORDR_SIDE_BUY ) ? ORDR_SIDE_SELL : ORDR_SIDE_BUY;
    tempMask = tmpOrdSide | ORDR_TRDRESTR_AU;

    rc = GetBest( setId, pOrdReq->newOrdrInfo.contractPos, tempMask, &pBkOrdr );
    RAISE_ERR(rc, RTN);

    while (pBkOrdr)
    {
        if ( pOrdReq->newOrdrInfo.side == ORDR_SIDE_BUY &&
            pBkOrdr->orderF.userIdx == pOrdReq->newOrdrInfo.userIdx )
        {
            if ( pOrdReq->newOrdrInfo.prcQtyInfo.price >= pBkOrdr->orderF.ordrExePrc )
            {
                * pIsInvrsn = TRUE;
                break;
            }
            else
            {
                * pIsInvrsn = FALSE;
                break;
            }
        }

        if ( pOrdReq->newOrdrInfo.side == ORDR_SIDE_SELL &&
            pBkOrdr->orderF.userIdx == pOrdReq->newOrdrInfo.userIdx )
        {
            if ( pOrdReq->newOrdrInfo.prcQtyInfo.price <= pBkOrdr->orderF.ordrExePrc )
            {
                * pIsInvrsn = TRUE;
                break;
            }
            else
            {
                * pIsInvrsn = FALSE;
                break;
            }
        }

        rc = GetNextOrder( setId, pOrdReq->newOrdrInfo.contractPos, tempMask, pBkOrdr, &pNxtOrdr );
        RAISE_ERR( rc, RTN );

        pBkOrdr = pNxtOrdr;
    }

    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:     api submit order check
 * Parameters:
 *  pInOrder        IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ApiSubmitOrderCheck(pNewOrderSingleReqT pApiReq, pCntrctBaseInfoT pCntrctData, int64 timestamp)
{
    BEGIN_FUNCTION( "ApiOrderCheck" );
    ResCodeT rc = NO_ERR;


    // 若为限价订单，验证订单到期时间
    if (pApiReq->newOrdrInfo.ordType == EXT_ORD_TYPE_NORMAL)
    {
        if (pApiReq->newOrdrInfo.effectTime < timestamp)
        {
            RAISE_ERR(APIERR_CODE_INVLD_EXPRTM, RTN);
        }
    }


    // 判断IN_ORDRPRC是否在有效范围内
    if (pCntrctData->cntrctType == C_CONTRACT_TYPE_IRS)
    {
        // 直接合约判断报价精度为4位小数
        if (pApiReq->newOrdrInfo.prcQtyInfo.price % 10 != 0)
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }
    }
    else
    {
        // 基准互换,期差合约，判断报价精度为2位小数
        if (pApiReq->newOrdrInfo.prcQtyInfo.price % 1000 != 0)
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }
    }


    // SELECT to_number(IN_ORDRPRC) INTO V_ORDRPRC FROM dual;
    if (pCntrctData->cntrctType == C_CONTRACT_TYPE_IRS)
    {
        if (pApiReq->newOrdrInfo.prcQtyInfo.price > EX_C_API_ORDRPRC_MAX
                || pApiReq->newOrdrInfo.prcQtyInfo.price < EX_C_API_ORDRPRC_MIN_IRS)
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }
    }
    else if (pCntrctData->cntrctType == C_CONTRACT_TYPE_ISP)
    {
        if (pApiReq->newOrdrInfo.prcQtyInfo.price > EX_C_API_ORDRPRC_MAX
                || pApiReq->newOrdrInfo.prcQtyInfo.price < EX_C_API_ORDRPRC_MIN_ISP)
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }
    }
    else if (pCntrctData->cntrctType == C_CONTRACT_TYPE_SIC)
    {
        if (pApiReq->newOrdrInfo.prcQtyInfo.price > EX_C_API_ORDRPRC_MAX
                || pApiReq->newOrdrInfo.prcQtyInfo.price < EX_C_API_ORDRPRC_MIN_SIC)
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }
    }


    // 判断IN_NTNLAMNT名义本金是否为正整数
    if (pApiReq->newOrdrInfo.prcQtyInfo.qty <= 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // 判断IN_NTNLAMNT是否是场务设置的值的整数倍
    if (pApiReq->newOrdrInfo.prcQtyInfo.qty % pCntrctData->dealUnit != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_ORDR_AMNT, RTN);
    }


    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:     sirs api submit order check
 * Parameters:
 *  pInOrder        IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT SirsApiSubmitOrderCheck(pNewOrderSingleReqT pApiReq, pCntrctBaseInfoT pCntrctData, int64 timestamp)
{
    BEGIN_FUNCTION( "SirsApiSubmitOrderCheck" );
    ResCodeT rc = NO_ERR;


    // 若为限价订单，验证订单到期时间
    if (pApiReq->newOrdrInfo.ordType == EXT_ORD_TYPE_NORMAL)
    {
        if (pApiReq->newOrdrInfo.effectTime < timestamp)
        {
            RAISE_ERR(APIERR_CODE_INVLD_EXPRTM, RTN);
        }
    }


    // 判断报价精度为4位小数
    if (pApiReq->newOrdrInfo.prcQtyInfo.price % 10 != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // SELECT to_number(IN_ORDRPRC) INTO V_ORDRPRC FROM dual;
    if (pApiReq->newOrdrInfo.prcQtyInfo.price > EX_C_API_ORDRPRC_MAX_SIRS
            || pApiReq->newOrdrInfo.prcQtyInfo.price < EX_C_API_ORDRPRC_MIN_SIRS)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // 判断IN_NTNLAMNT名义本金是否为正整数
    if (pApiReq->newOrdrInfo.prcQtyInfo.qty <= 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // 判断IN_NTNLAMNT是否是场务设置的值的整数倍
    if ((int64)(pApiReq->newOrdrInfo.prcQtyInfo.qty * pow10(FIGURES_OF_AMNT_PER_UNIT)) % (int64)(pCntrctData->amntPerUnit) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_ORDR_AMNT, RTN);
    }


    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:     sbfccp api submit order check
 * Parameters:
 *  pInOrder        IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT SbfccpApiSubmitOrderCheck(pNewOrderSingleReqT pApiReq, pCntrctBaseInfoT pCntrctData, int64 timestamp)
{
    BEGIN_FUNCTION( "SbfccpApiSubmitOrderCheck" );
    ResCodeT rc = NO_ERR;


    // 若为限价订单，验证订单到期时间
    if (pApiReq->newOrdrInfo.ordType == EXT_ORD_TYPE_NORMAL)
    {
        if (pApiReq->newOrdrInfo.effectTime < timestamp)
        {
            RAISE_ERR(APIERR_CODE_INVLD_EXPRTM, RTN);
        }
    }


    // 判断报价精度为4位小数
    if (pApiReq->newOrdrInfo.prcQtyInfo.price % 10 != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // SELECT to_number(IN_ORDRPRC) INTO V_ORDRPRC FROM dual;
    if (pApiReq->newOrdrInfo.prcQtyInfo.price > EX_C_API_ORDRPRC_MAX_SBFCCP
            || pApiReq->newOrdrInfo.prcQtyInfo.price <= 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // 判断IN_NTNLAMNT名义本金是否为正整数
    if (pApiReq->newOrdrInfo.prcQtyInfo.qty <= 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }


    // 判断IN_NTNLAMNT是否是场务设置的值的整数倍
    if ((int64)(pApiReq->newOrdrInfo.prcQtyInfo.qty * pow10(FIGURES_OF_AMNT_PER_UNIT)) % (int64)(pCntrctData->amntPerUnit) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_ORDR_AMNT, RTN);
    }


    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:     api cancel order check
 * Parameters:
 *  pInOrder        IN  Incoming order
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ApiCancelOrderCheck(int32 set, pOrderCancelRequestReqT pApiReq)
{
    BEGIN_FUNCTION( "ApiCancelOrderCheck" );
    ResCodeT rc = NO_ERR;


    if (pApiReq->apiCancelType == C_API_CANCEL_ONE)
    {
        uint32           ordrMgmtPos = 0;
        pOrderT         pInitOrder = NULL;
        pOrdrMgmtRcrdT  pOrdrMgmt  = NULL;

        rc = OrdrMgmtNrmlGet(set, pApiReq->ordId, &pOrdrMgmt, &pInitOrder, &ordrMgmtPos);
        RAISE_ERR( rc, RTN );

        // 如果不是当前API接口提的订单或者不是当前交易员提的订单
        if (pInitOrder->orderF.userIdx == pApiReq->userIdx
                || pInitOrder->orderF.apiLoginUsrIdx == pApiReq->apiLoginUsrIdx)
        {
            RAISE_ERR(APIERR_CODE_INVLD_ORDR, RTN);
        }

        // 订单编号填写错误
        if (pInitOrder->orderF.ordrNo == pApiReq->ordId)
        {
            RAISE_ERR(APIERR_CODE_INVALID_ORDR_ID, RTN);
        }

        // 订单已成交
        if (pInitOrder->orderF.ordrSts == ORDR_STS_DEAL)
        {
            RAISE_ERR(APIERR_CODE_ORD_CLOSED_NO_C, RTN);
        }
        // 订单已撤销
        else if (pInitOrder->orderF.ordrSts == ORDR_STS_CANCEL)
        {
            RAISE_ERR(APIERR_CODE_REP_CANCEL, RTN);
        }
        // 其他
        else if (pInitOrder->orderF.ordrSts != ORDR_STS_ACTIVE)
        {
            RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
        }
    }


    EXIT_BLOCK( );
    RETURN_RESCODE;
}
