﻿/***
Created on Aug 10, 2017
@author: longyun.hao
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "../include/err_lib.h"
#include "../include/err_cod.h"
#include "../include/common_macro.h"
#include "pck_irs_dicdata.h"

#include "org_info.h"
#include "contract_info.h"
#include "order_book.h"
#include "credit_mgmt.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
//#define MULTIPLE    100000
#ifndef TRANS_CRDT_RC
#define TRANS_CRDT_RC( rc, pOrder )\
    do\
    {\
        if ( ERR_CMN_HASH_LIST_FULL == rc ||    \
                ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc )    \
        {                                                   \
            if ( GET_ORDR_SIDE(pOrder->orderF.ordrMask) == ORDR_SIDE_BUY ) \
            { \
                rc = ERR_CODE_INVLD_PAYCRT_NTFND;   \
            }                                       \
            else                                    \
            {                                       \
                rc = ERR_CODE_INVLD_GETCRT_NTFND;   \
            }                                       \
        }   \
    } while (0)
#endif
#ifndef RAISE_RC_TRANS_RSLT
#define RAISE_RC_TRANS_RSLT( rc, __pFlag )  \
    do\
    {\
        if ( ERR_CMN_HASH_LIST_FULL == rc ||    \
                ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc )    \
        {                                                 \
            *__pFlag = FALSE;       \
            THROW_RESCODE( NO_ERR );\
        }   \
        RAISE_ERR( rc, RTN );   \
    } while (0)
#endif
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
//static creditChkModeT gChkMode = CREDIT_CMODE_NULL;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/******************************************************************************
 * Description:   credit Deduction after match happened
 * Parameters:
 *  pCrdtUpdInfo  IN  credit check result
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ChkCreditMode( pCreditT pCrdtInfoInc, pCreditT pCrdtInfoBst, 
                            crdtChkModeT * pCrdtMode, BOOL *pIsCrdtOK )
{
    BEGIN_FUNCTION( "ChkCreditMode" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */

    if ( pCrdtInfoInc->crdtRlFlag[0] == CREDIT_RELATION_NONE ||
                pCrdtInfoBst->crdtRlFlag[0] == CREDIT_RELATION_NONE )
    {
        //RAISE_ERR(ERR_CODE_INVLD_CRT_INVLD, RTN);
        *pIsCrdtOK = FALSE;
        THROW_RESCODE( NO_ERR );
    }
    else if ( pCrdtInfoInc->crdtRlFlag[0] == CREDIT_RELATION_RLNM &&
                pCrdtInfoBst->crdtRlFlag[0] == CREDIT_RELATION_RLNM )
    {
        /* 按授信关系数设置授信方式为有效时无授信额度限制 */
        *pCrdtMode = CREDIT_CMODE_NINB;
    }
    else if ( pCrdtInfoInc->crdtRlFlag[0] == CREDIT_RELATION_RLNM &&
                pCrdtInfoBst->crdtRlFlag[0] == CREDIT_RELATION_AMNT )
    {
        *pCrdtMode = CREDIT_CMODE_NICB;
    }
    else if ( pCrdtInfoInc->crdtRlFlag[0] == CREDIT_RELATION_AMNT &&
                pCrdtInfoBst->crdtRlFlag[0] == CREDIT_RELATION_RLNM )
    {
        *pCrdtMode = CREDIT_CMODE_CINB;
    }
    else if ( pCrdtInfoInc->crdtRlFlag[0] == CREDIT_RELATION_AMNT &&
                pCrdtInfoBst->crdtRlFlag[0] == CREDIT_RELATION_AMNT )
    {
        *pCrdtMode = CREDIT_CMODE_CICB;
    }
    else
    {
        *pIsCrdtOK = FALSE;
        THROW_RESCODE( NO_ERR );
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   credit Deduction after match happened
 * Parameters:
 *  pCrdtUpdInfo  IN  credit check result
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CalcCreditRslt( uint64 orgIdInc, uint64 orgIdBst, pCntrctBaseInfoT pCntrctInfo, 
                        int64 dealQty, int64 *pCrdtAmntInc, int64 *pCrdtAmntBst )
{
    BEGIN_FUNCTION( "CalcCreditRslt" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64  creditLmtInc = 0;
    int64  creditLmtBst = 0;

    pRiskCfcntT pRiskInfoInc = NULL;
    pRiskCfcntT pRiskInfoBst = NULL;   //备用
    pRiskCfcntT pRiskInfoInc2 = NULL;
    pRiskCfcntT pRiskInfoBst2 = NULL;   //备用

    switch ( pCntrctInfo->cntrctType )
    {
        /* 直接合约 */
        case C_CONTRACT_TYPE_IRS :
            rc = IrsRiskCfcntGetByKeyExt( orgIdInc, pCntrctInfo->cntrctName, &pRiskInfoInc );
            RAISE_ERR(rc, RTN);

            rc = IrsRiskCfcntGetByKeyExt( orgIdBst, pCntrctInfo->cntrctName, &pRiskInfoBst );
            RAISE_ERR(rc, RTN);

            creditLmtInc = dealQty * pRiskInfoInc->rskCfcntVal * AMNT_BASE / PRICE_BASE;
            creditLmtBst = dealQty * pRiskInfoBst->rskCfcntVal * AMNT_BASE / PRICE_BASE;
            break;

        /* 期差合约 */
        case C_CONTRACT_TYPE_ISP :
        /* 基准互换合约 */
        case C_CONTRACT_TYPE_SIC :
            /* get INC-Short side RISK info */
            rc = IrsRiskCfcntGetByKeyExt( orgIdInc, pCntrctInfo->shrtCntrctName, &pRiskInfoInc );
            RAISE_ERR(rc, RTN);

            /* get INC-Long side RISK info */
            rc = IrsRiskCfcntGetByKeyExt( orgIdInc, pCntrctInfo->lngCntrctName, &pRiskInfoInc2 );
            RAISE_ERR(rc, RTN);

            /* get Bst-Short side RISK info */
            rc = IrsRiskCfcntGetByKeyExt( orgIdBst, pCntrctInfo->shrtCntrctName, &pRiskInfoBst );
            RAISE_ERR(rc, RTN);

            /* get Bst-Long side RISK info */
            rc = IrsRiskCfcntGetByKeyExt( orgIdBst, pCntrctInfo->lngCntrctName, &pRiskInfoBst2 );
            RAISE_ERR(rc, RTN);

            /* Real calc */
            creditLmtInc = (pRiskInfoInc->rskCfcntVal + pRiskInfoInc2->rskCfcntVal) 
                            * dealQty * AMNT_BASE / PRICE_BASE;

            creditLmtBst = (pRiskInfoBst->rskCfcntVal + pRiskInfoBst2->rskCfcntVal) 
                            * dealQty * AMNT_BASE / PRICE_BASE;
            break;

        default:
            RAISE_ERR(ERR_CODE_INVLD_CNTRCT_NOTY, RTN);
            break;
    }

    *pCrdtAmntInc = creditLmtInc;
    *pCrdtAmntBst = creditLmtBst;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   set crdt update amount for updating
 * Parameters:
 *  pCrdtUpdInfo  IN  credit check result
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT SetCrdtUpdAmnt( crdtChkModeT * pCrdtMode, pCreditT pCrdtInfoInc, pCreditT pCrdtInfoBst,
                            int64 crdtAmntInc, int64 crdtAmntBst, pCrdtMgmtUpdtT pCrdtUpdInfo )
{
    BEGIN_FUNCTION( "SetCrdtUpdAmnt" );
    ResCodeT rc = NO_ERR;

    pCrdtUpdInfo->chkMode = *pCrdtMode;

    switch ( *pCrdtMode )
    {
        case CREDIT_CMODE_CINB:
            pCrdtUpdInfo->incRmntQty = pCrdtInfoInc->rmnCrdtAmnt - crdtAmntInc;
            pCrdtUpdInfo->incUsedQty = pCrdtInfoInc->usedCrdtAmnt + crdtAmntInc;
    
            pCrdtUpdInfo->bstUsedQty = pCrdtInfoBst->usedCrdtAmnt + crdtAmntBst;
            break;
        case CREDIT_CMODE_NICB:
            pCrdtUpdInfo->incUsedQty = pCrdtInfoInc->usedCrdtAmnt + crdtAmntInc;
    
            pCrdtUpdInfo->bstRmntQty = pCrdtInfoBst->rmnCrdtAmnt - crdtAmntBst;
            pCrdtUpdInfo->bstUsedQty = pCrdtInfoBst->usedCrdtAmnt + crdtAmntBst;
            break;
        case CREDIT_CMODE_NINB:
            pCrdtUpdInfo->incUsedQty = pCrdtInfoInc->usedCrdtAmnt + crdtAmntInc;

            pCrdtUpdInfo->bstUsedQty = pCrdtInfoBst->usedCrdtAmnt + crdtAmntBst;
            break;
        case CREDIT_CMODE_CICB:
            pCrdtUpdInfo->incRmntQty = pCrdtInfoInc->rmnCrdtAmnt - crdtAmntInc;
            pCrdtUpdInfo->incUsedQty = pCrdtInfoInc->usedCrdtAmnt + crdtAmntInc;

            pCrdtUpdInfo->bstRmntQty = pCrdtInfoBst->rmnCrdtAmnt - crdtAmntBst;
            pCrdtUpdInfo->bstUsedQty = pCrdtInfoBst->usedCrdtAmnt + crdtAmntBst;
            break;
        default:
            //RAISE_ERR(ERR_CODE_INVLD_CRTRL_ERROR, RTN);
            break;
    }

    pCrdtUpdInfo->incCrdtPos = pCrdtInfoInc->pos;
    pCrdtUpdInfo->bstCrdtPos = pCrdtInfoBst->pos;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   credit check before match happens
 * Parameters:
 *  pIncOrdr      IN  Incoming order
 *  pBestOrdr     IN  Match order
 *  pPrdctInfo    IN  prdct infomation
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CreditCheck( pOrderT pIncOrdr, pOrderT pBstOrdr, pCrdtMgmtUpdtT pCrdtUpdInfo, BOOL *pIsCrdtOK )
{
    BEGIN_FUNCTION( "CreditCheck" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    uint64 tempQty = 0;
    int64  creditLmtInc = 0;
    int64  creditLmtBst = 0;

    pOrgInfoT   pOrgInfoInc = NULL;
    pOrgInfoT   pOrgInfoBst = NULL;
    pCreditT    pCrdtInfoInc = NULL;
    pCreditT    pCrdtInfoBst = NULL;
    pPrdctInfoT pPrdctInfo = NULL;
    pCntrctBaseInfoT pCntrctInfo = NULL;

    crdtChkModeT crdtMode = CREDIT_CMODE_NULL;

    *pIsCrdtOK = TRUE;
    if ( pIncOrdr->orderF.entyIdxNo == pBstOrdr->orderF.entyIdxNo )
    {
        *pIsCrdtOK = FALSE;
        THROW_RESCODE(NO_ERR);
    }

    tempQty = ( pIncOrdr->orderF.ordrQty < pBstOrdr->orderF.ordrQty )?
                    pIncOrdr->orderF.ordrQty : pBstOrdr->orderF.ordrQty;

    /* Get org info */
    rc = OrgInfoGetByPosExt( pIncOrdr->orderF.entyIdxNo, &pOrgInfoInc );
    RAISE_RC_TRANS_RSLT( rc, pIsCrdtOK );

    rc = OrgInfoGetByPosExt( pBstOrdr->orderF.entyIdxNo, &pOrgInfoBst );
    RAISE_RC_TRANS_RSLT( rc, pIsCrdtOK );

    /* Get contract info */
    rc = PrdctInfoGetByPosExt( pIncOrdr->orderF.prdctId, &pPrdctInfo );
    RAISE_RC_TRANS_RSLT( rc, pIsCrdtOK );

    rc = IrsCntrctInfoGetByNameExt( pPrdctInfo->prdctName, &pCntrctInfo );
    RAISE_RC_TRANS_RSLT( rc, pIsCrdtOK );

    /* Get credit base info */
    rc = CreditInfoGetByKeyExt( pOrgInfoInc->orgId, pOrgInfoBst->orgId, &pCrdtInfoInc );
    RAISE_RC_TRANS_RSLT( rc, pIsCrdtOK );

    rc = CreditInfoGetByKeyExt( pOrgInfoBst->orgId, pOrgInfoInc->orgId, &pCrdtInfoBst );
    RAISE_RC_TRANS_RSLT( rc, pIsCrdtOK );

    /* Check credit relation, get credit mode */
    rc = ChkCreditMode( pCrdtInfoInc, pCrdtInfoBst, &crdtMode, pIsCrdtOK );
    RAISE_ERR(rc, RTN);

    if ( !(*pIsCrdtOK) )
    {
        THROW_RESCODE( NO_ERR );
    }

    /* calc update amount */
    rc = CalcCreditRslt( pOrgInfoInc->orgId, pOrgInfoBst->orgId, pCntrctInfo,
                            tempQty,  &creditLmtInc, &creditLmtBst );
    RAISE_RC_TRANS_RSLT(rc, pIsCrdtOK);

    /* Real amount check */
    if ( ( crdtMode == CREDIT_CMODE_CINB || crdtMode == CREDIT_CMODE_CICB ) &&
            pCrdtInfoInc->rmnCrdtAmnt < creditLmtInc )
    {
        //RAISE_ERR(ERR_CODE_CRDT_RMN_LMT, RTN);
        *pIsCrdtOK = FALSE;
        THROW_RESCODE(NO_ERR);
    }

    if ( ( crdtMode == CREDIT_CMODE_NICB || crdtMode == CREDIT_CMODE_CICB ) &&
            pCrdtInfoBst->rmnCrdtAmnt < creditLmtBst )
    {
        //RAISE_ERR(ERR_CODE_CRDT_RMN_LMT, RTN);
        *pIsCrdtOK = FALSE;
        THROW_RESCODE(NO_ERR);
    }

    /* set output value for crdtDeduction */
    rc = SetCrdtUpdAmnt( &crdtMode, pCrdtInfoInc, pCrdtInfoBst, creditLmtInc, creditLmtBst, pCrdtUpdInfo );
    RAISE_ERR(rc, RTN);

    pCrdtUpdInfo->incEntyIdPos = pIncOrdr->orderF.entyIdxNo;
    pCrdtUpdInfo->bstEntyIdPos = pBstOrdr->orderF.entyIdxNo;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   credit Deduction after match happened
 * Parameters:
 *  pCrdtUpdInfo  IN  credit check result
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CreditDeduction( pCrdtMgmtUpdtT  pCrdtUpdInfo )
{
    BEGIN_FUNCTION( "CreditDeduction" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    CreditT     creditInfoInc = {0};
    CreditT     creditInfoBst = {0};

    /* 校验授信关系是否有效 */
    if ( pCrdtUpdInfo->chkMode <= CREDIT_CMODE_MIN ||
            pCrdtUpdInfo->chkMode >= CREDIT_CMODE_MAX )
    {
        RAISE_ERR(ERR_CODE_INVLD_CRTRL_ERROR, RTN);
    }

    rc = CreditInfoGetByPos( pCrdtUpdInfo->incCrdtPos, &creditInfoInc );
    RAISE_ERR( rc, RTN );

    rc = CreditInfoGetByPos( pCrdtUpdInfo->bstCrdtPos, &creditInfoBst );
    RAISE_ERR( rc, RTN );

    /* get credit update result */
    creditInfoInc.usedCrdtAmnt = pCrdtUpdInfo->incUsedQty;
    creditInfoInc.rmnCrdtAmnt = pCrdtUpdInfo->incRmntQty;

    creditInfoBst.usedCrdtAmnt = pCrdtUpdInfo->bstUsedQty;
    creditInfoBst.rmnCrdtAmnt = pCrdtUpdInfo->bstRmntQty;

    /* update credit memory */
    rc = CreditInfoUpdateByPos( pCrdtUpdInfo->incCrdtPos, &creditInfoInc );
    RAISE_ERR( rc, RTN );

    rc = CreditInfoUpdateByPos( pCrdtUpdInfo->bstCrdtPos, &creditInfoBst );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   credit check before match happens
 * Parameters:
 *  incOrgPos      IN  Incoming order Org Pos
 *  bstOrgPos      IN  Match order Org Pos
 *  pPrdctInfo     OUT  
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT GetCreditRmnAmnt( uint32 aOrgId, uint32 bOrgId, BOOL * pAvaFlag, int64 * pRmnAmnt )
{
    BEGIN_FUNCTION( "GetCreditRmnAmnt" );
    ResCodeT rc = NO_ERR;

    /* 变量声明 */
    int64 tempAmnt = 0;
    uint64 tempQty = 0;

    pOrgInfoT    pOrgInfoA = NULL;
    pOrgInfoT    pOrgInfoB = NULL;
    pCreditT     pCrdtInfoA = NULL;
    pCreditT     pCrdtInfoB = NULL;

    * pRmnAmnt = 0;
    * pAvaFlag = FALSE;

    /* 获取机构信息 */
    rc = OrgInfoGetByIdExt( aOrgId, &pOrgInfoA );
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByIdExt( bOrgId, &pOrgInfoB );
    RAISE_ERR(rc, RTN);

    /* 获取授信信息 */
    rc = CreditInfoGetByKeyExt( pOrgInfoA->orgId, pOrgInfoB->orgId, &pCrdtInfoA );
    if ( ERR_CMN_HASH_LIST_FULL == rc || ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc )
    {
        * pAvaFlag = FALSE;
        THROW_RESCODE(NO_ERR);
    }
    RAISE_ERR(rc, RTN);

    /* 获取授信信息 */
    rc = CreditInfoGetByKeyExt( pOrgInfoB->orgId, pOrgInfoA->orgId, &pCrdtInfoB );
    if ( ERR_CMN_HASH_LIST_FULL == rc || ERR_CMN_HASH_LIST_NODE_NOT_EXIST == rc )
    {
        * pAvaFlag = FALSE;
        THROW_RESCODE(NO_ERR);
    }
    RAISE_ERR(rc, RTN);

    /* 校验授信关系是否有效 */
    if ( pCrdtInfoA->crdtRlFlag[0] == CREDIT_RELATION_NONE ||
                pCrdtInfoB->crdtRlFlag[0] == CREDIT_RELATION_NONE )
    {
        * pAvaFlag = FALSE;
        THROW_RESCODE(NO_ERR);
    }
    else if ( pCrdtInfoA->crdtRlFlag[0] == CREDIT_RELATION_RLNM &&
                pCrdtInfoB->crdtRlFlag[0] == CREDIT_RELATION_RLNM )
    {
        /* 按授信关系数设置授信方式为有效时无授信额度限制 */
        * pAvaFlag = TRUE;
        * pRmnAmnt = CREDIR_AMNT_UNLMT;
    }
    else if ( pCrdtInfoA->crdtRlFlag[0] == CREDIT_RELATION_RLNM &&
                pCrdtInfoB->crdtRlFlag[0] == CREDIT_RELATION_AMNT )
    {
        * pAvaFlag = TRUE;
        * pRmnAmnt = pCrdtInfoB->rmnCrdtAmnt;
    }
    else if ( pCrdtInfoA->crdtRlFlag[0] == CREDIT_RELATION_AMNT &&
                pCrdtInfoB->crdtRlFlag[0] == CREDIT_RELATION_RLNM )
    {
        * pAvaFlag = TRUE;
        * pRmnAmnt = pCrdtInfoA->rmnCrdtAmnt;
    }
    else if ( pCrdtInfoA->crdtRlFlag[0] == CREDIT_RELATION_AMNT &&
                pCrdtInfoB->crdtRlFlag[0] == CREDIT_RELATION_AMNT )
    {
        * pAvaFlag = TRUE;
        * pRmnAmnt = ( pCrdtInfoB->rmnCrdtAmnt < pCrdtInfoA->rmnCrdtAmnt ) ? 
                            pCrdtInfoB->rmnCrdtAmnt : pCrdtInfoA->rmnCrdtAmnt ;
    }
    else
    {
        * pAvaFlag = FALSE;
        THROW_RESCODE(NO_ERR);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
