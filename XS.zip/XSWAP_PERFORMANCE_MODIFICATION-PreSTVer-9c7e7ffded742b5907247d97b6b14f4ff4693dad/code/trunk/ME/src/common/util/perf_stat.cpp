/***
Created on June 13, 2017
@author: XiaoPing Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */


/* Project Header File*/
#include "../include/err_lib.h"
#include "../include/shm.h"
#include "../include/perf_stat.h"
#include "../include/uti_tool.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/



/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
PerfStatDescrT PERF_STAT[] = 
{
    /* Same order as PerfStatTypesT, which is index into array. */
    {"[Mtchr]Ordr/s", AvgPerSecond},  /* MOrdrEntry */
    {"[Mtchr]Deal/s", AvgPerSecond},  /* MDealEntry */
    {"[Mtchr]Brdg/s", AvgPerSecond},  /* MOrdrBrdgng */
    {"MktPush/s",     AvgPerSecond},  /* MktPushTrgr */
    {"TDPSMsg/s",     AvgPerSecond},  /* Snd2TdpsMsg */
    {"OrdrCnfrmSend/s",      AvgPerSecond},  /* OrdrCnfrmMsgSend */
    {"DealCnfrmSend/s",      AvgPerSecond},  /* DealCnfrmMsgSend */
    {"RspOut/s",     AvgPerSecond},  /* RspMsgOut */
    {"ReqIn/s",     AvgPerSecond},  /* ReqMsgIn */
    {"TxnCnt/s",     AvgPerSecond},  /* TxnCnt */
    {"TxnDatCnt/s",     AvgOfSamples},  /* TxnDatCnt */
    /* This one must always be the last to mark the list's end  */
    {"End",           AvgPerSecond}  /* EndOfTypes */
};
    
/* Library Status */
enum PerfStatus
{
    StatusNoInit = 0,
    StatusAttached,
    StatusDisabled
} Status = StatusNoInit;

/* Handle/pointer to statistics area */
int64 *pStatsShmRoot = NULL;
pPerfStatT pPerfStatus = NULL;

/* Stores yet unfinished samples locally before adding to the shared memory */
PerfStatT localSamples[EndOfTypes];

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT PerfStatShmCreate(pPerfStatT *ppShmRoot){

    BEGIN_FUNCTION("PerfStatShmCreate");

    ResCodeT rc;
    int64 *pShmRoot;
            
    rc = ShmCreate(GetShmNm((char*)SHM_PERF_STAT_NAME), sizeof(PerfStatT)*EndOfTypes, &pShmRoot);
    RAISE_ERR(rc, RTN);

    memset(pShmRoot, 0, sizeof(PerfStatT)*EndOfTypes);
    
    *ppShmRoot = (pPerfStatT)pShmRoot;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PerfStatShmAttach(pPerfStatT *ppShmRoot){

    BEGIN_FUNCTION("PerfStatShmAttach");

    ResCodeT rc;
    int64 *pRoot;
    int64 shmSize;
            
    rc = ShmAttach(GetShmNm((char*)SHM_PERF_STAT_NAME), &pRoot);
    RAISE_ERR(rc, RTN);

    
    *ppShmRoot = (pPerfStatT)pRoot;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PerfStatShmDestroy(){

    BEGIN_FUNCTION("PerfStatShmDestroy");

    ResCodeT rc;
           
    rc = ShmDelete(GetShmNm(GetShmNm((char*)SHM_PERF_STAT_NAME)));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


static ResCodeT PerfStatInit()
{
    BEGIN_FUNCTION("PerfStatInit");
    ResCodeT rc;
    int64 shmSize;
    
    /* Initialize local samples */
    memset(localSamples,0,sizeof(localSamples));
    
    /* Attach to Shared Memory */
    if (pStatsShmRoot == NULL){
        /* Try attaching silently: If successful, good, 
         if not, then just switch off statistics gathering */
        rc = ShmAttach(GetShmNm((char*)SHM_PERF_STAT_NAME), &pStatsShmRoot);
        
        if (NOTOK(rc)){
            THROW_RESCODE(rc);
        }
        
    }
    
    if (pPerfStatus == NULL){
        pPerfStatus = (pPerfStatT)pStatsShmRoot;
    }
    
    /* Set library status */
    Status = StatusAttached;

    RETURN_RESCODE;    
    
    EXIT_BLOCK();
    
    pStatsShmRoot = NULL;
    Status = StatusDisabled;
    RETURN_RESCODE;
    
}


ResCodeT PerfStatInc(PerfStatTypesT type){

    ResCodeT rc;
    
    BEGIN_FUNCTION("PerfStatInc");
    
    ASSERT(type < EndOfTypes);
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Do the actual incrememt */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
      
        pPerfStatus[type].cnt++;
      
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

 
ResCodeT PerfStatSampleInc(PerfStatTypesT type){

    BEGIN_FUNCTION("PerfStatSampleInc");
    ResCodeT rc;
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Do the actual local increment */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
      
        localSamples[type].cnt++;
      
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT PerfStatIncPlusSample(PerfStatTypesT typeInc,PerfStatTypesT typeSample){

    BEGIN_FUNCTION("PerfStatIncPlusSample");
    ResCodeT rc;
    
    ASSERT(typeInc < EndOfTypes);
    ASSERT(typeSample < EndOfTypes);
    
    rc = PerfStatInc(typeInc);
    RAISE_ERR(rc, RTN);
    
    rc = PerfStatSampleInc(typeSample);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT PerfStatSampleEnd(PerfStatTypesT type, int32 bLogZeroValue){

    BEGIN_FUNCTION("PerfStatSampleEnd");
    ResCodeT rc;
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Do the actual end-of-sample processing: Add locally stored value */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
      
        /* log zero value only if requested */
        if ((localSamples[type].cnt > 0) || bLogZeroValue){
            /* Let PerfStatSampleAdd handle moving to shared memory */
            rc = PerfStatSampleAdd(type, localSamples[type].cnt);
            RAISE_ERR(rc, RTN);
        
            /* reset local counter */
            localSamples[type].cnt = 0;
        }
      
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PerfStatSampleReset(PerfStatTypesT type){

    BEGIN_FUNCTION("PerfStatSampleReset");
    ResCodeT rc;
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Do the actual local reset */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
     
        /* reset local counter */
        localSamples[type].cnt = 0;
      
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT PerfStatSampleAdd(PerfStatTypesT type, uint64 cnt){

    BEGIN_FUNCTION("PerfStatSampleAdd");
    ResCodeT rc;
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Do the actual end-of-sample processing */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
     
        /* consistency protocol: increment samplesBegin at beginning */
        /* cnt is only valid if samplesBegin == samplesEnd */
        pPerfStatus[type].samplesBegin++;
      
        /* now add the sample size from the local temp value */
        pPerfStatus[type].cnt += cnt;
      
        /* consistency protocol: increment samplesEnd at end */
        pPerfStatus[type].samplesEnd++;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PerfStatSetVal(PerfStatTypesT type, uint64 val){

    BEGIN_FUNCTION("PerfStatSetVal");
    ResCodeT rc;
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Set the actual value */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
     
        /* reset local counter */
        pPerfStatus[type].cnt = val;
      
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PerfStatGetVal(PerfStatTypesT type, uint64* val){

    BEGIN_FUNCTION("PerfStatGetVal");
    ResCodeT rc;
    
    if (Status == StatusNoInit){
        /* No error handling. Status is set to StatusDisabled by PerfStatInit() if shared memory cannot be attached */
        rc = PerfStatInit();
        RAISE_ERR(rc, RTN);
    }
    
    /* Get the actual value */
    if ((Status == StatusAttached) && pPerfStatus && (0 <= type) && (type < EndOfTypes)){
     
        /* get the value of counter */
        *val = pPerfStatus[type].cnt;
      
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}