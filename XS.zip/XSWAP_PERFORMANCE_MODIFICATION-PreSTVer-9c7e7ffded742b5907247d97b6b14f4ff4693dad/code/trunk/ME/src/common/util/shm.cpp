/***
Created on May 31, 2017
@author: Ming.Kong
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <dirent.h>
/* Project Header File*/
#include "common_macro.h"
#include "data_type.h"
#include "err_lib.h"
#include "shm.h"
#include "err_cod.h"
#include "cfg_lib.h"
#include "uti_tool.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define SHM_MASK_ID                   0666 

#define FILE_OPEN_FAIL                              -1
#define FILE_NO_EXIST                               -1
#define ID_FTOK_FAIL                                -1
#define SHM_GET_FAIL                                -1
#define SHM_DT_FAIL                                 -1
#define SHM_CTL_FAIL                                -1
#define SHM_NAME_LEN                                128

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT CvtShmNmPth(char* shmName,char* fullShmNm)
{
    BEGIN_FUNCTION("CvtShmNmPth");
    ResCodeT rc = NO_ERR;
    
    char path[MAX_BUFF_LEN];
    CfgValueT ret;
    
    rc = GetCfgValue(&ret);
    RAISE_ERR(rc,RTN);
    strcpy(path,ret.homePath);
    strcat(path,"/../tmp/");
    strcat(path,shmName);
    strcpy(fullShmNm,path);
    
    LOG_DEBUG("fullShmNm %s", fullShmNm);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT ShmCreate(char* shmName, int64 size, int64** ppRoot)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("ShmCreate");
    key_t id = ID_FTOK_FAIL;
    int fd = FILE_OPEN_FAIL;
    int64 shmId = SHM_GET_FAIL;
    int64* pShm = NULL;
    char fullShmName[SHM_NAME_LEN];
    memset(fullShmName,0x00, SHM_NAME_LEN);
    rc = CvtShmNmPth(shmName,fullShmName);
    RAISE_ERR(rc,RTN);

    fd = open(fullShmName, O_CREAT, S_IRWXU|S_IRWXG|S_IRWXO);
    if (fd == FILE_OPEN_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_OPEN_FAIL, RTN);
    }
    
    /* create id from shmName */
    id = ftok(fullShmName, 1);
    if (id == ID_FTOK_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_FTOK_FAIL, RTN);
    }
    
    shmId = shmget(id, size, SHM_MASK_ID|IPC_CREAT);
    if (shmId == SHM_GET_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_GET_FAIL, RTN);
    }
    
    pShm = (int64*)shmat(shmId, (void*)0, 0);
    if (pShm == NULL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_MAT_FAIL, RTN);
    }
    
    *ppRoot = pShm;

    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT ShmAttach(char* shmName, int64** ppRoot)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("shmAttach");
    key_t id;
    int64 shmId;
    int64* pShm = NULL;
    char fullShmName[SHM_NAME_LEN];
    memset(fullShmName,0x00, SHM_NAME_LEN);
    rc = CvtShmNmPth(shmName,fullShmName);
    RAISE_ERR(rc,RTN);

    if (access(fullShmName,F_OK) == FILE_NO_EXIST)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_NOT_CREATED, RTN);
    }
    
    /* create id from shmName */
    id  =  ftok(fullShmName, 1);
    if (id == ID_FTOK_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_FTOK_FAIL, RTN);
    }
    
    shmId = shmget(id, 0, 0);
    if (shmId == SHM_GET_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_GET_FAIL, RTN);
    }
    
    pShm = (int64*)shmat(shmId, (void*)0, 0);
    if (pShm == NULL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_MAT_FAIL, RTN);
    }
    
    *ppRoot = pShm;

    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT ShmDelete(char* shmName)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("shmDelete");
    key_t id;  
    int32 fd;
    int64 shmId;
    int64* pShm;
    char fullShmName[SHM_NAME_LEN];
    memset(fullShmName,0x00, SHM_NAME_LEN);
    rc = CvtShmNmPth(shmName,fullShmName);
    RAISE_ERR(rc,RTN);
    
    if (access(fullShmName,F_OK) == FILE_NO_EXIST)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_NOT_CREATED, RTN);
    }

    fd = open(fullShmName, O_CREAT, S_IRWXU|S_IRWXG|S_IRWXO);
    if (fd == FILE_OPEN_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_OPEN_FAIL, RTN);
    }
    
    /* create id from shmName */
    id  =  ftok(fullShmName, 1);
    if (id == ID_FTOK_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_FTOK_FAIL, RTN);
    }
    
    shmId = shmget(id, 0, 0);
    if (shmId == SHM_GET_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_GET_FAIL, RTN);
    }
    
    if (shmctl(shmId, IPC_RMID, 0) == SHM_CTL_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_DESTORY_FAIL, RTN);
    }

    close(fd);
    unlink(fullShmName);
    
    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT ShmDetach(char* shmName)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("shmDetach");
    int64 shmId;
    int32 id;
    int64* pShm;
    char fullShmName[SHM_NAME_LEN];
    memset(fullShmName,0x00, SHM_NAME_LEN);
    rc = CvtShmNmPth(shmName,fullShmName);
    RAISE_ERR(rc,RTN);
    
    if (access(fullShmName,F_OK) == FILE_NO_EXIST)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_NOT_CREATED, RTN);
    }

    /* create id from shmName */
    id  =  ftok(fullShmName, 1);
    if (id == ID_FTOK_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_FTOK_FAIL, RTN);
    }
    
    shmId = shmget(id, 0, 0);
    if (shmId == SHM_GET_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_GET_FAIL, RTN);
    }
    
    pShm = (int64*)shmat(shmId, (void*)0, 0);
    if (pShm == NULL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_MAT_FAIL, RTN);
    }

    if (shmdt(pShm) == SHM_DT_FAIL)
    {
        RAISE_ERR(ERR_MSG_SHM_SHM_DETACH_FAIL, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}




ResCodeT ShmDeleteByPid(char* tmpPath,char * envNo, char * pid)
{
    ResCodeT rc = NO_ERR;
    DIR             * pTmpDir = NULL;
    struct  dirent   * pFile = NULL;
    key_t   id;  
    int32   fd;
    int64   shmId;
    int64*  pShm;
    
    char    root[1024] = {0};
    
    getcwd(root, 1024);
    
    char    filePath[1024];
    
    if (!(pTmpDir = opendir(tmpPath)))
    {
        printf("Open dir %s failed \n", tmpPath);
        return NO_ERR;
    }
    
    while (pFile = readdir(pTmpDir))
    {
        if (!strcmp(pFile->d_name, ".") || !strcmp(pFile->d_name, ".."))
        {
            continue;
        }
        else if (pFile->d_type == 8) //file type
        {
            if (!strstr((char*)pFile->d_name,pid ))
            {
                continue;
            }
            
            memset(filePath,0x00,1024);
            sprintf(filePath, "%s/%s%s",root, tmpPath, pFile->d_name);
            if (access(filePath ,F_OK) == FILE_NO_EXIST)
            {
                printf("Failed to access %s \n", filePath);
                return NO_ERR;
            }

            /* create id from shmName */
            id  =  ftok(filePath, 1);
            if (id == ID_FTOK_FAIL)
            {
                printf("Failed to ftok %s \n", filePath);
                return NO_ERR;
            }
            
            shmId = shmget(id, 0, 0);
            if (shmId == SHM_GET_FAIL)
            {
                printf("Failed to shmget %s id %X\n",filePath, id);
                return NO_ERR;
            }
            
            if (shmctl(shmId, IPC_RMID, 0) == SHM_CTL_FAIL)
            {
                printf("Failed to shmctl %s \n", filePath);
                return NO_ERR;
            }
        
            close(fd);
            unlink(filePath);
            
            printf("Delete %s \n", pFile->d_name);
        }             
    }
    
    closedir(pTmpDir);
    return NO_ERR;
}
