/***
Created on Aug 16, 2017
@author: Jiawang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files*/
#include "err_lib.h"
#include "common_macro.h"
#include "db_comm.h"
#include "cfg_lib.h"
#include "msg_cache.h"
#include "intrnl_msg.h"
#include "msg_type.h"
#include "uti_tool.h"
#include "app_shl.h"

#include "active_keeper.h"
#include "ActiveInfoDb.h"
#include "active_info.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define INIT_STATUS "init"

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

static int32    gConnId     = DB_INVALID_CONN_ID;
static int32    gLockConnId = DB_INVALID_CONN_ID;
static int16    gLockStatus = HA_LOCK_INIT;

static char     g_strHostName[MAX_HOST_LEN];

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 **
 ** Function Implementation
 **
 ******************************************************************************/

/******************************************************************************
 **
 ** SetPrimary
 **     ��������
 **
 ******************************************************************************/
ResCodeT SetPrimary(int64 iSetId, const char* host)
{
    BEGIN_FUNCTION( "SetPrimary" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(4)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(4)] = {0};


    ActiveInfo          data;

    memset(&data, 0, sizeof(data));

    data.setId = iSetId;
    strcpy(data.primaryHost, host);


    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 1 );

    rc = UpdateActiveInfoByKey(gConnId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(gConnId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetPrimary
 **     ��ȡ����
 ***
 ******************************************************************************/
ResCodeT GetPrimary(int64 iSetId, char* host)
{
    BEGIN_FUNCTION( "GetPrimary" );
    ResCodeT rc = NO_ERR;

    pActiveInfoT    pActiveInfo;
    rc = ActiveInfoGetByIdExt(iSetId, &pActiveInfo);
    RAISE_ERR(rc, RTN);

    strcpy(host, pActiveInfo->primaryHost);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** SetBackup
 **     ���ñ���
 **
 ******************************************************************************/
ResCodeT SetBackup(int64 iSetId, const char* host)
{
    BEGIN_FUNCTION( "SetBackup" );
    ResCodeT rc = NO_ERR;

    vectorT  keyVct[GET_BIT_VECT_LEN(4)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(4)] = {0};

    ActiveInfo          data;

    memset(&data, 0, sizeof(data));

    data.setId = iSetId;
    strcpy(data.backupHost, host);

    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 2 );

    rc = UpdateActiveInfoByKey(gConnId, &data, keyVct, datVct);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCommit(gConnId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetBackup
 **     ��ȡ����
 **
 ******************************************************************************/
ResCodeT GetBackup(int64 iSetId, char* host)
{
    BEGIN_FUNCTION( "GetBackup" );
    ResCodeT rc = NO_ERR;

    pActiveInfoT    pActiveInfo;
    rc = ActiveInfoGetByIdExt(iSetId, &pActiveInfo);
    RAISE_ERR(rc, RTN);

    strcpy(host, pActiveInfo->backupHost);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetHaTime
 **     ��ȡ�����������е�ʱ��
 **
 ******************************************************************************/
ResCodeT GetHaTime(int64 iSetId, char* haTime)
{
    BEGIN_FUNCTION( "GetHaTime" );
    ResCodeT rc = NO_ERR;

    pActiveInfoT    pActiveInfo;
    rc = ActiveInfoGetByIdExt(iSetId, &pActiveInfo);
    RAISE_ERR(rc, RTN);

    strcpy(haTime, pActiveInfo->haTime);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** IsPrimary
 **     �Ƿ�����
 **
 ******************************************************************************/
ResCodeT IsPrimary(int64 iSetId, BOOL* blIsPrimary)
{
    BEGIN_FUNCTION( "IsPrimary" );
    ResCodeT rc = NO_ERR;

    pActiveInfoT    pActiveInfo;
    rc = ActiveInfoGetByIdExt(iSetId, &pActiveInfo);
    RAISE_ERR(rc, RTN);

    *blIsPrimary = (strcmp(g_strHostName, pActiveInfo->primaryHost) == 0) ? TRUE : FALSE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** IsBackup
 **     �Ƿ񱸻�
 **
 ******************************************************************************/
ResCodeT IsBackup(int64 iSetId, BOOL* blIsBackup)
{
    BEGIN_FUNCTION( "IsBackup" );
    ResCodeT rc = NO_ERR;

    pActiveInfoT    pActiveInfo;
    rc = ActiveInfoGetByIdExt(iSetId, &pActiveInfo);
    RAISE_ERR(rc, RTN);

    *blIsBackup = (strcmp(g_strHostName, pActiveInfo->backupHost) == 0) ? TRUE : FALSE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ConvertTime
 **
 ******************************************************************************/
ResCodeT ConvertTime(char* strTime, int& hour, int& min, int& sec)
{
    BEGIN_FUNCTION( "ConvertTime" );
    ResCodeT rc = NO_ERR;

    char delims[] = ":";

    char* result;

    result = strtok(strTime, delims);
    if (result == NULL)
    {
        RAISE_ERR(ERR_HA_GET_TIME_FAILED, RTN);
    }
    hour = atoi(result);

    result = strtok(NULL, delims);
    if (result == NULL)
    {
        RAISE_ERR(ERR_HA_GET_TIME_FAILED, RTN);
    }
    min = atoi(result);

    result = strtok(NULL, delims);
    if (result == NULL)
    {
        RAISE_ERR(ERR_HA_GET_TIME_FAILED, RTN);
    }
    sec = atoi(result);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** IsHaBegin
 **     �Ƿ񱸻���������
 **
 ******************************************************************************/
ResCodeT IsHaBegin(int64 iSetId, BOOL* isBegin)
{
    BEGIN_FUNCTION( "IsHaBegin" );
    ResCodeT rc = NO_ERR;

    struct tm tmHa;
    struct tm tmCurrent;

    // 1. get ha time
    char haTime[MAX_HA_TIME_LEN];
    memset(haTime, 0, sizeof(haTime));
    rc = GetHaTime(iSetId, haTime);
    RAISE_ERR(rc, RTN);

    rc = ConvertTime(haTime, tmHa.tm_hour, tmHa.tm_min, tmHa.tm_sec);
    RAISE_ERR(rc, RTN);

    // 2. get current time
    char sCurrentTime[MAX_TIME_LEN];
    memset(sCurrentTime, 0, sizeof(sCurrentTime));
    rc = GetCurrentTime(sCurrentTime);
    RAISE_ERR(rc, RTN);

    char subCurTime[MAX_HA_TIME_LEN];
    memset(subCurTime, 0, sizeof(subCurTime));
    strncpy(subCurTime, sCurrentTime+9, 8);
    rc = ConvertTime(subCurTime, tmCurrent.tm_hour, tmCurrent.tm_min, tmCurrent.tm_sec);
    RAISE_ERR(rc, RTN);

    // 3. check
    if ((tmCurrent.tm_hour > tmHa.tm_hour)
            || (tmCurrent.tm_hour == tmHa.tm_hour && tmCurrent.tm_min > tmHa.tm_min)
            || (tmCurrent.tm_hour == tmHa.tm_hour && tmCurrent.tm_min == tmHa.tm_min && tmCurrent.tm_sec >= tmHa.tm_sec))
    {
        *isBegin = TRUE;
    }
    else
    {
        *isBegin = FALSE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 **
 ** LockRecord
 **     lock��ǰ��Ʒ����Ŷ�Ӧ�ļ�¼�������ݿ��е�ǰ��¼����lock����
 **     1. �ճ�����ʱ������lock��ǰ��¼
 **     2. �����ӹ�ʱ����������ȥlock��ǰ��¼��lock�ɹ���ӹ�
 **
 ******************************************************************************/
ResCodeT LockRecord(int64 iSetId)
{
    BEGIN_FUNCTION( "LockRecord" );
    ResCodeT rc = NO_ERR;

    int32       iSelId = 0;
    char        sql[100];

    memset(sql, 0, sizeof(sql));
    sprintf(sql, "SELECT * FROM active_info WHERE set_id = '%d' for update ", iSetId);

    rc = DbCmmnPrprSql(gLockConnId,sql, &iSelId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlNoRslt(gLockConnId, iSelId);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("Failed to execute sql select.");

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** ActiveKeeperInitWithoutConn
 **     active keeper ģ���ʼ��
 **
 ******************************************************************************/
ResCodeT ActiveKeeperInitWithoutConn()
{
    BEGIN_FUNCTION( "ActiveKeeperInitWithoutConn" );
    ResCodeT rc = NO_ERR;


    // Initialize Database Section for Lock
    struct cfgValueS cfgValue = {0};

    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnInit();
    RAISE_ERR(rc, RTN);

    // set the common gConnId
    rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &gConnId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &gLockConnId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveKeeperInit
 **     active keeper ģ���ʼ��
 **
 ******************************************************************************/
ResCodeT ActiveKeeperInit(int32 iConnId)
{
    BEGIN_FUNCTION( "ActiveKeeperInit" );
    ResCodeT rc = NO_ERR;


    // set the common gConnId
    gConnId = iConnId;


    // Initialize Database Section for Lock
    struct cfgValueS cfgValue = {0};

    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnInit();
    RAISE_ERR(rc, RTN);

    rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &gLockConnId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ActiveKeeperStop
 **     active keeper ģ������
 **
 ******************************************************************************/
ResCodeT ActiveKeeperStop()
{
    BEGIN_FUNCTION( "ActiveKeeperStop" );
    ResCodeT rc = NO_ERR;

    gLockStatus = HA_LOCK_INIT;

    rc = DbCmmnDisconnect(gConnId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnDisconnect(gLockConnId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCleanup();
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** InitPrimary
 **      �����ճ�����
 **
 ** return
 **      NO_ERR: �ɹ�
 **      others: ʧ��
 **
 ******************************************************************************/
ResCodeT InitPrimary(int64 iSetId)
{
    BEGIN_FUNCTION( "InitPrimary" );
    ResCodeT rc = NO_ERR;

    BOOL blIsPrimary = FALSE;
    rc = IsPrimary(iSetId, &blIsPrimary);
    RAISE_ERR(rc, RTN);

    // �ж��Ƿ�Ϊ����
    if (blIsPrimary == TRUE)
    {
        // ����lock��ǰ��¼
        rc = LockRecord(iSetId);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        RAISE_ERR( ERR_HA_INIT_PRIMARY_FAILED, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** InitBackup
 **      �����ճ�����
 **
 ** return
 **      NO_ERR: �ɹ�
 **      others: ʧ��
 **
 ******************************************************************************/
ResCodeT InitBackup(int64 iSetId)
{
    BEGIN_FUNCTION( "InitBackup" );
    ResCodeT rc = NO_ERR;

    BOOL    blIsBackup;

    // �ж��Ƿ�Ϊ����
    rc = IsBackup(iSetId, &blIsBackup);
    RAISE_ERR(rc, RTN);

    if (blIsBackup == FALSE)
    {
        RAISE_ERR( ERR_HA_INIT_BACKUP_FAILED, RTN );
    }

    BOOL isBegin;

    // �ж��Ƿ�HAʱ��
    rc = IsHaBegin(iSetId, &isBegin);
    RAISE_ERR(rc, RTN);

    if (isBegin == FALSE)
    {
        RAISE_ERR( ERR_HA_INIT_BACKUP_FAILED, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** BackupTakeover
 **      �����ӹ�
 **
 ** return
 **      NO_ERR: �ɹ�
 **      others: ʧ��
 **
 ******************************************************************************/
ResCodeT BackupTakeover(int64 iSetId, BOOL* blTackover)
{
    BEGIN_FUNCTION( "BackupTakeover" );
    ResCodeT rc = NO_ERR;

    *blTackover = FALSE;

    BOOL blIsBackup;
    rc = IsBackup(iSetId, &blIsBackup);
    RAISE_ERR(rc, RTN);

    BOOL isBegin;
    rc = IsHaBegin(iSetId, &isBegin);
    RAISE_ERR(rc, RTN);

    // �ж��Ƿ�Ϊ�����������Ѿ���HAʱ��
    if (blIsBackup && isBegin)
    {
        // ��������ȥlock��ǰ��¼��lock�ɹ���ӹ�
        rc = LockRecord(iSetId);
        RAISE_ERR(rc, RTN);

        *blTackover = TRUE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetAllSetIds
 **
 ******************************************************************************/
ResCodeT GetAllSetIds(vectorT * setIds)
{
    BEGIN_FUNCTION( "GetAllSetIds" );
    ResCodeT rc = NO_ERR;

    ActiveInfoHeadT head;
    rc = GetActiveHead(&head);
    RAISE_ERR(rc, RTN);

    memcpy(setIds, &head.allSetIds, sizeof(head.allSetIds));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetLocalLockStatus
 **
 ******************************************************************************/
ResCodeT GetLocalLockStatus(int16& status)
{
    BEGIN_FUNCTION( "GetLocalLockStatus" );
    ResCodeT rc = NO_ERR;

    status = gLockStatus;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** HaThreadMain
 **
 ******************************************************************************/
ResCodeT SendMsgToGateway(int64 iSetId)
{
    BEGIN_FUNCTION( "SendMsgToGateway" );
    ResCodeT        rc = NO_ERR;
    SlotT           slotId;
    pMsgCacheSlotT  pReqSlot;
    pMsgCacheSlotT  pRespSlot;
    pIntrnlMsgT     pReqMsg;
    pIntrnlMsgT     pRespMsg;

    LOG_DEBUG("Reserv Slot in SendMsgToGateway");


    rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot, &pRespSlot);
    RAISE_ERR( rc, RTN );

    pReqMsg = (pIntrnlMsgT)&pReqSlot->msgBody;
    pRespMsg = (pIntrnlMsgT)&pRespSlot->msgBody;


    // todo what's the body content ?
    pActiveInfoT    pActiveInfo;
    rc = ActiveInfoGetByIdExt(iSetId, &pActiveInfo);
    RAISE_ERR(rc, RTN);

    memcpy(pRespMsg->msgBody, pActiveInfo, sizeof(ActiveInfoT) );


    pRespMsg->msgHdr.msgLen += sizeof(MsgHdrT);
    pRespMsg->msgHdr.msgType = MSG_TYPE_MSG_TO_GATEWAY;
    pRespMsg->msgHdr.errCode = NO_ERR;

    memcpy(&pReqMsg->msgHdr,&pRespMsg->msgHdr, sizeof(sizeof(MsgHdrT)));


    rc = AppShlWriteSlotToBuff(slotId);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** HaThreadMain
 **
 ******************************************************************************/
void* HaThreadMain(void * args)
{
    BEGIN_FUNCTION( "HaThreadMain" );
    ResCodeT rc = NO_ERR;

    memset(g_strHostName, 0, sizeof(g_strHostName));
    if (gethostname(g_strHostName, sizeof(g_strHostName)) != 0)
    {
        RAISE_ERR(ERR_HA_GET_HOSTNAME_FAILED, NORTN);
        TRACE("Failed to get host name.");
        return NULL;
    }

    // get set id
    struct cfgValueS cfgValue;
    memset(&cfgValue, 0, sizeof(cfgValue));

    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, NORTN);
    if (rc != NO_ERR)
    {
        TRACE("Failed to get configuration.");
        return NULL;
    }

    int iSetId;
    iSetId = cfgValue.setId;


    BOOL blIsPrimary;
    blIsPrimary = FALSE;
    rc = IsPrimary(iSetId, &blIsPrimary);
    RAISE_ERR(rc, NORTN);
    if (rc != NO_ERR)
    {
        TRACE("Get primary failed");
        return NULL;
    }

    if (blIsPrimary == TRUE)
    {
        gLockStatus = HA_PRIMARY_LOCK_START;
        rc = InitPrimary(iSetId);
        RAISE_ERR(rc, NORTN);
        if (rc != NO_ERR)
        {
            gLockStatus = HA_PRIMARY_LOCK_FAILED;
            TRACE("Init primary failed");
            return NULL;
        }
        gLockStatus = HA_PRIMARY_LOCKING;
        LOG_INFO("Primary lock success.");
    }
    else
    {
        BOOL blIsBackup = FALSE;
        rc = IsBackup(iSetId, &blIsBackup);
        RAISE_ERR(rc, NORTN);
        if (rc != NO_ERR)
        {
            TRACE("Get backup failed");
            return NULL;
        }

        if (blIsBackup == TRUE)
        {
            rc = InitBackup(iSetId);
            RAISE_ERR(rc, NORTN);
            if (rc != NO_ERR)
            {
                TRACE("Init backup failed");
                return NULL;
            }

            BOOL blTackover = FALSE;
            gLockStatus = HA_BACKUP_LOCK_START;
            rc = BackupTakeover(iSetId, &blTackover);
            RAISE_ERR(rc, NORTN);
            if (rc != NO_ERR || blTackover == FALSE)
            {
                gLockStatus = HA_BACKUP_LOCK_FAILED;
                TRACE("Backup tackover failed.");
                return NULL;
            }
            gLockStatus = HA_BACKUP_LOCKING;
            LOG_INFO("Backup tackover success.");
        }
        else
        {
            RAISE_ERR(ERR_HA_INVALID_SERVER, NORTN);
            TRACE("Invalid server.");
            return NULL;
        }
    }


    EXIT_BLOCK();
    return NULL;
}
