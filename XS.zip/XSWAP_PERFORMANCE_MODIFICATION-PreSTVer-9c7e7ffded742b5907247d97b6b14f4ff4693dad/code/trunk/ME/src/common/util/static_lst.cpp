/***
Created on May 08, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>

#include "../include/static_lst.h"
#include "../include/err_cod.h"
/* to be removed when relevant DWRs are deliveried */

/* The below MARCORS are used for manipulating data types in share memory */
/* Therefore, pls use 64 pointer in these MACROS.  */
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
 
#ifdef EXTRACT_CONTAINER
#undef EXTRACT_CONTAINER
#endif


#define EXTRACT_CONTAINER(container, PTRTYPE, pRoot, slotSize, slotId)\
    if (NON_NULL_SLOT(slotId))\
    {\
        if (pOsSListMode->useMemFile)\
        {\
            RAISE_ERR( pOsSListMode->GetRecFunc((slotId), \
            (void **)&(container)), RTN);\
        }\
        else\
        {\
            (container) = (PTRTYPE)((char *)(pRoot) \
                + (uint64)(slotSize) * (uint64)(slotId));\
        }\
    }\
    else\
    {\
        (container) = (PTRTYPE)NULL;\
    }
#ifdef UPDATE_CONTAINER
#undef UPDATE_CONTAINER
#endif

#define UPDATE_CONTAINER(container)\
    if (pOsSListMode->useMemFile)\
    {\
        pOsSListMode->WriteRecFunc((void *)(container));\
    }

#ifdef EXTRACT_MEMBER_FROM_CONTAINER
#undef EXTRACT_MEMBER_FROM_CONTAINER
#endif

#define EXTRACT_MEMBER_FROM_CONTAINER(ptr, PTRTYPE, offset, pRoot)  \
    (ptr) = (PTRTYPE)((char *)(pRoot) + (offset))

#ifdef CHECK_EXISTENCE
#undef CHECK_EXISTENCE
#endif

/* if we don't re-initialize the slist entry after deletion, we can't perform
this check. so just define it NULL operation. */
#if REINIT_SLIST_ENTRY_AFTER_DEL
#define CHECK_EXISTENCE(pListEntry) \
    if (IN_VALID_SLIST(pListEntry)) \
    {\
        THROW_RESCODE(ERR_ITEM_ALREADY_EXIST_IN_LINKED_LIST);\
    }
#else
#define CHECK_EXISTENCE(pListEntry)
#endif

#ifndef SLIST_UPDATE_ITEM
#define SLIST_UPDATE_ITEM(slot, listEntry, newItem, theFrame)\
    do\
    {\
        if (theFrame)\
        {\
            long counter = (theFrame)->counter;\
            pLogItemSListT logItem = (theFrame)->logItem + counter;\
            logItem->slotNo = (slot);\
            memcpy(&logItem->data, (listEntry), sizeof (osSListEntryT));\
            (theFrame)->counter = -(counter + 1); \
            memcpy((listEntry), (newItem), sizeof (osSListEntryT));\
            (theFrame)->counter = -(theFrame)->counter;\
        }\
        else\
        {\
            memcpy((listEntry), (newItem), sizeof (osSListEntryT));\
        }\
    } while (0)
#endif


#ifndef NULL_SLOT
#define NULL_SLOT   (SlotT)-1
#endif

#ifndef NULL_SLOT_ID
#define NULL_SLOT_ID(slotId)    ((slotId) == NULL_SLOT)
#endif

#ifndef NON_NULL_SLOT
#define NON_NULL_SLOT(slotId)   ((slotId) != NULL_SLOT)
#endif

#ifndef SET_RESCODE_ON_COND
#define SET_RESCODE_ON_COND(rc, cond)\
    if (cond)\
    {\
        SET_RESCODE(rc);\
    }
#endif

#ifndef BREAK_ON_COND
#define BREAK_ON_COND(cond)\
    if (cond)\
    {\
        break;\
    }
#endif

#ifndef CONTINUE_ON_COND
#define CONTINUE_ON_COND(cond)\
    if (cond)\
    {\
        continue;\
    }
#endif

#ifndef UPDATE_VALUE_ON_COND
#define UPDATE_VALUE_ON_COND(val, newVal, cond)\
    if (cond)\
    {\
        (val) = (newVal);\
    }
#endif

#ifndef EXECUTE_ON_COND
#define EXECUTE_ON_COND(state, cond)\
    do { if (cond) {state;}} while (0)
#endif

#ifndef RAISE_ERROR_ON_COND
#define RAISE_ERROR_ON_COND(errCode, cond)\
    if (cond)\
    {\
        RAISE_ERR((errCode), RTN);\
    }
#endif

#ifndef SET_PTR_VALUE
#define SET_PTR_VALUE(ptr, value) do { if (ptr) *(ptr) = (value);} while (0)
#endif

/* validate the initializatio parameter for static link list */
static ResCodeT CheckSListMode(const pOsSListModeT pOsSListMode);
/*---------------------------------GLOBAL VARIABLES---------------------------*/

/*---------------------------------IMPLEMENTATION-----------------------------*/
ResCodeT CheckSListMode(const pOsSListModeT pOsSListMode)
{
    BEGIN_FUNCTION("CheckSListMode");

    ASSERT(pOsSListMode);

    THROW_RESCODE_ON_COND(ERR_INVLD_STATIC_LINK_LIST_MODE,
        !pOsSListMode->pListHead);
    THROW_RESCODE_ON_COND(ERR_INVLD_STATIC_LINK_LIST_ADDRESS,
        !pOsSListMode->pRoot);
    THROW_RESCODE_ON_COND(ERR_INVLD_STATIC_LINK_LIST_SLOT_SIZE,
        !pOsSListMode->slotSize);
    THROW_RESCODE_ON_COND(ERR_INVLD_KEY_CMP_FUNC,
        pOsSListMode->sortType != NON_SORTED && !pOsSListMode->CompareKeyFunc);
    THROW_RESCODE_ON_COND(ERR_INVLD_OFFSET_VALUE_OF_STATIC_LINK_LIST_HEAD,
        pOsSListMode->listEntryOffset > pOsSListMode->slotSize ||
        pOsSListMode->slotIdOffset > pOsSListMode->slotSize ||
        pOsSListMode->keyOffset > pOsSListMode->slotSize);
    THROW_RESCODE_ON_COND(ERR_INVLD_MEM_FILE_FUNC, pOsSListMode->useMemFile &&
        (!pOsSListMode->GetRecFunc || !pOsSListMode->WriteRecFunc));

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
* Description:   Insert an entry into the specified static linked list. If the
* list is sorted, then scan forwards from the head of the list to find the
* insertion position; otherwise insert it before the head item;
* NB: same record can't be inserted more than once. according to configuration,
* different entries with same key can or can't be inserted. for non-sorted list
* , the function won't check the possibility of duplicate keys. Before
* inserting, be sure that the list entry has been initialized by calling
* INIT_STATIC_LIST_ENTRY(), otherwise insertion will fail!
* Parameters:
*  pOsSListMode    IN  control information for the list.
*  rec IN  The entry to be inserted.
*  pHeadDirty  OUT flag to indicate the head of the list has been changed.
*              (can be NULL)
*  pTailDirty      OUT flag to indicate the tail of the list has been changed.
*              (can be NULL)
*  out OUT Write to the found linked list item in case duplicate obj exists.
*  tryInsert   IN  indicate trying to rathan than actually insert the entry. if
*                  TRUE, then fill the slot ID of the prv entry in pPrevSlotId
*  pPrevSlotId OUT If tryInsert == TRUE, then return the slot ID of the
*              previous slot ID.
* Return Value         :
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to insert the item to the list.
******************************************************************************/
ResCodeT InsertSListEntryFromHead(const pOsSListModeT pOsSListMode,
void * rec, BOOL *pHeadDirty, BOOL *pTailDirty, void * *out, BOOL tryInsert,
SlotT * pPrevSlotId)
{
    BEGIN_FUNCTION("InsertSListEntryFromHead");
    void * lstEntry;  /* last item */
    void * currEntry;  /* next item */

    SlotT slotId,  /* slot ID of incoming item */
            last,       /* slot ID of last item */
            curr;       /* slot ID of next item */

    pOsSListEntryT pHeadEntry, /* for list head entry */
                    pListEntry,     /* for list entry of incoming item */
                    lstListEntry,   /* for list entry of last item */
                    currListEntry;  /* for list entry of next item */

    pFrameSListT theFrame = pOsSListMode->theFrame;
    osSListEntryT newData, newHead;
    char dirty = 0;
    long cmpSts = -1;
    void * key1;
    void * key2;
        
    SlotT * pSlotId;
    if (theFrame)
    {
        theFrame->counter = 0;
    }

    ASSERT(pOsSListMode && rec)

    RAISE_ERR(CheckSListMode(pOsSListMode), RTN);
    RAISE_ERROR_ON_COND(ERR_INVLD_PTR_TO_SLOT_ID, tryInsert && !pPrevSlotId);

    pHeadEntry = pOsSListMode->pListHead;

    newHead = *pHeadEntry;

    EXTRACT_MEMBER_FROM_CONTAINER(pSlotId, SlotT *,
        pOsSListMode->slotIdOffset, rec);
    slotId = *pSlotId;
    EXTRACT_MEMBER_FROM_CONTAINER(pListEntry, pOsSListEntryT,
        pOsSListMode->listEntryOffset, rec);
    CHECK_EXISTENCE(pListEntry);

    last = NULL_SLOT;
    lstEntry = NULL;
    lstListEntry = NULL;
    curr = pHeadEntry->next;
    currEntry = NULL;
    currListEntry = NULL;
    
    /* for non-sorted list, we have remember the last and next position, and
    the new item will be inserted between them. so we continue with sorted
    cases to find the right insertion position. */
    if (pOsSListMode->sortType != NON_SORTED)
    {   /* sorted list, find the right position to insert the new item */


        EXTRACT_MEMBER_FROM_CONTAINER(key2, char *, pOsSListMode->keyOffset,
            rec);
        while (NON_NULL_SLOT(curr))
        {
            EXTRACT_CONTAINER(currEntry, char *, pOsSListMode->pRoot,
                pOsSListMode->slotSize, curr);
            EXTRACT_MEMBER_FROM_CONTAINER(currListEntry, pOsSListEntryT,
                    pOsSListMode->listEntryOffset, currEntry);
            EXTRACT_MEMBER_FROM_CONTAINER(key1, char *,
                pOsSListMode->keyOffset, currEntry);


            cmpSts = pOsSListMode->CompareKeyFunc(key1, key2);
            EXECUTE_ON_COND(cmpSts = -cmpSts, pOsSListMode->sortType ==
                DESCENDING);
            BREAK_ON_COND(cmpSts >= 0);
            last = curr;
            lstEntry = currEntry;
            lstListEntry = currListEntry;
            curr = currListEntry->next;
        }
        if (!cmpSts)
        {
            if (!pOsSListMode->allowDuplicateKey)
            {
                SET_PTR_VALUE(out, currEntry);
                THROW_RESCODE(ERR_DUPLICATE_KEY_IN_LINKED_LIST);
            }
            /* same record is not allowed to be inserted more than once */
            THROW_RESCODE_ON_COND(ERR_DUPLICATE_OBJ_IN_LINKED_LIST,
                slotId == curr);
        }
    }
    UPDATE_VALUE_ON_COND(*pPrevSlotId, last, tryInsert);
    THROW_RESCODE_ON_COND(NO_ERR, tryInsert);

    newData.prev= last;
    newData.next = curr;

    SLIST_UPDATE_ITEM(slotId, pListEntry, &newData, theFrame);
    UPDATE_CONTAINER(rec);
    if (last == pHeadEntry->prev)
    {
        newHead.prev = slotId;
        dirty = 1;
        DIRTY(pTailDirty);
    }
    else    /*if (NON_NULL_SLOT(curr))*/
    {
        /* NB: in some cases, currEntry and currListEntry are NULL pointer
        here. eg: the rec is inserted to the head of a non-sorted list. */
        EXECUTE_ON_COND( EXTRACT_CONTAINER(currEntry, char *,
            pOsSListMode->pRoot, pOsSListMode->slotSize, curr), !currEntry);
        EXECUTE_ON_COND( EXTRACT_MEMBER_FROM_CONTAINER(currListEntry,
            pOsSListEntryT, pOsSListMode->listEntryOffset, currEntry),
            !currListEntry);

        newData.prev = slotId;
        newData.next = currListEntry->next;
        SLIST_UPDATE_ITEM(curr, currListEntry, &newData, theFrame);
        UPDATE_CONTAINER(currEntry);
    }

    if (/*NULL_SLOT_ID(last)*/curr == pHeadEntry->next)
    {
        newHead.next = slotId;
        if (!dirty)
        {
            dirty = 1;
        }
        DIRTY(pHeadDirty);
    }
    else
    {
        newData.next = slotId;
        newData.prev = lstListEntry->prev;

        SLIST_UPDATE_ITEM(last, lstListEntry, &newData, theFrame);
        UPDATE_CONTAINER(lstEntry);

    }

    if (dirty)
    {
        SLIST_UPDATE_ITEM(-1, pHeadEntry, &newHead, theFrame);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
* Description:   Insert an entry into the specified static linked list. If the
* list is sorted, then scan backwards from the tail of the list to find the
*  insertion; otherwise insert it before the head item;
* NB: for sorted lists, same record can't be inserted more than once. but for
* non-sorted lists, the function won't check. so be careful with non-sorted
* list! Before inserting, be sure that the list entry has been initialized by
* calling INIT_STATIC_LIST_ENTRY(), otherwise insertion will fail!
* Parameters:
*  pOsSListMode    IN  control information for the list.
*  rec IN  The entry to be inserted.
*  pHeadDirty  OUT flag to indicate the head of the list has been changed.
*              (can be NULL)
*  pTailDirty      OUT flag to indicate the tail of the list has been changed.
*              (can be NULL)
*  out OUT Write to the found linked list item in case duplicate obj exists.
*  tryInsert   IN  indicate trying to rathan than actually insert the entry. if
*                  TRUE, then fill the slot ID of the prv entry in pPrevSlotId
*  pPrevSlotId OUT If tryInsert == TRUE, then return the slot ID of the
*              previous slot ID.
* Return Value         :
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to insert the item to the list.
******************************************************************************/
ResCodeT InsertSListEntryFromTail(const pOsSListModeT pOsSListMode,
void * rec, BOOL *pHeadDirty, BOOL *pTailDirty, void * *out, BOOL tryInsert,
SlotT * pPrevSlotId)
{
    BEGIN_FUNCTION("InsertSListEntryFromTail");
    void * lstEntry; /* last item */
    void * currEntry;  /* next item */

    SlotT slotId, /* slot ID of incoming item */
            last,   /* slot ID of last item */
            curr; /* slot ID of next item */

    pOsSListEntryT pHeadEntry, /* for list head entry */
                    pListEntry,     /* for list entry of incoming item */
                    lstListEntry,   /* for list entry of last item */
                    currListEntry;  /* for list entry of next item */

    pFrameSListT theFrame = pOsSListMode->theFrame;
    osSListEntryT newData, newHead;
    char dirty = 0;
    SlotT * pSlotId;
    long cmpSts = -1;
    void * key1;
    void *  key2;
        
    if (theFrame)
    {
        theFrame->counter = 0;
    }

    ASSERT(pOsSListMode && rec);

    RAISE_ERR(CheckSListMode(pOsSListMode), RTN);
    RAISE_ERROR_ON_COND(ERR_INVLD_PTR_TO_SLOT_ID, tryInsert && !pPrevSlotId);

    pHeadEntry = pOsSListMode->pListHead;

    newHead = *pHeadEntry;


    EXTRACT_MEMBER_FROM_CONTAINER(pSlotId, SlotT *,
        pOsSListMode->slotIdOffset, rec);
    slotId = *pSlotId;
    EXTRACT_MEMBER_FROM_CONTAINER(pListEntry, pOsSListEntryT,
        pOsSListMode->listEntryOffset, rec);
    CHECK_EXISTENCE(pListEntry);
    curr = NULL_SLOT;
    currListEntry = NULL;
    currEntry = NULL;
    last = pHeadEntry->prev;
    lstEntry = NULL;
    lstListEntry = NULL;

    /* for non-sorted list, we have remember the last and next position, and
    the new item will be inserted between them. so we continue with sorted
    cases to find the right insertion position. */
    if (pOsSListMode->sortType != NON_SORTED)
    {   /* sorted list, find the right position to insert the new item */


        EXTRACT_MEMBER_FROM_CONTAINER(key2, char *, pOsSListMode->keyOffset,
            rec);
        while (NON_NULL_SLOT(last))
        {
            EXTRACT_CONTAINER(lstEntry, char *, pOsSListMode->pRoot,
                pOsSListMode->slotSize, last);
            EXTRACT_MEMBER_FROM_CONTAINER(lstListEntry, pOsSListEntryT,
                    pOsSListMode->listEntryOffset, lstEntry);
            EXTRACT_MEMBER_FROM_CONTAINER(key1, char *,
                pOsSListMode->keyOffset, lstEntry);

            cmpSts = pOsSListMode->CompareKeyFunc(key1, key2);
            EXECUTE_ON_COND(cmpSts = -cmpSts, pOsSListMode->sortType ==
                DESCENDING);
            BREAK_ON_COND(cmpSts <= 0);
            curr = last;
            currEntry = lstEntry;
            currListEntry = lstListEntry;
            last = lstListEntry->prev;
        }
        if (!cmpSts)
        {
            if (!pOsSListMode->allowDuplicateKey)
            {
                SET_PTR_VALUE(out, lstEntry);
                THROW_RESCODE(ERR_DUPLICATE_KEY_IN_LINKED_LIST);
            }
            /* same record is not allowed to be inserted more than once */
            THROW_RESCODE_ON_COND(ERR_DUPLICATE_OBJ_IN_LINKED_LIST, slotId ==
            last);
        }
    }

    UPDATE_VALUE_ON_COND(*pPrevSlotId, last, tryInsert);
    THROW_RESCODE_ON_COND(NO_ERR, tryInsert);

    newData.prev = last;
    newData.next = curr;

    SLIST_UPDATE_ITEM(slotId, pListEntry, &newData, theFrame);
    UPDATE_CONTAINER(rec);

    if (/*NULL_SLOT_ID(curr)*/last == pHeadEntry->prev)
    {
        newHead.prev = slotId;
        dirty = 1;
        DIRTY(pTailDirty);
    }
    else
    {
        newData.prev = slotId;
        newData.next = currListEntry->next;

        SLIST_UPDATE_ITEM(curr, currListEntry, &newData, theFrame);
        UPDATE_CONTAINER(currEntry);
    }

    if (curr == pHeadEntry->next)
    {
        newHead.next = slotId;
        if (!dirty)
        {
            dirty = 1;
        }
        DIRTY(pHeadDirty);
    }
    else    /*if (NON_NULL_SLOT(last))*/
    {
        /* NB: in some cases, lstEntry and lstListEntry are NULL pointer
        here. eg: the rec is inserted to the tail of a non-sorted list. */

        EXECUTE_ON_COND( EXTRACT_CONTAINER(lstEntry, char *,
            pOsSListMode->pRoot, pOsSListMode->slotSize, last), !lstEntry);
        EXECUTE_ON_COND( EXTRACT_MEMBER_FROM_CONTAINER(lstListEntry,
            pOsSListEntryT, pOsSListMode->listEntryOffset, lstEntry),
            !lstListEntry);
        newData.next = slotId;
        newData.prev = lstListEntry->prev;

        SLIST_UPDATE_ITEM(last, lstListEntry, &newData, theFrame);
        UPDATE_CONTAINER(lstEntry);
    }

    if (dirty)
    {
        SLIST_UPDATE_ITEM(-1, pHeadEntry, &newHead, theFrame);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Iterate over the specified static linked list.
 *  pOsSListMode    IN  control information for the list.
 *  ProcessLinkListNodeFunc IN  The function to process each entry.
 *  stopOnError IN  Flag to indicate whether to stop processing when error
 *                  occurs.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to delete an entry from the list.
 ******************************************************************************/
ResCodeT IterateSList(const pOsSListModeT pOsSListMode,
    ResCodeT (*ProcessLinkListNodeFunc)(void * pListNode, void * context),
    void * context, BOOL stopOnError)
{
    BEGIN_FUNCTION("IterateSList");
    ResCodeT rc;
    SlotT curr;
    char * entry;

    ASSERT(pOsSListMode && ProcessLinkListNodeFunc);

    RAISE_ERR( CheckSListMode(pOsSListMode), RTN);
    curr = pOsSListMode->pListHead->next;
    while (NON_NULL_SLOT(curr))
    {
        SlotT victim = curr;

        pOsSListEntryT listEntry;

        EXTRACT_CONTAINER(entry, char *, pOsSListMode->pRoot,
            pOsSListMode->slotSize, victim);
        EXTRACT_MEMBER_FROM_CONTAINER(listEntry, pOsSListEntryT,
            pOsSListMode->listEntryOffset, entry);

        curr = listEntry->next;
        rc = ProcessLinkListNodeFunc(entry, context);
/*        UPDATE_CONTAINER(entry);*/
        THROW_RESCODE_ON_COND(rc, NOTOK(rc) && stopOnError);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Remove an entry from the specified linked list.
 * Parameters:
 *  pOsSListMode    IN  control information for the list.
 *  rec IN  The entry to be removed.
 *  pHeadDirty  OUT flag to indicate the head of the list has been changed.
 *              (can be NULL)
 *  pTailDirty      OUT flag to indicate the tail of the list has been changed.
 *              (can be NULL)
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to delete an entry from the list.
 ******************************************************************************/
ResCodeT DelSListEntry(const pOsSListModeT pOsSListMode, void * rec, BOOL
*pHeadDirty, BOOL *pTailDirty)
{
    BEGIN_FUNCTION("DelSListEntry");
    pOsSListEntryT headEntry,
                    listEntry;
    SlotT * pSlotId;
    SlotT slotId;

    pFrameSListT theFrame = pOsSListMode->theFrame;
    osSListEntryT newData, newHead;
    char dirty = 0;
    char * lstEntry;
    pOsSListEntryT lstListEntry;
    char * nxtEntry;

    if (theFrame)
    {
        theFrame->counter = 0;
    }

    ASSERT(pOsSListMode && rec);
    RAISE_ERR(CheckSListMode(pOsSListMode), RTN);

    EXTRACT_MEMBER_FROM_CONTAINER(listEntry, pOsSListEntryT,
        pOsSListMode->listEntryOffset, rec);
    EXTRACT_MEMBER_FROM_CONTAINER(pSlotId, SlotT *,
        pOsSListMode->slotIdOffset, rec);

    slotId = *pSlotId;

    headEntry = pOsSListMode->pListHead;

    //newHead = *headEntry;
    memcpy(&newHead, headEntry, sizeof(osSListEntryT));

    if (NON_NULL_SLOT(listEntry->prev))
    {


        EXTRACT_CONTAINER(lstEntry, char *, pOsSListMode->pRoot,
            pOsSListMode->slotSize, listEntry->prev);
        EXTRACT_MEMBER_FROM_CONTAINER(lstListEntry, pOsSListEntryT,
            pOsSListMode->listEntryOffset, lstEntry);

        newData.next = listEntry->next;
        newData.prev = lstListEntry->prev;

        SLIST_UPDATE_ITEM(listEntry->prev,lstListEntry, &newData, theFrame);
        UPDATE_CONTAINER(lstEntry);

    }
    else
    {
        newHead.next = listEntry->next;
        dirty = 1;
        DIRTY(pHeadDirty);
    }

    if (NON_NULL_SLOT(listEntry->next))
    {

        pOsSListEntryT nxtListEntry;

        EXTRACT_CONTAINER(nxtEntry, char *, pOsSListMode->pRoot,
            pOsSListMode->slotSize, listEntry->next);
        EXTRACT_MEMBER_FROM_CONTAINER(nxtListEntry, pOsSListEntryT,
            pOsSListMode->listEntryOffset, nxtEntry);

        newData.prev = listEntry->prev;
        newData.next = nxtListEntry->next;

        SLIST_UPDATE_ITEM(listEntry->next, nxtListEntry, &newData, theFrame);
        UPDATE_CONTAINER(nxtEntry);

    }
    else
    {
        newHead.prev = listEntry->prev;
        if (!dirty)
        {
            dirty = 1;
        }
        DIRTY(pTailDirty);
    }

    #if REINIT_SLIST_ENTRY_AFTER_DEL
    INIT_STATIC_LIST_ENTRY(listEntry);
    #endif

    if (dirty)
    {
        SLIST_UPDATE_ITEM(-1, headEntry, &newHead, theFrame);
    }

    EXIT_BLOCK();

    EXECUTE_ON_COND( UPDATE_CONTAINER(rec), OK(GET_RESCODE()));

    RETURN_RESCODE;
}

/*******************************************************************************
 * Description:   Find an item in the specified static linked list.
 * Parameters:
 *      pOsSListMode    IN  control information for the list.
 *      key IN  the key to find the rec.
 *      out OUT Write to the found linked list item.
 *      This function searches for an item with a given key.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT FindSListEntryByKey(const pOsSListModeT pOsSListMode, void * key,
void * *out)
{
    BEGIN_FUNCTION("FindSListEntryByKey");
    SlotT curr = NULL_SLOT;
    char * currEntry = NULL;
    pOsSListEntryT currListEntry = NULL, headEntry;
        int cmpSts;



    ASSERT(pOsSListMode && key && out)
    RAISE_ERR( CheckSListMode(pOsSListMode), RTN);

    headEntry = pOsSListMode->pListHead;
    curr = headEntry->next;
    cmpSts = -1;
    while (NON_NULL_SLOT(curr))
    {
        void * key0;

        EXTRACT_CONTAINER(currEntry, char *, pOsSListMode->pRoot,
            pOsSListMode->slotSize, curr);
        EXTRACT_MEMBER_FROM_CONTAINER(key0, void *, pOsSListMode->keyOffset,
            currEntry);

        cmpSts = pOsSListMode->CompareKeyFunc(key0, key);
        EXECUTE_ON_COND(cmpSts = -cmpSts, pOsSListMode->sortType == DESCENDING);
        BREAK_ON_COND(!cmpSts
            || pOsSListMode->sortType != NON_SORTED && cmpSts > 0);
        EXTRACT_MEMBER_FROM_CONTAINER(currListEntry, pOsSListEntryT,
            pOsSListMode->listEntryOffset, currEntry);
        curr = currListEntry->next;
    }
    if (!cmpSts)
    {
        *out = (void *)currEntry;
    }
    else
    {
        THROW_RESCODE(ERR_OBJ_NOT_IN_LINKED_LIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetSListHead(const pOsSListModeT pOsSListMode, void * *out)
{
    BEGIN_FUNCTION("GetSListHead");
    SlotT headSlotId;
    ASSERT(pOsSListMode && out);
    RAISE_ERR(CheckSListMode(pOsSListMode), RTN);

    headSlotId = pOsSListMode->pListHead->next;

    EXTRACT_CONTAINER(*out, void *, pOsSListMode->pRoot,
        pOsSListMode->slotSize, headSlotId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetSListTail(const pOsSListModeT pOsSListMode, void * *out)
{
    BEGIN_FUNCTION("GetSListTail");
    SlotT tailSlotId;
    ASSERT(pOsSListMode && out);
    RAISE_ERR(CheckSListMode(pOsSListMode), RTN);

    tailSlotId = pOsSListMode->pListHead->prev;

    EXTRACT_CONTAINER(*out, void *, pOsSListMode->pRoot,
        pOsSListMode->slotSize, tailSlotId);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetSListNext(const pOsSListModeT pOsSListMode,
                        void * *out,
                        SlotT *curr)
{
    BEGIN_FUNCTION("GetSListNext");
    SlotT headSlotId;
    pOsSListEntryT listEntry;
    ASSERT(pOsSListMode && out);
    RAISE_ERR(CheckSListMode(pOsSListMode), RTN);
    if (NULL_SLOT_ID(*curr))
    /*first time. get list head and return directly */
    {
        *curr = pOsSListMode->pListHead->next;
    }
    else
    {
        EXTRACT_CONTAINER(*out, 
            void *, 
            pOsSListMode->pRoot,
            pOsSListMode->slotSize,
            *curr);
        EXTRACT_MEMBER_FROM_CONTAINER(listEntry,
            pOsSListEntryT,
            pOsSListMode->listEntryOffset,
            *out);
        *curr = listEntry->next;
    }

    /* retrieve the next container */
    EXTRACT_CONTAINER(*out,
        void *,
        pOsSListMode->pRoot,
        pOsSListMode->slotSize,
        *curr);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SListUpdateRef(const pOsSListModeT pOsSListMode,
                        const void * rec,
                        const SlotT oldSlot,
                        BOOL *pHeadDirty,
                        BOOL *pTailDirty)
{
    BEGIN_FUNCTION("SListUpdateRef");

    pOsSListEntryT headEntry,
                    listEntry;

    pFrameSListT theFrame = pOsSListMode->theFrame;

    osSListEntryT newData, newHead;
    char dirty = 0;
    char * nxtEntry;
    pOsSListEntryT nxtListEntry;


    if (theFrame)
    {
        theFrame->counter = 0;
    }


    ASSERT(pOsSListMode && rec);
    RAISE_ERR( CheckSListMode(pOsSListMode), RTN);

    EXTRACT_MEMBER_FROM_CONTAINER(listEntry, pOsSListEntryT,
        pOsSListMode->listEntryOffset, rec);

    headEntry = pOsSListMode->pListHead;

    //
    //newHead = *headEntry;
    memcpy(&newHead, headEntry, sizeof(osSListEntryT));

    if (NON_NULL_SLOT(listEntry->prev))
    {
        char * lstEntry;
        pOsSListEntryT lstListEntry;

        EXTRACT_CONTAINER(lstEntry, char *, pOsSListMode->pRoot,
            pOsSListMode->slotSize, listEntry->prev);
        EXTRACT_MEMBER_FROM_CONTAINER(lstListEntry, pOsSListEntryT,
            pOsSListMode->listEntryOffset, lstEntry);

        if (lstListEntry->next != oldSlot)
        {
            newData.next = oldSlot;
            newData.prev = lstListEntry->prev;

            SLIST_UPDATE_ITEM(listEntry->prev,lstListEntry, &newData, theFrame);
            UPDATE_CONTAINER(lstEntry);

        }
    }
    else
    {
        if (headEntry->next != oldSlot)
        {
            newHead.next = oldSlot;
            dirty = 1;
        }
        DIRTY(pHeadDirty);
    }

    if (NON_NULL_SLOT(listEntry->next))
    {

        EXTRACT_CONTAINER(nxtEntry, char *, pOsSListMode->pRoot,
            pOsSListMode->slotSize, listEntry->next);
        EXTRACT_MEMBER_FROM_CONTAINER(nxtListEntry, pOsSListEntryT,
            pOsSListMode->listEntryOffset, nxtEntry);

        if (nxtListEntry->prev != oldSlot)
        {
            newData.prev = oldSlot;
            newData.next = nxtListEntry->next;

            SLIST_UPDATE_ITEM(listEntry->next,nxtListEntry, &newData, theFrame);
            UPDATE_CONTAINER(nxtEntry);

        }
    }
    else
    {
        if (headEntry->prev != oldSlot)
        {
            newHead.prev = oldSlot;
            if (!dirty)
            {
                dirty = 1;
            }
        }
        DIRTY(pTailDirty);
    }

    if (dirty)
    {
        SLIST_UPDATE_ITEM(-1, headEntry, &newHead, theFrame);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Rollback whatever changes have been made to the specified
 *  static linked list.
 *  The interface will scan backwards the frame data of the static linked list,
 *  and rollback each change made to the linked list one by one.
 * Parameters:
 *  pOsSListMode    IN  control information for the list.
 * Return Value         :
 *  NO_ERR:     Successful
 *  ERR_<DSCR>: fail to insert the item to the list.
 ******************************************************************************/
ResCodeT SListRollBack(const pOsSListModeT pOsSListMode)
{
    BEGIN_FUNCTION("SListRollBack");
    pFrameSListT theFrame = pOsSListMode->theFrame;
    pLogItemSListT logItem = theFrame->logItem + theFrame->counter - 1;
    char * entry;
    pOsSListEntryT listEntry;

    while (theFrame->counter)
    {
        /* loop until the counter counts down to 0 */
        if (theFrame->counter > 0)
        {
            theFrame->counter = -theFrame->counter;
        }

        if ((SlotT)-1 == logItem->slotNo)
        {
            /* the list head/tail was changed. */
            memcpy(pOsSListMode->pListHead, (pOsSListEntryT)&logItem->data,
                sizeof (osSListEntryT));
        }
        else
        {
            /* an item is updated. */

            EXTRACT_CONTAINER(entry, char *, pOsSListMode->pRoot,
                pOsSListMode->slotSize, logItem->slotNo);
            EXTRACT_MEMBER_FROM_CONTAINER(listEntry, pOsSListEntryT,
                pOsSListMode->listEntryOffset, entry);

            memcpy(listEntry, (pOsSListEntryT)&logItem->data, sizeof (osSListEntryT));
        }

        theFrame->counter = -theFrame->counter;
        theFrame->counter--;
        logItem--;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

