/***
Created on Aug 11, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files*/
#include "err_lib.h"
#include "common_macro.h"

#include "sys_st_rsrc.h"
#include "pck_irs_dicdata.h"
#include "base_param.h"
#include "base_param_api.h"
#include "usr.h"
#include "org_info.h"
#include "usr_role.h"
#include "uti_tool.h"

#include "api_common.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 **
 ** ApiCommonCheck
 **     parameters:
 **         [IN] strUserId  �û���ʶ
 **         [IN] strOrgCd   ������ʶ
 **         [IN] iFuncId    ���ܱ�ʶ
 **         [IN] strToken   Token
 **         [IN] iMktType   Market Type
 **         [OUT] iOrgId    �����û���ѯ���Ļ�����ʶ
 **
 ******************************************************************************/
ResCodeT ApiCommonCheck(
                char*       strUserId,
                char*       strOrgCd,
                int32       iFuncId,
                char*       strToken,
                int32       iMktType,
                int64       timestamp,
                int32*      iOrgId
                )
{
    BEGIN_FUNCTION( "ApiCommonCheck" );
    ResCodeT rc = NO_ERR;


    // ��ȡ�г�״̬
    pBaseParamT pParamData;
    int         iMktState;
    if (iMktType == 1)
    {
        rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
        RAISE_ERR(rc, RTN);
        iMktState = atoi(pParamData->paramValue);

        if (iMktState == C_MKT_ST_CLOSEQT_IRS)
        {
            iMktState = C_MKT_ST_CLOSEQT;
        }
    }
    else
    {
        rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pParamData);
        RAISE_ERR(rc, RTN);
        iMktState = atoi(pParamData->paramValue);
    }


    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(strUserId, &pUserInfo);
    RAISE_ERR(rc, RTN);

    // �Ƿ��½
    if (strcmp(pUserInfo->apiF, "1") != 0 || pUserInfo->usrOnlnStatus == FALSE)
    {
        if (iFuncId == C_API_USERLOGOUT_FUNCID)
        {
            RAISE_ERR(ERR_CODE_INVLD_NOT_LOGON, RTN);
        }
        else
        {
            RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
        }
    }

    // �ж�Token
    if (strToken == NULL || strcmp(pUserInfo->sesnId, strToken) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_TOKEN, RTN);
    }


    // ��ȡusr��Ӧ�Ļ���CD������ID�����ȶ�CD�Ƿ�һ��
    pOrgInfoT pOrgData;
    rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgData);
    RAISE_ERR(rc, RTN);
    if (strcmp(strOrgCd, pOrgData->orgCd) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_ORG_CD, RTN);
    }

    *iOrgId = pUserInfo->orgId;


    if (iFuncId == C_API_RISKUPDATE_FUNCID
            || iFuncId == C_API_CREDITUPDATE_FUNCID
            || iFuncId == C_API_RISKQUERY_FUNCID
            || iFuncId == C_API_CREDITQUERY_FUNCID)
    {
        if (pUserInfo->roleId[C_APIUSER_ROLE_CRDT-1] != 1)
        {
            RAISE_ERR(APIERR_CODE_INVLD_ROLE_PRV, RTN);
        }

        if (iFuncId == C_API_RISKUPDATE_FUNCID || iFuncId == C_API_CREDITUPDATE_FUNCID)
        {
            // check time according to BASE_PARAM_API table
            pBaseParamApiT pParamApiData;
            char strStartTime[MAX_TIME_LEN];
            char strEndTime[MAX_TIME_LEN];
            char strCurrTime[MAX_TIME_LEN];

            rc = GetCurrentTime(strCurrTime);
            RAISE_ERR(rc, RTN);
            strncpy(strStartTime, strCurrTime, 9);
            strncpy(strEndTime, strCurrTime, 9);

            rc = BaseParamApiGetByNameExt((char*)C_API_CRDT_TIME_START, &pParamApiData);
            RAISE_ERR(rc, RTN);
            strcat(strStartTime, pParamApiData->paramValue);
            strcat(strStartTime, ":00");

            rc = BaseParamApiGetByNameExt((char*)C_API_CRDT_TIME_END, &pParamApiData);
            RAISE_ERR(rc, RTN);
            strcat(strEndTime, pParamApiData->paramValue);
            strcat(strEndTime, ":00");

            int64 iStartTime, iEndTime;
            rc = DateTimeToTimestamp(strStartTime, &iStartTime);
            RAISE_ERR(rc, RTN);
            rc = DateTimeToTimestamp(strEndTime, &iEndTime);
            RAISE_ERR(rc, RTN);

            if (iStartTime > timestamp || iEndTime < timestamp)
            {
                RAISE_ERR(APIERR_CODE_INVLD_CRDT_MDFY_TM, RTN);
            }

            if (pOrgData->crdtOprtngSt == C_CRT_OPERATING)
            {
                RAISE_ERR(APIERR_CODE_CRT_MODIFYING, RTN);
            }
        }
    }
    else if (iFuncId == C_API_SUBSCRIBE_FUNCID)
    {
        if (pUserInfo->roleId[C_APIUSER_ROLE_QUOT-1] != 1)
        {
            RAISE_ERR(APIERR_CODE_INVLD_ROLE_PRV, RTN);
        }
    }
    else if (iFuncId == C_API_ORDCANCEL_FUNCID || iFuncId == C_API_ORDERSUBMIT_FUNCID)
    {
        if (pUserInfo->roleId[C_APIUSER_ROLE_DEAL-1] != 1)
        {
            RAISE_ERR(APIERR_CODE_INVLD_ROLE_PRV, RTN);
        }

        // �жϻ����Ƿ񱻽���,���������ò����ᵥ
        if (pOrgData->orgIrsSt != C_ORG_ST_ACTIVE)
        {
            RAISE_ERR(APIERR_CODE_ORG_FORBID, RTN);
        }

        // �жϸ��г�״̬�Ƿ�����ִ�д˹���
        pSysStRsrcT pSysStatus;
        rc = SysStRsrcGetByKeyExt(iFuncId, iMktState, &pSysStatus);
        if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST)
        {
            /* The function is not permitted to execute this function */
            RAISE_ERR(ERR_CODE_INVLD_MKT_NOT_PMT, RTN);
        }
        else
        {
            RAISE_ERR(rc, RTN);
        }
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT CheckApiUserRole(int32 (&pRoleId)[ROLE_ID_MAX_COUNT], int32& iUserRole)
{
    BEGIN_FUNCTION( "CheckApiUserRole" );
    ResCodeT rc = NO_ERR;

    if (NULL == pRoleId)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }

    // ��ȡ�û����ͣ�ÿ��API�û�����Ӧһ��Ȩ��
    int32 count;
    count = 0;
    for (int i = 1; i <= ROLE_ID_MAX_COUNT; i++)
    {
        if (pRoleId[i-1] != 0)
        {
            count++;
            iUserRole = i;
            if (count > 1)
            {
                RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
            }
        }
    }

    if (count != 1)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UserCheck
 ** ��鷢���û���ǰ̨ʵ���û����Ƿ�һ��
 **     parameters:
 **         [IN] usrIdHeader   �����û�ID��ʶ��api�û���
 **         [IN] orgCdHeader   ���𷽻���,21λCD
 **         [IN] usrId         ǰ̨����Ա��ʶ
 **         [IN] usrNm         ����Ա������ѡ�
 **         [IN] orgCd         ��������,21λCD
 **         [IN] mktId         �г����� irs/SIRS/SBFCCP
 **
 ******************************************************************************/
ResCodeT UserCheck(char* usrIdHeader, char* orgCdHeader, char* usrId, char* usrNm, char* orgCd, int32 mktId)
{
    BEGIN_FUNCTION("UserCheck");
    ResCodeT rc = NO_ERR;

    pUsrBaseInfoT pUsrInfo;
    pOrgInfoT pOrgInfo;
    pUsrRoleBaseInfoT pUsrRoleInfo;
    BOOL v_Org_Mkt_Prvlg, v_Usr_Mkt_Prvlg;

    v_Org_Mkt_Prvlg = FALSE;
    v_Usr_Mkt_Prvlg = FALSE;

    /* ���orgCdHeader��orgCd�Ƿ�һ�� */
    if (strcmp(orgCdHeader, orgCd) != 0){
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_ORG_CD, RTN);
    }


    /*  �ж�usrId�Ƿ���Ч */
    rc = IrsUsrInfoGetByNameExt(usrId, &pUsrInfo);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        // The usrId doesn't exist
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }

    if (atoi(pUsrInfo->usrSt) != C_USR_ST_ACTIVE){
        // The status of the user is not "Active"
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }


    /* ��ȡusrId��Ӧ�Ļ���CD������ID�����ȶ�CD��usrid�Ƿ�һ�� */
    rc = OrgInfoGetByIdExt(pUsrInfo->orgId, &pOrgInfo);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        // The organization doesn't exist
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }

    if (strcmp(pOrgInfo->orgCd, orgCd) != 0){
        // The orgCd of the user is not the same as the in parameter
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }


    /* �������Ա������Ϊ�� �������usrId�Ƿ��Ӧ */
    if (strlen(usrNm) != 0 && strcmp(usrNm, " ") != 0){
        if (strcmp(pUsrInfo->nmDesc, usrNm) != 0){
            // User name is not matched
            RAISE_ERR(APIERR_CODE_INVLD_TRDNM, RTN);
        }
    }


    /* ���е��˲�֤��usrIdһ���ǵ�ǰ�����µ��û���������û�����ǰ̨�û�������ǰ����Ա��APIȨ�� */
    if (pUsrInfo->roleId[C_USER_ROLE_FRONT - 1] == 0){
        // The user doesn't have the priviledge to access this function
        RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
    }


    /* ����ΪSBFCCP�г�������������״̬ */
    if (mktId != C_MKT_TP_SBFCCP){
        // ��ǰ����֤�������Ѿ���֤usrId��Ӧ��orgCd���������е�orgCdһ�£�
        // �����ȻԭSP��ʹ����ε�orgCd����ȡ���ݣ�������ֱ��ʹ�ô�ǰȡ����orgInfo�ڴ����ݡ�
        if (pOrgInfo->crdtOprtngSt == C_CRT_OPERATING){
            // The Org info is under modification
            RAISE_ERR(APIERR_CODE_CRT_MODIFYING, RTN);
        }
    }


    if (mktId == C_MKT_TP_IRS){
        /* �жϸ�ǰ̨����Ա�Ƿ�ѡ��API�����ᵥ-irs */
        rc = IrsRoleInfoGetByNameExt(usrId, &pUsrRoleInfo);
        if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
            // The user has no role info
            RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
        }else{
            RAISE_ERR(rc, RTN);
        }

        if (atoi(pUsrInfo->ordrPrvlgF) != C_ORDR_PRVLG_F_API){
            // The user must have API access right. Or raise error.
            RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
        }

    } else if (mktId == C_MKT_TP_SIRS){
        /* �жϸ�ǰ̨����Ա�Ƿ�ѡ��API�����ᵥ-sirs */
        rc = IrsRoleInfoGetByNameExt(usrId, &pUsrRoleInfo);
        if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
            // The user has no role info
            RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
        }else{
            RAISE_ERR(rc, RTN);
        }

        if (atoi(pUsrInfo->ordrPrvlgFSirs) != C_ORDR_PRVLG_F_API){
            // The user must have API access right. Or raise error.
            RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
        }

    }else if (mktId == C_MKT_TP_SBFCCP){
        /* �жϸ�ǰ̨����Ա�Ƿ�ѡ��API�����ᵥ-sbfccp */
        rc = IrsRoleInfoGetByNameExt(usrId, &pUsrRoleInfo);
        if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
            // The user has no role info
            RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
        }else{
            RAISE_ERR(rc, RTN);
        }

        if (atoi(pUsrInfo->ordrPrvlgFSbfccp) != C_ORDR_PRVLG_F_API){
            // The user must have API access right. Or raise error.
            RAISE_ERR(APIERR_CODE_INVLD_APIUSR, RTN);
        }

    }


    /* �������ڸ��г��Ƿ���Ȩ�� */
    rc = IsAuthorizedInMarket(pOrgInfo->orgId, mktId, &v_Org_Mkt_Prvlg);
    RAISE_ERR(rc, RTN);

    /* ��齻��Ա�ڸ��г��Ƿ���Ȩ�� */
    rc = IrsUsrMktStatusGet(usrId, mktId, &v_Usr_Mkt_Prvlg);
    RAISE_ERR(rc, RTN);

    if (v_Org_Mkt_Prvlg == FALSE || v_Usr_Mkt_Prvlg == FALSE){
        /* ����û�и��г�Ȩ�� ���� �û�û�и��г�Ȩ�� */
        RAISE_ERR(ERR_CODE_INVLD_USRMKT_PRV, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}
