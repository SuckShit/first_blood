/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>              /* define wait handling functions     */
#include <errno.h>
#include <pthread.h>
/* Project Header File*/
#include "common_macro.h"
#include "app_shl.h"
#include "msg_cache.h"
#include "mem_txn.h"
#include "msg_type.h"
#include "nmbr_srvc.h"
#include "cfg_lib.h"
#include "order_book.h"
#include "active_info.h"
#include "active_keeper.h"
#include "ordr_mgmt.h"
#include "trade_mgmt.h"
#include "brdg_ordr_mgmt.h"
#include "usr_flg.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
/******************************************************************************
 * Description:   stop the application shell
 * Parameters:
 *      fAppCallBack IN app callback
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT AppShmMgmtCreate()
{
    BEGIN_FUNCTION( "AppShmMgmtCreate" );
    
    ResCodeT rc = NO_ERR;
    OrdrBkCfgT  ordrBkCfg = {0};
    struct cfgValueS cfgValue = {0};
    vectorT *       pSetVct;
    int32           set = 0;
    
    /* Get config value for the system  */
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);

    rc = GetAllSetIdsPtr(&pSetVct);
    RAISE_ERR(rc, RTN);

    while (1)
    {
        /*�ҵ���ǰ����������set*/
        BitFindFS(pSetVct, set + 1, MAX_SET_CNT, &set);
        if (set == -1)
        {
            break;
        }

        LOG_DEBUG("create set %d shm", set);
        /* Initialize Order Book Section  */
        ordrBkCfg.nmbrOfOrdr = cfgValue.ttlOrdrNmbr;
        ordrBkCfg.nmbrOfPrdct =  cfgValue.ttlPrdctNmbr;
        ordrBkCfg.setId = set;
        ordrBkCfg.nmbrOfEnty =  cfgValue.ttlEntyNmbr;

        rc = OrdrBkShmCreate(&ordrBkCfg);
        RAISE_ERR(rc, RTN);

        rc = OrdrMgmtShmCreate(cfgValue.ttlOrdrNmbr, set);
        RAISE_ERR(rc, RTN);

        rc = NmbrSrvcShmCreate(set);
        RAISE_ERR(rc, RTN);

        rc = BrdgOrdrShmCreate(cfgValue.ttlOrdrNmbr, set);
        RAISE_ERR(rc, RTN);

        rc = MtchrInit(set);
        RAISE_ERR(rc, RTN);
             
        rc = TradeShmCreate(cfgValue.ttlOrdrNmbr, set);
        RAISE_ERR(rc, RTN);
    }
    
    rc = UsrFlgShmCreate();
    RAISE_ERR(rc, RTN);
    
    rc = UsrFlgShmLoad();
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlStop */
