﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "data_type.h"
#include "err_lib.h"
#include "mem_txn.h"
#include "common_macro.h"
#include "mem_txn_elem.h"
#include "order_type.h"
#include "match_lib.h"
#include "order_book.h"
#include "nmbr_srvc.h"
#include "ordr_mgmt.h"
#include "ref_dat_updt.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* Share memory control section */

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MemTxnElemDataAdd(BOOL bNeedMemTxn,int32 set, MTElemTypeT elemType, void * pData, int32 dataSize)
{
    BEGIN_FUNCTION( "MemTxnElemDataAdd" );
    ResCodeT        rc = NO_ERR;
    MTElemPrcsCtxT  ctx;
    if (gElemPrcsMatrix[elemType].elemType != elemType)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    ctx.set = set;
    
    if (gElemPrcsMatrix[elemType].fUpdateCallBack)
    {
        rc = gElemPrcsMatrix[elemType].fUpdateCallBack(bNeedMemTxn, elemType, pData, dataSize, &ctx);
        RAISE_ERR(rc,RTN);
    }

    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MemTxnElemDataMinus(BOOL bNeedMemTxn,int32 set, MTElemTypeT elemType, void * pData, int32 dataSize)
{
    BEGIN_FUNCTION( "MemTxnElemDataMinus" );
    ResCodeT        rc = NO_ERR;
    MTElemPrcsCtxT  ctx;
    
    if ( gElemPrcsMatrix[elemType].elemType != elemType )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    
    ctx.set = set;
    
    if (gElemPrcsMatrix[elemType].fRollbackCallBack)
    {
        rc = gElemPrcsMatrix[elemType].fRollbackCallBack(bNeedMemTxn, elemType, pData, dataSize, &ctx);
        RAISE_ERR(rc,RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrLogForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrLogForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    OrderT          order = {0};
    int32           actMnt = 0;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    uint32           ordrMgmtPos = 0;
    pOrderT         pTempOrder = NULL;
    
    pMLogOrdrT  pLogOrdrAddr = (pMLogOrdrT)pData;
   
    
    LOG_INFO("Ordr Log Slot %d", pLogOrdrAddr->slot);
    rc = OrdrMgmtNrmlGet(pLogOrdrAddr->setId, pLogOrdrAddr->ordr.ordrNo, &pOrdrMgmt, &pTempOrder, &ordrMgmtPos);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST)
    {
        LOG_INFO("Ordr Log Slot %d", pLogOrdrAddr->slot);
        rc = OrdBkCreateOrderBySlot(pLogOrdrAddr->setId, pLogOrdrAddr->slot, &pTempOrder);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        rc = OrdrBkGetOrdr(pLogOrdrAddr->setId, pLogOrdrAddr->slot,  &pTempOrder );
        RAISE_ERR(rc,RTN); 
    }
    
    /* in order to use the same function, we use input data tor format the neccessary structure.*/
    //order.orderT.slotNo = pLogOrdrAddr->slot;
    memcpy(&pTempOrder->orderF, &pLogOrdrAddr->ordr,sizeof (OrderFT));

    rc = MtchLogOrdr(bNeedMemTxn, pLogOrdrAddr->setId, pLogOrdrAddr->actnMask,pTempOrder, &pLogOrdrAddr->mtchInfo);
    RAISE_ERR(rc,RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrLogForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrLogForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrAddForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrAddForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    pOrderT         pTempOrder = NULL;
    pMAddOrdrT  pAddOrdrAddr = (pMAddOrdrT)pData;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    uint32           ordrMgmtPos = 0;
    
    int64 ordrPos = 0;
    
    LOG_INFO("Ordr Add Slot %d", pAddOrdrAddr->slot);
    rc = OrdrMgmtNrmlGet(pAddOrdrAddr->setId, pAddOrdrAddr->ordr.ordrNo, &pOrdrMgmt, &pTempOrder, &ordrMgmtPos);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST)
    {
        LOG_INFO("Ordr Add Slot %d", pAddOrdrAddr->slot);
        rc = OrdBkCreateOrderBySlot(pAddOrdrAddr->setId, pAddOrdrAddr->slot, &pTempOrder);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        rc = OrdrBkGetOrdr(pAddOrdrAddr->setId, pAddOrdrAddr->slot,  &pTempOrder );
        RAISE_ERR(rc,RTN); 
    }
 
 
    /* in order to use the same function, we use input data tor format the neccessary structure.*/
    //pTempOrder->orderT.slotNo = pAddOrdrAddr->slot;
    memcpy(&pTempOrder->orderF, &pAddOrdrAddr->ordr,sizeof (OrderFT));
    
    rc = NmbrSrvcSetNo(pAddOrdrAddr->setId, NMBR_TYPE_ORD, pTempOrder->orderF.ordrNo);
    RAISE_ERR(rc, RTN);
  

    rc = MtchAddOrdr(bNeedMemTxn, TRUE, pAddOrdrAddr->setId, pAddOrdrAddr->actnMask,pTempOrder, &pAddOrdrAddr->mtchInfo, pAddOrdrAddr);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrAddForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrAddForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrDelForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrDelForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    pOrderT pTmpOrdr = NULL;
    uint32           ordrMgmtPos = 0;
  
    pMDelOrdrT  pDelOrdrAddr = (pMDelOrdrT)pData;
    
    
    rc = OrdrBkGetOrdr(pDelOrdrAddr->setId, pDelOrdrAddr->slot,  &pTmpOrdr );
    RAISE_ERR(rc,RTN);
    
    /* in order to use the same function, we use input data tor format the neccessary structure.*/
    pTmpOrdr->orderT.slotNo = pDelOrdrAddr->slot;
    memcpy(&pTmpOrdr->orderF, &pDelOrdrAddr->orderF,sizeof (OrderFT));

    rc = MtchDelOrdr(bNeedMemTxn,pDelOrdrAddr->setId, &pTmpOrdr,pDelOrdrAddr->tranTime, pDelOrdrAddr->actnMask,&pDelOrdrAddr->mtchInfo, NULL,pDelOrdrAddr->delFlg);
    RAISE_ERR(rc,RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrDelForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrDelForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT TrdLogForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "TrdLogForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    MtchTrdT        mtchTrd;
    
   
    
    pMLogTrdT  pFrstLogTrdAddr = (pMLogTrdT)pData;
    pMLogTrdT  pScndLogTrdAddr = (pMLogTrdT)ADDRESS_ADD_OFFSET(pFrstLogTrdAddr, sizeof(MLogTrdT));


    
    
    /* we have to make the login sequence is same, so we do the second data first, it will be buffed in the MtchLogTrd function */
    memcpy(&mtchTrd.trade, &pFrstLogTrdAddr->trade, sizeof(TradeT));
    rc = MtchLogTrd(bNeedMemTxn, pFrstLogTrdAddr->setId, pFrstLogTrdAddr->actnMask, pFrstLogTrdAddr->oldOrdrNo, &mtchTrd);
    RAISE_ERR(rc,RTN);
    
    /* we have to make the login sequence is same, so we do the second data first, it will be buffed in the MtchLogTrd function */
    memcpy(&mtchTrd.trade, &pScndLogTrdAddr->trade, sizeof(TradeT));
    rc = MtchLogTrd(bNeedMemTxn, pScndLogTrdAddr->setId, pScndLogTrdAddr->actnMask, pScndLogTrdAddr->oldOrdrNo, &mtchTrd);
    RAISE_ERR(rc,RTN);
    
    rc = NmbrSrvcSetNo(pFrstLogTrdAddr->setId, NMBR_TYPE_TRD, mtchTrd.trade.tranIdNo);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT TrdLogForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "TrdLogForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrModForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrModForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    pOrderT          pTmpOrdr = NULL;   
    
    pMModOrdrT  pModOrdrAddr = (pMModOrdrT)pData;
    
    rc = OrdrBkGetOrdr(pModOrdrAddr->setId, pModOrdrAddr->slot,  &pTmpOrdr );
    RAISE_ERR(rc,RTN);
    
    
    /* in order to use the same function, we use input data tor format the neccessary structure.*/
    memcpy(&pTmpOrdr->orderF, &pModOrdrAddr->oldOrdr, sizeof (OrderFT));

    rc = MtchModOrdr(bNeedMemTxn, TRUE, pModOrdrAddr->setId, &pTmpOrdr,&pModOrdrAddr->newOrdr, pModOrdrAddr->actnMask,&pModOrdrAddr->mtchInfo, pModOrdrAddr);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrModForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrModForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrModQtyForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrModQtyForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    pOrderT         pTmpOrdr = NULL;

    pMModOrdQtyT  pModQtyOrdrAddr = (pMModOrdQtyT)pData;
    
        
    rc = OrdrBkGetOrdr(pModQtyOrdrAddr->setId, pModQtyOrdrAddr->slot,  &pTmpOrdr );
    RAISE_ERR(rc,RTN);
    
    /* in order to use the same function, we use input data tor format the neccessary structure.*/
    memcpy(&pTmpOrdr->orderF, &pModQtyOrdrAddr->oldOrdr, sizeof (OrderFT));

    
    rc = MtchModOrdrQty(bNeedMemTxn, pModQtyOrdrAddr->setId,  pTmpOrdr,
                                pModQtyOrdrAddr->exeQty,
                                pModQtyOrdrAddr->exePrc,
                                pModQtyOrdrAddr->tranTime,
                                pModQtyOrdrAddr->actnMask);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrModQtyForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrModQtyForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrSaveForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrSaveForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    pOrderT         pTempOrder = NULL;
    uint32           ordrMgmtPos = 0;
    pOrdrMgmtRcrdT  pOrdrMgmt  = NULL; 
  
    pMSaveOrdrT  pSaveOrdrAddr = (pMSaveOrdrT)pData;
    
    rc = OrdrMgmtNrmlGet(pSaveOrdrAddr->setId, pSaveOrdrAddr->ordrF.ordrNo, &pOrdrMgmt, &pTempOrder, &ordrMgmtPos);
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
    {
        rc = NO_ERR;
    }
    RAISE_ERR( rc, RTN );

    if ( !pTempOrder )
    {
        rc = OrdBkCreateOrderBySlot(pSaveOrdrAddr->setId, pSaveOrdrAddr->slot, &pTempOrder);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        rc = OrdrBkGetOrdr(pSaveOrdrAddr->setId, pSaveOrdrAddr->slot, &pTempOrder);
        RAISE_ERR(rc, RTN);
    }
    
    memcpy(&pTempOrder->orderF, &pSaveOrdrAddr->ordrF,sizeof (OrderFT));
    
    rc = NmbrSrvcSetNo(pSaveOrdrAddr->setId,NMBR_TYPE_ORD, pTempOrder->orderF.ordrNo);
    RAISE_ERR(rc, RTN);
    
    rc = MtchSaveOrdr(bNeedMemTxn, pSaveOrdrAddr->setId, pSaveOrdrAddr->actnMask,pTempOrder);
    RAISE_ERR(rc, RTN);
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrSaveForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "OrdrSaveForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT BilOrdrSaveForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "BilOrdrSaveForLoadMemTxn" );
    ResCodeT         rc = NO_ERR;
    pOrderT          pTmpBidOrdr,pTmpAskOrdr;
    uint32           ordrMgmtPos = 0;
    pOrdrMgmtRcrdT   pBilOrdrMgmt = NULL;
    pOrderT          pCnclBidOrder = NULL, pCnclAskOrder = NULL;

    pMSaveBilOrdrT  pSaveBilOrdrAddr = (pMSaveBilOrdrT)pData;
    
    LOG_INFO("Bil Ordr Save bidSlot %d, askSlot %d", pSaveBilOrdrAddr->bidSlot, pSaveBilOrdrAddr->askSlot);
    /* ADD means save here, bcoz we have created the order, get it directly */
    rc = OrdBkCreateOrderBySlot(pSaveBilOrdrAddr->setId, pSaveBilOrdrAddr->bidSlot, &pTmpBidOrdr);
    if ( rc == ERR_OBK_VECTOR_ERR )
    {
        rc = OrdrBkGetOrdr(pSaveBilOrdrAddr->setId, pSaveBilOrdrAddr->bidSlot, &pTmpBidOrdr);
    }
    RAISE_ERR(rc, RTN);

    rc = OrdBkCreateOrderBySlot(pSaveBilOrdrAddr->setId, pSaveBilOrdrAddr->askSlot, &pTmpAskOrdr);
    if ( rc == ERR_OBK_VECTOR_ERR )
    {
        rc = OrdrBkGetOrdr(pSaveBilOrdrAddr->setId, pSaveBilOrdrAddr->askSlot, &pTmpAskOrdr);
    }
    RAISE_ERR(rc, RTN);

    memcpy(&pTmpBidOrdr->orderF, &pSaveBilOrdrAddr->bidOrdrF,sizeof (OrderFT));
    memcpy(&pTmpAskOrdr->orderF, &pSaveBilOrdrAddr->askOrdrF,sizeof (OrderFT));
    
    rc = NmbrSrvcSetNo(pSaveBilOrdrAddr->setId,NMBR_TYPE_ORD, pTmpAskOrdr->orderF.ordrNo);
    RAISE_ERR(rc, RTN);
    
    rc = NmbrSrvcSetNo(pSaveBilOrdrAddr->setId,NMBR_TYPE_BIL_ORD, pTmpAskOrdr->orderF.specOrdrNo);
    RAISE_ERR(rc, RTN);

    rc = MtchSaveBilOrdr(bNeedMemTxn, pSaveBilOrdrAddr->setId, pSaveBilOrdrAddr->ordrAct, pSaveBilOrdrAddr->ordrSts,pTmpBidOrdr,pTmpAskOrdr,pSaveBilOrdrAddr->bidSlot,pSaveBilOrdrAddr->askSlot);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT BilOrdrSaveForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "BilOrdrSaveForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MktDatPushForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "MktDatPushForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    rc = MtchMktDatPush(bNeedMemTxn, pCtx->set);
    RAISE_ERR(rc, RTN);
   
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MktDatPushForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "MktDatPushForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT LogOcoForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "LogOcoForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    //pSubOrdrT       pSubOrdr = NULL;
    SlotT *         pOrdSlot = NULL;
    pMLogOcoOrdrT   pMLogOcoOrdr = (pMLogOcoOrdrT)pData;

    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    pOrderT         pBidOrder[MAX_ORDR_IN_OCO];
    pOrderT         pAskOrder[MAX_ORDR_IN_OCO];
    int32           i = 0;
    LOG_INFO("Oco Ordr Act %d, sts %d", pMLogOcoOrdr->ordrAct, pMLogOcoOrdr->ordrSts);
    
    pOrdrMgmt = (pOrdrMgmtRcrdT)ADDRESS_ADD_OFFSET(pMLogOcoOrdr, sizeof(MLogOcoOrdrT));
    
    for (i = 0; i<pMLogOcoOrdr->bidSlotCnt; i++)
    {
        rc = OrdrBkGetOrdr(pMLogOcoOrdr->setId, pOrdrMgmt->ordrSlot[i], &pBidOrder[i]);
        RAISE_ERR(rc, RTN);
    }
    
    for (i = pMLogOcoOrdr->bidSlotCnt - 1; i<pMLogOcoOrdr->askSlotCnt + pMLogOcoOrdr->bidSlotCnt; i++)
    {
        rc = OrdrBkGetOrdr(pMLogOcoOrdr->setId, pOrdrMgmt->ordrSlot[i], &pAskOrder[i - pMLogOcoOrdr->bidSlotCnt]);
        RAISE_ERR(rc, RTN);
    }

    rc = NmbrSrvcSetNo(pMLogOcoOrdr->setId, NMBR_TYPE_OCO_ORD, pMLogOcoOrdr->specOrdrNo);
    RAISE_ERR(rc, RTN);
    
    rc = MtchLogOcoOrdr(bNeedMemTxn, pMLogOcoOrdr->setId, pMLogOcoOrdr->specOrdrNo, pMLogOcoOrdr->ordrAct, pMLogOcoOrdr->ordrSts,
                    pMLogOcoOrdr->bidSlotCnt, pBidOrder, pMLogOcoOrdr->askSlotCnt, pAskOrder);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT LogOcoForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "LogOcoForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatUptForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "RefDatUptForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    rc = RefDatUpdtForLoad(bNeedMemTxn,elemType, pData, dataType);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatUptForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "RefDatUptForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT FlushMktDatForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "FlushMktDatForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    pMFlushMktDatT  pMFlushMktDat = (pMFlushMktDatT)pData;
    
    rc =  MtchFlushMktDat(bNeedMemTxn,pMFlushMktDat->setId,pMFlushMktDat->timestamp);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT FlushMktDatForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "FlushMktDatForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT UpdtCrdtByTrdForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "UpdtCrdtByTrdForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    pMUpdtCrdtByTrdT  pMUpdtCrdtByTrd = (pMUpdtCrdtByTrdT)pData;
    
    rc =  MtchUpdCrdtByTrd(bNeedMemTxn, pMUpdtCrdtByTrd->setId,&pMUpdtCrdtByTrd->crdtMgmtUpdt);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT UpdtCrdtByTrdForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "UpdtCrdtByTrdForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT PrdctInfoUpdtForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "PrdctInfoUpdtForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    pMPrdctInfoUpdtT  pMPrdctInfoUpdt = (pMPrdctInfoUpdtT)pData;
    
    
    rc = MtchUpdtPrdctInfo(bNeedMemTxn,pMPrdctInfoUpdt->prdctId, &pMPrdctInfoUpdt->prdctBaseInfo);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT PrdctInfoUpdtForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "PrdctInfoUpdtForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT BrdgMktDatPushForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "BrdgMktDatPushForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    pMBrdgMktDatPushT  pMBrdgMktDatPush = (pMBrdgMktDatPushT)pData;
    
    
    rc = MtchBrdgMktPush(bNeedMemTxn, pMBrdgMktDatPush->setId, &pMBrdgMktDatPush->brdgOrdrF);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT BrdgMktDatPushForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "BrdgMktDatPushForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT BrdgOrdUpdtForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "BrdgOrdUpdtForLoadMemTxn" );
    ResCodeT        rc = NO_ERR;
    
    pMBrdgOrdrUpdtT  pMBrdgOrdrUpdt = (pMBrdgOrdrUpdtT)pData;
    
    rc = MtchBrdgOrdrUpdt(bNeedMemTxn, pMBrdgOrdrUpdt->setId, pMBrdgOrdrUpdt->updtType, &pMBrdgOrdrUpdt->brdgOrdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Prcess the data minus logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT BrdgOrdUpdtPushForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx)
{
    BEGIN_FUNCTION( "BrdgOrdUpdtPushForRlbkMemTxn" );
    ResCodeT        rc = NO_ERR;
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}