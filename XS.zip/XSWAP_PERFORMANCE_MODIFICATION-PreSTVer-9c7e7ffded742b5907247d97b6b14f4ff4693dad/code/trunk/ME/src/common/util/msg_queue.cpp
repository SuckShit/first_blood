/***
Created on June 08, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "../include/lock_free_queue.h"
#include "../include/msg_queue.h"
#include "../include/err_lib.h"
#include "../include/common_macro.h"
#include "../include/thread_id.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_MSG_QUEUE_CNT   50

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static MsgQueueT   gMsgQHndl[MAX_MSG_QUEUE_CNT];
static int64       gMsgQHndlCnt = 0;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT MsgQueueCalcSize(MsgQueueCfgT   *pMsgQueueCfg, uint32 *totalSize)
{
    BEGIN_FUNCTION("MsgQueueCalcSize");
    //ResCodeT                rc = NO_ERR;
    size_t              lfqMemSize   = 0;
    ThreadLockFreeQCfgT    lfqConf;

    if ( NULL == pMsgQueueCfg || NULL == totalSize )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    if ( !IS2N(pMsgQueueCfg->itemCnt) )
    {
        RAISE_ERR(ERCD_ARCH_INVLD_QUEUE_LEN, RTN);
    }

    if ( pMsgQueueCfg->itemCnt >= (uint32)MAX_UINT32/pMsgQueueCfg->itemSize )
    {
        RAISE_ERR(ERCD_ARCH_INVLD_BUFFER_SIZE, RTN);
    }

    lfqConf.entryCapacity = pMsgQueueCfg->itemCnt;
    lfqConf.entrySize = pMsgQueueCfg->itemSize;

    lfqMemSize = ThreadLckFreeQCalcMemSize(&lfqConf);
    *totalSize = (uint32)lfqMemSize;
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT MsgQueueCreate( MsgQueueCfgT   *pMsgQueueCfg, 
                        int32 * pMsgHndl,void *pQueueAddr)
{
    BEGIN_FUNCTION("MsgQueueCreate");
    void                *pLfqMem = NULL;
    size_t              lfqMemSize;
    ThreadLockFreeQCfgT lfqConf;
    int32               realThreadCnt = 0;
    MsgQueueT           *pQueue = NULL;

    int32 threadCnt = pMsgQueueCfg->threadCnt;
    if ( NULL == pMsgQueueCfg || threadCnt <= 0 || gMsgQHndlCnt >= MAX_MSG_QUEUE_CNT)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    if ( !IS2N( pMsgQueueCfg->itemCnt) )
    {
        RAISE_ERR(ERCD_ARCH_INVLD_QUEUE_LEN, RTN);
    }

    pQueue = (MsgQueueT *)&gMsgQHndl[gMsgQHndlCnt];

    lfqConf.entryCapacity = pMsgQueueCfg->itemCnt;
    lfqConf.entrySize = pMsgQueueCfg->itemSize;
    pQueue->itemCnt = pMsgQueueCfg->itemCnt;
    pQueue->itemSize = pMsgQueueCfg->itemSize;
    pQueue->type = pMsgQueueCfg->type;
     
    pLfqMem = pQueueAddr;
    if ( NULL == pLfqMem )
    {
        lfqMemSize = ThreadLckFreeQCalcMemSize(&lfqConf);
        if ( NULL == (pLfqMem = malloc(lfqMemSize)) )
        {
            RAISE_ERR(ERCD_ARCH_MALLOC_ERR, RTN);
        }
        pQueue->pQueueMem = pLfqMem;
    }

    if ( !ThreadLckFreeQInit(&lfqConf,pLfqMem,&(pQueue->pThreadLfq)) )
    {
        RAISE_ERR(ERCD_ARCH_INVLD_HNDL, RTN);
    }

    /*初始化Queue上线程句柄*/
    pQueue->pLocalThreadLfqHdl = (ThreadLockFreeQHndlT**)calloc(threadCnt, sizeof(ThreadLockFreeQHndlT*));
    if ( NULL == pQueue->pLocalThreadLfqHdl )
    {
        RAISE_ERR(ERCD_ARCH_MALLOC_ERR, RTN);
    }

    for(int32 i = 0; i < realThreadCnt; i++)
    {
        pQueue->pLocalThreadLfqHdl[i] = NULL; 
    }
    pQueue->queueThreadCnt = realThreadCnt;
    

    *pMsgHndl = gMsgQHndlCnt;
    
    gMsgQHndlCnt ++;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


static ResCodeT MsgQueueHndlInit(int32 msgHndl, int32 threadId, ThreadLockFreeQHndlT **ppLfqHdl)
{
    BEGIN_FUNCTION("MsgQueueHndlInit");
    MsgQueueT *pQueue = NULL;

    pQueue = (MsgQueueT *) &gMsgQHndl[msgHndl];

    ThreadLockFreeQHndlT *pLfqHdl = pQueue->pLocalThreadLfqHdl[threadId]; 
    
    
    if (pLfqHdl != NULL)
    {
        *ppLfqHdl = pLfqHdl;
    }
    else
    {
        if (!ThreadLckFreeQInitHndl(pQueue->pThreadLfq,ppLfqHdl))
        {
            RAISE_ERR(ERCD_ARCH_INVLD_HNDL, RTN);
        }

        pQueue->pLocalThreadLfqHdl[threadId] = *ppLfqHdl;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

ResCodeT MsgQueueCalcMaxCnt(int32 msgHndl, int32* maxCnt)
{
    BEGIN_FUNCTION("MsgQueueCalcMaxCnt");
    ResCodeT rc = NO_ERR;

    MsgQueueT * pQueue = NULL;
    
    if ( msgHndl >= gMsgQHndlCnt)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }
    
    pQueue = (MsgQueueT *) &gMsgQHndl[msgHndl];
    
    if (NULL == pQueue->itemCnt)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }
    *maxCnt = pQueue->itemCnt;
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT MsgQueueCalcUsedCnt(int32 msgHndl, int32* usedCnt)
{
    BEGIN_FUNCTION("MsgQueueCalcUsedCnt");
    ResCodeT rc = NO_ERR;
    ThreadLockFreeQHndlT *pLfqHdl = NULL;
    MsgQueueT *pQueue = NULL;
    int32 threadId = 0;
    
    if ( msgHndl >= gMsgQHndlCnt)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }
    
    pQueue = (MsgQueueT *) &gMsgQHndl[msgHndl];

    if (NULL == pQueue->pThreadLfq )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }


    GET_THREAD_ID(threadId);
    
    rc = MsgQueueHndlInit(msgHndl, threadId, &pLfqHdl);
    RAISE_ERR(rc, RTN);

    *usedCnt = ThreadLckFreeQUsedSize(pLfqHdl);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT MsgQueueWriteData(int32 msgHndl, void *pData, int32 len)
{
    BEGIN_FUNCTION("MsgQueueWriteData");
    ResCodeT rc = NO_ERR;
    MsgQueueT *pQueue = NULL;
    ThreadLockFreeQHndlT *pLfqHdl = NULL;
    int32 threadId = 0;
    int32 dataLen = 0;

    if ( msgHndl >= gMsgQHndlCnt || NULL == pData || len <= 0 )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    pQueue = (MsgQueueT *)&gMsgQHndl[msgHndl];



    GET_THREAD_ID(threadId);
    rc = MsgQueueHndlInit(msgHndl, threadId, &pLfqHdl);
    RAISE_ERR(rc, RTN);
    

    dataLen = len >= pQueue->itemSize ? pQueue->itemSize : len;
    rc = ThreadLckFreeQNonBlockingPush(pLfqHdl, pData, dataLen);
    if (rc != 1)
    {
        THROW_RESCODE(ERCD_ARCH_WRITE_TRY_AGAIN);
    }
    else
    {

    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT MsgQueueWriteSlot(int32 msgHndl, SlotT slot)
{
    BEGIN_FUNCTION("MsgQueueWriteSlot");
    ResCodeT rc = NO_ERR;

    if ( msgHndl >= gMsgQHndlCnt)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }
    

    rc = MsgQueueWriteData(msgHndl, &slot, sizeof(SlotT));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT MsgQueueReadData(int32 msgHndl, void *pData, int32 len)
{
    
    BEGIN_FUNCTION("MsgQueueReadData");
    ResCodeT rc = NO_ERR;
    ThreadLockFreeQHndlT *pLfqHdl = NULL;
    MsgQueueT *pQueue = NULL;
    int32 dataLen = 0;
    int32 threadId = 0;
    if (msgHndl >= gMsgQHndlCnt || NULL == pData || len <=0 )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    pQueue = (MsgQueueT *) &gMsgQHndl[msgHndl];

    
    GET_THREAD_ID(threadId);
    rc = MsgQueueHndlInit(msgHndl, threadId, &pLfqHdl);
    RAISE_ERR(rc, RTN);


    dataLen = len >= pQueue->itemSize ? pQueue->itemSize : len;

    rc =  ThreadLckFreeQNonBlockingPop(pLfqHdl, pData, dataLen);
    if (rc != NO_ERR)
    {
        THROW_RESCODE(ERCD_ARCH_READ_TRY_AGAIN);
    }
    else
    {

    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT MsgQueueReadSlot(int32 msgHndl, SlotT *pSlot)
{
    BEGIN_FUNCTION("MsgQueueReadSlot");
    ResCodeT rc = NO_ERR;

    if (msgHndl >= gMsgQHndlCnt  || NULL == pSlot)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    rc = MsgQueueReadData(msgHndl, pSlot, sizeof(SlotT));
    if (rc != ERCD_ARCH_READ_TRY_AGAIN)
    {
        RAISE_ERR(rc, RTN);
    }else
    {
        THROW_RESCODE(ERCD_ARCH_READ_TRY_AGAIN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MsgQueueDispose(int32 msgHndl)
{
    BEGIN_FUNCTION("MsgQueueDispose");
    ResCodeT rc = NO_ERR;
    int32 i = 0;
    int32 eventfd = -1;
    MsgQueueT *pQueue = NULL;

    if (msgHndl >= gMsgQHndlCnt )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }
    pQueue = (MsgQueueT *)&gMsgQHndl[msgHndl];
    /*close fd*/
    rc = MsgQueueGetFd(msgHndl, &eventfd);
    RAISE_ERR(rc, RTN);
    
    close(eventfd);

    if ( NULL != pQueue->pLocalThreadLfqHdl )
    {
        for( i = 0 ; i < pQueue->queueThreadCnt; i++ )
        {
            if ( NULL != pQueue->pLocalThreadLfqHdl[i] )
            {
                ThreadLckFreeQFreeHndl(pQueue->pLocalThreadLfqHdl[i]);
            }
        }
        free(pQueue->pLocalThreadLfqHdl);
        pQueue->pLocalThreadLfqHdl = NULL;
    }

    if ( NULL != pQueue->pQueueMem )
    {
        free(pQueue->pQueueMem);
        pQueue->pQueueMem = NULL;
    }
    if ( NULL != pQueue->pThreadLfq )
    {
        pQueue->pThreadLfq = NULL;
    }
    RESET_TTL_THREAD_CNT();

    EXIT_BLOCK();
    RETURN_RESCODE;

}



ResCodeT MsgQueueGetFd(int32 msgHndl, int32 * pOutputFd)
{
    BEGIN_FUNCTION("MsgQueueGetFd");

    MsgQueueT *pQueue = NULL;

    if (msgHndl >= gMsgQHndlCnt )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    pQueue = (MsgQueueT *)&gMsgQHndl[msgHndl];
    * pOutputFd = ThreadLckFreeQGetEventFd(pQueue->pThreadLfq);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

