﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "data_type.h"
#include "err_lib.h"
#include "mem_txn.h"
#include "common_macro.h"
#include "mem_txn_elem.h"
#include "cfg_lib.h"
#include "ref_dat_updt.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* Share memory control section */


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static BOOL gbCfgInit = FALSE;
static struct cfgValueS gCfgValue = {0};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
static ResCodeT InitCfg()
{
    BEGIN_FUNCTION( "InitCfg" );
    ResCodeT        rc = NO_ERR;

    if (!gbCfgInit)
    {
        rc = GetCfgValue(&gCfgValue);
        RAISE_ERR(rc, RTN);

        gbCfgInit = TRUE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatUpdtCmmn(RefUpdtTypeT refUpdtType, void * pData, int32 dataSize)
{
    BEGIN_FUNCTION( "RefDatUpdtCmmn" );
    ResCodeT        rc = NO_ERR;
    pMRefDatUpdtT   pMRefDatUpdt = NULL;
    void   *         pMemTxnData = NULL;
    rc = InitCfg();
    RAISE_ERR(rc, RTN);

    if (gRefUpdtPrcsMatrix[refUpdtType].refUpdtType != refUpdtType || !gRefUpdtPrcsMatrix[refUpdtType].fRefUpdtCallBack)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }

    rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_REF_DAT_UPT, sizeof(MRefDatUpdtT) + dataSize , (void **)&pMRefDatUpdt);
    RAISE_ERR( rc, RTN );

    pMRefDatUpdt->updtType = refUpdtType;
    pMRefDatUpdt->dataLen = dataSize;

    pMemTxnData = (void *)ADDRESS_ADD_OFFSET(pMRefDatUpdt, sizeof(MRefDatUpdtT));
    memcpy(pMemTxnData, pData, dataSize);

    rc = MemTxnAddElemClose();
    RAISE_ERR( rc, RTN );

    rc = gRefUpdtPrcsMatrix[refUpdtType].fRefUpdtCallBack(pData,dataSize);
    RAISE_ERR(rc,RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatUpdtNoMemTxn(RefUpdtTypeT refUpdtType, void * pData, int32 dataSize)
{
    BEGIN_FUNCTION( "RefDatUpdtNoMemTxn" );
    ResCodeT        rc = NO_ERR;

    if (gRefUpdtPrcsMatrix[refUpdtType].refUpdtType != refUpdtType || !gRefUpdtPrcsMatrix[refUpdtType].fRefUpdtCallBack)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }

    rc = gRefUpdtPrcsMatrix[refUpdtType].fRefUpdtCallBack(pData,dataSize);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatDbUpdtCmmn(int32 connId, RefUpdtTypeT refUpdtType, void * pData, int32 dataSize)
{
    BEGIN_FUNCTION( "RefDatDbUpdtCmmn" );
    ResCodeT        rc = NO_ERR;
    rc = InitCfg();
    RAISE_ERR(rc, RTN);

    if (gRefUpdtPrcsMatrix[refUpdtType].refUpdtType != refUpdtType)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    
    if (gRefUpdtPrcsMatrix[refUpdtType].fRefDatDbUpdtCallback)
    {
        rc = gRefUpdtPrcsMatrix[refUpdtType].fRefDatDbUpdtCallback(connId, pData,dataSize);
        RAISE_ERR(rc,RTN);
    }

    

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatPrntCmmn(RefUpdtTypeT refUpdtType, void * pData, int32 dataSize)
{
    BEGIN_FUNCTION( "RefDatPrntCmmn" );
    ResCodeT        rc = NO_ERR;
    rc = InitCfg();
    RAISE_ERR(rc, RTN);

    if (gRefUpdtPrcsMatrix[refUpdtType].refUpdtType != refUpdtType || !gRefUpdtPrcsMatrix[refUpdtType].fRefPrntCallBack)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }

    rc = gRefUpdtPrcsMatrix[refUpdtType].fRefPrntCallBack(pData,dataSize);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Prcess the data add logic
 * Parameters:
 *      elemType    IN  element type
 *      pData       IN  self define data address
 *      dataSize    IN  self defined data length
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT RefDatUpdtForLoad(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType)
{
    BEGIN_FUNCTION( "RefDatUpdtForLoad" );
    ResCodeT        rc = NO_ERR;
    void *          pUsrData = NULL;

    pMRefDatUpdtT pMRefDatUpdt = (pMRefDatUpdtT)pData;
    pUsrData = (void *)ADDRESS_ADD_OFFSET(pMRefDatUpdt, sizeof(MRefDatUpdtT));

    if (bNeedMemTxn)
    {
        rc = RefDatUpdtCmmn(pMRefDatUpdt->updtType,  pUsrData, pMRefDatUpdt->dataLen);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        rc = RefDatUpdtNoMemTxn(pMRefDatUpdt->updtType, pUsrData, pMRefDatUpdt->dataLen);
        RAISE_ERR(rc,RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
