/***
Created on Aug 02, 2017
@author: Xiaoping Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "uti_tool.h"

#include "pck_irs_util.h"
#include "pck_irs_dicdata.h"
#include "base_param.h"
#include "usr.h"
#include "usr_role.h"
#include "org_info.h"
#include "contract_info.h"
#include "credit_info.h"
#include "sys_st_rsrc.h"
#include "role_prvlg.h"
#include "ImixMsgOutDb.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : CommonChk
 **
 ******************************************************************************/
ResCodeT CommonChk(char* usrId, int32 in_orgId, int32 funcId, char* token, int32* out_orgId)
{
    BEGIN_FUNCTION("CommonChk");
    ResCodeT rc = NO_ERR;
    pBaseParamT pParamData;
    pUsrBaseInfoT pUsrData;
    pOrgInfoT pOrgData;
    pBrdgOrgInfoT pBrdgOrgData;
    pUsrBaseInfoT pCrdtOprtrData;
    pSysStRsrcT pSysStatus;
    pRolePrvlgT pRolePrivilege;
    int32 mrktState;
    BOOL groundFlag, groundEmgcyFlag;
    int32 v_OrgId;
    BOOL lgnTpFlag;
    BOOL v_Org_Mkt_Prvlg, v_Usr_Mkt_Prvlg;
    char paramName[PARAM_NAME_LENGTH] = {0};

    groundFlag = FALSE;
    groundEmgcyFlag = FALSE;
    v_Org_Mkt_Prvlg = FALSE;
    v_Usr_Mkt_Prvlg = FALSE;
    
    /* 取得市场状态 */
    memcpy(paramName, C_MKT_ST_IRS, sizeof(paramName));
    rc = BaseParamGetByNameExt(paramName, &pParamData);
    RAISE_ERR(rc, RTN);
    
    if (atoi(pParamData->paramValue) == C_MKT_ST_CLOSEQT_IRS){
        mrktState = C_MKT_ST_CLOSEQT;
    }else {
        mrktState = atoi(pParamData->paramValue);
    }
    
    if (mrktState == C_MKT_ST_CLOSE){
        rc = IrsUsrInfoGetByNameExt(usrId, &pUsrData);
        if (OK(rc)){
            /* If the user exists, then check the role of the user */
            rc = IrsUsrRoleIdIsExist(usrId, C_USER_ROLE_GROUND, &groundFlag);
            RAISE_ERR(rc, RTN);
            
            rc = IrsUsrRoleIdIsExist(usrId, C_USER_ROLE_EMGCY_GROUND, &groundEmgcyFlag);
            RAISE_ERR(rc, RTN);
            
            /* 闭市后，非场务用户不能登录 */
            if (groundFlag == FALSE && groundEmgcyFlag == FALSE){
                RAISE_ERR(ERR_CODE_MKT_CLOSED_NO_D, RTN);
            }
            
        }else if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
            /* If the user doesn't exist, then raise error ERR_CODE_MKT_CLOSED_NO_D */
            RAISE_ERR(ERR_CODE_MKT_CLOSED_NO_D, RTN);
        }else{
            /* When other error occurs, just raise the error */
            RAISE_ERR(rc, RTN);
        }
        
    }
    

    /* Get the user information by usrId */
    rc = IrsUsrInfoGetByNameExt(usrId, &pUsrData);
    RAISE_ERR(rc, RTN);
    
    /* Check if the user is online */
    if (pUsrData->usrOnlnStatus == FALSE){
        /* If the user is not online, raise error. */
        RAISE_ERR(ERR_CODE_INVLD_NOT_LOGON, RTN);
    }

    
    /* 判断Token */
    if (strcmp(token, pUsrData->sesnId) != 0){
        /* If the value of the token parameter is not the same as the session id extracted from DB, raise error. */
        RAISE_ERR(ERR_CODE_INVLD_TOKEN_ERROR, RTN);
    }
    
    v_OrgId = 0;
    
    if (funcId == C_CREDITMODIFY_FUNCID){
        /* 修改授信或风险系数--4002 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            /* 取得登录用户的机构ID */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else if (in_orgId == C_ORG_NULL){
            /* 场务用户，输入机构ID必须非空 */
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else{
            v_OrgId = in_orgId;
        }
        
        
        rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pOrgData->crdtOprtngSt == C_CRT_OPERATING){
            if (strcmp(pOrgData->crdtOprtr, usrId) != 0){
                rc = IrsUsrInfoGetByNameExt(pOrgData->crdtOprtr, &pCrdtOprtrData);
                RAISE_ERR(rc, RTN);
                
                if (pCrdtOprtrData->lgnTp == C_USER_ROLE_GROUND ||
                    pCrdtOprtrData->lgnTp == C_USER_ROLE_EMGCY_GROUND){
                    /* 场务用户正在修改 */
                    RAISE_ERR(ERR_CODE_INVLD_GND_CRT_MDF, RTN);
                }else{
                    /* 后台用户正在修改 */
                    RAISE_ERR(ERR_CODE_INVLD_BGD_CRT_MDF, RTN);
                }
            }
        }
        
        
    }else if (funcId == C_CREDITUPDATE_FUNCID ||   
            funcId == C_RISKUPDATE_FUNCID ||    
            funcId == C_CRT_UNLOCK_FUNCID ||    
            funcId == C_RSK_UNLOCK_FUNCID){
        /*   授信更新--4003   风险系数更新--4004  接触授信修改锁定--4007  解除风险系数修改锁定--4008  */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            /* 取得登录用户的机构ID */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
            
        }else if (in_orgId == C_ORG_NULL){
            /* 场务用户，输入机构ID必须非空 */
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else{
            v_OrgId = in_orgId;
        }
        
        rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pOrgData->crdtOprtngSt == C_CRT_OPERATING){
            /* 锁定授信的用户必须为in_UserId */
            if ( strcmp(pOrgData->crdtOprtr, usrId) != 0 ){
                RAISE_ERR(ERR_CODE_INVLD_USER_NOTMATCH, RTN);
            }
        }else{
            RAISE_ERR(ERR_CODE_INVLD_ST_NOT_CRCT, RTN);
        }
        
    /* --------------------搭桥 start----------------------- */
    }else if (funcId == C_BRDGCRDTUPDATE_FUNCID ||
            funcId == C_BRDGCRDTMDFYUNLOCK_FUNCID){
        /* 中后台设置机构搭桥参数--4013   机构搭桥参数解锁--4014  */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            /* 取得登录用户的机构ID */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
            
        }else if (in_orgId == C_ORG_NULL){
            /* 场务用户，输入机构ID必须非空 */
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else{
            v_OrgId = in_orgId;
        }
        
        rc = BrdgOrgInfoGetByIdExt(v_OrgId, &pBrdgOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pBrdgOrgData->crdtOprtngSt == C_CRT_OPERATING){
            /* 锁定授信的用户必须为in_UserId */
            if ( strcmp(pBrdgOrgData->crdtOprtr, usrId) != 0 ){
                RAISE_ERR(ERR_CODE_INVLD_USER_NOTMATCH, RTN);
            }
        }else{
            RAISE_ERR(ERR_CODE_INVLD_ST_NOT_CRCT, RTN);
        }
        
    
    }else if (funcId == C_BRDGCRDTMDFY_FUNCID){
        /* 修改机构搭桥--4012  */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            /* 取得登录用户的机构ID */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else if (in_orgId == C_ORG_NULL){
            /* 场务用户，输入机构ID必须非空 */
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else{
            v_OrgId = in_orgId;
        }
        
        
        rc = BrdgOrgInfoGetByIdExt(v_OrgId, &pBrdgOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pBrdgOrgData->crdtOprtngSt == C_CRT_OPERATING){
            if (strcmp(pBrdgOrgData->crdtOprtr, usrId) != 0){
                rc = IrsUsrInfoGetByNameExt(pBrdgOrgData->crdtOprtr, &pCrdtOprtrData);
                RAISE_ERR(rc, RTN);
                
                if (pCrdtOprtrData->lgnTp == C_USER_ROLE_GROUND ||
                    pCrdtOprtrData->lgnTp == C_USER_ROLE_EMGCY_GROUND){
                    /* 场务用户正在修改 */
                    RAISE_ERR(ERR_CODE_INVLD_GND_CRT_MDF, RTN);
                }else{
                    /* 后台用户正在修改 */
                    RAISE_ERR(ERR_CODE_INVLD_BGD_CRT_MDF, RTN);
                }
            }
        }
    
    /* --------------------搭桥 end----------------------- */    
    
    }else if (funcId == C_ORDSAVING_FUNCID ||
            funcId == C_ORDCANCEL_FUNCID ||
            funcId == C_ORDFREEZE_FUNCID ||
            funcId == C_OCOORDSAVING_FUNCID ||
            funcId == C_OCOORDCANCEL_FUNCID ||
            funcId == C_OCOORDFREEZE_FUNCID ||
            funcId == C_BILORDSAVING_FUNCID ||
            funcId == C_BILORDCANCEL_FUNCID ||
            funcId == C_BILORDFREEZE_FUNCID){
        /*  订单保存--2000  订单撤销--2002  订单冻结--2003  OCO订单保存--3000   OCO订单撤销--3002
            OCO订单冻结--3003   BIL订单保存--3005   BIL订单撤销--3007   BIL订单冻结--3008  */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
            
            /* 检查交易员是否有客户端提单权限 */
            if (atoi(pUsrData->ordrPrvlgF) != C_ORDR_PRVLG_F_CLIENT){
                RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }
        
    
    }else if (funcId == C_ORDSUBMIT_FUNCID ||
            funcId == C_ORDACTIVATE_FUNCID ||
            funcId == C_OCOORDSUBMIT_FUNCID ||
            funcId == C_OCOORDACTIVATE_FUNCID ||
            funcId == C_BILORDSUBMIT_FUNCID ||
            funcId == C_BILORDACTIVATE_FUNCID){
        /* 订单提交--2001   订单激活--2004   OCO订单提交--3001   OCO订单激活--3004
           BIL订单提交--3006      BIL订单激活--3009  */
        
        v_OrgId = pUsrData->orgId;
        
        rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pOrgData->orgIrsSt == C_ORG_ST_FORBID || 
            pOrgData->orgIrsSt == C_ORG_ST_DELETE){
            /* 机构被禁用或删除 */
            RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
        }
        
        if (in_orgId != C_ORG_NULL){
            /* 输入机构非空 */
            RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
        }
        
        /* 检查交易员是否有客户端提单权限 */
        if (atoi(pUsrData->ordrPrvlgF) != C_ORDR_PRVLG_F_CLIENT){
            RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
        }
        
        rc = IsAuthorizedInMarket(v_OrgId, C_MKT_TP_IRS, &v_Org_Mkt_Prvlg);
        RAISE_ERR(rc, RTN);
        
        rc = IrsUsrMktStatusGet(usrId, C_MKT_TP_IRS, &v_Usr_Mkt_Prvlg);
        RAISE_ERR(rc, RTN);
        
        if (v_Org_Mkt_Prvlg == FALSE || v_Usr_Mkt_Prvlg == FALSE){
            /* 机构没有该市场权限 或者 用户没有该市场权限 */
            RAISE_ERR(ERR_CODE_INVLD_USRMKT_PRV, RTN);
        }
        
        /* 机构授信状态 */
        if (pOrgData->crdtOprtngSt == C_CRT_OPERATING){
            RAISE_ERR(ERR_CODE_INVLD_CRDT_MDFING, RTN);
        }
        
    
    }else if (funcId == C_CREDITQUERY_FUNCID ||
            funcId == C_CRT_RFSH_QUERY_FUNCID ||
            funcId == C_ORDQUERY_FUNCID ||
            funcId == C_PRICEQUERY_FUNCID ||
            funcId == C_RISKQUERY_FUNCID ||
            funcId == C_BRDGDEALERUPDATE_FUNCID ||
            funcId == C_BRDGPRVLGMDFYCW_FUNCID ||
            funcId == C_BRDGCRDTQUERY_FUNCID ||
            funcId == C_BRDGDEALERQUERY_FUNCID ||
            funcId == C_TRDQUERY_FUNCID ||
            funcId == C_UNLOCKCREDIT_FUNCID ||
            funcId == C_CRT_RFSH_MODIFY_FUNCID ||
            funcId == C_ORGFREEZE_FUNCID ||
            funcId == C_USRMKTQUERY_FUNCID ||
            funcId == C_USRMKTMDY_FUNCID ||
            funcId == C_ORGMKTQUERY_FUNCID ||
            funcId == C_ORGMKTMDY_FUNCID ||
            funcId == C_TRD_PRV_CFG_FUNCID ||
            funcId == C_TRD_PRV_QRY_FUNCID){
        /* 授信查询--4000   授信更新方式查询--4005   订单查询--2005   价格查询--2006   风险系数查询--4001 
            前台设置机构搭桥参数--4015   场务设置机构搭桥权限--4011   中后台查询机构搭桥参数--4016 
            前台查询机构搭桥参数--4017  成交查询--5000   应急解除授信锁定--7001  授信更新方式修改--4006
            机构禁用/解禁--7000   用户市场权限查询--7006  用户市场权限修改--7007   机构市场权限查询--7008
            修改机构市场权限--7009   设置用户提单通道--1002   查询用户提单通道--1003 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构非空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else if (in_orgId == C_ORG_NULL){
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else {
            v_OrgId = in_orgId;
        }
    
    }else if (funcId == C_PARAMUPDATE_FUNCID ||
                funcId == C_CONTRACTINFOUPDATE_FUNCID ||
                funcId == C_PARAMQUERY_FUNCID ||
                funcId == C_CONTRACTINFOQUERY_FUNCID ||
                funcId == C_USERLOGOUT_FUNCID ||
                funcId == C_TRADECANCEL_FUNCID ||
                funcId == C_APIPARAMUPDATE_FUNCID ||
                funcId == C_REMOVEUSER_FUNCID ||
                funcId == C_APIUSRFREEZE_FUNCID ||
                funcId == C_IRS_MANUALSMRY_FUNCID){
            /* 基本参数设置--6000   合约参数设置--6001   基本参数查询--6002   合约参数查询,6003 
            用户登出,1001   成交撤销,5001   api参数设置，6006   紧急移除在线用户,7005
            API用户禁用/解禁   手动汇总   */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }
    
    }else{
        /* Invalid function id */
        RAISE_ERR(ERR_CODE_INVLD_FUNCID_INVLD, RTN);
    }
    
    *out_orgId = v_OrgId;
    
    /* 判断该市场状态是否允许执行此功能 */
    rc = SysStRsrcGetByKeyExt(funcId, mrktState, &pSysStatus);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        /* The function is not permitted to execute this function */
        RAISE_ERR(ERR_CODE_INVLD_MKT_NOT_PMT, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    
    /* 判断用户是否有权限执行此功能 */
    rc = IrsUsrRoleIdIsExist(usrId, pUsrData->lgnTp, &lgnTpFlag);
    RAISE_ERR(rc, RTN);
    
    /* The Login type is not in the range of roles the user has */
    if (lgnTpFlag == FALSE){
        RAISE_ERR(ERR_CODE_INVLD_ROLE_PRV, RTN);
    }
    
    rc = RolePrvlgGetByKeyExt(funcId, pUsrData->lgnTp, &pRolePrivilege);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        /* The function is not permitted to execute this function */
        RAISE_ERR(ERR_CODE_INVLD_ROLE_PRV, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SirsCommonChk(char* usrId, int32 in_orgId, int32 funcId, char* token, int32* out_orgId)
{
    BEGIN_FUNCTION("SirsCommonChk");
    ResCodeT rc = NO_ERR;
    pBaseParamT pParamData;
    pUsrBaseInfoT pUsrData;
    pOrgInfoT pOrgData;
    pUsrBaseInfoT pCrdtOprtrData;
    pSysStRsrcT pSysStatus;
    pRolePrvlgT pRolePrivilege;
    uint16 v_MrktState;
    BOOL groundFlag, groundEmgcyFlag;
    int32 v_OrgId;
    BOOL lgnTpFlag;
    BOOL v_Org_Mkt_Prvlg, v_Usr_Mkt_Prvlg;
    char paramName[PARAM_NAME_LENGTH] = {0};

    groundFlag = FALSE;
    groundEmgcyFlag = FALSE;
    v_Org_Mkt_Prvlg = FALSE;
    v_Usr_Mkt_Prvlg = FALSE;
    
    /* 取得市场状态 */
    memcpy(paramName, C_MKT_ST, sizeof(paramName));
    rc = BaseParamGetByNameExt(paramName, &pParamData);
    RAISE_ERR(rc, RTN);
	
	v_MrktState = atoi(pParamData->paramValue);
    
    if (v_MrktState == C_MKT_ST_CLOSE){
        rc = IrsUsrInfoGetByNameExt(usrId, &pUsrData);
        if (OK(rc)){
            /* If the user exists, then check the role of the user */
            rc = IrsUsrRoleIdIsExist(usrId, C_USER_ROLE_GROUND, &groundFlag);
            RAISE_ERR(rc, RTN);
            
            rc = IrsUsrRoleIdIsExist(usrId, C_USER_ROLE_EMGCY_GROUND, &groundEmgcyFlag);
            RAISE_ERR(rc, RTN);
            
            /* 闭市后，非场务用户不能登录 */
            if (groundFlag == FALSE && groundEmgcyFlag == FALSE){
                RAISE_ERR(ERR_CODE_MKT_CLOSED_NO_D, RTN);
            }
            
        }else if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
            /* If the user doesn't exist, then raise error ERR_CODE_MKT_CLOSED_NO_D */
            RAISE_ERR(ERR_CODE_MKT_CLOSED_NO_D, RTN);
        }else{
            /* When other error occurs, just raise the error */
            RAISE_ERR(rc, RTN);
        }
        
    }
    

    /* Get the user information by usrId */
    rc = IrsUsrInfoGetByNameExt(usrId, &pUsrData);
    RAISE_ERR(rc, RTN);
    
    /* Check if the user is online */
    if (pUsrData->usrOnlnStatus == FALSE){
        /* If the user is not online, raise error. */
        RAISE_ERR(ERR_CODE_INVLD_NOT_LOGON, RTN);
    }

    
    /* 判断Token */
    if (strcmp(token, pUsrData->sesnId) != 0){
        /* If the value of the token parameter is not the same as the session id extracted from DB, raise error. */
        RAISE_ERR(ERR_CODE_INVLD_TOKEN_ERROR, RTN);
    }
    
    v_OrgId = 0;
    
    if (funcId == C_CREDITMODIFY_FUNCID){
        /* 修改授信或风险系数--4002 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            /* 取得登录用户的机构ID */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else if (in_orgId == C_ORG_NULL){
            /* 场务用户，输入机构ID必须非空 */
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else{
            v_OrgId = in_orgId;
        }
        
        
        rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pOrgData->crdtOprtngSt == C_CRT_OPERATING){
			if (strcmp(pOrgData->crdtOprtr, usrId) != 0){
                rc = IrsUsrInfoGetByNameExt(pOrgData->crdtOprtr, &pCrdtOprtrData);
                RAISE_ERR(rc, RTN);
                
                if (pCrdtOprtrData->lgnTp == C_USER_ROLE_GROUND ||
                    pCrdtOprtrData->lgnTp == C_USER_ROLE_EMGCY_GROUND){
                    /* 场务用户正在修改 */
                    RAISE_ERR(ERR_CODE_INVLD_GND_CRT_MDF, RTN);
                }else{
                    /* 后台用户正在修改 */
                    RAISE_ERR(ERR_CODE_INVLD_BGD_CRT_MDF, RTN);
                }
            }
        }   
        
    }else if (funcId == C_CREDITUPDATE_FUNCID ||   
              funcId == C_RISKUPDATE_FUNCID ||    
              funcId == C_CRT_UNLOCK_FUNCID ||    
              funcId == C_RSK_UNLOCK_FUNCID){
        /*   授信更新--4003   风险系数更新--4004  接触授信修改锁定--4007  解除风险系数修改锁定--4008  */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            /* 取得登录用户的机构ID */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
            
        }else if (in_orgId == C_ORG_NULL){
            /* 场务用户，输入机构ID必须非空 */
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else{
            v_OrgId = in_orgId;
        }
        
        rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pOrgData->crdtOprtngSt == C_CRT_OPERATING){
            /* 锁定授信的用户必须为in_UserId */
            if ( strcmp(pOrgData->crdtOprtr, usrId) != 0 ){
                RAISE_ERR(ERR_CODE_INVLD_USER_NOTMATCH, RTN);
            }
        }else{
            RAISE_ERR(ERR_CODE_INVLD_ST_NOT_CRCT, RTN);
        }
    
	}else if (funcId == C_ORDSAVING_FUNCID ||
              funcId == C_ORDCANCEL_FUNCID ||
              funcId == C_ORDFREEZE_FUNCID ||
              funcId == C_OCOORDSAVING_FUNCID ||
              funcId == C_OCOORDCANCEL_FUNCID ||
              funcId == C_OCOORDFREEZE_FUNCID){
        /*  订单保存--2000  订单撤销--2002  订单冻结--2003  
		    OCO订单保存--3000   OCO订单撤销--3002   OCO订单冻结--3003    */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
            
            /* 检查交易员是否有客户端提单权限 */
            if (atoi(pUsrData->ordrPrvlgFSirs) != C_ORDR_PRVLG_F_CLIENT){
                RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }
		
	}else if (funcId == C_ORDSUBMIT_FUNCID ||
              funcId == C_ORDACTIVATE_FUNCID ||
              funcId == C_OCOORDSUBMIT_FUNCID ||
              funcId == C_OCOORDACTIVATE_FUNCID){
        /* 订单提交--2001   订单激活--2004   OCO订单提交--3001   OCO订单激活--3004 */
        
        v_OrgId = pUsrData->orgId;
        
        rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
        RAISE_ERR(rc, RTN);
        
        if (pOrgData->orgIrsSt == C_ORG_ST_FORBID || 
            pOrgData->orgIrsSt == C_ORG_ST_DELETE){
            /* 机构被禁用或删除 */
            RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
        }
        
        if (in_orgId != C_ORG_NULL){
            /* 输入机构非空 */
            RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
        }
        
        /* 检查交易员是否有客户端提单权限 */
        if (atoi(pUsrData->ordrPrvlgFSirs) != C_ORDR_PRVLG_F_CLIENT){
            RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
        }
        
        rc = IsAuthorizedInMarket(v_OrgId, C_MKT_TP_SIRS, &v_Org_Mkt_Prvlg);
        RAISE_ERR(rc, RTN);
        
        rc = IrsUsrMktStatusGet(usrId, C_MKT_TP_SIRS, &v_Usr_Mkt_Prvlg);
        RAISE_ERR(rc, RTN);
        
        if (v_Org_Mkt_Prvlg == FALSE || v_Usr_Mkt_Prvlg == FALSE){
            /* 机构没有该市场权限 或者 用户没有该市场权限 */
            RAISE_ERR(ERR_CODE_INVLD_USRMKT_PRV, RTN);
        }
        
        /* 机构授信状态 */
        if (pOrgData->crdtOprtngSt == C_CRT_OPERATING){
            RAISE_ERR(ERR_CODE_INVLD_CRDT_MDFING, RTN);
        }
	
	}else if (funcId == C_CREDITQUERY_FUNCID ||
              funcId == C_CRT_RFSH_QUERY_FUNCID ||
              funcId == C_ORDQUERY_FUNCID ||
              funcId == C_PRICEQUERY_FUNCID ||
              funcId == C_RISKQUERY_FUNCID ||
              funcId == C_TRDQUERY_FUNCID ||
              funcId == C_UNLOCKCREDIT_FUNCID ||
              funcId == C_CRT_RFSH_MODIFY_FUNCID ||
              funcId == C_ORGFREEZE_FUNCID){
        /* 授信查询--4000   授信更新方式查询--4005   订单查询--2005   价格查询--2006   风险系数查询--4001 
           成交查询--5000   应急解除授信锁定--7001  授信更新方式修改--4006   机构禁用/解禁--7000 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构非空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else if (in_orgId == C_ORG_NULL){
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else {
            v_OrgId = in_orgId;
        }
		
	}else if (funcId == C_PARAMUPDATE_FUNCID ||
              funcId == C_CONTRACTINFOUPDATE_FUNCID ||
			  funcId == C_CONTR_INFOUPD_SIRS_FUNCID ||
              funcId == C_PARAMQUERY_FUNCID ||
              funcId == C_CONTRACTINFOQUERY_FUNCID ||
              funcId == C_USERLOGOUT_FUNCID ||
              funcId == C_TRADECANCEL_FUNCID ||
			  funcId == C_REMOVEUSER_FUNCID){
            /* 基本参数设置--6000   合约参数设置--6001   合约参数设置(SIRS)--8005   基本参数查询--6002   
			   合约参数查询,6003   用户登出--1001   成交撤销--5001   紧急移除在线用户,7005 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }
	
	}else if (funcId == C_ACNTDELETE_FUNCID ||
              funcId == C_REFPRCMDY_FUNCID ||
              funcId == C_ACNTMDY_FUNCID ||
              funcId == C_ACNTQUERY_FUNCID ||
			  funcId == C_STTLPRCQUERY_FUNCID){
            /* 资金账户删除--8001   场务修改结算价修改--8002   资金账户修改--8003   
			   资金账户查询--8004   每日结算价查询--8006 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }

    }else{
        /* Invalid function id */
        RAISE_ERR(ERR_CODE_INVLD_FUNCID_INVLD, RTN);
    }
    
	
    *out_orgId = v_OrgId;
    
    /* 判断该市场状态是否允许执行此功能 */
    rc = SysStRsrcGetByKeyExt(funcId, v_MrktState, &pSysStatus);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        /* The function is not permitted to execute this function */
        RAISE_ERR(ERR_CODE_INVLD_MKT_NOT_PMT, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    
    /* 判断用户是否有权限执行此功能 */
    rc = IrsUsrRoleIdIsExist(usrId, pUsrData->lgnTp, &lgnTpFlag);
    RAISE_ERR(rc, RTN);
    
    /* The Login type is not in the range of roles the user has */
    if (lgnTpFlag == FALSE){
        RAISE_ERR(ERR_CODE_INVLD_ROLE_PRV, RTN);
    }
    
    rc = RolePrvlgGetByKeyExt(funcId, pUsrData->lgnTp, &pRolePrivilege);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        /* The function is not permitted to execute this function */
        RAISE_ERR(ERR_CODE_INVLD_ROLE_PRV, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SbfCcpCommonChk(char* usrId, int32 in_orgId, int32 funcId, char* token, int32* out_orgId)
{
    BEGIN_FUNCTION("SbfCcpCommonChk");
    ResCodeT rc = NO_ERR;
    pBaseParamT pParamData;
    pUsrBaseInfoT pUsrData;
    pOrgInfoT pOrgData;
    pSysStRsrcT pSysStatus;
    pRolePrvlgT pRolePrivilege;
    BOOL groundFlag, groundEmgcyFlag;
    int32 v_OrgId;
    BOOL lgnTpFlag;
    BOOL v_Org_Mkt_Prvlg, v_Usr_Mkt_Prvlg;
    uint16 v_MrktState;
	char paramName[PARAM_NAME_LENGTH] = {0};

    groundFlag = FALSE;
    groundEmgcyFlag = FALSE;
    v_Org_Mkt_Prvlg = FALSE;
    v_Usr_Mkt_Prvlg = FALSE;
    
    /* 取得市场状态 */
    memcpy(paramName, C_MKT_ST, sizeof(paramName));
    rc = BaseParamGetByNameExt(paramName, &pParamData);
    RAISE_ERR(rc, RTN);
	
	v_MrktState = atoi(pParamData->paramValue);
    
    if (v_MrktState == C_MKT_ST_CLOSE){
        rc = IrsUsrInfoGetByNameExt(usrId, &pUsrData);
        if (OK(rc)){
            /* If the user exists, then check the role of the user */
            rc = IrsUsrRoleIdIsExist(usrId, C_USER_ROLE_GROUND, &groundFlag);
            RAISE_ERR(rc, RTN);
            
            rc = IrsUsrRoleIdIsExist(usrId, C_USER_ROLE_EMGCY_GROUND, &groundEmgcyFlag);
            RAISE_ERR(rc, RTN);
            
            /* 闭市后，非场务用户不能登录 */
            if (groundFlag == FALSE && groundEmgcyFlag == FALSE){
                RAISE_ERR(ERR_CODE_MKT_CLOSED_NO_D, RTN);
            }
            
        }else if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
            /* If the user doesn't exist, then raise error ERR_CODE_MKT_CLOSED_NO_D */
            RAISE_ERR(ERR_CODE_MKT_CLOSED_NO_D, RTN);
        }else{
            /* When other error occurs, just raise the error */
            RAISE_ERR(rc, RTN);
        }
        
    }
    

    /* Get the user information by usrId */
    rc = IrsUsrInfoGetByNameExt(usrId, &pUsrData);
    RAISE_ERR(rc, RTN);
    
    /* Check if the user is online */
    if (pUsrData->usrOnlnStatus == FALSE){
        /* If the user is not online, raise error. */
        RAISE_ERR(ERR_CODE_INVLD_NOT_LOGON, RTN);
    }

    
    /* 判断Token */
    if (strcmp(token, pUsrData->sesnId) != 0){
        /* If the value of the token parameter is not the same as the session id extracted from DB, raise error. */
        RAISE_ERR(ERR_CODE_INVLD_TOKEN_ERROR, RTN);
    }
    
	
    v_OrgId = 0;
    
	if (funcId == C_ORDSAVING_FUNCID ||
        funcId == C_ORDCANCEL_FUNCID ||
        funcId == C_ORDFREEZE_FUNCID ||
		funcId == C_ORDUNLIQUIDATE_FUNCID ||
        funcId == C_OCOORDSAVING_FUNCID ||
        funcId == C_OCOORDCANCEL_FUNCID ||
		funcId == C_OCOORDFREEZE_FUNCID){
        /*  订单保存--2000  订单撤销--2002  订单冻结--2003  撤销强平--2011  
		    OCO订单保存--3000   OCO订单撤销--3002  OCO订单冻结--3003 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构ID必须为空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
            
            /* 若不为撤销强平调用，检查交易员是否有客户端提单权限 */
			if (funcId != C_ORDUNLIQUIDATE_FUNCID){
			    /* 撤销强平,2011 执行者为特殊system用户代表清算所 */
				if (atoi(pUsrData->ordrPrvlgFSbfccp) != C_ORDR_PRVLG_F_CLIENT){
					RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
				}
			}
        }else{
            v_OrgId = in_orgId;
        }
		
	}else if (funcId == C_ORDSUBMIT_FUNCID ||
              funcId == C_ORDACTIVATE_FUNCID ||
			  funcId == C_ORDLIQUIDATE_FUNCID ||
              funcId == C_OCOORDSUBMIT_FUNCID ||
              funcId == C_OCOORDACTIVATE_FUNCID){
        /* 订单提交--2001   订单激活--2004   强平--2010   OCO订单提交--3001   OCO订单激活--3004  */
        
		if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
			/* 非场务用户 */
			
			v_OrgId = pUsrData->orgId;
			
			rc = OrgInfoGetByIdExt(v_OrgId, &pOrgData);
			RAISE_ERR(rc, RTN);
			
			if (pOrgData->orgIrsSt == C_ORG_ST_FORBID || 
				pOrgData->orgIrsSt == C_ORG_ST_DELETE){
				/* 机构被禁用或删除 */
				RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
			}
			
			if (in_orgId != C_ORG_NULL){
				/* 输入机构非空 */
				RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
			}
			
			
			rc = IsAuthorizedInMarket(v_OrgId, C_MKT_TP_SBFCCP, &v_Org_Mkt_Prvlg);
			RAISE_ERR(rc, RTN);
			
			rc = IrsUsrMktStatusGet(usrId, C_MKT_TP_SBFCCP, &v_Usr_Mkt_Prvlg);
			RAISE_ERR(rc, RTN);
			
			if (v_Org_Mkt_Prvlg == FALSE || v_Usr_Mkt_Prvlg == FALSE){
				/* 机构没有该市场权限 或者 用户没有该市场权限 */
				RAISE_ERR(ERR_CODE_INVLD_USRMKT_PRV, RTN);
			}
			
			/* 若不为强平调用，检查交易员是否有客户端提单权限 */
			if (funcId != C_ORDLIQUIDATE_FUNCID){
			    /* 强平,2010 执行者为特殊system用户代表清算所 */
				if (atoi(pUsrData->ordrPrvlgFSbfccp) != C_ORDR_PRVLG_F_CLIENT){
					RAISE_ERR(ERR_CODE_INVLD_ORDR_PRV, RTN);
				}
			}
			
		}else if (in_orgId == C_ORG_NULL){
			RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
			
		}else{
			v_OrgId = in_orgId;
		}
		
	}else if (funcId == C_ORDQUERY_FUNCID ||
              funcId == C_PRICEQUERY_FUNCID ||
              funcId == C_TRDQUERY_FUNCID ||
              funcId == C_PSTNLIMITMDFY_FUNCID ||
              funcId == C_ORGFREEZE_FUNCID){
        /* 订单查询--2005   价格查询--2006   成交查询--5000   修改限额--4010   机构禁用/解禁--7000  */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                /* 输入机构非空 */
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else if (in_orgId == C_ORG_NULL){
            RAISE_ERR(ERR_CODE_INVLD_GND_ORG_NULL, RTN);
        }else {
            v_OrgId = in_orgId;
        }
		
	}else if (funcId == C_PARAMUPDATE_FUNCID ||
              funcId == C_CONTR_INFOUPD_SBFCCP_FUNCID ||
              funcId == C_PARAMQUERY_FUNCID ||
              funcId == C_CONTRACTINFOQUERY_FUNCID ||
			  funcId == C_CONTRACTCNVRTUPDATE_FUNCID ||
              funcId == C_USERLOGOUT_FUNCID ||
              funcId == C_TRADECANCEL_FUNCID ||
              funcId == C_REMOVEUSER_FUNCID){
            /* 基本参数设置--6000   合约参数设置(SBFCCP)--8013   基本参数查询--6002   合约参数查询--6003 
               合约转换系数修改--6005   用户登出--1001   成交撤销--5001   紧急移除在线用户--7005 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }
		
	}else if (funcId == C_ACNTDELETE_FUNCID ||
              funcId == C_REFPRCMDY_FUNCID ||
              funcId == C_ACNTMDY_FUNCID ||
              funcId == C_ACNTQUERY_FUNCID ||
			  funcId == C_STTLPRCQUERY_FUNCID ||
              funcId == C_DPST_ACNTDELETE_FUNCID ||
              funcId == C_DPST_ACNTMDY_FUNCID ||
              funcId == C_DPST_ACNTQUERY_FUNCID ||
			  funcId == C_DLVRY_BONDQUERY_FUNCID ||
              funcId == C_DLVRY_BONDUPDATE_FUNCID ||
              funcId == C_HLD_AMNTQUERY_FUNCID ||
              funcId == C_PSTNLIMITQUERY_FUNCID){
            /* 资金账户删除--8001   场务修改结算价修改--8002   资金账户修改--8003   资金账户查询--8004 
               每日结算价查询--8006   托管账户删除--8007   托管账户修改--8008   托管结算价查询--8009 
			   可交割债券查询--8010   可交割债券更新--8011   持仓量查询--5002   持仓限额查询--4009 */
        
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND){
            /* 非场务用户 */
            v_OrgId = pUsrData->orgId;
            
            if (in_orgId != C_ORG_NULL){
                RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
            }
        }else{
            v_OrgId = in_orgId;
        }
		
    }else{
        /* Invalid function id */
        RAISE_ERR(ERR_CODE_INVLD_FUNCID_INVLD, RTN);
    }
    
	
    *out_orgId = v_OrgId;
    
    /* 判断该市场状态是否允许执行此功能 */
    rc = SysStRsrcGetByKeyExt(funcId, v_MrktState, &pSysStatus);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        /* The function is not permitted to execute this function */
        RAISE_ERR(ERR_CODE_INVLD_MKT_NOT_PMT, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    
    /* 判断用户是否有权限执行此功能 */
    rc = IrsUsrRoleIdIsExist(usrId, pUsrData->lgnTp, &lgnTpFlag);
    RAISE_ERR(rc, RTN);
    
    /* The Login type is not in the range of roles the user has */
    if (lgnTpFlag == FALSE){
        RAISE_ERR(ERR_CODE_INVLD_ROLE_PRV, RTN);
    }
    
    rc = RolePrvlgGetByKeyExt(funcId, pUsrData->lgnTp, &pRolePrivilege);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        /* The function is not permitted to execute this function */
        RAISE_ERR(ERR_CODE_INVLD_ROLE_PRV, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetBoundId(int32 connId, uint64* pMaxId){
    BEGIN_FUNCTION("GetBoundId");
    ResCodeT rc = NO_ERR;
    int32 boundNum = 0;
    uint64 maxValue = 0;
    
    rc = GetResultCntOfImixMsgOut(connId, &boundNum);
    RAISE_ERR(rc, RTN);
    
    if (boundNum != 0){
        //rc = GetMaxImixCd(connId, &maxValue);
        //RAISE_ERR(rc, RTN);
        
        *pMaxId = maxValue + 1;
    }else{
        *pMaxId = 0;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
