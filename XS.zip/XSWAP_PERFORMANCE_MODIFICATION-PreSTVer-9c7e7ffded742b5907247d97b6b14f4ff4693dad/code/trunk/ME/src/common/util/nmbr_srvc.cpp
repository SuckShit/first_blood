﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "shm.h"
#include "nmbr_srvc.h"
#include "mem_txn.h"
#include "uti_tool.h"
#include "internal_base_def.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static BOOL             gInit = FALSE;
static pNmbrInfoT       gpNmbrList[MAX_SET_CNT];


/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT NmbrSrvcShmCreate(int32 setId)
{
    BEGIN_FUNCTION( "NmbrSrvcShmCreate" );
    ResCodeT    rc = NO_ERR;
    void *      pRoot = NULL;    
    
    char        shmName[SHM_NAME_LEN];
    sprintf(shmName, SHM_NMBR_SRVC_NAME, setId);
    
    rc = ShmCreate(GetShmNm(shmName), sizeof(gGlblNmbrList), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    memcpy(pRoot, &gGlblNmbrList, sizeof(gGlblNmbrList));
    
    gpNmbrList[setId] = (pNmbrInfoT)pRoot;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Generate number
 * Parameters:
 *      nmbrType    IN  set value
 *      * pOutNmbr  OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
int64 NmbrSrvcGetPreFix(int32 setId, NmbrTypeT nmbrType)
{
    
    return gpNmbrList[setId][nmbrType].preFixBase;
}
/******************************************************************************
 * Description:   Attach to shm
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcShmAttach(int32 setId)
{
    BEGIN_FUNCTION( "NmbrSrvcShmAttach" );
    ResCodeT    rc = NO_ERR;
    
    char        shmName[SHM_NAME_LEN];
    sprintf(shmName, SHM_NMBR_SRVC_NAME, setId);
    void *  pRoot = NULL;
    
    rc = ShmAttach(GetShmNm(shmName), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    gpNmbrList[setId] = (pNmbrInfoT)pRoot;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Detach to shm
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcShmDetach(int32 setId)
{
    BEGIN_FUNCTION( "NmbrSrvcShmDetach" );
    ResCodeT    rc = NO_ERR;
    
    char        shmName[SHM_NAME_LEN];
    sprintf(shmName, SHM_NMBR_SRVC_NAME, setId);

    rc = ShmDetach(GetShmNm(shmName));
    RAISE_ERR(rc, RTN);

    gInit = FALSE;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Delete shm
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcShmDelete(int32 setId)
{
    BEGIN_FUNCTION( "NmbrSrvcShmDelete" );
    ResCodeT    rc = NO_ERR;
    
    char        shmName[SHM_NAME_LEN];
    sprintf(shmName, SHM_NMBR_SRVC_NAME, setId);

    rc = ShmDelete(GetShmNm(shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Inite
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcInit(int32 setId)
{
    BEGIN_FUNCTION( "NmbrSrvcInit" );
    ResCodeT    rc = NO_ERR;
    int64       timestamp = 0;
    char        date[MAX_DATETIME_LEN] = {0};
    char        time[MAX_DATETIME_LEN] = {0};
    int16       i = 0;
    
    rc = NmbrSrvcShmAttach(setId);
    RAISE_ERR(rc, RTN);
    
    rc = GetSysTimestamp(&timestamp);
    RAISE_ERR(rc, RTN);
    
    GetStrDateTime(timestamp,date,time);
    
    for (i=0;i<NMBR_TYPE_INVLD;i++)
    {
        if (i != NMBR_TYPE_TRD)
        {
            gpNmbrList[setId][i].preFixBase = atoll(date) * gpNmbrList[setId][i].offsetBase;
        }
        else
        {
            if(setId == SET_MKT_IRS)
            {
                gpNmbrList[setId][i].preFixBase = atoll(date) * gpNmbrList[setId][i].offsetBase;
                gpNmbrList[setId][i].preFixBase = gpNmbrList[setId][i].preFixBase + MKT_BASE_IRS;
            }
            else if(setId == SET_MKT_SIRS)
            {
                gpNmbrList[setId][i].preFixBase = atoll(date) * gpNmbrList[setId][i].offsetBase;
                gpNmbrList[setId][i].preFixBase = gpNmbrList[setId][i].preFixBase + MKT_BASE_SIRS;
            }
            else if(setId == SET_MKT_SBFCCP)
            {
                gpNmbrList[setId][i].preFixBase = atoll(date) * gpNmbrList[setId][i].offsetBase;
                gpNmbrList[setId][i].preFixBase = gpNmbrList[setId][i].preFixBase + MKT_BASE_SBFCCP;
            }
        }
        gpNmbrList[setId][i].currNo = 0;
    }
    
    gInit = TRUE;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Reset all data
 * Parameters:
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcReset(int32 setId)
{
    BEGIN_FUNCTION( "NmbrSrvcReset" );
    ResCodeT    rc = NO_ERR;
    int32       i = 0;
    
    for (i=0;i<NMBR_TYPE_INVLD;i++)
    {
        gpNmbrList[setId][i].currNo = 0;
    }

    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Generate number
 * Parameters:
 *      nmbrType    IN  set value
 *      * pOutNmbr  OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcGenNo(int32 setId,NmbrTypeT nmbrType, int64 * pOutNmbr)
{
    BEGIN_FUNCTION( "NmbrSrvcGenNo" );
    ResCodeT    rc = NO_ERR;
    int64       fixnum;
    
    if (nmbrType >= NMBR_TYPE_INVLD)
    {
        RAISE_ERR(ERR_NMBR_SRVC_INVLD_TYPE, RTN);
    }
    
    * pOutNmbr = gpNmbrList[setId][nmbrType].preFixBase + (++gpNmbrList[setId][nmbrType].currNo);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Get number
 * Parameters:
 *      nmbrType    IN  set value
 *      * pOutNmbr  OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcGetNo(int32 setId,NmbrTypeT nmbrType, int64 * pOutNmbr)
{
    BEGIN_FUNCTION( "NmbrSrvcGetNo" );
    ResCodeT    rc = NO_ERR;
    
    if (nmbrType >= NMBR_TYPE_INVLD)
    {
        RAISE_ERR(ERR_NMBR_SRVC_INVLD_TYPE, RTN);
    }
    
    * pOutNmbr = gpNmbrList[setId][nmbrType].preFixBase + gpNmbrList[setId][nmbrType].currNo;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Set number
 * Parameters:
 *      nmbrType    IN  set value
 *      * pOutNmbr  OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT NmbrSrvcSetNo(int32 setId,NmbrTypeT nmbrType, int64 setNmbr)
{

    BEGIN_FUNCTION( "NmbrSrvcSetNo" );
    ResCodeT    rc = NO_ERR;
    
    if (nmbrType >= NMBR_TYPE_INVLD)
    {
        RAISE_ERR(ERR_NMBR_SRVC_INVLD_TYPE, RTN);
    }
    
    gpNmbrList[setId][nmbrType].currNo = setNmbr % gpNmbrList[setId][nmbrType].preFixBase;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    

}