﻿/***
Created on Aug 10, 2017
@author: Yinsong.Zhao
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "common_hash.h"
#include "shm.h"
#include "usr_flg.h"
#include "usr.h"
#include "contract_info.h"
#include "internal_base_def.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static CmnHashHndlT gUsrFlgHndl = -1;
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
 

ResCodeT UsrFlgShmCreate()
{
    BEGIN_FUNCTION("UsrFlgShmCreate");
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT recInfo;
    void *pShmRoot;
    int64   rcrdCnt;
    uint64  ttlCnt, usedCnt;
    
    rc = IrsUsrInfoGetCnt(&ttlCnt, &usedCnt);
    RAISE_ERR(rc, RTN);
    
    rcrdCnt = ttlCnt;
    
    rc = IrsCntrctInfoGetCnt(&ttlCnt, &usedCnt);
    RAISE_ERR(rc, RTN);
    
    rcrdCnt *= usedCnt;
    
    
    recInfo.recSize = sizeof(UsrFlgRcrdT);
    recInfo.keyOffset = offsetof(UsrFlgRcrdT, usrFlgKey);
    recInfo.keySize = sizeof(UsrFlgKeyT);
    recInfo.recCnt = rcrdCnt;
    recInfo.bNeedTimeList = TRUE;
    
    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)SHM_USR_FLG_NAME), 
                                recInfo, TRUE, &pShmRoot, &gUsrFlgHndl);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT UsrFlgShmLoad()
{
    BEGIN_FUNCTION("UsrFlgShmLoad");
    ResCodeT        rc = NO_ERR;
    uint32          cntrtPos = CMN_LIST_NULL_NODE;
    uint32          usrPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT  pCntrctInfo = NULL;
    pUsrBaseInfoT      pUsrInfo = NULL;
    
    UsrFlgRcrdT         usrFlg = {0};
    uint32              usrFlgPos = CMN_LIST_NULL_NODE;

    while (TRUE)
    {
        rc = IrsUsrInfoIterExt(&usrPos, &pUsrInfo);
        RAISE_ERR(rc, RTN);

        if ( CMN_LIST_NULL_NODE == usrPos )
        {
            //LOG_DEBUG("No more user");
            break;
        }

        while (TRUE)
        {
            rc = IrsCntrctInfoIterExt(&cntrtPos, &pCntrctInfo);
            RAISE_ERR(rc, RTN);
            if ( CMN_LIST_NULL_NODE == cntrtPos )
            {
                //LOG_DEBUG("No more contract");
                break;
            }
            if ( pCntrctInfo->setId != SET_MKT_IRS )
            {
                continue;
            }

            memset(&usrFlg,0x00,sizeof(UsrFlgRcrdT));
            
            usrFlg.usrFlgKey.usrPos = usrPos;
            usrFlg.usrFlgKey.cntrctPos = cntrtPos;
            
            rc = UsrFlgAdd(&usrFlg, &usrFlgPos);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT UsrFlgShmAttach(int32 setId)
{
    BEGIN_FUNCTION("UsrFlgShmAttach");
    ResCodeT rc = NO_ERR;
    void *pShmRoot;

    rc = CmnHashTblAttach(GetShmNm((char*)SHM_USR_FLG_NAME), &pShmRoot, &gUsrFlgHndl);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UsrFlgShmDetach(int32 setId)
{
    BEGIN_FUNCTION("UsrFlgShmDetach");
    ResCodeT rc = NO_ERR;

    rc = ShmDetach((char*)SHM_USR_FLG_NAME);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UsrFlgShmDelete(int32 setId)
{
    BEGIN_FUNCTION("UsrFlgShmDelete");
    ResCodeT rc = NO_ERR;

    rc = ShmDelete((char*)SHM_USR_FLG_NAME);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UsrFlgShmReset(int32 setId)
{
    BEGIN_FUNCTION("UsrFlgShmInit");
    ResCodeT rc = NO_ERR;

    
    rc = CmnHashResetTbl(gUsrFlgHndl);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT UsrFlgChkExt(pUsrFlgKeyT pUsrFlgKey, pUsrFlgRcrdT * ppUsrFlg, uint32 * pUsrFlgPos)
{
    BEGIN_FUNCTION("UsrFlgChkExt");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gUsrFlgHndl, (void*)pUsrFlgKey, &isExist, pUsrFlgPos, (void**)ppUsrFlg);
    RAISE_ERR(rc, RTN);
    
    if (isExist == FALSE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




ResCodeT UsrFlgLogByPos(uint32 UsrFlgPos, pUsrFlgRcrdT pUsrFlg)
{
    BEGIN_FUNCTION("UsrFlgLogByPos");
    ResCodeT rc = NO_ERR;

    rc = CmnHashLogData(gUsrFlgHndl, pUsrFlg, UsrFlgPos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT UsrFlgAdd(pUsrFlgRcrdT pUsrFlg, uint32 * pUsrFlgPos)
{
    BEGIN_FUNCTION("UsrFlgAdd");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    uint32 nodePos;
    pUsrFlgRcrdT  pTempUsrFlg;
    
    rc = CmnHashCheckDataExt(gUsrFlgHndl, (void*)&pUsrFlg->usrFlgKey, &isExist, &nodePos, (void**)&pTempUsrFlg);
    RAISE_ERR(rc, RTN);
    
    *pUsrFlgPos = nodePos;

    if (isExist == TRUE)
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
    }
   
    rc = CmnHashLogData(gUsrFlgHndl, pUsrFlg, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UsrFlgUpdtByPos(uint32 UsrFlgPos, pUsrFlgRcrdT pUsrFlg)
{
    BEGIN_FUNCTION("UsrFlgUpdtByPos");
    ResCodeT rc = NO_ERR;

    rc = CmnHashUpdateData(gUsrFlgHndl, (void*) pUsrFlg, UsrFlgPos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT SetUsrFlg(pUsrFlgKeyT pUsrFlgKey, UsrFlgTypeT usrFlg)
{
    BEGIN_FUNCTION("SetUsrFlg");
    ResCodeT        rc = NO_ERR;
    pUsrFlgRcrdT   pUsrFlg = NULL;
    uint32          usrFlgPos = CMN_LIST_NULL_NODE;
    
    if (usrFlg >= USR_FLG_MAX)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN); 
    }

    rc = UsrFlgChkExt(pUsrFlgKey, &pUsrFlg, &usrFlgPos);
    RAISE_ERR(rc, RTN);
    
    BitSet(pUsrFlg->usrFlgVct, usrFlg);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT ResetUsrFlg(pUsrFlgKeyT pUsrFlgKey, UsrFlgTypeT usrFlg)
{
    BEGIN_FUNCTION("ResetUsrFlg");
    ResCodeT        rc = NO_ERR;
    pUsrFlgRcrdT   pUsrFlg = NULL;
    uint32          usrFlgPos = CMN_LIST_NULL_NODE;
    
    if (usrFlg >= USR_FLG_MAX)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN); 
    }

    rc = UsrFlgChkExt(pUsrFlgKey, &pUsrFlg, &usrFlgPos);
    RAISE_ERR(rc, RTN);
    
    BitReset(pUsrFlg->usrFlgVct, usrFlg);

    EXIT_BLOCK();
    RETURN_RESCODE;

}



ResCodeT GetUsrFlg(pUsrFlgKeyT pUsrFlgKey, UsrFlgTypeT usrFlg, BOOL * pbFlgChked)
{
    BEGIN_FUNCTION("GetUsrFlg");
    ResCodeT        rc = NO_ERR;
    pUsrFlgRcrdT   pUsrFlg = NULL;
    uint32          usrFlgPos = CMN_LIST_NULL_NODE;
    
    if (usrFlg >= USR_FLG_MAX)
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN); 
    }

    rc = UsrFlgChkExt(pUsrFlgKey, &pUsrFlg, &usrFlgPos);
    RAISE_ERR(rc, RTN);
    
    * pbFlgChked = BitCheck(pUsrFlg->usrFlgVct, usrFlg);


    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT UsrFlgIter(uint32* nodePos, pUsrFlgRcrdT  pUsrFlg)
{
    BEGIN_FUNCTION("IterMgmt");
    ResCodeT rc = NO_ERR;
    uint32 pos;
    
    rc = CmnHashIterData(gUsrFlgHndl, &pos, (void*)pUsrFlg);
    RAISE_ERR(rc, RTN);
    *nodePos = pos;
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

