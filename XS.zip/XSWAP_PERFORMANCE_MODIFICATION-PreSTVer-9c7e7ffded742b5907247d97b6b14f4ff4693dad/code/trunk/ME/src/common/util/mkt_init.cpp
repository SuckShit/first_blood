/***
Created on Sep 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>              /* define wait handling functions     */
#include <errno.h>
#include <pthread.h>
/* Project Header File*/
#include "common_macro.h"
#include "msg_type.h"
#include "err_lib.h"
#include "base_param.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

/******************************************************************************
* Description:   Init working epoll queue
* Parameters:
*      pInQHndl    IN  input queue handle array
*      N/A         OUT
*      NO_ERR:     Successful
*      ERR_<DSCR>: fail to Init the share memory.
******************************************************************************/
ResCodeT MktInit()
{
    BEGIN_FUNCTION( "MktInit" );
    ResCodeT            rc = NO_ERR;
    
    BaseParamT          batFlgParam = {0}, initFlgParam = {0};
    
    rc = BaseParamGetByName((char *)BASE_PARA_BAT_FLG, &batFlgParam);
    RAISE_ERR(rc, RTN);
    
    if (batFlgParam.paramValue[0] != WKSG_LIT_YES)
    {
        LOG_DEBUG("Batch flag is %c instead of %c", batFlgParam.paramValue[0], WKSG_LIT_YES);
        RAISE_ERR(ERR_BAT_FLG_NOT_YES, RTN);
    }
    
//    rc = BaseParamGetByName((char *)BASE_PARA_INIT_FLG, &initFlgParam);
//    RAISE_ERR(rc, RTN);
//    
//    if (initFlgParam.paramValue[0] == WKSG_LIT_YES)
//    {
//        LOG_DEBUG("Market already Init");
//        THROW_RESCODE(NO_ERR);
//    }
//    else
//    {
//        LOG_DEBUG("Init flag is %c instead of %c", initFlgParam.paramValue[0], WKSG_LIT_YES);
//        RAISE_ERR(ERR_MKT_NOT_INIT, RTN);
//    }
//    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of MktInit */
