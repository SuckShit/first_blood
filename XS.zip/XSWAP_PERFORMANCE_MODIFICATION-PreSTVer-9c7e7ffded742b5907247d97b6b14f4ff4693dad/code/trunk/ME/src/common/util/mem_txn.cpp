﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "data_type.h"
#include "err_lib.h"
#include "mem_txn.h"
#include "mem_txn_elem.h"
#include "common_macro.h"
#include "shm.h"
#include "shm_name.h"
#include "uti_tool.h"
#include "cfg_lib.h"
#include "db_comm.h"
#include "MemTxnTblDb.h"
#include "MemTxnDatTblDb.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


#define GET_TXN_ENTY_BY_ID( _txnId_) \
        (ADDRESS_ADD_OFFSET(gMemTxnAcs[gSetId].pRtTxnEntry, sizeof(MemTxnEntryT) * ((_txnId_) -1)))

#define GET_TXN_DATA_BY_SLOT( _SlotId_)\
        (ADDRESS_ADD_OFFSET(gMemTxnAcs[gSetId].pRtDatCtrl, (sizeof(MemTxnDataHdrT) + gMemTxnAcs.pSetShmInfo->dataSize)* (_SlotId_)))


#define GET_TTL_SET_MEM_SIZE( _set_mem_info_) (_set_mem_info_->memTxnAreaSize + _set_mem_info_->memDataAreaSize)

#define GET_TXN_MSG_SIZE(_dataCnt_, _dataSize_) (sizeof(MemTxnEntryT) + ((sizeof(DatCtrlT) + _dataSize_) * _dataCnt_))




#ifndef CHK_MEM_TXN_INIT
#define CHK_MEM_TXN_INIT()\
do\
{\
    if (!gInit)\
    {\
        RAISE_ERR(ERR_MEM_TXN_NOT_INIT,RTN);\
    }\
} while (0);
#endif


#ifndef CHK_TXN_ID
#define CHK_TXN_ID(_txnId_)\
do\
{\
    if (_txnId_ > gMemTxnAcs[gSetId].pTxnCtrl->maxTxnId)\
    {\
        RAISE_ERR(ERR_MEM_TXN_EXCD_MAX_TXN_ID,RTN);\
    }\
} while (0);
#endif
//
//#define CURR_DAT_SQNO()         (gMemTxnAcs[gSetId].currDatCtrl.pDataSqno)
//#define CURR_DAT_TTL_SIZE()     (gMemTxnAcs[gSetId].currDatCtrl.pDataTtlSize)
//#define CURR_DAT_CNT()          (gMemTxnAcs[gSetId].currDatCtrl.pDataCnt)
//#define CURR_DAT_PRE_SQNO()     (gMemTxnAcs[gSetId].currDatCtrl.prevDataSqno)
//#define CURR_DAT_NXT_SQNO()     (gMemTxnAcs[gSetId].currDatCtrl.nextDataSqno)
#define GET_DAT_IDX(_currDatCnt_)  ((_currDatCnt_) - 1)


#define ADD_CURR_DAT_ELEM_TTL_SIZE(_currDatCnt_, _val_)  ((gMemTxnAcs[gSetId].datCtrl.pElemTtlSize[GET_DAT_IDX(_currDatCnt_)]) += (_val_))
#define ADD_CURR_DAT_ELEM_CNT(_currDatCnt_, _val_)       ((gMemTxnAcs[gSetId].datCtrl.pElemCnt[GET_DAT_IDX(_currDatCnt_)]) += (_val_))


#define SET_CURR_DAT_SQNO(_currDatCnt_, _val_)      (gMemTxnAcs[gSetId].datCtrl.pDataSqno[GET_DAT_IDX(_currDatCnt_)] = (_val_))
#define SET_CURR_DAT_ELEM_TTL_SIZE(_currDatCnt_, _val_)  (gMemTxnAcs[gSetId].datCtrl.pElemTtlSize[GET_DAT_IDX(_currDatCnt_)] = (_val_))
#define SET_CURR_DAT_ELEM_CNT(_currDatCnt_, _val_)       (gMemTxnAcs[gSetId].datCtrl.pElemCnt[GET_DAT_IDX(_currDatCnt_)] = (_val_))
#define SET_CURR_DAT_PRE_SQNO(_currDatCnt_, _val_)  (gMemTxnAcs[gSetId].datCtrl.prevDataSqno[GET_DAT_IDX(_currDatCnt_)] = (_val_))
#define SET_CURR_DAT_NXT_SQNO(_currDatCnt_, _val_)  (gMemTxnAcs[gSetId].datCtrl.nextDataSqno[GET_DAT_IDX(_currDatCnt_)] = (_val_))
#define SET_CURR_MSG_SQNO(_currDatCnt_, _val_)  (gMemTxnAcs[gSetId].datCtrl.currMsgSqno[GET_DAT_IDX(_currDatCnt_)] = (_val_))


#define GET_CURR_DAT_RT_ELEM_ADDR(_currDatCnt_)     (ADDRESS_ADD_OFFSET(gMemTxnAcs[gSetId].datCtrl.pRtElemAddr, GET_DAT_IDX(_currDatCnt_)*gMemTxnAcs[gSetId].pSetShmInfo->dataSize))

#define GET_CURR_DAT_SQNO(_currDatCnt_)             (gMemTxnAcs[gSetId].datCtrl.pDataSqno[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_ELEM_TTL_SIZE(_currDatCnt_)    (gMemTxnAcs[gSetId].datCtrl.pElemTtlSize[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_ELEM_CNT(_currDatCnt_)         (gMemTxnAcs[gSetId].datCtrl.pElemCnt[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_PRE_SQNO(_currDatCnt_)         (gMemTxnAcs[gSetId].datCtrl.prevDataSqno[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_NXT_SQNO(_currDatCnt_)         (gMemTxnAcs[gSetId].datCtrl.nextDataSqno[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_MSG_SQNO(_currDatCnt_)             (gMemTxnAcs[gSetId].datCtrl.currMsgSqno[GET_DAT_IDX(_currDatCnt_)])


#define GET_CURR_DAT_SQNO_ADDR(_currDatCnt_)             (&gMemTxnAcs[gSetId].datCtrl.pDataSqno[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_ELEM_TTL_SIZE_ADDR(_currDatCnt_)    (&gMemTxnAcs[gSetId].datCtrl.pElemTtlSize[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_ELEM_CNT_ADDR(_currDatCnt_)         (&gMemTxnAcs[gSetId].datCtrl.pElemCnt[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_PRE_SQNO_ADDR(_currDatCnt_)         (&gMemTxnAcs[gSetId].datCtrl.prevDataSqno[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_DAT_NXT_SQNO_ADDR(_currDatCnt_)         (&gMemTxnAcs[gSetId].datCtrl.nextDataSqno[GET_DAT_IDX(_currDatCnt_)])
#define GET_CURR_MSG_SQNO_ADDR(_currDatCnt_)             (&gMemTxnAcs[gSetId].datCtrl.currMsgSqno[GET_DAT_IDX(_currDatCnt_)])


#define GET_ELEM_DATA_SIZE(_elemSize_)     (_elemSize_ - (sizeof(DatElemHdrT)*2))
#define GET_ELEM_SIZE(_dataSize_)     ((sizeof(DatElemHdrT)*2) + _dataSize_)

#define GET_MAX_DATA_SIZE()     (gMemTxnAcs[gSetId].pSetShmInfo->dataSize)


#define INIT_DAT_CTRL(_dataSqno_)\
do\
{\
    SET_CURR_DAT_SQNO(_dataSqno_, 0);\
    SET_CURR_DAT_ELEM_TTL_SIZE(_dataSqno_, 0);\
    SET_CURR_DAT_ELEM_CNT(_dataSqno_, 0);\
    SET_CURR_DAT_PRE_SQNO(_dataSqno_, NO_DATA_SQNO);\
    SET_CURR_DAT_NXT_SQNO(_dataSqno_, NO_DATA_SQNO);\
} while (0);


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MemTxnAcsS
{
    int32               setId;
    
    pShmInfoT           pShmInfo;
    pSetShmInfoT        pSetShmInfo;
    
    pMemTxnCtrlT        pTxnCtrl;
    
    pMemTxnEntryT       pRtTxnEntry;
    pMemTxnEntryT       pCurrTxnEntry;
    
    RtDatCtrlT          datCtrl;
    RtDatCtrlT          currDatCtrl;

    
} MemTxnAcsT, *pMemTxnAcsT;


typedef struct WrtElemCtxS
{
    pMemTxnCtrlT pTxnCtrl;
    pDatElemHdrT pDatElemHdr;
    int32 dataLen;
    
} WrtElemCtxT, *pWrtElemCtxT;



typedef struct IterElemCtxS
{
    int32 setId;
    int32 currTxnId;
    int32 endTxnId;
    int32 currDataSqno;
    int32 currDataCnt; 
    int32 currElemCnt;
    void * currElemAddr;  
} IterElemCtxT, *pIterElemCtxT;


typedef struct MemTxnDataRdModeS
{
    MemTxnUserModeT         memTxnUser;

    BOOL                    readOnly;
    BOOL                    allElemType;

    vectorT                 elemUserType[GET_BIT_VECT_LEN(MT_TYPE_MAX + 1)];
} MemTxnDataRdModeT, *pMemTxnDataRdModeT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static MemTxnAcsT   gMemTxnAcs[MAX_SET_CNT] = {0};
static BOOL         gInit = FALSE;
static int32        gSetId = 0;
static WrtElemCtxT  gWrtElemCtx;
static IterElemCtxT gIterElemCtx = {0};
static int32        gDbHndl = -1;
static int32        gbRplyMode = FALSE;

static MemTxnDataRdModeT    gMemTxnRdMode = {0};
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
/******************************************************************************
 * Description:   Calculate set mem size
 * Parameters:
 *      pMemTxnCfg  IN  include how many txn will be support by this set memory
 *      pSetShmInfo OUT mem size
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
int64 CalcSetMemSize (pMemTxnCfgT pMemTxnCfg, pSetShmInfoT pSetShmInfo)
{
    BEGIN_FUNCTION( "CalcSetMemSize" );
    
    int64       ttlMemSize = 0;
   
    pSetShmInfo->setId = pMemTxnCfg->setId;
    
    /* each set memory will have one control area, and mutiple txn entry and data record */
    pSetShmInfo->memTxnAreaSize = sizeof(MemTxnCtrlT) + pMemTxnCfg->nmbrOfTxn * sizeof(MemTxnEntryT);
    pSetShmInfo->memDataAreaSize = pMemTxnCfg->nmbrOfTxn * (sizeof(DatCtrlT) + pMemTxnCfg->dataSize);
    
    pSetShmInfo->maxTxnCnt = pMemTxnCfg->nmbrOfTxn;
    pSetShmInfo->dataSize = pMemTxnCfg->dataSize;
    
    ttlMemSize = GET_TTL_SET_MEM_SIZE(pSetShmInfo);

    EXIT_BLOCK();
    
    return ttlMemSize;
}


/******************************************************************************
 * Description:   Map the share memory access structure
 * Parameters:
 *      pSetRoot     IN  Set the root of shm
 *      pSetShmInfo  IN  Set information of shm
 *      pMemTxnAcs   OUT Each section's datCtrl
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to map the share memory.
 ******************************************************************************/
void MapSetShmAcs(void * pSetRoot, pSetShmInfoT pSetShmInfo, pMemTxnAcsT pMemTxnAcs)
{
    BEGIN_FUNCTION( "MapSetShmAcs" );
    
    pMemTxnAcs->setId = pSetShmInfo->setId;
    pMemTxnAcs->pTxnCtrl = (pMemTxnCtrlT)pSetRoot;
    
    pMemTxnAcs->pRtTxnEntry = (pMemTxnEntryT)ADDRESS_ADD_OFFSET(pMemTxnAcs->pTxnCtrl, sizeof(MemTxnCtrlT));        
    
    pMemTxnAcs->datCtrl.pDataSqno = (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->pRtTxnEntry, pSetShmInfo->memTxnAreaSize);
    pMemTxnAcs->datCtrl.pElemTtlSize =  (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->datCtrl.pDataSqno, pSetShmInfo->maxTxnCnt * sizeof(int32));
    pMemTxnAcs->datCtrl.pElemCnt = (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->datCtrl.pElemTtlSize, pSetShmInfo->maxTxnCnt * sizeof(int32));
    pMemTxnAcs->datCtrl.prevDataSqno = (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->datCtrl.pElemCnt, pSetShmInfo->maxTxnCnt * sizeof(int32));
    pMemTxnAcs->datCtrl.nextDataSqno = (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->datCtrl.prevDataSqno, pSetShmInfo->maxTxnCnt * sizeof(int32));
    pMemTxnAcs->datCtrl.currMsgSqno = (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->datCtrl.nextDataSqno, pSetShmInfo->maxTxnCnt * sizeof(int32));
    pMemTxnAcs->datCtrl.pRtElemAddr = (int32 *)ADDRESS_ADD_OFFSET(pMemTxnAcs->datCtrl.currMsgSqno, pSetShmInfo->maxTxnCnt * sizeof(int32));
    
    EXIT_BLOCK();
}



/******************************************************************************
 * Description:   Initialize the memory txn share memory
 * Parameters:
 *      pMemTxnAcs  IN  Each section's root address
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to initialize the share memory.
 ******************************************************************************/
void InitSetMemTxnShm(pMemTxnAcsT pMemTxnAcs)
{
    BEGIN_FUNCTION( "InitSetMemTxnShm" );
    
    pMemTxnAcs->pTxnCtrl->currTxnId = 0;
    pMemTxnAcs->pTxnCtrl->commitTxnId = 0;
    pMemTxnAcs->pTxnCtrl->maxTxnId = pMemTxnAcs->pSetShmInfo->maxTxnCnt;

    pMemTxnAcs->pTxnCtrl->currDataCnt = 0;
    pMemTxnAcs->pTxnCtrl->maxDataCnt = pMemTxnAcs->pSetShmInfo->maxTxnCnt;
    pMemTxnAcs->pTxnCtrl->elemCnt = 0;
    
    pMemTxnAcs->pTxnCtrl->currMsgSqno = 0;
    
    EXIT_BLOCK();
}



/******************************************************************************
 * Description:   Map the share memory access structure
 * Parameters:
 *      bInit        IN  need to init the share memory
 *      pRoot        IN  share memory root
 *      pShmInfo     IN  The share memory size info
 *      pSetShmInfo  IN  The set share memory size info
 *      pMemTxnAcs   OUT Each section's root address
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to map the share memory.
 ******************************************************************************/
void MapMemTxnShmAcs( BOOL bInit, void * pRoot, pShmInfoT pShmInfo, pSetShmInfoT pSetShmInfo, pMemTxnAcsT pMemTxnAcs)
{
    BEGIN_FUNCTION( "MapMemTxnShmAcs" );
    int32   setId = 0;
    void*   pSetRoot = NULL;
    int32   i = 0;
    pSetShmInfoT pCurrSetShmInfo  = NULL;
    /* Set the global area */
    
    pSetRoot = (void*)ADDRESS_ADD_OFFSET(pRoot,sizeof(ShmInfoT) + sizeof(SetShmInfoT) * pShmInfo->setCnt );
    for (i=0; i<pShmInfo->setCnt; i++)
    {
        setId = pSetShmInfo[i].setId;
        
        pMemTxnAcs[setId].setId = setId;
        pMemTxnAcs[setId].pShmInfo = (pShmInfoT)pRoot;
        
        /* point to 1st and then move to the specific one*/
        pMemTxnAcs[setId].pSetShmInfo = (pSetShmInfoT)ADDRESS_ADD_OFFSET(pMemTxnAcs[setId].pShmInfo,sizeof(ShmInfoT) + sizeof(SetShmInfoT) * i);

        MapSetShmAcs(pSetRoot, &pSetShmInfo[i], &pMemTxnAcs[setId]);
        
        if (bInit)
        {
            InitSetMemTxnShm(&pMemTxnAcs[setId]);
        }
        pCurrSetShmInfo = &pSetShmInfo[i];
        pSetRoot = (void*)ADDRESS_ADD_OFFSET(pSetRoot, GET_TTL_SET_MEM_SIZE(pCurrSetShmInfo));
    }

    EXIT_BLOCK();
}


/******************************************************************************
 * Description:   Create txn memory for all set
 * Parameters:
 *      pMemTxnCfg  IN  include how many txn will be support by this set memory
 *      cfgCnt      IN  number of set
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MemTxnShmCreateForAllSet(pMemTxnCfgT pMemTxnCfg, int32 cfgCnt)
{
    BEGIN_FUNCTION( "MemTxnShmCreateForAllSet" );
    ResCodeT    rc = NO_ERR;
    int32       i = 0;
    SetShmInfoT      setShmInfo[MAX_SET_CNT];
    ShmInfoT         shmInfo;
    void *      pRoot = NULL;
    void *      pSetRoot = NULL;
    char    shmName[]= SHM_MEM_TXN_NAME;
    
    if (gInit)
    {
        THROW_RESCODE(NO_ERR);
    }
    if ( NULL == pMemTxnCfg )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    
    
    memset(&shmInfo, 0x00, sizeof(ShmInfoT));
    memset(setShmInfo, 0x00, sizeof(SetShmInfoT)*MAX_SET_CNT);
    
    memset(gMemTxnAcs,0x00, sizeof(MemTxnAcsT)*MAX_SET_CNT);
   
    /* Calculate the total memor size, and populate the memory control area*/
    for (i=0; i<cfgCnt; i++)
    {   
        CHK_SET_ID(pMemTxnCfg[i].setId);
        
        shmInfo.memTtlSize += CalcSetMemSize(&pMemTxnCfg[i], &setShmInfo[i]);
    }
    shmInfo.setCnt = cfgCnt;
    
    /* add global area size */
    shmInfo.memTtlSize += sizeof(ShmInfoT) + sizeof(SetShmInfoT) * shmInfo.setCnt;
    
    rc = ShmCreate(GetShmNm(shmName), shmInfo.memTtlSize, (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    /* Set the global area */
    memcpy(pRoot, &shmInfo, sizeof(ShmInfoT));
    pSetRoot = (void*)ADDRESS_ADD_OFFSET(pRoot, sizeof(ShmInfoT));
    memcpy(pSetRoot,setShmInfo, sizeof(SetShmInfoT)*shmInfo.setCnt);
    
    MapMemTxnShmAcs( TRUE, pRoot, &shmInfo, setShmInfo, gMemTxnAcs);
        
    gInit = TRUE;

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   Init memory txn share memory
 * Parameters:
 *      setId       IN     setId
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnShmInit(int32 setId)
{
    BEGIN_FUNCTION( "MemTxnShmInit" );
    int64       memTtlSize = 0;
    void *      pRoot = NULL;
    ResCodeT    rc = NO_ERR;
    pSetShmInfoT      pSetShmInfo = NULL;
    pShmInfoT         pShmInfo = NULL;
    char    shmName[]= SHM_MEM_TXN_NAME;
    
    if (gMemTxnAcs[setId].setId == setId)
    {
        gSetId = gMemTxnAcs[setId].setId;
        
        THROW_RESCODE(NO_ERR);
    }
    
    rc = ShmAttach(GetShmNm(shmName), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    pShmInfo = (pShmInfoT)pRoot;
    pSetShmInfo = (pSetShmInfoT)ADDRESS_ADD_OFFSET(pShmInfo,sizeof(ShmInfoT));
    
    MapMemTxnShmAcs( FALSE, pRoot, pShmInfo, pSetShmInfo, gMemTxnAcs);
    
    gInit = TRUE;
    gSetId = setId;
   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   Detach memory txn share memory
 * Parameters:
 *      N/A         IN 
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnShmDetach()
{
    BEGIN_FUNCTION( "MemTxnShmDetach" );
    ResCodeT    rc = NO_ERR;
    char    shmName[]= SHM_MEM_TXN_NAME;
    
    if (!gInit)
    {
        RAISE_ERR(ERR_MEM_TXN_INVLD_INIT_STS, RTN);;
    }

    rc = ShmDetach(GetShmNm(shmName));
    RAISE_ERR(rc, RTN);

    gInit = FALSE;
    gSetId = 0;
   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}


/******************************************************************************
 * Description:   Delete memory txn share memory
 * Parameters:
 *      N/A         IN 
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnShmDelete()
{
    BEGIN_FUNCTION( "MemTxnShmDelete" );
    ResCodeT    rc = NO_ERR;
    char    shmName[]= SHM_MEM_TXN_NAME;
    
    if (gInit)
    {
        RAISE_ERR(ERR_MEM_TXN_INVLD_INIT_STS, RTN);
    }

    rc = ShmDelete(GetShmNm(shmName));
    RAISE_ERR(rc, RTN);

   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}


/******************************************************************************
 * Description:   Set the txnId for iterate
 * Parameters:
 *      txnId           IN      set
 *      txnId           IN      txn id
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT SetTxnIdForIter(int32 set, int32 txnId)
{
    BEGIN_FUNCTION( "MemTxnIterElem" );
    pMemTxnCtrlT    pTxnCtrl = NULL;
    pMemTxnEntryT   pTxnEntry = NULL;
    
    gSetId = set;
    pTxnCtrl = (pMemTxnCtrlT)gMemTxnAcs[gSetId].pTxnCtrl;
    
    if (txnId > pTxnCtrl->commitTxnId)
    {
        THROW_RESCODE(ERR_MEM_TXN_ITER_DATA_END);
    }
    
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(txnId);
    
    gIterElemCtx.currDataSqno = pTxnEntry->frstDataSqno; 
    gIterElemCtx.currDataCnt = pTxnEntry->dataCnt; 
    
    gIterElemCtx.currElemAddr = (void *)ADDRESS_ADD_OFFSET(GET_CURR_DAT_RT_ELEM_ADDR(gIterElemCtx.currDataSqno) , 0);  
    gIterElemCtx.currElemCnt = GET_CURR_DAT_ELEM_CNT(gIterElemCtx.currDataSqno);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   format txn message buffer 
 * Parameters:
 *      pRtDataCtrl     IN      root data ctrl
 *      pTxnEntry       IN      txn entry
 *      pData           IN      data address
 *      pDataLen        OUT     length of data
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT FmtTxnMsgBuff(pRtDatCtrlT pRtDataCtrl, pMemTxnEntryT  pTxnEntry, void * pData, int32 * pDataLen, int32 * pDatIdx)
{
    BEGIN_FUNCTION( "FmtTxnMsgBuff" );
    ResCodeT rc = NO_ERR;
    int32 msgBuffLen = 0;
    int32 fieldDataSize = 0;
    void * pCurrDataAddr = NULL;
    void * pCurrElemAddr = NULL;
    pDatCtrlT  pDatCtrl = NULL;
    pMemTxnCtrlT pTxnCtrl = NULL;
    int32    i = 0;
    pMemTxnEntryT pTmpTxnEntry = NULL;
    
    pCurrDataAddr = pData;
    
    pTxnCtrl = (pMemTxnCtrlT)gMemTxnAcs[gSetId].pTxnCtrl;
    
    /* copy txn entry */
    pTmpTxnEntry = (pMemTxnEntryT)pCurrDataAddr;
    memcpy(pCurrDataAddr, pTxnEntry, sizeof(MemTxnEntryT));
    msgBuffLen += sizeof(MemTxnEntryT);
    
    pCurrDataAddr = (void *)ADDRESS_ADD_OFFSET(pData , msgBuffLen);  
    
    //pCurrElemAddr = pRtDataCtrl->pRtElemAddr;  
    
    pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET( pRtDataCtrl->pRtElemAddr , (* pDatIdx)*pTxnEntry->dataSize); 
    
    for (i=(* pDatIdx); i<pTxnEntry->dataCnt; i++)
    {
        pDatCtrl = (pDatCtrlT)pCurrDataAddr;
        
        if ((msgBuffLen + sizeof(DatCtrlT) + pRtDataCtrl->pElemTtlSize[i]) > MAX_MSG_LEN)
        {   
            pTmpTxnEntry->dataCnt = i; //as count not idx.
            * pDatIdx = i;
            * pDataLen = msgBuffLen;
            LOG_DEBUG("Full till Data %d", *pDatIdx);
            THROW_RESCODE(NO_ERR); 
        }
        
        msgBuffLen += sizeof(DatCtrlT);
        msgBuffLen += pRtDataCtrl->pElemTtlSize[i];    
        
        
        
        pDatCtrl->dataSqno = pRtDataCtrl->pDataSqno[i];
        pDatCtrl->elemTtlSize = pRtDataCtrl->pElemTtlSize[i];
        pDatCtrl->elemCnt = pRtDataCtrl->pElemCnt[i];
    
        pDatCtrl->prevDataSqno = pRtDataCtrl->prevDataSqno[i];
        pDatCtrl->nextDataSqno = pRtDataCtrl->nextDataSqno[i];
        
        /* Gen the msg sqno for the data */
        pDatCtrl->currMsgSqno = pTxnCtrl->currMsgSqno;
        pRtDataCtrl->currMsgSqno[i] = pTxnCtrl->currMsgSqno;
        
        /* move the data control and start to copy the actual element data */
        pDatCtrl = (pDatCtrlT)ADDRESS_ADD_OFFSET(pDatCtrl , sizeof(DatCtrlT));
        
        memcpy(pDatCtrl, pCurrElemAddr,pRtDataCtrl->pElemTtlSize[i]);
 
        pCurrDataAddr = (void *)ADDRESS_ADD_OFFSET(pData , msgBuffLen);  
        pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET(pCurrElemAddr , pTxnEntry->dataSize);  
    
    }
    * pDatIdx = 0; //till the end
    pTmpTxnEntry->dataCnt = pTxnEntry->dataCnt - (*pDatIdx);     
    LOG_DEBUG("FmtTxnMsgBuff to TDPS Len %d", msgBuffLen);
    
    
    
    * pDataLen = msgBuffLen;

    EXIT_BLOCK();
    /* Increase the msg sqno for the data */
    pTxnCtrl->currMsgSqno ++;
    
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Memory txn  iterate element from buffer
 * Parameters:
 *      pInBuff         IN      input buffer
 *      pElemType       OUT     element type
 *      ppData          OUT     address of data
 *      pDataLen        OUT     lenth of data
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnIterElemFromBuff(void * pInBuff,  MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen)
{
    BEGIN_FUNCTION( "MemTxnIterElemFromBuff" );
    ResCodeT rc = NO_ERR;
   
    static pMemTxnEntryT   pMemTxnEntry = NULL;
    static pDatCtrlT       pDatCtrl = NULL;
    static void *   pCurrElemAddr = NULL;
    
    static int32 dataIdx = 0, elemIdx = 0;
    
    pDatElemHdrT    pElemHdr = NULL;
    void *          pElemDat = NULL;
    int32           elemSize = 0;
    
    if (pInBuff)
    {    
        pMemTxnEntry = (pMemTxnEntryT)pInBuff;
        pDatCtrl = (pDatCtrlT)ADDRESS_ADD_OFFSET(pMemTxnEntry, sizeof(MemTxnEntryT));
        pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET(pDatCtrl, sizeof(DatCtrlT));
        
        dataIdx = 0;
        elemIdx = 0;
    }
    
    if (dataIdx >= pMemTxnEntry->dataCnt)
    {
        THROW_RESCODE(ERR_MEM_TXN_ITER_DATA_END);
    }
    
            
    /* Process each element data */
    GetElemAddrFromHead(pCurrElemAddr, &pElemHdr, ppData, pDataLen);
    * pElemType = (MTElemTypeT)pElemHdr->elemType;
    
    elemIdx++;
    
    if (elemIdx >= pDatCtrl->elemCnt)
    {   /* all elem of this data entry is finished.. */
        dataIdx ++;
        elemIdx = 0;
        
        pDatCtrl = (pDatCtrlT)ADDRESS_ADD_OFFSET(pDatCtrl, sizeof(DatCtrlT) + pDatCtrl->elemTtlSize);
        pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET(pDatCtrl, sizeof(DatCtrlT));

    }
    else
    {
        pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET(pCurrElemAddr, pElemHdr->elemSize);  
    }
    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Iterate elements in memory txn 
 * Parameters:
 *      set             IN      Input set value
 *      startTxnId      IN      Input start txnId
 *      endTxnId        IN      Input end txnId
 *      pElemType       OUT     All type of elements
 *      pDataLen        OUT     Lenth of all data
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to set txn Id
 ******************************************************************************/
ResCodeT MemTxnIterElem(int32 set, int32 startTxnId,int32 endTxnId, MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen)
{
    BEGIN_FUNCTION( "MemTxnIterElem" );
    ResCodeT rc = NO_ERR;
    pDatElemHdrT    pElemHdr = NULL;
    
    gIterElemCtx.setId = set;
    gIterElemCtx.currTxnId = startTxnId;
    gIterElemCtx.endTxnId = endTxnId;
    
    
    rc = SetTxnIdForIter(set, gIterElemCtx.currTxnId);
    RAISE_ERR(rc,RTN);
    
    GetElemAddrFromHead(gIterElemCtx.currElemAddr, &pElemHdr, ppData, pDataLen);
    * pElemType = (MTElemTypeT)pElemHdr->elemType;
    
    /*data returned, move to next element */
    gIterElemCtx.currElemAddr = (void *)ADDRESS_ADD_OFFSET(gIterElemCtx.currElemAddr , pElemHdr->elemSize);  
    gIterElemCtx.currElemCnt--;
 
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Iterate the following elements in memory txn
 * Parameters:
 *      set             IN      Input set value
 *      currTxnId       IN      Input current txnId
 *      pElemType       OUT     All type of elements
 *      pDataLen        OUT     Lenth of all data
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to start iterate 
 ******************************************************************************/
ResCodeT MemTxnIterElemNext(int32 set, int32 * currTxnId, MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen)
{
    BEGIN_FUNCTION( "MemTxnIterElem" );
    ResCodeT        rc = NO_ERR;
    pMemTxnCtrlT    pTxnCtrl = NULL;
    pMemTxnEntryT   pTxnEntry = NULL;
    pDatElemHdrT    pElemHdr = NULL;
    
       
    if (0 == gIterElemCtx.currElemCnt)
    {
        /* need move to next data entry */
        
        gIterElemCtx.currDataSqno = GET_CURR_DAT_NXT_SQNO(gIterElemCtx.currDataSqno);
        
        if ( NO_DATA_SQNO == gIterElemCtx.currDataSqno)
        {
            /*next data sqno is null, move to next txnId */
            if ((gIterElemCtx.currTxnId+1) > gIterElemCtx.endTxnId)
            {
                THROW_RESCODE(ERR_MEM_TXN_ITER_DATA_END);
            }
            
            gIterElemCtx.currTxnId ++;
            
            rc = SetTxnIdForIter(set, gIterElemCtx.currTxnId);
            if (ERR_MEM_TXN_ITER_DATA_END == rc )
            {
                THROW_RESCODE(rc);
            }
            RAISE_ERR(rc,RTN);
           
        }
        else
        {   
            /* get next data sqno*/
                        
            gIterElemCtx.currDataCnt--; 
            
            gIterElemCtx.currElemAddr = (void *)ADDRESS_ADD_OFFSET(GET_CURR_DAT_RT_ELEM_ADDR(gIterElemCtx.currDataSqno) , 0);  
            gIterElemCtx.currElemCnt = GET_CURR_DAT_ELEM_CNT(gIterElemCtx.currDataSqno);

        }
    }
    
    GetElemAddrFromHead(gIterElemCtx.currElemAddr, &pElemHdr, ppData, pDataLen);
    * pElemType = (MTElemTypeT)pElemHdr->elemType;
    * currTxnId = gIterElemCtx.currTxnId;
  
    /*data returned, move to next element */
    gIterElemCtx.currElemAddr = (void *)ADDRESS_ADD_OFFSET(gIterElemCtx.currElemAddr , pElemHdr->elemSize);  
    gIterElemCtx.currElemCnt--;
 
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Get memory txn information
 * Parameters:
 *      set             IN      set id
 *      txnId           IN      txnId
 *      pTxnCtrl       OUT     txn ctrl info
 *      pTxnEntry       OUT     txn entry info
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnGetTxnInfo(int32 set, int64 txnId, pMemTxnCtrlT pTxnCtrl, pMemTxnEntryT pTxnEntry )
{
    BEGIN_FUNCTION( "MemTxnGetTxnInfo" );
    pMemTxnEntryT pTmpTxnEntry = NULL;
    
    if ( NULL == pTxnCtrl || NULL == pTxnEntry )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    if (txnId > gMemTxnAcs[set].pTxnCtrl->maxTxnId)
    {
        RAISE_ERR(ERR_MEM_TXN_EXCD_MAX_TXN_ID,RTN);
    }
    
    memcpy(pTxnCtrl, gMemTxnAcs[set].pTxnCtrl, sizeof(MemTxnCtrlT));
    
    pTmpTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(txnId);
    
    memcpy(pTxnEntry, pTmpTxnEntry, sizeof(MemTxnEntryT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Get txn entry exit
 * Parameters:
 *      set             IN      set
 *      txnId           IN      txn id
 *      pTxnEntry       OUT     txn entry info
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnGetTxnEntryExt(int32 set, int64 txnId,  pMemTxnEntryT * ppTxnEntry )
{
    BEGIN_FUNCTION( "MemTxnGetTxnEntryExt" );
    
    * ppTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(txnId);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Get data information of memory txn.
 * Parameters:
 *      set             IN      set id
 *      dataSqno        IN      data sqno
 *      pDatCtrl        OUT     data cntrl
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnGetDataInfo(int32 set, int64 dataSqno, pDatCtrlT pDatCtrl )
{
    BEGIN_FUNCTION( "MemTxnGetDataInfo" );
    pMemTxnEntryT pTmpTxnEntry = NULL;
    
    if ( NULL == pDatCtrl )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    gSetId = set;
    
    pDatCtrl->dataSqno = GET_CURR_DAT_SQNO(dataSqno);
    pDatCtrl->elemTtlSize = GET_CURR_DAT_ELEM_TTL_SIZE(dataSqno);
    pDatCtrl->elemCnt = GET_CURR_DAT_ELEM_CNT(dataSqno);
    
    pDatCtrl->prevDataSqno = GET_CURR_DAT_PRE_SQNO(dataSqno);
    pDatCtrl->nextDataSqno = GET_CURR_DAT_NXT_SQNO(dataSqno);
    pDatCtrl->currMsgSqno = GET_CURR_MSG_SQNO(dataSqno);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Start a new memory txn
 * Parameters:
 *      set             IN     set Id
 *      pTxnId          OUT     new txn id
 *      pTimestamp      OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnStart(int32 set, int64* pTxnId, int64 * pTimestamp)
{
    BEGIN_FUNCTION( "MemTxnStart" );
    pMemTxnEntryT pTxnEntry = NULL;
    
    CHK_MEM_TXN_INIT();
    
    if ( NULL == pTxnId || NULL == pTimestamp )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    
    gSetId = set;
  
    gMemTxnAcs[gSetId].pTxnCtrl->currTxnId = gMemTxnAcs[gSetId].pTxnCtrl->commitTxnId + 1;
    
    CHK_TXN_ID(gMemTxnAcs[gSetId].pTxnCtrl->currTxnId);
    
    * pTxnId = gMemTxnAcs[gSetId].pTxnCtrl->currTxnId;
    
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(gMemTxnAcs[gSetId].pTxnCtrl->currTxnId);

    pTxnEntry->txnId = gMemTxnAcs[gSetId].pTxnCtrl->currTxnId;
    pTxnEntry->txnSts = TXN_STS_OPEN;
    pTxnEntry->dataCnt = 0;   
    
    pTxnEntry->frstDataSqno = NO_DATA_SQNO;
    pTxnEntry->lstDataSqno = NO_DATA_SQNO;
    
    pTxnEntry->dataSize = GET_MAX_DATA_SIZE();
    
    if (!gbRplyMode)
    {
        GetSysTimestamp(pTimestamp);
    }

    pTxnEntry->timestamp = *pTimestamp;
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Get data root address of memory txn
 * Parameters:
 *      set          IN     set Id
 *      pRtDataCtrl  OUT    root data ctrl  
 *      frstDataSqno OUT    sqno of first data  
 *      NO_ERR:      Successful
 ******************************************************************************/
ResCodeT MemTxnGetDataRootAddr(int32 set, pRtDatCtrlT pRtDataCtrl, int32 frstDataSqno)
{
    BEGIN_FUNCTION( "MemTxnGetDataRootAddr" );
    pMemTxnEntryT pTxnEntry = NULL;
    ResCodeT rc = NO_ERR;
    int32 dataCnt = 0;
    int32 currDatCnt = 0;
    
    CHK_MEM_TXN_INIT();
    
    gSetId = set;


    pRtDataCtrl->pDataSqno = GET_CURR_DAT_SQNO_ADDR(frstDataSqno);
    pRtDataCtrl->pElemTtlSize = GET_CURR_DAT_ELEM_TTL_SIZE_ADDR(frstDataSqno);
    pRtDataCtrl->pElemCnt = GET_CURR_DAT_ELEM_CNT_ADDR(frstDataSqno);
    pRtDataCtrl->prevDataSqno = GET_CURR_DAT_PRE_SQNO_ADDR(frstDataSqno);
    pRtDataCtrl->nextDataSqno = GET_CURR_DAT_NXT_SQNO_ADDR(frstDataSqno);
    pRtDataCtrl->currMsgSqno = GET_CURR_MSG_SQNO_ADDR(frstDataSqno);
    
    pRtDataCtrl->pRtElemAddr = (void *) GET_CURR_DAT_RT_ELEM_ADDR(frstDataSqno);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Commit a memory txn
 * Parameters:
 *      set         IN      setId
 *      N/A         OUT     
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MemTxnCommit(int32 set)
{
    BEGIN_FUNCTION( "MemTxnCommit" );
    pMemTxnEntryT pTxnEntry = NULL;
    ResCodeT rc = NO_ERR;
    int32 dataCnt = 0;
    int32 currDatCnt = 0;
    
    CHK_MEM_TXN_INIT();
    
    gSetId = set;
   
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(gMemTxnAcs[gSetId].pTxnCtrl->currTxnId);
    if ((pTxnEntry->txnId != gMemTxnAcs[gSetId].pTxnCtrl->currTxnId ) ||
        (pTxnEntry->txnSts != TXN_STS_OPEN))
    {
        RAISE_ERR_PARM( ERR_MEM_TXN_INVLD_TXN_ID, RTN , pTxnEntry->txnId); 
    }
    
    dataCnt = pTxnEntry->dataCnt;
    currDatCnt = pTxnEntry->frstDataSqno;
    
    pTxnEntry->lstDataSqno = pTxnEntry->frstDataSqno + pTxnEntry->dataCnt - 1;
    

    gMemTxnAcs[gSetId].pTxnCtrl->commitTxnId = gMemTxnAcs[gSetId].pTxnCtrl->currTxnId;
    pTxnEntry->txnSts = TXN_STS_COMMIT;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get the element address from head
 * Parameters:
 *      pHeadAddr   IN      head address
 *      ppHdrAddr   IN      address of head address
 *      ppData      OUT     data address
 *      pDataSize   OUT     size of data    
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT GetElemAddrFromHead(void * pHeadAddr, pDatElemHdrT * ppHdrAddr, void ** ppData,int32 * pDataSize)
{
    BEGIN_FUNCTION( "GetElemAddrFromHead" );
    
    * ppHdrAddr = (pDatElemHdrT)pHeadAddr;
    
    * ppData = (void *)ADDRESS_ADD_OFFSET(* ppHdrAddr, sizeof(DatElemHdrT));
    
    *pDataSize = GET_ELEM_DATA_SIZE((*ppHdrAddr)->elemSize);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   get the element
 * Parameters:
 *      pTailAddr   IN      the tail address 
 *      ppHdrAddr   OUT     element header address
 *      ppData      OUT     element data address
 *      pDataSize   OUT     element data length    
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
static ResCodeT GetElemAddrFromTail(void * pTailAddr, pDatElemHdrT * ppHdrAddr, void ** ppData,int32 * pDataSize)
{
    BEGIN_FUNCTION( "GetElemAddrFromTail" );
    
    pDatElemHdrT  pTail = NULL;
    
    pTail = (pDatElemHdrT)ADDRESS_MINUS_OFFSET(pTailAddr, sizeof(DatElemHdrT));
    
    * ppHdrAddr = (pDatElemHdrT)ADDRESS_MINUS_OFFSET(pTailAddr, pTail->elemSize);
    
    * ppData = (void *)ADDRESS_ADD_OFFSET(* ppHdrAddr, sizeof(DatElemHdrT));
    
    *pDataSize = GET_ELEM_DATA_SIZE(pTail->elemSize);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Rollback a open txn
 * Parameters:
 *      set         IN      SetId
 *      N/A         OUT     
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to rollback the txn
 ******************************************************************************/
ResCodeT MemTxnRollback(int32 set)
{
    BEGIN_FUNCTION( "MemTxnRollback" );
    pMemTxnEntryT   pTxnEntry = NULL;
    ResCodeT        rc = NO_ERR;
    int32           lstDataSqno = 0;
    int32           dataCnt  = 0;
    int32           elemCnt = 0;
    void *          elemAddr = NULL;
    int64            elemTtlSize = 0;
    pDatElemHdrT    pHdrAddr = NULL;
    void *          pData = NULL;
    int32           elemDataSize = 0;
    int32           rollbackDataSqno = 0;
    pMemTxnCtrlT    pTxnCtrl = NULL;
    
    CHK_MEM_TXN_INIT();
    
    gSetId = set;
    
    pTxnCtrl = (pMemTxnCtrlT)gMemTxnAcs[gSetId].pTxnCtrl;
    
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(pTxnCtrl->currTxnId);
    if ((pTxnEntry->txnId != gMemTxnAcs[gSetId].pTxnCtrl->currTxnId ) || 
        (pTxnEntry->txnSts != TXN_STS_OPEN))
    {
        RAISE_ERR( ERR_MEM_TXN_INVLD_TXN_ID, RTN); 
    }
    
    pTxnEntry->txnSts = TXN_STS_ROLLBACK;
    /* Rollback the data entry one by one */
    dataCnt = pTxnEntry->dataCnt;
    rollbackDataSqno = pTxnEntry->frstDataSqno + pTxnEntry->dataCnt - 1;
    while (dataCnt)
    {
        /* Rollback the element one by one of this data entry */
        elemCnt = GET_CURR_DAT_ELEM_CNT(rollbackDataSqno);
        elemTtlSize = GET_CURR_DAT_ELEM_TTL_SIZE(rollbackDataSqno);
        /* Point the address to the tail of the data area */
        elemAddr = (void *)ADDRESS_ADD_OFFSET(GET_CURR_DAT_RT_ELEM_ADDR(rollbackDataSqno) , elemTtlSize);   
        while (elemCnt)
        {
            GetElemAddrFromTail(elemAddr, &pHdrAddr, &pData,&elemDataSize);

            /* call the register callback function to rollback the data */
            rc = MemTxnElemDataMinus(TRUE, set, (MTElemTypeT)pHdrAddr->elemType, pData, elemDataSize);
            RAISE_ERR(rc, NORTN);
 
            /* reduce the global element cnt */
            pTxnCtrl->elemCnt--;
            
            /* move to the previous element tailer */
            elemAddr = (void *)pHdrAddr;
            elemCnt--;
        }
        
        /* initialize the data entry */
        INIT_DAT_CTRL(rollbackDataSqno);
        
        rollbackDataSqno = GET_CURR_DAT_PRE_SQNO(rollbackDataSqno);
        dataCnt--;
        
        /* reduce the global data cnt */
        pTxnCtrl->currDataCnt--;
    }
    
    pTxnCtrl->currTxnId--;
   
    /* initialize the txn entry */
    memset(pTxnEntry, 0x00, sizeof(MemTxnEntryT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   To reverse a new data entry
 * Parameters:
 *      pTxnCtrl        IN      Overall txn control information
 *      pTxnEntry       IN      current txn entry information
 *      prevDatSqno     IN      previous data sqno
 *      N/A         OUT     
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
static ResCodeT RsrvNewDataEnty(pMemTxnCtrlT pTxnCtrl, pMemTxnEntryT pTxnEntry, int32 prevDatSqno)
{
    BEGIN_FUNCTION( "RsrvNewDataEnty" );
    ResCodeT            rc = NO_ERR;

    /* the first data entry of this txn*/
    pTxnCtrl->currDataCnt++;
    

    
    INIT_DAT_CTRL(pTxnCtrl->currDataCnt);

    SET_CURR_DAT_SQNO(pTxnCtrl->currDataCnt, pTxnCtrl->currDataCnt); 
    SET_CURR_DAT_PRE_SQNO(pTxnCtrl->currDataCnt, prevDatSqno);  
    
    pTxnEntry->frstDataSqno = (0 == pTxnEntry->dataCnt)? pTxnCtrl->currDataCnt : pTxnEntry->frstDataSqno;
    
    /* increase data cnt for current txn*/
    pTxnEntry->dataCnt++;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Close the write data address and header
 * Parameters:
 *      pTxnCtrl    IN      current data sqno
 *      pDatElemHdr IN      element header address
 *      dataLen     IN      date length 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to close the address
 ******************************************************************************/
static ResCodeT CloseToWrtElem(pMemTxnCtrlT pTxnCtrl, pDatElemHdrT pDatElemHdr, int32 dataLen)
{
    BEGIN_FUNCTION( "CloseToWrtElem" );
    ResCodeT            rc = NO_ERR;
    void *              pWrtDatAddr = NULL; 
    pDatElemHdrT        pDatElemTail = NULL;
                                    
    pDatElemHdr->elemSize += dataLen; /* add data size */
    
    pDatElemTail = (pDatElemHdrT)ADDRESS_ADD_OFFSET(pDatElemHdr, sizeof(DatElemHdrT) + dataLen);
    
    pDatElemHdr->elemSize += sizeof(DatElemHdrT); /* add tailer size */
    
    memcpy(pDatElemTail, pDatElemHdr, sizeof(DatElemHdrT) );
    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Prepare the write data address and header
 * Parameters:
 *      pTxnCtrl      IN      current data sqno
 *      elemType      IN      element type or call data type
 *      ppDatElemHdr  OUT     output data elements address    
 *      pWrtAddr      OUT     output address
 *      NO_ERR:       Successful
 *      ERR_<DSCR>: fail to prepare the address
 ******************************************************************************/
static ResCodeT PrepToWrtElem(pMemTxnCtrlT pTxnCtrl, MTElemTypeT elemType, pDatElemHdrT * ppDatElemHdr, void ** ppWrtAddr)
{
    BEGIN_FUNCTION( "PrepToWrtElem" );
    ResCodeT            rc = NO_ERR;
    
    /* move the write address to current avaliable address*/
    * ppDatElemHdr = (pDatElemHdrT)ADDRESS_ADD_OFFSET(GET_CURR_DAT_RT_ELEM_ADDR(pTxnCtrl->currDataCnt), 
                                    GET_CURR_DAT_ELEM_TTL_SIZE(pTxnCtrl->currDataCnt));
    
    (* ppDatElemHdr)->elemSqno =  ++pTxnCtrl->elemCnt;
    (* ppDatElemHdr)->elemType =  elemType;
    (* ppDatElemHdr)->elemSize =  sizeof(DatElemHdrT);
    
    * ppWrtAddr = (void *)ADDRESS_ADD_OFFSET((* ppDatElemHdr), sizeof(DatElemHdrT));
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Add new element data to the memory txn
 * Parameters:
 *      set         IN      setId
 *      elemType    IN      element type or call data type    
 *      pData       IN      data address
 *      dataLen     IN      data lenth
 *      N/A         OUT     
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MemTxnAddElem(int32 set,MTElemTypeT elemType, void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MemTxnAddElem" );
    void *              pWrtDatAddr =  NULL;
    ResCodeT            rc = NO_ERR;
    
    if ( NULL == pData || elemType >= MT_TYPE_MAX )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
    
    rc = MemTxnAddElemPrep(set,elemType, dataLen, &pWrtDatAddr );
    RAISE_ERR(rc,RTN);
                                                                   
    memcpy(pWrtDatAddr, pData,dataLen);                                
    
    rc = MemTxnAddElemClose();
    RAISE_ERR(rc,RTN);
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   mem txn add element prepare
 * Parameters:
 *      elemType    IN      element type or call data type    
 *      dataLen     IN      data lenth
 *      ppData      OUT     writeable address 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to commit the txn
 ******************************************************************************/
ResCodeT MemTxnAddElemPrep(int32 set,MTElemTypeT elemType, int32 dataLen, void ** ppData)
{
    BEGIN_FUNCTION( "MemTxnAddElemPrep" );
    ResCodeT            rc = NO_ERR;
    pMemTxnCtrlT        pTxnCtrl = NULL;
    pMemTxnEntryT       pTxnEntry = NULL;
    int32               lastDatSqno = 0;
    void *              pWrtDatAddr =  NULL;
    pDatElemHdrT        pDatElemHdr = NULL;

    gSetId = set;
    /* call the register callback function to update the application memory */

    pTxnCtrl = gMemTxnAcs[gSetId].pTxnCtrl;
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(pTxnCtrl->currTxnId);

    if ( elemType >= MT_TYPE_MAX || pTxnEntry->dataSize < dataLen )
    {
        LOG_DEBUG("%d exceeds the max data size %ld", dataLen, pTxnEntry->dataSize);
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }

    if (0 == pTxnEntry->dataCnt)
    {
        /* this is the first data entry of this txn, so everything is new or 0*/
        RsrvNewDataEnty(pTxnCtrl, pTxnEntry, NO_DATA_SQNO);

    }
    else
    {
        /* use current node */
    }
    
    TRACE("Txn %ld, currNod is %ld, ttlNod %ld, frstNode %ld " $$ pTxnCtrl->currTxnId 
                                $$ pTxnCtrl->currDataCnt
                                $$ pTxnEntry->dataCnt
                                $$ pTxnEntry->frstDataSqno);

    /* Check the remain length*/
    if ((GET_CURR_DAT_ELEM_TTL_SIZE(pTxnCtrl->currDataCnt) + GET_ELEM_SIZE(dataLen)) > GET_MAX_DATA_SIZE())
    {
        /* Need a new data area*/
        lastDatSqno = pTxnCtrl->currDataCnt; /* remember this for future update */
        
        RsrvNewDataEnty(pTxnCtrl, pTxnEntry, pTxnCtrl->currDataCnt);
        /* current became new, use last sqno to update */
        SET_CURR_DAT_NXT_SQNO(lastDatSqno, pTxnCtrl->currDataCnt);  
    }
    else
    {
        /* Use exist data area */
    }
   
    
    /* move the write address to current avaliable address and prepare the header */
    PrepToWrtElem(pTxnCtrl, elemType, &pDatElemHdr, &pWrtDatAddr);
    
    * ppData = pWrtDatAddr;
    
    gWrtElemCtx.pTxnCtrl= pTxnCtrl;
    gWrtElemCtx.pDatElemHdr = pDatElemHdr;
    gWrtElemCtx.dataLen = dataLen;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   close the  memory txn add elements
 * Parameters:
 *      N/A         IN 
 *      N/A         OUT     
 ******************************************************************************/
ResCodeT MemTxnAddElemClose()
{
    BEGIN_FUNCTION( "MemTxnAddElemClose" );
    
    CloseToWrtElem(gWrtElemCtx.pTxnCtrl, gWrtElemCtx.pDatElemHdr,gWrtElemCtx.dataLen);
    
    /* increase the element size and element count */
    ADD_CURR_DAT_ELEM_TTL_SIZE(gWrtElemCtx.pTxnCtrl->currDataCnt, GET_ELEM_SIZE(gWrtElemCtx.dataLen));
    ADD_CURR_DAT_ELEM_CNT(gWrtElemCtx.pTxnCtrl->currDataCnt, 1);
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   memory txn init database
 * Parameters:
 *      pDbHndl     OUT     database handle
 *      N/A         OUT     
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT MemTxnInitDb(int32 * pDbHndl)
{
    BEGIN_FUNCTION( "MemTxnInitDb" );
    ResCodeT rc = NO_ERR;
    
    CfgValueT cfgValue = {0};
    
    /* Get config value for the system  */
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
        

    
    rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, pDbHndl);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Load Element Data
 * Parameters:
 *      set             IN      setId
 *      pElemHdr        IN      element header
 *      pElemDat        IN      element date
 *      pElemDat        IN      element size
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT LoadElemDat(int32 set, pDatElemHdrT pElemHdr, void * pElemDat, int32 elemSize)
{
    BEGIN_FUNCTION( "LoadElemDat" );
    ResCodeT rc = NO_ERR;
    
    if (MT_TYPE_MAX <= pElemHdr->elemType)
    {
        
        RAISE_ERR(ERR_MEM_TXN_INVLD_ELEM_TYPE, RTN);
    }
    
    rc = MemTxnElemDataAdd(TRUE, set, (MTElemTypeT)pElemHdr->elemType, pElemDat, elemSize);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Load data entry
 * Parameters:
 *      set             IN     set id
 *      pMemTxnEntry    IN     memory txn entry
 *      pDataCtrl       IN     data ctrl
 *      pElemBuff       IN     element buffer
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT LoadDataEntry(int32 set, pMemTxnEntryT pMemTxnEntry, pDatCtrlT pDataCtrl, char * pElemBuff )
{
    BEGIN_FUNCTION( "LoadDataEntry" );
    ResCodeT        rc = NO_ERR;
    pDatElemHdrT    pElemHdr = NULL;
    void *          pElemDat = NULL;
    int32           elemSize = 0;
    void *          pCurrElemAddr = NULL;
    int32           i = 0;
    
    pCurrElemAddr = pElemBuff;
    
    for (i=0; i< pDataCtrl->elemCnt; i++)
    {
        /* Get each element and process it */
        GetElemAddrFromHead(pCurrElemAddr, &pElemHdr, &pElemDat, &elemSize); 
        
        rc = LoadElemDat(set, pElemHdr, pElemDat, elemSize);
        RAISE_ERR(rc, RTN);
        
        pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET(pCurrElemAddr, pElemHdr->elemSize);  
         
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Load Txn Entry
 * Parameters:
 *      set             IN      set id
 *      pMemTxnEntry    IN      memory txn entry
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT LoadTxnEntry(int32 set, pMemTxnEntryT pMemTxnEntry)
{
    BEGIN_FUNCTION( "LoadDataEntry" );
    ResCodeT        rc = NO_ERR;
    int64               txnId = 0;
    int32               frstDataSqno = 0;
    DatCtrlT            dataCtrl = {0};
    char                elemBuff[MAX_MSG_LEN];
    
    BOOL frstFlag = TRUE;
    
    rc = MemTxnStart(set, &txnId, &pMemTxnEntry->timestamp);
    RAISE_ERR(rc, RTN);
    
    if (txnId != pMemTxnEntry->txnId)
    {
        /* do some check about txnid, they should be same, we should never come here... */
        RAISE_ERR(ERR_MEM_TXN_INVLD_TXN_ID, RTN);
    }
    
    frstDataSqno = pMemTxnEntry->frstDataSqno;
    
    /* Read each data record by sqno, till the last one */
    for (frstDataSqno; frstDataSqno <= pMemTxnEntry->lstDataSqno; frstDataSqno++)
    {
        //rc = SelectMemTxnDatTblByKey(gDbHndl, frstDataSqno);
        //RAISE_ERR(rc, RTN);
        
        rc = FetchNextMemTxnDatTblByKey( &frstFlag, gDbHndl, frstDataSqno, 
                                        &dataCtrl, elemBuff, pMemTxnEntry->dataSize);
        RAISE_ERR(rc, RTN);
        
        LOG_DEBUG("Get Txn Id %d for Data %d" , pMemTxnEntry->txnId, frstDataSqno);
        
        rc = LoadDataEntry(set, pMemTxnEntry, &dataCtrl, elemBuff);
        RAISE_ERR(rc, RTN);
    }
    /* We need to commit the previous one */
    rc = MemTxnCommit(set);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Load Memory Txn Data from txnId
 * Parameters:
 *      set             IN      set value
 *      fromTxnId       IN      set value
 *      pOutTxnId       OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnLoadDatFromTxnId(int32 set, int64 fromTxnId, int64 * pOutTxnId)
{
    BEGIN_FUNCTION( "MemTxnLoadDat" );
    ResCodeT            rc = NO_ERR;
    MemTxnEntryT        memTxnEntry;

    BOOL frstFlag = TRUE;

    CHK_MEM_TXN_INIT();
    
    if (gDbHndl == -1)
    {
        rc = MemTxnInitDb(&gDbHndl);
        RAISE_ERR(rc, RTN);
    }
    
    gbRplyMode = TRUE;
    
    //rc = SelectMemTxnTbl(gDbHndl,fromTxnId);
    //RAISE_ERR(rc, RTN);
    
    
        
    while (TRUE)
    {
        /* Get Txn from TXN table one by one */
        rc = FetchNextMemTxnTbl(&frstFlag,gDbHndl, 0, &memTxnEntry);
        if (ERR_DB_COMMON_FETCH_END == rc)
        {
            LOG_DEBUG("No more Txn in Db.");
            THROW_RESCODE(ERR_MEM_TXN_ITER_DATA_END)
        }
        RAISE_ERR(rc, RTN);
 
        rc = LoadTxnEntry(set, &memTxnEntry);
        RAISE_ERR(rc, RTN);
        
        * pOutTxnId = memTxnEntry.txnId;
    }

    EXIT_BLOCK();
    
    gbRplyMode = FALSE;
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Load Memory Txn Data from txnId
 * Parameters:
 *      set             IN      set value
 *      fromTxnId       IN      set value
 *      pOutTxnId       OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnRegisterElemType(MTElemTypeT * pElemType)
{
    BEGIN_FUNCTION("MemTxnRegisterElemType");
    MTElemTypeT *        pElemTypePtr = pElemType;
    ASSERT( TRUE );

    if ( !pElemType || MT_TYPE_ALL == *pElemTypePtr )
    {
        gMemTxnRdMode.allElemType = TRUE;
    }
    else
    {
        memset( gMemTxnRdMode.elemUserType, 0x00,
                        sizeof(vectorT) * GET_BIT_VECT_LEN(MT_TYPE_MAX + 1) );

        for (;
            MT_TYPE_END != *pElemTypePtr && *pElemTypePtr <= MT_TYPE_MAX;
            pElemTypePtr++)
        {
            BitSet(gMemTxnRdMode.elemUserType, *pElemTypePtr);
        }
        gMemTxnRdMode.allElemType = FALSE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MemTxnRegisterElemType */


/******************************************************************************
 * Description:   Load Memory Txn Data from txnId
 * Parameters:
 *      set             IN      set value
 *      fromTxnId       IN      set value
 *      pOutTxnId       OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnRegisterUserMode(pMemTxnUserModeT pUserMode)
{
    BEGIN_FUNCTION("MemTxnRegisterUserMode");
    ResCodeT                rc = NO_ERR;
    ASSERT( pUserMode );


    if ( !pUserMode->callBack.PrcsData )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }

    memcpy(&gMemTxnRdMode.memTxnUser, pUserMode, sizeof(MemTxnUserModeT));

    rc = MemTxnRegisterElemType(pUserMode->pElemTypeArry);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of AppIraWPRegisterUserMode */


/******************************************************************************
 * Description:   Load Memory Txn Data from txnId
 * Parameters:
 *      set             IN      set value
 *      fromTxnId       IN      set value
 *      pOutTxnId       OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnRetrieveData(int32 setId,
                                int64 lowTxnId,
                                int64 highTxnId,
                                int64 * pMaxTxnId)
{
    BEGIN_FUNCTION("MemTxnRetrieveData");
    ResCodeT                rc = NO_ERR;
    int32                   currTxnId = 0, lstTxnId = 0;
    
    MTElemTypeT             elemTypeOut;
    void *                  pDataOut = NULL;
    int32                   dataLenOut = 0;       
    ASSERT( pMaxIra );


    if ( !gMemTxnRdMode.memTxnUser.callBack.PrcsData )
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS, RTN);
    }
    
    
    
    rc = MemTxnIterElem(setId, lowTxnId, highTxnId, &elemTypeOut, &pDataOut, &dataLenOut);
    RAISE_ERR(rc,RTN); 
    
    currTxnId = lstTxnId = lowTxnId;
    
    do
    {
        
        rc = gMemTxnRdMode.memTxnUser.callBack.PrcsData(pDataOut,
                                dataLenOut,
                                elemTypeOut,
                                gMemTxnRdMode.memTxnUser.callBack.pCtx4PrcsData);
        RAISE_ERR(rc, RTN);
    
        rc = MemTxnIterElemNext(setId, &currTxnId, &elemTypeOut, &pDataOut, &dataLenOut);
        if (rc == ERR_MEM_TXN_ITER_DATA_END)
        {
            break;
        }
        else
        {  
            RAISE_ERR(rc,RTN);
        }
        
        if ( currTxnId != lstTxnId )
        {
            if ( gMemTxnRdMode.memTxnUser.callBack.PrcsDataDone )
            {
                rc = gMemTxnRdMode.memTxnUser.callBack.PrcsDataDone(
                                setId,
                                lstTxnId,
                                gMemTxnRdMode.memTxnUser.callBack.pCtx4PrcsDataDone);
                RAISE_ERR(rc, RTN);
            }
            
            lstTxnId = currTxnId;
        }
        
    } while (TRUE);
    
    if ( gMemTxnRdMode.memTxnUser.callBack.PrcsDataDone )
    {
        rc = gMemTxnRdMode.memTxnUser.callBack.PrcsDataDone(
                        setId,
                        currTxnId,
                        gMemTxnRdMode.memTxnUser.callBack.pCtx4PrcsDataDone);
        RAISE_ERR(rc, RTN);
    }

    

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of AppIraWPRetrieveData */




/******************************************************************************
 * Description:   Load data entry
 * Parameters:
 *      set             IN     set id
 *      pMemTxnEntry    IN     memory txn entry
 *      pDataCtrl       IN     data ctrl
 *      pElemBuff       IN     element buffer
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT LoadDataEntryByKey(int32 set, pMemTxnEntryT pMemTxnEntry, pDatCtrlT pDataCtrl, char * pElemBuff, MemTxnCallBackT * pCallBack)
{
    BEGIN_FUNCTION( "LoadDataEntryByKey" );
    ResCodeT        rc = NO_ERR;
    pDatElemHdrT    pElemHdr = NULL;
    void *          pElemDat = NULL;
    int32           elemSize = 0;
    void *          pCurrElemAddr = NULL;
    int32           i = 0;
    
    pCurrElemAddr = pElemBuff;
    
    for (i=0; i< pDataCtrl->elemCnt; i++)
    {
        /* Get each element and process it */
        GetElemAddrFromHead(pCurrElemAddr, &pElemHdr, &pElemDat, &elemSize); 
        
        rc = LoadElemDat(set, pElemHdr, pElemDat, elemSize);
        RAISE_ERR(rc, RTN);
        
        if (pCallBack->PrcsData)
        {
            rc = pCallBack->PrcsData(pElemDat,elemSize,(MTElemTypeT)pElemHdr->elemType,pCallBack->pCtx4PrcsData);
            RAISE_ERR(rc, NORTN);
        }
        
        gMemTxnAcs[gSetId].pTxnCtrl->currMsgSqno = pDataCtrl->currMsgSqno;
        
        pCurrElemAddr = (void *)ADDRESS_ADD_OFFSET(pCurrElemAddr, pElemHdr->elemSize);  
         
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Load Txn Entry
 * Parameters:
 *      set             IN      set id
 *      pMemTxnEntry    IN      memory txn entry
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT LoadTxnEntryByKey(int32 set, pMemTxnEntryT pMemTxnEntry, MemTxnCallBackT * pCallBack)
{
    BEGIN_FUNCTION( "LoadTxnEntryByKey" );
    ResCodeT        rc = NO_ERR;
    int64               txnId = 0;
    int32               frstDataSqno = 0;
    DatCtrlT            dataCtrl = {0};
    char                elemBuff[MAX_MSG_LEN];
    
    BOOL frstFlag = TRUE;
    
    if (txnId != pMemTxnEntry->txnId)
    {
        /* do some check about txnid, they should be same, we should never come here... */
        RAISE_ERR(ERR_MEM_TXN_INVLD_TXN_ID, RTN);
    }
    
    frstDataSqno = pMemTxnEntry->frstDataSqno;
    
    /* Read each data record by sqno, till the last one */
    for (frstDataSqno; frstDataSqno <= pMemTxnEntry->lstDataSqno; frstDataSqno++)
    {   
        rc = FetchNextMemTxnDatTblByKey( &frstFlag, gDbHndl, frstDataSqno, 
                                        &dataCtrl, elemBuff, pMemTxnEntry->dataSize);
        RAISE_ERR(rc, RTN);
        
        LOG_DEBUG("Get Txn Id %d for Data %d" , pMemTxnEntry->txnId, frstDataSqno);
        
        rc = LoadDataEntryByKey(set, pMemTxnEntry, &dataCtrl, elemBuff, pCallBack);
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Load Txn Entry
 * Parameters:
 *      set             IN      set id
 *      pMemTxnEntry    IN      memory txn entry
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
static ResCodeT FmtDatByDataRcrd( void * pData, int32 * pDataLen, DatCtrlT* pDatCtrl,void * elemBuff, void ** ppOutDataAddr)
{
    BEGIN_FUNCTION( "FmtDatByDataRcrd" );
    ResCodeT        rc = NO_ERR;
    void *          pCurrDataAddr = NULL;
    pMemTxnEntryT   pTxnEntry = NULL;
    DatCtrlT*       pCurrDatCtrl = NULL;
    
    pCurrDataAddr = pData;
    pTxnEntry = (pMemTxnEntryT)pData;
    
    if (* pDataLen == 0 )
    {
        pTxnEntry->dataCnt = 0;
        (* pDataLen) += sizeof(MemTxnEntryT);
        
         pCurrDataAddr = (void *)ADDRESS_ADD_OFFSET(pData , (* pDataLen));  
    }
    
    /* copy the data ctrl area */
    pCurrDatCtrl = (pDatCtrlT)pCurrDataAddr;
    
    memcpy(pCurrDatCtrl, pDatCtrl, sizeof(DatCtrlT));
    (* pDataLen) += sizeof(DatCtrlT);
    
    pCurrDataAddr = (void *)ADDRESS_ADD_OFFSET(pData , (* pDataLen));  
    
    /* copy the element ctrl area */
    memcpy(pCurrDataAddr, elemBuff, pDatCtrl->elemTtlSize);
    (* pDataLen) += pDatCtrl->elemTtlSize;

    pCurrDataAddr = (void *)ADDRESS_ADD_OFFSET(pData , (* pDataLen));
    
    * ppOutDataAddr = pCurrDataAddr;
    
    pTxnEntry->dataCnt ++;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Load Memory Txn Data from txnId
 * Parameters:
 *      set             IN      set value
 *      fromTxnId       IN      set value
 *      pOutTxnId       OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnGetDatByMsgSqnoInit(int32 set)
{
    BEGIN_FUNCTION( "MemTxnGetDatByMsgSqnoInit" );
    ResCodeT            rc = NO_ERR;
    
    if (gDbHndl == -1)
    {
        rc = DbCmmnInit();        
        RAISE_ERR(rc, RTN);
        
        rc = MemTxnInitDb(&gDbHndl);
        RAISE_ERR(rc, RTN);
        
        rc = InitMemTxnTblSqlQuery(gDbHndl, set);
        RAISE_ERR(rc, RTN);
        
        rc = InitMemTxnDatTblSqlQuery(gDbHndl, set);
        RAISE_ERR(rc, RTN);
    }
  
    EXIT_BLOCK(); 
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   Load Memory Txn Data from txnId
 * Parameters:
 *      set             IN      set value
 *      fromTxnId       IN      set value
 *      pOutTxnId       OUT     timestamp
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to init the share memory.
 ******************************************************************************/
ResCodeT MemTxnGetDatByMsgSqno(int32 set, int32 msgSqno, void * pData, int32 * pDataLen, int32 cfgDataSize)
{
    BEGIN_FUNCTION( "MemTxnGetDatByMsgSqno" );
    ResCodeT            rc = NO_ERR;
    MemTxnEntryT        memTxnEntry;
    DatCtrlT            dataOut;
    void                * pCurrData = NULL;
    char                elemBuff[MAX_MSG_LEN];
    BOOL                bFrstFlg = TRUE;
    

    pCurrData = pData;
    * pDataLen = 0;
    
    rc =  FetchNextMemTxnDatTblByMsgSqno( &bFrstFlg, gDbHndl, msgSqno,&dataOut, elemBuff, cfgDataSize); 
    if (rc == ERR_DB_COMMON_FETCH_END)
    {
        THROW_RESCODE( NO_ERR );
    }
	RAISE_ERR(rc, RTN);


    do
    {
        rc = FmtDatByDataRcrd( pCurrData, pDataLen, &dataOut,elemBuff,&pCurrData);
        RAISE_ERR(rc, RTN);
        
        /* Get Txn from TXN table one by one */
        rc = FetchNextMemTxnDatTblByMsgSqno( &bFrstFlg, gDbHndl, msgSqno,&dataOut, elemBuff, cfgDataSize); 
    } while (OK(rc));
    
    if (rc == ERR_DB_COMMON_FETCH_END)
    {
        THROW_RESCODE( NO_ERR );
    }
	RAISE_ERR(rc, RTN);

    
    EXIT_BLOCK(); 
    RETURN_RESCODE;
}