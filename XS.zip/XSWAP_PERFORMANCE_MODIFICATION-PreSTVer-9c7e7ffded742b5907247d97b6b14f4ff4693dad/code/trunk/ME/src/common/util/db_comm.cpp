﻿/***
Created on June 28, 2017
@author: Dongwei Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header files */
#include "db_comm.h"
#include "err_lib.h"
#include "ocilib.h"
#include "common_macro.h"
#include "bit_lib.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_CONN_ID_CNT         100
#define MAX_STMNT_ID_CNT         1000
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static BOOL             gInitFlg = FALSE;
static int32            gConnIdCnt = 0;
static OCI_Connection * gpCnnArry[MAX_CONN_ID_CNT] = {0};

static vectorT          gStmntVct[GET_BIT_VECT_LEN(MAX_STMNT_ID_CNT)] = {0};
static OCI_Statement *  gpStmntArry[MAX_STMNT_ID_CNT] = {0};

static OCI_Resultset *  gpRsltSet[MAX_STMNT_ID_CNT] = {0};
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT DbCmmnInit()
{
    ResCodeT rc = NO_ERR;
    int32 iErrCd = 0;

    BEGIN_FUNCTION( "DbCmmnInit" );
    if (gInitFlg) 
    {
        THROW_RESCODE(NO_ERR);
    }
    
    if (!OCI_Initialize(NULL, NULL, OCI_ENV_DEFAULT | OCI_ENV_CONTEXT | OCI_ENV_THREADED)) 
    {
        LOG_ERROR(ERR_DB_OCI_INIT_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        OCI_Cleanup();
        RAISE_ERR( ERR_DB_OCI_INIT_ERR, RTN );
    }
    
    gInitFlg = TRUE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnCleanup()
{
    BEGIN_FUNCTION( "DbCmmnCleanup" );
    ResCodeT rc = NO_ERR;

    OCI_Cleanup();

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnConnect(char* pAddr, char* pUser, char* pPasswd, int32* pConnId)
{
    ResCodeT rc = NO_ERR;
    int32 iErrCd = 0;

    BEGIN_FUNCTION( "DbCmmnConnect" );
    
    if ( ++gConnIdCnt >= MAX_CONN_ID_CNT)
    {
        gConnIdCnt--;
        RAISE_ERR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    
    // Create Connection.
    gpCnnArry[gConnIdCnt] = OCI_ConnectionCreate(pAddr, pUser, pPasswd, OCI_SESSION_DEFAULT);
    if (!gpCnnArry[gConnIdCnt]) 
    {
        gConnIdCnt--;
        LOG_ERROR(ERR_DB_OCI_EXEC_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    
    * pConnId = gConnIdCnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnDisconnect(int32 connId)
{
    ResCodeT rc = NO_ERR;

    BEGIN_FUNCTION( "DbCmmnDisconnect" );
    
    if ( connId >= MAX_CONN_ID_CNT || connId > gConnIdCnt)
    {
        RAISE_ERR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    
    if (OCI_IsConnected(gpCnnArry[connId])) 
    {
        OCI_ConnectionFree(gpCnnArry[connId]);
        gpCnnArry[connId] = NULL;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnCommit(int32 connId)
{
    BEGIN_FUNCTION( "DbCmmnCommit" );
    ResCodeT rc = NO_ERR;
    
    if ( connId >= MAX_CONN_ID_CNT || connId > gConnIdCnt)
    {
        RAISE_ERR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    
    if (gpCnnArry[connId]) {
        if (!OCI_Commit(gpCnnArry[connId])) 
        {
            LOG_ERROR(ERR_DB_OCI_COMMIT_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d), connId %d", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()), connId);
            RAISE_ERR(ERR_DB_OCI_COMMIT_ERR, RTN);
        }
    }
    else 
    {
        RAISE_ERR(ERR_DB_OCI_CONN_NOT_USE_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnRollback(int32 connId)
{
    BEGIN_FUNCTION( "DbCmmnRollback" );
    ResCodeT rc = NO_ERR;

    
    if ( connId >= MAX_CONN_ID_CNT || connId > gConnIdCnt)
    {
        RAISE_ERR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    
    if (gpCnnArry[connId]) {
        if (!OCI_Rollback(gpCnnArry[connId])) 
        {
            LOG_ERROR(ERR_DB_OCI_COMMIT_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d), connId %d", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()), connId);
            RAISE_ERR(ERR_DB_OCI_COMMIT_ERR, RTN);
        }
    }
    else 
    {
        RAISE_ERR(ERR_DB_OCI_CONN_NOT_USE_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbCmmnPrprSql(int32 connId,char* pSql, int32 * pStmntId)
{
    
    BEGIN_FUNCTION( "DbCmmnPrprSql" );
    ResCodeT rc = NO_ERR;
    int32   tmpStmntId = 0; 
    
    if ( connId >= MAX_CONN_ID_CNT || connId > gConnIdCnt)
    {
        RAISE_ERR( ERR_DB_OCI_CONN_ERR, RTN );
    }

    BitFindFC(gStmntVct, 0, MAX_STMNT_ID_CNT, &tmpStmntId);
    if (tmpStmntId == -1)
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    if ( tmpStmntId >= MAX_STMNT_ID_CNT)
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }

//    LOG_DEBUG("SQL %s",pSql);
    // Create Connection.
    gpStmntArry[tmpStmntId] = OCI_StatementCreate(gpCnnArry[connId]);
    if (!gpStmntArry[tmpStmntId]) 
    {
        LOG_ERROR(ERR_DB_OCI_CREATE_STATE_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    // Prepare Start.
    if (!OCI_Prepare(gpStmntArry[tmpStmntId], pSql)) {
        LOG_ERROR(ERR_DB_OCI_PREPARE_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        if (gpStmntArry[tmpStmntId]) {
            OCI_StatementFree(gpStmntArry[tmpStmntId]);
            gpStmntArry[tmpStmntId] = NULL;
        }
        RAISE_ERR(ERR_DB_OCI_PREPARE_ERR, RTN);
    }
    
    BitSet(gStmntVct, tmpStmntId);
    
    * pStmntId = tmpStmntId;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



void DbCmmnSetColBit(vectorT * pColVct, int32 colIdx )
{
    BitSet(pColVct, colIdx);
}



void DbCmmnSetAllColBit(vectorT * pColVct, int32 colCnt)
{
    int i = 0;
    for (i=0; i<colCnt; i++)
    {
        BitSet(pColVct, i);
    }
}

ResCodeT DbCmmnFreeStmnt(int32 stmntId)
{
    
    BEGIN_FUNCTION( "DbCmmnFreeStmnt" );
    ResCodeT rc = NO_ERR;
    int32   tmpStmntId = 0; 
    
    if ( stmntId >= MAX_STMNT_ID_CNT || !BitCheck (gStmntVct, stmntId))
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    
    if (!gpStmntArry[stmntId]) {
        LOG_INFO("the statement is null.(StmtID:%d)", stmntId);
        THROW_RESCODE(NO_ERR);
    }

    // free the current statement.
    if (gpStmntArry[stmntId]){
        OCI_StatementFree(gpStmntArry[stmntId]);
        gpStmntArry[stmntId] = NULL;
    }
    
    BitReset(gStmntVct, stmntId);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbCmmnExcSqlNoRslt(int32 connId, int32 stmntId)
{
    BEGIN_FUNCTION( "DbCmmnExcSqlNoRslt" );
    
    ResCodeT rc = NO_ERR;
    
    if ( connId > gConnIdCnt || !BitCheck (gStmntVct, stmntId))
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    
    if (!gpStmntArry[stmntId]) {
        LOG_ERROR(ERR_DB_OCI_STATE_NOT_USE_ERR, "the statement is null.(ConnID:%d, StmtID:%d)", connId, stmntId);
        RAISE_ERR(ERR_DB_OCI_STATE_NOT_USE_ERR, RTN);
    }

    // Execute the statement.
    if (!OCI_Execute(gpStmntArry[stmntId])) 
    {
        LOG_ERROR(ERR_DB_OCI_EXEC_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_EXEC_ERR, RTN);
    }
    
    
    rc = DbCmmnFreeStmnt(stmntId);
    RAISE_ERR( rc, RTN );
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



static ResCodeT DbCmmnBindCol(int32 connId, int32 stmntId, pDbColInfoT pDbColInfo, void * pColValAddr, void * pColPtrAddr)
{
    BEGIN_FUNCTION( "DbCmmnBindCol" );
    int      bindRslt = 0;
    ResCodeT rc = NO_ERR;
    
    switch (pDbColInfo->colType) {
        case DB_COL_STRING:
            bindRslt = OCI_BindString(gpStmntArry[stmntId], pDbColInfo->colName, (otext*) pColValAddr, pDbColInfo->valSize);
            break;
            
        case DB_COL_INT32:
        case DB_COL_INT16:
            bindRslt = OCI_BindInt(gpStmntArry[stmntId], pDbColInfo->colName, (int *)pColValAddr);
            break;
            
        case DB_COL_INT64:
            bindRslt = OCI_BindBigInt(gpStmntArry[stmntId], pDbColInfo->colName, (long long int *)pColValAddr);
            break;
            
        case DB_COL_DOUBLE:
            bindRslt = OCI_BindDouble(gpStmntArry[stmntId], pDbColInfo->colName, (double*)pColValAddr);
            break;
            
        case DB_COL_FLOAT:
            bindRslt = OCI_BindFloat(gpStmntArry[stmntId], pDbColInfo->colName, (float*)pColValAddr);
            break;
            
        case DB_COL_DATE:
            bindRslt = OCI_BindDate(gpStmntArry[stmntId], pDbColInfo->colName, *(OCI_Date**) pColPtrAddr);
            break;
            
        case DB_COL_TIMESTAMP:
            bindRslt = OCI_BindTimestamp(gpStmntArry[stmntId], pDbColInfo->colName, *(OCI_Timestamp**) pColPtrAddr);
            break;
            
        case DB_COL_BLOB:
        case DB_COL_CLOB:
            bindRslt = OCI_BindLob(gpStmntArry[stmntId], pDbColInfo->colName, *(OCI_Lob**)pColPtrAddr);
            break;
            
        default:
            LOG_ERROR(ERR_DB_COMMON_INVLD_DATATYPE_ERR,"bound data type is undefined %d.", pDbColInfo->colType);
            RAISE_ERR(ERR_DB_COMMON_INVLD_DATATYPE_ERR, RTN);
    }
    
    if (!bindRslt) 
    {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d) for col %s", OCI_ErrorGetString(OCI_GetLastError()), 
                    OCI_ErrorGetOCICode(OCI_GetLastError()), (char *)pColValAddr);
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


static ResCodeT DbCmmnBindArryCol(int32 connId, int32 stmntId, int32 rowCnt, pDbColInfoT pDbColInfo, void * pColValAddr, void * pColPtrAddr)
{
    BEGIN_FUNCTION( "DbCmmnBindArryCol" );
    int      bindRslt = 0;
    ResCodeT rc = NO_ERR;
    
    if (!OCI_BindArraySetSize(gpStmntArry[stmntId], rowCnt)) 
    {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }
    
    switch (pDbColInfo->colType) {
        case DB_COL_STRING:
            bindRslt = OCI_BindArrayOfStrings(gpStmntArry[stmntId], pDbColInfo->colName, (otext*)pDbColInfo->colName, pDbColInfo->valSize, 0);
            break;
            
        case DB_COL_INT32:
        case DB_COL_INT16:
            bindRslt = OCI_BindArrayOfInts(gpStmntArry[stmntId], pDbColInfo->colName, (int*)pColValAddr, 0);
            break;
            
        case DB_COL_INT64:
            bindRslt = OCI_BindArrayOfBigInts(gpStmntArry[stmntId], pDbColInfo->colName,  (long long int*)pColValAddr, 0);
            break;
            
        case DB_COL_DOUBLE:
            bindRslt = OCI_BindArrayOfDoubles(gpStmntArry[stmntId], pDbColInfo->colName, (double *)pColValAddr, 0);
            break;
            
        case DB_COL_FLOAT:
            bindRslt = OCI_BindArrayOfFloats(gpStmntArry[stmntId], pDbColInfo->colName, (float *)pColValAddr,0);
            break;
            
        case DB_COL_DATE:
            bindRslt = OCI_BindArrayOfDates(gpStmntArry[stmntId], pDbColInfo->colName, (OCI_Date **)pColPtrAddr,0);
            break;
            
        case DB_COL_TIMESTAMP:
            bindRslt = OCI_BindArrayOfTimestamps(gpStmntArry[stmntId], pDbColInfo->colName, (OCI_Timestamp **)pColPtrAddr,OCI_TIMESTAMP, 0);
            break;
            
        case DB_COL_BLOB:
            bindRslt = OCI_BindArrayOfLobs(gpStmntArry[stmntId], pDbColInfo->colName, (OCI_Lob **)pColPtrAddr,OCI_BLOB,0);
        case DB_COL_CLOB:
            bindRslt = OCI_BindArrayOfLobs(gpStmntArry[stmntId], pDbColInfo->colName, (OCI_Lob **)pColPtrAddr,OCI_CLOB,0);
            break;
            
        default:
            LOG_ERROR(ERR_DB_COMMON_INVLD_DATATYPE_ERR,"bound data type is undefined %d.", pDbColInfo->colType);
            RAISE_ERR(ERR_DB_COMMON_INVLD_DATATYPE_ERR, RTN);
    }
    
    if (!bindRslt) 
    {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d) for col %s", OCI_ErrorGetString(OCI_GetLastError()), 
                    OCI_ErrorGetOCICode(OCI_GetLastError()), pColValAddr);
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbCmmnExcBindAllVal(int32 connId, int32 stmtId, pDbColInfoT pDbColInfo, int32 colCnt, void * pColVal)
{
    BEGIN_FUNCTION( "DbCmmnExcSqlNoRslt" );
    
    ResCodeT    rc = NO_ERR;
    int32       colIdx = 0;
    
    void * pColValAddr = NULL; 
    void * pColPtrAddr = NULL; 
    
    if ( connId > gConnIdCnt || !BitCheck (gStmntVct, stmtId))
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    for (colIdx = 0; colIdx<colCnt; colIdx++)
    {
        pColValAddr = (void *)ADDRESS_ADD_OFFSET(pColVal, pDbColInfo[colIdx].valOffset);
        pColPtrAddr = (void *)ADDRESS_ADD_OFFSET(pColVal, pDbColInfo[colIdx].ptrOffset);    
        rc = DbCmmnBindCol(connId, stmtId, &pDbColInfo[colIdx], pColValAddr, pColPtrAddr);
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbCmmnExcBindVal(int32 connId, int32 stmtId, pDbColInfoT pDbColInfo, int32 colCnt,vectorT * pColFlg, void * pColVal)
{
    BEGIN_FUNCTION( "DbCmmnExcSqlNoRslt" );
    
    ResCodeT    rc = NO_ERR;
    int32       colIdx = -1;
    
    void * pColValAddr = NULL;
    void * pColPtrAddr = NULL;
    
    if ( connId > gConnIdCnt || !BitCheck (gStmntVct, stmtId))
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    
    while (TRUE)
    {
        BitFindFS(pColFlg, colIdx + 1, colCnt, &colIdx);
        if (colIdx == -1)
        {
            break;
        }
        
        pColValAddr = (void *)ADDRESS_ADD_OFFSET(pColVal, pDbColInfo[colIdx].valOffset);
        pColPtrAddr = (void *)ADDRESS_ADD_OFFSET(pColVal, pDbColInfo[colIdx].ptrOffset);

        rc = DbCmmnBindCol(connId, stmtId, &pDbColInfo[colIdx], pColValAddr, pColPtrAddr );
        RAISE_ERR( rc, RTN );
        
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbCmmnFmtDateType( char* pValue, DbDateTypeT ** ppDbDateType)
{
    BEGIN_FUNCTION( "DbCmmnFmtDateType" );
    
    * ppDbDateType = OCI_DateCreate(NULL);
    OCI_DateFromText(* ppDbDateType, pValue, "YYYY-MM-DD HH24:MI:SS");

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnFmtTimestampType( char* pValue, DbTimestampTypeT ** ppDbTimestampType)
{
    BEGIN_FUNCTION( "DbCmmnFmtTimestampType" );
    
    * ppDbTimestampType = OCI_TimestampCreate(NULL, OCI_TIMESTAMP);
    //OCI_TimestampFromText(* ppDbTimestampTypeType, pValue, "YYYY-MM-DD HH24:MI:SS");
    OCI_TimestampFromText(* ppDbTimestampType, pValue, "YYYY-MM-DD HH24:MI:SS:FF\n");

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnFmtLobType( int32 connId, char* pValue, DbLobTypeT ** ppDbLobType,int32 lobSize, int32 lobType)
{
    BEGIN_FUNCTION( "DbCmmnFmtLobType" );
    
    * ppDbLobType = OCI_LobCreate(gpCnnArry[connId], lobType);
    OCI_LobWrite(* ppDbLobType, pValue, lobSize);

    EXIT_BLOCK();
    RETURN_RESCODE;
}





ResCodeT DbCmmnFreeDateType( DbDateTypeT * pDbDateType)
{
    BEGIN_FUNCTION( "DbCmmnFreeDateType" );
    
    OCI_DateFree(pDbDateType);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnFreeTimestampType(DbTimestampTypeT * pDbTimestampType)
{
    BEGIN_FUNCTION( "DbCmmnFreeTimestampType" );
    
    OCI_TimestampFree(pDbTimestampType);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DbCmmnFmtLobType( DbLobTypeT * pDbLobType)
{
    BEGIN_FUNCTION( "DbCmmnFmtLobType" );
    
    OCI_LobFree(pDbLobType);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT DbCmmnExcSqlWithRslt(int32 connId, int32 stmntId)
{
    BEGIN_FUNCTION( "DbCmmnExcSqlNoRslt" );
    
    ResCodeT rc = NO_ERR;
    
    if ( connId > gConnIdCnt || !BitCheck (gStmntVct, stmntId))
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    
    if (!gpStmntArry[stmntId]) {
        LOG_ERROR(ERR_DB_OCI_STATE_NOT_USE_ERR, "the statement is null.(ConnID:%d, StmtID:%d)", connId, stmntId);
        RAISE_ERR(ERR_DB_OCI_STATE_NOT_USE_ERR, RTN);
    }

    // Execute the statement.
    if (!OCI_Execute(gpStmntArry[stmntId])) 
    {
        LOG_ERROR(ERR_DB_OCI_EXEC_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_EXEC_ERR, RTN);
    }
    
    
    gpRsltSet[stmntId] = OCI_GetResultset(gpStmntArry[stmntId]);
    // Execute the statement.
    if (!gpRsltSet[stmntId]) 
    {
        LOG_ERROR(ERR_DB_OCI_GET_RESULTSET_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_GET_RESULTSET_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT DbCmmnGetRow(int32 stmntId, int32 colIdx, pDbColInfoT pDbColInfo, void * pColValAddr)
{
    BEGIN_FUNCTION( "DbCmmnGetRow" );

    ResCodeT rc = NO_ERR;
    
    int64 *     pInt64Val = NULL;
    int32 *     pInt32Val = NULL;
    double *    pDoubleVal = NULL;
    float *     pFloatVal = NULL;
    char *      pLobVal = NULL;
    
    switch (pDbColInfo->colType) 
    {
            case DB_COL_STRING:
                strcpy((char *)pColValAddr, OCI_GetString(gpRsltSet[stmntId], colIdx));
                break;
                
            case DB_COL_INT64:
                pInt64Val = (int64 *)pColValAddr;
                *pInt64Val = (int64)OCI_GetBigInt(gpRsltSet[stmntId], colIdx);
                break;
                
            case DB_COL_INT32:
            case DB_COL_INT16:      
                pInt32Val = (int32 *)pColValAddr;
                *pInt32Val = (int32)OCI_GetInt(gpRsltSet[stmntId], colIdx);
                break;
                
            case DB_COL_DOUBLE:
                pDoubleVal = (double *)pColValAddr;
                *pDoubleVal = (double)OCI_GetDouble(gpRsltSet[stmntId], colIdx);
                break;
            case DB_COL_FLOAT:
                pFloatVal = (float *)pColValAddr;
                *pFloatVal = (float)OCI_GetFloat(gpRsltSet[stmntId], colIdx);
                break;
            case DB_COL_DATE:
                OCI_DateToText(OCI_GetDate(gpRsltSet[stmntId], colIdx), OTEXT("YYYY-MM-DD HH24:MI:SS"),  pDbColInfo->valSize, (otext*)pColValAddr);
                break;
            case DB_COL_TIMESTAMP:
                OCI_TimestampToText(OCI_GetTimestamp(gpRsltSet[stmntId], colIdx), OTEXT("YYYYMMDD-HH24:MI:SS:FF\n"), pDbColInfo->valSize, (otext*)pColValAddr, 3);
                break;
            
            case DB_COL_BLOB:
            case DB_COL_CLOB:
                pLobVal = (char *)pColValAddr;
                pLobVal[OCI_LobRead(OCI_GetLob(gpRsltSet[stmntId], colIdx),pColValAddr, pDbColInfo->valSize)] = 0;
                break;
                                
            default:
                LOG_ERROR(ERR_DB_OCI_EXEC_ERR,"read data type is undefined.");
                RAISE_ERR(ERR_DB_COMMON_INVLD_DATATYPE_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbCmmnFetchNext(int32 connId, int32 stmntId, int32 infoCnt, pDbColInfoT pDbColInfo, void * pColValAddr)
{
    BEGIN_FUNCTION( "DbCmmnFetchNext" );
    ResCodeT    rc = NO_ERR;
    int32       i = 0;
    void *      pColVal = NULL; 
    if ( connId > gConnIdCnt || !BitCheck (gStmntVct, stmntId))
    {
        RAISE_ERR( ERR_DB_OCI_CREATE_STATE_ERR, RTN );
    }
    
    if (!OCI_FetchNext(gpRsltSet[stmntId] )) 
    {
        //LOG_DEBUG(ERR_DB_OCI_EXEC_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        THROW_RESCODE(ERR_DB_OCI_END_OF_RESULTSET_ERR);
    }
    
    for (i = 0; i < infoCnt; i++)
    {
        
        pColVal = (void *)ADDRESS_ADD_OFFSET(pColValAddr, pDbColInfo[i].valOffset);
        rc = DbCmmnGetRow(stmntId, i+1, &pDbColInfo[i], pColVal);
        RAISE_ERR( rc, RTN );
        
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT ExtPrprSttmnt(DbStmt * pDbStmnt, char * pSql)
{
    BEGIN_FUNCTION( "ExtPrprSttmnt" );

    // Prepare Start.
    if (!OCI_Prepare(pDbStmnt->ociStmt, pSql)) {
//        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        LOG_ERROR(ERR_DB_OCI_EXEC_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        if (pDbStmnt->ociStmt) {
            OCI_StatementFree(pDbStmnt->ociStmt);
            pDbStmnt->ociStmt = NULL;
        }
        RAISE_ERR(ERR_DB_OCI_PREPARE_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtCreateSttmnt(DbConn * pDbConn, DbStmt * pDbStmnt)
{
    BEGIN_FUNCTION( "ExtCreateSttmnt" );


    // Use connection to create statement.
    pDbStmnt->ociStmt = OCI_StatementCreate(pDbConn->ociConn);
    if (!pDbStmnt->ociStmt ) {
//        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        LOG_ERROR(ERR_DB_OCI_EXEC_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_CREATE_STATE_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtGetConnAddr(int32 connId,DbConn * pDbConn )
{
    BEGIN_FUNCTION( "ExtGetConnAddr" );
   
    pDbConn->ociConn = gpCnnArry[connId];
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtExeSql(DbStmt * pDbStmnt)
{
    BEGIN_FUNCTION( "ExtExeSql" );


    // Data Bind Start.
    if (!OCI_Execute(pDbStmnt->ociStmt)) {
        LOG_ERROR(ERR_DB_OCI_EXEC_ERR, "statement execute is failed. %s",OCI_ErrorGetString(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_EXEC_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtCreateArrayLob(DbConn * pDbConn, int32 rcrdCnt, DbLobTypeT *** pppDbBuff)
{
    BEGIN_FUNCTION( "ExtCreateArrayLob" );

    * pppDbBuff  = OCI_LobArrayCreate(pDbConn->ociConn,  OCI_BLOB, rcrdCnt);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtFreeArrayLob(DbLobTypeT ** ppDbBuff)
{
    BEGIN_FUNCTION( "ExtFreeArrayLob" );

    OCI_LobArrayFree(ppDbBuff);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtSetArraySize(DbStmt * pDbStmnt, int32 size)
{
    BEGIN_FUNCTION( "ExtSetArraySize" );

    if (!OCI_BindArraySetSize(pDbStmnt->ociStmt, size)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtBindArrayLob(DbStmt * pDbStmnt, char* pColString, DbLobTypeT ** ppDbBuff)
{
    BEGIN_FUNCTION( "ExtBindArrayInt" );


    if (!OCI_BindArrayOfLobs(pDbStmnt->ociStmt, pColString, ppDbBuff, OCI_BLOB, 0)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtWriteLob(DbLobTypeT * pDbBuff, void * pInBuff, int32 buffLen)
{
    BEGIN_FUNCTION( "ExtWriteLob" );


    if (!OCI_LobWrite(pDbBuff, pInBuff, buffLen)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtFreeStmnt(DbStmt * pDbStmnt)
{
    BEGIN_FUNCTION( "ExtFreeStmnt" );


    if (!OCI_StatementFree(pDbStmnt->ociStmt)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtBindArrayInt(DbStmt * pDbStmnt, char* pColString, int32* pValueList)
{
    BEGIN_FUNCTION( "ExtBindArrayInt" );


    if (!OCI_BindArrayOfInts(pDbStmnt->ociStmt, pColString, pValueList, 0)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtBindInt(DbStmt * pDbStmnt, char* pColString, int32* pValue)
{
    BEGIN_FUNCTION( "ExtBindInt" );

    // Data Bind Start.
    if (!OCI_BindInt(pDbStmnt->ociStmt, pColString, (int*)pValue)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR,"[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtBindBigInt(DbStmt * pDbStmnt, char* pColString, int64* pValue)
{
    BEGIN_FUNCTION( "ExtBindBigInt" );

    // Data Bind Start.
    if (!OCI_BindBigInt(pDbStmnt->ociStmt, pColString, (long long int *)pValue)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtWriteTimestamp( char * pValue, DbTimestampTypeT * pDbTimestamp)
{
    BEGIN_FUNCTION( "ExtBindTimestamp" );
    
    OCI_TimestampFromText(pDbTimestamp, pValue, "YYYY-MM-DD HH24:MI:SS:FF");

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtBindTimestamp(DbStmt * pDbStmnt, char* pColString, DbTimestampTypeT ** ppDbTimestamp)
{
    BEGIN_FUNCTION( "ExtBindTimestamp" );
    
    * ppDbTimestamp = OCI_TimestampCreate(NULL, OCI_TIMESTAMP);

    // Data Bind Start.
    if (!OCI_BindTimestamp(pDbStmnt->ociStmt, pColString, * ppDbTimestamp)) {
        LOG_ERROR(ERR_DB_OCI_BIND_ERR, "[OCI_MSG]: %s.(OCI_CODE:%d)", OCI_ErrorGetString(OCI_GetLastError()), OCI_ErrorGetOCICode(OCI_GetLastError()));
        RAISE_ERR(ERR_DB_OCI_BIND_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExtFreeTimestamp( DbTimestampTypeT * pDbTimestamp)
{
    BEGIN_FUNCTION( "ExtFreeTimestamp" );
    
    OCI_TimestampFree(pDbTimestamp);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
