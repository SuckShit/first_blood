﻿/***
Created on June 13, 2017
@author: No One
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

#include "../include/data_type.h"
#include "../include/err_lib.h"
#include "../include/common_hash.h"
#include "../include/shm.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define HASH_TBL_NULL_KEY           ((uint64)-1)
#define HASH_TBL_DEL_KEY            ((uint64)-2)

#define HASH_TBL_STATUS_IDX_SIZE    ( sizeof(int64) )


#define PROCESS_MEMORY_TAG                      "PROCESS_MEM"


/* Return the next available control handle */
#define GET_NEXT_HNDL(__newHndl)             \
do\
{\
    gCurHashHndl++;                                             \
    if ( gCurHashHndl > MAX_CMN_HASH_HNDL )                     \
    {                                                           \
        RAISE_ERR_PARM(ERCD_ARCH_INVLD_HNDL, RTN,              \
                        MAX_CMN_HASH_HNDL $$ gCurHashHndl);     \
    }                                                           \
    else                                                        \
    {                                                           \
        (__newHndl) = gCurHashHndl;                             \
    }                                                           \
} while ( 0 )

/* Validate the hash handle pass-in */
#define IS_VALID_HASH_HNDL(__curHndl)       \
do\
{\
    if ( (__curHndl) < 1 || (__curHndl) > MAX_CMN_HASH_HNDL ||          \
        !gShmHashAccs[(__curHndl)].pRtShm )                             \
    {                                                                   \
        RAISE_ERR_PARM(ERCD_ARCH_INVLD_HNDL, RTN, (__curHndl)); \
    }                                                                   \
} while ( 0 )

/* Pointer to the current handle structure */
#define GET_HASH_HNDL_PNT(__curHndl)        (&gShmHashAccs[(__curHndl)])

/* Control area size from the common hash table */
#define CMN_HASH_INTL_SIZE()                \
                            (sizeof(HashTableInfoT) + sizeof(HashTableCtrlT))


#define GET_ALL_HASH_LIST_SIZE(__pHashAccs, __listSize)     \
do\
{\
    (__listSize) = 0;                                                       \
    int64 __tmpListSize = sizeof(listCmnHeadT) +                          \
            (__pHashAccs)->CmnHashTblAccsT_cntSlots * sizeof(listCmnNodeT); \
    if ( (__pHashAccs)->CmnHashTblAccsT_bHasList )                          \
    {                                                                       \
        (__listSize) = (__listSize) + __tmpListSize;                        \
    }                                                                       \
    if ( (__pHashAccs)->CmnHashTblAccsT_bHasTimeList )                      \
    {                                                                       \
        (__listSize) = (__listSize) + __tmpListSize;                        \
    }                                                                       \
} while ( 0 )

/* Get the hash table list area size */
#define GET_HASH_LIST_SIZE(__pHashAccs, __listSize)  \
do\
{\
    if ( (__pHashAccs)->CmnHashTblAccsT_bHasList ||                         \
        (__pHashAccs)->CmnHashTblAccsT_bHasTimeList )                       \
    {                                                                       \
        (__listSize) = sizeof(listCmnHeadT) +                               \
            (__pHashAccs)->CmnHashTblAccsT_cntSlots * sizeof(listCmnNodeT); \
    }                                                                       \
    else                                                                    \
    {                                                                       \
        (__listSize) = 0;                                                   \
    }                                                                       \
} while ( 0 )



/* Get the hash table data area size */
#define GET_HASH_TABLE_SIZE(__pHashAccs, __tblSize)  \
do\
{\
    int64 __tmpSize = 0;                                      \
    GET_ALL_HASH_LIST_SIZE((__pHashAccs), __tmpSize);           \
    (__tblSize) = (__pHashAccs)->CmnHashTblAccsT_memSize -      \
                    __tmpSize - CMN_HASH_INTL_SIZE();           \
} while ( 0 )


/* Check if the current data position is within the list */
#define IS_NODE_IN_HASH_LIST(__tblAccs, __node, __result)   \
do\
{\
    int64 __sts = (__tblAccs)->pHashList->listData[(__node)].validFlg;    \
    (__result) = (__sts == CMN_LIST_VALID_NODE);                            \
} while ( 0 )


/* Validate if a data position is beyond the table range */
#define IS_VALID_NODE_POS(__pos, __tblAccs)         \
do\
{\
    if ( (__pos) >= (__tblAccs)->CmnHashTblAccsT_cntSlots )     \
    {                                                           \
        RAISE_ERR_PARM( ERCD_ARCH_BUFF_TOO_SHORT, RTN,         \
                    0 $$ 0 $$ (__pos) $$                        \
                    (__tblAccs)->CmnHashTblAccsT_cntSlots );    \
    }                                                           \
} while ( 0 )

#define SHIFT_TO_DATA(__pRoot, __dOffset, __pData)      \
do\
{\
    (__pData) = (void *)ADDRESS_ADD_OFFSET((__pRoot),         \
                    (__dOffset) + sizeof(int64));             \
} while ( 0 )

#define SHIFT_TO_STATUS(__pRoot, __dOffset, __pData, __type)    \
do\
{\
    (__pData) = (void *)ADDRESS_ADD_OFFSET((__pRoot),         \
                    (__dOffset) );                              \
} while ( 0 )

#define IS_AN_DELETED_HASH_KEY( __pData )       \
            ( *((uint64 *)(__pData)) == HASH_TBL_DEL_KEY )

#define CONV_USER_REC_SIZE( __iSize )       \
            ( (__iSize) - HASH_TBL_STATUS_IDX_SIZE )

#define UPD_HASH_STTS( __pHashCtrl, __sCnt, __fCnt )        \
do\
{\
    (__pHashCtrl)->hashCnt += 1;                    \
    (__pHashCtrl)->searchCnt += (__sCnt);           \
    (__pHashCtrl)->findAvaSlotCnt += (__fCnt);      \
} while ( 0 )


/******************************************************************************
 **
 **  Type Defination
 **
 ******************************************************************************/
/* Macro defined for simpler parameter access */
#define CmnHashTblAccsT_recSize             pHashInfo->tableRecInfo.recSize
#define CmnHashTblAccsT_keyOffset           pHashInfo->tableRecInfo.keyOffset
#define CmnHashTblAccsT_keySize             pHashInfo->tableRecInfo.keySize
#define CmnHashTblAccsT_recCnt              pHashInfo->tableRecInfo.recCnt

#define CmnHashTblAccsT_OArecSize       pHashInfo->oaHashTableRecInfo.recSize
#define CmnHashTblAccsT_OAkeyOffset     pHashInfo->oaHashTableRecInfo.keyOffset
#define CmnHashTblAccsT_OAkeySize       pHashInfo->oaHashTableRecInfo.keySize
#define CmnHashTblAccsT_OArecCnt        pHashInfo->oaHashTableRecInfo.recCnt

#define CmnHashTblAccsT_memSize             pHashInfo->memSize
#define CmnHashTblAccsT_fullThreshold       pHashInfo->fullThreshold
#define CmnHashTblAccsT_cntSlots            pHashInfo->cntSlots
#define CmnHashTblAccsT_bHasList            pHashInfo->bHasList
#define CmnHashTblAccsT_bHasTimeList        pHashInfo->bHasTimeList
#define CmnHashTblAccsT_shmName             pHashInfo->shmName

#define CmnHash_Ctrl_peakSlotsInList        pHashCtrl->peakSlotsInList
#define CmnHash_Ctrl_usedSlotsInList        pHashCtrl->usedSlotsInList
#define CmnHash_Ctrl_peakSlots              pHashCtrl->peakSlots
#define CmnHash_Ctrl_usedSlots              pHashCtrl->usedSlots
#define CmnHash_Ctrl_fullThreshold          pHashCtrl->fullThreshold


/* Common hash table internal access structure, pointing to the shared memory
    and containing necessary hash info */
typedef struct CmnHashTblAccsS
{
    void *            pRtShm;
    HashTableInfoT *   pHashInfo;
    HashTableCtrlT *   pHashCtrl;
    HashTableListT *   pHashList;
    HashTableListT *   pDfltTimeList;

    OAHashTableT        oaHash;
} CmnHashTblAccsT, *pCmnHashTblAccsT;



/*****************************************************************************
 **
 ** ???偿
 **
 *****************************************************************************/
/* Global library initial flag */
static BOOL                 gbInitial = FALSE;

/* Hash control array handle */
static CmnHashTblAccsT      gShmHashAccs[MAX_CMN_HASH_HNDL + 1];
static CmnHashHndlT         gCurHashHndl = 0;   /* increase prior to usage */




/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static __inline__ BOOL DefltIsKeyEqualFunc(const void * key1,
                                const void * key2, int32 keyLen);
static __inline__ BOOL DefltIsNullFunc(const void * key, int32 stsOffset);
static __inline__ BOOL DefltIsDeleteFunc(const void * key, int32 stsOffset);


static __inline__ void HashTblReadData(uint32 pos,
                                OAHashTableT * pOAHashTable,
                                void * pData,
                                unsigned short dLen);

void ShmMap2CmnHashTbl(void * pData, pCmnHashTblAccsT pHashTblAccs);
void ShmInitOaHashObject(pCmnHashTblAccsT pHashTblAccs);

static ResCodeT IntlGlbCtrlParaInitial();

static void ListDelNode(uint32 nodePos,
                                HashTableListT * pHashList,
                                pCmnHashTblAccsT pHashTblAccs);
static void ListAddNode(uint32 nodePos,
                                HashTableListT * pHashList,
                                pCmnHashTblAccsT pHashTblAccs);
static void ListIterateData(HashTableListT * pHashList,
                                uint32 lstIterPos,
                                uint32 * pDataPos,
                                uint32 * pCurrPos);

static void ListIterateDataExt(HashTableListT * pHashList,
                                uint32 lstIterPos,
                                uint32 * pDataPos,
                                uint32 * pCurrPos);
/******************************************************************************
 **
 ** Function Implementation
 **
 ******************************************************************************/
uint32 FNVHash (char * str, uint32 len)
{
    char * s = str;
    uint32 i =0;
    uint32 hashVal = 0;
    
    i = 0;
    while (i<len)
    {
        hashVal += (hashVal<<1)+(hashVal<<4) + (hashVal<<7)+ (hashVal<<8)+(hashVal<<24);
        
        hashVal ^= (uint32)*s++;
        i++;
    }
    
    return hashVal;
}

BOOL IsPrime(int64 lnVal)
{
    register int64 i;
    register int64 testMax;
    
    if (1>= lnVal)
    {
        return FALSE;
    }
    
    switch(lnVal)
    {
        case 2:
        case 3:
        case 5:
            return TRUE;
        default:
            if (0==(lnVal%2) || 0==(lnVal%3) || 0==(lnVal%5))
            {
                return FALSE;
            }
            break;
    }
    testMax = lnVal;
    for (i=7; testMax>i; i+=2)
    {
        if (0==(lnVal%i))
        {
            return FALSE;
        }
        testMax = (int64)(0.5 + ((double)lnVal/i));
    }
    
    return TRUE;
}


int64 GetPrime(int64 lnVal)
{
    register int64 v;
    if (1>=lnVal)
    {
        return lnVal;
    }
    
    for (v=lnVal; v>1; --v)
    {
        if (TRUE == IsPrime(v))
        {
            return v;
        }
    }
    
    return v;
}
 

ResCodeT OAHashTableSearchExt(OAHashTableT* OAHashTable,
            const void * key,
            uint32 * position,
            int32 * fFoundFlag,
            BOOL returnNxtAvaSlot,
            BOOL findNullSlotOnly,
            uint32 * searchCnt,
            uint32 * findAvaSlotCnt,
            uint32 maxTries,
            int32 keyLen,
            int32 stsOffset)
{
    BEGIN_FUNCTION("OAHashTableSearchExt");
    uint64 hashKey, step, offset, oldOffset, delSlot;
    unsigned char * slotIter;
    uint32 tryCnt = 1, findDelSlotCnt;

    ASSERT(TRUE);

    if (!OAHashTable || !fFoundFlag || !position)
    {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }
    *fFoundFlag = FALSE;
    *position = -1;
    delSlot = -1;

    /* hashing */
    hashKey = OAHashTable->hashFunc((char *)key, OAHashTable->keySize);
    step = hashKey / OAHashTable->cntSlots;
    offset = hashKey % OAHashTable->cntSlots;
    if (step >= OAHashTable->cntSlots)
    {
        step %= OAHashTable->cntSlots;
    }
    if (!step)
    {
        /* then use a magic # */
        step = 7;
    }

    slotIter = OAHashTable->pTableRoot +
        OAHashTable->recSize * offset +
        OAHashTable->keyOffset;
    oldOffset = -1;

    while (!OAHashTable->IsNullSlot(slotIter, stsOffset) && oldOffset != offset)
    {
        /* if findNullSlotOnly is TRUE, then the calling modules must assure
        that same key has not been inserted into the table yet */
        if (findNullSlotOnly && OAHashTable->IsDeletedSlot(slotIter,stsOffset))
        {
            /* find a NULL slot, and return */
            if (findAvaSlotCnt)
            {
                *findAvaSlotCnt = tryCnt;
            }
            *position = (uint32)offset;
            THROW_RESCODE(NO_ERR);
        }
        if (OAHashTable->IsKeyEqual(slotIter, key, keyLen))
        {
            /* find */
            *fFoundFlag = TRUE;
            *position = (uint32)offset;
            THROW_RESCODE(NO_ERR);
        }
        else
        {
            if ((uint64)-1 == delSlot &&
                OAHashTable->IsDeletedSlot(slotIter,stsOffset))
            {
                /* rememer the search times to find the first deleted slot */
                findDelSlotCnt = tryCnt;
                delSlot = offset;
            }
            if ((uint64)-1 == oldOffset)
            {
                oldOffset = offset;
            }
            /* collision occurs, then open addressing to find another positon */
            offset += step;
            if (offset >= OAHashTable->cntSlots)
            {
                offset -= OAHashTable->cntSlots;
            }
            slotIter = OAHashTable->pTableRoot +
                OAHashTable->recSize * offset +
                OAHashTable->keyOffset;
        }
        if (tryCnt >= maxTries)
        {
            /* have tried the maxium # of times, but still can not find an
            available slot. stop searching now */
            LOG_DEBUG("OA hash table: can not find a slot within %04d tries\n"
                ,maxTries);
            /* failed to find a slot, then exit */
            break;
        }
        ++tryCnt;
    }

    if (!(*fFoundFlag) && returnNxtAvaSlot)
    {
        if ((uint64)-1 != delSlot)
        {
            if (findAvaSlotCnt)
            {
                *findAvaSlotCnt = findDelSlotCnt;
            }
            *position = (uint32)delSlot;
        }
        else if (oldOffset != offset)
        {
            if (findAvaSlotCnt)
            {
                *findAvaSlotCnt = tryCnt;
            }
            *position = (uint32)offset;
        }
        else
        {
            /* holding over-flow */
            RAISE_ERR(ERR_CMN_HASH_LIST_FULL, RTN);
        }
    }

    EXIT_BLOCK();
    if (OK(GET_RESCODE()))
    {
        if (searchCnt)
        {
            *searchCnt = tryCnt;
        }
        TRACE("OA hash table: tried %04d times to find a position\n"
            $$ tryCnt);
    }
    RETURN_RESCODE;
}

int64 GetDfltHashMemSize(const int64 lnVal)
{
    int64 v =0;
    v = lnVal/DEFAULT_HASH_LOAD_RATIO;
    return GetPrime(v);
}
/* 3 inline functions, serving as the default comparing functions */
static __inline__ BOOL DefltIsKeyEqualFunc(const void * key1,
                                const void * key2, int32 keyLen)
{
    BEGIN_FUNCTION("DefltIsKeyEqualFunc");
    ASST(key1 && key2);
    EXIT_BLOCK();
    return ( memcmp(key1, key2, keyLen) == 0 );
} /* End of DefltIsKeyEqualFunc */

static __inline__ BOOL DefltIsNullFunc(const void * key, int32 stsOffset)
{
    BEGIN_FUNCTION("DefltIsNullFunc");
    uint64 *              pStts = NULL;
    ASST(key);
    pStts = (uint64 *)ADDRESS_MINUS_OFFSET(key, stsOffset);
    EXIT_BLOCK();
    return ((*pStts) == HASH_TBL_NULL_KEY );
} /* End of DefltIsNullFunc */
static __inline__ BOOL DefltIsDeleteFunc(const void * key, int32 stsOffset)
{
    BEGIN_FUNCTION("DefltIsDeleteFunc");
    uint64 *              pStts = NULL;
    ASST(key);
    EXIT_BLOCK();
    pStts = (uint64 *)ADDRESS_MINUS_OFFSET(key, stsOffset);
    return ( IS_AN_DELETED_HASH_KEY(pStts) );
} /* End of DefltIsDeleteFunc */

/*______________________________________________________________________________
 *******************************************************************************
 * Function: HashTblReadDataAddr
 * ----------------------------------------------------------------------------
 * Description: inline function, directly read the memory address
 *
 ******************************************************************************/
static __inline__ void HashTblReadDataAddr(uint32 pos,
                                OAHashTableT * pOAHashTable,
                                void * * ppData,
                                unsigned short dLen)
{
    BEGIN_FUNCTION("HashTblReadDataAddr");
    int64                 dataOffset = pos;
    ASST( pOAHashTable && ppData );

    dataOffset *= pOAHashTable->recSize;
    SHIFT_TO_DATA(pOAHashTable->pTableRoot, dataOffset, (* ppData));
    EXIT_BLOCK();
} /* End of HashTblReadDataAddr */


static __inline__ void HashTblReadData(uint32 pos,
                                OAHashTableT * pOAHashTable,
                                void * pData,
                                unsigned short dLen)
{
    BEGIN_FUNCTION("HashTblReadData");
    int64                 dataOffset = pos;
    void *                pSrcData = NULL;
    ASST( pOAHashTable && pData );

    dataOffset *= pOAHashTable->recSize;
    SHIFT_TO_DATA(pOAHashTable->pTableRoot, dataOffset, pSrcData);
    memcpy( pData, pSrcData, dLen );
    EXIT_BLOCK();
} /* End of HashTblReadData */


ResCodeT CmnHashTblCreateWithTimeList(char *pShmName,
                                HashTableRecInfoT recInfo,
                                BOOL bNeedList,
                                void * *ppRt,
                                pCmnHashHndlT pHashHndl)
{
    BEGIN_FUNCTION("CmnHashTblCreateWithTimeList");
    ResCodeT                rc = NO_ERR;
    ASST ( ppRt && pHashHndl && pShmName );

    if ( !gbInitial )
    {
        /* Not an actual initializatio call, but for global parameters */
        RAISE_ERR(IntlGlbCtrlParaInitial(), RTN);
    }

    *ppRt = NULL;

    recInfo.bNeedTimeList = TRUE;

    rc = CmnHashTblCreate(pShmName, recInfo, bNeedList, ppRt, pHashHndl);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblCreateWithTimeList */


ResCodeT CmnHashTblCreate(char *pShmName,
                                HashTableRecInfoT recInfo,
                                BOOL bNeedList,
                                void * *ppRt,
                                pCmnHashHndlT pHashHndl)
{
    BEGIN_FUNCTION("CmnHashTblCreate");
    ResCodeT                rc = NO_ERR;
    void *                pRoot = NULL;
    int64                 memSize = 0;
    int64                 elememtSize = 0;
    int64                 listSize = 0;
    int64                 hashTblCnt = 0;
    CmnHashHndlT            iHashHndl = NULL_CMN_HASH_HNDL;
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST ( ppRt && pHashHndl && pShmName );

    if ( !gbInitial )
    {
        /* Not an actual initializatio call, but for global parameters */
        RAISE_ERR(IntlGlbCtrlParaInitial(), RTN);
    }

    *ppRt = NULL;

    /* Calculate the hash table total element count and then get shm size */
    hashTblCnt = GetDfltHashMemSize(recInfo.recCnt);
    listSize = 0;
    if ( bNeedList )
    {
        /* If list funciton is enabled, extra space is needed */
        listSize += hashTblCnt * sizeof(listCmnNodeT) + sizeof(listCmnHeadT);
    }
    if ( recInfo.bNeedTimeList )
    {
        listSize += hashTblCnt * sizeof(listCmnNodeT) + sizeof(listCmnHeadT);
    }
    /* Each elelment consists of the aligned user data length and a 8-byte
       status field */
    elememtSize = ELEM_SIZE_ALIGN( recInfo.recSize ) + sizeof(int64);
    memSize = hashTblCnt * elememtSize +
                sizeof(HashTableInfoT) +
                sizeof(HashTableCtrlT) +
                listSize;

    /*-------------------    Create the shm section here   -------------------*/
    rc = ShmCreate(pShmName, memSize, (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);

    memset(pRoot, 0xFF, memSize);
    //LOG_CREATE_SHM_INFO(adapt_name(pShmName), memSize);


    /*-------------------    Prepare internal control hndl -------------------*/
    /* Get the next hash table handle */
    GET_NEXT_HNDL(iHashHndl);
    pTblAccs = (pCmnHashTblAccsT)&gShmHashAccs[iHashHndl];

    /* ### Map the shared memory to access structure ### */
    ShmMap2CmnHashTbl(pRoot, pTblAccs);

    /* Then, update the hash table info to the shared memory */
    pTblAccs->CmnHashTblAccsT_recSize   = recInfo.recSize;
    pTblAccs->CmnHashTblAccsT_keyOffset = recInfo.keyOffset;
    pTblAccs->CmnHashTblAccsT_keySize   = recInfo.keySize;
    pTblAccs->CmnHashTblAccsT_recCnt    = recInfo.recCnt;

    pTblAccs->CmnHashTblAccsT_OArecSize     =
                        ELEM_SIZE_ALIGN( recInfo.recSize ) + sizeof(int64);
    pTblAccs->CmnHashTblAccsT_OAkeyOffset   =
                        sizeof(int64) + recInfo.keyOffset;
    pTblAccs->CmnHashTblAccsT_OAkeySize     = recInfo.keySize;
    pTblAccs->CmnHashTblAccsT_OArecCnt      = recInfo.recCnt;

    pTblAccs->CmnHashTblAccsT_memSize       = memSize;
    pTblAccs->CmnHashTblAccsT_fullThreshold = recInfo.recCnt;
    pTblAccs->CmnHashTblAccsT_cntSlots      = hashTblCnt;
    pTblAccs->CmnHashTblAccsT_bHasList      = bNeedList;
    pTblAccs->CmnHashTblAccsT_bHasTimeList  = recInfo.bNeedTimeList;


    /* Also log the shm name into the control struction for better
       error informaiton output */
    memset(pTblAccs->CmnHashTblAccsT_shmName, 0x00, SHM_NAME_LEN);
    memcpy(pTblAccs->CmnHashTblAccsT_shmName,
            pShmName, strlen(pShmName));

    /* Initial the control area */
    pTblAccs->CmnHash_Ctrl_peakSlotsInList  = 0;
    pTblAccs->CmnHash_Ctrl_usedSlotsInList  = 0;
    pTblAccs->CmnHash_Ctrl_peakSlots        = 0;
    pTblAccs->CmnHash_Ctrl_usedSlots        = 0;
    pTblAccs->CmnHash_Ctrl_fullThreshold    = recInfo.recCnt;

    /* ### Fill data to the OaHash structure ### */
    ShmInitOaHashObject(pTblAccs);


    /*-------------------    Return the output info        -------------------*/
    /* Return the shm pointer and the hash handle */
    (*ppRt) = pRoot;
    (*pHashHndl) = iHashHndl;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblCreate */


ResCodeT CmnHashTblAttach(char *pShmName,
                                void * *ppRt,
                                pCmnHashHndlT pHashHndl)
{
    BEGIN_FUNCTION("CmnHashTblAttach");
    ResCodeT                rc = NO_ERR;
    int64                   shmSize;
    void *                pRoot = NULL;
    CmnHashHndlT            iHashHndl = NULL_CMN_HASH_HNDL;
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST( pShmName && ppRt && pHashHndl );

    if ( !gbInitial )
    {
        /* Not an actual initializatio call, but for global parameters */
        RAISE_ERR(IntlGlbCtrlParaInitial(), RTN);
    }

    /*-------------------    Attach to the given shm       -------------------*/
    rc = ShmAttach(pShmName, (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);

    /*-------------------    Prepare internal control hndl -------------------*/
    /* Get the next hash table handle */
    GET_NEXT_HNDL(iHashHndl);
    pTblAccs = (pCmnHashTblAccsT)&gShmHashAccs[iHashHndl];

    /* Map the shared memory to access structure */
    ShmMap2CmnHashTbl(pRoot, pTblAccs);
    /* Fill data to the OaHash structure */
    ShmInitOaHashObject(pTblAccs);

    /*-------------------    Return the output info        -------------------*/
    /* Return the shm pointer and the hash handle */
    (*ppRt) = pRoot;
    (*pHashHndl) = iHashHndl;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblAttach */

ResCodeT CmnHashTblGetGlbInfo(CmnHashHndlT hHashHndl,
                            HashTableCtrlT * pHashCtrl)
{
    BEGIN_FUNCTION("CmnHashTblGetGlbInfo");
    ResCodeT                rc = NO_ERR;
    ASST( pHashCtrl );

    IS_VALID_HASH_HNDL(hHashHndl);

    memcpy(pHashCtrl, gShmHashAccs[hHashHndl].pHashCtrl,
                        sizeof(HashTableCtrlT));

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblAttach */

ResCodeT CmnHashTblGetRecTotal(CmnHashHndlT hHashHndl, uint64 * pRecTotal)
{
    BEGIN_FUNCTION("CmnHashTblGetRecTotal");
    ASST( pRecTotal );

    IS_VALID_HASH_HNDL(hHashHndl);
    (*pRecTotal) = gShmHashAccs[hHashHndl].pHashCtrl->usedSlots;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblGetRecTotal */


ResCodeT CmnHashTblGetRecAll(CmnHashHndlT hHashHndl, uint64 * pRecAll)
{
    BEGIN_FUNCTION("CmnHashTblGetRecAll");
    ASST( pRecAll );

    IS_VALID_HASH_HNDL(hHashHndl);
    (*pRecAll) = gShmHashAccs[hHashHndl].pHashInfo->cntSlots;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblGetRecAll */


void ShmMap2CmnHashTbl(void * pData, pCmnHashTblAccsT pHashTblAccs)
{
    BEGIN_FUNCTION("ShmMap2CmnHashTbl");
    ASST( pData && pHashTblAccs );

    /* Map the HashTable Shm Section */
    pHashTblAccs->pRtShm    = pData;
    pHashTblAccs->pHashInfo = (HashTableInfoT *)pHashTblAccs->pRtShm;
    pHashTblAccs->pHashCtrl = (HashTableCtrlT *)ADDRESS_ADD_OFFSET(
                                pHashTblAccs->pHashInfo,
                                sizeof(HashTableInfoT));

    EXIT_BLOCK();
} /* End of ShmMap2CmnHashTbl */


void ShmInitOaHashObject(pCmnHashTblAccsT pHashTblAccs)
{
    BEGIN_FUNCTION("ShmInitOaHashObject");
    void *                pHashRt = NULL;
    int64                 prevSectSize = 0;
    ASST( pHashTblAccs && pHashTblAccs->pRtShm );


    /* The hash table section would start right after the control area */
    pHashRt = (void *)pHashTblAccs->pHashCtrl;
    prevSectSize = sizeof(HashTableCtrlT);


    /* Map the OaHash structure below */
    pHashTblAccs->oaHash.pTableRoot = (unsigned char *)ADDRESS_ADD_OFFSET(
                                    pHashRt,
                                    prevSectSize);
    pHashRt = (void *)pHashTblAccs->oaHash.pTableRoot;
    GET_HASH_TABLE_SIZE(pHashTblAccs, prevSectSize);

    if ( pHashTblAccs->CmnHashTblAccsT_bHasList )
    {
        /* If list function is enabled, need to map them here */
        pHashTblAccs->pHashList = (HashTableListT *)ADDRESS_ADD_OFFSET(
                                    pHashRt,
                                    prevSectSize);

        pHashRt = (void *)pHashTblAccs->pHashList;
        GET_HASH_LIST_SIZE(pHashTblAccs, prevSectSize);
    }

    if ( pHashTblAccs->CmnHashTblAccsT_bHasTimeList )
    {
        /* If list function is enabled, need to map them here */
        pHashTblAccs->pDfltTimeList = (HashTableListT *)ADDRESS_ADD_OFFSET(
                                    pHashRt,
                                    prevSectSize);

        pHashRt = (void *)pHashTblAccs->pDfltTimeList;
        GET_HASH_LIST_SIZE(pHashTblAccs, prevSectSize);
    }



    /*-------------------    Fill-in the OaHash table obj  -------------------*/
    pHashTblAccs->oaHash.cntSlots   = pHashTblAccs->CmnHashTblAccsT_cntSlots;
    pHashTblAccs->oaHash.recSize    = pHashTblAccs->CmnHashTblAccsT_OArecSize;
    pHashTblAccs->oaHash.keyOffset  = pHashTblAccs->CmnHashTblAccsT_OAkeyOffset;
    pHashTblAccs->oaHash.keySize    = pHashTblAccs->CmnHashTblAccsT_OAkeySize;

    pHashTblAccs->oaHash.IsNullSlot     = DefltIsNullFunc;
    pHashTblAccs->oaHash.IsDeletedSlot  = DefltIsDeleteFunc;
    pHashTblAccs->oaHash.IsKeyEqual     = DefltIsKeyEqualFunc;
    pHashTblAccs->oaHash.hashFunc       = FNVHash;



    EXIT_BLOCK();
    return;
} /* End of ShmInitOaHashObject */

ResCodeT CmnHashRegisterFunc(CmnHashHndlT hashHndl,
                                BOOL (*IsNullSlot)(const void *, int32 stsOffset),
                                BOOL (*IsDeletedSlot)(const void *, int32 stsOffset),
                                BOOL (*IsKeyEqual)(const void *,const void *, int32 keyLen))
{
    BEGIN_FUNCTION("CmnHashRegisterFunc");
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST( TRUE );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);

    /* Validate to ensure the callback interface is provided */
    if (!IsNullSlot || !IsDeletedSlot || !IsKeyEqual)
    {
        RAISE_ERR(ERR_INVLD_POINTER, RTN);
    }

    pTblAccs->oaHash.IsNullSlot = IsNullSlot;
    pTblAccs->oaHash.IsDeletedSlot = IsDeletedSlot;
    pTblAccs->oaHash.IsKeyEqual = IsKeyEqual;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashRegisterFunc */


ResCodeT CmnHashLogData(CmnHashHndlT hashHndl,
                                const void * pData,
                                uint32 dataPos,
                                BOOL bAddData,
                                BOOL bAddList)
{
    BEGIN_FUNCTION("CmnHashLogData");
    ResCodeT                rc = NO_ERR;
    HashTableCtrlT *       pHashCtrl = NULL;
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST( pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pHashCtrl = pTblAccs->pHashCtrl;

    /* Update the data into hash table */
    rc = CmnHashUpdateData(hashHndl, pData, dataPos);
    RAISE_ERR(rc, RTN);

    /* Increment the used data count for new data */
    if ( bAddData )
    {
        pHashCtrl->usedSlots++;

        pHashCtrl->peakSlots = (pHashCtrl->usedSlots > pHashCtrl->peakSlots) ?
                    pHashCtrl->usedSlots : pHashCtrl->peakSlots;

        /* If the default timestamp list is enabled, put it into the list */
        if ( pTblAccs->CmnHashTblAccsT_bHasTimeList )
        {
            ListAddNode(dataPos, pTblAccs->pDfltTimeList, pTblAccs);
        }
    }

    /* If needed, add this element to the list as well */
    if ( bAddList )
    {
        if ( pTblAccs->CmnHashTblAccsT_bHasList )
        {
            /* Record the number of nodes in the list */
            pHashCtrl->usedSlotsInList ++;

            pHashCtrl->peakSlotsInList =
                    (pHashCtrl->usedSlotsInList > pHashCtrl->peakSlotsInList) ?
                    pHashCtrl->usedSlotsInList : pHashCtrl->peakSlotsInList;
            ListAddNode(dataPos, pTblAccs->pHashList, pTblAccs);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashLogData */


ResCodeT CmnHashUpdateData(CmnHashHndlT hashHndl,
                                const void * pData,
                                uint32 dataPos)
{
    BEGIN_FUNCTION("CmnHashUpdateData");
    OAHashTableT *         pOAHashTable = NULL;
    HashTableCtrlT *       pHashCtrl = NULL;
    pCmnHashTblAccsT        pTblAccs = NULL;
    int64                 dataOffset = dataPos;
    void *                pDstData = NULL;
    short                   stsLen = sizeof(int64);
    ASST( pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;
    pHashCtrl = pTblAccs->pHashCtrl;

    /* Validate the write position is not beyond the hash table range */
    IS_VALID_NODE_POS(dataPos, pTblAccs);

    dataOffset *= pOAHashTable->recSize;
    /* Special caution is needed here for the actual record size and algned
        OA-Hash table element size, pTblAccs->CmnHashTblAccsT_recSize is a must
    */
    stsLen = stsLen > pTblAccs->CmnHashTblAccsT_recSize ?
            pTblAccs->CmnHashTblAccsT_recSize : stsLen;

    /* First we write 8-byte data to override the status position */
    memcpy(pOAHashTable->pTableRoot + dataOffset, pData, stsLen);

    SHIFT_TO_DATA(pOAHashTable->pTableRoot, dataOffset, pDstData);
    memcpy(pDstData, pData, pTblAccs->CmnHashTblAccsT_recSize);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashUpdateData */

ResCodeT CmnHashDeleteData(CmnHashHndlT hashHndl,
                                uint32 dataPos)
{
    BEGIN_FUNCTION("CmnHashDeleteData");
    OAHashTableT *         pOAHashTable = NULL;
    HashTableCtrlT *       pHashCtrl = NULL;
    pCmnHashTblAccsT        pTblAccs = NULL;
    int64                 dataOffset = dataPos;
    uint64 *              pDelVal = NULL;
    BOOL                    lbInList = FALSE;

    char *                pKeyFrstB = NULL;

    ASST( TRUE );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;
    pHashCtrl = pTblAccs->pHashCtrl;

    /* Validate the write position is not beyond the hash table range */
    IS_VALID_NODE_POS(dataPos, pTblAccs);

    dataOffset *= pOAHashTable->recSize;
    
    pDelVal = (uint64 *)ADDRESS_ADD_OFFSET(pOAHashTable->pTableRoot,dataOffset);      
                    
    //SHIFT_TO_STATUS(pOAHashTable->pTableRoot, dataOffset, pDelVal);
    pKeyFrstB = (char *)ADDRESS_ADD_OFFSET(pOAHashTable->pTableRoot,
                    dataOffset + pOAHashTable->keyOffset);


    /* Avoid for deleting the same node twice */
    if ( (*pDelVal) != HASH_TBL_DEL_KEY )
    {
        pHashCtrl->usedSlots = pHashCtrl->usedSlots > 0 ?
                            (pHashCtrl->usedSlots - 1) : 0;

        /* If list function is enabled for this hash table, need to cleanup */
        if ( pTblAccs->CmnHashTblAccsT_bHasList )
        {
            /* As int32 as this node exists, delete it from node */
            IS_NODE_IN_HASH_LIST(pTblAccs, dataPos, lbInList);
            if ( lbInList )
            {

                /* Record the number of nodes in the list */
                pHashCtrl->usedSlotsInList = pHashCtrl->usedSlotsInList > 0 ?
                                    (pHashCtrl->usedSlotsInList - 1) : 0;

                ListDelNode(dataPos, pTblAccs->pHashList, pTblAccs);
            }
        }

        /* If the default timestamp list is enabled, put it into the list */
        if ( pTblAccs->CmnHashTblAccsT_bHasTimeList )
        {
            ListDelNode(dataPos, pTblAccs->pDfltTimeList, pTblAccs);
        }
    }


    /* Mark and thus to delete this element */
    (*pDelVal) = HASH_TBL_DEL_KEY;

    /* Re-write to change the key. Here, it has the operation on 2 8-byte
        position, we change the data first, so in worst situation, a break
        of 2 operations, it may lead to
            1. data changed, but delete status is not set. this slot is
                thus wasted
            2. data changed, and then matched with another data, false pre-
                existence judgement

        Therefore, the optimized choice is to reset the status 8-byte first
        and sacrificing an additional judgement after OAHashSearch
    */
    memset(pKeyFrstB, 0xFF, pTblAccs->CmnHashTblAccsT_keySize);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashDeleteData */

ResCodeT CmnHashReadDataByPos(CmnHashHndlT hashHndl,
                                uint32 dataPos,
                                void * pData)
{
    BEGIN_FUNCTION("CmnHashReadDataByPos");
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST( pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    /* Validate the write position is not beyond the hash table range */
    IS_VALID_NODE_POS(dataPos, pTblAccs);


    HashTblReadData(dataPos, &pTblAccs->oaHash, pData,
                        pTblAccs->CmnHashTblAccsT_recSize);


    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashReadDataByPos */



ResCodeT CmnHashReadDataAddrByPos(CmnHashHndlT hashHndl,
                                uint32 dataPos,
                                void * * ppData)
{
    BEGIN_FUNCTION("CmnHashReadDataAddrByPos");
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST( ppData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    /* Validate the write position is not beyond the hash table range */
    IS_VALID_NODE_POS(dataPos, pTblAccs);

    HashTblReadDataAddr(dataPos, &pTblAccs->oaHash, ppData,
                        pTblAccs->CmnHashTblAccsT_recSize);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashReadDataAddrByPos */


ResCodeT CmnHashCheckDataExt(CmnHashHndlT hashHndl,

                                const void * pKey,

                                BOOL *pExist,
                                uint32 * pDataPos,
                                void * * ppData)
{
    BEGIN_FUNCTION("CmnHashCheckDataExt");
    ResCodeT                rc = NO_ERR;

    uint32           hashIdx = 0;
    uint32           searchCnt = 0;
    uint32           findCnt = 0;
    int32                    foundFlag = 0;
    OAHashTableT *         pOAHashTable = NULL;
    HashTableCtrlT *       pHashCtrl = NULL;
    pCmnHashTblAccsT        pTblAccs = NULL;

    int64                 dataOffset = 0;

    uint64 *              pStts = NULL;


    ASST( pKey && pExist && pDataPos );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    *pExist = FALSE;

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;
    pHashCtrl = pTblAccs->pHashCtrl;

    /*-------------------    Standard OaHash search opt    -------------------*/
    rc = OAHashTableSearchExt(pOAHashTable,
                pKey,
                (uint32 *)&hashIdx,
                &foundFlag,
                TRUE,
                FALSE,
                &searchCnt,
                &findCnt,
                -1,
                pOAHashTable->keySize,
                pOAHashTable->keyOffset);

    UPD_HASH_STTS(pHashCtrl, searchCnt, findCnt);


    RAISE_ERR(rc, RTN);


    /* If found, return the position */
    if ( foundFlag )
    {

        dataOffset = hashIdx * pOAHashTable->recSize;
        pStts = (uint64 *)ADDRESS_ADD_OFFSET(pOAHashTable->pTableRoot,dataOffset);      
        
        //SHIFT_TO_STATUS(pOAHashTable->pTableRoot, dataOffset, pStts);
        /* There is a case the data status is reset, but the key is not
            yet changed, e.g. due to process failure. Hereby, we catch
            this exception and regard as a new found */
        if ( !( IS_AN_DELETED_HASH_KEY(pStts) ) )
        {
            *pExist = TRUE;
            if ( ppData )
            {
                /* If a read pointer is available, point to the data */
                HashTblReadDataAddr(hashIdx, pOAHashTable, ppData,
                                pTblAccs->CmnHashTblAccsT_recSize);
            }
        }

    }
    else
    {
        /* If not found but the table is full, need to raise error */
        if ( pHashCtrl->usedSlots >= pHashCtrl->fullThreshold )
        {
            /* If consider a new error code here to distinguish? */
            SET_RESCODE( ERR_CMN_HASH_LIST_FULL );
        }
    }

    /* Ha, here is the hash table position */
    *pDataPos = hashIdx;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashCheckDataExt */


ResCodeT CmnHashRemoveFromList(CmnHashHndlT hashHndl,
                                void * pKey)
{
    BEGIN_FUNCTION("CmnHashRemoveFromList");
    ResCodeT                rc = NO_ERR;
    uint32           hashIdx = 0;
    BOOL                    lbExist = FALSE;
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST( pKey );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);

    /* Search for the data position of the given key */
    rc = CmnHashCheckData(hashHndl, pKey, &lbExist,&hashIdx, NULL);

    if ( ERR_CMN_HASH_LIST_FULL == rc )
    {
        THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    }

    RAISE_ERR(rc, RTN);

    if ( !lbExist )
    {
        /* If try deleting a non-existing node, raise error here 1*/
        RAISE_ERR_PARM(ERR_CMN_HASH_LIST_NODE_NOT_EXIST, RTN, hashIdx);
    }

    /* If list function is not enabled, raise error to caller as well */
    if ( pTblAccs->CmnHashTblAccsT_bHasList )
    {
        lbExist = FALSE;
        /* Only perform the deletion to a valid node */
        IS_NODE_IN_HASH_LIST(pTblAccs, hashIdx, lbExist);
        if ( lbExist )
        {
            ListDelNode(hashIdx, pTblAccs->pHashList, pTblAccs);
        }
    }
    else
    {
        RAISE_ERR_PARM(ERCD_CMN_HASH_LIST_NOT_SUPPORT, RTN,
                    pTblAccs->CmnHashTblAccsT_shmName);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashRemoveFromList */

ResCodeT CmnHashCheckData(CmnHashHndlT hashHndl,

                                const void * pKey,

                                BOOL *pExist,
                                uint32 * pDataPos,
                                void * pData)
{
    BEGIN_FUNCTION("CmnHashCheckData");
    ResCodeT                rc = NO_ERR;

    uint32           hashIdx = 0;
    uint32           searchCnt = 0;
    uint32           findCnt = 0;
    int32                    foundFlag = 0;
    OAHashTableT *         pOAHashTable = NULL;
    HashTableCtrlT *       pHashCtrl = NULL;
    pCmnHashTblAccsT        pTblAccs = NULL;

    int64                 dataOffset = 0;

    uint64 *              pStts = NULL;


    ASST( pKey && pExist && pDataPos );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    *pExist = FALSE;

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;
    pHashCtrl = pTblAccs->pHashCtrl;

    /*-------------------    Standard OaHash search opt    -------------------*/
    rc = OAHashTableSearchExt(pOAHashTable,
                pKey,
                (uint32 *)&hashIdx,
                &foundFlag,
                TRUE,
                FALSE,
                &searchCnt,
                &findCnt,
                -1,
                pOAHashTable->keySize,
                pOAHashTable->keyOffset);

    UPD_HASH_STTS(pHashCtrl, searchCnt, findCnt);


    RAISE_ERR(rc, RTN);


    /* If found, return the position */
    if ( foundFlag )
    {

        dataOffset = hashIdx * pOAHashTable->recSize;
        pStts = (uint64 *)ADDRESS_ADD_OFFSET(pOAHashTable->pTableRoot,dataOffset);      
        //SHIFT_TO_STATUS(pOAHashTable->pTableRoot, dataOffset, pStts);
        /* There is a case the data status is reset, but the key is not
            yet changed, e.g. due to process failure. Hereby, we catch
            this exception and regard as a new found */
        if ( !( IS_AN_DELETED_HASH_KEY(pStts) ) )
        {
            *pExist = TRUE;
            if ( pData )
            {
                /* If a read buffer is available, return the data */
                HashTblReadData(hashIdx, pOAHashTable, pData,
                                pTblAccs->CmnHashTblAccsT_recSize);
            }
        }

    }
    else
    {
        /* If not found but the table is full, need to raise error */
        if ( pHashCtrl->usedSlots >= pHashCtrl->fullThreshold )
        {
            /* If consider a new error code here to distinguish? */
            SET_RESCODE( ERR_CMN_HASH_LIST_FULL );
        }
    }

    /* Ha, here is the hash table position */
    *pDataPos = hashIdx;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashCheckData */



static ResCodeT IntlGlbCtrlParaInitial()
{
    BEGIN_FUNCTION("IntlGlbCtrlParaInitial");
    ASST( TRUE );

    /* Prevent the re-initialization of the library */
    if ( gbInitial )
    {
        THROW_RESCODE(NO_ERR);
    }

    memset( gShmHashAccs, 0x00,
            sizeof(CmnHashTblAccsT) * (MAX_CMN_HASH_HNDL + 1) );

    gCurHashHndl = 0;


    /* By readching here we complete the initializing */
    gbInitial = TRUE;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of IntlGlbCtrlParaInitial */


ResCodeT CmnHashResetTbl(CmnHashHndlT hashHndl)
{
    BEGIN_FUNCTION("CmnHashResetTbl");
    pCmnHashTblAccsT        pTblAccs = NULL;
    HashTableCtrlT *       pHashCtrl = NULL;
    int64                 tblSize = 0;
    int64                 listSize = 0;
    ASST( TRUE );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pHashCtrl = pTblAccs->pHashCtrl;

    /*  Get the memory size information from shm */
    GET_HASH_TABLE_SIZE(pTblAccs, tblSize);
    GET_HASH_LIST_SIZE(pTblAccs, listSize);

    /* Reset the data area accordingly, list section is always an option */
    memset( pTblAccs->oaHash.pTableRoot, 0xFF, tblSize );
    if ( pTblAccs->pHashList && listSize )
    {
        memset( pTblAccs->pHashList, 0xFF, listSize );
    }

    if ( pTblAccs->pDfltTimeList && listSize )
    {
        memset( pTblAccs->pDfltTimeList, 0xFF, listSize );
    }

    /* Lastly, need to reset the volume control count to zero */
    pHashCtrl->usedSlots = 0;

    pHashCtrl->peakSlotsInList  = 0;
    pHashCtrl->usedSlotsInList  = 0;
    pHashCtrl->peakSlots        = 0;


    SET_RESCODE(NO_ERR);
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashResetTbl */


static void ListAddNode(uint32 nodePos,
                                HashTableListT * pHashList,
                                pCmnHashTblAccsT pHashTblAccs)
{
    BEGIN_FUNCTION("ListAddNode");
    uint32           tail = 0;
    listCmnNodeT *         pTailNode = NULL;
    listCmnNodeT *         pCurrNode = NULL;
    ASST( pHashTblAccs && pHashList );

    /* Validate the position is within range */
    IS_VALID_NODE_POS(nodePos, pHashTblAccs);

    pCurrNode = &pHashList->listData[nodePos];

    /* If this is the first node to add, point it to the head and tail */
    if ( pHashList->listCtrl.head == CMN_LIST_NULL_NODE ||
        pHashList->listCtrl.tail == CMN_LIST_NULL_NODE )
    {
        pCurrNode->validFlg = CMN_LIST_VALID_NODE;

        pHashList->listCtrl.head = nodePos;
        pHashList->listCtrl.tail = nodePos;
    }
    else
    {
        /* Here, we are trying to add a node to the tail of the list,
           firstly, need to verify if it is already added */
        if ( pCurrNode->validFlg != CMN_LIST_DELETE_NODE )
        {
            //RAISE_ERR_PARM(ERR_CMN_HASH_LIST_NODE_EXISTED, RTN, nodePos);
            THROW_RESCODE(ERR_CMN_HASH_LIST_NODE_EXISTED);
        }
        tail = pHashList->listCtrl.tail;
        pTailNode = &pHashList->listData[tail];

        /* Add the new node to the tail node and then link it to the tail */
        pCurrNode->prev = tail;
        pCurrNode->next = CMN_LIST_NULL_NODE;

        pTailNode->next = nodePos;

        /* Lastly, set this node to valid and update the global tail */
        pCurrNode->validFlg = CMN_LIST_VALID_NODE;
        pHashList->listCtrl.tail = nodePos;
    }

    EXIT_BLOCK();
} /* End of ListAddNode */



static void ListDelNode(uint32 nodePos,
                                HashTableListT * pHashList,
                                pCmnHashTblAccsT pHashTblAccs)
{
    BEGIN_FUNCTION("ListDelNode");
    uint32           prevNode = 0;
    uint32           nextNode = 0;
    listCmnNodeT *         pPrevNode = NULL;
    listCmnNodeT *         pNextNode = NULL;
    listCmnNodeT *         pCurrNode = NULL;
    ASST( pHashTblAccs && pHashTblAccs->CmnHashTblAccsT_bHasList );

    /* Validate the position is within range */
    IS_VALID_NODE_POS(nodePos, pHashTblAccs);

    pCurrNode = &pHashList->listData[nodePos];

    if ( pHashList->listCtrl.head == CMN_LIST_NULL_NODE ||
        pHashList->listCtrl.tail == CMN_LIST_NULL_NODE )
    {
        /* Empty list, then nothing to do */
        THROW_RESCODE(NO_ERR);
    }
    else
    {
        /* Point to the node in front and behind the one to delete */
        prevNode = pCurrNode->prev;
        nextNode = pCurrNode->next;

        /* Delete the head, update the head to the next node */
        if ( pHashList->listCtrl.head == nodePos &&
            pHashList->listCtrl.tail == nodePos )
        {
            pCurrNode->validFlg = CMN_LIST_DELETE_NODE;
            pHashList->listCtrl.head = CMN_LIST_NULL_NODE;
            pHashList->listCtrl.tail = CMN_LIST_NULL_NODE;
        }
        else if ( pHashList->listCtrl.head == nodePos )
        {
            pNextNode = &pHashList->listData[nextNode];

            pCurrNode->validFlg = CMN_LIST_DELETE_NODE;
            pHashList->listCtrl.head = nextNode;
            pNextNode->prev = CMN_LIST_NULL_NODE;
        }
        /* Delete the tail, update the tail to the previous node */
        else if ( pHashList->listCtrl.tail == nodePos )
        {
            pPrevNode = &pHashList->listData[prevNode];

            pCurrNode->validFlg = CMN_LIST_DELETE_NODE;
            pHashList->listCtrl.tail = prevNode;
            pPrevNode->next = CMN_LIST_NULL_NODE;
        }
        /* Delete a node in middle, need to verify this is an existing node */
        else if ( prevNode != CMN_LIST_NULL_NODE &&
                nextNode != CMN_LIST_NULL_NODE &&
                pCurrNode->validFlg == CMN_LIST_VALID_NODE )
        {
            /* Link the previous and next nodes directly */
            pNextNode = &pHashList->listData[nextNode];
            pPrevNode = &pHashList->listData[prevNode];

            /* Only mark the node as deleted, do not change other data fields */
            pCurrNode->validFlg = CMN_LIST_DELETE_NODE;
            pPrevNode->next = nextNode;
            pNextNode->prev = prevNode;
        }
        else
        {
            /* Other condition is regarded as an error */
            RAISE_ERR_PARM(ERR_CMN_HASH_LIST_NODE_NOT_EXIST, RTN, nodePos);
        }
    }

    EXIT_BLOCK();
} /* End of ListDelNode */


ResCodeT CmnHashIterData(CmnHashHndlT hashHndl,
                                uint32 * pDataPos,
                                void * pData)
{
    BEGIN_FUNCTION("CmnHashIterData");
    uint32          curPos = 0;
    static uint32    lstIterPos[MAX_CMN_HASH_HNDL] = {CMN_LIST_NULL_NODE};
    pCmnHashTblAccsT        pTblAccs = NULL;
    OAHashTableT *         pOAHashTable = NULL;
    ASST( pDataPos && pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;

    /* Only usable, if the list function is enabled */
    if ( !pTblAccs->CmnHashTblAccsT_bHasList )
    {
        RAISE_ERR_PARM(ERCD_CMN_HASH_LIST_NOT_SUPPORT, RTN,
                    pTblAccs->CmnHashTblAccsT_shmName);
    }

    curPos = CMN_LIST_NULL_NODE;
    ListIterateData(pTblAccs->pHashList, lstIterPos[hashHndl], pDataPos, &curPos);

    /* As int32 as we read a valid position, read the data and return */
    if ( curPos != CMN_LIST_NULL_NODE )
    {

        HashTblReadData(curPos, pOAHashTable, pData,
                            pTblAccs->CmnHashTblAccsT_recSize);

    }

    /* Log the last iteration position */
    lstIterPos[hashHndl] = curPos;
    (*pDataPos) = curPos;

    SET_RESCODE(NO_ERR);
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashIterData */


ResCodeT CmnHashIterDataExt(CmnHashHndlT hashHndl,
                                uint32 * pDataPos,
                                void ** ppData)
{
    BEGIN_FUNCTION("CmnHashIterData");
    uint32           curPos = 0;
    static uint32    lstIterPos[MAX_CMN_HASH_HNDL] = {CMN_LIST_NULL_NODE};
    pCmnHashTblAccsT        pTblAccs = NULL;
    OAHashTableT *         pOAHashTable = NULL;
    ASST( pDataPos && pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;

    /* Only usable, if the list function is enabled */
    if ( !pTblAccs->CmnHashTblAccsT_bHasList )
    {
        RAISE_ERR_PARM(ERCD_CMN_HASH_LIST_NOT_SUPPORT, RTN,
                    pTblAccs->CmnHashTblAccsT_shmName);
    }

    curPos = CMN_LIST_NULL_NODE;
    ListIterateData(pTblAccs->pHashList, lstIterPos[hashHndl], pDataPos, &curPos);

    /* As int32 as we read a valid position, read the data and return */
    if ( curPos != CMN_LIST_NULL_NODE )
    {
        HashTblReadDataAddr(curPos, pOAHashTable, ppData,
                        pTblAccs->CmnHashTblAccsT_recSize);

    }

    /* Log the last iteration position */
    lstIterPos[hashHndl] = curPos;
    (*pDataPos) = curPos;

    SET_RESCODE(NO_ERR);
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashIterData */


ResCodeT CmnHashIterDataOnTimeList(CmnHashHndlT hashHndl,
                                uint32 * pDataPos,
                                void * pData)
{
    BEGIN_FUNCTION("CmnHashIterDataOnTimeList");
    uint32           curPos = 0;
    static uint32    lstIterPos = CMN_LIST_NULL_NODE;
    pCmnHashTblAccsT        pTblAccs = NULL;
    OAHashTableT *         pOAHashTable = NULL;
    ASST( pDataPos && pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;

    /* Only usable, if the list function is enabled */
    if ( !pTblAccs->CmnHashTblAccsT_bHasTimeList )
    {
        RAISE_ERR_PARM(ERCD_CMN_HASH_LIST_NOT_SUPPORT, RTN,
                    pTblAccs->CmnHashTblAccsT_shmName);
    }

    curPos = CMN_LIST_NULL_NODE;
    ListIterateData(pTblAccs->pDfltTimeList, lstIterPos, pDataPos, &curPos);

    /* As int32 as we read a valid position, read the data and return */
    if ( curPos != CMN_LIST_NULL_NODE )
    {

        HashTblReadData(curPos, pOAHashTable, pData,
                            pTblAccs->CmnHashTblAccsT_recSize);

    }

    /* Log the last iteration position */
    lstIterPos = curPos;
    (*pDataPos) = curPos;

   
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashIterDataOnTimeList */


static void ListIterateData(HashTableListT * pHashList,
                                uint32 lstIterPos,
                                uint32 * pDataPos,
                                uint32 * pCurrPos)
{
    BEGIN_FUNCTION("ListIterateData");
    uint32           curPos = 0;
    uint32           tmpPos = 0;
    listCmnNodeT *         pCurrNode = NULL;


    ASST( pHashList && pDataPos && pCurrPos );



    (*pCurrPos) = CMN_LIST_NULL_NODE;

    /* If we read the input has this reset-2-start info, we iterate from
       the beginning */
    if ( (*pDataPos) == CMN_HASH_ITER_START )
    {
        lstIterPos = CMN_LIST_NULL_NODE;
    }

    /* If the last iteration point is NULL, we start from the beginning */

    tmpPos = lstIterPos == CMN_LIST_NULL_NODE ?
                pHashList->listCtrl.head : lstIterPos;
    if ( tmpPos == CMN_LIST_NULL_NODE )
    {
        curPos = tmpPos;
        THROW_RESCODE( NO_ERR );
    }

    pCurrNode = &pHashList->listData[tmpPos];

    if ( lstIterPos == CMN_LIST_NULL_NODE &&
        pCurrNode->validFlg == CMN_LIST_VALID_NODE )
    {
        curPos = tmpPos;
    }
    else
    {
        curPos = CMN_LIST_NULL_NODE;

        /* Iterate to the first valid node from list */
        do
        {
            tmpPos = pCurrNode->next;
            if ( tmpPos == CMN_LIST_NULL_NODE ) { break; }
            pCurrNode = &pHashList->listData[tmpPos];
        } while ( pCurrNode->validFlg != CMN_LIST_VALID_NODE );

        curPos = tmpPos;
    }


    EXIT_BLOCK();

    /* Return the */
    (*pCurrPos) = curPos;
   
    return;

} /* End of ListIterateData */


ResCodeT CmnHashIterDataOnTimeListExt(CmnHashHndlT hashHndl, BOOL resetFlg,
                                uint32 * pDataPos,
                                void * pData)
{
    BEGIN_FUNCTION("CmnHashIterDataOnTimeList");
    uint32           curPos = 0;
    static uint32    lstIterPos = CMN_LIST_NULL_NODE;
    pCmnHashTblAccsT        pTblAccs = NULL;
    OAHashTableT *         pOAHashTable = NULL;
    ASST( pDataPos && pData );

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;

    if (resetFlg)
    {
        lstIterPos = CMN_LIST_NULL_NODE;
        THROW_RESCODE(NO_ERR);
    }

    /* Validate the position is not beyond the hash table range */
    if (*pDataPos != CMN_LIST_NULL_NODE)
    {
        IS_VALID_NODE_POS(*pDataPos, pTblAccs);
    }

    /* Only usable, if the list function is enabled */
    if ( !pTblAccs->CmnHashTblAccsT_bHasTimeList )
    {
        RAISE_ERR_PARM(ERCD_CMN_HASH_LIST_NOT_SUPPORT, RTN,
                    pTblAccs->CmnHashTblAccsT_shmName);
    }

    curPos = CMN_LIST_NULL_NODE;
    ListIterateDataExt(pTblAccs->pDfltTimeList, lstIterPos, pDataPos, &curPos);

    /* As int32 as we read a valid position, read the data and return */
    if ( curPos != CMN_LIST_NULL_NODE )
    {

        HashTblReadData(curPos, pOAHashTable, pData,
                            pTblAccs->CmnHashTblAccsT_recSize);

    }

    /* Log the last iteration position */
    lstIterPos = curPos;
    (*pDataPos) = curPos;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashIterDataOnTimeListExt */

static void ListIterateDataExt(HashTableListT * pHashList,
                                uint32 lstIterPos,
                                uint32 * pDataPos,
                                uint32 * pCurrPos)
{
    BEGIN_FUNCTION("ListIterateData");
    uint32           curPos = 0;
    uint32           tmpPos = 0;
    listCmnNodeT *         pCurrNode = NULL;


    ASST( pHashList && pDataPos && pCurrPos );



    (*pCurrPos) = CMN_LIST_NULL_NODE;

    /* If we read the input has this reset-2-start info, we iterate from
       the beginning */
    if ( (*pDataPos) == CMN_HASH_ITER_START )
    {
        lstIterPos = CMN_LIST_NULL_NODE;
    }

    /* If the last iteration point is NULL, we start from the beginning */

    tmpPos = *pDataPos == CMN_LIST_NULL_NODE ?
                pHashList->listCtrl.head : *pDataPos;
    if ( tmpPos == CMN_LIST_NULL_NODE )
    {
        curPos = tmpPos;
        THROW_RESCODE( NO_ERR );
    }

    pCurrNode = &pHashList->listData[tmpPos];

    if ( lstIterPos == CMN_LIST_NULL_NODE &&
        pCurrNode->validFlg == CMN_LIST_VALID_NODE )
    {
        curPos = tmpPos;
    }
    else
    {
        curPos = CMN_LIST_NULL_NODE;

        /* Iterate to the first valid node from list */
        do
        {
            tmpPos = pCurrNode->next;
            if ( tmpPos == CMN_LIST_NULL_NODE )
            {
                break;
            }
            pCurrNode = &pHashList->listData[tmpPos];
        } while ( pCurrNode->validFlg != CMN_LIST_VALID_NODE );

        curPos = tmpPos;
    }


    EXIT_BLOCK();
    /* Return the */
    (*pCurrPos) = curPos;
    return;

} /* End of ListIterateDataExt */
/*______________________________________________________________________________
 *******************************************************************************
 * Function: CmnHashTblGetMemSize
 * ----------------------------------------------------------------------------
 * Description: Get the total memory size
 *
 ******************************************************************************/
ResCodeT CmnHashTblGetMemSize(CmnHashHndlT hHashHndl, int64 * pMemSize)
{
    BEGIN_FUNCTION("CmnHashTblGetMemSize");
    ASST( pMemSize );

    IS_VALID_HASH_HNDL(hHashHndl);
    (*pMemSize) = gShmHashAccs[hHashHndl].pHashInfo->memSize;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblGetMemSize */

ResCodeT CmnHashDumpMem( char * shmName, char * pDumpFileName )
{
    BEGIN_FUNCTION("CmnHashDumpMem(");
    ResCodeT        rc = NO_ERR;
    void *        pRoot = NULL;
    CmnHashHndlT    hashHndl = NULL_CMN_HASH_HNDL;
    int64         memSize = 0;

    ASST( TRUE );

    rc = CmnHashTblAttach( shmName, &pRoot, &hashHndl );
    RAISE_ERR( rc, RTN );

    rc = CmnHashTblGetMemSize(hashHndl, &memSize);
    RAISE_ERR( rc, RTN );

//    rc = DLLibDumpToFile(pDumpFileName, &pRoot, memSize);
//    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT CmnHashTblMap2PrcMem(void *pMemRt,
                                int64 prcMemSize,
                                HashTableRecInfoT recInfo,
                                BOOL bNeedList,
                                BOOL bTimeList,
                                pCmnHashHndlT pHashHndl)
{
    BEGIN_FUNCTION("CmnHashTblMap2PrcMem");
    int64                 memSize = 0;
    int64                 elememtSize = 0;
    int64                 listSize = 0;
    int64                 hashTblCnt = 0;
    CmnHashHndlT            iHashHndl = NULL_CMN_HASH_HNDL;
    pCmnHashTblAccsT        pTblAccs = NULL;
    ASST ( pMemRt && pHashHndl );

    if ( !gbInitial )
    {
        /* Not an actual initializatio call, but for global parameters */
        RAISE_ERR(IntlGlbCtrlParaInitial(), RTN);
    }

    recInfo.bNeedTimeList = bTimeList;

    /* Calculate the hash table total element count and then get shm size */
    hashTblCnt = GetDfltHashMemSize(recInfo.recCnt);
    listSize = 0;
    if ( bNeedList )
    {
        /* If list funciton is enabled, extra space is needed */
        listSize += hashTblCnt * sizeof(listCmnNodeT) + sizeof(listCmnHeadT);
    }
    if ( recInfo.bNeedTimeList )
    {
        listSize += hashTblCnt * sizeof(listCmnNodeT) + sizeof(listCmnHeadT);
    }

    /* Each elelment consists of the aligned user data length and a 8-byte
       status field */
    elememtSize = ELEM_SIZE_ALIGN( recInfo.recSize ) + sizeof(int64);
    memSize = hashTblCnt * elememtSize +
                sizeof(HashTableInfoT) +
                sizeof(HashTableCtrlT) +
                listSize;
    /* Validate the required size does not exceed the available memory */
    if ( memSize > prcMemSize )
    {
        RAISE_ERR(ERCD_ARCH_MALLOC_ERR, RTN);
    }

    /*-------------------    Create the shm section here   -------------------*/
    memset(pMemRt, 0xFF, memSize);



    /*-------------------    Prepare internal control hndl -------------------*/
    /* Get the next hash table handle */
    GET_NEXT_HNDL(iHashHndl);
    pTblAccs = (pCmnHashTblAccsT)&gShmHashAccs[iHashHndl];

    /* ### Map the shared memory to access structure ### */
    ShmMap2CmnHashTbl(pMemRt, pTblAccs);

    /* Then, update the hash table info to the shared memory */
    pTblAccs->CmnHashTblAccsT_recSize   = recInfo.recSize;
    pTblAccs->CmnHashTblAccsT_keyOffset = recInfo.keyOffset;
    pTblAccs->CmnHashTblAccsT_keySize   = recInfo.keySize;
    pTblAccs->CmnHashTblAccsT_recCnt    = recInfo.recCnt;

    pTblAccs->CmnHashTblAccsT_OArecSize     =
                        ELEM_SIZE_ALIGN( recInfo.recSize ) + sizeof(int64);
    pTblAccs->CmnHashTblAccsT_OAkeyOffset   =
                        sizeof(int64) + recInfo.keyOffset;
    pTblAccs->CmnHashTblAccsT_OAkeySize     = recInfo.keySize;
    pTblAccs->CmnHashTblAccsT_OArecCnt      = recInfo.recCnt;

    pTblAccs->CmnHashTblAccsT_memSize       = memSize;
    pTblAccs->CmnHashTblAccsT_fullThreshold = recInfo.recCnt;
    pTblAccs->CmnHashTblAccsT_cntSlots      = hashTblCnt;
    pTblAccs->CmnHashTblAccsT_bHasList      = bNeedList;
    pTblAccs->CmnHashTblAccsT_bHasTimeList  = recInfo.bNeedTimeList;


    /* Also log the shm name into the control struction for better
       error informaiton output */
    memset(pTblAccs->CmnHashTblAccsT_shmName, 0x00, SHM_NAME_LEN);
    memcpy(pTblAccs->CmnHashTblAccsT_shmName, PROCESS_MEMORY_TAG,
            strlen(PROCESS_MEMORY_TAG));

    /* Initial the control area */

    pTblAccs->CmnHash_Ctrl_peakSlotsInList  = 0;
    pTblAccs->CmnHash_Ctrl_usedSlotsInList  = 0;
    pTblAccs->CmnHash_Ctrl_peakSlots        = 0;

    pTblAccs->CmnHash_Ctrl_usedSlots        = 0;
    pTblAccs->CmnHash_Ctrl_fullThreshold    = recInfo.recCnt;

    /* ### Fill data to the OaHash structure ### */
    ShmInitOaHashObject(pTblAccs);


    /*-------------------    Return the output info        -------------------*/
    /* Return the shm pointer and the hash handle */
    (*pHashHndl) = iHashHndl;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashTblCreate */

ResCodeT CommHashSubDel(SubNodeT* pPre, uint32 prePos, SubNodeT* pNxt, uint32 nxtPos, MstrHdrT* pMstr)
{
    BEGIN_FUNCTION("CommHashSubDel");

    //the delete node is the last one
    if (pNxt == NULL)
    {
        pPre->nxtPos = -1;
        
        pMstr->lstPos = prePos;
    }
    
    //the delete node is the first one 
    if (pPre == NULL)
    {
        pNxt->prePos = -1;
        
        pMstr->frstPos = nxtPos;
    }

    if ( (pNxt != NULL) &&  (pPre != NULL) )
    {
        pPre->nxtPos = nxtPos;
        pNxt->prePos = prePos;
    }
    
    //CmnHashDeleteData(pos);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CommHashSubAdd(SubNodeT* pAdd, uint32 addPos, SubNodeT* pLast, uint32 lastPos, MstrHdrT* pMstr)
{
    BEGIN_FUNCTION("CommHashSubAdd");

    //the add node is the first one
    if (pLast == NULL)
    {
        pAdd->nxtPos = -1;
        pAdd->prePos = -1;
        
        pMstr->frstPos = addPos;
        pMstr->lstPos = addPos;
    }else
    { 
        pLast->nxtPos = addPos;
    
        pAdd->prePos = lastPos;
        pAdd->nxtPos = -1;
        
        pMstr->lstPos = addPos;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CommHashAddFrNode(MstrHdrT* pHdr, uint32 curSubPos, SubNodeT* pCurSub, uint32 preSubPos, SubNodeT* pPreSub )
{
    BEGIN_FUNCTION("CommHashAddFrNode");

    pCurSub->prePos = -1;
    pCurSub->nxtPos = -1;

    if (pHdr->frstPos == -1)
    {
        pHdr->frstPos = curSubPos;
        pHdr->lstPos = curSubPos;
    }else
    {
        pCurSub->prePos = preSubPos;
        pHdr->lstPos = curSubPos;
        pPreSub->nxtPos = curSubPos;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CmnHashLstNxtData(CmnHashHndlT hashHndl,
                                uint32 * pCurPos,
                                uint32 * pNxtPos,
                                void * pNxtData)
{
    BEGIN_FUNCTION("CmnHashLstNxtData");
    uint32           curPos = 0;
    uint32    lstIterPos = CMN_LIST_NULL_NODE;
    pCmnHashTblAccsT        pTblAccs = NULL;
    OAHashTableT *         pOAHashTable = NULL;
    ASST( pCurPos && pNxtPos && pNxtData );

    lstIterPos = *pCurPos;

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pOAHashTable = &pTblAccs->oaHash;

    /* Only usable, if the list function is enabled */
    if ( !pTblAccs->CmnHashTblAccsT_bHasList )
    {
        RAISE_ERR_PARM(ERCD_CMN_HASH_LIST_NOT_SUPPORT, RTN,
                    pTblAccs->CmnHashTblAccsT_shmName);
    }

    curPos = CMN_LIST_NULL_NODE;
    ListIterateData(pTblAccs->pHashList, lstIterPos, pNxtPos, &curPos);

    /* As int32 as we read a valid position, read the data and return */
    if ( curPos != CMN_LIST_NULL_NODE )
    {

        HashTblReadData(curPos, pOAHashTable, pNxtData,
                            pTblAccs->CmnHashTblAccsT_recSize);

    }

    /* Log the last iteration position */
    (*pNxtPos) = curPos;

    SET_RESCODE(NO_ERR);
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashLstNxtData */

ResCodeT CmnHashGetUsedCnt( CmnHashHndlT hashHndl, int64 *pUsedCnt )
{
    BEGIN_FUNCTION("CmnHashGetUsedCnt");
    ResCodeT                rc = NO_ERR;
    HashTableCtrlT *       pHashCtrl = NULL;
    pCmnHashTblAccsT        pTblAccs = NULL;

    /* Validate the handle and then pointer to internal control structure */
    IS_VALID_HASH_HNDL(hashHndl);

    pTblAccs = (pCmnHashTblAccsT)GET_HASH_HNDL_PNT(hashHndl);
    pHashCtrl = pTblAccs->pHashCtrl;

    /* Return the used data count */
    *pUsedCnt = pHashCtrl->usedSlots;


    SET_RESCODE(NO_ERR);
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of CmnHashGetUsedCnt */