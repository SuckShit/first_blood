/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _MSG_COMMON_VALUE_
#define _MSG_COMMON_VALUE_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files */
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define MAX_RSP_ORDER_CNT   10
#define MAX_RSP_DEAL_CNT    10
#define MAX_RSP_USR_CNT     100

#define MAX_USR_NM_LENTH    32
#define MAX_USR_ID_LENTH    32
#define MAX_ORG_CD_LENTH    (21+1)
#define MAX_ORG_ID_LENTH    (16+1)
#define MAX_TOKEN_LENTH     (32+1)
#define MAX_MAKET_ID_LENTH  8

#define MAX_APIF_LENTH      8
#define MAX_OPRT_TP_LENTH   8
#define MAX_IP_LENTH        16
#define MAX_TIME_LENGTH     20
#define MARKET_X_SWAP       "X-Swap"
#define MAX_MSG_LENTH       100

#define MAX_BRDG_FLAG_LENGTH    4
#define MAX_BRDG_PRCNTG_LENGTH  4
#define MAX_BRDG_TIME_LENGTH    12
#define MAX_BRDG_FEE_LENGTH     8
#define MAX_CNTRCT_CD_LENGTH    56
#define MAX_QSC_SRNO_LENGTH     24

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

#endif /* _MSG_COMMON_VALUE_ */
