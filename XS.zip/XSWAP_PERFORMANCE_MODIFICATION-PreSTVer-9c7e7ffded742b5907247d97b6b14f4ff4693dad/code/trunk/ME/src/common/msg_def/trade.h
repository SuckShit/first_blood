/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _TRADE_T_
#define _TRADE_T_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define TRD_RES_TYP_COD_LEN             2
#define TRAN_TYP_COD_LEN                3
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct TradeS
{
    int64   tranIdNo;
    int32   prdctId;
    int32   trdSts;
    char    ordrPrtFilCod;
    char    filler[7];
    int64   tranDatTim;
    int64   ordrNo;
    int64   tradMtchPrc;
    int64   trdQty;
    int64   ordrExePrc;
    int64   ordrExeQty;
    int32   ordrMask;
} TradeT, *pTradeT;



typedef struct TradeKeyS
{
    int64   trdNo;
} TradeKeyT, *pTradeKeyT;

typedef struct TradeDatS
{
    TradeKeyT   trdKey;
    TradeT  bidTrd;
    TradeT  askTrd;
} TradeDatT, *pTradeDatT;

#endif /* _TRADE_T_ */
