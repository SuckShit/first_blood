/***
Created on Aug 09, 2017
@author: Xiaoping Zhou
@version $Id
***/

#ifndef _MSG_MARKET_INFO_UPDATE_
#define _MSG_MARKET_INFO_UPDATE_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MarketInfoUpdateReqS
{
    int32  intFuncId;      
    char   strToken[16];
    int32  intOpenClsId;        //市场状态标识
    int32  intIsExecute;        //是否要检查
    uint64 intMktStCfgId;       //市场状态变化消息ID

} MarketInfoUpdateReqT, *pMarketInfoUpdateReqT;

typedef struct MarketInfoUpdateRespS
{
    int32  intMktSt;                 //市场状态
    int32  intMktStIrs;              //市场状态
    int32  intMktStFlag;             //市场状态是否改变 1、改变 0 不改变
    int32  intMktStIrsFlag;          //IRS市场状态是否改变 1、改变 0 不改变
    //TC_WTPRCCUSOR                  //合约参考价
    //TC_ORGUSR                      //在线的用户及所在机构
    int64  intTrdNum;                //当前已成交笔数
    int64  intTrdCancelNum;          //当前已经撤销成交笔数
    char   strUpdTime[32];           //更新时间
    //TC_ORDINFOCURSOR               //变化的订单信息
    //TC_ORDINFOCURSOR               //变化的SIRS订单信息
    //TC_ORDINFOCURSOR               //变化的SBF订单信息
    //TC_ORDINFOCURSOR               //变化的SIRSCCP订单信息
    //TC_ORDINFOCURSOR               //变化的SBFCCP订单信息
    //TC_BRDGORDRCURSOR              //桥单Cursor
    //TC_SREFPRCCURSOR               //每日结算价 SIRS
    //TC_SREFPRCCURSOR               //每日结算价 SBF
    //TC_SREFPRCCURSOR               //每日结算价 SIRSCCP
    //TC_SREFPRCCURSOR               //每日结算价 SBFCCP
    uint64 intMaxOutBoundId;         //最大Imix消息号

} MarketInfoUpdateRespT, *pMarketInfoUpdateRespT;

#endif /* _MSG_MARKET_INFO_UPDATE_ */
