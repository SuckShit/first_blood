/***
Created on Sep 19, 2017
@author: xuetao.bai
@version $Id
***/

#ifndef _MSG_RISK_H_
#define _MSG_RISK_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */
#include "msg_common_value.h"
#include "usr_def_ref.h"
#include "common_macro.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_RISKCFCNT_COUNT     100

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/********** RiskInfo **********/
typedef struct RiskInfoCfcntS 
{
    int32           intRiskCfcnt;
    int32           iFiller;
    char            strCntrctNm[MAX_CNTRCT_NM];
    char            strFiller[FILL_6_LEN];
} RiskInfoCfcntT, *pRiskInfoCfcntT;

typedef struct RiskUpdateReqS 
{
    int32           iFuncId; 
    int32           iRiskCount;
    int64           timestamp;
    int32           iMarketId;                                       /* X-Swap */
    int32           iCleaningMthd;                                   /* 13 */
    char            strUsrIdHeader[MAX_USR_ID_LENTH];                /* �����û�ID��ʶ */
    char            strOrgIdHeader[MAX_ORG_ID_LENTH];                /* ���𷽻��� */
    char            strSecuriType[MAX_APIF_LENTH];                   /* IRS/SIRS/SBFWD */
    char            strUserId[MAX_USR_ID_LENTH];
    char            strToken[MAX_TOKEN_LENTH]; 
    char            strOrgId[MAX_ORG_ID_LENTH];
    RiskInfoCfcntT  riskCfcnt[MAX_RISKCFCNT_COUNT]; 
} RiskInfoReqT, *pRiskInfoReqT;

typedef struct RiskUpdateRespS 
{
    int32           intOrgId;
    int32           filler;
} RiskInfoRespT, *pRiskInfoRespT;

#endif /* _MSG_RISK_H_ */
