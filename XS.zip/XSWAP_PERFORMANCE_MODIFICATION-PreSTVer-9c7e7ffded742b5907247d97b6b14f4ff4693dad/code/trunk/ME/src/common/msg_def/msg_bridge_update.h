/***
Created on Aug 24, 2017
@author: Xiaoping Zhou
@version $Id
***/

#ifndef _MSG_BRIDGE_UPDATE_
#define _MSG_BRIDGE_UPDATE_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "intrnl_msg.h"
#include "msg_common_value.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/* 桥授信更新消息中能容纳的搭桥参数结构体的最大个数 */
#define BRIDGE_CREDIT_INFO_MAX_COUNT   \
        (MSG_BODY_LEN - 3*sizeof(int32) - MAX_USR_ID_LENTH - MAX_TOKEN_LENTH) / (sizeof(BrdgCreditUpdateInfoT))

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* 桥交易员设置 */
typedef struct BrdgDealerUpdateReqS
{
    int32 intFuncId;
    char strUserId[MAX_USR_ID_LENTH];
    char strToken[MAX_TOKEN_LENTH];
    int32 intBrdgPrvlgSt;                           // 是否开启 
    char strBrdgDealer[MAX_USR_ID_LENTH];           // 默认交易员 
} BrdgDealerUpdateReqT, *pBrdgDealerUpdateReqT;

typedef struct BrdgDealerUpdateRespS
{
    //TODO: OUT_BRDGORDRC            //搭桥订单信息
    uint64 intMaxOutBoundId;         //最大Imix消息号
} BrdgDealerUpdateRespT, *pBrdgDealerUpdateRespT;


/* 桥授信修改 */
typedef struct BrdgCreditModifyReqS
{
    int32 intFuncId;
    char strUserId[MAX_USR_ID_LENTH];
    char strToken[MAX_TOKEN_LENTH];
} BrdgCreditModifyReqT, *pBrdgCreditModifyReqT;

typedef struct BrdgCreditModifyRespS
{
    //TODO: OUT_BRDGORDRC            //搭桥订单信息
    uint64 intMaxOutBoundId;         //最大Imix消息号
} BrdgCreditModifyRespT, *pBrdgCreditModifyRespT;


/* 桥授信更新 */
// typedef struct BrdgCreditUpdateReqS
// {
    // int32 intFuncId;
    // char strUserId[32];
    // char strToken[16];
    // int32 intOpOrgId;                // 对手方机构ID
    // int32 intCrdtRlf;                // 关系
    // char strBrdgFee[32];             // 桥费
    // int32 intTerm;                   // 期限
// } BrdgCreditUpdateReqT, *pBrdgCreditUpdateReqT;
typedef struct BrdgCreditUpdateInfoS
{
    int32 intOpOrgId;                       // 对手方机构ID
    short intCrdtRlf;                       // 关系
    char strBrdgFee[MAX_BRDG_FEE_LENGTH];   // 桥费 
    short intTerm;                          // 期限
} BrdgCreditUpdateInfoT, *pBrdgCreditUpdateInfoT;

typedef struct BrdgCreditUpdateReqS
{
    int32 intFuncId;
    char strUserId[MAX_USR_ID_LENTH];
    char strToken[MAX_TOKEN_LENTH];
    int32 intMdfyF;                  // 是否有修改
    
    BrdgCreditUpdateInfoT brdgCrdtInfo[BRIDGE_CREDIT_INFO_MAX_COUNT];
    int32 intInfoCount;              // brdgCrdtInfo的实际个数
} BrdgCreditUpdateReqT, *pBrdgCreditUpdateReqT;

// /* 桥授信解锁 */
// typedef struct BrdgCreditUnlockReqS
// {
    // int32 intFuncId;
    // char strUserId[32];
    // char strToken[16];
    // int32 intMdfyF;                  // 是否有修改 
// } BrdgCreditUnlockReqT, *pBrdgCreditUnlockReqT;

typedef struct BrdgCreditUpdateRespS
{
    //TODO: OUT_BRDGORDRC            //搭桥订单信息
    uint64 intMaxOutBoundId;         //最大Imix消息号
} BrdgCreditUpdateRespT, *pBrdgCreditUpdateRespT;


/* 桥百分比设置 */
typedef struct BrdgPercentageUpdateReqS
{
    int32 intFuncId;
    char strBrdgFlag[MAX_BRDG_FLAG_LENGTH];             // 搭桥标志位
    char strBrdgPercentage[MAX_BRDG_PRCNTG_LENGTH];     // 搭桥百分比
    char strBrdgReturn[MAX_BRDG_TIME_LENGTH];           // 搭桥返回时间限制
} BrdgPercentageUpdateReqT, *pBrdgPercentageUpdateReqT;

typedef struct BrdgPercentageUpdateRespS
{
    //TODO: OUT_BRDGORDRC            //桥单Cursor
    uint64 intMaxOutBoundId;         //最大Imix消息号
} BrdgPercentageUpdateRespT, *pBrdgPercentageUpdateRespT;

#endif /* _MSG_BRIDGE_UPDATE_ */
