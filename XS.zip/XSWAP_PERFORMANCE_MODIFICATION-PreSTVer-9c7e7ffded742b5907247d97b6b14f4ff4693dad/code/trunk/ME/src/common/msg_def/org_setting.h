/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _ORG_SETTING_
#define _ORG_SETTING_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "msg_common_value.h"
#include "order.h"
#include "user_order.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct PartyDetailsListReportReqS
{
    char            strUserId[MAX_USR_ID_LENTH];
    char            strToken[MAX_TOKEN_LENTH];
    char            strOrgId[MAX_ORG_ID_LENTH];
    int32           iFuncId;
    int16           rqstType;
} PartyDetailsListReportReqT, *pPartyDetailsListReportReqT;

typedef struct PartyDetailsListReportRspS
{
    NewOrderSingleRspT orderRsp; ;
} PartyDetailsListReportRspT, *pPartyDetailsListReportRspT;

typedef struct SecurityDefinitionReqS
{
    int32  iFuncId;                                                     /* 功能标识 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token */
    char   strOpOrgId[MAX_ORG_ID_LENTH];                                /* 被处理机构ID */

    int32  intPrvlgIRS;                                                 /* Irs市场权限 */
    int32  intPrvlgSIRS;                                                /* Sirs市场权限 */
    int32  intPrvlgSBF;                                                 /* Sbf市场权限 */
    int32  intPrvlgSIRSCCP;                                             /* Sirsccp市场权限 */
    int32  intPrvlgSBFCCP;                                              /* Sbfccp市场权限 */
} SecurityDefinitionReqT, *pSecurityDefinitionT;

typedef struct SecurityDefinitionRspS
{
//    int32  rspOrderCnt;
//    OrderInfoT  rspOrder[MAX_RSP_ORDER_CNT];
    NewOrderSingleRspT rspOrderCancel;                                  /* 冻结订单 */
    int32  errCode;                                                     /* 错误返回码 */
    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */
} SecurityDefinitionRspT, *pSecurityDefinitionRspT;


#endif /* _ORG_SETTING_ */
