/***
Created on OCT 13, 2017
@author: xuetao.bai
@version $Id
***/

#ifndef _MSG_SETLPRC_H_
#define _MSG_SETLPRC_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */
#include "msg_common_value.h"
#include "usr_def_ref.h"
#include "common_macro.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/********** SetlPrc **********/
typedef struct SetlPrcModifyReqS
{
    int64           stlPrice;
    int32           iFuncId; 
    char            strUserId[MAX_USR_ID_LENTH];
    char            strToken[MAX_TOKEN_LENTH];
    char            strCntrctNm[MAX_CNTRCT_NM];
    char            strPriceDate[MAX_TIME_LENGTH];
} SetlPrcModifyReqT, *pSetlPrcModifyReqT;


typedef struct SetlPrcModifyRspS
{
    int64           stlPrice;
    int32           iFuncId; 
    char            strUserId[MAX_USR_ID_LENTH];
    char            strToken[MAX_TOKEN_LENTH];
    char            strCntrctNm[MAX_CNTRCT_NM];
    char            strPriceDate[MAX_TIME_LENGTH];
} SetlPrcModifyRspT, *pSetlPrcModifyRspT;


#endif /* _MSG_SETLPRC_H_ */
