/***
Created on Oct 13, 2017
@author: XiaoPing.Zhou
@version $Id
***/

#ifndef _MSG_CREDIT_PSTN_SBFCCP_H_
#define _MSG_CREDIT_PSTN_SBFCCP_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */
#include "intrnl_msg.h"
#include "msg_common_value.h"
#include "user_order.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define FIGURES_OF_CREDIT_AMOUNT_SBFCCP            2         /* SBFCCP授信额度的小数位数 */ 

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* 合约转换比例 */
typedef struct SbfCcpCntrctCnvrtModifyReqS
{
    int32 intFuncId;
    char strUserId[MAX_USR_ID_LENTH];
    char strToken[MAX_TOKEN_LENTH];
    char strCntrctCd[MAX_CNTRCT_CD_LENGTH];        // 合约序号 
    uint64 intCnvrtRate;                           // 额度转换系数 
} SbfCcpCntrctCnvrtModifyReqT, *pSbfCcpCntrctCnvrtModifyReqT;



/* 场务限仓 */
typedef struct SbfCcpCrdtLimitByCwReqS
{
    int32 intFuncId;
    char strUserId[MAX_USR_ID_LENTH];
    char strToken[MAX_TOKEN_LENTH];
    uint32 intOrgId;
    int64 intCrdtAmnt;                           // 额度 
} SbfCcpCrdtLimitByCwReqT, *pSbfCcpCrdtLimitByCwReqT;

typedef struct SbfCcpCrdtLimitByCwRespS
{
    //TODO: out_NoteC            //通知用户列表
    // TODO: out_OrdInfoC        //冻结订单列表
    uint64 intMaxOutBoundId;         //最大Imix消息号
    char strHitMsg[MAX_MSG_LENTH];   //提示
} SbfCcpCrdtLimitByCwRespT, *pSbfCcpCrdtLimitByCwRespT;


/* CW端强平 */
typedef struct SbfCcpOrdrSubmitByCwReqS
{
    NewOrderSingleReqT  orderReq;
	int64               messageId;
} SbfCcpOrdrSubmitByCwReqT, *pSbfCcpOrdrSubmitByCwReqT;

typedef struct SbfCcpOrdrSubmitByCwRespS
{
    NewOrderSingleRspT  orderRsp;
    int64               forceId;
	int64               messageId;
	int64				effectTime;
    uint32              orgIdx;
	int32               filler;
} SbfCcpOrdrSubmitByCwRespT, *pSbfCcpOrdrSubmitByCwRespT;

/* CW端强平撤销 */
typedef struct SbfCcpOrdrCancelByCwReqS
{
    OrderCancelRequestReqT      orderCnclReq;
	int64               messageId;
	int64               forceId;
	int64               srcForceId;
	int64				tranTime;
} SbfCcpOrdrCancelByCwReqT, *pSbfCcpOrdrCancelByCwReqT;

typedef struct SbfCcpOrdrCancelByCwRespS
{
    NewOrderSingleRspT  orderRsp;
	int64               messageId;
	int64               srcForceId;
	int64				tranTime;
	uint32              orgIdx;
	int32               filler;
} SbfCcpOrdrCancelByCwRespT, *pSbfCcpOrdrCancelByCwRespT;


#endif /* _MSG_CREDIT_PSTN_SBFCCP_H_ */
