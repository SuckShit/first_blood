/***
Created on August 25, 2017
@author: dongwei.li
@version $Id
***/

#ifndef _MSG_CREDIT_H_
#define _MSG_CREDIT_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */
#include "msg_common_value.h"
#include "user_order.h"
#include "shch.pb.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define MAX_CREDITUPDATE_COUNT 100

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/********** CreditUpdate **********/
typedef struct CreditUpdateReqS {
    int32  iFuncId;                                                     /* 功能标识 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 授信机构标识 */
    int32  iCrdtMthd;                                                   /* 授信方式: 1 机构关系 0 授信额度授信 */

    int32  iCrdtCount;
    int32  iCrdtedOrgIdLst[MAX_CREDITUPDATE_COUNT];                     /* 被授信机构标识 */
    uint64 iIntlCrdtAmntLst[MAX_CREDITUPDATE_COUNT];                    /* 初始授信额度 */
    int32  iCrdtTermLst[MAX_CREDITUPDATE_COUNT];                        /* 最长期限(年) */
    int32  iCrdtRlfLst[MAX_CREDITUPDATE_COUNT];                         /* 授信关系标识 枚举: 0 无关系 1 有关系 */
} CreditUpdateReqT, *pCreditUpdateReqT;

typedef struct CreditUpdateRespS {
    int64  iMaxOutBoundId;                                              /* 最大Imix消息号 */
    int32  errCode;                                                     /* 错误返回码 */
    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */

    int32  iResult;                                                     /* 返回结果类型 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 授信机构标识 */
    char   strUpdTime[MAX_TIME_LENGTH];                                 /* 更新时间 */
} CreditUpdateRespT, *pCreditUpdateRespT;

/********** CreditUnlock **********/
typedef struct CreditUnlockReqS {
    int32  iFuncId;                                                     /* 功能标识 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 机构标识 */
    int32  iCheckOrg;                                                   /* 是否检查机构有效性 */
} CreditUnlockReqT, *pCreditUnlockReqT;

typedef struct CreditUnlockRespS {
//OUT_FREEZENOTEC OUT PCK_IRS_TYPE.TC_FREEZECURSOR, --冻结信息
//OUT_UPDTIME     OUT PCK_IRS_TYPE.T_TIME, --完成时间
//OUT_SIGNDESC    OUT PCK_IRS_TYPE.T_DESC, --提示内容
    int32  errCode;                                                     /* 错误返回码 */
    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */

    int32  iResult;                                                     /* 返回结果类型 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 授信机构标识 */
    char   strUpdTime[MAX_TIME_LENGTH];                                 /* 更新时间 */
} CreditUnlockRespT, *pCreditUnlockRespT;

/********** CreditRefreshMethodUpdate **********/
typedef struct CreditRefreshMethodUpdateReqS {
    int32  iFuncId;                                                     /* 功能标识 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 授信机构标识 */
    int32  iUpdMthd;                                                    /* 额度更新方式: 0 使用初始额度 1 使用剩余初始额度 */
} CreditRefreshMethodUpdateReqT, *pCreditRefreshMethodUpdateReqT;

typedef struct CreditRefreshMethodUpdateRespS {
    int64  iMaxOutBoundId;                                              /* 最大Imix消息号 */
    int32  errCode;                                                     /* 错误返回码 */
    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */
} CreditRefreshMethodUpdateRespT, *pCreditRefreshMethodUpdateRespT;

/********** CreditRiskModify **********/
typedef struct CreditRiskModifyReqS {
    int32  iFuncId;                                                     /* Function ID */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* UserID */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token  */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* OrgID  */
} CreditRiskModifyReqT, *pCreditRiskModifyReqT;

typedef struct CreditRiskModifyRespS {
//    FreezeNoteT*    pFreezeNoteT;                                     /* 冻结信息 */
    char   strFreezeTime[MAX_TIME_LENGTH];                              /* 冻结时间 */
//    OrdInfoT*        pOrdInfoT;                                       /* 订单状态更新信息 */
//    SIRSOrdInfoT*    pSIRSOrdInfoT;                                   /* SIRS订单状态更新信息 */
//    SBFOrdInfoT*    pSBFOrdInfoT;                                     /* SBF订单状态更新信息 */
//    ImpInfoT*        pImpInfoT;                                       /* 隐含订单信息 */
//    BrdgOrdrT*    pBrdgOrdrT;                                         /* 桥单Cursor */
    NewOrderSingleRspT orderRsp;                                        /* 冻结订单*/
//    int64  iMaxOutBoundId;                                              /* 最大Imix消息号 */
//    int32  errCode;                                                     /* 错误返回码 */
//    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 授信机构标识 */
    char   strUpdTime[MAX_TIME_LENGTH];                                 /* 更新时间 */
} CreditRiskModifyRespT, *pCreditRiskModifyRespT;

/********** ApiCreditUpdate **********/
typedef struct ApiCreditUpdateReqS {
    int32  iFuncId;                                                     /* 功能标识 */
    char   strUsrIdHeader[MAX_USR_ID_LENTH];                            /* 发起方用户ID标识 */
    char   strOrgIdHeader[MAX_ORG_ID_LENTH];                            /* 发起方机构 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token */
    char   strOrgId[MAX_ORG_ID_LENTH];                                  /* 授信机构标识 */
    char   strMarketId[MAX_MAKET_ID_LENTH];                             /* X-Swap */
    int32  iCrdtMthd;                                                   /* 授信方式: 1 机构关系 0 授信额度授信 */

    int32  iCrdtCount;
    int32  iCrdtedOrgIdLst[MAX_CREDITUPDATE_COUNT];                     /* 被授信机构标识 */
    uint64 iIntlCrdtAmntLst[MAX_CREDITUPDATE_COUNT];                    /* 初始授信额度 */
    int32  iCrdtTermLst[MAX_CREDITUPDATE_COUNT];                        /* 最长期限(年) */
    int32  iCrdtRlfLst[MAX_CREDITUPDATE_COUNT];                         /* 授信关系标识 枚举: 0 无关系 1 有关系 */
} ApiCreditUpdateReqT, *pApiCreditUpdateReqT;

typedef struct ApiCreditUpdateRespS {
    int64  iMaxOutBoundId;                                              /* 最大Imix消息号 */
    int32  errCode;                                                     /* 错误返回码 */
    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */
    NewOrderSingleRspT orderRsp;                                        /* 冻结订单*/
} ApiCreditUpdateRespT, *pApiCreditUpdateRespT;

/********** CCP Market Credit **********/
typedef struct CCPCreditUptReqS 
{ 
    int64           crdtAmnt;                     /* 额度 */
    int64           msgSrno;                      /* 全局指令编号 */
    int64           crdtLmtSrno;                  /* 限仓指令编号 */
    int32           iFuncId;                      /* 功能标识 */
    char            strOrgCd[MAX_ORG_CD_LENTH];   /* 机构唯一标识21位 */
} CCPCreditUptReqT, *pCCPCreditUptReqT;

typedef struct CCPCreditUptRspS 
{ 
    int64           msgSrno;                      /* 全局指令编号 */
    int64           crdtLmtSrno;                  /* 限仓指令编号 */
    int16           setId; 
} CCPCreditUptRspT, *pCCPCreditUptRspT;


#endif /* _MSG_CREDIT_H_ */
