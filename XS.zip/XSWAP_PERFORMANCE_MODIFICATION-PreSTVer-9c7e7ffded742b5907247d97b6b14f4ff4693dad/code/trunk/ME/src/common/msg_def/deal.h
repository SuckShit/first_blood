/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _DEAL_LOG_
#define _DEAL_LOG_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define DEAL_STS_OK         1
#define DEAL_STS_CANCEL     2
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


typedef struct DealInfoS
{
    int64   tradeNo;
    int32   contractPos;
    int64   trdAmount;
    int64   trdPrice;
    int64   trdDateTime;
    int16   trdSts;
    int64   bidOrdNo; 
    int64   askOrdNo;
    int32   bidOrgIdx;     
    int32   askOrgIdx;     
    int32    bidUsrIdx;
    int32    askUsrIdx;
    
    
    /* Used till here */
    int64   trdDate;
    int16   trdMthd;
    int64   bidToAskLastCredit;
    int64   askToBidLastCredit;
    int16   bidTradeType;
    int16   askTradeType;
    int16     tradeSubType;
    int64   updateTime;
    int16   calcOrg;
    int32   rowNum;
    int64    bidAccntNo;
    int64    bidStlmntAccntNo;     
    int32   termLimit;//合约期限
    int32   interestDaysChange;//计息天数调整：1 不调整、2 实际天数
    int64   interestFirstDay;//计息期首日
    int64   dlvryDtDay;//到期交割日
    int64   interestPayforDaysChange;//支付日调整
    int16   stleTp;//清算方式
    int32   interestBidPayPrd;//固定利率支付方支付周期
    int64   interestBidDlvryDt;//固定利率支付方首期定期支付日
    int64   interestBidInterestBnchmk;//固定利率支付方计息基准
    int64   refCntrct;//固定利率收取方参考利率
    int64   interestSprd;//固定利率收取方_利差(%)
    int64   interestOfferDlvryDt;//固定利率收取方首期定期支付日
    int32   interestOfferPayPrd;//固定利率收取方支付周期
    int64   interestConfirmFirstDay;//首次利率确定日
    int32   interestOfferResetRate;//固定利率收取方_重置频率：1 天、2 周、3 两周、4 月、5 季、6 半年、7 年
    int32   interestOfferTp;//固定利率收取方_计息方式：1 复利、2 单利
    int32   interestOfferInterestBnchmk;//固定利率收取方计息基准
/*
    T_CNTRCTNM m_sInterBidOrgNameShortCN;// 固定利率支付方_机构中文简称
    T_CNTRCTNM m_sInterBidOrgCode;// 固定利率支付方_机构编码21位
    T_CNTRCTNM m_sInterBidIntrstType;//固定利率支付方_计息方式：1 复利、2 单利
    T_CNTRCTNM m_sInterOfferNameShortCN;//固定利率收取方_机构中文简称
    T_CNTRCTNM m_sInterOfferOrgCode;//固定利率收取方_机构编码21位.

    T_CNTRCTNM m_sInterestDate; //起息日
    T_CNTRCTNM m_sFisrtInterestDate; //首期起息日
    T_CNTRCTNM m_sInterBidOrgNameShortEn;//固定利率支付方_机构英文简称
    T_CNTRCTNM m_sInterOfferOrgNameShortEn;//固定利率收取方_机构英文简称

    //SBF市场新增字段
    T_CNTRCTNM    m_sInstNameEn;            //合约种类(合约英文名)
    T_CNTRCTNM    m_sInstNameCn;            //合约中文名
    T_CNTRCTNM    m_sBidOrgFullNameCn;    //买方机构中文全称
    T_CNTRCTNM    m_sBidOrgFullNameEn;    //买方机构英文全称
    T_CNTRCTNM    m_sBidAccountID;        //买方账户ID
    T_CNTRCTNM    m_sBidDpstAccountID;    //买方托管账户ID
    T_CNTRCTNM    m_sBidDpstAccountNo;    //买方托管账号
    T_CNTRCTNM    m_sBidDpstAccountName;    //买方托管账户名称
    T_CNTRCTNM    m_sBidDpstOrg;//买方托管机构

    T_CNTRCTNM    m_sOfferOrgFullNameCn;    //卖方机构中文全称
    T_CNTRCTNM    m_sOfferOrgFullNameEn;    //卖方机构英文全称
    T_CNTRCTNM    m_sOfferAccountID;        //卖方账户ID
    T_CNTRCTNM    m_sOfferDpstAccountID;    //卖方托管账户ID
    T_CNTRCTNM    m_sOfferDpstAccountNo;    //卖方托管账号
    T_CNTRCTNM    m_sOfferDpstAccountName;    //卖方托管账户名称
    T_CNTRCTNM    m_sOfferDpstOrg;//卖方托管机构

    T_CNTRCTNM    m_sUpdateUserName;        //更新用户
    T_NORNUM    m_nSecurityFaceValue;          //合约面值
    T_CNTRCTNM  m_sSirsChange;                //标准利率互换
    T_CLS_PSTN_CD m_sBid_ClosePositionCD;    //BID编号
    T_CLS_PSTN_CD m_sOfr_ClosePositionCD;    //OFFER强平编号
    std::string m_sDealDir;        //成交方向
*/    
} DealInfoT, *pDealInfoT;
#endif /* _TRADE_T_ */