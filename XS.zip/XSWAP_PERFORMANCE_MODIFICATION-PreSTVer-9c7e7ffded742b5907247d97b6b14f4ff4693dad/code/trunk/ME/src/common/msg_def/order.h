/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _ORDER_LOG_
#define _ORDER_LOG_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct OrderInfoS
{
    int32   orgId;
    int32   traderId;
    int64   orderNo;
    int16   extOrdrType;
    int16   status;     //0,1,2,3,4  int16
    int16   ordrMask;      
    char    rqstId[2];    //API用户请求ID
    int64   contractPos;
    int64   qty;
    int64   remain;
    int64   price;
    int64   specOrdrId ;
    int64   createTime;        
    int64   activateTime;    
    int64   updateTime;        
    int64   expireTime;
    int64   closePositionCD;    //强平编号
    char    apiId;    //API用户登录名
    char    orgCd;    //机构唯一代码
    
} OrderInfoT, *pOrderInfoT;
#endif /* _TRADE_T_ */
