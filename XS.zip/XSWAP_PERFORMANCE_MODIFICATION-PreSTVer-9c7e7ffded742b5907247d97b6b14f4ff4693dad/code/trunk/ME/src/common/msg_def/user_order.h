/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _USER_ORDER_
#define _USER_ORDER_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include "msg_common_value.h"
#include "deal.h"
#include "order.h"
#include "msg_cache.h"
#include "usr_def_ref.h"
/* Project Header files*/
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define MAX_OCO_ORDER       100
#define MAX_RSP_SLOT_CNT    ((MAX_MSG_LEN - (sizeof(int64)*2))/sizeof(SlotT)-1)


#define MAX_DEAL_SLOT_CNT    ((MAX_MSG_LEN -  sizeof(int64))/sizeof(DealInfoT)-1)

#define MAX_ORDR_SLOT_CNT    ((MAX_MSG_LEN -  sizeof(int64))/sizeof(OrderInfoT)-1)


#define CNFRM_TYPE_ORDR    1
#define CNFRM_TYPE_DEAL    2
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct OrdrPrcQtyInfoS
{
    int64 price;
    int64 qty;
} OrdrPrcQtyInfoT,  *pOrdrPrcQtyInfoT;


typedef struct NewOrderInfoS
{
    int64               ordId;
    int32               userIdx;
    int32               contractPos;
    OrdrPrcQtyInfoT     prcQtyInfo;
    int64               effectTime;
    int32               ordType;
    int32               extOrdType;
    int32               execInst;
    uint32              orgIdx;
    int16               side;
    int16               ordAction;
    int32               apiLoginUsrIdx;
    int64               ocoId;
    int64               apiRqstId;
    int64               forceId;
} NewOrderInfoT,  *pNewOrderInfoT;

typedef struct NewOrderSingleReqS
{
    char                token[MAX_TOKEN_LENTH];
    NewOrderInfoT       newOrdrInfo;
    OrdrPrcQtyInfoT     askPrcQtyInfo;
} NewOrderSingleReqT,  *pNewOrderSingleReqT;

typedef struct NewOrderSingleRspS
{
    SlotT   currOrdrSlot;
    SlotT   currDealSlot;
    int64   slotCnt;
    SlotT   rspSlot[MAX_RSP_SLOT_CNT];
} NewOrderSingleRspT, *pNewOrderSingleRspT;


typedef struct NewOrderCnfrmS
{
    int32  cnfrmCnt;
    int32  cnfrmType;
    OrderInfoT  rspOrder[1];
} NewOrderCnfrmT, *pNewOrderCnfrmT;

typedef struct NewDealCnfrmS
{
    int32  cnfrmCnt;
    int32  cnfrmType;
    DealInfoT   rspDeal[1];
} NewDealCnfrmT, *pNewDealCnfrmT;

typedef struct OrderCancelReplaceRequestReqS
{
    int32  userIdx;
    char   token[MAX_TOKEN_LENTH];
    int64  ordId;
    int32  contractPos;
    int16  side;
    int64  price;
    int64  askPrice;
    int64  orderQty;
    int64 askOrderQty;
    int64  ocoId;
    int64  effectTime;
    int32  ordType;
    int32  execInst;
    int16  ordAction;
} OrderCancelReplaceRequestReqT, *pOrderCancelReplaceRequestReqT;

typedef struct OCOFirstS
{
    int32  userIdx;
    char   token[MAX_TOKEN_LENTH];
    int64  ocoId;
    int32  ordNum;
    int32  execInst;
    int32  eCheckBox;
    int16  ordAction;
}OCOFirstT, *pOCOFirstT;

typedef struct NewOrderListReqS
{
    OCOFirstT           frstInfo;
    NewOrderInfoT       secInfo[MAX_OCO_ORDER];
    NewOrderInfoT       secAskInfo[MAX_OCO_ORDER];
    int32               secInfoCnt;
    int32               secAskInfoCnt;
}NewOrderListReqT, *pNewOrderListReqT;

typedef struct OrderCancelRequestReqS
{
    int32 userIdx;
    char token[MAX_TOKEN_LENTH];
    int64 ordId;
    int64 ocoId;
    int64 apiRqstId;
    int64 apiLoginUsrIdx;
    int64 orgIdx;
    int64 apiCancelRqstId;
    int64 apiCancelType;
} OrderCancelRequestReqT, *pOrderCancelRequestReqT;


typedef struct DealCancelRequestReqS
{
    int32   userIdx;
    int32   officerIdx;
    char    token[MAX_TOKEN_LENTH];
    int64   dealId;
} DealCancelRequestReqT, *pDealCancelRequestReqT;


typedef struct CCPClosePositionReqS
{
    int64           closeSrno;
    int64           closePrice;
    int64           grossTradeAmt;
    int64           message_id;
    int32           iFuncId;
    int16           side;
    char            strOrgCd[MAX_ORG_CD_LENTH];
    char            strCntrctNm[MAX_CNTRCT_NM];
    char            tranTime[MAX_TIME_LENGTH];
} CCPClosePositionReqT, *pCCPClosePositionReqT;

typedef struct CCPClosePositionRspS
{
    int64           closeSrno;
    int64           closePrice;
    int64           grossTradeAmt;
    int64           message_id;
    int32           iMktTyp;
    int16           side;
    char            strOrgCd[MAX_ORG_CD_LENTH];
    char            strCntrctNm[MAX_CNTRCT_NM];
    char            tranTime[MAX_TIME_LENGTH];
} CCPClosePositionRspT, *pCCPClosePositionRspT;

typedef struct CCPClsPosCnclReqS
{
    int64           closeSrno;
    int64           closeCnclSrno;
    int64           message_id;
    int32           iFuncId;
    char            tranTime[MAX_TIME_LENGTH];
} CCPClsPosCnclReqT, *pCCPClsPosCnclReqT;

typedef struct CCPClsPosCnclRspS
{
    int64           closeSrno;
    int64           closeCnclSrno;
    int64           message_id;
    int32           iMktTyp;
    char            tranTime[MAX_TIME_LENGTH];
} CCPClsPosCnclRspT, *pCCPClsPosCnclRspT;

#endif /* _USER_ORDER_ */
