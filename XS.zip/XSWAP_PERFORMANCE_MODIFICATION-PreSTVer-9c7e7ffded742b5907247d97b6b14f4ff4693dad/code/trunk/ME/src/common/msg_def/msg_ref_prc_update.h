/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _MSG_REF_PRC_UPDATE_H_
#define _MSG_REF_PRC_UPDATE_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
// Cursor OUT_ORDRC
typedef struct OrdrRespS {
    char    strTrdrNm[100];                        /* 交易员标识 */
    char    strOrdrId[50];                        /* 订单编号 */
    char    strOrdrTp[64];                        /* 订单类型
                                                    R[常规];
                                                    i[隐含订单];
                                                    OCO[一篮子订单];
                                                    i(OCO)[一篮子订单中包含隐含订单]; 
                                                */
    char    strSt[8];                            /* 订单状态：0 失效 1冻结 2有效 3成交 4撤销 */
    char    strDlDir[8];                        /* 交易方向: 0:BID, 1:OFFER */
    char    strCntrctNm[50];                    /* 合约名 */
    int64   strNtnlAmnt;                        /* 名义本金 */
    int64   strRmngNtnlAmnt;                    /* 剩余本金 */
    int64   strOrdrPrc;                            /* 订单价格 */
    char    strOrdrCrtTm[20];                    /* 订单创建时间 */
    char    strOrdrExprdTm[20];                    /* 订单到期时间 */
    char    strOrdrActvTm[20];                    /* 激活时间 */
    char    strUpdTm[20];                        /* 更新时间 */
    char    strOcoId[50];                        /* OCO编号 */
    int64   strOrgId;                            /* 机构号 */
    char    strRqstId[50];                        /* API用户请求ID */
    char    strUsrLgnNmApi[100];                /* API用户登录名 */
    char    strOrgCd[50];                        /* 机构编码21位 */
    char    strBilId[50];                        /* 双边订单编号 */
} OrdrRespT, *pOrdrRespT;

// Cursor OUT_TRDINFO
typedef struct TrdCntrctRefPrcRespS {
    char    strDlId[50];                        /* 成交编号 */
    char    strCntrctNm[50];                    /* 合约系列号 */
    char    strTrdngMthd[8];                    /* 交易方式: 1--竞价 */
    int64   iNtnlAmnt;                            /* 名义本金 */
    int64   iDlPrc;                                /* 价格 */
    char    strDlDt[20];                        /* 成交日期 */
    char    strDlTm[20];                        /* 成交时间 */
    char    strFxdIntrstBidOrdrId[50];            /* 固定利率支付方订单号 */
    int64   iFxdIntrstBidOrgId;                    /* 固定利率支付方机构标识 */
    char    strOrgNmCn1[100];                    /* 机构1(支付方)中文简称 */
    char    strFxdIntrstBidTrdr[100];            /* 固定利率支付方交易员 */
    char    strFxdIntrstBidTrdrNm[300];            /* 固定利率支付方交易员姓名 */
    int64   iBidCreditAmnt;                        /* 额度(支付方->收取方)*/
    char    strFxdIntrstOfrOrdrId[50];            /* 固定利率收取方订单号 */
    int64   iFxdIntrstOfrOrgId;                    /* 固定利率收取方机构标识 */
    char    strOrgNmCn2[100];                    /* 机构2(收取方)中文简称 */
    char    strFxdIntrstOfrTrdr[100];            /* 固定利率收取方交易员 */
    char    strFxdIntrstOfrTrdrNm[300];            /* 固定利率收取方交易员姓名 */
    int64   iOfrCreditAmnt;                        /* 额度(收取方->支付方)*/
    char    strDlTp[8];                            /* 成交类型:
                                                    200-期差合约实单与期差合约实单成交;
                                                    201-期差实单与期差内隐订单的成交;
                                                    202-直接合约实单与直接合约外隐订单成交;
                                                    203-直接合约实单与直接合约实单成交;
                                                    301-期差合约与桥单;
                                                    302-直接合约与桥单;
                                                    303-基准互换合约实单与桥单成交;
                                                    204-基准互换合约实单与基准互换合约实单成交;
                                                */
    char    strCntrctTp1[8];                    /* (支付方)合约类型 枚举: 0 直接合约 1 期差合约 2 基准互换合约 */
    char    strCntrctTp2[8];                    /* (收取方)合约类型 枚举: 0 直接合约 1 期差合约 2 基准互换合约 */
    char    strDlDir[8];                        /* 成交方向,枚举值: 1-TAKEN, 2-GIVEN, 3-DONE */
    char    strFxdIntrstBidOrgShortNmCn[100];    /* 固定利率支付方机构中文简称 */
    char    strFxdIntrstOfrOrgShortNmCn[100];    /* 固定利率收取方机构中文简称 */
    char    strFxdIntrstBidOrgShortNmEn[100];    /* 固定利率支付方机构英文简称 */
    char    strFxdIntrstOfrOrgShortNmEn[100];    /* 固定利率收取方机构英文简称 */
} TrdCntrctRefPrcRespT, *pTrdCntrctRefPrcRespT;

// Cursor OUT_BRDGORDRC
typedef struct OrdrBrdgRespS {
    int64   iOrdrBrdgSrno;                        /* 桥订单序列号 */
    int64   iBrdgOrdrOwnrOrgId;                    /* 桥订单所属机构ID */
    char    strDlDir[8];                        /* 交易方向,枚举值: 0-BID, 1-OFFER */
    char    strCntrctNm[50];                    /* 合约名 */
    int32   iOrdrPrc;                            /* 订单价格 */
    int64   iNtnlAmnt;                            /* 名义本金 */
    char    strOrdrId[50];                        /* 实订单编号 */
    int64   iRmngNtnlAmnt;                        /* 剩余本金 */
    char    strUpdTm[20];                        /* 更新时间 */
} OrdrBrdgRespT, *pOrdrBrdgRespT;

// Cursor OUT_WTPRCC
typedef struct CntrctRefPrcRespS {
    char    strCntrctNm[50];                    /* 合约名 */ 
    int64   iRefPrc;                            /* 参考价 */
} CntrctRefPrcRespT, *pCntrctRefPrcRespT;


// Main Request Struct.
typedef struct RefPrcUpdateReqS {
    int32 iFuncId;                                /* Function ID */
    char strToken[16];                            /* Token */
} RefPrcUpdateReqT, *pRefPrcUpdateReqT;

// Main Response Struct.
typedef struct RefPrcUpdateRespS {
    CntrctRefPrcRespT        stWtPrc;            /* 合约参考价 */
    int64                    iMaxOutBoundId;        /* 最大Imix消息号 */
    int32                    iSendFlag;            /* 是否发送 */
    OrdrRespT                stOrdr;                /* 订单Cursor */
    TrdCntrctRefPrcRespT    stTrdInfo;            /* 成交Cursor */
    OrdrBrdgRespT            stBrdgOrdr;            /* 桥单Cursor */
    int32                    errCode;            /* 错误返回码 */
    char                    errMsg[100];        /* 错误信息 */
} RefPrcUpdateRespT, *pRefPrcUpdateRespT;

#endif /* _MSG_REF_PRC_UPDATE_H_ */
