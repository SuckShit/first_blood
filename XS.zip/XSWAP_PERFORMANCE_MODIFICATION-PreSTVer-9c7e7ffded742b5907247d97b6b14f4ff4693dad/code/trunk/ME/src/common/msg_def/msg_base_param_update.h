/***
Created on Aug 02, 2017
@author: Xiaoping Zhou
@version $Id
***/

#ifndef _MSG_BASE_PARAM_UPDATE_
#define _MSG_BASE_PARAM_UPDATE_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct BaseParamUpdateReqS
{
    int32 intFuncId;
    char strUserId[32];
    char strToken[16];
    char strMrktStallsLvl[16];
    char strPrcSpreadLmt[16];
    char strSetmntPrcSirs[16];
    char strSetmntPrcSbf[16];
    char strOcoMaxNumLmt[16];
    char strOcoMinNumLmt[16];
    char strEffCreditAmtLmt[16];
    char strEffCreditCntrct[64];
    char strOcoMaxNum[16];
    char strMinCreditOrgNum[16];
    char strBrdgSqnc[16];
    char strSetmntPrcSbfccp[16];
    char strBilNtfSqnc[16];
    char strOrdrStatInterval[16];
    char strOrdrDifference[16];
} BaseParamUpdateReqT, *pBaseParamUpdateReqT;

typedef struct MarketStCfgModifyReqS
{
    int32 intFuncId;
    char strToken[16];
    uint64 intMktStCfgId;                 // 市场状态变化消息ID
    char strTime[16];                     // 市场状态变化时间
} MarketStCfgModifyReqT, *pMarketStCfgModifyReqT;

#endif /* _MSG_BASE_PARAM_UPDATE_ */
