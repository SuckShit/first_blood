/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _MSG_TIMER_
#define _MSG_TIMER_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "msg_common_value.h"
#include "order.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct BilNoteUsrS
{
    char   usrLgnNm[MAX_USR_NM_LENTH];
    int32  orgId;
}BilNoteUsrT, *pBilNoteUsrT;
 
 
typedef struct ExecutionReportReqS
{
    OrderInfoT  rspOrder[MAX_RSP_ORDER_CNT];
    int32  rspOrderCnt;
    int64  rspUsrCnt;
    BilNoteUsrT rspUsr[MAX_RSP_USR_CNT];
}ExecutionReportRspT, *pExecutionReportRspT;

#endif /* _ORG_SETTING_ */
