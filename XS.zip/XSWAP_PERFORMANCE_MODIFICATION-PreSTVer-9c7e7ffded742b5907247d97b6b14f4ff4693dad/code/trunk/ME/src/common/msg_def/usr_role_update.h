/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _USER_ROLE_UPDATE_
#define _USER_ROLE_UPDATE_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include "msg_common_value.h"
#include "user_order.h"
#include "order.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define MAX_OCO_ORDER       100
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct SecurityListReqS {
    int32  iFuncId;                                                     /* 功能标识 */
    char   strUserId[MAX_USR_ID_LENTH];                                 /* 用户标识 */
    char   strToken[MAX_TOKEN_LENTH];                                   /* Token */
    char   strOpUsrId[MAX_USR_ID_LENTH];                                /* 被处理用户ID */
    int32  iMktIrsRole;                                                 /* Irs市场权限 */
    int32  iMktSirsRole;                                                /* Sirs市场权限 */
    int32  iMktSbfRole;                                                 /* Sbf市场权限 */
    int32  iMktSirsccpRole;                                             /* Sirsccp市场权限 */
    int32  iMktSbfccpRole;                                              /* Sbfccp市场权限 */
} SecurityListReqT, *pSecurityListReqT;

typedef struct SecurityListRspS {
//    int32         rspOrderCnt;
//    OrderInfoT    rspOrder[MAX_RSP_ORDER_CNT];
    NewOrderSingleRspT rspOrderCancel;                                  /* 冻结订单 */
//    int32  errCode;                                                     /* 错误返回码 */
//    char   errMsg[MAX_MSG_LENTH];                                       /* 错误信息 */
} SecurityListRspT, *pSecurityListRspT;

#endif /* _USER_ROLE_UPDATE_ */
