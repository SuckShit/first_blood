/***
Created on July 20, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _LOGIN_H_
#define _LOGIN_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files*/
#include "order.h"
#include "uti_tool.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_FREEZE_INFO_NUM 16

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct RiskCoefUpdateReqS
{
    int32   iFuncId;
    char    strUserId[32];
    char    strToken[16];
    int32   orgId;
    char    cntrctNm[50];
    float   rskCfCnt;
}RiskCoefUpdateReqT, *pRiskCoefUpdateReqT;


typedef struct UserLoginReqS
{
    int32   iFuncId;
    char    strUserId[32];
    int     iLoginType;
    char    strUniqueKey[32];
} UserLoginReqT, *pUserLoginReqT;

typedef struct UserLoginRespS
{
    char    m_sToken[16];
    char    m_sUserName[64];
    char    m_sUserRole[64];
    char    m_strOrgId[64];
    char    m_sOrgNameCN[300];
    int16   m_iMktSt;
    int16   m_iMktStSirs;
    char    m_sUpTime[MAX_TIME_LEN];
    int32   m_sBrdgFlag;
} UserLoginRespT, *pUserLoginRespT;


typedef struct UserLogoutReqS
{
    int32   iFuncId;
    char    strUserId[32];
    char    strToken[16];
} UserLogoutReqT, *pUserLogoutReqT;


typedef struct RemoveUserReqS
{
    int32   iFuncId;
    char    strOfficer[32];
    char    strToken[16];
    char    strOrgId[64];
    char    strRemoveUserId[32];
} RemoveUserReqT, *pRemoveUserReqT;

typedef struct FreezeInfoS
{
    int32   orgId;
    char    usrLgnNm[64];
    char    crdtMdffnsh[64];
    char    currentTime[32];
} FreezeInfoT, *pFreezeInfoT;

typedef struct RemoveUserRespS
{
    FreezeInfoT     sFreezeInfo[MAX_FREEZE_INFO_NUM];
} RemoveUserRespT, *pRemoveUserRespT;



typedef struct ApiLoginReqS
{
    int32   iFuncId;
    char    strInitUserId[32];      // �����û�ID
    char    strUserId[32];          // �û�ID
    char    strOrgCd[32];           // ����21λ
    int32   iLoginType;

    char    strRequestId[256];
} ApiLoginReqT, *pApiLoginReqT;

typedef struct ApiLoginRespS
{
    char    strToken[16];
    char    iMktState;              // �г�״̬��־
    char    iMktStIrs;              // �г�״̬
    char    strUpdateTime[32];      // ����ʱ��
    char    strUpdateTimeIrs[32];   // IRS ����ʱ��
    int32   iUserRole;              // �û�Ȩ������ 6 7 8

    char    strUserId[32];          // �û�ID
    char    strOrgCd[32];           // ����21λ
    char    strRequestId[256];

    OrderInfoT  sOrdInfo;           // ����״̬������Ϣ
    OrderInfoT  sSirsOrdInfo;       // SIRS����״̬������Ϣ todo
    OrderInfoT  sSbfccpOrdInfo;     // SBFCCP����״̬������Ϣ todo
    char        sBrdgInfo;          // �Ŷ�����Ϣ
    uint64      iMaxOutboundId;     // ���Imix��Ϣ��
} ApiLoginRespT, *pApiLoginRespT;


typedef struct ApiLogoutReqS
{
    int32   iFuncId;
    char    strUserId[32];          // �û�ID
    char    strOrgCd[64];
    char    strToken[16];
    int32   iLoginType;             // �ǳ���ʶ��2

    char    strRequestId[256];
} ApiLogoutReqT, *pApiLogoutReqT;

typedef struct ApiLogoutRespS
{
    int32   iUserRole;          // �ǳ���6-API�û�����Ȩ�޽�ɫ��7-API�û�����Ȩ�޽�ɫ��8-API�û�����Ȩ�޽�ɫ

    char    strToken[16];
    char    strUserId[32];          // �û�ID
    char    strOrgCd[32];           // ����21λ
    char    strRequestId[256];

    OrderInfoT  sOrdInfo;           // ����״̬������Ϣ tbd
    OrderInfoT  sSirsOrdInfo;       // SIRS����״̬������Ϣ tbd
    OrderInfoT  sSbfccpOrdInfo;     // SBFCCP����״̬������Ϣ tbd
    OrderInfoT  sBrdgInfo;          // �Ŷ�����Ϣ tbd

    uint64      iMaxOutboundId;     // ���Imix��Ϣ��
} ApiLogoutRespT, *pApiLogoutRespT;


#endif /* _LOGIN_H_ */
