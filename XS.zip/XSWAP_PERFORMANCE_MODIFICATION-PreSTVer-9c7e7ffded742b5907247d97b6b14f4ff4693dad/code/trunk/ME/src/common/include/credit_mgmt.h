﻿/***
Created on Aug 10, 2017
@author: Longyun Hao
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _CREDIT_MGMT_H_
#define _CREDIT_MGMT_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files */
#include "data_type.h"

#include "credit_info.h"

#ifdef __cplusplus
extern "C" {
#endif
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define CREDIR_AMNT_UNLMT               (((uint64)-1)>>1)

#define CREDIT_RELATION_NONE            '0'
#define CREDIT_RELATION_RLNM            '1'
#define CREDIT_RELATION_AMNT            ' ' //数据库中以NULL表示，后台转为空格

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef enum crdtChkModeTag
{
    CREDIT_CMODE_NULL = 0,
    CREDIT_CMODE_MIN,
    CREDIT_CMODE_NINB,
    CREDIT_CMODE_CINB,
    CREDIT_CMODE_NICB,
    CREDIT_CMODE_CICB,
    CREDIT_CMODE_MAX
    
}crdtChkModeT;

typedef struct CrdtMgmtUpdtTag
{
    int32           prdctPos;
    crdtChkModeT    chkMode;
    int32           incEntyIdPos;
    int32           bstEntyIdPos;
    int32           incCrdtPos;
    int32           bstCrdtPos;
    int64           incUsedQty;
    int64           incRmntQty;
    int64           bstUsedQty;
    int64           bstRmntQty;
}CrdtMgmtUpdtT, *pCrdtMgmtUpdtT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CreditCheck( pOrderT pIncOrdr, pOrderT pBstOrdr, pCrdtMgmtUpdtT  pCrdtUpdInfo, BOOL *isCrdtOK );
ResCodeT CreditDeduction( pCrdtMgmtUpdtT  pCrdtUpdInfo );
ResCodeT GetCreditRmnAmnt( uint32 aOrgId, uint32 bOrgId, BOOL * pAvaFlag, int64 * pRmnAmnt );

#ifdef __cplusplus
}
#endif

#endif /* _CREDIT_MGMT_H_ */
