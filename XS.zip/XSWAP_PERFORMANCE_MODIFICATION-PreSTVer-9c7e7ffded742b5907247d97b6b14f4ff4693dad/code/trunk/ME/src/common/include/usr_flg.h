/***
Created on Aug 10, 2017
@author: Yinsong.Zhao
@version $Id
***/

#ifndef _USR_FLG_
#define _USR_FLG_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define MAX_USR_FLG_CNT


typedef enum
{
    USR_FLG_ALL = 0,
    /* Add new memory txn element type BELOW */
    USR_BIL_ORD_FLG,
    /* Add new memory txn element type ABOVE */
    USR_FLG_MAX
}UsrFlgTypeT;





/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct UsrFlgKeyS
{
    uint32          usrPos;
    uint32          cntrctPos;
} UsrFlgKeyT, *pUsrFlgKeyT;

typedef struct UsrFlgRcrdS
{
    UsrFlgKeyT  usrFlgKey;
    vectorT     usrFlgVct[GET_BIT_VECT_LEN(USR_FLG_MAX)];
} UsrFlgRcrdT, *pUsrFlgRcrdT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT UsrFlgShmCreate();
ResCodeT UsrFlgShmDetach();
ResCodeT UsrFlgShmAttach();
ResCodeT UsrFlgShmDelete();
ResCodeT UsrFlgShmReset();
ResCodeT UsrFlgShmLoad();

ResCodeT UsrFlgChkExt(pUsrFlgKeyT pUsrFlgKey, pUsrFlgRcrdT * ppUsrFlg, uint32 * pUsrFlgPos);
ResCodeT UsrFlgLogByPos(uint32 UsrFlgPos, pUsrFlgRcrdT pUsrFlg);
ResCodeT UsrFlgAdd(pUsrFlgRcrdT pUsrFlg, uint32 * pUsrFlgPos);
ResCodeT UsrFlgUpdtByPos(uint32 UsrFlgPos, pUsrFlgRcrdT pUsrFlg);
ResCodeT UsrFlgIter(uint32* nodePos, pUsrFlgRcrdT  pUsrFlg);
ResCodeT SetUsrFlg(pUsrFlgKeyT pUsrFlgKey, UsrFlgTypeT usrFlg);
ResCodeT ResetUsrFlg(pUsrFlgKeyT pUsrFlgKey, UsrFlgTypeT usrFlg);
ResCodeT GetUsrFlg(pUsrFlgKeyT pUsrFlgKey, UsrFlgTypeT usrFlg, BOOL * pbFlgChked);
#endif /* _USR_FLG_ */
