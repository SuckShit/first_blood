/***
Created on Sep 4, 2017
@author: 
@version $Id
***/

#ifndef _BRDG_ORDR_MGMT_
#define _BRDG_ORDR_MGMT_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
#include "order_type.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

//#define MAX_ORDR_RCRD_CNT   100

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef enum
{
    ACTN_BRDG_NULL = 0,
    ACTN_BRDG_ADD,
    ACTN_BRDG_MTCH,
    ACTN_BRDG_DEL,
    ACTN_BRDG_DEL_ALL,
    ACTN_BRDG_DEL_BRDG,
    ACTN_BRDG_DEL_ORG,
    ACTN_BRDG_MAX
} ActnBrdgTypeT;

typedef struct BrdgOrdrKeyS
{
    uint32          entyIdxNo;
    int16           ordrSide;
    char            filler[2];
    int64           prdctId;
} BrdgOrdrKeyT, *pBrdgOrdrKeyT;

typedef struct BrdgOrdrRcrdS
{
    BrdgOrdrKeyT    ordrKey;
    int64           brdgOrgId;
    int64           brdgFee;
    SlotT           ordrBkSlot;
} BrdgOrdrRcrdT, *pBrdgOrdrRcrdT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT BrdgOrdrShmCreate(int64 rcrdCnt, int32 setId);
ResCodeT BrdgOrdrShmDetach(int32 setId);
ResCodeT BrdgOrdrShmAttach(int32 setId);
ResCodeT BrdgOrdrShmDelete(int32 setId);
ResCodeT BrdgOrdrShmReset(int32 setId);

ResCodeT BrdgOrdrChk(int32 setId, pBrdgOrdrKeyT pBrdgOrdrKey, pBrdgOrdrRcrdT * ppBrdgOrdr, uint32 * pBrdgOrdrPos);
ResCodeT BrdgOrdrAdd(int32 setId, pBrdgOrdrRcrdT pBrdgOrdr, uint32 * pBrdgOrdrPos);
ResCodeT BrdgOrdrGetByPos(int32 setId, pBrdgOrdrKeyT pBrdgOrdrKey, uint32 brdgOrdrPos, pBrdgOrdrRcrdT * ppBrdgOrdr );
ResCodeT BrdgOrdrDel(int32 setId, pBrdgOrdrKeyT pBrdgOrdrKey);
ResCodeT BrdgOrdrDelByPos(int32 setId, uint32 brdgOrdrPos);
ResCodeT BrdgOrdrMgmtIter(int32 setId, uint32* pNodePos, pBrdgOrdrRcrdT pBrdgOrdrRcrd);
ResCodeT BrdgOrdrMgmtDelAll( int32 setId );
ResCodeT BrdgOrdrMgmtDelAllByOrgId( int32 setId, uint32 orgId );
ResCodeT BrdgOrdrMgmtDelAllByBrdgOrgId( int32 setId, uint32 brdgOrgId );
#endif /* _BRDG_ORDR_MGMT_ */
