﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _REF_DAT_UPDT_
#define _REF_DAT_UPDT_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files */
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
#include "mem_txn_elem.h"
#include "msg_type.h"
#include "usr_def_ref.h"
#include "org_def_ref.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef enum
{
    REF_TYPE_INIT = 0,
    /* Add new ref update type BELOW */
    REF_TYP_UPDT_USR_DAT,
    REF_TYP_UPDT_API_SUBSCRIBE_DAT,
    REF_TYP_UPDT_TRADE_PRIVIL_CONFIG_DAT,
    REF_TYP_UPDT_CREDIT_DAT,
    REF_TYP_UPDT_REFPRC_DAT,
    REF_TYP_UPDT_BRIDGE_DAT,
    REF_TYP_UPDT_BRIDGE_PARAM_DAT,
    REF_TYP_UPDT_BRIDGE_CREDIT_DAT,
    REF_TYP_UPDT_MARKET_INFO_CONFIG_DAT,
    REF_TYP_UPDT_MARKET_INFO_UPDATE_DAT,
    REF_TYP_UPDT_ORG_DAT,
    REF_TYP_UPDT_RISK_DAT,
    REF_TYP_UNLCK_RISK_DAT,
    REF_TYP_MODY_SETLPRC_DAT,
    REF_TYP_UPDT_CCPCRDT_DAT,
    REF_TYP_UPDT_SBFCCP_CREDIT_LIMIT_DAT,
    REF_TYP_UPDT_ORDRCNCL_BYCW_DAT,
    REF_TYP_UPDT_DEAL_CNCL,
    REF_TYP_UPDT_ORDRSBMT_BYCW_DAT,
    /* Add new ref update type ABOVE */
    REF_TYPE_INVLD
}RefUpdtTypeT;

typedef struct MRefDatUpdtS
{
    RefUpdtTypeT     updtType;
    int32            dataLen;
} MRefDatUpdtT, *pMRefDatUpdtT;

typedef ResCodeT (*RefDatUpdtCallbackT)(void * pData, int32 dataLen);
typedef ResCodeT (*RefDatDbUpdtCallbackT)(int32 connId, void * pData, int32 dataLen);
typedef ResCodeT (*RefDatPrntCallbackT)(void * pData, int32 dataLen);


typedef struct RefUpdtPrcsInfoS
{
    RefUpdtTypeT                refUpdtType;
    RefDatUpdtCallbackT         fRefUpdtCallBack;
    RefDatDbUpdtCallbackT       fRefDatDbUpdtCallback;
    RefDatPrntCallbackT         fRefPrntCallBack;
} RefUpdtPrcsInfoT, *pRefUpdtPrcsInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

static RefUpdtPrcsInfoT gRefUpdtPrcsMatrix[] = {
    {REF_TYPE_INIT,                         NULL,                           NULL,                           NULL},
    /* Please add the new type below */
    {REF_TYP_UPDT_USR_DAT,                  UserMemRef,                     NULL,                           UserDataPrint},
    {REF_TYP_UPDT_API_SUBSCRIBE_DAT,        ApiSubscribeMemRef,             NULL,                           ApiSubscribeDataPrint},
    {REF_TYP_UPDT_TRADE_PRIVIL_CONFIG_DAT,  TrdPrvlConfMemRef,              TrdPrvlConfDbRef,               TrdPrvlConfDataPrint},
    {REF_TYP_UPDT_CREDIT_DAT,               CreditMemUpdateCallback,        CreditDbUpdateCallback,         CreditPrintCallback},
    {REF_TYP_UPDT_REFPRC_DAT,               RefPrcUpdCallback,              RefPrcUpdDbCallback,            RefPrcPrintCallback},
    {REF_TYP_UPDT_BRIDGE_DAT,               BridgeMemUpdateCallback,        BridgeDbUpdateCallback,         BridgePrintCallback},
    {REF_TYP_UPDT_BRIDGE_PARAM_DAT,         BridgeParamMemUpdateCallback,   BridgeParamDbUpdateCallback,    BridgeParamPrintCallback},
    {REF_TYP_UPDT_BRIDGE_CREDIT_DAT,        BridgeCreditMemUpdateCallback,  BridgeCreditDbUpdateCallback,   BridgeCreditPrintCallback},
    {REF_TYP_UPDT_MARKET_INFO_CONFIG_DAT,   MarketInfoCfgMemUpdateCallback, MarketInfoCfgDbUpdateCallback,  MarketInfoCfgPrintCallback},
    {REF_TYP_UPDT_MARKET_INFO_UPDATE_DAT,   MktInfoMemUpdateCallback ,      MktInfoDbUpdateCallback,        MktInfoPrintCallback},
    {REF_TYP_UPDT_ORG_DAT,                  OrgMemRef,                      OrgDbRef,                       OrgDataPrintRef},
    {REF_TYP_UPDT_RISK_DAT,                 RiskMemUpdateCallback,          RiskDbUpdateCallback,           RiskUpdatePrintCallback},
    {REF_TYP_UNLCK_RISK_DAT,                RiskMemUnlockCallback,          RiskDbUnlockCallback,           RiskUnlockPrintCallback},
    {REF_TYP_MODY_SETLPRC_DAT,              SetlPrcMemModifyCallback,       SetlPrcDbModifyCallback,        SetlPrcModifyPrintCallback},
    {REF_TYP_UPDT_CCPCRDT_DAT,              CCPCrdtMemUpdateCallback,       CCPCrdtDbUpdateCallback,        CCPCrdtUpdatePrintCallback},
    {REF_TYP_UPDT_SBFCCP_CREDIT_LIMIT_DAT,  SbfCcpCrdtLimitMemUpdateCallback, SbfCcpCrdtLimitDbUpdateCallback, SbfCcpCrdtLimitPrintCallback},
    {REF_TYP_UPDT_ORDRCNCL_BYCW_DAT,        OrdrCnclByCwMemUpdateCallback,  OrdrCnclByCwDbUpdateCallback,   OrdrCnclByCwPrintCallback},
    {REF_TYP_UPDT_DEAL_CNCL,                DealCnclCallback,               DealCnclDbCallback,             DealCnclPrintCallback},
    {REF_TYP_UPDT_ORDRSBMT_BYCW_DAT,        OrdrSubmitByCwMemUpdateCallback,OrdrSubmitByCwDbUpdateCallback, OrdrSubmitByCwPrintCallback},

};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT RefDatUpdtNoMemTxn(RefUpdtTypeT refUpdtType, void * pData, int32 dataSize);
ResCodeT RefDatUpdtCmmn(RefUpdtTypeT refUpdtType, void * pData, int32 dataSize);
ResCodeT RefDatUpdtForLoad(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType);
ResCodeT RefDatDbUpdtCmmn(int32 connId, RefUpdtTypeT refUpdtType, void * pData, int32 dataSize);
ResCodeT RefDatPrntCmmn(RefUpdtTypeT refUpdtType, void * pData, int32 dataSize);

#endif /* _REF_DAT_UPDT_ */
