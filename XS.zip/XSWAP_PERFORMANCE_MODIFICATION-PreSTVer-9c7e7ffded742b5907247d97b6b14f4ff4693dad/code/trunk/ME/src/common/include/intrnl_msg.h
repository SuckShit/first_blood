/***
Created on June 13, 2017
@author: Brian Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _INTRNL_MSG_STRUCT_
#define _INTRNL_MSG_STRUCT_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define IMIX_HDR_ID_LEN        16
#define IMIX_HDR_ID_LEN2       32
#define MSG_HDR_LEN         (sizeof(MsgHdrT))
#define MSG_BODY_LEN        ((MAX_MSG_LEN) - (MSG_HDR_LEN))

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct ImixHdrS
{
    int32 applRefSeqNum;
    char senderCompID[IMIX_HDR_ID_LEN];
    char senderSubID[IMIX_HDR_ID_LEN];
    char onBehalfOfSubID[IMIX_HDR_ID_LEN2];
    char onBehalfOfCompID[IMIX_HDR_ID_LEN2];
}ImixHdrT, *pImixHdrT;
 
typedef struct MsgHdrS
{
    int16       msgLen;
    int16       msgType;
    int16       fromNode;
    int16       setId;
    SlotT       slotNo;
    int32       errCode;
    ImixHdrT    imixHdr;
} MsgHdrT, *pMsgHdrT;

typedef struct IntrnlMsgS
{
    MsgHdrT     msgHdr;
    char        msgBody[MSG_BODY_LEN];
} IntrnlMsgT, *pIntrnlMsgT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

#endif /* _INTRNL_MSG_STRUCT_ */
