/***
Created on June 13, 2017
@author: Ming Kong
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _SHM_LIB_
#define _SHM_LIB_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "shm_name.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT ShmCreate(char* shmName, int64 size, int64** ppRoot);
ResCodeT ShmAttach(char* shmName, int64** pRot);
ResCodeT ShmDelete(char* shmName);
ResCodeT ShmDetach(char* shmName);

ResCodeT ShmDeleteByPid(char* tmpPath,char * envNo, char * pid);
#endif /* _SHM_LIB_ */
