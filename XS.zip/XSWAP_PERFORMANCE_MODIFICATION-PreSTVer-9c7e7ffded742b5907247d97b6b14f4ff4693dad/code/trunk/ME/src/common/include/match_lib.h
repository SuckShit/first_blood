﻿/***
Created on June 30, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


#ifndef _MATCH_LIB_
#define _MATCH_LIB_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "static_lst.h"
#include "err_lib.h"
#include "trade.h"
#include "order_type.h"
#include "prdct_info.h"
#include "user_order.h"
#include "order.h"
#include "credit_mgmt.h"
#include "brdg_ordr_mgmt.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/*command code*/
#define ACTN_ADD_CMD     0x0
#define ACTN_CHG_CMD     0x1
#define ACTN_DEL_CMD     0x2
#define ACTN_BOOK_CMD    0x3
#define ACTN_CNCL_CMD    0x4
#define ACTN_CMD_COD_MSK 0X7   /*command code MASK*/
        
/* maintenance code*/
#define ACTN_ADD_MNT     0x0
#define ACTN_CHG_MNT     0x8
#define ACTN_DEL_MNT     0x10
#define ACTN_MATCH_MNT   0x18
#define ACTN_PRT_FIL_MNT 0x20
#define ACTN_CANCEL_MNT  0x28
#define ACTN_EXE_MNT     0x30
#define ACTN_TRG_MNT     0x38
#define ACTN_INSERT_MNT  0x40
#define ACTN_STACHG_MNT  0x48
#define ACTN_MAINT_MSK   0x78  /* maintenance code MASK*/

/* audit trail flag*/
#define ACTN_AUD_YES     0x0
#define ACTN_AUD_NO      0x80
#define ACTN_AUD_MSK     0X80  /* audit trail flag MASK*/

/* order confirmation flag*/
#define ACTN_CONF_ORDER    0x0
#define ACTN_CONF_QUOTE  0x100
#define ACTN_CONF_NO     0x200
#define ACTN_CONF_MSK    0x300 /* order confirmation flag MASK*/ 

/*physical order book flag*/
#define ACTN_ORDR_BK_YES 0x0
#define ACTN_ORDR_BK_NO  0x400
#define ACTN_ORDR_BK_MSK 0x400 /* physical order book flag MASK*/ 

/* Return a specific attribute from actn mask. */
#define GET_ACTN_CMD( aMask ) ( ( aMask ) & ACTN_CMD_COD_MSK )
#define GET_ACTN_MAINT( aMask ) ( ( aMask ) & ACTN_MAINT_MSK )
#define GET_ACTN_ADTTRL( aMask ) ( ( aMask ) & ACTN_AUD_MSK )
#define GET_ACTN_ORDRCFM( aMask ) ( ( aMask ) & ACTN_CONF_MSK )
#define GET_ACTN_ORDR_BK( aMask ) ( ( aMask ) & ACTN_ORDR_BK_MSK )

#define MTCH_TYPE_NO_MTCH                  ' '    /* No match code */
#define MTCH_TYPE_PRT_FIL                  'P'    /* Order partially filled */
#define MTCH_TYPE_FULL_MTCH                'F'    /* Order fully matched */


#define MAX_ORDR_IN_OCO         100
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct MtchInfoS
{
    uint64      ordrNoOld;
    int64       tradePrc;
    uint64      actnSeqNum;
    char        ordrPrtFilCod;
    char        ordrFreeCod;
    char        filler[6];
} MtchInfoT, *pMtchInfoT;

typedef struct HoldTag
{
    int16 bstBkPrc;       /* 订单簿最优订单价格 */
    int16 mktQty;         /* 市价订单数量 */
    int16 lstTrdQty;      /* 上比成交数量 */
    int16 trdPrc;         /* 成交价格 */
    int16 mtchId;         /* 撮合序列号 */
    int16 totalTrdQty;    /* 总计成交数量*/
    int16 totalNumOfTrd;  /* 总计成绩次数*/
    int16 trnover;        /* 总计成交金额*/
} HoldT;


typedef struct MtchTrdS
{
    TradeT      trade;
} MtchTrdT, *pMtchTrdT;

typedef struct MLogOrdrS
{
    OrderFT           ordr;
    MtchInfoT         mtchInfo;
    SlotT             slot;
    uint16            actnMask;
    int16             setId;
} MLogOrdrT, *pMLogOrdrT;

typedef struct MSaveOrdrS
{
    OrderFT           ordrF;
    SlotT             slot;
    uint16            actnMask;
    int16             setId;
} MSaveOrdrT, *pMSaveOrdrT;


typedef struct MSaveBilOrdrS
{
    OrderFT           bidOrdrF;
    OrderFT           askOrdrF;
    SlotT             bidSlot;
    SlotT             askSlot;
    int16             ordrSts;
    int16             ordrAct;
    int16             setId;
    char              filler[2];
} MSaveBilOrdrT, *pMSaveBilOrdrT;

typedef struct MAddOrdrS
{
    OrderFT     ordr;
    MtchInfoT   mtchInfo;
    SlotT       slot;
    SlotT       prcLder;
    /* remember the old holding mask */
    int16       oldHldMask;
    int16       actnMask;
    char        fNewPrcLder;
    int16       setId;
    char        filler[1];
} MAddOrdrT, *pMAddOrdrT;


typedef struct MLogTrdS
{
    TradeT            trade;
    uint64            oldOrdrNo;
    unsigned short    actnMask;
    int16             setId;
    char              filler[4];
} MLogTrdT, *pMLogTrdT;

typedef struct MDelOrdrS
{
    OrderFT     orderF;
    MtchInfoT   mtchInfo;
    int64       tranTime;
    SlotT       slot;
    uint16      actnMask;
    int16       setId;
    BOOL        delFlg;
} MDelOrdrT, *pMDelOrdrT;

typedef struct MModOrdQtyS
{
    OrderFT           oldOrdr;
/* following 4 fields are for updated order */
    int64     exeQty;
    int64     remPkQty;
    int64     tranTime;
    int64     exePrc;
    SlotT     slot;
    uint16    actnMask;
    int16     setId;  
} MModOrdQtyT, *pMModOrdQtyT;

typedef struct MModOrdrS
{

    SlotT           slot;
    SlotT           oldPrcLder;

    SlotT           newPrcLder;
    uint16          actnMask;
    char            fNewPrcLder;
    char            filler;
    
    OrderFT         oldOrdr;
    OrderFT         newOrdr;
    MtchInfoT       mtchInfo;
    int16           setId;
    char            filler1[6];
} MModOrdrT, *pMModOrdrT;

typedef struct MMktDatPushS
{
    int64       eventId;
} MMktDatPushT, *pMMktDatPushT;


typedef struct SubOrdrS
{
    OrderFT         ordrF;
    SlotT           slot;
    char            filler[4];
} SubOrdrT, *pSubOrdrT;

typedef struct MLogOcoOrdrS
{
    int64               specOrdrNo;
    int32               bidSlotCnt;
    int32               askSlotCnt;
    int16               ordrSts;
    int16               ordrAct;
    int16               setId;
    char                filler[2];
} MLogOcoOrdrT, *pMLogOcoOrdrT;


typedef struct MFlushMktDatS
{
    int32               setId;
    int32               filler;
    int64               timestamp;
} MFlushMktDatT, *pMFlushMktDatT;

typedef struct MUpdtCrdtByTrdS
{
    int32               setId;
    int32               filler;
    CrdtMgmtUpdtT       crdtMgmtUpdt;
} MUpdtCrdtByTrdT, *pMUpdtCrdtByTrdT;


typedef struct MPrdctInfoUpdtS
{
    int32           prdctId;
    int32           filler;
    PrdctBaseInfoT  prdctBaseInfo;
} MPrdctInfoUpdtT, *pMPrdctInfoUpdtT;

typedef struct MBrdgMktDatPushS
{
    int32           setId;
    int32           filler;
    OrderFT         brdgOrdrF;
} MBrdgMktDatPushT, *pMBrdgMktDatPushT;

typedef struct MBrdgOrdrUpdtS
{
    int32               setId;
    int32               updtType;
    BrdgOrdrRcrdT       brdgOrdr;
} MBrdgOrdrUpdtT, *pMBrdgOrdrUpdtT;
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
void InitRspDat(pNewOrderSingleRspT pOrderRsp );

ResCodeT MtchrInit(int32 set);
ResCodeT MtchrDetach(int32 set);
ResCodeT MtchrPrcsOrdrAdd(BOOL bRcrvOrdrFlg, BOOL bBrdgMtchOn, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp, pMtchInfoT pMtchInfo);
ResCodeT MtchrCreateOrdrFromOrdrInfo(int32 set, NewOrderInfoT * pNewOrder, pOrderT * ppOrder, BOOL bBilOrdr, pOrdrPrcQtyInfoT pBilAskPrcQtyInfo);  
ResCodeT MtchrPrcsOrdrCancel(int32 setId, int32 ordrSts,pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOrdrActive(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOrdrWthdr(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOrdrSave(BOOL bRcrvOrdrFlg, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);

/* Bil Order Process */
ResCodeT MtchrPrcsBilOrdrAdd(BOOL bRcrvOrdrFlg, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pAskOrder,pOrderT pBidOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp, pMtchInfoT pMtchInfo);
ResCodeT MtchrPrcsBilOrdrSave(BOOL bRcrvOrdrFlg, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pAskOrder,pOrderT pBidOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsBilOrdrCancel(int32 setId, int32 ordrSts, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsBilOrdrActive(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsBilOrdrWthdr(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);

/*for OCO order*/
ResCodeT MtchrPrcsOcoOrdrAdd(BOOL bRcrvOrdrFlg, int32 setId,
                            OCOFirstT *       pOcoHdr, 
                            int32 bidOrdrCnt, NewOrderInfoT * pBidOrder,
                            int32 askOrdrCnt, NewOrderInfoT * pAskOrder, 
                            int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOcoOrdrSave(BOOL bRcrvOrdrFlg, int32 setId,
                            OCOFirstT *       pOcoHdr, 
                            int32 bidOrdrCnt, NewOrderInfoT * pBidOrder,
                            int32 askOrdrCnt, NewOrderInfoT * pAskOrder, 
                            int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOcoOrdrActive(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);                            
ResCodeT MtchrPrcsOcoOrdrCancel(int32 setId, int32 ordrSts, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);                            
ResCodeT MtchrPrcsOcoOrdrWthdr(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp);

/*for memory udate*/
ResCodeT MtchAddOrdr(BOOL bNeedMemTxn, BOOL bRcvrFlg, int32 set, uint16 actnMask,pOrderT pOrder, MtchInfoT * pMtchInfo, pMAddOrdrT  pRcvrAddOrdrAddr);
ResCodeT MtchLogOrdr(BOOL bNeedMemTxn, int32 set, uint16 actnMask,pOrderT pOrder, MtchInfoT * pMtchInfo);
ResCodeT MtchDelOrdr(BOOL bNeedMemTxn, int32 setId, pOrderT *order,
                int64 tranTime,
                uint16 actnMask,
                pMtchInfoT pMtchInfo,
                pPrdctInfoT pPrdctInfo,
                BOOL delFlg);
ResCodeT MtchLogTrd(BOOL bNeedMemTxn, int32 set, uint16 actnMask, int64 oldOrdrNo, MtchTrdT * pMtchTrd);
ResCodeT MtchModOrdr(BOOL bNeedMemTxn, BOOL bRcvrFlg, int32 set, pOrderT *pOldOrdr,
                    const pOrderFT newOrdr,
                    int32 actnMask,
                    MtchInfoT * pMtchInfo,
                    pMModOrdrT      pRcvrModOrdrAddr);
ResCodeT MtchModOrdrQty(BOOL bNeedMemTxn, int32 set, pOrderT oldOrdr,
                int64 exeQty,
                int64 exePrc,
                int64 tranTime,
                uint16 actnMask);
ResCodeT MtchSaveBilOrdr(BOOL bNeedMemTxn, int32 set,int16 ordrAct, uint16 ordrSts, pOrderT pBidOrder, pOrderT pAskOrder, SlotT bidSlot, SlotT askSlot);
ResCodeT MtchMktDatPush(BOOL bNeedMemTxn, int32 set);
ResCodeT MtchLogOcoOrdr(BOOL bNeedMemTxn, int32 set,  int64 ocoOrdrNo,int16 ordrAct, uint16 ordSts, int32 bidCnt, pOrderT pBidOrderArr[], int32 askCnt, pOrderT pAskOrderArr[]);
ResCodeT MtchFlushMktDat(BOOL bNeedMemTxn,int32 set, int64 timestamp );
ResCodeT MtchUpdCrdtByTrd(BOOL bNeedMemTxn, int32 setId,pCrdtMgmtUpdtT pCrdtMgmtUpdt);
ResCodeT MtchUpdtPrdctInfo(BOOL bNeedMemTxn,int64 prdctId, pPrdctBaseInfoT pPrdctBaseInfo);
ResCodeT MtchBrdgMktPush(BOOL bNeedMemTxn, int32 setId, pOrderFT pBrdgOrdr);
ResCodeT MtchBrdgOrdrUpdt(BOOL bNeedMemTxn, int32 setId, int32 updtType, pBrdgOrdrRcrdT pBrdgOrdrRcrd); 
/* Other usage */                
int32   MtchGetOrdrStsByActMnt(int32 actnMask);
ResCodeT DelOrdrFromMgmtLst(int32 set, int64 ordrNo);
ResCodeT AddOrdrToMgmtLst(int32 set, int32 ordrSts, int32 ordType, pOrderT pOrder, int64 * pOrdrMgmtPos);
ResCodeT MtchSaveOrdr(BOOL bNeedMemTxn, int32 set, uint16 actnMask,pOrderT pOrder);
ResCodeT MtchrPrcsOrdrExpireChk(int32 setId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOrdrBrdg(int32 setId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsFlushMktDat(int32 setId);
ResCodeT MtchrPrcsOrdrCnclByUser(int32 setId, int64 timestamp,int32 usrPos,int32 orgPos, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsFreezeOrgOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsFreezeOrgOrdr(int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsCnclOrgOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsOrdrFreezeByUser(int32 setId, int64 timestamp,int32 usrPos,int32 orgPos, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsApiOrdrCncl(int32 setId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT FmtDealCnclCnfrm( int32 setId, pTradeDatT pTradeDat, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsCnclOrgOrdrByUsr(uint32 usrPos, uint32 orgPos, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsCnclClsPosnOrgOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchrPrcsFreezeOrgClsPosnOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp);
#endif /* _MATCH_LIB_ */
