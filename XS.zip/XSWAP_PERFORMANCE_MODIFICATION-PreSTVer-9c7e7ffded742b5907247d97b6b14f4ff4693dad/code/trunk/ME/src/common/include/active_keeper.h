/***
Created on Aug 16, 2017
@author: Jiawang.Xie
@version $Id
***/

#ifndef _ACTIVE_KEEPER_H_
#define _ACTIVE_KEEPER_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files */
#include "data_type.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

typedef enum
{
    HA_LOCK_INIT = 0,
    HA_PRIMARY_LOCK_START,
    HA_PRIMARY_LOCK_FAILED,
    HA_PRIMARY_LOCKING,
    HA_BACKUP_LOCK_START,
    HA_BACKUP_LOCK_FAILED,
    HA_BACKUP_LOCKING
} HaLockStatusT;

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT SetPrimary(int64 iSetId, const char* host);
ResCodeT GetPrimary(int64 iSetId, char* host);
ResCodeT SetBackup(int64 iSetId, const char* host);
ResCodeT GetBackup(int64 iSetId, char* host);
ResCodeT GetHaTime(int64 iSetId, char* haTime);

ResCodeT IsPrimary(int64 iSetId, BOOL* blIsPrimary);
ResCodeT IsBackup(int64 iSetId, BOOL* blIsBackup);
ResCodeT IsHaBegin(int64 iSetId, BOOL* isBegin);


void* HaThreadMain(void * args);
ResCodeT ActiveKeeperInitWithoutConn();
//ResCodeT ActiveKeeperInit(int32 iConnId);
ResCodeT ActiveKeeperStop();
ResCodeT InitPrimary(int64 iSetId);
ResCodeT InitBackup(int64 iSetId);
ResCodeT BackupTakeover(int64 iSetId, BOOL* blTackover);
ResCodeT GetAllSetIds(vectorT * setIds);
ResCodeT GetLocalLockStatus(int16& status);

ResCodeT SendMsgToGateway(int64 iSetId);

#endif /* _ACTIVE_KEEPER_H_ */
