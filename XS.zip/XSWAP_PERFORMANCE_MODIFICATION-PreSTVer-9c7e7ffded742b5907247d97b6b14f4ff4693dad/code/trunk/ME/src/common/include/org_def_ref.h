/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _ORG_DEF_REF_
#define _ORG_DEF_REF_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files */
#include "data_type.h"
#include "common_macro.h"
#include "msg_type.h"
#include "msg_common_value.h"

#include "org_info.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
 #define MAX_ORG_MARKET_COUNT 5

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct OrgMemDataRefS {
    IntrnlMsgTypeT  eMessageType;                    /* Message type */
    char  strUserId[MAX_USR_ID_LENTH];               /* 用户ID */
    char  strOpUserId[MAX_USR_ID_LENTH];             /* 被处理用户ID */
    char  strOpOrgId[MAX_ORG_ID_LENTH];              /* 被处理机构ID */
    int32 intOrgId;                                  /* 授信机构标识 */
    int32 intSt;                                     /* 状态 */
    int32 intMktTp;                                  /* 用户市场类型 */
    int32 intOrgMktSt[MAX_ORG_MARKET_COUNT];         /* 机构市场状态 */
    int32 intUpdUsrMktFlg;                           /* 更新用户市场标识 */
    int32 intUpdBrdgOrdFlg;                          /* 更新桥单标识 */
    int16 rqstType;
    char  strUpdTm[MAX_TIME_LENGTH];                 /* 更新时间 */
} OrgMemDataRefT, *pOrgMemDataRefT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*** common db interface ***/

/*** org ****/
ResCodeT OrgMemRef(void *pData, int32 dataLen);
ResCodeT OrgDbRef(int32 connId, void *pData, int32 dataLen);
ResCodeT OrgDataPrintRef(void *pData, int32 dataLen);
#endif /* _ORG_DEF_REF_ */
