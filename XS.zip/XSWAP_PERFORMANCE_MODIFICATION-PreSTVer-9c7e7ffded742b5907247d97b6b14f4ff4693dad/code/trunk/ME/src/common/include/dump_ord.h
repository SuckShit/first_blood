﻿/***
Created on June 20, 2017
@author: 
@version $Id
***/


#ifndef _DUMP_ORDR_H_
#define _DUMP_ORDR_H_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "DlDb.h"
#include "OrdrDb.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MEM_TXN_DUMP_TO_DB_RUN      1
#define MEM_TXN_DUMP_TO_DB_END      0


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT GetOrderSide(int32 oMask, char *side);
ResCodeT GetTradingRestriction(int32 oMask, char *trdrestr);
ResCodeT GetOrderType(int32 oMask, char *type);    
 
ResCodeT DumpOrdInit(int32 set );
 
ResCodeT DumpOrdrFromMemTxn(int32 setId, int64 fromTxnId, int64 toTxnId, int32 *pTxnId);

void* MatchingDumptxnThread( void *pRunFlag );

#endif /* _DUMP_ORDR_H_ */