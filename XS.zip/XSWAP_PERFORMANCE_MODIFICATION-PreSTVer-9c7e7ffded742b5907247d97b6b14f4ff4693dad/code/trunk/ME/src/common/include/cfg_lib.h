﻿/***
Created on June 13, 2017
@author: No One
@version $Id
***/

/*****************************************************************************
**
**  Header File
**
*****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "UTILITY/logfile.h"
#include "Utils.h"

/*****************************************************************************
**
** Type Defination
**
*****************************************************************************/
typedef struct cfgValueS
{
    char    homePath[MAX_CFG_VAL_LEN];
    char    cfgPath[MAX_CFG_VAL_LEN];
    char    envNo[MAX_CFG_VAL_LEN];
    char    prcsRole;
    int32   prcsId;

    int32   iPerfMonIntrval;
    int32   iMktDatPushIntrval;
    int32   iMaxMsgCacheSlotCnt;
    int32   iMaxSecondLevelSlotCnt;
    int32   iMaxThreadCnt;
    int32   iIntrnlQueueSize;
    
    int32   setId;
    int32   nmbrOfTxn;
    int32   dataSize;
    int32   shlTxn;
    int32   rplyIntrvl;
    
    int32   ttlOrdrNmbr;
    int32   ttlPrdctNmbr;
    int32   ttlEntyNmbr;
    
    int32   needDbSupport;
    char    dbInst[MAX_CFG_VAL_LEN];
    char    dbName[MAX_CFG_VAL_LEN];
    char    dbPwd[MAX_CFG_VAL_LEN];

    int32   monSleepTim;
} CfgValueT, *pCfgValueT;

/*****************************************************************************
**
** Macro
**
*****************************************************************************/

/******************************************************************************
**
**  Type Defination
**
******************************************************************************/

/******************************************************************************
**
**  Type Defination
**
******************************************************************************/

/******************************************************************************
**
** Function Declaration
**
******************************************************************************/
ResCodeT GetStrCfgValue(char* secNm,char*keyNm, char*pValue);

ResCodeT GetIntCfgValue(char* secNm,char*keyNm, int32*pValue);

ResCodeT CfgInit(char*cfgPath);

ResCodeT GetCfgValue(struct cfgValueS *ret);
