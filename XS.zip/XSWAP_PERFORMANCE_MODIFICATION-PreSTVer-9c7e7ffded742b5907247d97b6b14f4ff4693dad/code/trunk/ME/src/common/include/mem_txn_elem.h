﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _MEM_TXN_ELEM_
#define _MEM_TXN_ELEM_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MT_TYPE_END         -1
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef enum
{
    MT_TYPE_ALL = 0,
    /* Add new memory txn element type BELOW */
    MT_TYP_ODR_LOG,
    MT_TYP_ODR_ADD,
    MT_TYP_ORD_DEL,
    MT_TYP_TRD_LOG,
    MT_TYP_ODR_MOD,
    MT_TYP_ORD_MOD_QTY,
    MT_TYP_ORD_SAVE,
    MT_TYP_BIL_ORD_SAVE,
    MT_TYP_MKT_DAT_PUSH,
    MT_TYP_LOG_OCO,
    MT_TYP_REF_DAT_UPT,
    MT_TYP_FLUSH_MKT,
    MT_TYP_CRDT_UPDT_BY_TRD,
    MT_TYP_PRDCT_INFO_UPDT,
    MT_TYP_BRDG_MKT_DAT_PUSH,
    MT_TYP_BRDG_ORD_UPDT,
    /* Add new memory txn element type ABOVE */
    MT_TYPE_MAX
}MTElemTypeT;



typedef struct MTElemPrcsCtxS
{   
    int32 set;
} MTElemPrcsCtxT, *pMTElemPrcsCtxT;



typedef ResCodeT (*MTElemUpdateCallbackT)(BOOL bNeedMemTxn, MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

typedef ResCodeT (*MTElemRollbackCallbackT)(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

typedef struct MTElemPrcsInfoS
{   
    MTElemTypeT                 elemType;
    MTElemUpdateCallbackT       fUpdateCallBack;
    MTElemRollbackCallbackT     fRollbackCallBack;
} MTElemPrcsInfoT, *pMTElemPrcsInfoT;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT MemTxnElemDataAdd(BOOL bNeedMemTxn,int32 set, MTElemTypeT, void * pData, int32 dataSize);

ResCodeT MemTxnElemDataMinus(BOOL bNeedMemTxn,int32 set, MTElemTypeT, void * pData, int32 dataSize);

/* For MT_TYP_ODR_LOG */
ResCodeT OrdrLogForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT OrdrLogForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_ODR_ADD */
ResCodeT OrdrAddForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT OrdrAddForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_ORD_DEL */
ResCodeT OrdrDelForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT OrdrDelForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_TRD_LOG */
ResCodeT TrdLogForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT TrdLogForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_ODR_MOD */
ResCodeT OrdrModForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT OrdrModForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_ORD_MOD_QTY */
ResCodeT OrdrModQtyForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT OrdrModQtyForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_ORD_SAVE */
ResCodeT OrdrSaveForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT OrdrSaveForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);


/* For MT_TYP_BIL_ORD_SAVE */
ResCodeT BilOrdrSaveForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT BilOrdrSaveForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_MKT_DAT_PUSH */
ResCodeT MktDatPushForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT MktDatPushForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_LOG_OCO */
ResCodeT LogOcoForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT LogOcoForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);


/* For MT_TYP_REF_DAT_UPT */
ResCodeT RefDatUptForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT RefDatUptForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/* For MT_TYP_FLUSH_MKT */
ResCodeT FlushMktDatForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT FlushMktDatForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);


/* For MT_TYP_CRDT_UPDT_BY_TRD */
ResCodeT UpdtCrdtByTrdForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT UpdtCrdtByTrdForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);


/* For MT_TYP_PRDCT_INFO_UPDT */
ResCodeT PrdctInfoUpdtForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT PrdctInfoUpdtForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);



/* For MT_TYP_BRDG_MKT_DAT_PUSH */
ResCodeT BrdgMktDatPushForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT BrdgMktDatPushForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);



/* For MT_TYP_BRDG_ORD_UPDT */
ResCodeT BrdgOrdUpdtForLoadMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);
ResCodeT BrdgOrdUpdtPushForRlbkMemTxn(BOOL bNeedMemTxn,MTElemTypeT elemType, void * pData, int32 dataType, pMTElemPrcsCtxT pCtx);

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static MTElemPrcsInfoT      gElemPrcsMatrix[] = {
    {MT_TYPE_ALL, NULL, NULL},
    /* Please add the new MT data type below */
    {MT_TYP_ODR_LOG,            OrdrLogForLoadMemTxn,        OrdrLogForRlbkMemTxn},
    {MT_TYP_ODR_ADD,            OrdrAddForLoadMemTxn,        OrdrAddForRlbkMemTxn},
    {MT_TYP_ORD_DEL,            OrdrDelForLoadMemTxn,        OrdrDelForRlbkMemTxn},
    {MT_TYP_TRD_LOG,            TrdLogForLoadMemTxn,         TrdLogForRlbkMemTxn},
    {MT_TYP_ODR_MOD,            OrdrModForLoadMemTxn,        OrdrModForRlbkMemTxn},
    {MT_TYP_ORD_MOD_QTY,        OrdrModQtyForLoadMemTxn,     OrdrModQtyForRlbkMemTxn},
    {MT_TYP_ORD_SAVE,           OrdrSaveForLoadMemTxn,       OrdrSaveForRlbkMemTxn},
    {MT_TYP_BIL_ORD_SAVE,       BilOrdrSaveForLoadMemTxn,    BilOrdrSaveForRlbkMemTxn},
    {MT_TYP_MKT_DAT_PUSH,       MktDatPushForLoadMemTxn,     MktDatPushForRlbkMemTxn},
    {MT_TYP_LOG_OCO,            LogOcoForLoadMemTxn,         LogOcoForRlbkMemTxn},
    {MT_TYP_REF_DAT_UPT,        RefDatUptForLoadMemTxn,      RefDatUptForRlbkMemTxn},
    {MT_TYP_FLUSH_MKT,          FlushMktDatForLoadMemTxn,    FlushMktDatForRlbkMemTxn},
    {MT_TYP_CRDT_UPDT_BY_TRD,   UpdtCrdtByTrdForLoadMemTxn,  UpdtCrdtByTrdForRlbkMemTxn},
    {MT_TYP_PRDCT_INFO_UPDT,    PrdctInfoUpdtForLoadMemTxn,  PrdctInfoUpdtForRlbkMemTxn},
    {MT_TYP_BRDG_MKT_DAT_PUSH,  BrdgMktDatPushForLoadMemTxn, BrdgMktDatPushForRlbkMemTxn},
    {MT_TYP_BRDG_ORD_UPDT,      BrdgOrdUpdtForLoadMemTxn,    BrdgOrdUpdtPushForRlbkMemTxn}    
};


#endif /* _MEM_TXN_ELEM_ */
