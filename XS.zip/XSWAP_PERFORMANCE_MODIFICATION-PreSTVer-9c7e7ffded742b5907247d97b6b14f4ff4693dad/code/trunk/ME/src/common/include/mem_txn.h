﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _MEM_TXN_
#define _MEM_TXN_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
#include "intrnl_msg.h"
#include "mem_txn_elem.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define NO_DATA_SQNO        (NULL_SLOT)

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MemBkCfgS
{
    int32 setId;
    int32 nmbrOfTxn;
    int32 dataSize;
} MemTxnCfgT, *pMemTxnCfgT;

/* Share memory control section */
typedef struct ShmInfoS
{
    int64   memTtlSize;
    int32   setCnt;
    int32   filler;
} ShmInfoT, *pShmInfoT;

typedef struct SetShmInfoS
{
    int32   setId;
    int32   filler;
    int32   maxTxnCnt;
    int32   dataSize;
    int64   memTxnAreaSize;
    int64   memDataAreaSize;
} SetShmInfoT, *pSetShmInfoT;

/* Txn data section */
typedef struct MemTxnCtrlS
{
    int32   currTxnId;
    int32   commitTxnId;
    int32   maxTxnId;
    
    int32   currDataCnt;
    int32   maxDataCnt;
    int32   elemCnt;
    int32   currMsgSqno;
    int32   filler;

} MemTxnCtrlT, *pMemTxnCtrlT;

typedef struct MemTxnEntryS
{
    int32    txnId;
    int32    txnSts;
    int32    dataCnt;
    int32    frstDataSqno; /* Link the first data sqno */
    int32    lstDataSqno; /* Link the last data sqno for rollback */
    int32    dataSize;   /* Tells the data entry size, always same for each data entry. */
    int64    timestamp;

} MemTxnEntryT, *pMemTxnEntryT;


/* We need rotate the memory structure in order to support batch insert natively */
typedef struct RtDatCtrlS
{
    int32 *     pDataSqno;
    int32 *     pElemTtlSize;
    int32 *     pElemCnt;
    
    int32 *     prevDataSqno;
    int32 *     nextDataSqno;
    int32 *     currMsgSqno;
    
    void *      pRtElemAddr;
} RtDatCtrlT, *pRtDatCtrlT;

/* we need make sure DataCtrlT and RtDatCtrlT has the same number of field */
typedef struct DatCtrlS
{
    int32       dataSqno;
    int32       elemTtlSize;
    int32       elemCnt;
    
    int32       prevDataSqno;
    int32       nextDataSqno;
    int32       currMsgSqno;
} DatCtrlT, *pDatCtrlT;

typedef struct DatElemHdrS
{
    int32           elemSqno;
    int16           elemType;
    int16           elemSize;
} DatElemHdrT, *pDatElemHdrT;


typedef enum
{
    TXN_STS_INIT = 0,
    TXN_STS_OPEN,
    TXN_STS_COMMIT,
    TXN_STS_ROLLBACK,
    TXN_STS_INVLD
}TxnStsTypeT;


typedef ResCodeT (*MemTxnPrcsData)(void * pData,
                    int32 dLen,
                    MTElemTypeT elemType,
                    void * pCtx);

typedef ResCodeT (*MemTxnPrcsDataDone)(int32 setId,
                    int64 txnId,
                    void * pCtx);
                    
typedef struct MemTxnCallBackS
{
    MemTxnPrcsData          PrcsData;
    MemTxnPrcsDataDone      PrcsDataDone;

    void    *               pCtx4PrcsData;
    void    *               pCtx4PrcsDataDone;
} MemTxnCallBackT, *pMemTxnCallBackT;


typedef struct MemTxnUserModeS
{
    MemTxnCallBackT      callBack;

    BOOL                readOnly;
    MTElemTypeT *       pElemTypeArry;
} MemTxnUserModeT, *pMemTxnUserModeT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT MemTxnShmCreateForAllSet(pMemTxnCfgT pMemTxnCfg, int32 cfgCnt);
ResCodeT MemTxnShmDetach();
ResCodeT MemTxnShmDelete();

ResCodeT MemTxnShmInit(int32 setId);
ResCodeT MemTxnStart(int32 set, int64* pTxnId, int64 * pTimestamp);
ResCodeT MemTxnCommit(int32 set);
ResCodeT MemTxnRollback(int32 set);
ResCodeT MemTxnAddElem(int32 set, MTElemTypeT elemType, void * pData, int32 dataLen);



ResCodeT MemTxnAddElemPrep(int32 set,MTElemTypeT elemType, int32 dataLen, void ** ppData );
ResCodeT MemTxnAddElemClose();

ResCodeT MemTxnIterElem(int32 set, int32 startTxnId,int32 endTxnId, MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen);
ResCodeT MemTxnIterElemNext(int32 set, int32 * currTxnId, MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen);

/* For monitor */
ResCodeT MemTxnGetTxnInfo(int32 set, int64 txnId, pMemTxnCtrlT pTxnCtrl, pMemTxnEntryT pTxnEntry );
ResCodeT MemTxnGetDataInfo(int32 set, int64 dataSqno, pDatCtrlT pDatCtrl );
ResCodeT MemTxnGetTxnEntryExt(int32 set, int64 txnId,  pMemTxnEntryT * ppTxnEntry );
ResCodeT MemTxnGetDataRootAddr(int32 set, pRtDatCtrlT pRtDataCtrl, int32 frstDataSqno);
ResCodeT FmtTxnMsgBuff(pRtDatCtrlT pRtDataCtrl, pMemTxnEntryT  pTxnEntry, void * pData, int32 * pDataLen, int32 * pDatIdx);
ResCodeT MemTxnIterElemFromBuff(void * pInBuff,  MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen);
ResCodeT GetElemAddrFromHead(void * pHeadAddr, pDatElemHdrT * ppHdrAddr, void ** ppData,int32 * pDataSize);
/* For load mem txn share memory */
ResCodeT MemTxnLoadDatFromTxnId(int32 set, int64 fromTxnId, int64 * pOutTxnId);

ResCodeT MemTxnRegisterElemType(MTElemTypeT * pElemType);
ResCodeT MemTxnRegisterUserMode(pMemTxnUserModeT pUserMode);
ResCodeT MemTxnRetrieveData(int32 setId, int64 lowTxnId, int64 highTxnId, int64 * pMaxTxnId);

ResCodeT MemTxnGetDatByMsgSqno(int32 set, int32 msgSqno, void * pData, int32 * pDataLen, int32 cfgDataSize);
ResCodeT MemTxnGetDatByMsgSqnoInit(int32 set);
#endif /* _MEM_TXN_ */
