/***
Created on May 08, 2017
@author: No One
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _THREAD_LOCK_FREE_
#define _THREAD_LOCK_FREE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/eventfd.h>            /* define string handling functions     */
#include <time.h>                   /* define time functions     */
#include <unistd.h>                   /* define time functions     */
/* Project Header files*/


/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#if ! defined(CACHE_ALIGN_SIZE)
#   define CACHE_ALIGN_SIZE 128
#if defined (__GNUC__)
#   define CACHE_ALIGN __attribute__((aligned(CACHE_ALIGN_SIZE)))
#else
#   define CACHE_ALIGN
#endif
#endif




/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#ifndef TRUE
#define TRUE   (1)
#endif

#ifndef FALSE
#define FALSE  (0)
#endif

#define WRITTEN_FLAG (1)

#define ENTRY_STATE_SIZE (1)

#define STATIC_FORCE_INLINE \
        static inline __attribute__((always_inline))


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct  ThreadLockFreeQCfgTag
{
    size_t      entryCapacity;
    unsigned    entrySize;
}ThreadLockFreeQCfgT, *pThreadLockFreeQCfgT;

typedef struct ThreadLockFreeQTag {
/*   reducedSize =   entryCapacity-1 ,
  *   if entryCapacity = 2^n then
  *   x % entryCapacity = x & reducedSize
*/
    CACHE_ALIGN uint_fast64_t reducedSize;

    CACHE_ALIGN uint_fast64_t writeCursor;  //the latest write position

    CACHE_ALIGN uint_fast64_t readCursor;   //the position reader is reading

    int lfqFd;     //eventFd, to notify that the LFQ is ready for reading

    ThreadLockFreeQCfgT conf;

    char buffer[];   //point to the LFQ buffer following this struct

}ThreadLockFreeQT, *pThreadLockFreeQT;

typedef struct ThreadLockFreeQHndlTag
{
    uint_fast64_t  localWriteCursor;   //record the local writing position
    uint_fast64_t  localReadCursor;    //record the local reading position
    ThreadLockFreeQT *pThreadLfq;
}ThreadLockFreeQHndlT, *pThreadLockFreeQHndlT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
//when the LFQ is full,the time publisher to wait
static const struct timespec timeoutPublisher__ = { 0, 64000000 };
//when fail to grab write position,the time publisher to wait
static const struct timespec timeoutBreak__ = { 0, 2000000 };

//the following para is used by eventfd and writev()
static  uint_fast64_t eventfdDelta = 1;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*
 *publiser to accquire write position by blocking mode
 */
STATIC_FORCE_INLINE
void PublishNextEntryBlocking(ThreadLockFreeQT * const pLfq,
                    uint_fast64_t * __restrict__ const cursor)
{
    uint_fast64_t incur;
again:
    incur = 1 + pLfq->writeCursor;
    if (!__sync_bool_compare_and_swap(&pLfq->writeCursor,incur - 1,incur)){
        nanosleep(&timeoutBreak__,NULL);
        goto again;
    }
    *cursor = incur;
    do {
        if (incur <= pLfq->reducedSize + pLfq->readCursor)
            return;
        nanosleep(&timeoutPublisher__, NULL);
    } while (TRUE);
}

/*
 *publiser to accquire write position by nonblocking mode
 */
STATIC_FORCE_INLINE
int PublishNextEntryNonBlocking(ThreadLockFreeQT * const pLfq,
                                uint_fast64_t * __restrict__ const cursor)
{
    uint_fast64_t oldCur = 0;
    uint_fast64_t incur = 0;

again:
    oldCur =  pLfq->writeCursor;
    incur =  1 + oldCur;
    if (incur <= pLfq->reducedSize + pLfq->readCursor){
        if (__sync_bool_compare_and_swap(&pLfq->writeCursor, oldCur, incur)){
            *cursor = incur;
            return TRUE;
        }
        goto again;
    }
    while (write(pLfq->lfqFd,&eventfdDelta,sizeof(eventfdDelta))
                < (int)sizeof(eventfdDelta));

    return FALSE;
}

/*
 *process to accquire read position by nonblocking mode
 */
STATIC_FORCE_INLINE
int PrcsWaitForNonBlocking(ThreadLockFreeQT * const pLfq,
                uint_fast64_t * __restrict__ const cursor)
{
    uint_fast64_t tmpVal;
    const uint_fast64_t incur = pLfq->readCursor + 1;
    volatile char *index = (incur & pLfq->reducedSize) * (pLfq->conf.entrySize + ENTRY_STATE_SIZE) + pLfq->buffer;
    int ret;
    if (!(*index)){
        read(pLfq->lfqFd,&tmpVal,sizeof(tmpVal));
        if (*index){
            *cursor = incur;
            pLfq->readCursor++;
        again:
            ret = write(pLfq->lfqFd,&eventfdDelta,sizeof(eventfdDelta));
            if (ret < (int)sizeof(eventfdDelta))
                goto again;
            return TRUE;
        }
        return FALSE;
    }


    *cursor = incur;
    pLfq->readCursor++;

    return TRUE;
}

/*
 * publisher push data into LFQ by blocking mode
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQBlockingPush(ThreadLockFreeQHndlT * const pLfqHdl,
                                    const void * const src,size_t const size)
{
    ThreadLockFreeQT *pLfq = pLfqHdl->pThreadLfq;
    uint_fast64_t offset;
    char *dst,*index;
    int ret;

    PublishNextEntryBlocking(pLfq,&pLfqHdl->localWriteCursor);

    offset = pLfqHdl->localWriteCursor & pLfq->reducedSize;
    dst = pLfq->buffer + offset * (pLfq->conf.entrySize + ENTRY_STATE_SIZE) + ENTRY_STATE_SIZE;

    memcpy(dst,src,size);

    index = dst - ENTRY_STATE_SIZE;
    *index = WRITTEN_FLAG;

    __sync_synchronize();

    if (pLfq->readCursor == pLfqHdl->localWriteCursor - 1){
    again:
        ret = write(pLfq->lfqFd,&eventfdDelta,sizeof(eventfdDelta));
        if (ret < (int)sizeof(eventfdDelta))
            goto again;
    }

    return TRUE;
}

/*
 * publisher push data into LFQ by nonblocking mode
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQNonBlockingPushFix(ThreadLockFreeQHndlT * const pLfqHdl,
                                  const void * const src,size_t const size)
{
    ThreadLockFreeQT *pLfq = pLfqHdl->pThreadLfq;
    uint_fast64_t offset;
    char *dst,*index;
    int ret;
    
    if (!PublishNextEntryNonBlocking(pLfq,&pLfqHdl->localWriteCursor))
        return FALSE;
    
    offset = pLfqHdl->localWriteCursor & pLfq->reducedSize;
    dst = pLfq->buffer + offset * (pLfq->conf.entrySize + ENTRY_STATE_SIZE) + ENTRY_STATE_SIZE;
    
    memcpy(dst,src,size);
    
    index = dst - ENTRY_STATE_SIZE;
    *index = WRITTEN_FLAG;
    
    __sync_synchronize();
    
    if (pLfq->readCursor == pLfqHdl->localWriteCursor - 1){
    again:
        ret = write(pLfq->lfqFd,&eventfdDelta,sizeof(eventfdDelta));
        if (ret < (int)sizeof(eventfdDelta))
            goto again;
    }
    
    return TRUE;
}

/*
 * publisher push data into LFQ by nonblocking mode
 * and always trigger
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQNonBlockingPush(ThreadLockFreeQHndlT * const pLfqHdl,
                                        const void * const src,size_t const size)
{
    ThreadLockFreeQT *pLfq = pLfqHdl->pThreadLfq;
    uint_fast64_t offset = 0;
    char *dst = NULL;
    char *index = NULL;

    if (!PublishNextEntryNonBlocking(pLfq,&pLfqHdl->localWriteCursor))
        return FALSE;

    offset = pLfqHdl->localWriteCursor & pLfq->reducedSize;
    dst = pLfq->buffer + offset * (pLfq->conf.entrySize + ENTRY_STATE_SIZE) + ENTRY_STATE_SIZE;

    memcpy(dst,src,size);

    index = dst - ENTRY_STATE_SIZE;
    *index = WRITTEN_FLAG;

    __sync_synchronize();

    while (write(pLfq->lfqFd,&eventfdDelta,sizeof(eventfdDelta))
            < (int)sizeof(eventfdDelta));

    return TRUE;
}

/*
 * processor pop data from LFQ by nonblocking mode
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQNonBlockingPop(ThreadLockFreeQHndlT * const pLfqHdl,
                            void * const dst,size_t const size)
{
    ThreadLockFreeQT *pLfq = pLfqHdl->pThreadLfq;
    uint_fast64_t offset;
    char *src,*index;

    int retv = PrcsWaitForNonBlocking(pLfq,&pLfqHdl->localReadCursor);

    if (!retv)
        return FALSE;

    offset = pLfqHdl->localReadCursor & pLfq->reducedSize;
    src = pLfq->buffer + offset * (pLfq->conf.entrySize + ENTRY_STATE_SIZE) + ENTRY_STATE_SIZE;


    memcpy(dst,src,size);

    index = src - ENTRY_STATE_SIZE;
    *index = !WRITTEN_FLAG;

    return TRUE;
}

/*
 * accquire eventfd associate with lfq
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQGetEventFd(const ThreadLockFreeQT * const pLfq)
{
    if (pLfq)
    {
        return pLfq->lfqFd;
    }
    else
    {
        return -1;
    }
}

/*
 * calculate the memory size that LFQ occupy
 */
STATIC_FORCE_INLINE
size_t ThreadLckFreeQCalcMemSize(const ThreadLockFreeQCfgT *pConf)
{
    return (size_t)(sizeof(ThreadLockFreeQT) + pConf->entryCapacity * (pConf->entrySize + ENTRY_STATE_SIZE));
}

/*
 * initialize ThreadLockFreeQCfgT structure
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQInit(const ThreadLockFreeQCfgT *pConf,void *pmem,ThreadLockFreeQT **ppLfq)
{
    size_t memSize;
    ThreadLockFreeQT *pLfq = (ThreadLockFreeQT *)pmem;

    if (0 != (pConf->entryCapacity & (pConf->entryCapacity - 1)))
        goto err;

    if (-1 == (pLfq->lfqFd = eventfd(0,EFD_NONBLOCK))){
        goto err;
    }

    memSize = ThreadLckFreeQCalcMemSize(pConf);

    memset(pLfq->buffer,0,(size_t)(memSize - sizeof(ThreadLockFreeQT)));
    pLfq->readCursor = 0;
    pLfq->writeCursor = 0;
    pLfq->reducedSize = pConf->entryCapacity - 1;
    pLfq->conf = *pConf;

    *ppLfq = pLfq;
    return TRUE;
err:
    return FALSE;
}

/*
 * initialize ThreadLockFreeQHndlT structure
 * this function is used by publiser or processor in diff thread
 */
STATIC_FORCE_INLINE
int ThreadLckFreeQInitHndl(ThreadLockFreeQT * const pLfq,ThreadLockFreeQHndlT **ppLfqHdl)
{
    ThreadLockFreeQHndlT *pLfqHdl;

    if (NULL == (pLfqHdl = (ThreadLockFreeQHndlT *)malloc(sizeof(ThreadLockFreeQHndlT))))
        return FALSE;

    pLfqHdl->localReadCursor = 0;
    pLfqHdl->localWriteCursor = 0;
    pLfqHdl->pThreadLfq = pLfq;

    *ppLfqHdl = pLfqHdl;
    return TRUE;
}

STATIC_FORCE_INLINE
void ThreadLckFreeQFreeHndl(ThreadLockFreeQHndlT *pLfqHdl)
{
    free(pLfqHdl);
}

STATIC_FORCE_INLINE
uint_fast64_t ThreadLckFreeQGetSize(ThreadLockFreeQHndlT * const pLfqHdl)
{
    return pLfqHdl->pThreadLfq->reducedSize;
}

STATIC_FORCE_INLINE
uint_fast64_t ThreadLckFreeQUsedSize(ThreadLockFreeQHndlT * const pLfqHdl)
{
    uint_fast64_t ret = pLfqHdl->pThreadLfq->readCursor;
    __sync_synchronize();
    return  pLfqHdl->pThreadLfq->writeCursor -ret;
}

STATIC_FORCE_INLINE
uint_fast64_t ThreadLckFreeQFreeSize(ThreadLockFreeQHndlT * const pLfqHdl)
{
    uint_fast64_t used =
            pLfqHdl->pThreadLfq->writeCursor - pLfqHdl->pThreadLfq->readCursor;
    __sync_synchronize();
    return pLfqHdl->pThreadLfq->reducedSize - used;
}

#endif /* _THREAD_LOCK_FREE_ */
