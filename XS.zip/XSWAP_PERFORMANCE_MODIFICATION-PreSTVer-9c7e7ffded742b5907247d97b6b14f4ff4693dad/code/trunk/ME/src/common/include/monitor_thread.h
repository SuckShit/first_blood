/***
Created on Sep 26, 2017
@author: xuetao.bai
@version $Id
***/

#ifndef _MON_THREAD_UPDT_
#define _MON_THREAD_UPDT_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files */
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
#include "mem_txn_elem.h"
#include "msg_type.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define     MEM_TXN_MON_RUN             1             // thread running flag
#define     MEM_TXN_MON_END             0             // thread exit flag
#define     EXIT_FLAG                   0             // process exit flag
#define     THREAD_NAME_LEN             50
#define     THREAD_RUNNING              0             // running status
#define     THREAD_HALT                 1             // halt status
#define     THREAD_EXIT                 2             // exit status
#define     DEFAULT_SLEEP_TIME          1000000       // 1 second
#define     MAX_RETRY                   10
#define     PRINT_LINE_LENGTH           72

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef enum
{
    MON_TYPE_INIT = 0,
    /* Add new thead type BELOW */
    MON_THREAD_CALLBACK_TYP,
    MON_THREAD_DUMP_TYP,
    MON_THREAD_RESP_TYP,
    /* Add new thead type ABOVE */
    MON_TYPE_MAX
}MonThreadTypeT;

typedef struct MonTreadS
{
    MonThreadTypeT  threadType;
    int32           exitFlg;         // 1-exit when thread halt;0-update status only
    int64           lastCnt;         // sync from newCnt by monitor
    int64           newCnt;          // update by thread
    int64           timestamp;       // update by monitor
    int32           status;          // 0-running;1-halt;2-exit
    int32           retryCnt;        // retry count
    char            threadDesc[THREAD_NAME_LEN];
}MonTreadT, *pMonTreadT;

typedef struct MonTreadUpdtS
{
    int64           threadCnt;
    MonTreadT       monThreadNum[MON_TYPE_MAX];
}MonTreadUpdtT, *pMonTreadUpdtT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
void     MonThreadCntSync(MonThreadTypeT monType, int64 timestamp);
void     MonThreadSetState(MonThreadTypeT monType, int32 status);
ResCodeT MonRetryCntUpt(MonThreadTypeT monType);
ResCodeT MonThreadReg(MonThreadTypeT monType);
void     MonThreadUpt(MonThreadTypeT monType);
ResCodeT MonThreadSync(int64 timestamp);
ResCodeT MonThreadShmCreate();
ResCodeT MonThreadShmAttach();
ResCodeT PrintMonThread();
void* MonitorServThread(void * args);
#endif /* _REF_DAT_UPDT_ */
