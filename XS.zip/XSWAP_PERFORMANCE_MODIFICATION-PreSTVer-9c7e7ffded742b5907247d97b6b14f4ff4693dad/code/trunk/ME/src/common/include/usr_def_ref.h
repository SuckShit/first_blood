﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _USR_DEF_REF_
#define _USR_DEF_REF_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files */
#include "data_type.h"
#include "common_macro.h"
#include "msg_type.h"
#include "msg_common_value.h"

#include "UsrLgnHstryDb.h"
#include "UsrOnlnDb.h"
#include "msg_bridge_update.h"
#include "contract_info.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_CREDITINFO_COUNT    1000
#define MAX_RISKDATA_COUNT      100
#define MAX_USR_NM              100
#define MAX_CNTRCT_NM           50
#define MAX_CCP_CRDT_AMNT       99999900000000 
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/***** user interface *****/
typedef struct UserMemDataRefS
{
    IntrnlMsgTypeT  eMessageType;                   /* Message type */
    char            strUserName[MAX_USR_NM_LENTH];  /* User name */
    char            strCWUsrNm[MAX_USR_NM_LENTH];   /* CW User name */
    int32           intOrgId;                       /* 授信机构标识 */

    /* User online table info */
    char            sesnId[MAX_TOKEN_LENTH];
    int32           lgnTp;
    char            apiF[MAX_APIF_LENTH];

    /* User login history table info */
    char            oprtTp[MAX_OPRT_TP_LENTH];
    char            lgnIp[MAX_IP_LENTH];
    char            oprtTm[MAX_TIME_LENGTH];
} UserMemDataRefT, *pUserMemDataRefT;

/***** Api Subscribe/Un-Subscribe *****/
typedef struct ApiSubscribeDataRefS
{
    IntrnlMsgTypeT  eMessageType;                   /* Message type */
    char            strUserName[MAX_USR_NM_LENTH];  /* User name */
    int16           iRequestType;                   /* Request Type */
    int16           mktTp;                          /* market type */
    char            strCntRctCd[CONTRCT_NAME_LENGTH];
    int16           iMdBookType;
    int16           iMarketDepth;
    char            oprtTm[MAX_TIME_LENGTH];
    int64           iReqId;
} ApiSubscribeDataRefT, *pApiSubscribeDataRefT;

/***** trade privli config *****/
typedef struct TrdPrvlConfDataRefS
{
    char        strUsrId[MAX_USR_ID_LENTH];         /* 用户id */
    char        strTrdId[MAX_USR_ID_LENTH];         /* 交易员标识 */
    char        oprtTm[MAX_TIME_LENGTH];
    vectorT     allPrvls[GET_BIT_VECT_LEN(7)];      /* 提单权限汇总 */
} TrdPrvlConfDataRefT, *pTrdPrvlConfDataRefT;



/******* Credit *******/
typedef struct CreditInfoS {
    int32  intCrdtedOrgId;       // 被授信机构标识
    int32  intCrdtRlf;           // 授信关系标识
    uint64 intIntlCrdtAmnt;      // 初始授信额度
    int32  intCrdtTerm;          // 最长期限(年)
} CreditInfoT, *pCreditInfoT;

typedef struct CreditUpdateDataS {
    // Common
    IntrnlMsgTypeT  eMessageType;                   /* Message type */
    char strUserId[MAX_USR_ID_LENTH];               /* 用户标识 */
    int32 intOrgId;                                 /* 授信机构标识 */
    char strUpdTm[MAX_TIME_LENGTH];                 /* 更新时间 */

    // CreditModify(NULL)
    // CreditUnlock
    int32 intCheckOrg;                              /* 是否检查机构有效性 */

    // CreditRefreshMethodUpdate
    int32 intUpdMthd;

    // CreditUpdate&ApiCreditUpdate
    int32 intCrdtMthd;                              /* 授信方式 */
    int32 intCrdtVldOrgFlag;                        /* 授信有效标识 */
    int32 intCount;                                 /* 更新信息数量 */
    CreditInfoT crdtInfo[MAX_CREDITINFO_COUNT];     /* 授信信息 */
} CreditUpdateDataT, *pCreditUpdateDataT;

// Frontend req
typedef struct RiskDataS {
    int32           intRiskCfcnt;                   /* 风险系数 */
    char            strCntrctNm[MAX_CNTRCT_NM];     /* 合约系列号 */
} RiskDataT, *pRiskDataT;

typedef struct RiskDataBaseS {
    IntrnlMsgTypeT  eMessageType;                   /* Message type */
    int32           intOrgId;                       /* 机构系列号 */
    int64           timestamp;
    int32           intCrdtVldOrgFlag;              /* 授信有效标识 */
    int16           setId;
    char            strUpdUsrNm[MAX_USR_ID_LENTH];  /* 更新用户 */
} RiskDataBaseT, *pRiskDataBaseT;

typedef struct RiskUpdateDataS {
    RiskDataBaseT   riskDataBase;
    int32           intCount;                       /* 更新信息数量 */
    RiskDataT       riskData[MAX_RISKDATA_COUNT];   /* 风险系数信息 */
} RiskUpdateDataT, *pRiskUpdateDataT;


/******* Bridge Organization *******/
// 桥交易员设置 & 桥授信修改
typedef struct BridgeUpdateDataRefS {
    IntrnlMsgTypeT  eMessageType;                       /* Message type */
    char strUserId[MAX_USR_ID_LENTH];
    int32 intOrgId;
    char strDealerId[MAX_USR_ID_LENTH];
    int32 intBrdgOrgSt;
    int32 intBrdgPrvlgSt;
    char strSysTime[MAX_TIME_LENGTH];
} BridgeUpdateDataRefT, *pBridgeUpdateDataRefT;

// 桥百分比设置
typedef struct BridgeCwDataRefS {
    char strBrdgFlag[MAX_BRDG_FLAG_LENGTH];
    char strBrdgPercentage[MAX_BRDG_PRCNTG_LENGTH];
    char strBrdgTime[MAX_BRDG_TIME_LENGTH];
    char strSysTime[MAX_TIME_LENGTH];
} BridgeCwDataRefT, *pBridgeCwDataRefT;

// 桥授信更新
typedef struct BridgeCreditDetailS {
    int32 intOpOrgId;                      // 对手方机构ID
    int16 intCrdtRlf;                      // 关系
    char strBrdgFee[MAX_BRDG_FEE_LENGTH];  // 桥费
    int16 intTerm;                         // 期限
} BridgeCreditDetailT, *pBridgeCreditDetailT;

typedef struct BridgeCreditDataRefS {
    char strUserId[MAX_USR_ID_LENTH];
    int32 intOrgId;
    int32 intInfoCount;                    // 实际需要更新的桥授信记录个数
    int16 intModifyFlag;                   // 是否有修改
    int16 intBrdgSt;
    char strSysTime[MAX_TIME_LENGTH];
    BridgeCreditDetailT brdgCrdtDetail[BRIDGE_CREDIT_INFO_MAX_COUNT];
} BridgeCreditDataRefT, *pBridgeCreditDataRefT;


/******* Base Parameters *******/
// 市场状态应急变更（交易时间设置）
typedef struct MarketInfoCfgDataRefS {
    uint64 intMktStCfgId;                 // 市场状态变化消息ID
    char strTime[MAX_TIME_LENGTH];        // 市场状态变化时间
    char strSysTime[MAX_TIME_LENGTH];     // 系统当前时间
} MarketInfoCfgDataRefT, *pMarketInfoCfgDataRefT;

// 市场状态更新
typedef struct MktInfoDataRefS {
    uint64 intMktStCfgId;                 // 市场状态变化消息ID
    int32  intOpenClsId;                  // 市场状态标识
    char strSysTime[MAX_TIME_LENGTH];     // 系统当前时间
    int16 intMktStCfgUpdFlag;             // MKT_ST_CFG更新标识 1:更新  0:不更新
    int16 intBaseParamUpdFlag;            // BASE_PARAM更新标识 1:更新  0:不更新
} MktInfoDataRefT, *pMktInfoDataRefT;

// 每日结算价修改
typedef struct SetlPrcDataRefS {
    int64           stlPrice;
    int64           timestamp;
    int16           setId;
    char            strUserId[MAX_USR_ID_LENTH];
    char            strCntrctNm[MAX_CNTRCT_NM];
    char            strPriceDate[MAX_TIME_LENGTH];
} SetlPrcDataRefT, *pSetlPrcDataRefT;

// 限额调整
typedef struct CCPCreditDataRefS {
    int64           timestamp;
    int64           crdtAmnt;
    int32           intOrgId;
    int16           setId;
    int16           filler;
} CCPCreditDataRefT, *pCCPCreditDataRefT;

// 强制平仓
typedef struct CCPClsPosDataRefS {
    int64           closeSrno;
    int64           closePrice;
    int64           grossTradeAmt;
    int64           timestamp;
    int32           intOrgId;
    int16           setId;
    int16           side;
    char            strCntrctNm[MAX_CNTRCT_NM];
} CCPClsPosDataRefT, *pCCPClsPosDataRefT;

// 强制平仓撤销
typedef struct CCPClsPosCnclDataRefS {
    int64           closeSrno;
    int64           closeCnclSrno;
    int64           timestamp;
    int16           setId;
} CCPClsPosCnclDataRefT, *pCCPClsPosCnclDataRefT;


/******* SBFCCP Credit & Position *******/
typedef struct SbfCcpCrdtLimitDataRefS {
    int32           intOrgId;
    double          intlAmnt;
	double          bidIntlAmnt;
    double          ofrIntlAmnt;
	BOOL            ordFrzFlag;
	BOOL            isLmtPstnUpdated;
	uint16          lmtPstnFlagValue;
	double          bidUsedAmnt;
	double          bidRmnAmnt;
	double          bidHoldAmnt;
	double          ofrUsedAmnt;
	double          ofrRmnAmnt;
	double          ofrHoldAmnt;
	double          pstnBidHoldAmnt;
    double          pstnOfrHoldAmnt;	
	char            strSysTime[MAX_TIME_LENGTH];     // 系统当前时间

} SbfCcpCrdtLimitDataRefT, *pSbfCcpCrdtLimitDataRefT;


//成交撤销更新
typedef struct DealCnclS{
    int64   dealNo;
    int32   dealSt; 
    int64   updTime;
    int32   setId;
}DealCnclT, *pDealCnclT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*** common db interface ***/
ResCodeT InsertUserLoginHistory(int32 connId, UsrLgnHstry* pUserLoginHistory);
ResCodeT InsertUserOnline(int32 connId, UsrOnln* pData);
ResCodeT DeleteUserOnline(int32 connId, char* pData);
ResCodeT UpdateUserOnline(int32 connId, UsrOnln* pData);
ResCodeT UpdateApiUserOnline(int32 connId, UsrOnln* pData);

/*** user ****/
ResCodeT UserMemRef(void * pData, int32 dataLen);
ResCodeT UserDbtRef(int32 connId, void * pData, int32 dataLen);
ResCodeT UserDataPrint(void *pData, int32 dataLen);

/*** api subscribe ****/
ResCodeT ApiSubscribeMemRef(void * pData, int32 dataLen);
ResCodeT ApiSubscribeDbtRef(int32 connId, void * pData, int32 dataLen);
ResCodeT ApiSubscribeDataPrint(void *pData, int32 dataLen);

/*** trade privil config ****/
ResCodeT TrdPrvlConfMemRef(void * pData, int32 dataLen);
ResCodeT TrdPrvlConfDbRef(int32 connId, void * pData, int32 dataLen);
ResCodeT TrdPrvlConfDataPrint(void *pData, int32 dataLen);



/******* Credit *******/
ResCodeT CreditMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT CreditDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT CreditPrintCallback(void *pData, int32 dataLen);

/******* Ref prc *******/
ResCodeT RefPrcUpdCallback( void * pData, int32 dataSize );
ResCodeT RefPrcUpdDbCallback( int32 connId, void * pData, int32 dataSize );
ResCodeT RefPrcPrintCallback( void * pData, int32 dataSize );

/******* Bridge Organization *******/
ResCodeT BridgeMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT BridgeDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT BridgePrintCallback(void *pData, int32 dataLen);

ResCodeT BridgeParamMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT BridgeParamDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT BridgeParamPrintCallback(void *pData, int32 dataLen);

ResCodeT BridgeCreditMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT BridgeCreditDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT BridgeCreditPrintCallback(void *pData, int32 dataLen);

/******* Risk *******/
ResCodeT RiskMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT RiskDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT RiskUpdatePrintCallback(void *pData, int32 dataLen);
ResCodeT RiskMemUnlockCallback(void *pData, int32 dataLen);
ResCodeT RiskDbUnlockCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT RiskUnlockPrintCallback(void *pData, int32 dataLen);


/******* Base Parameters *******/
ResCodeT MarketInfoCfgMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT MarketInfoCfgDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT MarketInfoCfgPrintCallback(void *pData, int32 dataLen);

ResCodeT MktInfoMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT MktInfoDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT MktInfoPrintCallback(void *pData, int32 dataLen);

/******* Settle price adjust *******/
ResCodeT SetlPrcMemModifyCallback(void *pData, int32 dataLen);
ResCodeT SetlPrcDbModifyCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT SetlPrcModifyPrintCallback(void *pData, int32 dataLen);

/******* CCP Credit Parameter *******/
ResCodeT CCPCrdtMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT CCPCrdtDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT CCPCrdtUpdatePrintCallback(void *pData, int32 dataLen);

/******* SBFCCP Credit & Position *******/
ResCodeT SbfCcpCrdtLimitMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT SbfCcpCrdtLimitDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT SbfCcpCrdtLimitPrintCallback(void *pData, int32 dataLen);

ResCodeT OrdrSubmitByCwMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT OrdrSubmitByCwDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT OrdrSubmitByCwPrintCallback(void *pData, int32 dataLen);

ResCodeT OrdrCnclByCwMemUpdateCallback(void *pData, int32 dataLen);
ResCodeT OrdrCnclByCwDbUpdateCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT OrdrCnclByCwPrintCallback(void *pData, int32 dataLen);


/******* Deal Cancle *******/
ResCodeT DealCnclCallback(void *pData, int32 dataLen);
ResCodeT DealCnclDbCallback(int32 connId, void *pData, int32 dataLen);
ResCodeT DealCnclPrintCallback(void *pData, int32 dataLen);


#endif /* _USR_DEF_REF_ */
