/***
Created on June 13, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _COMMON_HASH_
#define _COMMON_HASH_
/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/
#include "data_type.h"
#include "err_lib.h"   
#include "common_macro.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define NULL_CMN_HASH_HNDL          ((int32)-1)
#define MAX_CMN_HASH_HNDL           999

/* Used for initial a common hahs table iteration */
#define CMN_HASH_ITER_START         ((uint32)-1)

#define CMN_LIST_NULL_NODE          ((uint32)-1)
#define CMN_LIST_DELETE_NODE        ((uint64)-1)
#define CMN_LIST_VALID_NODE         ((uint64)219)


/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/* Defined common hash handle structure */
typedef struct OAHashTableS
{
    /* root pointer of the hash table */
    unsigned char * pTableRoot;
    /* # of slots in the table, which must be a prime number */
    unsigned long cntSlots;
    /* byte lenght of each element */
    unsigned short recSize;
    /* byte offset of the key from the beginning of an element */
    unsigned short keyOffset;
    /* byte length of key data */
    unsigned short keySize;
    char filler[6];
    /* callback interface to check whether a slot is NULL one */
    BOOL (*IsNullSlot)(const void *, int32 stsOffset);
    /* callback interface to check whether a slot is deleted one. for hash
    table using open-addressing algorithm, deleted slots can not be marked as
    NULL coz the positions must be occupied to support search */
    BOOL (*IsDeletedSlot)(const void *, int32 stsOffset);
    /* callback interface to compare the keys of two slots */
    BOOL (*IsKeyEqual)(const void *, const void *, int32 keyLen);
    /* hash function */
    unsigned int (*hashFunc)(char *, unsigned int);
} OAHashTableT, *pOAHashTableT;

typedef int32 CmnHashHndlT;
typedef CmnHashHndlT *pCmnHashHndlT;

typedef struct listCmnHeadS
{
    uint32  head;
    uint32  tail;
} listCmnHeadT, *pListCmnHeadT;


typedef struct listCmnNodeS
{
    uint32  prev;
    uint32  next;
    uint64  validFlg;
} listCmnNodeT, *pListCmnNodeT;

typedef struct HashTableRecInfoS
{
    /* byte lenght of each element */
    uint16      recSize;
    /* byte offset of the key from the beginning of an element */
    uint16      keyOffset;
    /* byte length of key data */
    uint16      keySize;
    uint16      fillerS;
    uint32       recCnt;
    BOOL                bNeedTimeList;
} HashTableRecInfoT, *pHashTableRecInfoT;

typedef struct HashTableInfoS
{
    uint64    memSize;
    /* # of expected element count */
    uint32       fullThreshold;
    /* # of slots in the table, which must be a prime number */
    uint32       cntSlots;
    BOOL                bHasList;
    BOOL                bHasTimeList;
    /* The following 2 identical properties are used to distinguish the
       original user-data record and aligned elements with 8-byte status */
    HashTableRecInfoT   tableRecInfo;
    HashTableRecInfoT   oaHashTableRecInfo;
    char                shmName[SHM_NAME_LEN];
} HashTableInfoT, *pHashTableInfoT;

/* Hash table volume control structure, for the purposing of prevension of
   hash table full */
typedef struct HashTableCtrlS
{
    uint32        peakSlotsInList;
    uint32        usedSlotsInList;
    uint32        filler4B;
    uint32        peakSlots;
    uint32       usedSlots;
    uint32       fullThreshold;
    uint64    hashCnt;
    uint64    searchCnt;
    uint64    findAvaSlotCnt;
} HashTableCtrlT, *pHashTableCtrlT;

/* Basic element for the internal list in common hash */
typedef struct HashTableListS
{
    listCmnHeadT        listCtrl;
    listCmnNodeT        listData[1];
} HashTableListT, *pHashTableListT;

typedef struct MstrNodeS
{
    int64  frstPos;
    int64  lstPos;
} MstrHdrT, *pMstrHdrT;

typedef struct NodeHdrS
{
    int64  prePos;
    int64  nxtPos;
} SubNodeT, *pSubNodeT;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CmnHashTblCreate(char *pShmName,
                                HashTableRecInfoT recInfo,
                                BOOL bNeedList,
                                void * *ppRt,
                                pCmnHashHndlT pHashHndl);

ResCodeT CmnHashTblCreateWithTimeList(char *pShmName,
                                HashTableRecInfoT recInfo,
                                BOOL bNeedList,
                                void * *ppRt,
                                pCmnHashHndlT pHashHndl);

ResCodeT CmnHashTblAttach(char *pShmName,
                                void * *ppRt,
                                pCmnHashHndlT pHashHndl);


ResCodeT CmnHashResetTbl(CmnHashHndlT hashHndl);


ResCodeT CmnHashCheckData(CmnHashHndlT hashHndl,
                                const void * pKey,
                                BOOL *pExist,
                                uint32 * pDataPos,
                                void * pData);

ResCodeT CmnHashLogData(CmnHashHndlT hashHndl,
                                const void * pData,
                                uint32 dataPos,
                                BOOL bAddData,
                                BOOL bAddList);

ResCodeT CmnHashReadDataByPos(CmnHashHndlT hashHndl,
                                uint32 dataPos,
                                void * pData);

ResCodeT CmnHashDeleteData(CmnHashHndlT hashHndl,
                                uint32 dataPos);

ResCodeT CmnHashUpdateData(CmnHashHndlT hashHndl,
                                const void * pData,
                                uint32 dataPos);

ResCodeT CmnHashRegisterFunc(CmnHashHndlT hashHndl,
                                BOOL (*IsNullSlot)(const void *, int32 stsOffset),
                                BOOL (*IsDeletedSlot)(const void *, int32 stsOffset),
                                BOOL (*IsKeyEqual)(const void *,const void *, int32 keyLen));

ResCodeT CmnHashIterData(CmnHashHndlT hashHndl,
                                uint32 * pDataPos,
                                void * pData);
ResCodeT CmnHashIterDataExt(CmnHashHndlT hashHndl,
                                uint32 * pDataPos,
                                void ** ppData);
ResCodeT CmnHashIterDataOnTimeList(CmnHashHndlT hashHndl,
                                uint32 * pDataPos,
                                void * pData);


ResCodeT CmnHashRemoveFromList(CmnHashHndlT hashHndl,
                                void * pKey);

ResCodeT CmnHashTblMap2PrcMem(void *pMemRt,
                                int64 prcMemSize,
                                HashTableRecInfoT recInfo,
                                BOOL bNeedList,
                                BOOL bTimeList,
                                pCmnHashHndlT pHashHndl);
ResCodeT CmnHashTblGetGlbInfo(CmnHashHndlT hHashHndl,
                            HashTableCtrlT * pHashCtrl);
ResCodeT CmnHashTblGetRecTotal(CmnHashHndlT hHashHndl, uint64 * pRecTotal);
ResCodeT CmnHashTblGetRecAll(CmnHashHndlT hHashHndl, uint64 * pRecAll);
ResCodeT CmnHashReadDataAddrByPos(CmnHashHndlT hashHndl,
                                uint32 dataPos,
                                void * * ppData);
ResCodeT CmnHashCheckDataExt(CmnHashHndlT hashHndl,
                                const void * pKey,
                                BOOL *pExist,
                                uint32 * pDataPos,
                                void * * ppData);
ResCodeT CmnHashIterDataOnTimeListExt(CmnHashHndlT hashHndl, BOOL resetFlg,
                                uint32 * pDataPos,
                                void * pData);
ResCodeT CmnHashTblGetMemSize(CmnHashHndlT hHashHndl, int64 * pMemSize);
ResCodeT CmnHashDumpMem( char * shmName, char * pDumpFileName );

ResCodeT CommHashAddFrNode(MstrHdrT* pHdr, uint32 curSubPos, SubNodeT* pCurSub, uint32 preSubPos, SubNodeT* pPreSub);
ResCodeT CommHashSubAdd(SubNodeT* pAdd, uint32 addPos, SubNodeT* pLast, uint32 lastPos, MstrHdrT* pMstr);
ResCodeT CommHashSubDel(SubNodeT* pPre, uint32 prePos, SubNodeT* pNxt, uint32 nxtPos, MstrHdrT* pMstr);
ResCodeT CmnHashLstNxtData(CmnHashHndlT hashHndl,
                                uint32 * pCurPos,
                                uint32 * pNxtPos,
                                void * pNxtData);
ResCodeT CmnHashGetUsedCnt( CmnHashHndlT hashHndl, int64 *pUsedCnt );

#endif /* _COMMON_HASH_ */
