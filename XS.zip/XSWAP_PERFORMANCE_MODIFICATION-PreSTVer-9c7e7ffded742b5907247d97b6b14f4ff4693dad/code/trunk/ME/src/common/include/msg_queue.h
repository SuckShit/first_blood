/***
Created on June 13, 2017
@author: No One
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


#ifndef _MSG_QUEUE_
#define _MSG_QUEUE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "lock_free_queue.h"
#include "data_type.h"
#include "err_lib.h"


#ifdef __cplusplus
extern "C" {
#endif
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef enum {
    Q_TYPE_1W1R = 1,
    Q_TYPE_MW1R,
}MsgQueueTypeT;

typedef struct MsgQueueTag{
    MsgQueueTypeT      type;
    ThreadLockFreeQT       *pThreadLfq;
    ThreadLockFreeQHndlT **pLocalThreadLfqHdl;
    void                *pQueueMem;
    int32               queueThreadCnt;
    //IPCMutex            *lock;
    uint32              itemCnt;
    uint16              itemSize;
} MsgQueueT;

typedef struct MsgQueueCfgTag{
    MsgQueueTypeT       type;
    uint32              itemCnt;
    uint16              itemSize;
    int32                 threadCnt;
    int32               filter;
}MsgQueueCfgT;
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT MsgQueueCalcSize(MsgQueueCfgT   *pMsgQueueCfg, 
        uint32 *totalSize);

ResCodeT MsgQueueCalcUsedCnt(int32 msgHndl, int32* usedCnt);

ResCodeT MsgQueueCalcMaxCnt(int32 msgHndl, int32* maxCnt);

ResCodeT MsgQueueCreate(MsgQueueCfgT   *pMsgQueueCfg, 
        int32 * pMsgHndl,  void *pQueueAddr);

ResCodeT MsgQueueWriteSlot(int32 msgHndl, SlotT slot);

ResCodeT MsgQueueWriteData(int32 msgHndl, void *pData, int32 len);

ResCodeT MsgQueueReadData(int32 msgHndl, void *pData, int32 len);

ResCodeT MsgQueueReadSlot(int32 msgHndl, SlotT *pSlot);

ResCodeT MsgQueueDispose(int32 msgHndl);

ResCodeT MsgQueueGetFd(int32 msgHndl, int32 * outputFd);


#ifdef __cplusplus
}
#endif

#endif /* _MSG_QUEUE_ */
