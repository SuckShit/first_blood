﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/
#ifndef _OPTLIB_
#define _OPTLIB_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


#define MSK_VAL   0x01   //参数必需跟值
#define MSK_DEF   0x10   //参数可省略

typedef struct OpEntryS{
    char* key; //参数名
    char mask; //参数是否可省略，是否必须跟值等
} OpEntryT;
  
#define MAX_OPS  60  //命令行最多功能项

#define MAX_ENTRY 10 //一个功能项最多参数项
 
int GetTheOpt();
char* GetNextOption(int argc, char** argv, OpEntryT options[MAX_OPS][MAX_ENTRY], 
    char** optKey, char** optValue);

#endif /* _OPTLIB_ */