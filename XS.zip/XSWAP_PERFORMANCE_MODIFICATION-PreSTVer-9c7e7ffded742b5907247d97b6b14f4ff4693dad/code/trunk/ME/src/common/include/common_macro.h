/***
Created on June 13, 2017
@author: Brian Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _COMM_MACRO_
#define _COMM_MACRO_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** System level Macro
 **
 *****************************************************************************/
#define NO_ERR          1
 

#ifndef TRUE
#define TRUE   (1)
#endif

#ifndef FALSE
#define FALSE  (0)
#endif

#define MAX_INT64       0x7fffffffffffff
#define MAX_UINT32      (-1)

#define IS2N(n)     (!(n & (n-1)))


#define MAX_MSG_LEN                 4096
#define MAX_CFG_VAL_LEN             256 
#define SHM_NAME_LEN                128
#define MAX_BUFF_LEN                512
#define MAX_DATETIME_LEN            24
#define MAX_ORD_NMBR_LEN            18


#ifndef NULL_SLOT
#define NULL_SLOT   (SlotT)-1
#endif


#define UNIT_ALGN_SIZE          (sizeof(int64))
#define ELEM_SIZE_ALIGN(__elem_sz)  \
    ( ((__elem_sz) + UNIT_ALGN_SIZE - 1)/UNIT_ALGN_SIZE*UNIT_ALGN_SIZE)

#define DEFAULT_HASH_LOAD_RATIO 0.9

#ifndef NULL_SLOT
#define NULL_SLOT   (ShmSlotIdT)-1
#endif


#define TIMESTAMP_TEXT_FORMAT            "YYYY/MM/DD HH24:MI:SS:FF"
#define TIMESTAMP_MILLISEC_LEN           6
#define TIMESTAMP_TEXT_LEN               20+TIMESTAMP_MILLISEC_LEN+1

#define ADDRESS_ADD_OFFSET(_prt_, _offset_) ((uint64)(_prt_) + (uint64)(_offset_))
#define ADDRESS_MINUS_OFFSET(_prt_, _offset_) ((uint64)(_prt_) - (uint64)(_offset_))

#define MIN(x,y)     ((x) < (y)?(x):(y))
#define MAX(x,y)     ((x) > (y)?(x):(y))

#define GET_BIT_VECT_LEN(_cnt_)    ((((_cnt_) + 1 + VECTOR_BASE - 1)/ VECTOR_BASE) * 8)

#ifndef offsetof
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif

#ifndef MALLOC
#define MALLOC(_ptr_, _size_)\
do\
{\
    (_ptr_) = (void *)malloc(_size_);\
    if (!_ptr_)\
    {\
    }\
} while (0);
#endif

#ifndef CHK_SET_ID
#define CHK_SET_ID(_set_)\
do\
{\
    if (_set_ >= MAX_SET_CNT)\
    {\
        RAISE_ERR(ERR_INVLD_SET_ID,RTN);\
    }\
} while (0);
#endif

#define  CFG_PATH  "CFG_PATH"
#define  CFG_FILE_NM   "MatcherServer.cfg"

/******************************************************************************
 **
 ** Application level Macro
 **
 ******************************************************************************/
#define PRCS_ROLE_MATCHER                 'M'


/*Application level macro*/
#define WKSG_LIT_BUY                      'B'
#define WKSG_LIT_SELL                     'S'
#define WKSG_LIT_MARKETABLE               'M'
#define WKSG_LIT_YES                      'Y'
#define WKSG_LIT_NO                       'N' 

#define MAX_SET_CNT                       1000

/* Product status */
#define PROD_STAT_TRADE                   20

/* DB Connection status */
#define DB_INVALID_CONN_ID                -1


#define PRICE_BASE                  100000
#define AMNT_BASE                   1000

#define FILL_6_LEN                          6


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _COMM_MACRO_ */
