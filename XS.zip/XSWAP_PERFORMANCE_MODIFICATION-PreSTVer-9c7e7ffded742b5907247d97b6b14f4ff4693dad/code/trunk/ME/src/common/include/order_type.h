/***
Created on June 13, 2017
@author: Brian Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _ORDER_TYPE_
#define _ORDER_TYPE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "static_lst.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct OrderFS 
{
    int64       ordrExePrc;
    int64       ordrNo;
    int64       specOrdrNo;
    int64       ordrEntTim;
    int64       ordrActiveTim;
    int64       ordrExpTim;
    int64       tranTime;
    int64       ordrQty;
    int64       remPkQty;
    int64       ordrExeQty;
    int64       ordrApplyPrc;
    int64       ordrMtchPrc;
    int32       brdgFee;
    int32       userIdx;
    int32       prdctId;
    int32       entyIdxNo;
    int16       ordrMask; 
    int16       execInst;
    int16       extOrdrType;
    int16       ordrSts; 
    int16       ordAct;
    int32       apiLoginUsrIdx;
    int64       apiRqstId;
    int64       forceId;
    uint32      entyIdBrdg;
    char        brdgFlag;
    char        filler[3];
}OrderFT, *pOrderFT;

/* OrderFT for price leader */
/* OrderF4PrcLeadT and OrderFT should have the same size */

typedef struct OrderF4PrcLeadS 
{
    int64       ordrExePrc;
    int32       prdctId;
    int64       ordrNo;
    int64       ordrPri; /* order priority used to sorting of price leader */
    int32       odrBkSortingType;
    int32       cntUnrO;
    int32       cntUnrAuOaO;
    int32       cntUnrAuO;
    
    int64       totUnrO;
    int64       totUnrAuO;
    int64       totUnrAuOaO;
    
    int16       ordrMask; 
    char        filler[74];
}OrderF4PrcLeadT, *pOrderF4PrcLeadT;

typedef struct OrderTS /* 8 8 8 4 4 4 12 = 48*/
{
    osSListEntryT   unrO;
    osSListEntryT   unrAuO;
    osSListEntryT   unrAuOaO;
    osSListEntryT   ordNo;
    osSListEntryT   entyNo;
    osSListEntryT   expTimeLst;
    
    SlotT           priceLdr;
    SlotT           slotNo;
    
    char            filler[8];

    int32           free;
    int32           sltOpen;
}OrderTT, *pOrderTT;

/* OrderTT for price leader */
/* OrderT4PrcLeadT and OrderTT should have the same size */
typedef struct OrderT4PrcLeadS /* 8 8 8 4 4 8 4 4 = 48*/
{
    osSListEntryT   unrO;
    osSListEntryT   unrAuO;
    osSListEntryT   unrAuOaO;
    osSListEntryT   ordNo;
    osSListEntryT   entyNo;
    osSListEntryT   expTimeLst;
    
    SlotT           priceLdr;
    SlotT           slotNo;

    osSListEntryT   prcLder;

    int32           free;
    int32           filler;

}OrderT4PrcLeadT, *pOrderT4PrcLeadT;


typedef struct OrderS
{
    OrderFT orderF;
    OrderTT orderT;
}OrderT, *pOrderT;


typedef struct Order4PrcLeadS
{
    OrderF4PrcLeadT orderF;
    OrderT4PrcLeadT orderT;
}Order4PrcLeadT, *pOrder4PrcLeadT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _ORDER_TYPE_ */
