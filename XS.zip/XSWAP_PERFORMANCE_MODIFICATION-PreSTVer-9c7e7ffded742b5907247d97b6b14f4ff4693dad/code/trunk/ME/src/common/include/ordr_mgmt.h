/***
Created on Aug 10, 2017
@author: Yinsong.Zhao
@version $Id
***/

#ifndef _ORDR_MGMT_
#define _ORDR_MGMT_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
#include "order_type.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define MAX_ORDR_RCRD_CNT   100

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct OrdrMgmtKeyS
{
    int64           ordrNo;
    int16           ordrType;
    char            filler[6];
} OrdrMgmtKeyT, *pOrdrMgmtKeyT;

typedef struct OrdrMgmtRcrdS
{
    OrdrMgmtKeyT    ordrKey;    
    int16           ordrSts;
    int16           ordrCnt;
    char            filler[4];
    SlotT           ordrSlot[MAX_ORDR_RCRD_CNT];
} OrdrMgmtRcrdT, *pOrdrMgmtRcrdT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT OrdrMgmtShmCreate(int64 rcrdCnt, int32 setId);
ResCodeT OrdrMgmtShmDetach(int32 setId);
ResCodeT OrdrMgmtShmAttach(int32 setId);
ResCodeT OrdrMgmtShmDelete(int32 setId);

ResCodeT OrdrMgmtShmReset(int32 setId);

ResCodeT OrdrMgmtChk(int32 setId, pOrdrMgmtKeyT pOrdrKey, pOrdrMgmtRcrdT * ppOrdrMgmt, uint32 * pOrdrMgmtPos);
ResCodeT OrdrMgmtLogByPos(int32 setId, uint32 ordrMgmtPos, pOrdrMgmtRcrdT pOrdrMgmt);
ResCodeT OrdrMgmtAdd(int32 setId, pOrdrMgmtRcrdT pOrdrMgmt, uint32 * pOrdrMgmtPos);
ResCodeT OrdrMgmtUpdtByNo(int32 setId, pOrdrMgmtRcrdT pOrdrMgmt);
ResCodeT OrdrMgmtUpdtByPos(int32 setId, uint32 ordrMgmtPos, pOrdrMgmtRcrdT pOrdrMgmt);

ResCodeT OrdrMgmtGetByNo(int32 setId,pOrdrMgmtKeyT pOrdrKey, pOrdrMgmtRcrdT * ppOrdrMgmt, uint32 * pOrdrMgmtPos);
ResCodeT OrdrMgmtGetByPos(int32 setId, uint32 ordrMgmtPos, pOrdrMgmtRcrdT * ppOrdrMgmt );
ResCodeT OrdrMgmtDel(int32 setId, pOrdrMgmtKeyT pOrdrKey);
ResCodeT OrdrMgmtDelByPos(int32 setId, uint32 ordrMgmtPos);
ResCodeT OrdrMgmtIter(int32 setId, uint32* nodePos, pOrdrMgmtRcrdT  pOrdrMgmt);

ResCodeT OrdrMgmtNrmlUpdt(int32 set, int64 ordrNo, int32 ordrSts, pOrderT pOrder);
ResCodeT OrdrMgmtNrmlGet(int32 set, int64 ordrNo, pOrdrMgmtRcrdT * ppOrdrMgmt, pOrderT * ppOrder, uint32 * pOrdrPos);
ResCodeT OrdrMgmtBilUpdt(int32 set, int64 bilOrdrNo, int32 ordrSts, pOrderT pBidOrder, pOrderT pAskOrder, SlotT bidSlot, SlotT askSlot);
ResCodeT OrdrMgmtBilGet(int32 set, int64 bilOrdrNo, pOrdrMgmtRcrdT * ppBilOrdrMgmt, pOrderT * ppBidOrder, pOrderT * ppAskOrder, uint32 * pOrdrPos);

ResCodeT OrdrMgmtOcoUpdt(int32 set, int64 ocoOrdrNo, int32 ordrSts, pOrdrMgmtRcrdT  pOrdrMgmt);
ResCodeT OrdrMgmtOcoDatPrpr(int32 ordrSts, pOrdrMgmtRcrdT pOrdrMgmt, pOrderT pOrder);
ResCodeT OrdrMgmtOcoGet(int32 set, int64 ocoOrdrNo,pOrdrMgmtRcrdT * ppOcoOrdrMgmt, pOrderT * ppNmrlOrder, int64 * pIter);
ResCodeT OrdrMgmtOcoGetNext(int32 set, pOrdrMgmtRcrdT  pOcoOrdrMgmt, pOrderT * ppNmrlOrder, int64 * pIter);
#endif /* _ORDR_MGMT_ */
