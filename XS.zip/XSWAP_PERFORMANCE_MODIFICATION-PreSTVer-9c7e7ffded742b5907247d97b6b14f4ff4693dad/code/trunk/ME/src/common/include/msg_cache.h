/***
Created on June 13, 2017
@author: Ming.Kong
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _MSG_CACHE_LIB_
#define _MSG_CACHE_LIB_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <pthread.h>

/* Project Header files*/
#include "lock_free_queue.h"
#include "data_type.h"
#include "err_lib.h"
#include "msg_queue.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_MSG_LEN                 4096
#define MAX_MSG_CACHE_CNT           100
//#define MAX_MSG_CACHE_SLOT_CNT      100
#define MAX_MSG_CACHE_THREAD_CNT    100

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MsgCacheConfigS
{
    uint64      frstLevelElemCnt;
    uint64      secLevelElemCnt;
    uint32      elemSize;
    uint32      threadCnt;
} MsgCacheConfigT, *pMsgCacheConfigT;

typedef struct MsgDataS
{
    char        msgData[MAX_MSG_LEN];
} MsgDataT, *pMsgDataT;

typedef struct MsgCacheSlotS
{
    int64       timstmp;        /* Timestamp of when the req is passed in */
    int32       pairedSlotId;   /* The slot ID of paired response */
    int32       slotId;         /* This slot's slot ID */
    int32       destNode;       /* destination node */
    int32       filler;
    MsgDataT    msgBody;        /* Message in the slot */
} MsgCacheSlotT, *pMsgCacheSlotT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT MsgCacheCreate(char *dataCacheName, MsgCacheConfigT* pMsgConfig, int32 * pMsgCacheIdx);
ResCodeT MsgCacheAttach(char *dataCacheName, int32* pMsgCacheIdx);
ResCodeT MsgCacheDestroy(int32 msgCacheIdx);
ResCodeT MsgCacheDetach(int32 msgCacheIdx);
ResCodeT MsgCacheResrveSlot(int32 msgCacheIdx, SlotT *pSlot, void ** ppData);
ResCodeT MsgCacheGetSlotAddr(int32 msgCacheIdx, SlotT slot, void ** ppData);
ResCodeT MsgCacheReleaseSlot(int32 msgCacheIdx, SlotT slot);

ResCodeT MsgDelete(SlotT slotId);
ResCodeT MsgRsrvSlot(SlotT * pSlotId, pMsgCacheSlotT * ppSlot);
ResCodeT MsgCreate(SlotT slotNum, int32 secLvlCnt, int32 threadCnt);
ResCodeT MsgRsrvSlotsPaired(SlotT * pSlotId, pMsgCacheSlotT * ppReqSlot, pMsgCacheSlotT * ppRespSlot);
ResCodeT MsgInit();
ResCodeT MsgGetMsg(SlotT slotId, pMsgDataT * ppMsg );
ResCodeT MsgGetSlotRsp(SlotT slotId, pMsgCacheSlotT * ppRespSlot);
ResCodeT MsgGetSlot(SlotT slotId, pMsgCacheSlotT * ppMsg);
ResCodeT MsgDetach();
ResCodeT MsgDestory();
ResCodeT MsgCacheGetMsgCount(int32 msgHndl,int32 * msgCacheMaxCnt, int32 *  msgCacheUsedCnt);
ResCodeT GetMsgCount(int32 * maxCnt, int32 * usedCnt);
ResCodeT MsgCacheCleanThread();
#endif /* _MSG_CACHE_LIB_ */
