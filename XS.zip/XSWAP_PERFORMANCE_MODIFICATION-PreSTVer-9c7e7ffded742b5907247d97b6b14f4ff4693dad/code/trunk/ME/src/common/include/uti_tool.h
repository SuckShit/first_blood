﻿/***
Created on June 20, 2017
@author: 
@version $Id
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "err_cod.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define MAX_TIME_LEN    30


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
//SP Used.
ResCodeT GetSystemTime(time_t* pTime);
ResCodeT GetStringOfSystemTime(char* pTime);
ResCodeT ConvertFromCharToTime(char* pString, time_t* pTime);
ResCodeT ConvertFromTimeToChar(time_t iTime, char* pString);

ResCodeT GetStrEnvVar(char *varNm,char *pVarValue);
ResCodeT GetIntEnvVar(char *varNm,int64 *pVarValue);
ResCodeT GetSysTimestamp(int64 * timestamp);
ResCodeT GetStrTime(int64 timestamp, char * pTime, BOOL uSec);
ResCodeT GetStrDateTime(int64 timestamp,char * pDate, char * pTime);
ResCodeT GetStrDateTimeByFormat(int64 timestamp,char* pDateTime);
ResCodeT DateTimeToTimestamp(char * dateTime, int64* pTimestamp);
ResCodeT TimeToSecs(char * pDateTime, int64 * pSec);
ResCodeT SecondsToDateTime(char * pDateTime, int64 seconds, char* pNewTime);
ResCodeT ReplaceWord(char *word, char*find,char*repalce,char*newWord);
char* GetShmNm(char* inFileNm);
ResCodeT PrcsInit(char* prcsNm);

ResCodeT GetCurrentTime(char* sUpdateTime);
ResCodeT CnvtDoubleToIntnlVal(double input, int64 * pPrice );