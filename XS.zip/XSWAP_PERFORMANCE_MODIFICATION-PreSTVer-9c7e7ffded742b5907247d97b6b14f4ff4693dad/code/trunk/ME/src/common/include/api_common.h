/***
Created on Aug 11, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _API_COMMON_H_
#define _API_COMMON_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files*/
#include "data_type.h"
#include "usr_role.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT ApiCommonCheck(
                char*       strUserId,
                char*       strOrgCd,
                int32       iFuncId,
                char*       strToken,
                int32       iMktType,
                int64       timestamp,
                int32*      iOrgId
                );

ResCodeT CheckApiUserRole(int32 (&pRoleId)[ROLE_ID_MAX_COUNT], int32& iUserRole);

ResCodeT UserCheck(char* usrIdHeader, char* orgCdHeader, char* usrId, char* usrNm, char* orgCd, int32 mktId);

#endif /* _API_COMMON_H_ */
