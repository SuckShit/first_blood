/***
Created on June 13, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _SHM_NAME_
#define _SHM_NAME_

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/* Arch Shared memory*/
#define SHM_MSG_CACHE_NAME              "SHM_MSG_CACHE_E@@"
#define SHM_MSG_CACHE_SLOT_SUFFIX       "_SLOT"
#define SHM_PERF_STAT_NAME              "SHM_PERF_STATUS_E@@"
#define SHM_MSG_CACHE_TO_ME_SLOT_NAME   "SHM_MSG_CACHE_TO_ME_SLOT_E@@"
#define SHM_MSG_CACHE_FROM_ME_SLOT_NAME "SHM_MSG_CACHE_FROM_ME_SLOT_E@@"
#define SHM_MSG_CACHE_EVENT_SLOT_NAME   "SHM_MSG_CACHE_EVENT_SLOT_E@@"
#define SHM_ERR_DESC_NAME               "SHM_ERR_DESC_E@@"
#define SHM_STATE_SRVC_NAME             "SHM_STATE_SRVC_E@@"

/* Matcher relate shared memory */
#define SHM_MEM_TXN_NAME                "SHM_MEM_TXN_E@@"
#define SHM_TRADE_NAME                  "SHM_TRADE_E@@"
#define SHM_BRDG_ORDR_NAME              "SHM_BRDG_ORDR_E@@"
#define SHM_ORD_MGMT_NAME               "SHM_ORD_MGMT_%02d_E@@"
#define SHM_SET_ORDR_BK_NAME            "SHM_ORDR_BK_%02d_E@@"
#define SHM_NMBR_SRVC_NAME              "SHM_NMBR_SRVC_%02d_E@@"
#define SHM_USR_FLG_NAME                "SHM_USR_FLG_E@@"

/* Ref Data */
/* User*/
#define SHM_IRS_USR_ROLE_NAME           "SHM_IRS_USR_ROLE_INFO_E@@"
#define SHM_IRS_USR_ONLN_NAME           "SHM_IRS_USR_ONLN_INFO_E@@"
#define SHM_IRS_USR_NAME                "SHM_IRS_USR_INFO_E@@"
#define SHM_ROLE_PRVLG_NAME             "SHM_ROLE_PRVLG_E@@"

/* Contract*/
#define SHM_IRS_CONTRACT_INFO_NAME      "SHM_IRS_CONTRACT_INFO_E@@"
#define SHM_CNTRCT_PSTN_SBFCCP_NAME     "SHM_CNTRCT_PSTN_SBFCCP_INFO_E@@"
#define SHM_PRODUCT_INFO_NAME           "SHM_PRODUCT_INFO_E@@"
#define SHM_IRS_CONTRACT_LIST_NAME      "SHM_IRS_CONTRACT_LIST_E@@"
#define SHM_SIRS_CONTRACT_LIST_NAME     "SHM_SIRS_CONTRACT_LIST_E@@"
#define SHM_SBFCCP_CONTRACT_LIST_NAME   "SHM_SBFCCP_CONTRACT_LIST_E@@"

/* Risk*/
#define SHM_RISK_COEFFICIENCY_IRS_NAME  "SHM_RISK_COEFFICIENCY_IRS_E@@"
#define SHM_RISK_COEFFICIENCY_SIRS_NAME "SHM_RISK_COEFFICIENCY_SIRS_E@@"
#define SHM_IRS_RISK_CF_CNT_NAME        "SHM_IRS_RISK_CF_CNT_INFO_E@@"

/* Credit */
#define SHM_CRDT_NAME                   "SHM_CRDT_INFO_E@@"
#define SHM_CRDT_BRDG_NAME              "SHM_CRDT_BRDG_E@@"
#define SHM_CRDT_SBFCCP_NAME            "SHM_CRDT_SBFCCP_INFO_E@@"

/* Org */
#define SHM_ORG_ONLN_NAME               "SHM_ORG_ONLN_E@@"
#define SHM_ORG_INFO_NAME               "SHM_ORG_INFO_E@@"
#define SHM_BRIDGE_ORG_INFO_NAME        "SHM_BRIDGE_ORG_INFO_E@@"
#define SHM_ORGCD_POS_NAME              "SHM_ORGCD_POS_E@@"

/* Account */
#define SHM_ACNT_INFO_NAME              "SHM_ACNT_INFO_E@@"
#define SHM_DPST_ACNT_INFO_SBF_NAME     "SHM_DPST_ACNT_INFO_SBF_E@@"

/* Other */
#define SHM_BASE_PARAM_NAME             "SHM_BASE_PARAM_E@@"
#define SHM_BASE_PARAM_API_NAME         "SHM_BASE_PARAM_API_E@@"
#define SHM_ACTIVE_INFO_NAME            "SHM_ACTIVE_INFO_E@@"
#define SHM_MKT_ST_CFG_NAME             "SHM_MKT_ST_CFG_E@@"
#define SHM_SYS_ST_RSRC_NAME            "SHM_RSYS_ST_RSRC_E@@"
#endif /* _SHM_NAME_ */
