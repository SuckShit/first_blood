/***
Created on June 13, 2017
@author: Brian Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _DATA_TYPE_
#define _DATA_TYPE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <stdint.h>                 /* define int handling functions     */
/* Project Header files*/


/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef int16_t int16;
typedef uint16_t uint16;
typedef int32_t int32;
typedef uint32_t uint32;
typedef int64_t int64;
typedef uint64_t uint64;

typedef int16  BOOL;

typedef void *   pVoidT;

#define vectorT     uint64

#define VECTOR_BASE      (8 * sizeof(vectorT))

#ifndef vectorT
#define vectorT     uint64
#endif
typedef vectorT             *pVectorT;


typedef int32 ResCodeT;

typedef uint32 SlotT;



/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

//#define NULL        0
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _DATA_TYPE_ */
