/***
Created on June 13, 2017
@author: Brian Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _ORDER_BOOk_
#define _ORDER_BOOk_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"
#include "order_type.h"
#include "static_lst.h"
#include "match_lib.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/* Bit flag Order Side. */
#define ORDR_SIDE_BUY  0x0
#define ORDR_SIDE_SELL 0x1
#define ORDR_SIDE_NONE 0x2
#define ORDR_SIDE_MSK  0x3              /* Order side mask. */

/* Bit flag Trading Restriction. */
#define ORDR_TRDRESTR_OA  0x0           /* Opening Auction Only. */
#define ORDR_TRDRESTR_AU  0x10          /* Auction Only. */
//#define ORDR_TRDRESTR_SU  0x20          /* Accept Surplus. */
//#define ORDR_TRDRESTR_FP  0x30          /* Fixed Price. */
#define ORDR_TRDRESTR_NO  0x40          /* None. */
#define ORDR_TRDRESTR_MSK 0x70          /* Trading Restriction mask. */

/* Bit flag Execution Restriction. */
#define ORDR_EXERESTR_FOK 0x0
//#define ORDR_EXERESTR_IOC 0x80
//#define ORDR_EXERESTR_STP 0x100
//#define ORDR_EXERESTR_TRG 0x180
#define ORDR_EXERESTR_NON 0x200
#define ORDR_EXERESTR_MSK 0x380         /* Execution Restriction mask. */

/* Bit flag order type. */
#define ORDR_TYPE_LIMIT 0x0
#define ORDR_TYPE_MARKT 0x400
#define ORDR_TYPE_MKTOL 0x800
//#define ORDR_TYPE_ICEBG 0xC00
//#define ORDR_TYPE_QUOTE 0x1000
#define ORDR_TYPE_NONE  0x1800
#define ORDR_TYPE_MSK   0x1C00          /* Order Type mask. */


/* Exec Instruction. */
#define EXEC_INST_SAVE              1
#define EXEC_INST_SUBMIT            2
#define EXEC_INST_FORCE_SUBMIT      3


/* Exec Instruction. */
#define EXEC_INST_ORD_NEW           4
#define EXEC_INST_ORD_NEW_EXEC      5//ǿ��ִ��
#define EXEC_INST_ORD_SAVING        6
#define EXEC_INST_ORD_FREEZE        7
#define EXEC_INST_ORD_ACTIVATE      8
#define EXEC_INST_ORD_ACTIVATE_EXEC 9  //ǿ��ִ��
#define EXEC_INST_ORD_CHECK         10 //�������ڼ��
#define EXEC_INST_TRD_CANCLE        11 //�ɽ�����
#define EXEC_INST_TRD_STOP          12 //��ȫ��ǰ��ֹ
#define EXEC_INST_TRD_ABANDON       13 //��ǰ��ֹ


/* Order Action */
#define ORDR_ACT_NEW              1
#define ORDR_ACT_MOD              2


/* Order Status */
#define ORDR_STS_ACTIVE            1
#define ORDR_STS_DEAL              2
#define ORDR_STS_CANCEL            3
#define ORDR_STS_FREEZE            4
#define ORDR_STS_INACTIVE          5
#define ORDR_STS_INVALID           9

/* External Order Type */
#define EXT_ORD_TYPE_NORMAL         1
#define EXT_ORD_TYPE_IMP            2
#define EXT_ORD_TYPE_OCO            3
#define EXT_ORD_TYPE_IMPOCO         4
#define EXT_ORD_TYPE_BIL            5
#define EXT_ORD_TYPE_BRDG           6
#define EXT_ORD_TYPE_CLICK          7

/* Bridge order flag */
#define INT_ORD_FLAG_BRDG           'B'

#define ORDR_STS_FROZEN                   'Y'    /* Frozen order status */
#define ORDR_STS_UNFROZEN                 'N'    /* Unfrozen order status */

#define GET_ORDR_SIDE( oMask ) ( ( oMask ) & ORDR_SIDE_MSK )
#define GET_ORDR_TRDRESTR( oMask ) ( ( oMask ) & ORDR_TRDRESTR_MSK )
#define GET_ORDR_EXERESTR( oMask ) ( ( oMask ) & ORDR_EXERESTR_MSK )
#define GET_ORDR_TYPE( oMask ) ( ( oMask ) & ORDR_TYPE_MSK )

#define ODBK_SHM_NO_SLOT        ((SlotT) -1)

#define VALID_ORDERF4PRCLEADT_SIZE offsetof(OrderF4PrcLeadT, filler)

#ifndef NULL_SLOT_ID
#define NULL_SLOT_ID(slotId)    ((slotId) == NULL_SLOT)
#endif


#ifndef INIT_REG_LIST
#define INIT_REG_LIST(pListReg)\
    do\
    {\
        (pListReg)->frmUList.counter = 0; \
        (pListReg)->frmUAList.counter = 0; \
        (pListReg)->frmPrcLderList.counter = 0; \
        (pListReg)->frmUAOList.counter = 0; \
        (pListReg)->frmEntyList.counter = 0; \
        (pListReg)->frmOrdrNoList.counter = 0; \
    } while (0)
#endif


#define INIT_STATIC_LIST_ENTRY(ptr)\
    do {(ptr)->next = NULL_SLOT; (ptr)->prev = NULL_SLOT;} while (0)

#ifndef INIT_ORDER_TECH_PART
#define INIT_ORDER_TECH_PART(pAddO)\
    do\
    {\
        pOrderT pOrder = (pOrderT)(pAddO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.unrO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.unrAuO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.unrAuOaO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.ordNo);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.entyNo);\
        (pOrder)->orderT.priceLdr = NULL_SLOT;\
        (pOrder)->orderT.free = 0;\
    } while (0)
#endif

#ifndef INIT_PRC_LDER_FUNC_PART
#define INIT_PRC_LDER_FUNC_PART(pPrcLder, sortingType,oMask, exePrc, prdctId)\
    do\
    {\
        memset(&(pPrcLder)->orderF, 0x00, VALID_ORDERF4PRCLEADT_SIZE);\
        (pPrcLder)->orderF.odrBkSortingType = (sortingType);\
        (pPrcLder)->orderF.ordrMask = (oMask);\
        (pPrcLder)->orderF.ordrExePrc = (exePrc);\
        (pPrcLder)->orderF.prdctId = (prdctId);\
        (pPrcLder)->orderF.ordrNo = ((uint64)-1);\
        CalcuPri4PrcLder(&(pPrcLder)->orderF);\
    } while (0)
#endif



#ifndef IS_EMPTY_PRC_LDER
#define IS_EMPTY_PRC_LDER(pPrcLder)\
    IS_EMPTY_SLIST(&((pPrcLder)->orderT.unrAuOaO))
#endif
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* Order Sorting Type. */
typedef short OrdBkSortingT;                    /* P/T or P/Q/T. */

typedef struct OrdrBkCfgS
{
    int32 setId;
    int32 nmbrOfOrdr;
    int32 nmbrOfEnty;
    int32 nmbrOfPrdct;
} OrdrBkCfgT, *pOrdrBkCfgT;

typedef struct tagBstGrp
{
    int64 bstBuyLmtPrc;
    int64 bstSellLmtPrc;
    int64 bstBuyMktQty;
    int64 bstSellMktQty;
    int64 bstBuyLmtQty;
    int64 bstSellLmtQty;
    int64 bstBuyLmtOrdCnt;
    int64 bstSellLmtOrdCnt;
} BstGrpT, *pBstGrpT;

typedef struct tagRegListS
{
    frameSListT frmUList;
    frameSListT frmUAList;
    frameSListT frmPrcLderList;
    frameSListT frmUAOList;
    frameSListT frmOrdrNoList;
    frameSListT frmEntyList;
    frameSListT frmExpTimeList;
}RegListT, *p64RegListT;

typedef struct OrderKeyS
{
    uint32      prdctId; /* Product Id */
    uint32      orderNo; /* Order Number */
} OrderKeyT, *pOrderKeyT;

typedef struct OrderRcrdS
{
    OrderKeyT           orderKey;
    int64               exePrc;
    int64               orderEntTime;
    int64               orderExpTime;
    int64               orderTxnTime;
    int64               orderQty;
    int64               orderExeQty;
    int16               orderSide;
    int16               orderSts;
    int32               filler;
} OrderRcrdT, *pOrderRcrdT;

//
//typedef struct OrdrRbInfoS
//{
//    SlotT   prcLder;
//
//    char    fNewPrcLder; 
//    SlotT   newPrcLder;
//    SlotT   oldPrcLder;
//} OrdrRbInfoT, *pOrdrRbInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT OrdrBkShmAttach(int32 setId);
ResCodeT OrdrBkShmCreate(pOrdrBkCfgT pOrdrBkCfg);
ResCodeT OrdrBkShmDetach(int32 setId);
ResCodeT OrdrBkShmDelete(int32 setId);

ResCodeT OrdrBkCreateOrdr(int32 set, pOrderT *pOrderCreate);
ResCodeT OrdrBkFreeOrder(int32 set, pOrderT *pFreeOrder );
ResCodeT OrdrBkAddOrdr(BOOL bRcvrFlg,int32 set, pOrderT *ppAddO, pMAddOrdrT pAddOrdrAddr);
ResCodeT OrdrBkDeleteOrdr( int32 set, pOrderT *pDelOrder,const int64 tranTime);
ResCodeT OrdrBkModOrdr (BOOL bRcvrFlg, int32 set, pOrderT * pOldOrdr,
                        pOrderFT pNewOrdr,
                        pMModOrdrT pModOrdrAddr);
ResCodeT OrdrBkGetOrdrByNo( int32 set, int64 ordrNo, int32 prdctId, pOrderT *pOrdrNoGet );                        
ResCodeT GetBest(int32 set, const int32 prdctId,int16 oMask,  pOrderT *pBestO );

ResCodeT GetBstPrc(int32 set, int32            prdctId,
                    int32            ordrMask,
                    pBstGrpT       pBstGrp);
ResCodeT OrdrBkGetOrdr( int32 setId, int32 slotId,  pOrderT *pBkOrdr );
ResCodeT GetBstGrp(int32 set, const int32 prdctId,
                int32 oMask,
                pBstGrpT pBstGrp);
ResCodeT OrdBkModOrdrQty (int32 set,  pOrderT modOrdr,
                            int64 exeQty,
                            int64 tranTime); 
ResCodeT OrdrBkShmReset(int32 setId);    

ResCodeT OrdBkGetUsedOrdr(BOOL bReset,  int32 set, pOrderT * ppOrdr);  
ResCodeT OrdBkCreateOrderBySlot(int32 setId, int32 slot,
                        pOrderT *ppOrder);                    

ResCodeT SetOrdrExpListMode(int32 setId, int32 prdctId, osSListModeT ** ppExpOrdrListMode);
ResCodeT IterOrdrExpListMode(osSListModeT * pExpOrdrListMode, pOrderT * ppOrdrOrder);
ResCodeT IterNextOrdrExpListMode(osSListModeT * pExpOrdrListMode, pOrderT * ppOrdrOrder, int32 * pIter);

ResCodeT GetNxtPrcLeader(int32 setId,int32 BuySellMask,
                            int32 prdctId,
                            pOrder4PrcLeadT currPrcLdr,
                            pOrder4PrcLeadT *nxtPrcLdr );
ResCodeT GetPrvPrcLeader( int32 setId,int32 BuySellMask,
                            int32 prdctId,
                            pOrder4PrcLeadT currPrcLdr,
                            pOrder4PrcLeadT *prvPrcLdr );
ResCodeT GetNextOrder( int32 set, int32 prdctId, const int32 oMask, const pOrderT pCrrOrder,
                    pOrderT *pNxtOrder );
ResCodeT GetBestOrgOrder( int32 set, int32 prdctId, const int32 oMask, int64 orgPos, pOrderT * ppBstOrgOrder );

BOOL OrdBkChkUpdMktInfo( int32 setId );
void OrdBkSetMktUpdVec( int32 setId, int32 prdctId );
void OrdBkResetMktUpdVec( int32 setId );
void OrdBkGetMktUpdVec( int32 setId, pVectorT * pMktVec, int32 * pMaxPrdctNum );
ResCodeT GetFrstOrdrForPrcLeader(int32 set, const int32 prdctId,int16 oMask, pOrder4PrcLeadT pPrcLder, pOrderT *pFrstOrdr );
ResCodeT OrdrBkGetOrdrByOrgPos( int32 set, int64 orgPos, int32 prdctId, pOrderT *pNextOrgOrdr, SlotT *nxtSlt );
ResCodeT OrdrBkGetOrdrIterExt( int32 set, int32 prdctId, int16 ordMask, pOrderT pCurrOrdr, pOrderT *pNextOrdr );
#endif /* _ORDER_BOOk_ */
