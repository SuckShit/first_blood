/***
Created on June 30, 2017
@author: Pei.Rao
@version $Id
***/




/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "trade.h"
#include "shm_name.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
 
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


ResCodeT TradeShmCreate(int64 rcrdCnt, int32 setId);
ResCodeT TradeShmDetach(int32 setId);
ResCodeT TradeShmAttach(int32 setId);
ResCodeT TradeShmDelete(int32 setId);
ResCodeT TradeShmReset(int32 setId);

ResCodeT TradeChk(int32 setId, pTradeKeyT pTradeKey, pTradeDatT * ppTradeDat, uint32 * pTradePos);
ResCodeT TradeAdd(int32 setId, pTradeDatT pTradeDat, uint32 * pTradePos);
ResCodeT TradeGetByPos(int32 setId, pTradeKeyT pTradeKey , uint32 tradePos, pTradeDatT * ppTradeDat );
ResCodeT TradeUpdtByPos(int32 setId, uint32 tradePos, pTradeDatT pTradeDat);
ResCodeT TradeMgmtIter(int32 setId, uint32* pTradePos, pTradeDatT  pTradeDat);