/***
Created on August 14, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _CREDIT_COMMON_H_
#define _CREDIT_COMMON_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */

/* Project Header files */
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/** 验证授信关系
    名称：   CreditOrgCheck
    功能：   验证授信关系
    涉及的表或者视图：CRDT、CNTRCT_REF_PRC、ORG_INFO
  */
ResCodeT CreditOrgCheck(int32 orgCnt);

/** useCredit时使用 更新对应机构
    名称：   UpdateOrgCrdt
    功能：   useCredit时使用 更新对应机构
  */
ResCodeT UpdateOrgCrdt(int32 connId, int32 in_orgId);


/* 注释
   名称：   GetCreditAllowance
   功能：   获取可用授信额度
   涉及的表或者视图：CRDT
*/
ResCodeT GetCreditAllowance(int32 in_orgId, int32 in_crdtdOrgId, char* in_cntrctNm, uint64* out_Amnt);


/* 注释
   名称：   GetRiskInfo
   功能：   获取风险系数
   涉及的表或者视图：RSK_CFCNT
*/
ResCodeT GetRiskInfo(int32 in_orgId, char* in_cntrctNm, uint64* out_Amnt);

/******************************************************************************
 **
 ** CreditOrgCheckForRisk
 ** Validate credit for riskcfcnt 
 **
 ******************************************************************************/
ResCodeT CreditOrgCheckForRisk(int32 orgId);

#endif /* _CREDIT_COMMON_H_ */
