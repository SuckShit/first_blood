/***
Created on July 3, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


#ifndef _MSG_TYPE_H_
#define _MSG_TYPE_H_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define CHK_TXN_MSG_TYPE(_msgType_)  (MSG_TYPE_TXN_SETCTION > (_msgType_))


typedef enum
{
    MSG_TYPE_INIT = 0,

/***** Start of Txn Message Type Section *****/
    MSG_TYPE_ORDER_SUBMIT_MESSAGE,
    MSG_TYPE_ORDER_SAVE_MESSAGE,
    MSG_TYPE_ORDER_MODIFY_SUBMIT_MESSAGE,
    MSG_TYPE_ORDER_MODIFY_SAVE_MESSAGE,
    MSG_TYPE_ORDER_CANCEL_MESSAGE,
    MSG_TYPE_ORDER_FREEZE_MESSAGE,
    MSG_TYPE_ORDER_ACTIVATE_MESSAGE,
    MSG_TYPE_ORDER_WITHDRAW_MESSAGE,
    MSG_TYPE_BILORDER_SUBMIT_MESSAGE,
    MSG_TYPE_BILORDER_SAVE_MESSAGE,
    MSG_TYPE_BILORDER_MODIFY_SUBMIT_MESSAGE,
    MSG_TYPE_BILORDER_MODIFY_SAVE_MESSAGE,
    MSG_TYPE_BILORDER_CANCEL_MESSAGE,
    MSG_TYPE_BILORDER_FREEZE_MESSAGE,
    MSG_TYPE_BILORDER_ACTIVATE_MESSAGE,
    MSG_TYPE_BILORDER_WITHDRAW_MESSAGE,
    MSG_TYPE_OCOORDER_SUBMIT_MESSAGE,
    MSG_TYPE_OCOORDER_SAVE_MESSAGE,
    MSG_TYPE_OCOORDER_MODIFY_SUBMIT_MESSAGE,
    MSG_TYPE_OCOORDER_MODIFY_SAVE_MESSAGE,
    MSG_TYPE_OCOORDER_CANCEL_MESSAGE,
    MSG_TYPE_OCOORDER_FREEZE_MESSAGE,
    MSG_TYPE_OCOORDER_ACTIVATE_MESSAGE,
    MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE,
    MSG_TYPE_ORDER_CANCEL_BY_ADMIN,
    MSG_TYPE_DEAL_CNCL_MESSAGE,
    MSG_TYPE_ORG_BANK_FREEZE,
    MSG_TYPE_ORG_MARKET_ROLE_UPDATE,
    MSG_TYPE_USR_MARKET_ROLE_UPDATE,
    MSG_TYPE_MSG_TO_TDPS,
    MSG_TYPE_MSG_TO_GATEWAY,
    MSG_TYPE_MARKET_INFO_UPDATE,
    MSG_TYPE_PERIOD_VALIDATE,
    MSG_TYPE_TIMER_CAL_REF_PRC,
    MSG_TYPE_MKT_DAT_PUSH,
    MSG_TYPE_BRDG_ORDR_TRGR,
    MSG_TYPE_BRIDGE_DEALER_UPDATE,
    MSG_TYPE_BRIDGE_CREDIT_MODIFY,
    MSG_TYPE_BRIDGE_CREDIT_UPDATE,
    MSG_TYPE_ORDTRD_TO_CLNT,
    /*--- user ---*/
    MSG_TYPE_USER_LOGIN,
    MSG_TYPE_USER_LOGOUT,
    MSG_TYPE_REMOVE_ONLINE_USER,
    /*--- api ---*/
    MSG_TYPE_API_LOGIN,
    MSG_TYPE_API_LOGOUT,
    MSG_TYPE_API_PARAM_UPDATE,
    MSG_TYPE_API_USER_FREEZE,
    MSG_TYPE_API_USER_REMOVE,
    MSG_TYPE_API_SUBSCRIBE,
    MSG_TYPE_API_UNSUBSCRIBE_ALL,
    MSG_TYPE_API_ORD_SUBMIT,
    MSG_TYPE_API_ORD_CANCEL,
    MSG_TYPE_SIRS_API_ORD_SUBMIT,
    MSG_TYPE_SIRS_API_ORD_CANCEL,
    MSG_TYPE_SBFCCP_API_ORD_SUBMIT,
    MSG_TYPE_SBFCCP_API_ORD_CANCEL,
    MSG_TYPE_API_TRADER_PRIVIL_CONFIG,
    MSG_TYPE_API_CREDIT_UPDATE,
    MSG_TYPE_API_RISK_UPDATE,
    MSG_TYPE_API_RISK_UNLOCK,
    MSG_TYPE_BASE_PARAM_UPDATE,
    MSG_TYPE_CREDIT_MODIFY,
    MSG_TYPE_CREDIT_UPDATE,
    MSG_TYPE_CREDIT_UNLOCK,
    MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE,
    MSG_TYPE_BRIDGE_PERCENTAGE_UPDATE,
    MSG_TYPE_MARKET_CONFIG_MODIFY_CW,
    MSG_TYPE_RISK_UPDATE,
    /*--- SBFCCP ---*/
    MSG_TYPE_SETL_PRC_MODIFY,
    MSG_TYPE_CCP_CREDIT_UPDATE,
    MSG_TYPE_SBFCCP_ORDER_SUBMIT_QSS,
    MSG_TYPE_SBFCCP_ORDER_CANCEL_QSS,
    MSG_TYPE_SBFCCP_CONTRACT_CONVERT_RATE,
    MSG_TYPE_SBFCCP_CREDIT_LIMIT_CW,
    MSG_TYPE_SBFCCP_ORDER_SUBMIT_CW,
    MSG_TYPE_SBFCCP_ORDER_CANCEL_CW,
/***** End of Txn Message Type Section *****/

    MSG_TYPE_TXN_SETCTION,

/***** Start of Non-Txn Message Type Section *****/
    MSG_TYPE_ORDR_QUERY,

/***** End of Non-Txn Message Type Section *****/

    MSG_TYPE_INVLD
} IntrnlMsgTypeT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

#endif /* _MSG_TYPE_H_ */
