﻿/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _NMBR_SRVC_
#define _NMBR_SRVC_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define NMBR_SRVC_NAME                "NMBR_SRVC_TXN_@@"
#define MKT_BASE_IRS                  800000
#define MKT_BASE_SIRS                 700000
#define MKT_BASE_SBFCCP               600000
 
 
 
typedef enum
{
    /* Add new number type BELOW */
    NMBR_TYPE_ORD = 0,
    NMBR_TYPE_TRD,
    NMBR_TYPE_BIL_ORD,
    NMBR_TYPE_OCO_ORD,
    /* Add new number element type ABOVE */
    NMBR_TYPE_INVLD
}NmbrTypeT;

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct NmbrInfoS
{
    NmbrTypeT nmbrType;
    int64 preFixBase;
    int64 offsetBase;
    int64 currNo;
} NmbrInfoT, *pNmbrInfoT;
/* preFixBase * offsetBase + currNo*/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static NmbrInfoT gGlblNmbrList[] = {
    
        {NMBR_TYPE_ORD,     0, 100000000,   0 },
        {NMBR_TYPE_TRD,     0, 1000000,     0 },
        {NMBR_TYPE_BIL_ORD, 0, 100000,      0 },
        {NMBR_TYPE_OCO_ORD, 0, 100000,      0 }
    
};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT NmbrSrvcShmCreate(int32 setId);
ResCodeT NmbrSrvcShmAttach(int32 setId);
ResCodeT NmbrSrvcShmDetach(int32 setId);
ResCodeT NmbrSrvcShmDelete(int32 setId);

ResCodeT NmbrSrvcInit(int32 setId);
ResCodeT NmbrSrvcReset(int32 setId);
ResCodeT NmbrSrvcGenNo(int32 setId,NmbrTypeT nmbrType, int64 * pOutNmbr);
ResCodeT NmbrSrvcGetNo(int32 setId,NmbrTypeT nmbrType, int64 * pOutNmbr);
ResCodeT NmbrSrvcSetNo(int32 setId,NmbrTypeT nmbrType, int64    setNmbr);
int64 NmbrSrvcGetPreFix(int32 setId,NmbrTypeT nmbrType);
#endif /* _NMBR_SRVC_ */
