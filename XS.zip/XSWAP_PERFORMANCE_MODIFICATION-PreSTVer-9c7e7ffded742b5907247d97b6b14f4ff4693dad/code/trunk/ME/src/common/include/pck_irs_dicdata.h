/***
Created on Aug 02, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _PCK_IRS_DICDATA_H_
#define _PCK_IRS_DICDATA_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/* ETL相关 */
/* SP_ETL_once是否执行 */
#define C_SIRS_ETL_ONCE_FLAG_FALSE           0                            /* 不执行 */
#define C_SIRS_ETL_ONCE_FLAG_TRUE            1                            /* 执行 */

/* SP执行状态编码:0-失败,1-成功 */
#define C_ERR_CODE_FALSE                     0                            /* 失败 */
#define C_ERR_CODE_TRUE                      1                            /* 成功 */

/* T_ERR_MSG默认消息 */
#define C_ERR_MSG_DEFAULT                    "Succeed"
#define C_REC_NUM_DEFAULT                    0                            /* SQL处理条数,默认值 */
#define C_FORMAT_CNTRCT_MTH                  "YYMM"                       /* 合约月份格式 */

/* 隔日生效参数通用状态，枚举值：1-已修改，2-已生效 */
#define C_PARAM_NEXT_ST_MODIFY               1                            /* 已修改 */
#define C_PARAM_NEXT_ST_ACTIVE               2                            /* 已生效 */
  
/* 合约参数状态 */
#define C_CNTRCT_PARAM_ST_UNUSE              1                            /* 未生效 */
#define C_CNTRCT_PARAM_ST_USE                2                            /* 已生效 */

/* 合约隔日生效表,修改状态 */
#define C_CNTRCT_NEXT_ST_MODIFY              1                            /* 已修改 */
#define C_CNTRCT_NEXT_ST_ACTIVE              2                            /* 已生效 */

/* 合约状态 */
#define C_CNTRCT_ST_BFR_LIST                 0                            /* 待上市 */
#define C_CNTRCT_ST_LISTING                  1                            /* 交易中 */
#define C_CNTRCT_ST_AFTR_LIST                2                            /* 已退市 */
#define C_CNTRCT_ST_STOP_DL                  3                            /* 交易结束 */
#define C_CNTRCT_ST_PAUSE                    4                            /* 已暂停 */

/* 合约报价单位 */
#define C_CNTRCT_PRC_UNIT_BP                 0                            /* BP值 */
#define C_CNTRCT_PRC_UNIT_PCT                1                            /* 百分比值 */

/* 合约应急下架标志 */
#define C_CNTRCT_EMGCY_RESTORE               1                            /* 恢复 */
#define C_CNTRCT_EMGCY_STOP                  2                            /* 暂停 */

/* 用户 */
#define C_CNTRCT_CHK_NEW                     1                            /* 复核状态，1-新增待复核 */
#define C_CNTRCT_CHK_DEL                     2                            /* 复核状态，2-删除待复核 */
#define C_CNTRCT_CHK_OK                      3                            /* 复核状态，3-复核成功 */

/* 隔日生效参数通用状态，枚举值：1-已修改，2-已生效 */
#define C_NEXT_ST_MODIFY                     1                            /* 已修改 */
#define C_NEXT_ST_ACTIVE                     2                            /* 已生效 */

#define C_INIT_USER                          "IRSINIT"                    /* 数据初始化用户 */

/* ETL_STATE,当天标志默认个数 */
#define C_ETL_STATE_CNT_DEFAULT              0                            /* 每天每个标志应,初始0条 */
#define C_ETL_STATE_CNT_SHOULD               1                            /* 每天每个标志应该1条记录 */
#define C_ETL_STATE_FLAG_PRC                 "DailysettlementPrice"       /* 每日结算价标志_SIRS市场 */
#define C_ETL_STATE_FLAG_CNTRCT              "ContractInfoUpdate"         /* 合约信息更新标志_SIRS市场 */
#define C_ETL_STATE_FLAG_PRC_SBF             "DailysettlementPrice_SBF"   /* 每日结算价标_SBF市场 */
#define C_ETL_STATE_FLAG_CNTRCT_SBF          "ContractInfoUpdate_SBF"     /* 合约信息更新标志_SBF市场 */
#define C_ETL_STATE_DLVRY_BOND_SBF           "DlvryBondUpdate_SBF"        /* 可交割债券更新标志_SBF市场 */
#define C_ETL_STATE_ST_YES                   "Y"                          /* 成功 */
#define C_ETL_STATE_ST_YES                   "Y"                          /* 成功 */
#define C_ETL_STATE_ST_NO                    "N"                          /* 失败 */

/* 风险系数状态：0 禁用、1 启用 */
#define C_RSK_ST_SIRS_FORBID                 0                            /* 禁用 */
#define C_RSK_ST_SIRS_ACTIVE                 1                            /* 启用 */
#define C_RSK_VL_SIRS_DEFAULT                1                            /* 风险系数默认值 */

/* 外汇交易中心的ORG_ID */
#define C_ORG_ID_CFETS                       1                            /* 外汇交易中心的ORG_ID */

/* 市场类型 */
#define C_MKT_TP_IRS                         1                            /* IRS */
#define C_MKT_TP_SIRS                        2                            /* SIRS */
#define C_MKT_TP_SBF                         3                            /* SBF */
#define C_MKT_TP_SIRSCCP                     4                            /* SIRSCCP */
#define C_MKT_TP_SBFCCP                      5                            /* SBFCCP */

#define C_MKT_TP_INEDITABLE                  0                            /* 锁定 */
#define C_MKT_TP_EDITABLE                    1                            /* 可修改 */

/* CLNDR_TP */
#define C_CLNDR_TP_DL                        0                            /* 交易假日 */
#define C_CLNDR_TP_STL                       1                            /* 结算假日 */

/* 订单状态常量 */
#define C_ORD_STATUS_NEW                     "N"                          /* 新订单 */
#define C_ORD_STATUS_ACTIVE                  "2"                          /* 有效订单 */
#define C_ORD_STATUS_FROZEN                  "1"                          /* 订单冻结 */
#define C_ORD_STATUS_CLOSED                  "3"                          /* 订单成交 */
#define C_ORD_STATUS_CANCELED                "4"                          /* 被撤单 */
#define C_ORD_STATUS_INVLD                   "0"                          /* 订单无效 */

/* 订单处理类别 */
#define C_ORD_ACT_INSERT                     "I"                          /* 新增订单 */
#define C_ORD_ACT_UPDATE                     "U"                          /* 修改订单 */
#define C_ORD_ACT_ACTIVATE                   "A"                          /* 激活订单 */

/* 订单类型 */
#define C_ORD_TYPE_R                         "R"                          /* 常规订单 */
#define C_ORD_TYPE_I                         "i"                          /* 隐含订单 */
#define C_ORD_TYPE_OCO                       "OCO"                        /* OCO订单 */
#define C_ORD_TYPE_BIL                       "BIL"                        /* 双边订单 */

/* 订单成交类型 */
#define C_ORD_TYPE_LIMIT                     "LMT"                        /* 限价订单 */
#define C_ORD_TYPE_IOC                       "IOC"                        /* 点击成交订单 */

/* 买卖方向 */
#define C_ORDER_DIR_BID                      0                            /* 买 */
#define C_ORDER_DIR_ASK                      1                            /* 卖 */

/* 合约类型 */
#define C_CONTRACT_TYPE_SIC                  2                            /* 基准互换 */
#define C_CONTRACT_TYPE_ISP                  1                            /* 期差合约 */
#define C_CONTRACT_TYPE_IRS                  0                            /* 直接合约 */

/* 是否隐含订单相关 */
#define C_IMPLIED_YES                        TRUE                         /* 相关 */
#define C_IMPLIED_NO                         FALSE                        /* 无关 */

/* 默认值 */
#define C_DEFAULT_ZERO                       0                            /* 默认值0 */
#define C_DEFAULT_YES                        "Y"                          /* 默认值Y */
#define C_DEFAULT_NO                         "N"                          /* 默认值N */
#define C_DEFAULT_NULL                       ""                           /* 默认值空 */

/* 成交状态 */
#define C_TRDDTL_ST_NORMAL                   1                            /* 成交 */
#define C_TRDDTL_ST_CANCEL                   2                            /* 撤销 */
#define C_TRDDTL_ST_TERMIN                   3                            /* 提前终止 */

/* 用户类型 */
#define C_USER_TYPE_FRONT                    0                            /* 前台交易员 */
#define C_USER_TYPE_BACKGROUND               1                            /* 中后台用户 */
#define C_USER_TYPE_GROUND                   2                            /* 场务用户 */

/* 用户提单通道 */
#define C_ORDR_PRVLG_F_CLIENT                1                            /* 客户端 */
#define C_ORDR_PRVLG_F_API                   2                            /* API */

 
/* 角色权限 */
#define C_USER_ROLE_GROUND                   1                            /* 场务角色 */
#define C_USER_ROLE_BACKGROUND               2                            /* 中后台角色 */
#define C_USER_ROLE_FRONT                    3                            /* 交易员完全权限角色 */
#define C_USER_ROLE_LIMIT_FRONT              4                            /* 交易员部分权限角色 */
#define C_USER_ROLE_EMGCY_GROUND             5                            /* 场务应急角色 */
#define C_APIUSER_ROLE_CRDT                  7                            /* 授信api权限 */
#define C_APIUSER_ROLE_DEAL                  6                            /* 交易api权限 */
#define C_APIUSER_ROLE_QUOT                  8                            /* 行情api权限 */
 

/* 机构状态 */
#define C_ORG_ST_FORBID                      0                            /* 机构被禁用 */
#define C_ORG_ST_ACTIVE                      1                            /* 机构在活动 */
#define C_ORG_ST_DELETE                      2                            /* 机构已删除 */

/* 用户市场权限是否更新标识 */
#define C_USR_MKT_UPDATE_NO                  0                            /* 更新用户市场权限NO */
#define C_USR_MKT_UPDATE_YES                 1                            /* 更新用户市场权限YES */

/* 刷新桥单标识 */
#define C_BRDG_ORDR_UPDATE_NO                0                            /* 不刷新桥单 */
#define C_BRDG_ORDR_UPDATE_ORG               1                            /* 刷新该机构 */
#define C_BRDG_ORDR_UPDATE_MKT               2                            /* 刷新全市场 */

/* 机构标识 */
#define C_ORG_NULL                           0                            /* 机构号0 */
#define C_ORG_CD_NULL                        0                            /* 机构CD号0 */

/* 登录登出 */
#define C_LOGCONSTANT                        0                            /* 登录 */
#define C_LOGOUT                             1                            /* 登出 */

/* 合约类型 */
#define C_CNTRT_DRCT                         0                            /* 直接合约 */
#define C_CNTRT_DATEDIFF                     1                            /* 期差合约 */
#define C_CNTRT_SIC                          2                            /* 基准互换 */

/* 授信方式 */
#define C_CREDIT_AMT                         0                            /* 按额度授信 */
#define C_CREDIT_RL                          1                            /* 按关系授信 */

/* 有效授信个数 */
#define C_CRT_USEFUL                         5                            /* 授信授信个数 */

/* 授信状态 */
#define C_CRT_USEFULL                        0                            /* 有效授信 */
#define C_CRT_USELESS                        1                            /* 无效授信 */
#define C_CRT_MODIFY                         2                            /* 正在修改 */

/* 授信操作状态 */
#define C_CRT_OPERATING                      1                            /* 正在执行授信操作 */
#define C_CRT_NONE                           0                            /* 无授信操作 */

/* 授信关系 */
#define C_CRT_RL                             1                            /* 按关系授信 */
#define C_CRT_RLESS                          0                            /* 无关系 */
#define C_CRT_AMOUNT                         "NULL"                       /* 按额度授信 */

/* 机构授信有效性 */
#define C_ORG_CRT_USEFULL                    1                            /* 有效 */
#define C_ORG_CRT_USELESS                    0                            /* 无效 */

/* 机构清算所平仓模式 */
#define C_SHCH_CLSPSTN_ON                    1                            /* 平仓模式 */
#define C_SHCH_CLSPSTN_OFF                   0                            /* 正常 */

/* 机构清算所限仓模式 */
#define C_SHCH_LMTPSTN_ON                    1                            /* 限仓模式 */
#define C_SHCH_LMTPSTN_OFF                   0                            /* 正常 */
  
/* 授信额度更新方式 */
#define C_CRTAMOUNT_ORIGIN                   0                            /* 使用初始额度 */
#define C_CRTAMOUNT_REMIN                    1                            /* 使用剩余额度 */

/* 盘中参考价间隔时间 */
#define C_PRCCALC_TIME                       30                           /* 盘中参考价间隔时间 */

/* 操作类型 */
#define C_OPTION_TP_IN                       0                            /* 登录 */
#define C_OPTION_TP_OUT                      1                            /* 登出 */

/* 禁用/解禁请求 */
#define C_REQUEST_FORBID                     0                            /* 禁用请求 */
#define C_REQUEST_ACTIVE                     1                            /* 解禁请求 */

/* 用户状态 */
#define C_USR_ST_ACTIVE                      1                            /* 启用 */
#define C_USR_ST_LOCK                        0                            /* 锁定 */
#define C_USR_ST_DELETE                      -1                           /* 作废 */

/* 账户状态 */
#define C_ACNT_ST_ACTIVE                     1                            /* 活动 */
#define C_ACNT_ST_FRZE                       2                            /* 禁用 */
#define C_ACNT_ST_PRCS                       3                            /* 待处理 */
#define C_ACNT_ST_DELETE                     4                            /* 删除 */

/* 托管账户状态 */
#define C_DPST_ACNT_ST_ACTIVE                1                            /* 活动 */
#define C_DPST_ACNT_ST_FRZE                  2                            /* 禁用 */
#define C_DPST_ACNT_ST_PRCS                  3                            /* 待处理 */
#define C_DPST_ACNT_ST_DELETE                4                            /* 删除 */

#define C_SYSTEM                             "SYSTEM"                     /* 系统操作名 */
#define C_SHCH                               "SHCH"                       /* 上海清算所 */
#define C_CFETS                              "1"                          /* 外汇交易中心枚举值 */
#define C_CFETS_CN                           "中国外汇交易中心"           /* 外汇交易中心中文名 */
#define C_CT                                 "CT"                         /* API前缀 */
#define C_EMERGENCY                          "emergency"                  /* 应急更新用户名 */

  
/* API线路重连用户 */
#define C_GTW_USER                           "APIDUMP"                    /* API线路重连用户 */

#define C_USERLOGIN_FUNCID                    1000                        /* 用户登录 */
#define C_USERLOGOUT_FUNCID                   1001                        /* 用户登出 */
#define C_TRD_PRV_CFG_FUNCID                  1002                        /* 设置用户提单通道 */
#define C_TRD_PRV_QRY_FUNCID                  1003                        /* 查询用户提单通道 */


/* 订单FUNCID */
#define C_ORDSAVING_FUNCID                    2000                        /* 订单保存 */
#define C_ORDSUBMIT_FUNCID                    2001                        /* 订单提交 */
#define C_ORDCANCEL_FUNCID                    2002                        /* 订单撤销 */
#define C_ORDFREEZE_FUNCID                    2003                        /* 订单冻结 */
#define C_ORDACTIVATE_FUNCID                  2004                        /* 订单激活 */
#define C_ORDQUERY_FUNCID                     2005                        /* 订单查询 */
#define C_PRICEQUERY_FUNCID                   2006                        /* 价格查询 */
#define C_ORDLIQUIDATE_FUNCID                 2010                        /* 强平 */
#define C_ORDUNLIQUIDATE_FUNCID               2011                        /* 撤销强平 */


/* OCO订单FUNCID */
#define C_OCOORDSAVING_FUNCID                 3000                        /* OCO订单保存 */
#define C_OCOORDSUBMIT_FUNCID                 3001                        /* OCO订单提交 */
#define C_OCOORDCANCEL_FUNCID                 3002                        /* OCO订单撤销 */
#define C_OCOORDFREEZE_FUNCID                 3003                        /* OCO订单冻结 */
#define C_OCOORDACTIVATE_FUNCID               3004                        /* OCO订单激活 */
#define C_BILORDSAVING_FUNCID                 3005                        /* BIL订单保存 */
#define C_BILORDSUBMIT_FUNCID                 3006                        /* BIL订单提交 */
#define C_BILORDCANCEL_FUNCID                 3007                        /* BIL订单撤销 */
#define C_BILORDFREEZE_FUNCID                 3008                        /* BIL订单冻结 */
#define C_BILORDACTIVATE_FUNCID               3009                        /* BIL订单激活 */


/* 机构系数FUNCID */
#define C_RISKQUERY_FUNCID                    4001                        /* 风险系数查询 */
#define C_RISKUPDATE_FUNCID                   4004                        /* 风险系数更新 */
#define C_CREDITQUERY_FUNCID                  4000                        /* 查询授信信息 */
#define C_CREDITMODIFY_FUNCID                 4002                        /* 授信修改 */
#define C_CREDITUPDATE_FUNCID                 4003                        /* 授信更新 */
#define C_CRT_RFSH_QUERY_FUNCID               4005                        /* 授信更新方式查询 */
#define C_CRT_RFSH_MODIFY_FUNCID              4006                        /* 授信更新方式修改 */
#define C_CRT_UNLOCK_FUNCID                   4007                        /* 解除授信修改锁定 */
#define C_RSK_UNLOCK_FUNCID                   4008                        /* 解除风险系数引起的锁定 */
#define C_PSTNLIMITQUERY_FUNCID               4009                        /* 持仓限额查询 */
#define C_PSTNLIMITMDFY_FUNCID                4010                        /* 持仓限额修改 */
#define C_BRDGPRVLGMDFYCW_FUNCID              4011                        /* 场务设置机构搭桥权限 */
#define C_BRDGCRDTMDFY_FUNCID                 4012                        /* 修改机构搭桥 */
#define C_BRDGCRDTUPDATE_FUNCID               4013                        /* 中后台设置机构搭桥参数 */
#define C_BRDGCRDTMDFYUNLOCK_FUNCID           4014                        /* 机构搭桥参数解锁 */
#define C_BRDGDEALERUPDATE_FUNCID             4015                        /* 前台设置机构搭桥参数 */
#define C_BRDGCRDTQUERY_FUNCID                4016                        /* 中后台查询机构搭桥参数 */
#define C_BRDGDEALERQUERY_FUNCID              4017                        /* 前台查询机构搭桥参数 */


/* 成交FUNCID */
#define C_TRDQUERY_FUNCID                     5000                        /* 成交查询 */
#define C_TRADECANCEL_FUNCID                  5001                        /* 成交撤销 */
#define C_HLD_AMNTQUERY_FUNCID                5002                        /* 持仓量查询 */


/* 市场系数FUNCID */
#define C_PARAMUPDATE_FUNCID                  6000                        /* 基本参数设置 */
#define C_CONTRACTINFOUPDATE_FUNCID           6001                        /* 合约参数设置 */
#define C_PARAMQUERY_FUNCID                   6002                        /* 基本参数查询 */
#define C_CONTRACTINFOQUERY_FUNCID            6003                        /* 合约参数查询 */
#define C_CONTRACTCNVRTUPDATE_FUNCID          6005                        /* 合约转换系数修改 */
#define C_APIPARAMUPDATE_FUNCID               6006                        /* API参数设置 */
#define C_IRS_MANUALSMRY_FUNCID               10017                       /* API参数设置 */


/* 权限、系统FUNCID */
#define C_ORGFREEZE_FUNCID                    7000                        /* 机构禁用/解禁 */
#define C_UNLOCKCREDIT_FUNCID                 7001                        /* 应急解除授信修改锁定 */
#define C_UPDMKTINFO_FUNCID                   7002                        /* 市场状态更新 */
#define C_IRSINIT_FUNCID                      7003                        /* IRS系统初始化 */
#define C_IRSBATCH_FUNCID                     7004                        /* IRS批处理 */
#define C_REMOVEUSER_FUNCID                   7005                        /* 紧急移除在线用户 */
#define C_USRMKTQUERY_FUNCID                  7006                        /* 查询用户市场权限 */
#define C_USRMKTMDY_FUNCID                    7007                        /* 修改用户市场权限 */
#define C_ORGMKTQUERY_FUNCID                  7008                        /* 查询机构市场权限 */
#define C_ORGMKTMDY_FUNCID                    7009                        /* 修改机构市场权限 */
#define C_PRVLGCHK_FUNCID                     7010                        /* 检查权限修改范围 */
#define C_MKTSTCFGMDFY_FUNCID                 7011                        /* 市场状态时间更新 */
#define C_APIUSRFREEZE_FUNCID                 7012                        /* API用户禁用/解禁 */

#define C_ACNTDELETE_FUNCID                   8001                        /* 资金账户删除 */
#define C_REFPRCMDY_FUNCID                    8002                        /* 结算价修改 */
#define C_ACNTMDY_FUNCID                      8003                        /* 资金账户修改 */
#define C_ACNTQUERY_FUNCID                    8004                        /* 资金账户查询 */
#define C_STTLPRCQUERY_FUNCID                 8006                        /* 结算价查询 */
#define C_DPST_ACNTDELETE_FUNCID              8007                        /* 托管账户删除 */
#define C_DPST_ACNTMDY_FUNCID                 8008                        /* 托管账户修改 */
#define C_DPST_ACNTQUERY_FUNCID               8009                        /* 托管账户查询 */
#define C_DLVRY_BONDQUERY_FUNCID              8010                        /* 可交割债券查询 */
#define C_DLVRY_BONDUPDATE_FUNCID             8011                        /* 可交割债券更新 */

#define C_CONTR_INFOUPD_SIRS_FUNCID           8005                        /* 合约参数设置(SIRS) */
#define C_CONTR_INFOUPD_SBFCCP_FUNCID         8013                        /* 合约参数设置(SBFCCP) */

#define C_API_RISKQUERY_FUNCID                10006                       /* API授信-风险系数查询 */
#define C_API_RISKUPDATE_FUNCID               10007                       /* API授信-风险系数更新 */
#define C_API_CREDITUPDATE_FUNCID             10009                       /* API授信-交易限额更新 */
#define C_API_CREDITQUERY_FUNCID              10012                       /* API授信-查询限额信息 */
#define C_API_USERLOGOUT_FUNCID               10015                       /* API授信-用户登出 */
#define C_API_SUBSCRIBE_FUNCID                10016                       /* API行情-请阅取消 */

#define C_API_ORDERSUBMIT_FUNCID              2001                        /* API提交订单 */
#define C_API_ORDCANCEL_FUNCID                2002                        /* api撤销订单 */


/* 市场状态 */
#define C_MKT_ST_WAIT                        0                            /* 等待 */
#define C_MKT_ST_OPEN                        1                            /* 开市 */
#define C_MKT_ST_OPENQT                      2                            /* 开盘 */
#define C_MKT_ST_MDCLOSE                     3                            /* 休市 */
#define C_MKT_ST_CLOSEQT                     4                            /* 收盘 */
#define C_MKT_ST_CLOSE                       5                            /* 闭市 */
#define C_MKT_ST_CLOSEQT_IRS                 6                            /* IRS收盘 */


/* 交易方式 */
#define C_TRD_TYP_MATCHING                   '1'                          /* 竞价 */

/* 时间日期格式 */
#define C_FORMAT_MINUTE                      "HH24:MI:SS"                 /* 时间格式时分秒 */
#define C_FORMAT_DATE                        "YYYYMMDD"                   /* 时间格式年月天 */
#define C_FORMAT_DATE2                       "YYYY-MM-DD"                 /* 时间格式年月天 */
#define C_FORMAT_TIME                        "YYYYMMDD-HH24:MI:SS"        /* 时间格式年月日时分秒 */
#define C_FORMAT_ACTIME                      "YYYYMMDD-HH24:MI:SS.ff"     /* 时间格式年月日时分秒毫秒 */

/* 是否需要检查参考价 */
#define C_CHK_REF_PRC_Y                      1                            /* 需要检查 */
#define C_CHK_REF_PRC_N                      0                            /* 不需要检查 */

/* 基础参数 */
/* 批处理完成标志 */
#define C_BASE_PARAM_BAT_FLAG                "BAT_FLAG"                   /* 跑批是否成功标志 */
#define C_BASE_PARAM_ETL_FLAG                "ETL_FLAG"                   /* ETL是否成功标志 */
#define C_BASE_PARAM_INIT_FLAG               "INIT_FLAG"                  /* 初始化是否成功标志 */

#define C_LARGEST_QTY                        99999999999999999999         /* 最大数量 */
#define C_LARGEST_TERM                       9999999999                   /* 最大授信天数 */

/* oco订单设置 */
#define C_OCO_SET_FLAG_Y                     1                            /* 设置OCO */
#define C_OCO_SET_FLAG_N                     0                            /* 取消OCO */

/* 授信风险系数返回消息内容 */
#define C_CRDT_MDFING                        "正在进行授信管理，请稍候"        /* 正在授信提示 */
#define C_CRDT_MDFFRZ                        "进行授信管理，所有订单自动冻结"  /* 授信冻结提示 */
#define C_CRDT_MDFFNSH                       "授信/风险系数修改完毕！"         /* 授信修改完毕提示 */
#define C_CRDT_FINISH                        "修改完毕，可正常交易"            /* 修改完毕 */
#define C_RSK_MDFFNSH                        "风险系数修改完毕！"

#define MSG_ORG_CREDIT_MODIFING              "进行授信管理，所有订单自动冻结！"  /* 正在授信提示 */
#define MSG_ORG_CREDIT_MODIFIED              "授信/风险系数修改完毕！"           /* 授信修改完毕提示 */
#define MSG_ORG_CREDIT_USELESS               "未满足有效授信要求！"              /* 未满足有效授信要求 */
#define MSG_ORG_CREDIT_USEFULL               "授信/风险系数修改成功！"           /* 授信/风险系数修改成功 */

/* 基本参数设置 */
#define C_MKTLVL                             "marketQuote"                /* 行情展示档位 */
#define C_PRCLMT                             "quotePrice"                 /* 报价点差限制 */
#define C_OCO_ODR_MAX_LMT                    "ocoHigh"                    /* OCO包含订单数最大限制 */
#define C_OCO_ODR_MIN_LMT                    "ocoLow"                     /* OCO包含订单数最小值 */
#define C_CRT_LMT                            "crdtUnit"                   /* 有效授信限额 */
#define C_CRT_RFCCNTCT                       "crdtCntrct"                 /* 有效授信参考合约 */
#define C_OCO_MAX                            "ocoTotal"                   /* OCO篮子最大个数 */
#define C_MKT_ST                             "marketState"                /* 市场状态 */
#define C_MKT_ST_IRS                         "marketStateIRS"             /* 市场状态 */
#define C_REFPRC_CLC_TIME                    "lastPrcCalcTime"            /* 盘中参考价最后一次计算时间 */
#define C_API_CRDT_FLW_CNTRL                 "flowControl"                /* 授信流控限制，单位：秒/次 */
#define C_API_TRADE_FLW_CNTRL                "dealFlowControl"            /* 交易流控限制，单位：秒/次 */
#define C_API_LOGIN_FLW_CNTRL                "loginFlowControl"           /* 登陆流控限制，单位：秒/次 */
#define C_API_MKT_FLW_CNTRL                  "marketFlowControl"          /* 行情流控限制，单位：秒/次 */
#define C_API_CRDT_TIME_START                "crdtTimeStart"              /* 有效授信起始时间，格式HH24:MI */
#define C_API_CRDT_TIME_END                  "crdtTimeEnd"                /* 有效授信结束时间，格式HH24:MI */
#define C_ORDR_STAT_INTERVAL                 "ordrStatInterval"           /* 报价次数统计时间间隔16:30前，单位：秒 */
#define C_ORDR_DIFFERENCE                    "ordrDifference"             /* 价差阀值，单位：BP */
#define C_GEN_IMP_ORD_TIME                   "genImpOrdTime"              /* 隐含订单最后一次计算时间 */
#define C_CRT_MINORGCOUNT                    "crdtMinCount"               /* 最低授信方数量 */
#define C_CRT_SETMNTPRICE_SIRS               "setmntPrice_SIRS"           /* SIRS报价点差限制 */
#define C_CRT_SETMNTPRICE_SBF                "setmntPrice_SBF"            /* SBF报价点差限制 */
#define C_CRT_SETMNTPRICE_SIRSCCP            "setmntPrice_SIRSCCP"        /* SIRSCCP报价点差限制 */
#define C_CRT_SETMNTPRICE_SBFCCP             "setmntPrice_SBFCCP"         /* SBFCCP报价点差限制 */
#define C_BRDG_LASTBRDGETIME                 "lastBrdgeTime"              /* 上次搭桥时间 */
#define C_BRDG_BYPASSFREQUENCY               "bypassFrequency"            /* 搭桥频率 */
#define C_BRDG_BRIDGEFLAG                    "bridgeFlag"                 /* 搭桥开关 */
#define C_BRDG_BRIDGEPERCENT                 "bridgePercent"              /* 搭桥百分比 */
#define C_BRDG_BRIDGETIME                    "bridgeTm"                   /* 搭桥持续时间 */
#define C_BIL_NOTIFYFREQUENCY                "bilNotifyFrequency"         /* 搭桥百分比 */
#define C_IMPLCTN_FLAG                       "implctnFlag"                /* 隐含订单开关 */
#define C_IMP_Y                              "Y"                          /* 隐含订单开 */
#define C_IMP_N                              "N"                          /* 隐含订单关 */

#define C_CALCORG                            1                            /* 计算机构 */
#define C_STLETP                             1                            /* 清算方式 */
#define C_MSG_F_Y                            1                            /* 需要处理 */
#define C_MSG_F_N                            0                            /* 不要处理 */
	
	
/* 机构类型 */
#define C_CENTRE                             1                            /* 中心 */

/* 合约状态 */
#define C_CNTCT_FORBID                       0                            /* 禁用 */
#define C_CNTCT_AVAIL                        1                            /* 启用 */

/* SIRS合约状态：0 待上市、1 交易中、2 已退市、3 交易结束 */
#define C_CNTCT_SIRS_WAIT                    0                            /* 待上市 */
#define C_CNTCT_SIRS_TRADING                 1                            /* 交易中 */
#define C_CNTCT_SIRS_CLOSE                   2                            /* 已退市 */
#define C_CNTCT_SIRS_STOPTRADING             3                            /* 已退市 */
#define C_CNTCT_SIRS_SUSPEND                 4                            /* 已暂停 */

/* SBF合约状态：0 待上市、1 交易中、2 已退市、3 交易结束 */
#define C_CNTCT_SBF_WAIT                     0                            /* 待上市 */
#define C_CNTCT_SBF_TRADING                  1                            /* 交易中 */
#define C_CNTCT_SBF_CLOSE                    2                            /* 已退市 */
#define C_CNTCT_SBF_STOPTRADING              3                            /* 交易结束 */
#define C_CNTCT_SBF_SUSPEND                  4                            /* 已暂停 */

#define C_TRD_METHOD_SC2BG                   "303"                        /* 基准互换合约实单与桥单成交 */
#define C_TRD_METHOD_OR2BG                   "302"                        /* 直接合约实单与桥单成交 */
#define C_TRD_METHOD_SR2BG                   "301"                        /* 期差合约实单与桥单成交 */
#define C_TRD_METHOD_SC2SC                   "204"                        /* 基准互换合约实单与基准互换合约实单成交 */
#define C_TRD_METHOD_OR2OR                   "203"                        /* 直接合约实单与直接合约实单成交 */
#define C_TRD_METHOD_SR2SR                   "200"                        /* 期差合约实单与期差合约实单成交 */
#define C_TRD_METHOD_SR2II                   "201"                        /* 期差实单与期差内隐订单的成交 */
#define C_TRD_METHOD_OROIO                   "202"                        /* 直接合约实单与直接合约外隐订单成交 */

#define C_BASE_TERM                          "1Y"                         /* 授信基准年限 */

/* 初始编号 */
#define C_TRD_INTL_ID                        "00001"                      /* 初始成交编号；*/
#define C_OCO_INTL_ID                        "00001"                      /* 初始OCO编号； */
#define C_ORDR_INTL_ID                       "00000001"                   /* 初始订单编号；*/
#define C_IRS_TRD_INTL_ID                    "800001"                     /* 初始成交编号；*/
#define C_SIRS_TRD_INTL_ID                   "700001"                     /* 初始成交编号；*/
#define C_SBFCCP_TRD_INTL_ID                 "600001"                     /* 初始成交编号；*/

#define C_BP_FCTR                            100                          /* BP计算因子 */
#define C_UNIT_TP_BP                         0                            /* 价格单位为bp */
#define C_UNIT_TP_PER                        1                            /* 价格单位为% */

#define C_SEND_FLAG                          1                            /* 是否发送 */
#define C_NOSEND_FLAG                        0                            /* 不发送 */


/* 最大授信额度 */
#define C_MAX_CRDT_AMNT                      1000000000000                /* 最大授信额度 */
#define C_MIN_UNIT                           0.0001                       /* 最小交易单位 */
#define C_PRC_L                              1                            /* 按照左腿价格来刷新隐含订单 */
#define C_PRC_R                              2                            /* 按照左腿价格来刷新隐含订单 */
#define C_PRC_ALL                            3                            /* 普通方法刷新隐含订单 */
#define C_BRDG_FLAG                          "bridgeFlag"                 /* 隐含订单开关 */
#define C_RISK_MIN_UNIT                      1                            /* 风险系数最小值 */
#define C_RISK_MAX_UNIT                      10000000                     /* 风险系数最大值 */

/* API订单价格范围 */
#define C_API_ORDRPRC_MAX                    999.9999                     /* 订单价格最大值 */
#define C_API_ORDRPRC_MAX_SIRS               999.9999                     /* SIRS订单价格最大值 */
#define C_API_ORDRPRC_MAX_SBFCCP             999.9999                     /* SBFCCP订单价格最大值 */
#define C_API_ORDRPRC_MIN_IRS                0.0001                       /* 直接订单价格最小值 */
#define C_API_ORDRPRC_MIN_ISP                -999.99                      /* 期差合约订单最小值 */
#define C_API_ORDRPRC_MIN_SIC                -999.99                      /* 基准互换订单最小值 */
#define C_API_ORDRPRC_MIN_SIRS               0                            /* SIRS订单价格最小值 */

#define EX_C_API_ORDRPRC_MAX                99999990                    /* 订单价格最大值 */
#define EX_C_API_ORDRPRC_MAX_SIRS           99999990                    /* SIRS订单价格最大值 */
#define EX_C_API_ORDRPRC_MAX_SBFCCP         99999990                    /* SBFCCP订单价格最大值 */
#define EX_C_API_ORDRPRC_MIN_IRS            10                          /* 直接订单价格最小值 */
#define EX_C_API_ORDRPRC_MIN_ISP            -99999000                   /* 期差合约订单最小值 */
#define EX_C_API_ORDRPRC_MIN_SIC            -99999000                   /* 基准互换订单最小值 */
#define EX_C_API_ORDRPRC_MIN_SIRS           0                           /* SIRS订单价格最小值 */

/* API订单撤销指令类型 */
#define C_API_CANCEL_ONE                     0                            /* 单笔撤销 */
#define C_API_CANCEL_ALL                     1                            /* 全部撤销 */

/* API订单提交指令类型 */
#define C_API_BID                            "1"                          /* 交易方向 BID S/B */
#define C_API_OFFER                          "2"                          /* 交易方向 OFFER B/S */
#define C_API_LMT                            "2"                          /* 限价订单 */
#define C_API_FOK                            "b"                          /* 点击成交（FOK） */

/* API市场和清算方法 */
#define C_API_MKTID_IRS                      "2"                          /* C_API_MKTID_SBF金融工具，2-利率互换 */
#define C_API_MKTDESC_IRS                    "IRS"                        /* 金融工具描述，IRS-利率互换 */
#define C_API_MKTID_SIRS                     "42"                         /* 金融工具，42-标准利率互换 */
#define C_API_MKTDESC_SIRS                   "SIRS"                       /* 金融工具，SIRS-标准利率互换 */
#define C_API_MKTID_SBF                      "43"                         /* 金融工具，43-标准债券远期 */
#define C_API_MKTDESC_SBF                    "SBFWD"                      /* 金融工具，SBFWD-标准债券远期 */
#define C_API_CLEARMTHD_BITATERAL            "13"                         /* 清算方式，43-双边自行清算 */
#define C_API_CLEARMTHD_CENTRAL              "6"                          /* 清算方式，6-集中清算 */

/* API用户标志 */
#define C_API_USRFLAG                        1                            /* API用户标志，1-是 */
#define C_API_NOUSRFLAG                      0                            /* API用户标志，0-否 */

/* 设置和查询提单权限 操作发起平台 */
#define C_DWS                                1                            /* 前台 */
#define C_MBO                                2                            /* 中后台 */

/* 提单权限修改标志（前台用户是否可以修改），枚举值：0-否，1-是 */
#define C_TRD_PVL_YES                        1                            /* 是 */
#define C_TRD_PVL_NO                         0                            /* 否 */

/* 订单，成交编号 */
#define C_IRS_SIRS_ORDRNO                    "IRS_SIRS_ORDR"              /* IRS、SIRS订单编号 */
#define C_IRS_DLNO                           "IRS_DL"                     /* IRS成交编号 */
#define C_SIRS_DLNO                          "SIRS_DL"                    /* SIRS成交编号 */
#define C_SBFCCP_ORDRNO                      "SBFCCP_ORDR"                /* SBFCCP订单编号 */
#define C_SBFCCPDLNO                         "SBFCCP_DL"                  /* SBFCCP成交编号 */
	
	
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

#endif /* _PCK_IRS_DICDATA_H_ */
