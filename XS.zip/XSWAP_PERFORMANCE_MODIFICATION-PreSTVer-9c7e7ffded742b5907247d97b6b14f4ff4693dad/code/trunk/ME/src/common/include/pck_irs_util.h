/***
Created on Aug 02, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _PCK_IRS_UTIL_H_
#define _PCK_IRS_UTIL_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/** 通用检查
    名称：   CommonChk
    功能：   对修改授信、风险系数，提交订单等进行状态检查
    涉及的表或者视图：USR、USR_ONLN、USR_ROLE、SYS_ST_RSRC、RSRC、ORG_INFO、ORG_PRVLG、ROLE、ROLE_PRVLG
  */
ResCodeT CommonChk(char* usrId, int32 in_orgId, int32 funcId, char* token, int32* out_orgId);

/** 通用检查
    名称：   SirsCommonChk
    功能：   对修改授信、风险系数，提交订单等进行状态检查
    涉及的表或者视图：USR、USR_ONLN、USR_ROLE、SYS_ST_RSRC、RSRC、ORG_INFO、ORG_PRVLG、ROLE、ROLE_PRVLG
  */
ResCodeT SirsCommonChk(char* usrId, int32 in_orgId, int32 funcId, char* token, int32* out_orgId);

/** 通用检查
    名称：   SbfCcpCommonChk
    功能：   对修改授信、风险系数，提交订单等进行状态检查
    涉及的表或者视图：USR、USR_ONLN、USR_ROLE、SYS_ST_RSRC、RSRC、ORG_INFO、ORG_PRVLG、ROLE、ROLE_PRVLG
  */
ResCodeT SbfCcpCommonChk(char* usrId, int32 in_orgId, int32 funcId, char* token, int32* out_orgId);

/** 
    名称：   GetBoundId
    功能：   取得IMIX_MSG_OUT表的记录中最大的ID
    涉及的表或者视图：IMIX_MSG_OUT
  */
ResCodeT GetBoundId(int32 connId, uint64* pMaxId);

#endif /* _PCK_IRS_UTIL_H_ */
