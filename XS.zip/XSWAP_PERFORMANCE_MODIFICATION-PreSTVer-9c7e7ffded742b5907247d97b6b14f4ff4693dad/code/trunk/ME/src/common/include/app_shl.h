/***
Created on June 15, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _APP_SHL_
#define _APP_SHL_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "intrnl_msg.h"
#include "err_lib.h"
#include "bit_lib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef enum
{
    /* Add new shl queue type BELOW */
    SHL_Q_TYPE_DFLT = 0,
    SHL_Q_TYPE_EVENT,
    /* Add new shl queue type ABOVE */
    SHL_Q_TYPE_MAX
}ShlQTypeT;

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define NULL_TXN_ID     ((uint32)(-1))

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct ShlCfgInfoS
{
    int32   inQHndl[SHL_Q_TYPE_MAX];
    int32   outQHndl[SHL_Q_TYPE_MAX];
    int32   txnSize;
    int32   bDbSupport;
} ShlCfgInfoT, *pShlCfgInfoT;

typedef struct CallBackCtxS
{
    int32 sendFlg;
} CallBackCtxT, *pCallBackCtxT;

typedef ResCodeT (*AppCallBackT)(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

typedef ResCodeT (*AppDoneCallBackT)();

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT AppShlInit(int32 setId, char *pPrcsName, pShlCfgInfoT  pShlCfgInfo, AppCallBackT fAppCallBack, AppDoneCallBackT fAppDoneCallBack);
ResCodeT AppShlRun();
ResCodeT AppShlShutDown();
ResCodeT AppShlStop();
ResCodeT AppShlWriteSlotToBuff(int32 slotId);
#endif /* _APP_SHL_ */
