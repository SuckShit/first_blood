/***
Created on June 13, 2017
@author: XiaoPing Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _PERF_STAT_HEADER_
#define _PERF_STAT_HEADER_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header files*/
#include "data_type.h"
#include "shm_name.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef enum
{
    MOrdrEntry = 0,       /* Mtchr: Order Entry */
    MDealEntry,           /* Mtchr: Deal Entry */
    MOrdrBrdgng,          /* Mtchr: Order Bridging */
    MktPushTrgr,          /* Market Data Trigger */
    Snd2TdpsMsg,          /* Matcher send message to TDPS */
    OrdrCnfrmMsgSend,     /* Order Confirmation message send */
    DealCnfrmMsgSend,     /* Deal Confirmation message send */
    RspMsgOut,            /* Response message send */
    ReqMsgIn,             /* Request message send */
    TxnCnt,               /* Txn cnt per  */
    TxnDatCnt,            /* Txn data cnt per  */
    Intvl,                /* Constant value: The sampling interval */
    /* This one must always be the last to mark the list's end,
       add new types anywhere before  */
    EndOfTypes
} PerfStatTypesT;

typedef enum
{
    AvgPerSecond,         /* Use PerfStatInc, output is increments per second */
    AvgOfSamples,         /* Use PerfStatSample, output is avg of samples */
    Constant              /* Use PerfStatSetVal, output is constant value */
} PerfStatMethodT;


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define PERF_STAT_DESCR_LEN     30



/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* Structure describing one type */
typedef struct PerfStatDescrType
{
    char              descr[PERF_STAT_DESCR_LEN +1 +1];
    PerfStatMethodT   method;
} PerfStatDescrT, *pPerfStatDescrT;

/* Structure holding the statistics of one type */
typedef struct PerfStatTy
{
    uint64      cnt;
    uint64      samplesBegin;
    uint64      samplesEnd;
} PerfStatT, *pPerfStatT;

// TODO: what's the following pragmas for???
#pragma required_pointer_size save
#pragma required_pointer_size 64
typedef PerfStatT *pPerfStatT;
#pragma required_pointer_size restore


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
extern PerfStatDescrT PERF_STAT[];


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/* Create the shared memory used by PerfStat. Before recording the data of 
   performance data, Monitor should call this function once to prepare the 
   shared memory.
   */
ResCodeT PerfStatShmCreate(pPerfStatT *ppShmRoot);


/* Attach the shared memory used by PerfStat. If the shared memory has been 
   created previously, then call this function to attach it
   and do the other operations.
   */
ResCodeT PerfStatShmAttach(pPerfStatT *ppShmRoot);


/* Delete the shared memory used by PerfStat. If the Monitor finishes recording
   the performance data and the shared memory will no longer be used, 
   Monitor could call this function to free the shared memory.
   */
ResCodeT PerfStatShmDestroy();


/* Increments a counter. (instr 'set' is for future extensions, can be both 0.
   The set can be given either as binary or as text. Text expects 4 characters.
   No terminating 0 is required, i.e,can pass in any record field directly.)
   Function always succeeds. Errors are handled internally, if unrecoverable,
   then collecting statistics is disabled. The function will log a warning 
   in ERRLOG, but no further handling necessary.
   */
ResCodeT PerfStatInc(PerfStatTypesT type);


/* Increment a counter of a sample. Does not yet change any shared memory, 
   just stores the counter process internally. To hand the entire sample over 
   to monitoring process, finish the sample with PerfStatSampleEnd
   */
ResCodeT PerfStatSampleInc(PerfStatTypesT type);


/* Increment a normal counter and a counter of a sample. Combination of a call to 
   PerfStatInc and PerfStatSampleInc. Good if the total number as well as an average
   per Recovery Unit of the same base value is to be collected. 
   */
ResCodeT PerfStatIncPlusSample(PerfStatTypesT typeInc,PerfStatTypesT typeSample);


/* Marks the end of a sample. Hand over the counters as collected previously by  
   PerfStatSampleInc to monitoring process as one sample. Monitoring process will 
   output the average across all samples collected per time period.
   */
ResCodeT PerfStatSampleEnd(PerfStatTypesT type, int32 bLogZeroValue);

/* Invalidate a sample, sets internal counter back to 0.
   In case it really matters, e.g. after a rollback.
   */
ResCodeT PerfStatSampleReset(PerfStatTypesT type);


/* Adds an entire sample to monitoring process. Basically combines the functionality of 
   several calls to PerfStatInc and a call to PerfStatSampleEnd.
   Good if the value to be sampled is available at once and not in several small steps.
   */
ResCodeT PerfStatSampleAdd(PerfStatTypesT type, uint64 cnt);


/* Sets the value of a constant element.
   */
ResCodeT PerfStatSetVal(PerfStatTypesT type, uint64 val);


/* Gets the value of a constant element.
   */
ResCodeT PerfStatGetVal(PerfStatTypesT type, uint64* val);

#endif /* _PERF_STAT_HEADER_ */