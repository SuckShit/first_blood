﻿/***
Created on July 18, 2017
@author: Dongwei Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _DB_CMMN_H_
#define _DB_CMMN_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "data_type.h"
#include "ocilib.h"
#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_COL_NAME_LEN    48
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

typedef struct DbColInfoS
{
    char colFlag[MAX_COL_NAME_LEN];
    char colName[MAX_COL_NAME_LEN];
    int64   valOffset;
    int64   ptrOffset;
    int16   colType;
    int16   valSize;
    char filler[4];
} DbColInfoT, *pDbColInfoT;

typedef enum
{
    DB_COL_INIT = 0,
    /* Add new database type BELOW */
    DB_COL_STRING,
    DB_COL_INT64,
    DB_COL_INT32,
    DB_COL_INT16,
    DB_COL_DOUBLE,
    DB_COL_FLOAT,
    DB_COL_TIMESTAMP,
    DB_COL_DATE,
    DB_COL_BLOB,
    DB_COL_CLOB,
    /* Add new database type ABOVE */
    DB_COL_INVLD
}DbColTypeT;


typedef OCI_Date            DbDateTypeT;     
typedef OCI_Timestamp       DbTimestampTypeT; 
typedef OCI_Lob             DbLobTypeT; 

typedef struct DbConnection {
    OCI_Connection* ociConn;
} DbConn;

typedef struct DbStatement {
    OCI_Statement* ociStmt;
//    OCI_Resultset* ociRstSet;
} DbStmt;

typedef struct DbResultSet {
    OCI_Resultset* ociRstSet;
} DbRstSet;


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT DbCmmnCleanup();
ResCodeT DbCmmnCommit(int32 connId);
ResCodeT DbCmmnConnect(char* pAddr, char* pUser, char* pPasswd, int32* pConnId);
ResCodeT DbCmmnDisconnect(int32 connId);
ResCodeT DbCmmnExcBindVal(int32 connId, int32 stmtId, pDbColInfoT pDbColInfo, int32 colCnt,vectorT * pColFlg, void * pColVal);
ResCodeT DbCmmnExcBindAllVal(int32 connId, int32 stmtId, pDbColInfoT pDbColInfo, int32 colCnt, void * pColVal);
ResCodeT DbCmmnExcSqlNoRslt(int32 connId, int32 stmtId);
ResCodeT DbCmmnExcSqlWithRslt(int32 connId, int32 stmtId);
ResCodeT DbCmmnGetRow(int32 stmntId, int32 colIdx, pDbColInfoT pDbColInfo, void * pColValAddr);
ResCodeT DbCmmnFetchNext(int32 connId, int32 stmntId, int32 infoCnt, pDbColInfoT pDbColInfo, void * pColValAddr);
ResCodeT DbCmmnFmtDateType( char* pValue, DbDateTypeT ** ppDbDateType);
ResCodeT DbCmmnFmtLobType( int32 connId, char* pValue, DbLobTypeT ** ppDbLobType,int32 lobSize, int32 lobType);
ResCodeT DbCmmnFmtTimestampType( char* pValue, DbTimestampTypeT ** ppDbTimestampType);
ResCodeT DbCmmnFreeStmnt(int32 stmntId);
ResCodeT DbCmmnInit();
ResCodeT DbCmmnPrprSql(int32 connId,char* pSql, int32 * pStmntId);
ResCodeT DbCmmnRollback(int32 connId);
ResCodeT DbCmmnFreeDateType( DbDateTypeT * pDbDateType);
ResCodeT DbCmmnFreeTimestampType(DbTimestampTypeT * pDbTimestampType);

void DbCmmnSetColBit(vectorT * pColVct, int32 colIdx);
void DbCmmnSetAllColBit(vectorT * pColVct, int32 colCnt);


/* The following function is for special prepose, do not use if you don't how to use them, thanks */
ResCodeT ExtPrprSttmnt(DbStmt * pDbStmnt, char * pSql);
ResCodeT ExtCreateSttmnt(DbConn * pDbConn, DbStmt * pDbStmnt);
ResCodeT ExtGetConnAddr(int32 connId,DbConn * pDbConn );
ResCodeT ExtExeSql(DbStmt * pDbStmnt);
ResCodeT ExtBindInt(DbStmt * pDbStmnt, char* pColString, int32* pValue);
ResCodeT ExtBindBigInt(DbStmt * pDbStmnt, char* pColString, int64* pValue);
ResCodeT ExtBindTimestamp(DbStmt * pDbStmnt, char* pColString, DbTimestampTypeT ** ppDbTimestamp);
ResCodeT ExtFreeTimestamp( DbTimestampTypeT * pDbTimestamp);
ResCodeT ExtWriteTimestamp( char * pValue, DbTimestampTypeT * pDbTimestamp);
ResCodeT ExtBindArrayInt(DbStmt * pDbStmnt, char* pColString, int32* pValueList);
ResCodeT ExtCreateArrayLob(DbConn * pDbConn, int32 rcrdCnt, DbLobTypeT *** ppDbBuff);
ResCodeT ExtFreeArrayLob(DbLobTypeT ** ppDbBuff);
ResCodeT ExtSetArraySize(DbStmt * pDbStmnt, int32 size);
ResCodeT ExtWriteLob(DbLobTypeT * pDbBuff, void * pInBuff, int32 buffLen);
ResCodeT ExtBindArrayLob(DbStmt * pDbStmnt, char* pColString, DbLobTypeT ** ppDbBuff);
ResCodeT ExtFreeStmnt(DbStmt * pDbStmnt);


#ifdef __cplusplus
}
#endif

#endif /* _DB_COMM_H_ */
