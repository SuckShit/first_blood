/***
Created on May 08, 2017
@author: Brian.Ping
@version $Id
***/

#ifndef _ERR_CODE_
#define _ERR_CODE_


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "UTILITY/error_def.h"
#include "data_type.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


#define TEXT_LEN 300

#define NO_ERR                                      1

#define ERR_MSG_NOT_FOUND                           400002
#define ERR_OPEN_ERR_LOG_ERR                        400003
#define ERR_CREATE_THREAD                           400004
#define ENV_VAR_CONV_ERR                            400005
#define CFG_FILE_LOAD_ERR                           400006
#define CFG_FILE_READ_ERR                           400007
#define ERR_ARCH_EL_ISSUESYSERROR                   400008
#define ERR_ARCH_IO_CLOSE_ERR                       400009
#define ERCD_UNSPECIFIED_ERROR                      400010

/* For Market Init */
#define ERR_BAT_FLG_NOT_YES                         400050
#define ERR_MKT_NOT_INIT                            400051


/* For protocol conversion */
#define APP_CODE_UNHANDLE_MSG                       400101

/** Link List Error Section **/
#define ERR_INVLD_KEY_CMP_FUNC                      400201
#define ERR_INVLD_POINTER                           400202
#define ERR_OUT_OF_MEMORY                           400203
#define ERR_ITEM_ALREADY_EXIST_IN_LINKED_LIST       400204
#define ERR_DUPLICATE_OBJ_IN_LINKED_LIST            400205
#define ERR_OBJ_NOT_IN_LINKED_LIST                  400206
#define ERR_INVLD_SORT_TYPE                         400207
#define ERR_ITEM_NOT_BELONG_TO_LINKED_LIST          400208
#define ERR_INVLD_GET_KEY_FUNC                      400209
#define ERR_INVLD_OBJ_CMP_FUNC                      400210
#define ERR_INVLD_STATIC_LINK_LIST_MODE             400211
#define ERR_INVLD_STATIC_LINK_LIST_ADDRESS          400212
#define ERR_INVLD_PTR_TO_SLOT_ID                    400213
#define ERR_INVLD_STATIC_LINK_LIST_SLOT_SIZE        400214
#define ERR_INVLD_OFFSET_VALUE_OF_STATIC_LINK_LIST_HEAD 400215
#define ERR_DUPLICATE_KEY_IN_LINKED_LIST            400216
#define ERR_INVLD_MEM_FILE_FUNC                     400217

/** Matcher Error Section **/
#define ERR_MATCHER_VECTOR_ERR                      400301
#define ERR_INVLD_SET_ID                            400302
#define ERR_MATCHER_BST_ORD_ERR                     400303
#define ERR_OBK_FREEORDER_FAIL                      400304

/** Share memory section **/
#define ERR_ARCH_MSG_EMPTY_SLOT_ERR                 400401

/** Order book Error Section **/
#define  ERR_OBK_NOT_ENOUGH_BUFFER                  400501
#define  ERR_OBK_NULL_POINTER                       400502
#define  ERR_OBK_SET_ODRBK_FULL                     400503
#define  ERR_OBK_INVLD_PRDCT                        400504
#define  ERR_OBK_NOT_INIT                           400505
#define  ERR_OBK_VECTOR_ERR                         400506
#define  ERR_OBK_TRDRESTR_TYP_INV                   400507
#define  ERR_OBK_ORDR_NOT_EXIST                     400508
#define  ERR_OBK_INVLD_TYPE                         400509
#define  ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER   400510

/** Database Error Section **/
#define ERR_DB_OCI_INIT_ERR                         400601
#define ERR_DB_OCI_NOT_INIT                         400602
#define ERR_DB_OCI_INITIATED                        400603
#define ERR_DB_OCI_CONN_ERR                         400604
#define ERR_DB_OCI_CONN_FULL_ERR                    400605
#define ERR_DB_OCI_CONN_NOT_USE_ERR                 400606
#define ERR_DB_OCI_CREATE_STATE_ERR                 400607
#define ERR_DB_OCI_STATE_FULL_ERR                   400608
#define ERR_DB_OCI_RESULT_FULL_ERR                  400609
#define ERR_DB_OCI_STATE_NOT_USE_ERR                400610
#define ERR_DB_OCI_RESULT_NOT_USE_ERR               400611
#define ERR_DB_OCI_PREPARE_ERR                      400612
#define ERR_DB_OCI_BIND_ERR                         400613
#define ERR_DB_OCI_EXEC_ERR                         400614
#define ERR_DB_OCI_GET_RESULTSET_ERR                400615
#define ERR_DB_OCI_END_OF_RESULTSET_ERR             400616
#define ERR_DB_OCI_COMMIT_ERR                       400617
#define ERR_DB_OCI_ROLLBACK_ERR                     400618

/** Database Common Error Section **/
#define ERR_DB_COMMON_DATA_NUMBER_ERR               400641
#define ERR_DB_COMMON_INVLD_DATATYPE_ERR            400642
#define ERR_DB_COMMON_FETCH_END                     400643

/** Shared Memory error **/
#define ERR_MSG_SHM_TOO_MANY_SHM                    400701
#define ERR_MSG_SHM_SHM_GET_FAIL                    400702
#define ERR_MSG_SHM_SHM_INFO_GET_FAIL               400703
#define ERR_MSG_SHM_SHM_DETACH_FAIL                 400704
#define ERR_MSG_SHM_SHM_DESTORY_FAIL                400705
#define ERR_MSG_SHM_SHM_NOT_CREATED                 400706
#define ERR_MSG_SHM_SHM_FTOK_FAIL                   400707
#define ERR_MSG_SHM_SHM_MAT_FAIL                    400708
#define ERR_MSG_SHM_SHM_OPEN_FAIL                   400709


/** Matcher Error Section **/
#define ERR_MEM_TXN_NOT_INIT                        400801
#define ERR_MEM_TXN_EXCD_MAX_TXN_ID                 400802
#define ERR_MEM_TXN_INVLD_TXN_ID                    400803
#define ERR_MEM_TXN_INVLD_INIT_STS                  400804
#define ERR_MEM_TXN_ITER_DATA_END                   400805
#define ERR_MEM_TXN_INVLD_ELEM_TYPE                 400806
/** Architecture Error **/
#define ERCD_ARCH_INPUT_ARGS                        400901
#define ERCD_ARCH_READ_TRY_AGAIN                    400902
#define ERCD_ARCH_WRITE_TRY_AGAIN                   400903
#define ERCD_ARCH_INVLD_QUEUE_LEN                   400904
#define ERCD_ARCH_INVLD_HNDL                        400905
#define ERCD_ARCH_MALLOC_ERR                        400906
#define ERCD_ARCH_INVLD_BUFFER_SIZE                 400907
#define ERCD_CMN_HASH_LIST_NOT_SUPPORT              400908
#define ERCD_ARCH_BUFF_TOO_SHORT                    400909
#define ERCD_ARCH_SERV_THREAD_HALT                  400910


/** Hash List Error **/
#define ERR_CMN_HASH_LIST_FULL                      401001
#define ERR_CMN_HASH_LIST_NODE_NOT_EXIST            401002
#define ERR_CMN_HASH_LIST_NODE_EXISTED              401003

/** Message Cache Error **/
#define ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE          402001
#define ERR_MSG_CACHE_CACHE_NAME_DUPLICATE          402002
#define ERR_MSG_CACHE_CACHE_THREAD_INDEX_OUTRANGE   402003

/** Application shel error **/
#define ERR_APP_EPOLL_WAIT_ERR                      403001
#define ERR_APP_EPOLL_ADD_ERR                       403002


/** me frame error **/
#define ERR_CAR_DEP_API_CREATE_ERR                  404001
#define ERR_CAR_MAIN_PARAMETER_NUMBERS_ERR          404002
#define ERR_CAR_MARCH_LISTENER_CTEATE_ERR           404003
#define ERR_CAR_DEP_API_INIT_ERR                    404004
#define ERR_CAR_MARCH_LISTENER_INIT_ERR             404005

/* me task error */
#define ERR_MSG_HANDLE_NULL_ERR                     404101
#define ERR_MSG_MAP_OPERATION_ERR                   404102
#define ERR_MSG_ID_ERR                              404103
#define ERR_MSG_NOT_SUPPORT_TYPE                    404104

#define ERR_NMBR_SRVC_INVLD_TYPE                    404201
#define ERR_NMBR_SRVC_INVLD_STS                     404202


/* High Available */
#define ERR_HA_INIT_PRIMARY_FAILED                  410001
#define ERR_HA_INIT_BACKUP_FAILED                   410002
#define ERR_HA_GET_TIME_FAILED                      410003
#define ERR_HA_GET_SETCOUNT_FAILED                  410004
#define ERR_HA_INPUT_SET_ID                         410005
#define ERR_HA_GET_HOSTNAME_FAILED                  410006
#define ERR_HA_TACKOVER_FAILED                      410007
#define ERR_HA_INVALID_SERVER                       410008



#define ERR_CODE_INVLD_EXPIRE_TIME                  500000
#define ERR_CODE_INVLD_FROZEN_ORDER                 500001
#define ERR_CODE_INVLD_ORDER_ACTION                 500002
#define ERR_CODE_INVLD_OCO_ID                       500003
#define ERR_CODE_INVLD_TEMP_OCO_ID                  500004
#define ERR_CODE_INVLD_ORDER_STATUS                 500005
#define ERR_CODE_ORDER_NOT_EXIST                    500006
#define ERR_CODE_INVLD_TRD_CNCL_OT                  500007
#define ERR_CODE_INVLD_NOT_LOGON                    500008
#define ERR_CODE_INVLD_ORG_FRD                      500009
#define ERR_CODE_INVLD_ORG_NOPRV                    500010
#define ERR_CODE_INVLD_MKT_NOT_PMT                  500011
#define ERR_CODE_INVLD_GND_ORG_NULL                 500012
#define ERR_CODE_INVLD_GND_CRT_MDF                  500013
#define ERR_CODE_INVLD_BGD_CRT_MDF                  500014
#define ERR_CODE_INVLD_TOKEN_ERROR                  500015
#define ERR_CODE_INVLD_ROLE_PRV                     500016
#define ERR_CODE_INVLD_ORG_DEL                      500017
#define ERR_CODE_INVLD_RCKCNF_OR                    500018
#define ERR_CODE_INVLD_USER_NOTMATCH                500019
#define ERR_CODE_INVLD_ST_NOT_CRCT                  500020
#define ERR_CODE_INVLD_CNTRCT_NOTY                  500021
#define ERR_CODE_INVLD_PAYCRT_NTFND                 500022
#define ERR_CODE_INVLD_GETCRT_NTFND                 500023
#define ERR_CODE_INVLD_PAYRSK_NTFND                 500024
#define ERR_CODE_INVLD_GETRSK_NTFND                 500025
#define ERR_CODE_INVLD_CRTRL_NOTFILL                500026
#define ERR_CODE_INVLD_CRTRL_ERROR                  500027
#define ERR_CODE_INVLD_CRT_INVLD                    500028
#define ERR_CODE_INVLD_CRTAMT_INVLD                 500029
#define ERR_CODE_INVLD_CRTUPTY_ERROR                500030
#define ERR_CODE_INVLD_CRTAMTTY_ERROR               500031
#define ERR_CODE_INVLD_CNTRCT_NOTEXIST              500032
#define ERR_CODE_INVLD_ORDPRC_ERROR                 500033
#define ERR_CODE_INVLD_MKTST_INVLD                  500034
#define ERR_CODE_PRC_LESS_THAN_REF                  500035
#define ERR_CODE_INVLD_TRD_NT_EXST                  500036
#define ERR_CODE_INVLD_TRD_CNT_MDF                  500037
#define ERR_CODE_ETL_BAT_FAIL                       500038
#define ERR_CODE_INVLD_QURYPG_ERROR                 500039
#define ERR_CODE_INVLD_OCO_SET_FLAG                 500040
#define ERR_CODE_INVLD_FUNCID_INVLD                 500041
#define ERR_CODE_INVLD_ORG_UNFRD                    500042
#define ERR_CODE_BAT_FLG_EMPTY                      500043
#define ERR_CODE_ETL_FLG_EMPTY                      500044
#define ERR_CODE_INIT_FLG_EMPTY                     500045
#define ERR_CODE_REFCNTRCT_EMPTY                    500046
#define ERR_CODE_REFCNTRCT_RSK_EMPTY                500047
#define ERR_CODE_REFCNTRCT_LMT_EMPTY                500048
#define ERR_CODE_CLCTIME_EMPTY                      500049
#define ERR_CODE_MKTSTATE_EMPTY                     500050
#define ERR_CODE_INVLD_USRLGIN_ERROR                500051
#define ERR_CODE_INVLD_ORDR_QTY                     500052
#define ERR_CODE_INVLD_ORG_FRZ_REQST                500053
#define ERR_CODE_INVLD_INVALID_USER                 500054
#define ERR_CODE_INVLD_QUERY_DATE                   500055
#define ERR_CODE_INVLD_QUERY_STRTDATE               500056
#define ERR_CODE_INVLD_OCO_COUNT                    500057
#define ERR_CODE_INVLD_ORDR_PRC                     500058
#define ERR_CODE_INVLD_INVLID_AMNT                  500059
#define ERR_CODE_INVLD_CRDT_MDFING                  500060
#define ERR_CODE_INVLD_OCO_NUM                      500061
#define ERR_CODE_CRDT_RMN_LMT                       500062
#define ERR_CODE_INVLD_CNCL_MKCLS                   500063
#define ERR_CODE_CNTRCT_DL_UNIT_EMPTY               500064
#define ERR_CODE_ORD_CLOSED                         500065
#define ERR_CODE_ORD_CLOSED_NO_C                    500066
#define ERR_CODE_MKT_CLOSED_NO_D                    500067
#define ERR_CODE_LGN_IN_NO_PRV                      500068
#define ERR_CODE_INVLD_PARAM_CRDT_NUM               500069
#define ERR_CODE_PARAM_CRDT_NUM_INVLD               500070
#define ERR_CODE_PARAM_CNTRCT_ERR_ST                500071
#define ERR_CODE_INVLD_QUERY_DATE1                  500072
#define ERR_CODE_INVLD_MRK_ST                       500073
#define ERR_CODE_INVLD_ACNT_DL                      500074
#define ERR_CODE_SECOND_ACNT_DL                     500075
#define ERR_CODE_CNTRT_MDF                          500076
#define ERR_CODE_INVLD_CAPICALACT                   500077
#define ERR_CODE_INVLD_TRMNL_MK                     500078
#define ERR_CODE_INVLD_CANCEL_F                     500079
#define ERR_CODE_INVLD_CANCELED                     500080
#define ERR_CODE_INVLD_TERMINED                     500081
#define ERR_CODE_INVLD_TRD_TRMN_OT                  500082
#define ERR_CODE_DEF_ACNT_SAV                       500083
#define ERR_CODE_INVLD_DPST_CAPICALACT              500084
#define ERR_CODE_INVLD_TRMNL_MKCLS                  500085
#define ERR_CODE_PARAM_STAT_NUM_INVLD               500185
#define ERR_CODE_SECOND_DLVY_BOND                   500086
#define ERR_CODE_DPST_ACNT_NO_EXIST                 500087
#define ERR_CODE_DPST_ACNT_SHLD_EXIST               500088
#define ERR_CODE_ACNT_SHLD_NOT_CHANGE               500089
#define ERR_CODE_ACNT_SHLD_NOT_DELETE               500090
#define ERR_CODE_ACNT_NO_LINKED                     500091
#define ERR_CODE_DPST_ACNT_NO_LINKED                500092
#define ERR_CODE_DPST_ACNT_MUST_ACNT                500093
#define ERR_CODE_DPST_ACNT_SHLD_ACNT                500094
#define ERR_CODE_INVLD_DPST_ACNT_DL                 500095
#define ERR_CODE_DEF_DPST_ACNT_SAV                  500096
#define ERR_CODE_DPST_SHLD_EXIST                    500097
#define ERR_CODE_ACNT_SHLD_EXIST                    500098
#define ERR_CODE_ACNT_SHLD_NOT_ADD                  500099
#define ERR_CODE_ACNT_SHLD_NOT_CHANGE2              500100
#define ERR_CODE_CCP_CRDT_OVER_LIMIT                500101
#define ERR_CODE_CCP_CRDT_ST_LIMIT                  500102
#define ERR_CODE_PERMISSION_INEDITABLE              500103
#define ERR_CODE_INVLD_USRMKT_PRV                   500104
#define ERR_CODE_CCP_CRDT_ST_OFF                    500105
#define ERR_CODE_INVLD_INVALID_ORG                  500106
#define ERR_CODE_INVLD_INVALID_C_QSS                500107
#define ERR_CODE_FORCE_CANCEL                       500108
#define ERR_CODE_FORCE_FREEZE                       500109
#define ERR_CODE_MORE_THAN_REF                      500110
#define ERR_CODE_ORDR_CANCEL_OCO                    500111
#define ERR_CODE_INVLD_CRDT_PSTN                    500112
#define ERR_CODE_FORCE_MODIFY                       500113
#define ERR_CODE_CNTRCT_EXISTS_DL                   500114
#define ERR_CODE_CNTRCT_REMOVE_DL                   500115
#define ERR_CODE_CNTRCT_EXISTS                      500116
#define ERR_CODE_TRD_END_DT                         500117
#define ERR_CODE_INVLD_SIRS_CANCEL_F                500118
#define ERR_CODE_INVLD_FLWVAL                       500119
#define ERR_CODE_INVLD_BOND_MDFY_TM                 500120
#define ERR_CODE_INVLD_CRDT_TM                      500121
#define ERR_CODE_INVLD_BRDG_FEE                     500122
#define ERR_CODE_INVLD_ORDR_PRV                     500123
#define ERR_CODE_INVLD_DL_ST                        500124
#define ERR_CODE_BIL_EXISTS                         500125
#define ERR_CODE_BIL_SINGLE                         500126

#define APIERR_CODE_OVERTIME                        600001
#define APIERR_CODE_CRT_MODIFYING                   600002
#define APIERR_CODE_INVLD_MDF_FREQ                  600003
#define APIERR_CODE_INVLD_RSK_CFCNT_TP              600004
#define APIERR_CODE_INVLD_INCOME                    600005
#define APIERR_CODE_INVLD_ORGCD                     600006
#define APIERR_CODE_INVLD_OTHERS                    600007
#define APIERR_CODE_INVLD_CRDTPAIR                  600008
#define APIERR_CODE_INVLD_CRDTMTHD                  600009
#define APIERR_CODE_USR_LOGOUT                      600011
#define APIERR_CODE_INVLD_USER                      600012
#define APIERR_CODE_INVLD_TOKEN                     600014
#define APIERR_CODE_USER_FORBID                     600015
#define APIERR_CODE_ORG_FORBID                      600016
#define APIERR_CODE_INVLD_MKT_NOT_PMT               600017
#define APIERR_CODE_INVLD_ROLE_PRV                  600018
#define APIERR_CODE_INVLD_CRDT_MDFY_TM              600019
#define APIERR_CODE_INVLD_OWNR_ORG_CD               600020
#define APIERR_CODE_INVLD_QUERY_MTHD                600021
#define APIERR_CODE_INVLD_RSK_CNTRCT                600022
#define APIERR_CODE_UNSUPPORT_CRT_TYPE              600023
#define APIERR_CODE_INVLD_OWNR_USRID                600024
#define APIERR_CODE_INVLD_MARKET_ID                 600025
#define APIERR_CODE_INVLD_SUBQT_INCOME              600026
#define APIERR_CODE_INVLD_DUP_UNSUBQT               600027
#define APIERR_CODE_INVLD_DUP_SUBQT                 600028
#define APIERR_CODE_INVLD_ORDR_AMNT                 600029
#define APIERR_CODE_INVLD_APIUSR                    600030
#define APIERR_CODE_INVLD_PRC                       600031
#define APIERR_CODE_INVLD_ORDRINCOME                600032
#define APIERR_CODE_INVLD_ORDR                      600033
#define APIERR_CODE_INVLD_REQID                     600034
#define APIERR_CODE_REP_CANCEL                      600035
#define APIERR_CODE_ORD_CLOSED_NO_C                 600036
#define APIERR_CODE_ORD_BOOF                        600037
#define APIERR_CODE_INVALID_ORDR_ID                 600038
#define APIERR_CODE_ALREADY_LOGIN                   600039
#define APIERR_CODE_INVLD_USR_ORDR                  600040
#define APIERR_CODE_INVLD_EXPRTM                    600041
#define APIERR_CODE_NO_ACTIVEORD                    600042
#define APIERR_CODE_CANNT_APIORD                    600043
#define APIERR_CODE_INVLD_TRDNM                     600044
#define APIERR_CODE_TRD_NO_PVL                      600045


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct ErrInfoS
{
    int64 errCode;
    int64 errType;
    char  errText[TEXT_LEN];
} ErrInfoT, *pErrInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static ErrInfoT gErrInfoList[] =
{

    {NO_ERR,                                  ERROR_HANDLE_LOG,       "SUCCESS"},
    {ERR_MSG_NOT_FOUND,                       ERROR_HANDLE_LOG,       "Error messgae was not found"},
    {ERR_OPEN_ERR_LOG_ERR,                    ERROR_HANDLE_LOG,       "Open error log error"},
    {ERR_CREATE_THREAD,                       ERROR_HANDLE_LOG,       "Create thread error"},
    {ENV_VAR_CONV_ERR,                        ERROR_HANDLE_LOG,       "Value convert failed"},
    {CFG_FILE_LOAD_ERR,                       ERROR_HANDLE_LOG,       "Cfg File cannot be loaded"},
    {CFG_FILE_READ_ERR,                       ERROR_HANDLE_LOG,       "Cfg File cannot be read"},
    {ERR_ARCH_EL_ISSUESYSERROR,               ERROR_HANDLE_LOG,       "Arch system error"},
    {ERR_ARCH_IO_CLOSE_ERR,                   ERROR_HANDLE_LOG,       "Arch io error"},
    {ERCD_UNSPECIFIED_ERROR,                  ERROR_HANDLE_LOG,       "unspecified error"},

    /* For Market Init */
    {ERR_BAT_FLG_NOT_YES,                     ERROR_HANDLE_LOG,       "Batch does not finished"},
    {ERR_MKT_NOT_INIT,                        ERROR_HANDLE_LOG,       "Market is not init"},

    /* for IMIX conversion*/
    {APP_CODE_UNHANDLE_MSG,                   ERROR_HANDLE_LOG,       "Application code not handled"},

    {ERR_INVLD_KEY_CMP_FUNC,                  ERROR_HANDLE_LOG,       "Linked list error, invalid key compare fucntion"},//???
    {ERR_INVLD_POINTER,                       ERROR_HANDLE_LOG,       "Linked list error,Invalid pointer"},
    {ERR_OUT_OF_MEMORY,                       ERROR_HANDLE_LOG,       "Linked list error,out of memory"},
    {ERR_ITEM_ALREADY_EXIST_IN_LINKED_LIST,   ERROR_HANDLE_LOG,       "Linked list error,item already exist"},
    {ERR_DUPLICATE_OBJ_IN_LINKED_LIST,        ERROR_HANDLE_LOG,       "Linked list error,duplicate object in list"},
    {ERR_OBJ_NOT_IN_LINKED_LIST,              ERROR_HANDLE_LOG,       "Linked list error,object not in list"},
    {ERR_INVLD_SORT_TYPE,                     ERROR_HANDLE_LOG,       "Linked list error,invalid sort type"},
    {ERR_ITEM_NOT_BELONG_TO_LINKED_LIST,      ERROR_HANDLE_LOG,       "Linked list error,item not belongs to list"},
    {ERR_INVLD_GET_KEY_FUNC,                  ERROR_HANDLE_LOG,       "Linked list error,invalid get key funciton"},
    {ERR_INVLD_OBJ_CMP_FUNC,                  ERROR_HANDLE_LOG,       "Linked list error,invalid object compare function"},
    {ERR_INVLD_STATIC_LINK_LIST_MODE,         ERROR_HANDLE_LOG,       "Linked list error,invalid static link list mode"},
    {ERR_INVLD_STATIC_LINK_LIST_ADDRESS,      ERROR_HANDLE_LOG,       "Linked list error,invalid static link list address"},
    {ERR_INVLD_PTR_TO_SLOT_ID,                ERROR_HANDLE_LOG,       "Linked list error,invalid ptr to slot id"},//???
    {ERR_INVLD_STATIC_LINK_LIST_SLOT_SIZE,    ERROR_HANDLE_LOG,       "Linked list error,invalid static link list size"},
    {ERR_INVLD_OFFSET_VALUE_OF_STATIC_LINK_LIST_HEAD,    ERROR_HANDLE_LOG,       "Linked list error, invalid offset value of static link list head"},
    {ERR_DUPLICATE_KEY_IN_LINKED_LIST,        ERROR_HANDLE_LOG,       "Linked list error, duplicate key in list."},
    {ERR_INVLD_MEM_FILE_FUNC,                 ERROR_HANDLE_LOG,       "Linked list error,invalid memory file fucntion"},

    /** Matcher Error Section **/
    {ERR_MATCHER_VECTOR_ERR,                  ERROR_HANDLE_LOG,       "Matcher vector error"},
    {ERR_INVLD_SET_ID,                        ERROR_HANDLE_LOG,       "Invalid set id"},
    {ERR_MATCHER_BST_ORD_ERR,                 ERROR_HANDLE_LOG,       "Matcher best order error"},
    {ERR_OBK_FREEORDER_FAIL,                  ERROR_HANDLE_LOG,       "OrderBook free order fail"},

    /** Share memory section **/
    {ERR_ARCH_MSG_EMPTY_SLOT_ERR,             ERROR_HANDLE_LOG,       "Arch message empty slot error"},

    /** Order book Error Section **/
    {ERR_OBK_NOT_ENOUGH_BUFFER,              ERROR_HANDLE_LOG,       "Order book is not enough to buffer"},
    {ERR_OBK_NULL_POINTER,                   ERROR_HANDLE_LOG,       "Order book has no pointer"},
    {ERR_OBK_SET_ODRBK_FULL,                 ERROR_HANDLE_LOG,       "Set Order book to full"},
    {ERR_OBK_INVLD_PRDCT,                    ERROR_HANDLE_LOG,       "Invalid product id <%ld>"},
    {ERR_OBK_NOT_INIT,                       ERROR_HANDLE_LOG,       "Order book not initialized"},
    {ERR_OBK_VECTOR_ERR,                     ERROR_HANDLE_LOG,       "Order book vector error"},
    {ERR_OBK_TRDRESTR_TYP_INV,               ERROR_HANDLE_LOG,       "Invalid Order trade restriction"},
    {ERR_OBK_ORDR_NOT_EXIST,                 ERROR_HANDLE_LOG,       "Order is not exist"},
    {ERR_OBK_INVLD_TYPE,                     ERROR_HANDLE_LOG,       "Invalid order type"},
    {ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER,  ERROR_HANDLE_LOG,    "No price lead fo this fix price"},


    /** Database Error Section **/
    {ERR_DB_OCI_INIT_ERR,                    ERROR_HANDLE_LOG,       "DB error: oci initiate error"},
    {ERR_DB_OCI_NOT_INIT,                    ERROR_HANDLE_LOG,       "DB error: oci not initiate error"},
    {ERR_DB_OCI_INITIATED,                   ERROR_HANDLE_LOG,       "DB error: oci has been initiated error"},
    {ERR_DB_OCI_CONN_ERR,                    ERROR_HANDLE_LOG,       "DB error: oci connection error"},
    {ERR_DB_OCI_CONN_FULL_ERR,               ERROR_HANDLE_LOG,       "DB error: oci connection full already error"},
    {ERR_DB_OCI_CONN_NOT_USE_ERR,            ERROR_HANDLE_LOG,       "DB error: oci connection not use error"},
    {ERR_DB_OCI_CREATE_STATE_ERR,            ERROR_HANDLE_LOG,       "DB error: oci failed to create statement"},
    {ERR_DB_OCI_STATE_FULL_ERR,              ERROR_HANDLE_LOG,       "DB error: oci statement full already error"},
    {ERR_DB_OCI_RESULT_FULL_ERR,             ERROR_HANDLE_LOG,       "DB error: oci resultset full already error"},
    {ERR_DB_OCI_STATE_NOT_USE_ERR,           ERROR_HANDLE_LOG,       "DB error: oci statement not use error"},
    {ERR_DB_OCI_RESULT_NOT_USE_ERR,          ERROR_HANDLE_LOG,       "DB error: oci resultset not use error"},
    {ERR_DB_OCI_PREPARE_ERR,                 ERROR_HANDLE_LOG,       "DB error: oci failed to prepare"},
    {ERR_DB_OCI_BIND_ERR,                    ERROR_HANDLE_LOG,       "DB error: oci failed to bind"},
    {ERR_DB_OCI_EXEC_ERR,                    ERROR_HANDLE_LOG,       "DB error: oci failed to execute"},
    {ERR_DB_OCI_GET_RESULTSET_ERR,           ERROR_HANDLE_LOG,       "DB error: oci failed to get result set"},
    {ERR_DB_OCI_END_OF_RESULTSET_ERR,        ERROR_HANDLE_LOG,       "DB error: end of resultset error"},
    {ERR_DB_OCI_COMMIT_ERR,                  ERROR_HANDLE_LOG,       "DB error: oci failed to commit"},
    {ERR_DB_OCI_ROLLBACK_ERR,                ERROR_HANDLE_LOG,       "DB error: oci failed to rollback"},

    {ERR_DB_COMMON_DATA_NUMBER_ERR,          ERROR_HANDLE_LOG,       "DB error: data number error"},
    {ERR_DB_COMMON_INVLD_DATATYPE_ERR,       ERROR_HANDLE_LOG,       "DB error: data type undefined error"},
    {ERR_DB_COMMON_FETCH_END,                ERROR_HANDLE_LOG,       "Database record fetching end."},


    /** Shared Memory error **/
    {ERR_MSG_SHM_TOO_MANY_SHM,               ERROR_HANDLE_LOG,       "Too many shared memory"},
    {ERR_MSG_SHM_SHM_GET_FAIL,               ERROR_HANDLE_LOG,       "Failed to get shared memory"},
    {ERR_MSG_SHM_SHM_INFO_GET_FAIL,          ERROR_HANDLE_LOG,       "Failed to get shared memory information"},
    {ERR_MSG_SHM_SHM_DETACH_FAIL,            ERROR_HANDLE_LOG,       "Failed to detach shared memory"},
    {ERR_MSG_SHM_SHM_DESTORY_FAIL,           ERROR_HANDLE_LOG,       "Failed to destroy shared memory"},
    {ERR_MSG_SHM_SHM_NOT_CREATED,            ERROR_HANDLE_LOG,       "Shared memory is not created"},
    {ERR_MSG_SHM_SHM_FTOK_FAIL,              ERROR_HANDLE_LOG,       "Failed to FTOK shared memory"},//??
    {ERR_MSG_SHM_SHM_MAT_FAIL,               ERROR_HANDLE_LOG,       "Failed to match shared memory"},//??
    {ERR_MSG_SHM_SHM_OPEN_FAIL,              ERROR_HANDLE_LOG,       "Failed to open sahred memory"},

    /** Memory TXN Error Section **/
    {ERR_MEM_TXN_NOT_INIT,                   ERROR_HANDLE_LOG,      "Memory TXN not initialized"},
    {ERR_MEM_TXN_EXCD_MAX_TXN_ID,            ERROR_HANDLE_LOG,       "Memory TXN error: exceed max TXN ID"},
    {ERR_MEM_TXN_INVLD_TXN_ID,               ERROR_HANDLE_LOG,       "Invalid Txn Id <%d>"},
    {ERR_MEM_TXN_INVLD_INIT_STS,             ERROR_HANDLE_LOG,       "Invalid init status"},
    {ERR_MEM_TXN_ITER_DATA_END,              ERROR_HANDLE_LOG,       "Iterate Txn data end"},
    {ERR_MEM_TXN_INVLD_ELEM_TYPE,            ERROR_HANDLE_LOG,       "Invalid element data"},


    /** Architecture Error **/
    {ERCD_ARCH_INPUT_ARGS,                   ERROR_HANDLE_LOG,       "Input arguments error"},//??
    {ERCD_ARCH_READ_TRY_AGAIN,               ERROR_HANDLE_LOG,       "Try again to read"},//??
    {ERCD_ARCH_WRITE_TRY_AGAIN,              ERROR_HANDLE_LOG,       "Try again to write"},
    {ERCD_ARCH_INVLD_QUEUE_LEN,              ERROR_HANDLE_LOG,       "Invalid queue length"},
    {ERCD_ARCH_INVLD_HNDL,                   ERROR_HANDLE_LOG,       "Invalid hndl"},//??
    {ERCD_ARCH_MALLOC_ERR,                   ERROR_HANDLE_LOG,       "Invalid hndl"},//??
    {ERCD_ARCH_INVLD_BUFFER_SIZE,            ERROR_HANDLE_LOG,       "Invalid buffer size"},
    {ERCD_CMN_HASH_LIST_NOT_SUPPORT,         ERROR_HANDLE_LOG,       "Not support hash list"},
    {ERCD_ARCH_BUFF_TOO_SHORT,               ERROR_HANDLE_LOG,       "Buffer is too short"},
    {ERCD_ARCH_SERV_THREAD_HALT,             ERROR_HANDLE_LOG,       "Serv Thread halt"},

    /** Hash List Error **/
    {ERR_CMN_HASH_LIST_FULL,                 ERROR_HANDLE_LOG,       "Hash list is full"},
    {ERR_CMN_HASH_LIST_NODE_NOT_EXIST,       ERROR_HANDLE_LOG,       "Hash list node is not existed"},
    {ERR_CMN_HASH_LIST_NODE_EXISTED,         ERROR_HANDLE_LOG,       "Hash list node is existed"},

    /** Message Cache Error **/
    {ERR_MSG_CACHE_CACHE_INDEX_OUTRANGE,     ERROR_HANDLE_LOG,       "Catch indec our of range"},
    {ERR_MSG_CACHE_CACHE_NAME_DUPLICATE,     ERROR_HANDLE_LOG,       "Catch name is duplicate"},
    {ERR_MSG_CACHE_CACHE_THREAD_INDEX_OUTRANGE,   ERROR_HANDLE_LOG,  "Cache thread index out of range"},

    /** Application shell Error **/
    {ERR_APP_EPOLL_WAIT_ERR,                ERROR_HANDLE_LOG,       "Epoll wait error"},
    {ERR_APP_EPOLL_ADD_ERR,                 ERROR_HANDLE_LOG,       "Epoll add error"},

    {ERR_CAR_DEP_API_CREATE_ERR,            ERROR_HANDLE_LOG,       "car dep api create error"},
    {ERR_CAR_MAIN_PARAMETER_NUMBERS_ERR,    ERROR_HANDLE_LOG,       "car main parameter numbers error"},
    {ERR_CAR_MARCH_LISTENER_CTEATE_ERR,     ERROR_HANDLE_LOG,       "car match listener create error"},
    {ERR_CAR_DEP_API_INIT_ERR,              ERROR_HANDLE_LOG,       "car dep api init error"},
    {ERR_CAR_MARCH_LISTENER_INIT_ERR,       ERROR_HANDLE_LOG,       "car match listener init error"},

    {ERR_MSG_HANDLE_NULL_ERR,               ERROR_HANDLE_LOG,       "Message handle null error"},
    {ERR_MSG_MAP_OPERATION_ERR,             ERROR_HANDLE_LOG,       "Message map operation error"},
    {ERR_MSG_ID_ERR,                        ERROR_HANDLE_LOG,       "Message id error"},
    {ERR_MSG_NOT_SUPPORT_TYPE,              ERROR_HANDLE_LOG,       "Message type is not supportted"},


    /** Nmbr srvc error **/
    {ERR_NMBR_SRVC_INVLD_TYPE,              ERROR_HANDLE_LOG,       "Failed to get type"},
    {ERR_NMBR_SRVC_INVLD_STS,               ERROR_HANDLE_LOG,       "Failed to get sts"},


    /** High Available **/
    {ERR_HA_INIT_PRIMARY_FAILED,            ERROR_HANDLE_LOG,       "Failed to init primary"},
    {ERR_HA_INIT_BACKUP_FAILED,             ERROR_HANDLE_LOG,       "Failed to init backup"},
    {ERR_HA_GET_TIME_FAILED,                ERROR_HANDLE_LOG,       "Failed to get time"},
    {ERR_HA_GET_SETCOUNT_FAILED,            ERROR_HANDLE_LOG,       "Failed to get the set count"},
    {ERR_HA_INPUT_SET_ID,                   ERROR_HANDLE_LOG,       "Input set id is invalid."},
    {ERR_HA_GET_HOSTNAME_FAILED,            ERROR_HANDLE_LOG,       "Failed to get host name."},
    {ERR_HA_TACKOVER_FAILED,                ERROR_HANDLE_LOG,       "Tackover failed."},
    {ERR_HA_INVALID_SERVER,                 ERROR_HANDLE_LOG,       "Invalid server."},


    {ERR_CODE_INVLD_EXPIRE_TIME             ,0,                     "有效时间应晚于当前时间"},
    {ERR_CODE_INVLD_FROZEN_ORDER            ,0,                     "原订单不是冻结状态"},
    {ERR_CODE_INVLD_ORDER_ACTION            ,0,                     "无效的订单处理代码"},
    {ERR_CODE_INVLD_OCO_ID                  ,0,                     "无效的OCO编号"},
    {ERR_CODE_INVLD_TEMP_OCO_ID             ,0,                     "无效的客户端临时OCO编号"},
    {ERR_CODE_INVLD_ORDER_STATUS            ,0,                     "无效的订单状态"},
    {ERR_CODE_ORDER_NOT_EXIST               ,0,                     "订单不存在"},
    {ERR_CODE_INVLD_TRD_CNCL_OT             ,0,                     "撤销时间已超时"},
    {ERR_CODE_INVLD_NOT_LOGON               ,0,                     "用户未登录或已登出"},
    {ERR_CODE_INVLD_ORG_FRD                 ,0,                     "机构已被禁用"},
    {ERR_CODE_INVLD_ORG_NOPRV               ,0,                     "无权操作此机构"},
    {ERR_CODE_INVLD_MKT_NOT_PMT             ,0,                     "此时段内无法修改"},
    {ERR_CODE_INVLD_GND_ORG_NULL            ,0,                     "场务端操作时输入机构标识为空"},
    {ERR_CODE_INVLD_GND_CRT_MDF             ,0,                     "正在修改,请与场务联系！"},
    {ERR_CODE_INVLD_BGD_CRT_MDF             ,0,                     "其他用户正在修改"},
    {ERR_CODE_INVLD_TOKEN_ERROR             ,0,                     "Token认证不一致请重新登录"},
    {ERR_CODE_INVLD_ROLE_PRV                ,0,                     "您没有此权限"},
    {ERR_CODE_INVLD_ORG_DEL                 ,0,                     "该机构被删除"},
    {ERR_CODE_INVLD_RCKCNF_OR               ,0,                     "风险系数超出范围"},
    {ERR_CODE_INVLD_USER_NOTMATCH           ,0,                     "用户不匹配"},
    {ERR_CODE_INVLD_ST_NOT_CRCT             ,0,                     "授信状态不正确"},
    {ERR_CODE_INVLD_CNTRCT_NOTY             ,0,                     "合约类型异常"},
    {ERR_CODE_INVLD_PAYCRT_NTFND            ,0,                     "支付方授信额度未找到"},
    {ERR_CODE_INVLD_GETCRT_NTFND            ,0,                     "收取方授信额度未找到"},
    {ERR_CODE_INVLD_PAYRSK_NTFND            ,0,                     "支付方风险系数未找到"},
    {ERR_CODE_INVLD_GETRSK_NTFND            ,0,                     "收取方风险系数未找到"},
    {ERR_CODE_INVLD_CRTRL_NOTFILL           ,0,                     "关系授信不满5家"},
    {ERR_CODE_INVLD_CRTRL_ERROR             ,0,                     "授信方式异常"},
    {ERR_CODE_INVLD_CRT_INVLD               ,0,                     "未满足有效授信要求!"},
    {ERR_CODE_INVLD_CRTAMT_INVLD            ,0,                     "无效初始额度"},
    {ERR_CODE_INVLD_CRTUPTY_ERROR           ,0,                     "授信更新方式错误"},
    {ERR_CODE_INVLD_CRTAMTTY_ERROR          ,0,                     "授信额度初始方式错误"},
    {ERR_CODE_INVLD_CNTRCT_NOTEXIST         ,0,                     "合约品种不存在"},
    {ERR_CODE_INVLD_ORDPRC_ERROR            ,0,                     "单笔最小报价大于单笔最大报价"},
    {ERR_CODE_INVLD_MKTST_INVLD             ,0,                     "市场状态无效"},
    {ERR_CODE_PRC_LESS_THAN_REF             ,0,                     "报价超过盘中参考区间，是否继续"},
    {ERR_CODE_INVLD_TRD_NT_EXST             ,0,                     "成交不存在"},
    {ERR_CODE_INVLD_TRD_CNT_MDF             ,0,                     "成交状态不能修改"},
    {ERR_CODE_ETL_BAT_FAIL                  ,0,                     "ETL或批处理执行失败"},
    {ERR_CODE_INVLD_QURYPG_ERROR            ,0,                     "页码超出不翻转"},
    {ERR_CODE_INVLD_OCO_SET_FLAG            ,0,                     "无效的OCO设置标志"},
    {ERR_CODE_INVLD_FUNCID_INVLD            ,0,                     "非法的功能号"},
    {ERR_CODE_INVLD_ORG_UNFRD               ,0,                     "已活动"},
    {ERR_CODE_BAT_FLG_EMPTY                 ,0,                     "BAT_FLAG字段缺失"},
    {ERR_CODE_ETL_FLG_EMPTY                 ,0,                     "ETL_FLAG字段缺失"},
    {ERR_CODE_INIT_FLG_EMPTY                ,0,                     "INIT_FLAG字段缺失"},
    {ERR_CODE_REFCNTRCT_EMPTY               ,0,                     "crdtCntrct字段缺失"},
    {ERR_CODE_REFCNTRCT_RSK_EMPTY           ,0,                     "授信参考合约对应的风险系数缺失"},
    {ERR_CODE_REFCNTRCT_LMT_EMPTY           ,0,                     "crdtUnit字段缺失"},
    {ERR_CODE_CLCTIME_EMPTY                 ,0,                     "lastPrcCalcTime字段缺失"},
    {ERR_CODE_MKTSTATE_EMPTY                ,0,                     "marketState字段缺失"},
    {ERR_CODE_INVLD_USRLGIN_ERROR           ,0,                     "未开市无法登录"},
    {ERR_CODE_INVLD_ORDR_QTY                ,0,                     "无效的订单数量"},
    {ERR_CODE_INVLD_ORG_FRZ_REQST           ,0,                     "无效的机构禁用解禁请求"},
    {ERR_CODE_INVLD_INVALID_USER            ,0,                     "用户不存在"},
    {ERR_CODE_INVLD_QUERY_DATE              ,0,                     "查询日期跨度超出一年"},
    {ERR_CODE_INVLD_QUERY_STRTDATE          ,0,                     "开始日期不能晚于结束日期"},
    {ERR_CODE_INVLD_OCO_COUNT               ,0,                     "OCO订单数目不正确"},
    {ERR_CODE_INVLD_ORDR_PRC                ,0,                     "无效的订单价格"},
    {ERR_CODE_INVLD_INVLID_AMNT             ,0,                     "存在一个无效额度"},
    {ERR_CODE_INVLD_CRDT_MDFING             ,0,                     "正在进行授信管理，请稍候"},
    {ERR_CODE_INVLD_OCO_NUM                 ,0,                     "现有OCO组合数已达上限"},
    {ERR_CODE_CRDT_RMN_LMT                  ,0,                     "剩余授信额度不满足此成交"},
    {ERR_CODE_INVLD_CNCL_MKCLS              ,0,                     "闭市时段无法撤销!"},
    {ERR_CODE_CNTRCT_DL_UNIT_EMPTY          ,0,                     "合约对应的每手量缺失"},
    {ERR_CODE_ORD_CLOSED                    ,0,                     "订单已成交，无法修改/冻结"},
    {ERR_CODE_ORD_CLOSED_NO_C               ,0,                     "订单已成交，无法撤销"},
    {ERR_CODE_MKT_CLOSED_NO_D               ,0,                     "已闭市，不可操作"},
    {ERR_CODE_LGN_IN_NO_PRV                 ,0,                     "用户无登录权限"},
    {ERR_CODE_INVLD_PARAM_CRDT_NUM          ,0,                     "存在无效参数"},
    {ERR_CODE_PARAM_CRDT_NUM_INVLD          ,0,                     "最低授信对手方数量不在1-10的范围之内!"},
    {ERR_CODE_PARAM_CNTRCT_ERR_ST           ,0,                     "该合约状态不是交易中!"},
    {ERR_CODE_INVLD_QUERY_DATE1             ,0,                     "历史查询日期跨度超出三个月"},
    {ERR_CODE_INVLD_MRK_ST                  ,0,                     "市场状态为非收盘"},
    {ERR_CODE_INVLD_ACNT_DL                 ,0,                     "默认资金账号不可删除"},
    {ERR_CODE_SECOND_ACNT_DL                ,0,                     "资金账号已存在，请重新输入"},
    {ERR_CODE_CNTRT_MDF                     ,0,                     "此时段内无法修改"},
    {ERR_CODE_INVLD_CAPICALACT              ,0,                     "该机构没有默认资金账户，请先设置"},
    {ERR_CODE_INVLD_TRMNL_MK                ,0,                     "闭市时段无法完全提前终止!"},
    {ERR_CODE_INVLD_CANCEL_F                ,0,                     "撤销失败!"},
    {ERR_CODE_INVLD_CANCELED                ,0,                     "已撤销!"},
    {ERR_CODE_INVLD_TERMINED                ,0,                     "当前成交状态无法提前终止！"},
    {ERR_CODE_INVLD_TRD_TRMN_OT             ,0,                     "终止时间已超时"},
    {ERR_CODE_DEF_ACNT_SAV                  ,0,                     "资金账号为默认,保存失败"},
    {ERR_CODE_INVLD_DPST_CAPICALACT         ,0,                     "该机构没有默认托管账户，请先设置"},
    {ERR_CODE_INVLD_TRMNL_MKCLS             ,0,                     "闭市时段无法完全提前终止!"},
    {ERR_CODE_PARAM_STAT_NUM_INVLD          ,0,                     "可交割债券修改状态不存在!"},
    {ERR_CODE_SECOND_DLVY_BOND              ,0,                     "可交割债券已存在，请重新输入"},
    {ERR_CODE_DPST_ACNT_NO_EXIST            ,0,                     "关联的资金账户不存在"},
    {ERR_CODE_DPST_ACNT_SHLD_EXIST          ,0,                     "必须关联资金账户"},
    {ERR_CODE_ACNT_SHLD_NOT_CHANGE          ,0,                     "已存在与托管账户关联的默认资金账户,不能修改"},
    {ERR_CODE_ACNT_SHLD_NOT_DELETE          ,0,                     "资金账户已经关联,不能删除"},
    {ERR_CODE_ACNT_NO_LINKED                ,0,                     "当前默认托管账号与资金账号没有关联，无法提交订单"},
    {ERR_CODE_DPST_ACNT_NO_LINKED           ,0,                     "当前默认托管账号和资金账号没有关联,无法提交订单"},
    {ERR_CODE_DPST_ACNT_MUST_ACNT           ,0,                     "默认关联存在时,设置默认托管账户必须设置关联资金账户"},
    {ERR_CODE_DPST_ACNT_SHLD_ACNT           ,0,                     "请关联资金账户"},
    {ERR_CODE_INVLD_DPST_ACNT_DL            ,0,                     "默认托管账号不可删除"},
    {ERR_CODE_DEF_DPST_ACNT_SAV             ,0,                     "托管账户为默认,保存失败"},
    {ERR_CODE_DPST_SHLD_EXIST               ,0,                     "修改的托管账户不存在"},
    {ERR_CODE_ACNT_SHLD_EXIST               ,0,                     "修改的资金账户不存在"},
    {ERR_CODE_ACNT_SHLD_NOT_ADD             ,0,                     "已存在与托管账户关联的默认资金账户,不能新增默认资金账户"},
    {ERR_CODE_ACNT_SHLD_NOT_CHANGE2         ,0,                     "该资金账户与托管账户关联,不能修改!"},
    {ERR_CODE_CCP_CRDT_OVER_LIMIT           ,0,                     "您的剩余持仓量不足！"},
    {ERR_CODE_CCP_CRDT_ST_LIMIT             ,0,                     "当前处于限仓模式，无法提交当前方向的订单！"},
    {ERR_CODE_PERMISSION_INEDITABLE         ,0,                     "不可修改该用户市场权限"},
    {ERR_CODE_INVLD_USRMKT_PRV              ,0,                     "您没有此市场权限"},
    {ERR_CODE_CCP_CRDT_ST_OFF               ,0,                     "当前处于强平模式，无法提交订单！"},
    {ERR_CODE_INVLD_INVALID_ORG             ,0,                     "机构不存在"},
    {ERR_CODE_INVLD_INVALID_C_QSS           ,0,                     "强平订单编号有误"},
    {ERR_CODE_FORCE_CANCEL                  ,0,                     "当前处于强平模式，强平订单无法撤销"},
    {ERR_CODE_FORCE_FREEZE                  ,0,                     "当前处于强平模式，强平订单无法冻结"},
    {ERR_CODE_MORE_THAN_REF                 ,0,                     "订单价格超出涨跌幅控制，是否继续提交？"},
    {ERR_CODE_ORDR_CANCEL_OCO               ,0,                     "无法撤销OCO/双边类型的订单"},
    {ERR_CODE_INVLD_CRDT_PSTN               ,0,                     "无效的持仓限额"},
    {ERR_CODE_FORCE_MODIFY                  ,0,                     "当前处于强平模式，强平订单无法修改"},
    {ERR_CODE_CNTRCT_EXISTS_DL              ,0,                     "该合约已有关联交易，不可删除"},
    {ERR_CODE_CNTRCT_REMOVE_DL              ,0,                     "该合约正在交易，不可删除"},
    {ERR_CODE_CNTRCT_EXISTS                 ,0,                     "该合约品种已存在"},
    {ERR_CODE_TRD_END_DT                    ,0,                     "成交已经到期，完全提前终止失败"},
    {ERR_CODE_INVLD_SIRS_CANCEL_F           ,0,                     "仅能撤销当日成交，撤销失败"},
    {ERR_CODE_INVLD_FLWVAL                  ,0,                     "流控设置存在无效参数"},
    {ERR_CODE_INVLD_BOND_MDFY_TM            ,0,                     "此时段无法设置可交割债券"},
    {ERR_CODE_INVLD_CRDT_TM                 ,0,                     "有效授信时间区间存在无效参数"},
    {ERR_CODE_INVLD_BRDG_FEE                ,0,                     "无效的桥费参数"},
    {ERR_CODE_INVLD_ORDR_PRV                ,0,                     "当前交易员无交易权限"},
    {ERR_CODE_INVLD_DL_ST                   ,0,                     "无效的成交状态"},
    {ERR_CODE_BIL_EXISTS                    ,0,                     "当前合约已存在双边订单，不可重复提交！"},
    {ERR_CODE_BIL_SINGLE                    ,0,                     "不支持单边报价，请重新输入"},

    {APIERR_CODE_OVERTIME                   ,0,                     "超时"},
    {APIERR_CODE_CRT_MODIFYING              ,0,                     "其他用户正在修改"},
    {APIERR_CODE_INVLD_MDF_FREQ             ,0,                     "授信设置指令频率过高"},
    {APIERR_CODE_INVLD_RSK_CFCNT_TP         ,0,                     "当前的风险系数设置方式不满足要求"},
    {APIERR_CODE_INVLD_INCOME               ,0,                     "指令要素验证不通过"},
    {APIERR_CODE_INVLD_ORGCD                ,0,                     "机构不存在"},
    {APIERR_CODE_INVLD_OTHERS               ,0,                     "其他"},
    {APIERR_CODE_INVLD_CRDTPAIR             ,0,                     "机构授信关系不存在"},
    {APIERR_CODE_INVLD_CRDTMTHD             ,0,                     "授信方式填写错误"},
    {APIERR_CODE_USR_LOGOUT                 ,0,                     "用户已断线"},
    {APIERR_CODE_INVLD_USER                 ,0,                     "用户不存在"},
    {APIERR_CODE_INVLD_TOKEN                ,0,                     "TOKEN认证不一致请重新登录"},
    {APIERR_CODE_USER_FORBID                ,0,                     "用户已禁用"},
    {APIERR_CODE_ORG_FORBID                 ,0,                     "机构已被禁用"},
    {APIERR_CODE_INVLD_MKT_NOT_PMT          ,0,                     "此时段内无法操作"},
    {APIERR_CODE_INVLD_ROLE_PRV             ,0,                     "权限错误"},
    {APIERR_CODE_INVLD_CRDT_MDFY_TM         ,0,                     "当前不是授信设置有效时间区间"},
    {APIERR_CODE_INVLD_OWNR_ORG_CD          ,0,                     "本方机构ID填写错误"},
    {APIERR_CODE_INVLD_QUERY_MTHD           ,0,                     "查询条件有误"},
    {APIERR_CODE_INVLD_RSK_CNTRCT           ,0,                     "合约品种不存在"},
    {APIERR_CODE_UNSUPPORT_CRT_TYPE         ,0,                     "关系授信下不支持风险系数相关指令"},
    {APIERR_CODE_INVLD_OWNR_USRID           ,0,                     "本方用户ID填写错误"},
    {APIERR_CODE_INVLD_MARKET_ID            ,0,                     "市场不存在"},
    {APIERR_CODE_INVLD_SUBQT_INCOME         ,0,                     "订阅要素填写有误"},
    {APIERR_CODE_INVLD_DUP_UNSUBQT          ,0,                     "指令无效"},
    {APIERR_CODE_INVLD_DUP_SUBQT            ,0,                     "指令重复"},
    {APIERR_CODE_INVLD_ORDR_AMNT            ,0,                     "报价量不符合要求"},
    {APIERR_CODE_INVLD_APIUSR               ,0,                     "当前交易员无API交易权限"},
    {APIERR_CODE_INVLD_PRC                  ,0,                     "报价要素填写错误"},
    {APIERR_CODE_INVLD_ORDRINCOME           ,0,                     "指令要素填写错误"},
    {APIERR_CODE_INVLD_ORDR                 ,0,                     "当前指令无对应有效订单"},
    {APIERR_CODE_INVLD_REQID                ,0,                     "指令不存在"},
    {APIERR_CODE_REP_CANCEL                 ,0,                     "订单已撤销"},
    {APIERR_CODE_ORD_CLOSED_NO_C            ,0,                     "订单已成交"},
    {APIERR_CODE_ORD_BOOF                   ,0,                     "本方BID/OFFER价格出现倒挂"},
    {APIERR_CODE_INVALID_ORDR_ID            ,0,                     "订单编号填写错误"},
    {APIERR_CODE_ALREADY_LOGIN              ,0,                     "交易接口已登陆"},
    {APIERR_CODE_INVLD_USR_ORDR             ,0,                     "当前用户无有效订单"},
    {APIERR_CODE_INVLD_EXPRTM               ,0,                     "有效时间填写有误"},
    {APIERR_CODE_NO_ACTIVEORD               ,0,                     "当前用户无有效订单"},
    {APIERR_CODE_CANNT_APIORD               ,0,                     "不可操作API订单！"},
    {APIERR_CODE_INVLD_TRDNM                ,0,                     "交易员姓名有误"},
    {APIERR_CODE_TRD_NO_PVL                 ,0,                     "当前用户不允许设置接口权限"}

};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

#define APP_NULL_SOPATH               30001,  ERROR_HANDLE_LOG, "Invalid parameter"

#endif /* _ERR_CODE_ */
