﻿/***
Created on Aug 15, 2017
@author: Longyun Hao
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _ORDER_CHECK_H_
#define _ORDER_CHECK_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files */
#include "data_type.h"

#include "ordr_mgmt.h"
#include "../ref_data/include/contract_info.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define ORG_STATUS_FORBID        0
#define ORG_STATUS_ACTIVE        1

#define ORG_IRS_ST_FORBID        0
#define ORG_IRS_ST_ACTIVE        1
#define ORG_IRS_ST_DELETE        2

#define ORG_MKT_ST_FORBID        0      /* 禁用 */
#define ORG_MKT_ST_ACTIVE        1      /* 启用 */


#define COMMN_POS_NULL          -1
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef enum OrdrChkModeS
{
    ORD_CHK_MODE_NULL = 0,
    ORD_CHK_MODE_SAVE,
    ORD_CHK_MODE_SBMT,
    ORD_CHK_MODE_ACTV,
    ORD_CHK_MODE_FRZE,
    ORD_CHK_MODE_CNCL,
    ORD_CHK_MODE_MODI,
    ORD_CHK_MODE_MAX,
}OrdrChkModeT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CheckUsrStatus( int32 usrPos );
ResCodeT CheckOrgStatus( int32 orgPos );

ResCodeT OrderSaveCheck( pNewOrderSingleReqT pSaveOrder, int64 timeStamp );
ResCodeT OrderSubmitCheck( pNewOrderSingleReqT pNewOrder, int64 timeStamp );
ResCodeT OrderFreezeCheck( int32 setId, pOrderCancelReplaceRequestReqT pFrzOrder );
ResCodeT OrderCancelCheck( int32 setId, pOrderCancelRequestReqT pCnclOrder );
ResCodeT OrderActiveCheck( int32 setId, pOrderCancelReplaceRequestReqT pActvOrder, int64 timeStamp );

ResCodeT BilOrderSaveCheck( pNewOrderSingleReqT pSaveOrder, int64 timeStamp );
ResCodeT BilOrderSubmitCheck( pNewOrderSingleReqT pNewOrder, int64 timeStamp );
ResCodeT BilOrderFreezeCheck( int32 setId, pOrderCancelReplaceRequestReqT pFrzOrder );
ResCodeT BilOrderCancelCheck( int32 setId, pOrderCancelRequestReqT pCnclOrder );
ResCodeT BilOrderActiveCheck( int32 setId, pOrderCancelReplaceRequestReqT pActvOrder, int64 timeStamp );

ResCodeT OCOOrderSaveCheck( pNewOrderListReqT pOcoOrderList, int64 timeStamp );
ResCodeT OCOOrderSubmitCheck( pNewOrderListReqT pOcoOrderList, int64 timeStamp );
ResCodeT OCOOrderFreezeCheck( int32 setId, pOrderCancelReplaceRequestReqT pFrzOrder );
ResCodeT OCOOrderCancelCheck( int32 setId, pOrderCancelRequestReqT pCnclOrder );
ResCodeT OCOOrderActiveCheck( int32 setId, pOrderCancelReplaceRequestReqT pActvOrder, int64 timeStamp );

ResCodeT OrderInvrsnCheck( int32 setId, pNewOrderSingleReqT pOrdReq, BOOL * pIsInvrsn );

ResCodeT ApiSubmitOrderCheck(pNewOrderSingleReqT pApiReq, pCntrctBaseInfoT pCntrctData, int64 timestamp);
ResCodeT SirsApiSubmitOrderCheck(pNewOrderSingleReqT pApiReq, pCntrctBaseInfoT pCntrctData, int64 timestamp);
ResCodeT SbfccpApiSubmitOrderCheck(pNewOrderSingleReqT pApiReq, pCntrctBaseInfoT pCntrctData, int64 timestamp);
ResCodeT ApiCancelOrderCheck(int32 set, pOrderCancelRequestReqT pApiReq);

ResCodeT FmtCnclRqstToOrder(pOrderCancelRequestReqT pCnclOrderReq, pOrderT pOrder);
#endif /* _ORDER_CHECK_H_ */
