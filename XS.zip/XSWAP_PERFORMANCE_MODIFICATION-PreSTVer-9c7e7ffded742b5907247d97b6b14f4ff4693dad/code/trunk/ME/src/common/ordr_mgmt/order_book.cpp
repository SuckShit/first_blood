/***
Created on May 08, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "order_book.h"
#include "static_lst.h"
#include "order_type.h"
#include "common_macro.h"
#include "pool_slot.h"
#include "shm.h"
#include "uti_tool.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Type Defination
 **
 ******************************************************************************/

/* Product Control Area Type. */
typedef struct PrdctCtrlS
{
    uint32  cntBuy;
    uint32  cntSell;

    SlotT     bstBuyO;
    SlotT     bstSellO;
    SlotT     lstBuyO;
    SlotT     lstSellO;

    osSListEntryT prcLderBuyO;
    osSListEntryT prcLderSellO;

    OrdBkSortingT  odrBkSortingType;

    uint16 state;
    uint16 statusMask;

    /* the index of the set shared hash table, which stores all heads of linked
    lists of orderNo for the instrument. it will be filled during loading set
    memory */
    uint32 ordrNoListIdx;

    uint32 entyListIdx;

} PrdctCtrlT, *pPrdctCtrlT;

typedef struct OrdBookCtxS
{
    PrdctCtrlT * pPrdctCtrl;
    RegListT *  pListRegister;
    RegListT    listRegister[2];
    pOsSListEntryT pPrcLderList;
} OrdBookCtxT, *pOrdBookCtxT;



typedef struct LstTypeInfoS
{
    pOsSListEntryT pRtItemSearchVct;
} LstTypeInfoT, *pLstTypeInfoT;

typedef enum
{
    ENTY_LST = 0,
    ORD_NO_LST,
    EXP_TIME_LST,
    MAX_LST_TYPE
}OrdrLstTypeT;

typedef struct MemOffsetInfoS
{
    int64   ttlMemSize;
    int64   elemCnt;    
    int64   usedCnt;
    int64   peakCnt;  
    int64   areaOffset;  
    int64   vectOffset;
} MemOffsetInfoT, *pMemOffsetInfoT;

typedef struct OrdrBkShmAcsS
{
    void*               pRoot;
    pMemOffsetInfoT     pSetShmCtrlInfo;
    pVectorT            pOrdrBkVect;
    pOrderT             pOrdrBkRoot;
        
    pVectorT            pPrdctIdVect;
    PrdctCtrlT *        pPrdctCtrlRoot;
    pVectorT            pMktInfoUpdVect;

    LstTypeInfoT        lstInfo[MAX_LST_TYPE];
} OrdrBkShmAcsT, *pOrdrBkShmAcsT;

typedef enum
{
    ORDR_BK_OFFSET = 0,
    SLOT_OFFSET,
    PRDCT_CTRL_OFFSET,
    ORD_NO_LST_OFFSET,
    MKT_INFO_UPD_OFFSET,
    ENTY_LST_OFFSET,
    EXP_TIME_LST_OFFSET,
    MAX_OFFSET_TYPE
}MemOffsetTypeT;


typedef enum
{
    UAO_LIST = 0,
    UA_LIST,
    U_LIST,
    PRICE_LEADER_LIST,
    ENTY_NO_LIST,
    ORDR_NO_LIST,
    EXP_TIME_LIST
}OrdBkListModeT;

enum SlotUseSts
{
    _SLOT_FREED_ = 0,       /* 对应订单槽可用 */
    _SLOT_IN_USE_,          /* 对应订单槽被使用 */
};

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

static OrdrBkShmAcsT        gOrdrBkShmAcs[MAX_SET_CNT];
static PoolSlotT            gSetPoolSlot[MAX_SET_CNT];

static OrdBookCtxT          gOrdBookCtx = {0};

static int64                gPooledSlotSize = 500; //todo move to cfg
static BOOL                 gbOrdBkInit = FALSE;

static int32                gNumOfPrdct = 0;    //Add by hly

static int32 PriceLeaderKeyCmp(void * key1, void * key2);
static int32 TimeOrderKeyCmp(void * key1, void * key2);

static osSListModeT listMode[] = {
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.unrAuOaO),
    offsetof(OrderT, orderF.ordrEntTim), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   ASCENDING,  1, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.unrAuO  ),
    offsetof(OrderT, orderF.ordrEntTim), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   ASCENDING,  1, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.unrO    ),
    offsetof(OrderT, orderF.ordrEntTim), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   ASCENDING,  1, 0, NULL, NULL},    
{NULL, NULL, sizeof (OrderT), offsetof(Order4PrcLeadT, orderT.prcLder ),
    offsetof(Order4PrcLeadT, orderF.ordrPri), offsetof(OrderT, orderT.slotNo),
/* price leader always reside in memory */
    PriceLeaderKeyCmp, DESCENDING, 0, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.entyNo),
    offsetof(OrderT, orderF.ordrNo), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   NON_SORTED,  0, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.ordNo),
    offsetof(OrderT, orderF.ordrNo), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   NON_SORTED,  0, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.expTimeLst),
    offsetof(OrderT, orderF.ordrExpTim), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   ASCENDING,  1, 0, NULL, NULL}
};


#define GET_MAX_ORDR_CNT(_set_) (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORDR_BK_OFFSET].elemCnt)
#define GET_USED_ORDR_CNT(_set_) (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORDR_BK_OFFSET].usedCnt)
#define GET_PEAK_ORDR_CNT(_set_) (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORDR_BK_OFFSET].peakCnt)

#define INC_USED_ORDR_CNT(_set_) (++gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORDR_BK_OFFSET].usedCnt)
#define DES_USED_ORDR_CNT(_set_) (--gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORDR_BK_OFFSET].usedCnt)
#define INC_PEAK_ORDR_CNT(_set_) (++gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORDR_BK_OFFSET].peakCnt)

#define GET_MAX_SLOT_CNT(_set_)  (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[SLOT_OFFSET].elemCnt)
#define GET_USED_SLOT_CNT(_set_) (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[SLOT_OFFSET].usedCnt)
#define GET_PEAK_SLOT_CNT(_set_) (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[SLOT_OFFSET].peakCnt)

#define INC_USED_SLOT_CNT(_set_) (++gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[SLOT_OFFSET].usedCnt)
#define DES_USED_SLOT_CNT(_set_) (--gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[SLOT_OFFSET].usedCnt)
#define INC_PEAK_SLOT_CNT(_set_) (++gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[SLOT_OFFSET].peakCnt)

#define GET_MAX_ORD_NO_LIST_OF_PRDCT(_set_) (gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[ORD_NO_LST_OFFSET].elemCnt)


#define MAX_ORD_NO_LIST_BASE 1000

#ifndef NXT_PRC_LDER
#define NXT_PRC_LDER(_pNxtPrcLder_, _set_)\
    do\
    {\
        SlotT _nxtPriceLder_ = (_pNxtPrcLder_)->orderT.prcLder.next;\
        if (NON_NULL_SLOT(_nxtPriceLder_))\
        {\
            (_pNxtPrcLder_) = \
                (pOrder4PrcLeadT)&gOrdrBkShmAcs[_set_].pOrdrBkRoot[_nxtPriceLder_];\
        }\
        else\
        {\
            (_pNxtPrcLder_) = NULL;\
        }\
    } while (0)
#endif


#define CHK_PRDCT_ID(_set_, _prdctId_)\
do\
{\
    if (_prdctId_ > gOrdrBkShmAcs[_set_].pSetShmCtrlInfo[PRDCT_CTRL_OFFSET].elemCnt)\
    {\
        RAISE_ERR_PARM(ERR_OBK_INVLD_PRDCT, RTN , _prdctId_);\
    }\
} while (0)

#ifndef CHECK_ORDR_SLOT_OPEN
#define CHECK_ORDR_SLOT_OPEN(pAddO)\
        ( ((pOrderT)(pAddO))->orderT.sltOpen == _SLOT_IN_USE_ )
#endif

#ifndef SET_ORDR_SLOT_OPEN
#define SET_ORDR_SLOT_OPEN(pAddO)\
        ( ((pOrderT)(pAddO))->orderT.sltOpen = _SLOT_IN_USE_ )
#endif

#ifndef RESET_ORDR_SLOT_OPEN
#define RESET_ORDR_SLOT_OPEN(pAddO)\
        ( ((pOrderT)(pAddO))->orderT.sltOpen = _SLOT_FREED_ )
#endif

#ifndef IS_PRC_LDER
#define IS_PRC_LDER(pOrder)\
    (((pOrder4PrcLeadT)(pOrder))->orderF.ordrNo == (uint64)-1)
#endif
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
/******************************************************************************
 * Description:   Update best order
 * Parameters:
 *      myInstCtrl          IN  instrument or prooduct control 
 *      fBuySide            IN  buy / sell side 
 *      pRtOrderbook        OUT order rollback information
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
static void UpdateBstLstOrders(pPrdctCtrlT myInstCtrl,
                        BOOL fBuySide, pOrderT pRtOrderbook)
{
    BEGIN_FUNCTION("UpdateBstLstOrders");
    SlotT prcLderSlot;
    pOrder4PrcLeadT pPrcLder;

    if (fBuySide)
    {

        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderBuyO.next))
        {
            myInstCtrl->bstBuyO = -1; 
        }
        else
        {
            myInstCtrl->bstBuyO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.next;
        }

        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderBuyO.prev))
        {
            myInstCtrl->lstBuyO = -1;
        }
        else
        {
            myInstCtrl->lstBuyO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.prev;
        }
    }
    else
    {
        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderSellO.next))
        {
            myInstCtrl->bstSellO = -1;
        }
        else
        {
            myInstCtrl->bstSellO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.next;
        }

        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderSellO.prev))
        {
            myInstCtrl->lstSellO = -1;
        }
        else
        {
            myInstCtrl->lstSellO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.prev;
        }
    }

    EXIT_BLOCK();
}


/******************************************************************************
 * Description:   Find and retrieve an order (no.) from the Orderbook Search
 *                Vector based on order number.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT SetOrdrExpListMode(int32 setId, int32 prdctId, osSListModeT ** ppExpOrdrListMode)
{
    BEGIN_FUNCTION("SetOrdrExpListMode");
    pOsSListEntryT pExpTimeList = NULL;
    int32   iter = -1;
    
    
    gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    
    pExpTimeList = &gOrdrBkShmAcs[setId].lstInfo[EXP_TIME_LST].pRtItemSearchVct[prdctId];
    
    listMode[EXP_TIME_LIST].pRoot = (char * )gOrdrBkShmAcs[setId].pOrdrBkRoot;
    listMode[EXP_TIME_LIST].pListHead = pExpTimeList;
    listMode[EXP_TIME_LIST].theFrame = &gOrdBookCtx.pListRegister->frmExpTimeList;
    
    * ppExpOrdrListMode = &listMode[EXP_TIME_LIST];
    
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - SetOrdrExpListMode */

/******************************************************************************
 * Description:   Find and retrieve an order (no.) from the Orderbook Search
 *                Vector based on order number.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT IterOrdrExpListMode(osSListModeT * pExpOrdrListMode, pOrderT * ppOrdrOrder)
{
    BEGIN_FUNCTION("IterOrdrExpListMode");
    ResCodeT rc = NO_ERR;

    rc = GetSListHead(pExpOrdrListMode, (void **)ppOrdrOrder);
    RAISE_ERR(rc, RTN);
        


    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - IterOrdrExpListMode. */

/******************************************************************************
 * Description:   Find and retrieve an order (no.) from the Orderbook Search
 *                Vector based on order number.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT IterNextOrdrExpListMode(osSListModeT * pExpOrdrListMode, pOrderT * ppOrdrOrder, int32 * pIter)
{
    BEGIN_FUNCTION("IterNextOrdrExpListMode");
    ResCodeT rc = NO_ERR;
    
    rc =  GetSListNext(pExpOrdrListMode, (void **)ppOrdrOrder, (uint32 *)pIter);
    RAISE_ERR( rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - IterNextOrdrExpListMode. */

/******************************************************************************
 * Description:   Find and retrieve an order (no.) from the Orderbook Search
 *                Vector based on order number.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT OrdrBkGetOrdrByOrgPos( int32 set, int64 orgPos, int32 prdctId, pOrderT *pNextOrgOrdr, SlotT *nxtSlt )
{
    BEGIN_FUNCTION("OrdrBkGetOrdrByOrgPos");
    ResCodeT rc = NO_ERR;
    pOsSListEntryT pEntyNoList = NULL;
    
    
    if (NULL_SLOT_ID(*nxtSlt))
    {
        gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    
        pEntyNoList = &gOrdrBkShmAcs[set].lstInfo[ENTY_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + orgPos];
        
        
        listMode[ENTY_NO_LIST].pRoot = (char * )gOrdrBkShmAcs[set].pOrdrBkRoot;
        listMode[ENTY_NO_LIST].pListHead = pEntyNoList;
    }

    rc = GetSListNext(&listMode[ENTY_NO_LIST], (void **)pNextOrgOrdr, nxtSlt);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - OrdrBkGetOrdrByNo. */

/******************************************************************************
 * Description:   Find and retrieve an order (no.) from the Orderbook Search
 *                Vector based on order number.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT OrdrBkGetOrdrByNo( int32 set, int64 ordrNo, int32 prdctId, pOrderT *pOrdrNoGet )
{
    BEGIN_FUNCTION("OrdrBkGetOrdrByNo");
    int64 ordrNoWanted = ordrNo;
    ASSERT(pOrdrNoGet);
    int32 bucketNo ;
    *pOrdrNoGet = NULL;
    pOsSListEntryT pOrdNoList = NULL;
    
    
    gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    
    bucketNo = ordrNo % MAX_ORD_NO_LIST_BASE;
    pOrdNoList = &gOrdrBkShmAcs[set].lstInfo[ORD_NO_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + bucketNo];
    
    
    listMode[ORDR_NO_LIST].pRoot = (char * )gOrdrBkShmAcs[set].pOrdrBkRoot;
    listMode[ORDR_NO_LIST].pListHead = pOrdNoList;

    if (NOTOK(FindSListEntryByKey(&listMode[ORDR_NO_LIST], &ordrNoWanted,
        (void **)pOrdrNoGet)))
    {
        /* Here we cannot find the order in the orderbook, it must have been
           matched or deleted already, use a specific error code then */
        LOG_INFO("prdctId %ld, orderNo %lld, bucketNo %ld, wanted No %lld", prdctId, ordrNo, bucketNo, ordrNoWanted);
        SET_RESCODE(ERR_OBK_ORDR_NOT_EXIST);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - OrdrBkGetOrdrByNo. */

ResCodeT OrdrBkGetOrdr( int32 setId, int32 slotId,  pOrderT *pBkOrdr )
{
    BEGIN_FUNCTION( "OrdrBkGetOrdr" );
    ResCodeT rc = NO_ERR;
    pOrderT pRtOrderbook =NULL;

    ASSERT(pBkOrdr);
        
        
    pRtOrderbook = gOrdrBkShmAcs[setId].pOrdrBkRoot;
    *pBkOrdr = &pRtOrderbook[slotId];
    
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - OrdrBkGetOrdr. */

/******************************************************************************
 * Description:  calculate price priority
 * Parameters:
 *      pPrcLder            IN/OUT price lead node
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
static ResCodeT CalcuPri4PrcLder(pOrderF4PrcLeadT pPrcLder)
{
    BEGIN_FUNCTION("CalcuPri4PrcLder");

    int32 oSide;
    int64 ordPri;

    oSide = GET_ORDR_SIDE(pPrcLder->ordrMask);
    ordPri = pPrcLder->ordrExePrc << 1;
    EXECUTE_ON_COND(ordPri = -ordPri, ORDR_SIDE_SELL == oSide);

    /* we can see that for sell side orders, their priority is always
    negative, and zero for market order */
    pPrcLder->ordrPri = ordPri;

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* END - CalcuPri4PrcLder */

/******************************************************************************
 * Description:  price lead key comparasion function
 * Parameters:
 *      pPrcLder            IN/OUT price lead node
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
static int32 PriceLeaderKeyCmp(void * key1, void * key2)
{
    BEGIN_FUNCTION("PriceLeaderKeyCmp");

    int64 prcDiff = *(uint64 *)key1 - *(uint64 *)key2;

    ASSERT(key1 && key2);
    /* NB: prcDiff is possibly a 64bit positive integer but the return code is
    a long type, and when type cast to long, prcDiff is possibly become a
    negative one! so watch out this! */
    return (int32)(prcDiff ? (prcDiff > 0 ? 1 : -1) : prcDiff);
    EXIT_BLOCK();
}/* END - PriceLeaderKeyCmp */
/******************************************************************************
 * Description:   time order key comparasion function
 * Parameters:
 *      pPrcLder            IN/OUT price lead node
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
static int32 TimeOrderKeyCmp(void * key1, void * key2)
{
    BEGIN_FUNCTION("TimeOrderKeyCmp");
    int64 timeDiff = *(uint64 *)key1 - *(uint64 *)key2;

    ASSERT(key1 && key2);

    /* NB: timeDiff is possibly a 64bit positive integer but the return code is
    a int32 type, and when type cast to int32, timeDiff is possibly become a
    negative one! so watch out this! */
    return (int32)(timeDiff ? (timeDiff > 0 ? 1 : -1) : timeDiff);
    EXIT_BLOCK();
}/* END - TimeOrder3KeyCmp */


/******************************************************************************
 * Description:   initialize the static link list 
 * Parameters:
 *      elemCnt         IN  Element count
 *      pCurrListEnty   IN  First link list node
 *      return:         Return value
 *      ERR_<DSCR>: fail to initialized
 ******************************************************************************/
ResCodeT InitStaticList(int32 elemCnt, pOsSListEntryT pCurrListEnty)
{
    BEGIN_FUNCTION("InitStaticList");
    int32 i = 0;
    for (i = 0; i < elemCnt; i++)
    {
        INIT_STATIC_LIST_ENTRY(pCurrListEnty);
        
        pCurrListEnty = (pOsSListEntryT)ADDRESS_ADD_OFFSET(pCurrListEnty, sizeof(osSListEntryT));
    }
                                 
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   initialize the product control area
 * Parameters:
 *      elemCnt         IN  Element count
 *      pCurrPrdctCtrl  IN  First product control node
 *      return:         Return value
 *      ERR_<DSCR>: fail to initialized
 ******************************************************************************/
ResCodeT InitPrdctCtrlArea(int32 elemCnt, pPrdctCtrlT  pCurrPrdctCtrl)
{
    BEGIN_FUNCTION("InitPrdctCtrlArea");
    int32       prdctId = 0;
    for (prdctId = 0; prdctId<elemCnt; prdctId ++)
    {
        pCurrPrdctCtrl->cntBuy = 0;
        pCurrPrdctCtrl->cntSell = 0;
        pCurrPrdctCtrl->bstBuyO = ODBK_SHM_NO_SLOT;
        pCurrPrdctCtrl->bstSellO = ODBK_SHM_NO_SLOT;
        pCurrPrdctCtrl->lstBuyO = ODBK_SHM_NO_SLOT;
        pCurrPrdctCtrl->lstSellO = ODBK_SHM_NO_SLOT;
        INIT_STATIC_LIST_ENTRY(&pCurrPrdctCtrl->prcLderBuyO);
        INIT_STATIC_LIST_ENTRY(&pCurrPrdctCtrl->prcLderSellO);
        pCurrPrdctCtrl->odrBkSortingType = 1;

        pCurrPrdctCtrl->state; //todo fix this
        pCurrPrdctCtrl->statusMask;

        pCurrPrdctCtrl =  (pPrdctCtrlT)ADDRESS_ADD_OFFSET( pCurrPrdctCtrl, sizeof(PrdctCtrlT));
    }
                                 
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Map the share memory section
 * Parameters:
 *      pRoot           IN      Share memory root address
 *      pMemOffsetInfo  IN      Memory offest infomation
 *      pShmAccess      OUT     Populate the global share memory access structure
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
static ResCodeT MapOrdrBkShmAcs(void * pRoot, int32 ctrlAreaSize, pMemOffsetInfoT pMemOffsetInfo, pOrdrBkShmAcsT pShmAcs)
{
    BEGIN_FUNCTION("MapOrdBookShmAccess");
    ResCodeT                rc = NO_ERR;
    int32 i = 0;
    int64 tmpOffset = 0;
    /* Map root and control information */
    pShmAcs->pRoot = pRoot;
    pShmAcs->pSetShmCtrlInfo = (pMemOffsetInfoT)pRoot;
    /* Map Order Book Information */
    pShmAcs->pOrdrBkVect = (pVectorT)ADDRESS_ADD_OFFSET( pShmAcs->pSetShmCtrlInfo, ctrlAreaSize);
    pShmAcs->pOrdrBkRoot = (pOrderT)ADDRESS_ADD_OFFSET( pShmAcs->pOrdrBkVect, pMemOffsetInfo[ORDR_BK_OFFSET].vectOffset);
    
    
    pShmAcs->pPrdctIdVect = (pVectorT)ADDRESS_ADD_OFFSET( pShmAcs->pOrdrBkRoot, pMemOffsetInfo[ORDR_BK_OFFSET].areaOffset);
    pShmAcs->pPrdctCtrlRoot = (pPrdctCtrlT)ADDRESS_ADD_OFFSET( pShmAcs->pPrdctIdVect, pMemOffsetInfo[PRDCT_CTRL_OFFSET].vectOffset);

    pShmAcs->pMktInfoUpdVect = (pVectorT)ADDRESS_ADD_OFFSET( pShmAcs->pPrdctCtrlRoot, pMemOffsetInfo[PRDCT_CTRL_OFFSET].areaOffset);

    pShmAcs->lstInfo[ORD_NO_LST].pRtItemSearchVct = (pOsSListEntryT)ADDRESS_ADD_OFFSET( pShmAcs->pMktInfoUpdVect, 
                                            pMemOffsetInfo[MKT_INFO_UPD_OFFSET].vectOffset);
           
    pShmAcs->lstInfo[ENTY_LST].pRtItemSearchVct = (pOsSListEntryT)ADDRESS_ADD_OFFSET( pShmAcs->lstInfo[ORD_NO_LST].pRtItemSearchVct, 
                                            pMemOffsetInfo[ORD_NO_LST_OFFSET].areaOffset);
    
    pShmAcs->lstInfo[EXP_TIME_LST].pRtItemSearchVct = (pOsSListEntryT)ADDRESS_ADD_OFFSET( pShmAcs->lstInfo[ENTY_LST].pRtItemSearchVct, 
                                            pMemOffsetInfo[ENTY_LST_OFFSET].areaOffset);                                            

    rc = InitStaticList(pMemOffsetInfo[ORD_NO_LST_OFFSET].elemCnt, pShmAcs->lstInfo[ORD_NO_LST].pRtItemSearchVct);
    RAISE_ERR(rc, RTN);    

    rc = InitStaticList(pMemOffsetInfo[ENTY_LST_OFFSET].elemCnt, pShmAcs->lstInfo[ENTY_LST].pRtItemSearchVct);
    RAISE_ERR(rc, RTN);
    
    rc = InitStaticList(pMemOffsetInfo[EXP_TIME_LST_OFFSET].elemCnt, pShmAcs->lstInfo[EXP_TIME_LST].pRtItemSearchVct);
    RAISE_ERR(rc, RTN);          
              
    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   Calculate order book size for one set
 * Parameters:
 *      pOrdrBk         IN  Number of entity in the market
 *      pMemOffsetInfo  OUT calculate the memory offset result by type
 *      return:         Total memory size
 *      ERR_<DSCR>: fail to calculate the memory size.
 ******************************************************************************/
static int32 CalcShmSizeBySet(pOrdrBkCfgT pOrdrBkCfg, pMemOffsetInfoT pMemOffsetInfo)
{
    BEGIN_FUNCTION("CalcShmSizeBySet");
    ResCodeT                rc = NO_ERR;

    int64 ttlMemSize = 0;
    int32 i = 0;
    
    
    pMemOffsetInfo[SLOT_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfOrdr * 2;
    pMemOffsetInfo[SLOT_OFFSET].usedCnt = 0;
    pMemOffsetInfo[SLOT_OFFSET].peakCnt = 0;
    
    pMemOffsetInfo[ORDR_BK_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfOrdr;
    pMemOffsetInfo[ORDR_BK_OFFSET].usedCnt = 0;
    pMemOffsetInfo[ORDR_BK_OFFSET].peakCnt = 0;
    pMemOffsetInfo[ORDR_BK_OFFSET].vectOffset = GET_BIT_VECT_LEN(pMemOffsetInfo[SLOT_OFFSET].elemCnt);
    pMemOffsetInfo[ORDR_BK_OFFSET].areaOffset = pMemOffsetInfo[SLOT_OFFSET].elemCnt * sizeof(OrderT); /*give the space to have full slot area, but control as order cnt*/
    
    pMemOffsetInfo[PRDCT_CTRL_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfPrdct;
    pMemOffsetInfo[PRDCT_CTRL_OFFSET].usedCnt = 0;
    pMemOffsetInfo[PRDCT_CTRL_OFFSET].peakCnt = 0;
    pMemOffsetInfo[PRDCT_CTRL_OFFSET].vectOffset = GET_BIT_VECT_LEN(pOrdrBkCfg->nmbrOfPrdct);
    pMemOffsetInfo[PRDCT_CTRL_OFFSET].areaOffset = pOrdrBkCfg->nmbrOfPrdct * sizeof(PrdctCtrlT);
    
    pMemOffsetInfo[ORD_NO_LST_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfPrdct*pOrdrBkCfg->nmbrOfOrdr;
    pMemOffsetInfo[ORD_NO_LST_OFFSET].usedCnt = 0;
    pMemOffsetInfo[ORD_NO_LST_OFFSET].peakCnt = 0;    
    pMemOffsetInfo[ORD_NO_LST_OFFSET].vectOffset = 0;
    pMemOffsetInfo[ORD_NO_LST_OFFSET].areaOffset = sizeof(osSListEntryT)*pMemOffsetInfo[ORD_NO_LST_OFFSET].elemCnt;
    
    pMemOffsetInfo[ENTY_LST_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfPrdct*pOrdrBkCfg->nmbrOfEnty;
    pMemOffsetInfo[ENTY_LST_OFFSET].usedCnt = 0;
    pMemOffsetInfo[ENTY_LST_OFFSET].peakCnt = 0;    
    pMemOffsetInfo[ENTY_LST_OFFSET].vectOffset = 0;
    pMemOffsetInfo[ENTY_LST_OFFSET].areaOffset = sizeof(osSListEntryT)*pMemOffsetInfo[ENTY_LST_OFFSET].elemCnt;
    
    pMemOffsetInfo[EXP_TIME_LST_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfPrdct*pOrdrBkCfg->nmbrOfOrdr;
    pMemOffsetInfo[EXP_TIME_LST_OFFSET].usedCnt = 0;
    pMemOffsetInfo[EXP_TIME_LST_OFFSET].peakCnt = 0;    
    pMemOffsetInfo[EXP_TIME_LST_OFFSET].vectOffset = 0;
    pMemOffsetInfo[EXP_TIME_LST_OFFSET].areaOffset = sizeof(osSListEntryT)*pMemOffsetInfo[EXP_TIME_LST_OFFSET].elemCnt;

    pMemOffsetInfo[MKT_INFO_UPD_OFFSET].elemCnt = pOrdrBkCfg->nmbrOfPrdct;
    pMemOffsetInfo[MKT_INFO_UPD_OFFSET].usedCnt = 0;
    pMemOffsetInfo[MKT_INFO_UPD_OFFSET].peakCnt = 0;
    pMemOffsetInfo[MKT_INFO_UPD_OFFSET].vectOffset = GET_BIT_VECT_LEN(pOrdrBkCfg->nmbrOfPrdct);
    pMemOffsetInfo[MKT_INFO_UPD_OFFSET].areaOffset = 0;

    for (i=0; i<MAX_OFFSET_TYPE; i++)
    {
        ttlMemSize += pMemOffsetInfo[i].vectOffset;
        ttlMemSize += pMemOffsetInfo[i].areaOffset;
        
        TRACE("Total memory size %d for type %d" $$ ttlMemSize $$ i);
    }
    
    TRACE("Total memory size %d ");

    EXIT_BLOCK();
    return ttlMemSize;
}

/******************************************************************************
 * Description:   Create order book share memeory.
 * Parameters:
 *      pOrdBkCfg   IN  giving how many set we have, how many order and product per set will process
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT OrdrBkShmCreate(pOrdrBkCfgT pOrdrBkCfg)
{
    BEGIN_FUNCTION("OrdrBkShmCreate");
    ResCodeT                rc = NO_ERR;
    void *                  pRoot = NULL;
    int64                   ttlMemSize =  0;
    MemOffsetInfoT          memOffsetInfo[MAX_OFFSET_TYPE];
    char                    shmName[SHM_NAME_LEN] = {0};
    int32                   setId = 0;
    int32                   shmCtrlAreaSize = 0;
    pPrdctCtrlT             pCurrPrdctCtrl = NULL;
    
    
    setId = pOrdrBkCfg->setId;
    
    memset(memOffsetInfo, 0x00, sizeof(MemOffsetInfoT)* MAX_OFFSET_TYPE );
    ttlMemSize = CalcShmSizeBySet(pOrdrBkCfg, memOffsetInfo);
    
    sprintf(shmName,SHM_SET_ORDR_BK_NAME, setId);
    
    rc = ShmCreate(GetShmNm(shmName), ttlMemSize, (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    memOffsetInfo[0].ttlMemSize = ttlMemSize;

    /* Copy the memory section information to the share memory, it is static after creatation */
    shmCtrlAreaSize = sizeof(MemOffsetInfoT)*MAX_OFFSET_TYPE;
    memset(pRoot, 0x00, ttlMemSize);
    memcpy(pRoot, memOffsetInfo, shmCtrlAreaSize);
    
    /* Map the share memory access global array */
    rc = MapOrdrBkShmAcs(pRoot, shmCtrlAreaSize, memOffsetInfo, &gOrdrBkShmAcs[setId]);
    RAISE_ERR(rc, RTN);

    /* Initialize the product control area */
    pCurrPrdctCtrl = gOrdrBkShmAcs[setId].pPrdctCtrlRoot;
    rc = InitPrdctCtrlArea(memOffsetInfo[PRDCT_CTRL_OFFSET].elemCnt, pCurrPrdctCtrl);
    
    gNumOfPrdct = pOrdrBkCfg->nmbrOfPrdct;
    gbOrdBkInit = TRUE;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Delete from the share memory
 * Parameters:
 *      setId       IN  input set
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
ResCodeT OrdrBkShmDelete(int32 setId)
{
    BEGIN_FUNCTION("OrdrBkShmDelete");
    ResCodeT                rc = NO_ERR;
    char                    shmName[SHM_NAME_LEN] = {0};

    sprintf(shmName,SHM_SET_ORDR_BK_NAME, setId);
    
    /*-------------------    Delete to the given shm       -------------------*/
    rc = ShmDelete(GetShmNm(shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Detach from the share memory
 * Parameters:
 *      setId       IN  input set
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to detach the share memory.
 ******************************************************************************/
ResCodeT OrdrBkShmDetach(int32 setId)
{
    BEGIN_FUNCTION("OrdrBkShmDetach");
    ResCodeT                rc = NO_ERR;
    char                    shmName[SHM_NAME_LEN] = {0};

    sprintf(shmName,SHM_SET_ORDR_BK_NAME, setId);
    
    /*-------------------    detach to the given shm       -------------------*/
    rc = ShmDetach(GetShmNm(shmName));
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   reset the share memory
 * Parameters:
 *      setId       IN  input set
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Attach the share memory.
 ******************************************************************************/
ResCodeT OrdrBkShmReset(int32 setId)
{
    BEGIN_FUNCTION("OrdrBkShmAttach");
    ResCodeT                rc = NO_ERR;
    void *                  pRoot = NULL;
    char                    shmName[SHM_NAME_LEN] = {0};
    int64                   shmSize = 0;
    int32                   shmCtrlAreaSize = 0;
    pMemOffsetInfoT         pMemOffsetInfo = NULL;
    
    sprintf(shmName,SHM_SET_ORDR_BK_NAME, setId);
    
    /*-------------------    Reset to the given shm       -------------------*/
    rc = ShmAttach(GetShmNm(shmName), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    pMemOffsetInfo = (pMemOffsetInfoT)pRoot;
    
    memset(pRoot,0x00, pMemOffsetInfo->ttlMemSize);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Attach from the share memory
 * Parameters:
 *      setId       IN  input set
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Attach the share memory.
 ******************************************************************************/
ResCodeT OrdrBkShmAttach(int32 setId)
{
    BEGIN_FUNCTION("OrdrBkShmAttach");
    ResCodeT                rc = NO_ERR;
    void *                  pRoot = NULL;
    char                    shmName[SHM_NAME_LEN] = {0};
    int64                   shmSize = 0;
    int32                   shmCtrlAreaSize = 0;
    
    sprintf(shmName,SHM_SET_ORDR_BK_NAME, setId);
    
    /*-------------------    Attach to the given shm       -------------------*/
    rc = ShmAttach(GetShmNm(shmName), (int64 **)&pRoot);
    RAISE_ERR(rc, RTN);
    
    shmCtrlAreaSize = sizeof(MemOffsetInfoT)*MAX_OFFSET_TYPE;
    
    rc = MapOrdrBkShmAcs(pRoot,shmCtrlAreaSize, (pMemOffsetInfoT)pRoot, &gOrdrBkShmAcs[setId]);
    RAISE_ERR(rc, RTN);
    
    rc = InitPoolSlot(&gSetPoolSlot[setId], gPooledSlotSize);     
    RAISE_ERR(rc, RTN);
    
    gbOrdBkInit = TRUE;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   to get next free slot
 * Parameters:
 *      prdctId         IN  product id
 *      setId           IN  input set
 *      oNxtSlt         OUT order slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
ResCodeT OrdBkGetUsedOrdr(BOOL bReset,  int32 set, pOrderT * ppOrdr)
{
    BEGIN_FUNCTION( "OrdBkGetUsedOrdr" );
    ResCodeT rc = NO_ERR;
    static int32 currSlotNo = NULL_SLOT;
    pOrderT pRtOrderbook ;
     
    currSlotNo = (bReset)? NULL_SLOT : (currSlotNo);
    
    
    BitFindFS(gOrdrBkShmAcs[set].pOrdrBkVect, currSlotNo + 1, GET_MAX_SLOT_CNT(set) - 1, &currSlotNo);
    if (currSlotNo == NULL_SLOT)
    {
        THROW_RESCODE(ERR_OBK_SET_ODRBK_FULL);
    }
    
    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    *ppOrdr = &pRtOrderbook[currSlotNo];
     
    EXIT_BLOCK();
    RETURN_RESCODE;
    
} /* End - OrdBkGetUsedOrdr. */

/******************************************************************************
 * Description:   to get next free slot
 * Parameters:
 *      prdctId         IN  product id
 *      setId           IN  input set
 *      oNxtSlt         OUT order slot
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
static ResCodeT OrdBkNextFreeSlot( int32 set, SlotT *oNxtSlt)
{
    BEGIN_FUNCTION( "OrdBkNextFreeSlot" );
    ResCodeT rc = NO_ERR;
    pOrderT  oCO;
    BOOL openStatus = TRUE;
    BOOL errStatus = FALSE;
    uint32 firstSlot = NULL_SLOT;
    uint32 lastSlot = NULL_SLOT;

    pPoolSlotT poolSlot = &gSetPoolSlot[set];
    rc = RequestPoolSlot(poolSlot, (int32*)oNxtSlt);
    TRACE(" Slot %lld RequestPoolSlot, rc %lld" $$ oNxtSlt $$ rc);
    if (ERR_OBK_NOT_ENOUGH_BUFFER == rc)
    {
        int32 slotNo = -1;
        int32 i;
        TRACE("Alloc pool slot again");
        for (i = 0; i < poolSlot->poolSize; i++)
        {
            BitFindFC(gOrdrBkShmAcs[set].pOrdrBkVect, slotNo + 1,
                GET_MAX_SLOT_CNT(set) - 1, &slotNo);
            BREAK_ON_COND(-1 == slotNo);

            oCO = &( gOrdrBkShmAcs[set].pOrdrBkRoot[slotNo] );
            if ( CHECK_ORDR_SLOT_OPEN(oCO) )
            {
                openStatus = FALSE;
                i--;
                errStatus = TRUE;
            }
            else
            {
                SET_ORDR_SLOT_OPEN(oCO);
            }
            if ( firstSlot == NULL_SLOT )
            {
                firstSlot = slotNo;
            }
            BitSet(gOrdrBkShmAcs[set].pOrdrBkVect, slotNo);
            

            TRACE("Slot %lld allocates to pool slot" $$ slotNo);

            if ( openStatus )
            {
                RAISE_ERR(AllocPoolSlot(poolSlot, slotNo), RTN);
            }
            else
            {
                RAISE_ERR_PARM(ERR_OBK_VECTOR_ERR, NORTN,
                        set
                        $$ oCO->orderF.prdctId
                        $$ slotNo
                        $$ oCO->orderT.priceLdr );
                openStatus = TRUE;
            }
        }
        if ( lastSlot == NULL_SLOT )
        {
            lastSlot = slotNo;
        }
        THROW_RESCODE(RequestPoolSlot(poolSlot, (int32*)oNxtSlt));
    }
    else
    {
        TRACE("GetSlotFromPool slot %lld" $$ *oNxtSlt);
        THROW_RESCODE(rc);
    }


    EXIT_BLOCK();
    if (errStatus)
    {
        rc = GET_RESCODE();
        RAISE_ERR_PARM(ERR_OBK_VECTOR_ERR, NORTN,
                set
                $$ -1
                $$ firstSlot
                $$ lastSlot );
        SET_RESCODE(rc);
    }
    else
    {
        INC_USED_SLOT_CNT(set);
    }

    if (ERR_OBK_NOT_ENOUGH_BUFFER == GET_RESCODE())
    {
        SET_RESCODE(ERR_OBK_SET_ODRBK_FULL);
    }

    RETURN_RESCODE;
} /* End - OrdBkNextFreeSlot. */



/******************************************************************************
 * Description:   to create an order, but not in the order book itself
 * Parameters:
 *      prdctId         IN  product id
 *      setId           IN  input set
 *      pOrderCreate    OUT the output orderT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
ResCodeT OrdrBkCreateOrdr(int32 set, pOrderT *pOrderCreate)
{
    BEGIN_FUNCTION("OrdrBkCreateOrdr");
    ResCodeT rc = NO_ERR;
    SlotT    nextFreeSlot = ODBK_SHM_NO_SLOT;
    pOrderT  oCreateOrd = NULL;
    
    if ( !gbOrdBkInit )
    {
        RAISE_ERR( ERR_OBK_NOT_INIT, RTN );
    }
    
    TRACE("used %ld, max %ld" $$ GET_USED_ORDR_CNT(set) $$ GET_MAX_ORDR_CNT(set));
    if (GET_USED_ORDR_CNT(set) >= GET_MAX_ORDR_CNT(set))
    /*over a certain amount, don't search anymore*/
    {
        nextFreeSlot = ODBK_SHM_NO_SLOT;
        /* Enhance the error raised */
        RAISE_ERR_PARM(ERR_OBK_SET_ODRBK_FULL, RTN, set);
    }
    
    /* Get slot no. for new order. */
    rc = OrdBkNextFreeSlot(set, &nextFreeSlot);
    RAISE_ERR( rc, RTN );

    /* Create order in orderbook. */
    oCreateOrd = &( gOrdrBkShmAcs[set].pOrdrBkRoot[nextFreeSlot] );

    /* Initialise all the functional fields to their default values. */
    memset(&(oCreateOrd->orderF), 0x00, sizeof (OrderFT));

    /* Numerical, time, qty and prc fields. */

    /* Initialise all the technical fields to their default values. */

    /* OBSS fields. */
    INIT_ORDER_TECH_PART(oCreateOrd);

    /* Sundry fields. */
    oCreateOrd->orderT.slotNo    = nextFreeSlot;   /* Create orders' slot no. */
    oCreateOrd->orderT.free = 0;

    /* Set pointer to new order in the Orderbook Memory Area. */
    *pOrderCreate = oCreateOrd;
    
    INC_USED_ORDR_CNT(set);

    EXIT_BLOCK();
    RETURN_RESCODE;   
}

/******************************************************************************
 * Description: Create order at the specified order slot. This interface is for
 *  LoadMatcher to replicate order book on back-up host.
 * Parameters:
 *  setId   IN  The impacted set identification.
 *  slot    IN  The slot used to create the order.
 *  ppOrder OUT Write to the pointer to the created order.
 *  Return Value         :
 *  NO_ERR      successful.
 *  ERR_<DSCR>  error happens.
 *****************************************************************************/
ResCodeT OrdBkCreateOrderBySlot(int32 setId, int32 slot,
                        pOrderT *ppOrder)
{
    BEGIN_FUNCTION("CreateOrderBySlot");

    ASSERT(ppOrder);



    *ppOrder = &gOrdrBkShmAcs[setId].pOrdrBkRoot[slot];
    if ( CHECK_ORDR_SLOT_OPEN(*ppOrder) )
    {
        THROW_RESCODE( ERR_OBK_VECTOR_ERR );
    }
    SET_ORDR_SLOT_OPEN(*ppOrder);
    BitSet(gOrdrBkShmAcs[setId].pOrdrBkVect, slot);
   

    INIT_ORDER_TECH_PART(*ppOrder);
    (*ppOrder)->orderT.slotNo = slot;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Technically connect an order to all impacted linked lists in
 *  orderbook. The function will be called when an order is inserted either in a
 *  normal insertation/modification operation or in a rollback for a successful
 *  deletition operation. It will also be called in a rollback for an
 *  unsuccessful deletion operation.
 * Parameters:
 *  pAddO   IN/OUT  The order to be inserted.
 *  obssDirty   IN  Flag indicating impact on OBSS tree.
 *  ordNoDirty  IN  Flag indicating impact on order number list.
 *  rollback    IN  Flag indicating this calling is for a rollback operation.
 *  lstDone     IN  Flag indicating whether the operation to be rollback was
 *                  successful.
 *  pPrcLder    IN/OUT  Pointer to the price leader in case the calling impacts
                    on one.
 *  pOrdNoList  IN/OUT  Pointer to the order number list entry in case the
 *                  calling impact on one.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT OrdBkTechConnectOrder(pOrderT pAddO,
                BOOL obssDirty,
                BOOL ordNoDirty,
                BOOL entyDirty,
                BOOL rollback, 
                BOOL lstDone,
                pOrder4PrcLeadT pPrcLder,
                pOsSListEntryT pEntyNoList,
                pOsSListEntryT pOrdNoList,
                pOsSListEntryT pExpTimeList,
                pOrdrBkShmAcsT pShmAccess,
                pOrdBookCtxT pCtx)
{
    BEGIN_FUNCTION("OrdBkTechConnectOrder");
    ResCodeT rc = NO_ERR;
    int32 oSide; 
    ResCodeT (*InsertFunc)(const pOsSListModeT, void*, BOOL*, BOOL*, void**, BOOL, SlotT *);
    SlotT prcLderSlot = NULL_SLOT;
    int16   oTrdRes = 0;
    uint32  prdctId = pAddO->orderF.prdctId;
    char    doRollBack = rollback && !lstDone;
    
    BOOL headDirty, tailDirty, bstDirty, lstDirty;
    ASSERT(pAddO);

    if (pPrcLder)
    {
        TRACE("WithPrcLdr ## prdctId:%d|slot:%lld"
            $$ prdctId
            $$ pAddO->orderT.slotNo);
    }
    else
    {
        TRACE("NullPrcLder ## prdctId:%d|slot:%lld"
            $$ prdctId
            $$ pAddO->orderT.slotNo);
    }
    oSide = GET_ORDR_SIDE(pAddO->orderF.ordrMask);
    
    oTrdRes = GET_ORDR_TRDRESTR(pAddO->orderF.ordrMask);
    /* if not rollback, add the order to the list tail, while for rollback, add
    the order to the list head */
    InsertFunc = rollback ? InsertSListEntryFromHead : InsertSListEntryFromTail;
    if (pPrcLder)
    {
        prcLderSlot = pPrcLder->orderT.slotNo;
    }

    if (obssDirty)
    {
        
        /* new price leader is ready now. just add it to....*/
        /* special processing of price leader */
        listMode[PRICE_LEADER_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[PRICE_LEADER_LIST].pListHead = pCtx->pPrcLderList;
        listMode[PRICE_LEADER_LIST].theFrame=&pCtx->pListRegister->frmPrcLderList;
/*-----------------------------------------------------------------------------
if rollback for a succesful operation or a newly add operation, and the price
leader is empty, then the price leader is new and needs to be inserted into the
price leader list. If rollback for an unsuccessful operation, we need to
determine whether it was only one order left in the price leader prior to the
operation. If so, the price leader should have been removed from the price
leader list, and therefore also needs rollback for the deletion operation.
------------------------------------------------------------------------------*/
            if (doRollBack)
            {
                rc = SListRollBack(&listMode[PRICE_LEADER_LIST]);
            }
            else if (IS_EMPTY_PRC_LDER(pPrcLder))
            {
                TRACE("begin insert price leader");
                rc = InsertSListEntryFromHead(&listMode[PRICE_LEADER_LIST],
                    pPrcLder, NULL, NULL, NULL, 0, NULL);
            }
            RAISE_ERR(rc, RTN);
        
        
        switch (oTrdRes)
        {
            case ORDR_TRDRESTR_NO:

                listMode[U_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
                listMode[U_LIST].pListHead = &pPrcLder->orderT.unrO;
                listMode[U_LIST].theFrame = &pCtx->pListRegister->frmUList;
                TRACE("begin insert U list with slotNo %05d"
                    $$ pAddO->orderT.slotNo);
                rc = doRollBack ? SListRollBack(&listMode[U_LIST]) :
                InsertFunc(&listMode[U_LIST], pAddO, NULL, NULL, NULL, 0, NULL);
                RAISE_ERR(rc, RTN);

                
            case ORDR_TRDRESTR_AU:

                listMode[UA_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
                listMode[UA_LIST].pListHead = &pPrcLder->orderT.unrAuO;
                listMode[UA_LIST].theFrame = &pCtx->pListRegister->frmUAList;
                TRACE("begin insert UA list");
                rc = doRollBack ? SListRollBack(&listMode[UA_LIST]) :
                InsertFunc(&listMode[UA_LIST], pAddO, NULL, NULL, NULL, 0,NULL);
                RAISE_ERR(rc, RTN);
                
                

            case ORDR_TRDRESTR_OA:
        
                listMode[UAO_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
                listMode[UAO_LIST].pListHead = &pPrcLder->orderT.unrAuOaO;
                listMode[UAO_LIST].theFrame = &pCtx->pListRegister->frmUAOList;
                TRACE("begin insert UAO list");
                if (doRollBack)
                {
                    RAISE_ERR(SListRollBack(&listMode[UAO_LIST]), RTN);
                }
                else
                {

                    headDirty = tailDirty = 0;
                    RAISE_ERR(InsertFunc(&listMode[UAO_LIST], pAddO,
                    &headDirty, &tailDirty, NULL, 0, NULL), RTN);
                }
                break;
            default:
            THROW_RESCODE(!NO_ERR);
        }/* end switch (oTrdRes) */
        /* add reference to the price leader */
        if (!doRollBack)
        {
            pAddO->orderT.priceLdr = prcLderSlot;
        }
    }/* end obssDirty */

    if (ordNoDirty)
    {
        listMode[ORDR_NO_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[ORDR_NO_LIST].pListHead = pOrdNoList;
        listMode[ORDR_NO_LIST].theFrame = &pCtx->pListRegister->frmOrdrNoList;

        rc = doRollBack ? SListRollBack(&listMode[ORDR_NO_LIST]) :
            InsertSListEntryFromHead(&listMode[ORDR_NO_LIST], pAddO, NULL, NULL,
                NULL, 0, NULL);
        RAISE_ERR(rc, RTN);
        
        /**/
        listMode[EXP_TIME_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[EXP_TIME_LIST].pListHead = pExpTimeList;
        listMode[EXP_TIME_LIST].theFrame = &pCtx->pListRegister->frmExpTimeList;

        rc = doRollBack ? SListRollBack(&listMode[EXP_TIME_LIST]) :
            InsertSListEntryFromHead(&listMode[EXP_TIME_LIST], pAddO, NULL, NULL,
                NULL, 0, NULL);
        RAISE_ERR(rc, RTN);
        
    }

    if (entyDirty)
    {
        listMode[ENTY_NO_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[ENTY_NO_LIST].pListHead = pEntyNoList;
        listMode[ENTY_NO_LIST].theFrame = &pCtx->pListRegister->frmEntyList;
        
        TRACE("begin insert pbu list");
        rc = doRollBack ? SListRollBack(&listMode[ENTY_NO_LIST]) :
            InsertSListEntryFromHead(&listMode[ENTY_NO_LIST], pAddO, NULL, NULL,
                NULL, 0, NULL);
        RAISE_ERR(rc, RTN)
    }
        TRACE("Tech Connect Order book done");
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkTechConnectOrder */


/******************************************************************************
 * Description:   update the total order qty
 * Parameters:
 *      ordrSide            IN  order side
 *      qty                 IN  order qty
 *      remPkQty            IN  order remaining qty     
 *      pPrcLder            IN  price leader
 *      add                 IN  update type
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
static ResCodeT OrdBkOrdCntQtyAdjust(int16 ordMask, int64 qty,
                int64 remPkQty,
                pOrder4PrcLeadT pPrcLder,
                BOOL add,
                pOrdBookCtxT pCtx )
{
    BEGIN_FUNCTION("OrdBkOrdCntQtyAdjust");
    
    int64 adjustQty, adjustCnt, adjustQty4IceO;
    int16 oTrdRes = GET_ORDR_TRDRESTR(ordMask);
    int32 ordrSide = GET_ORDR_SIDE(ordMask);
    BOOL buySide = ORDR_SIDE_BUY == ordrSide;
    adjustQty = add ? qty : -qty;
    adjustCnt = add ? 1 : -1;
    
   
    ASSERT(pPrcLder);
    THROW_RESCODE_ON_COND(ERR_OBK_NULL_POINTER, !pPrcLder);
    EXECUTE_ON_2_COND(pCtx->pPrdctCtrl->cntBuy += adjustCnt,
        pCtx->pPrdctCtrl->cntSell += adjustCnt, buySide);
    do
    {
        pPrcLder->orderF.cntUnrAuOaO += adjustCnt;
        pPrcLder->orderF.totUnrAuOaO += adjustQty;
        BREAK_ON_COND(ORDR_TRDRESTR_OA == oTrdRes);

        pPrcLder->orderF.cntUnrAuO += adjustCnt;
        pPrcLder->orderF.totUnrAuO += adjustQty;
        BREAK_ON_COND(ORDR_TRDRESTR_AU == oTrdRes);

        pPrcLder->orderF.cntUnrO += adjustCnt;
        pPrcLder->orderF.totUnrO += adjustQty;
    } while (0);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkOrdCntQtyAdjust. */

/******************************************************************************
 * Description:   Add order to order book
 * Parameters:
 *      set             IN  set id
 *      ppAddO          IN  order book
 *      pModOrdrAddr     OUT order rollback information
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
ResCodeT OrdrBkAddOrdr(BOOL bRcvrFlg,int32 set, pOrderT *ppAddO, pMAddOrdrT pAddOrdrAddr)
{
    BEGIN_FUNCTION("OrdrBkAddOrdr");
    ResCodeT rc = NO_ERR;
    pOrderT pAddO = NULL;
    SlotT slotId;
    int32  oSide;
    pOrder4PrcLeadT pPrcLder = NULL;
    pOsSListEntryT pOrdNoList = NULL;
    pOsSListEntryT pEntyNoList = NULL;
    pOsSListEntryT pExpTimeList = NULL;
    OrdBkSortingT odrBkSortingType;
    void * pRoot = NULL;
    BOOL buySide;
    int32 bucketNo ;
    SlotT prcLderSlot;
    
    /* Start to preapre the input */    
    pAddO = *ppAddO;
    slotId = pAddO->orderT.slotNo;

    oSide = GET_ORDR_SIDE(pAddO->orderF.ordrMask);
     
    int64 ordrExePrc;
    Order4PrcLeadT prcLder;
    pOrder4PrcLeadT pTmpPrcLder = &prcLder;
    int32 prdctId = pAddO->orderF.prdctId;
    pOrderT pRtOrderbook ;
    
    CHK_PRDCT_ID(set,prdctId);
    
    gOrdBookCtx.pPrdctCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];

    pRtOrderbook = (pOrderT)gOrdrBkShmAcs[set].pOrdrBkRoot;
    pRoot = (void *)pRtOrderbook;
    
    buySide = ORDR_SIDE_BUY == oSide;

    gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    INIT_REG_LIST(gOrdBookCtx.pListRegister);

    /* find the price leader */
    /* firstly initialize a price leader */
    gOrdBookCtx.pPrcLderList = buySide ? &gOrdBookCtx.pPrdctCtrl->prcLderBuyO :
        &gOrdBookCtx.pPrdctCtrl->prcLderSellO;
    prcLderSlot = NULL_SLOT;
    
    
    odrBkSortingType = gOrdBookCtx.pPrdctCtrl->odrBkSortingType;
    ordrExePrc = pAddO->orderF.ordrExePrc;
    
    if (bRcvrFlg)
    {
        prcLderSlot = pAddOrdrAddr->prcLder;
        pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];

        if (pAddOrdrAddr->fNewPrcLder)
        {
            if ( CHECK_ORDR_SLOT_OPEN(pPrcLder) )
            {
                RAISE_ERR(ERR_OBK_VECTOR_ERR, RTN);
            }
            SET_ORDR_SLOT_OPEN(pPrcLder);
            BitSet(gOrdrBkShmAcs[set].pOrdrBkVect, prcLderSlot);
            INIT_ORDER_TECH_PART(pPrcLder);
            pPrcLder->orderT.slotNo = prcLderSlot;
            INIT_PRC_LDER_FUNC_PART(pPrcLder, odrBkSortingType,
                pAddO->orderF.ordrMask, ordrExePrc, prdctId);
        }
    }
    else
    {
        INIT_ORDER_TECH_PART((pOrderT)pTmpPrcLder);
        pTmpPrcLder->orderT.slotNo = NULL_SLOT;
    

        INIT_PRC_LDER_FUNC_PART(pTmpPrcLder, odrBkSortingType,pAddO->orderF.ordrMask, ordrExePrc,prdctId);
    
        listMode[PRICE_LEADER_LIST].pRoot = (char *)pRtOrderbook;
        listMode[PRICE_LEADER_LIST].pListHead = gOrdBookCtx.pPrcLderList;
         /* try to find the insertion position */
        rc = FindSListEntryByKey(&listMode[PRICE_LEADER_LIST],
                &pTmpPrcLder->orderF.ordrPri, (void**)&pPrcLder);
        if (ERR_OBJ_NOT_IN_LINKED_LIST == rc)
        {    
            TRACE("Try find price leader");
            RAISE_ERR(OrdBkNextFreeSlot(set, &prcLderSlot),RTN);
            pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];
            
            pPrcLder->orderT.free = 0;
    
            memcpy(pPrcLder, pTmpPrcLder, sizeof (Order4PrcLeadT));
            pPrcLder->orderT.slotNo = prcLderSlot;
            SET_ORDR_SLOT_OPEN(pPrcLder);
            
            if (pAddOrdrAddr)
            {
                pAddOrdrAddr->fNewPrcLder = 1;
            }
    
        }
        else
        {
            RAISE_ERR(rc, RTN);
            prcLderSlot = pPrcLder->orderT.slotNo;
            
            if (pAddOrdrAddr)
            {
                pAddOrdrAddr->fNewPrcLder = 0;
            }
    
        }
        if (pAddOrdrAddr)
        {
            pAddOrdrAddr->prcLder = prcLderSlot;
        }
    }
    bucketNo = pAddO->orderF.ordrNo % MAX_ORD_NO_LIST_BASE;
    pOrdNoList = &gOrdrBkShmAcs[set].lstInfo[ORD_NO_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + bucketNo];
   
    pEntyNoList = &gOrdrBkShmAcs[set].lstInfo[ENTY_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + pAddO->orderF.entyIdxNo];
    pExpTimeList = &gOrdrBkShmAcs[set].lstInfo[EXP_TIME_LST].pRtItemSearchVct[prdctId];
    TRACE("begin OrdBkTechConnectOrder");

    RAISE_ERR(OrdBkTechConnectOrder(pAddO, TRUE, TRUE, TRUE, FALSE,0,pPrcLder, pEntyNoList, pOrdNoList,pExpTimeList,&gOrdrBkShmAcs[set],&gOrdBookCtx), RTN);

    EXIT_BLOCK();
    if (OK(GET_RESCODE()))
    {
        RAISE_ERR(OrdBkOrdCntQtyAdjust( pAddO->orderF.ordrMask, pAddO->orderF.ordrQty,
            pAddO->orderF.remPkQty, pPrcLder, 1, &gOrdBookCtx), NORTN);

        UpdateBstLstOrders(gOrdBookCtx.pPrdctCtrl, buySide, gOrdrBkShmAcs[set].pOrdrBkRoot);

    }
    RETURN_RESCODE;   
}

/******************************************************************************
 * Description:Technically disconnect an order from all impacted linked lists in
 *  orderbook. The function will be called when an order is deleted either in a
 *  normal deletion/modification operation or in a rollback for a successful
 *  insertion operation. It will also be called 4 a rollback for an unsuccessful
 *  insertion operation.
 * Parameters:
 *  pDelO   IN/OUT  The order to be inserted.
 *  obssDirty   IN  Flag indicating impact on OBSS tree.
 *  ordNoDirty  IN  Flag indicating impact on order number list.
 *  rollback    IN  Flag indicating this calling is for a rollback operation.
 *  lstDone     IN  Flag indicating whether the operation to be rollback was
 *                  successful.
 *  pPrcLder    IN/OUT  Pointer to the price leader in case the calling impacts
                    on one.
 *  pOrdNoList  IN/OUT  Pointer to the order number list entry in case the
 *                  calling impact on one.
 * Return Value         :
 *  NO_ERR  successful.
 *  ERR_<DSCR>  error happens.
 *****************************************************************************/
static ResCodeT OrdBkTechDisconnectOrder(pOrderT pDelO,
                BOOL obssDirty,
                BOOL ordNoDirty,
                BOOL entyDirty,
                BOOL rollback,
                BOOL lstDone,
                pOrder4PrcLeadT pPrcLder,
                pOsSListEntryT pEntyNoList,
                pOsSListEntryT pOrdNoList,
                pOsSListEntryT pExpTimeList,
                pOrdrBkShmAcsT pShmAccess,
                pOrdBookCtxT pCtx)
{
    BEGIN_FUNCTION("OrdBkTechDisconnectOrder");
    ResCodeT    rc = NO_ERR;
    SlotT       prcLderSlot;
    int32       oMask, oTrdRes, oType;
    char        doRollback = rollback & !lstDone;


    ASSERT(pDelO);
    
    oMask = pDelO->orderF.ordrMask;
    oTrdRes = GET_ORDR_TRDRESTR(oMask);
    oType = GET_ORDR_TYPE(oMask);

    if (obssDirty)
    {
        switch (oTrdRes)
        {
            case ORDR_TRDRESTR_NO:

            listMode[U_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
            listMode[U_LIST].pListHead = &pPrcLder->orderT.unrO;
            listMode[U_LIST].theFrame = &pCtx->pListRegister->frmUList;
            rc = doRollback ?
                SListRollBack(&listMode[U_LIST]) :
                DelSListEntry(&listMode[U_LIST], pDelO, NULL, NULL);
            RAISE_ERR(rc, RTN);

            case ORDR_TRDRESTR_AU:

            listMode[UA_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
            listMode[UA_LIST].pListHead = &pPrcLder->orderT.unrAuO;
            listMode[UA_LIST].theFrame = &pCtx->pListRegister->frmUAList;
            rc = doRollback ? SListRollBack(&listMode[UA_LIST]) :
                DelSListEntry(&listMode[UA_LIST], pDelO, NULL, NULL);
            RAISE_ERR(rc, RTN);

            case ORDR_TRDRESTR_OA:

            listMode[UAO_LIST].pRoot =(char * )pShmAccess->pOrdrBkRoot;;
            listMode[UAO_LIST].pListHead = &pPrcLder->orderT.unrAuOaO;
            listMode[UAO_LIST].theFrame = &pCtx->pListRegister->frmUAOList;
            if (doRollback)
            {

                RAISE_ERR(SListRollBack(&listMode[UAO_LIST]), RTN);
            }
            else
            {
                BOOL headDirty = 0, tailDirty = 0,bstDirty = 0,lstDirty = 0;
                RAISE_ERR(DelSListEntry(&listMode[UAO_LIST], pDelO,
                    &headDirty, &tailDirty), RTN);
        /* it's not always correct to update best/last orders here. coz
        it's possible that the price leader become empty, and therefore the
        best/last orders should come from next price leader rather than
        current one. this can happen only when an order is removed from a
        price leader, therefore we will not update best/last orders here
        any more, but do so at the end of delete/modify an order, rollback
        for add/delete/modify an order */
            }
            break;
            default:
            THROW_RESCODE(!NO_ERR);
        }/* end switch (oTrdRes)*/

        listMode[PRICE_LEADER_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[PRICE_LEADER_LIST].pListHead = pCtx->pPrcLderList;
        listMode[PRICE_LEADER_LIST].theFrame =
            &pCtx->pListRegister->frmPrcLderList;
        if (doRollback)
        {
            rc = SListRollBack(&listMode[PRICE_LEADER_LIST]);
        }
        else if (IS_EMPTY_PRC_LDER(pPrcLder))
        {
            rc = DelSListEntry(&listMode[PRICE_LEADER_LIST], pPrcLder, NULL,
                NULL);
        }
        RAISE_ERR(rc, RTN);
    }

    if (ordNoDirty)
    {
        listMode[ORDR_NO_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[ORDR_NO_LIST].pListHead = pOrdNoList;
        listMode[ORDR_NO_LIST].theFrame = &pCtx->pListRegister->frmOrdrNoList;

        rc = doRollback ? SListRollBack(&listMode[ORDR_NO_LIST]) :
            DelSListEntry(&listMode[ORDR_NO_LIST], pDelO, NULL, NULL);
        RAISE_ERR(rc, RTN);
        
        listMode[EXP_TIME_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[EXP_TIME_LIST].pListHead = pExpTimeList;
        listMode[EXP_TIME_LIST].theFrame = &pCtx->pListRegister->frmExpTimeList;

        rc = doRollback ? SListRollBack(&listMode[EXP_TIME_LIST]) :
            DelSListEntry(&listMode[EXP_TIME_LIST], pDelO, NULL, NULL);
        RAISE_ERR(rc, RTN);
        
        
    }

    if (entyDirty)
    {
        listMode[ENTY_NO_LIST].pRoot = (char * )pShmAccess->pOrdrBkRoot;
        listMode[ENTY_NO_LIST].pListHead = pEntyNoList;
        listMode[ENTY_NO_LIST].theFrame = &pCtx->pListRegister->frmEntyList;
        TRACE("begin delete pbu list");
        rc = doRollback ? SListRollBack(&listMode[ENTY_NO_LIST]) :
            DelSListEntry(&listMode[ENTY_NO_LIST], pDelO, NULL, NULL);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkTechDisconnectOrder */

/******************************************************************************
 * Description:   free the order space
 * Parameters:
 *      setId           IN  input set
 *      pOrderCreate    OUT the output orderT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Delete the share memory.
 ******************************************************************************/
ResCodeT OrdrBkFreeOrder(int32 set, pOrderT *pFreeOrder )
{
    BEGIN_FUNCTION( "OrdrBkFreeOrder" );
    ResCodeT rc = NO_ERR;
    
    if ( !gbOrdBkInit )
    {
        RAISE_ERR( ERR_OBK_NOT_INIT, RTN );
    }

    pOrderT  pFreeO;
    SlotT oFree;
    ASSERT( pFreeOrder );

    pFreeO = *pFreeOrder;

    /* Slot no. of order to be freed. */
    oFree = pFreeO->orderT.slotNo;

    pFreeO->orderT.free = 0;

    if (!BitCheck((uint64 *)gOrdrBkShmAcs[set].pOrdrBkVect, oFree))
    {
        TRACE("slotno:%lld" $$ oFree);
        RAISE_ERR_PARM(ERR_OBK_FREEORDER_FAIL, NORTN, oFree);
        return NO_ERR;
    }
    RESET_ORDR_SLOT_OPEN(pFreeO);
    BitReset((uint64 *)gOrdrBkShmAcs[set].pOrdrBkVect, oFree);

    pFreeO->orderT.free = 1;

    /* Free order pointer should no longer exist. */
    *pFreeOrder = NULL;
    
    DES_USED_ORDR_CNT(set);
    DES_USED_SLOT_CNT(set);

    EXIT_BLOCK();

    RETURN_RESCODE;
} /* End - OrdrBkFreeOrder. */

/******************************************************************************
 * Description:   Delete an order residing in the Orderbook Memory Area from
 *                the Orderbook Sorting Structure (OBSS). The order is freed
 *                from the orderbook memory area and a null pointer is returned.
 *  The function can work in 2 modes:
 *  (1) if pFrameData is NULL, then delete order from the OBSS tree on back-up
 *      host. This is mode is for LoadMatcher to replicate order book on back-up
 *      host. In this case, pMlDelOrdr provides input parameters;
 *  (2) otherwise delete orde from the OBSS on primary host. This mode is for
 *      MainMatcher to delete order on primary host. In this case, both
 *      pMlDelOrdr and pFrameData are output to log data for rollback or
 *      replication
 *
 * Parameters:
 *  pDelOrder   IN/OUT  pointer to the order to be deleted from the OBSS. if
 *                      successful, the pointer will be filled with NULL.
 *  tranTime    IN  The transaction time to delete the order.
 *  pMlDelOrdr  IN/OUT  pointer to working page.
 *  pFrameData  OUT pointer to frame data.

 * Return Value         : NO_ERR                    - Successful
 *                        ERR_<DESC>                - Error
 *                        ERR_OBK_NULL_POINTER      - NULL pointer input.
 *                        ERR_OBK_ADDORDER_INV_TREE - Invalid tree structure.
 *                        ERR_OBK_ADDORDER_INV_SIDE - Invalid orderbook side.
 *****************************************************************************/
ResCodeT OrdrBkDeleteOrdr( int32 set, pOrderT *pDelOrder,
                const int64 tranTime)
{
    BEGIN_FUNCTION("OrdrBkDeleteOrdr");
    ResCodeT rc = NO_ERR;
    pOrderT pDelO;
    SlotT prcLderSlot = NULL_SLOT, modBucket = NULL_SLOT;
    pOrder4PrcLeadT pPrcLder = NULL;
    pOsSListEntryT pOrdNoList = NULL;
    pOsSListEntryT pEntyNoList = NULL;
    pOsSListEntryT pExpTimeList = NULL;
    int32 oSide = 0;
    BOOL    buySide;
    char obssDirty, ordNoDirty;
    pPrdctCtrlT instCtrl = NULL;
    pOrderT pRtOrderbook = NULL;
    int32 bucketNo;
    int32 prdctId;
    ASSERT(pDelOrder);

    pDelO = *pDelOrder;
    prcLderSlot = pDelO->orderT.priceLdr;
    prdctId= pDelO->orderF.prdctId;
 
    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    instCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];
    oSide = GET_ORDR_SIDE(pDelO->orderF.ordrMask);
    buySide = ORDR_SIDE_BUY == oSide;
    
    bucketNo = pDelO->orderF.ordrNo % MAX_ORD_NO_LIST_BASE;
    pOrdNoList = &gOrdrBkShmAcs[set].lstInfo[ORD_NO_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + bucketNo];
   
    pEntyNoList = &gOrdrBkShmAcs[set].lstInfo[ENTY_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + pDelO->orderF.entyIdxNo];
    pExpTimeList = &gOrdrBkShmAcs[set].lstInfo[EXP_TIME_LST].pRtItemSearchVct[prdctId];

    TRACE("begin OrdBkTechConnectOrder");
    

    gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    INIT_REG_LIST(gOrdBookCtx.pListRegister);


    TRACE("FindPrcLdr ## prdctId:%d|setId:%d|prcLderSlot:%lld|ordSlot:%lld"
            $$ pDelO->orderF.prdctId $$ set
            $$ prcLderSlot $$ pDelO->orderT.slotNo);

    /* find the price leader */
    prcLderSlot = pDelO->orderT.priceLdr;
    pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];
    gOrdBookCtx.pPrcLderList = buySide ? &instCtrl->prcLderBuyO :
        &instCtrl->prcLderSellO;

    pDelO->orderF.tranTime = tranTime;

    RAISE_ERR(OrdBkTechDisconnectOrder(pDelO, TRUE, TRUE,
        TRUE, 0,0, pPrcLder, pEntyNoList, pOrdNoList, pExpTimeList, &gOrdrBkShmAcs[set],&gOrdBookCtx), RTN);

    EXIT_BLOCK();

    if (OK(GET_RESCODE()))
    {
        RAISE_ERR(OrdBkOrdCntQtyAdjust( pDelO->orderF.ordrMask, pDelO->orderF.ordrQty,
            pDelO->orderF.remPkQty, pPrcLder, 0, &gOrdBookCtx), NORTN);
        /*free the slot occupied by the deleted order and update information .*/

        //RAISE_ERR(OrdrBkFreeOrder(set, pDelOrder), NORTN);
        if (pPrcLder && IS_EMPTY_PRC_LDER(pPrcLder))
        {

            RAISE_ERR(OrdrBkFreeOrder(set,(pOrderT *)&pPrcLder), NORTN);
        }

        UpdateBstLstOrders(instCtrl, buySide, gOrdrBkShmAcs[set].pOrdrBkRoot);
    }
    
    RETURN_RESCODE;
}/* End - OrdrBkDeleteOrdr */
/******************************************************************************
 * Description:   Get Best Order 
 * Parameters:
 *      setId           IN  input set
 *      prdctId         IN  product id
 *      oMask           IN  order side
 *      pBestO          OUT best order address 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to get best order
 ******************************************************************************/
ResCodeT GetBest(int32 set, const int32 prdctId,int16 oMask,  pOrderT *pBestO )
{
    BEGIN_FUNCTION( "GetBest" );
    ResCodeT rc = NO_ERR;
    BOOL buySide;
    SlotT slotId = NULL_SLOT, priceLder = NULL_SLOT;
    pOrderT pRtOrderbook = NULL;
    pOrder4PrcLeadT pPrcLder = NULL;
    pPrdctCtrlT instCtrl = NULL;
    int16 oTrdrestr = GET_ORDR_TRDRESTR(oMask);
    int32 oSide = GET_ORDR_SIDE(oMask);
    ASSERT(pBestO);
    

    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    instCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];

    buySide = ORDR_SIDE_BUY == oSide;

    /* No best order yet, return NULL pointer. */
    *pBestO = NULL;

    priceLder = buySide ? instCtrl->prcLderBuyO.next :
        instCtrl->prcLderSellO.next;
    EXECUTE_ON_COND(pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[priceLder],
        NON_NULL_SLOT(priceLder));

    while (pPrcLder)
    {
        if (ORDR_TRDRESTR_OA == oTrdrestr)
        {
            /* UAO list*/
            slotId = pPrcLder->orderT.unrAuOaO.next;
        }
        else if (ORDR_TRDRESTR_AU == oTrdrestr)
        {
            /* UA list */
            slotId = pPrcLder->orderT.unrAuO.next;
        }
        else if (ORDR_TRDRESTR_NO == oTrdrestr)
        {
            /* U list */
            slotId = pPrcLder->orderT.unrO.next;
        }
        else
        {
            THROW_RESCODE(ERR_OBK_TRDRESTR_TYP_INV);
        }
        if ( NON_NULL_SLOT(slotId) )
        {
            TRACE("FoundASlot ## isix:%d|setId:%d|prcLderSlotNo:%lld|ordSlot:%lld"
            $$ prdctId $$ set
            $$ pPrcLder->orderT.slotNo $$ slotId );
        }
        

        BREAK_ON_COND(NON_NULL_SLOT(slotId));
        NXT_PRC_LDER(pPrcLder,set);
    }

    EXIT_BLOCK();

    if (OK(GET_RESCODE()) && NON_NULL_SLOT(slotId))
    {
        *pBestO = &pRtOrderbook[slotId];

        if ( prdctId != 0 && prdctId != (*pBestO)->orderF.prdctId )
        {
            RAISE_ERR_PARM(ERR_MATCHER_BST_ORD_ERR, NORTN,
                set $$ prdctId $$ (*pBestO)->orderF.prdctId $$ slotId);
        }
    }
    RETURN_RESCODE;
} /* End - GetBest. */


/******************************************************************************
 * Description:   Get Best Order 
 * Parameters:
 *      setId           IN  input set
 *      prdctId         IN  product id
 *      oMask           IN  order side
 *      pBestO          OUT best order address 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to get best order
 ******************************************************************************/
ResCodeT GetFrstOrdrForPrcLeader(int32 set, const int32 prdctId,int16 oMask, pOrder4PrcLeadT pPrcLder, pOrderT *pFrstOrdr )
{
    BEGIN_FUNCTION( "GetBest" );
    ResCodeT rc = NO_ERR;
    BOOL buySide;
    SlotT slotId = NULL_SLOT, priceLder = NULL_SLOT;
    pOrderT pRtOrderbook = NULL;
    int16 oTrdrestr = GET_ORDR_TRDRESTR(oMask);
    int32 oSide = GET_ORDR_SIDE(oMask);
    ASSERT(pBestO);
    

    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;

    buySide = ORDR_SIDE_BUY == oSide;

    /* No best order yet, return NULL pointer. */
    *pFrstOrdr = NULL;

    while (pPrcLder)
    {
        if (ORDR_TRDRESTR_OA == oTrdrestr)
        {
            /* UAO list*/
            slotId = pPrcLder->orderT.unrAuOaO.next;
        }
        else if (ORDR_TRDRESTR_AU == oTrdrestr)
        {
            /* UA list */
            slotId = pPrcLder->orderT.unrAuO.next;
        }
        else if (ORDR_TRDRESTR_NO == oTrdrestr)
        {
            /* U list */
            slotId = pPrcLder->orderT.unrO.next;
        }
        else
        {
            THROW_RESCODE(ERR_OBK_TRDRESTR_TYP_INV);
        }
        if ( NON_NULL_SLOT(slotId) )
        {
            TRACE("FoundASlot ## isix:%d|setId:%d|prcLderSlotNo:%lld|ordSlot:%lld"
            $$ prdctId $$ set
            $$ pPrcLder->orderT.slotNo $$ slotId );
        }
        

        BREAK_ON_COND(NON_NULL_SLOT(slotId));
        NXT_PRC_LDER(pPrcLder,set);
    }

    EXIT_BLOCK();

    if (OK(GET_RESCODE()) && NON_NULL_SLOT(slotId))
    {
        *pFrstOrdr = &pRtOrderbook[slotId];

        if ( prdctId != 0 && prdctId != (*pFrstOrdr)->orderF.prdctId )
        {
            RAISE_ERR_PARM(ERR_MATCHER_BST_ORD_ERR, NORTN,
                set $$ prdctId $$ (*pFrstOrdr)->orderF.prdctId $$ slotId);
        }
    }
    RETURN_RESCODE;
} /* End - GetBest. */


/******************************************************************************
 * Description:   Retrieves the next order following the current order in an
 *                OBSS.
 *
 * Parameters:
 *      oMask           : IN  - order mask specifying trading restriction and
 *                              orderbook side.
 *      pCrrOrder       : IN  - pointer to the current order.
 *      pNxtOrder       : OUT - pointer to the next order.
 * Return Value         : NO_ERR               - Successful
 *                        ERR_<DESC>           - Error
 *****************************************************************************/
ResCodeT GetBestOrgOrder( int32 set, int32 prdctId, const int32 oMask, int64 orgPos, pOrderT * ppBstOrgOrder )
{
    BEGIN_FUNCTION( "GetBestOrgOrder" );
    ResCodeT        rc = NO_ERR;
    pOrderT         pBkOrdr = NULL,  pNxtOrdr = NULL;
    
    
    rc = GetBest(set, prdctId, oMask,  &pBkOrdr );
    RAISE_ERR( rc, RTN );
    
    do
    {
        if (pBkOrdr->orderF.entyIdxNo == orgPos)
        {
            LOG_DEBUG("Found the org id in best order list %d", orgPos);
            * ppBstOrgOrder = pBkOrdr;
            THROW_RESCODE(NO_ERR);
        }
        
        rc = GetNextOrder(set, prdctId, oMask, pBkOrdr, &pNxtOrdr );
        RAISE_ERR( rc, RTN );
        
        pBkOrdr = pNxtOrdr;
        
    } while (pBkOrdr);

    EXIT_BLOCK();

    RETURN_RESCODE;
} /* End - GetNextOrder. */

/******************************************************************************
 * Description:   Retrieves the next order following the current order in an
 *                OBSS.
 *
 * Parameters:
 *      oMask           : IN  - order mask specifying trading restriction and
 *                              orderbook side.
 *      pCrrOrder       : IN  - pointer to the current order.
 *      pNxtOrder       : OUT - pointer to the next order.
 * Return Value         : NO_ERR               - Successful
 *                        ERR_<DESC>           - Error
 *****************************************************************************/
ResCodeT GetNextOrder( int32 set, int32 prdctId, const int32 oMask, const pOrderT pCrrOrder,
                    pOrderT *pNxtOrder )
{
    BEGIN_FUNCTION( "GetNextOrder" );
    ResCodeT rc = NO_ERR;
    int32 oTrdrestr;

    SlotT slotId = NULL_SLOT, priceLder = NULL_SLOT;
    pOrderT pRtOrderbook = NULL;
    pPrdctCtrlT instCtrl = NULL;

    ASSERT(pNxtOrder);

    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    instCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];
    oTrdrestr = GET_ORDR_TRDRESTR(oMask);

    *pNxtOrder = NULL;


    /* here is a trick. all fiedls accessed below are the same for both
    OrderT and Order4PrcLeadT */
    pOrder4PrcLeadT pPrcLder = (pOrder4PrcLeadT)pCrrOrder;
    do
    {
        if (ORDR_TRDRESTR_OA == oTrdrestr)
        {   /* UAO list */
            slotId = pPrcLder->orderT.unrAuOaO.next;
        }
        else if (ORDR_TRDRESTR_AU == oTrdrestr)
        {   /* UA list */
            slotId = pPrcLder->orderT.unrAuO.next;
        }
        else if (ORDR_TRDRESTR_NO == oTrdrestr)
        {   /* U list */
            slotId = pPrcLder->orderT.unrO.next;
        }
        else
        {
            /* Enhance the error raised */
            RAISE_ERR(ERR_OBK_TRDRESTR_TYP_INV, RTN);
        }
        BREAK_ON_COND(NON_NULL_SLOT(slotId));
        /* real price leader has a NULL_SLOT value in this field! if
        NON_NULL_SLOT, it is a time order. so get the price leader. */
        if (NON_NULL_SLOT(pPrcLder->orderT.priceLdr))
        {
            priceLder = pPrcLder->orderT.priceLdr;
            pPrcLder =
                (pOrder4PrcLeadT)&pRtOrderbook[priceLder];
        }
        priceLder = pPrcLder->orderT.prcLder.next;
        BREAK_ON_COND(NULL_SLOT_ID(priceLder));
        pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[priceLder];
    } while (1);
  

    EXIT_BLOCK();
    if (OK(GET_RESCODE()) && NON_NULL_SLOT(slotId))
    {
        *pNxtOrder = &pRtOrderbook[slotId];
    }
    RETURN_RESCODE;
} /* End - GetNextOrder. */

/******************************************************************************
 * Description:   Get best order group information.
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 *  oMask       IN  order mask
 *  pBstGrp     OUT Order group.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT GetBstGrp(int32 set, const int32 prdctId,
                int32 oMask,
                pBstGrpT pBstGrp)
{
    BEGIN_FUNCTION("GetBstGrp");
    ResCodeT rc = NO_ERR;
    SlotT prcLderSlot = NULL_SLOT;
    pOrder4PrcLeadT pPrcLder = NULL;
    int16 offset, ordrSide;
    pPrdctCtrlT instCtrl;
    pOrderT pRtOrderbook;

    ASSERT(pBstGrp);
    
    instCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];
    memset(pBstGrp, 0x00, sizeof (BstGrpT));
    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    
    int32 oTrdRes = GET_ORDR_TRDRESTR(oMask),
                    oSide = GET_ORDR_SIDE(oMask);
                
    switch (oTrdRes)
    {
        case ORDR_TRDRESTR_NO:
            offset = 0;
            break;
        case ORDR_TRDRESTR_AU:
            offset = (offsetof(OrderF4PrcLeadT, totUnrAuO) - offsetof(OrderF4PrcLeadT,
            totUnrO))  / sizeof (int64);
            break;
        case ORDR_TRDRESTR_OA:
            offset = (offsetof(OrderF4PrcLeadT, totUnrAuOaO) - offsetof(OrderF4PrcLeadT,
            totUnrO)) / sizeof (int64);
            break;
        default:
            THROW_RESCODE(ERR_OBK_TRDRESTR_TYP_INV);
    }

    /* 0 for buy side and 1 for sell side */
    ordrSide = ORDR_SIDE_SELL == oSide;
    do
    {
        /* get best group */
        prcLderSlot = ((&instCtrl->prcLderBuyO)[ordrSide]).next;
        if (NON_NULL_SLOT(prcLderSlot))
        {
            pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];
            if (!pPrcLder->orderF.ordrExePrc)
            {
                (&pBstGrp->bstBuyMktQty)[ordrSide] =
                    (&pPrcLder->orderF.totUnrO)[offset];
                NXT_PRC_LDER(pPrcLder,set);
            }
            /*we only interest in particular trading restrictions*/
            while (pPrcLder && !(&pPrcLder->orderF.totUnrO)[offset] )
            {
                NXT_PRC_LDER(pPrcLder,set);
            }
            if (pPrcLder)
            {
                (&pBstGrp->bstBuyLmtPrc)[ordrSide] =
                    pPrcLder->orderF.ordrExePrc;
                (&pBstGrp->bstBuyLmtQty)[ordrSide] =
                    (&pPrcLder->orderF.totUnrO)[offset];
                    
                (&pBstGrp->bstBuyLmtOrdCnt)[ordrSide]  =
                    (&pPrcLder->orderF.cntUnrO)[offset];
                    
                    
                    
                NXT_PRC_LDER(pPrcLder,set);
            }
            /* it's possible that next price leader with the same limit price
            while lower priority because of PQT/PT sorting configuration. */
            if (pPrcLder &&
                (&pBstGrp->bstBuyLmtPrc)[ordrSide] ==
                    pPrcLder->orderF.ordrExePrc                &&
                (&pPrcLder->orderF.totUnrO)[offset] )
            {
                (&pBstGrp->bstBuyLmtQty)[ordrSide] +=
                    (&pPrcLder->orderF.totUnrO)[offset];
                
                (&pBstGrp->bstBuyLmtOrdCnt)[ordrSide]  =
                    (&pPrcLder->orderF.cntUnrO)[offset];                       
            }          
        }
        ordrSide = !ordrSide;
    } while (ORDR_SIDE_NONE == oSide && ordrSide);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - GetBstGrp */


/******************************************************************************
 * Description:   Get best order price
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 *  oMask       IN  order mask
 *  pBstGrp     OUT Order group.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT GetBstPrc(int32 set, int32            prdctId,
                    int32            ordrMask,
                    pBstGrpT       pBstGrp)
{
    BEGIN_FUNCTION("GetBstPrc");
    ResCodeT        rc = NO_ERR;
    
    /* future we could add trading schedule logic here in case different business logic in different trading time */

    rc = GetBstGrp(set, prdctId, ordrMask, pBstGrp);
    RAISE_ERR(rc, RTN);
    RETURN_RESCODE;

    EXIT_BLOCK();
}

/******************************************************************************
 * Description:   update order exe qty
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 *  oMask       IN  order mask
 *  pBstGrp     OUT Order group.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT OrdBkUpdOrdExeQty ( pOrderFT pUpdO,
                                    pOrder4PrcLeadT pPrcLder,
                                    int64 exeQty )
{
    BEGIN_FUNCTION ( "OrdBkUpdOrdExeQty" );
    int32 oMask, oType, oTrdRes;
    oMask = pUpdO->ordrMask;
    oType = GET_ORDR_TYPE(oMask);
    oTrdRes = GET_ORDR_TRDRESTR(oMask);
    int64 tmpQty;
    
    tmpQty = pUpdO->ordrQty - pUpdO->remPkQty;
    pUpdO->ordrExeQty += exeQty;
    pUpdO->ordrQty    -= exeQty;

    switch (oTrdRes)
    {
        case ORDR_TRDRESTR_NO:
        pPrcLder->orderF.totUnrO -= exeQty;
        case ORDR_TRDRESTR_AU:
        pPrcLder->orderF.totUnrAuO -= exeQty;
        case ORDR_TRDRESTR_OA:
        pPrcLder->orderF.totUnrAuOaO -= exeQty;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}                               /* End - OrdBkUpdOrdExeQty */
/******************************************************************************
 * Description:   Modify quantity of order residing in the set share memory.
 *  The function can work in 2 modes:
 *  (1) if pFrameData is NULL, then modify order on back-up host. This is mode
 *      is for LoadMatcher to replicate order book on back-up host. In this case
 *      , pMlModQty provides input parameters;
 *  (2) otherwise modify order on primary host. This mode is for MainMatcher to
 *      modify order on primary host. In this case, both pMlModQty and
 *      pFrameData are output to log data for rollback or replication
 *
 * Parameters:
 *  modOrdr IN/OUT  Pointer to the order whose quantity is to be modified.
 *  exeQty  IN  The order quantity to be updated.
 *  tranTime    IN  The transaction time to modify the order quantity.
 *  pMlModQty   IN/OUT  Pointer to working page.
 *
 * Return Value         : NO_ERR                    - Successful
 *                        ERR_<DESC>                - Error
 *                        ERR_OBK_NULL_POINTER      - NULL pointer input.
 *                        ERR_OBK_ADDORDER_INV_TREE - Invalid tree structure.
 *                        ERR_OBK_ADDORDER_INV_SIDE - Invalid orderbook side.
 *****************************************************************************/
ResCodeT OrdBkModOrdrQty (int32 set,  pOrderT modOrdr,
                            int64 exeQty,
                            int64 tranTime)
{
    BEGIN_FUNCTION ( "OrdBkModOrdrQty" );
    pOrder4PrcLeadT pPrcLder = NULL;
    SlotT prcLderSlot = NULL_SLOT;
    pOrderT pRtOrderbook = NULL;
    int32 oMask, oTrdRes;    
    int32 buySide;
    int32 prdctId;

    ASSERT( modOrdr );
    
    oMask = modOrdr->orderF.ordrMask;
    oTrdRes = GET_ORDR_TRDRESTR(oMask);
    buySide = ORDR_SIDE_BUY == GET_ORDR_SIDE(oMask);
    pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    prdctId = modOrdr->orderF.prdctId;
    gOrdBookCtx.pPrdctCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];

    prcLderSlot = modOrdr->orderT.priceLdr;
    pPrcLder = ( pOrder4PrcLeadT ) & pRtOrderbook[prcLderSlot];
    
    /* change the order */
    modOrdr->orderF.tranTime = tranTime;
    RAISE_ERR( OrdBkUpdOrdExeQty ( &modOrdr->orderF, pPrcLder, exeQty ),
                        RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}  /* End - OrdBkModOrdrQty */

/******************************************************************************
 * Description: update order quantity of the specified order. NB: the order
 *  quantity information of the order itself won't be changed during the calling
 *  , and only the order quantity information in instrument control or price
 *  leader will be changed.
 * Parameters:
 *  oldOrdr IN  Functional part of the old order that provides the old order
 *              quantity information.
 *  pPrcLder IN Pointer to the impacted price leader.
 *  newOrdr IN  Functional part of the new order that provides the new order
 *              quantity information.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>  error happens.
 *****************************************************************************/
ResCodeT OrdBkUpdOrdQty ( pOrderFT oldOrdr,
                                pOrder4PrcLeadT pPrcLder,
                                pOrderFT newOrdr)
{
    BEGIN_FUNCTION ( "OrdBkUpdOrdQty" );
    int32 oMask, oTrdRes;
    int64 qtyChg;

    oMask = newOrdr->ordrMask;
    oTrdRes = GET_ORDR_TRDRESTR(oMask);
    qtyChg = newOrdr->ordrQty - oldOrdr->ordrQty;
    
    switch (oTrdRes)
    {
        case ORDR_TRDRESTR_NO:
        pPrcLder->orderF.totUnrO += qtyChg;
        case ORDR_TRDRESTR_AU:
        pPrcLder->orderF.totUnrAuO += qtyChg;
        case ORDR_TRDRESTR_OA:
        pPrcLder->orderF.totUnrAuOaO += qtyChg;
        break;
        default:
        THROW_RESCODE(!NO_ERR);
    }
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkUpdOrdQty */
/******************************************************************************
 * Description:   Modify order residing in set share memory.
 *  The function can work in 2 modes:
 *  (1) if pFrameData is NULL, then modify order on back-up host. This is mode
 *      is for LoadMatcher to replicate order book on back-up host. In this case
 *      , pMlModQty provides input parameters;
 *  (2) otherwise modify order on primary host. This mode is for MainMatcher to
 *      modify order on primary host. In this case, both pMlModOrdr and
 *      pFrameData are output to log data for rollback or replication
 *
 * Parameters:
 *  pOldOrdr    IN/OUT  Pointer to pointer to the order to be modified.
 *  pModOrdrAddr IN/OUT  rollback information
 *  newOrdr IN  Pointer to the functional part of the new order.
 *  pFrameData  OUT pointer to frame data.
 *
 * Return Value         : NO_ERR                    - Successful
 *                        ERR_<DESC>                - Error
 *                        ERR_OBK_NULL_POINTER      - NULL pointer input.
 *                        ERR_OBK_ADDORDER_INV_TREE - Invalid tree structure.
 *                        ERR_OBK_ADDORDER_INV_SIDE - Invalid orderbook side.
 *****************************************************************************/
ResCodeT OrdrBkModOrdr (BOOL bRcvrFlg, int32 set, pOrderT * pOldOrdr,
                        pOrderFT pNewOrdr,
                        pMModOrdrT pModOrdrAddr)
{
    BEGIN_FUNCTION ( "OrdrBkModOrdr" );
    ResCodeT rc = NO_ERR;
    pOrderT oldOrdr = NULL;
    char entTimDirty = 0, trdResDirty = 0, prcDirty = 0, ordNoDirty = 0,
        qtyDirty = 0, obssDirty = 0, remQtyDirty = 0;
    int32 oldMask, newMask, oldTrdRes, newTrdRes,prdctId, buySide;
    int32 ordrExePrc;
    SlotT oModBucket = NULL_SLOT, nModBucket = NULL_SLOT,
        slotId = NULL_SLOT, prcLderSlot = NULL_SLOT, newPrcLderSlot = NULL_SLOT;
    pOsSListEntryT pOrdNoList = NULL, pNewOrdNoList = NULL;
    pOsSListEntryT pExpTimeList = NULL, pNewExpTimeList = NULL;
    pOrder4PrcLeadT pPrcLder = NULL, pNewPrcLder = NULL;

    ASSERT( pOldOrdr && pNewOrdr );
    oldOrdr = *pOldOrdr;
    
    oldOrdr = *pOldOrdr;
    oldMask = oldOrdr->orderF.ordrMask;
    newMask = pNewOrdr->ordrMask;
    oldTrdRes = GET_ORDR_TRDRESTR(oldMask);
    newTrdRes = GET_ORDR_TRDRESTR(newMask);
    prdctId = pNewOrdr->prdctId;
    buySide = ORDR_SIDE_BUY == GET_ORDR_SIDE(oldMask);


    /* NB: change of any of the following 4 flags will result in the change of
       the order's position on the linked lists of orderbook */
    entTimDirty = oldOrdr->orderF.ordrEntTim != pNewOrdr->ordrEntTim;
    /* NB: cases for change of price leader */
    /* 1. orders with NON-FP trade restriction: price change */
    prcDirty = oldOrdr->orderF.ordrExePrc != pNewOrdr->ordrExePrc ;
    ordNoDirty = oldOrdr->orderF.ordrNo != pNewOrdr->ordrNo;
    qtyDirty = oldOrdr->orderF.ordrQty > pNewOrdr->ordrQty ||
    //oldOrdr->orderF.peakSizeQty > pNewOrdr->peakSizeQty ||
    oldOrdr->orderF.remPkQty != pNewOrdr->remPkQty ||
    (oldOrdr->orderF.ordrQty - oldOrdr->orderF.remPkQty) != (pNewOrdr->ordrQty -
    pNewOrdr->remPkQty);
    obssDirty = entTimDirty || trdResDirty || prcDirty;


    
    pOrderT pRtOrderbook = gOrdrBkShmAcs[set].pOrdrBkRoot;
    gOrdBookCtx.pPrdctCtrl = &gOrdrBkShmAcs[set].pPrdctCtrlRoot[prdctId];
    
    
    char *  pRoot = ( char *  ) pRtOrderbook;
    gOrdBookCtx.pPrcLderList = buySide ? &gOrdBookCtx.pPrdctCtrl->prcLderBuyO : &gOrdBookCtx.pPrdctCtrl->prcLderSellO;
        
        
    prcLderSlot = oldOrdr->orderT.priceLdr;
    pPrcLder = ( pOrder4PrcLeadT ) & pRtOrderbook[prcLderSlot];


    if ( !obssDirty && !ordNoDirty )
    {
        if ( qtyDirty )
        {
            RAISE_ERR ( OrdBkUpdOrdQty ( &oldOrdr->orderF, pPrcLder,
                                                pNewOrdr ), RTN );
        }
        /* change the order.... */
        memcpy ( &oldOrdr->orderF, pNewOrdr, sizeof ( OrderFT ) );
        THROW_RESCODE ( NO_ERR );
    }

    /* store frame data for roll back purpose */
    if ( prcDirty )
    {
        /* find the new price leader */
        /* if not value is set, it means it is the online process, if value is set, means it is replay, use pre-set price leader value*/
        if (!bRcvrFlg)
        {
            Order4PrcLeadT newPrcLder;
            pOrder4PrcLeadT pTmpNewPrcLder = &newPrcLder;
            INIT_ORDER_TECH_PART(pTmpNewPrcLder);
            pTmpNewPrcLder->orderT.slotNo = NULL_SLOT;
            INIT_PRC_LDER_FUNC_PART(pTmpNewPrcLder, gOrdBookCtx.pPrdctCtrl->odrBkSortingType,
                newMask, pNewOrdr->ordrExePrc, prdctId);

            listMode[PRICE_LEADER_LIST].pRoot = (char *)pRtOrderbook;
            listMode[PRICE_LEADER_LIST].pListHead = gOrdBookCtx.pPrcLderList;
            rc = FindSListEntryByKey(&listMode[PRICE_LEADER_LIST],
                &pTmpNewPrcLder->orderF.ordrPri, (void **)&pNewPrcLder);
            if (ERR_OBJ_NOT_IN_LINKED_LIST == rc)
            {
                newPrcLderSlot = NULL_SLOT;
                RAISE_ERR(OrdBkNextFreeSlot(set,&newPrcLderSlot), RTN);
                pNewPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[newPrcLderSlot];
                memcpy(pNewPrcLder, pTmpNewPrcLder, sizeof (Order4PrcLeadT));
                pNewPrcLder->orderT.slotNo = newPrcLderSlot;
                pModOrdrAddr->fNewPrcLder = 1;
            }
            else
            {
                RAISE_ERR(rc, RTN);
                newPrcLderSlot = pNewPrcLder->orderT.slotNo;
                pModOrdrAddr->fNewPrcLder = 0;
            }
        }
        else
        {
            newPrcLderSlot = pModOrdrAddr->newPrcLder;
            pNewPrcLder = ( pOrder4PrcLeadT ) & pRtOrderbook[newPrcLderSlot];
            if ( pModOrdrAddr->fNewPrcLder )
            {
                if ( CHECK_ORDR_SLOT_OPEN ( pNewPrcLder ) )
                {
                    RAISE_ERR_PARM( ERR_OBK_VECTOR_ERR, RTN,
                                        set
                                        $$ pNewPrcLder->orderF.prdctId
                                        $$ newPrcLderSlot
                                        $$ pNewPrcLder->orderT.priceLdr );
                    SET_RESCODE ( NO_ERR );
                }
                SET_ORDR_SLOT_OPEN ( pNewPrcLder );
                BitSet (gOrdrBkShmAcs[set].pOrdrBkVect, newPrcLderSlot );
                INIT_ORDER_TECH_PART ( pNewPrcLder );
                pNewPrcLder->orderT.slotNo = newPrcLderSlot;
                
                ordrExePrc = pNewOrdr->ordrExePrc;
                INIT_PRC_LDER_FUNC_PART ( pNewPrcLder,
                                            gOrdBookCtx.pPrdctCtrl->odrBkSortingType, newMask,
                                            ordrExePrc, prdctId );
            }
        }
    }
    else
    {
        /* price leader not changed, but still need to provide one! */
        newPrcLderSlot = prcLderSlot;
        pNewPrcLder = pPrcLder;
    }

                    
    if ( ordNoDirty )
    {
        
        int32 oldBucketNo = oldOrdr->orderF.ordrNo % MAX_ORD_NO_LIST_BASE;
        int32 newBucketNo = pNewOrdr->ordrNo % MAX_ORD_NO_LIST_BASE;

        pOrdNoList =
            &gOrdrBkShmAcs[set].lstInfo[ORD_NO_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + oldBucketNo];
        pNewOrdNoList =
            &gOrdrBkShmAcs[set].lstInfo[ORD_NO_LST].pRtItemSearchVct[prdctId*GET_MAX_ORDR_CNT(set) + newBucketNo];
            
        pExpTimeList =
            &gOrdrBkShmAcs[set].lstInfo[EXP_TIME_LST].pRtItemSearchVct[prdctId];

    }

    gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    INIT_REG_LIST ( gOrdBookCtx.pListRegister );
    INIT_REG_LIST ( gOrdBookCtx.pListRegister + 1 );
    
    pModOrdrAddr->oldPrcLder = prcLderSlot;
    pModOrdrAddr->newPrcLder = newPrcLderSlot;
   
    /* disconnect the order from the OBSS and other related lists. */
    RAISE_ERR ( OrdBkTechDisconnectOrder ( oldOrdr, obssDirty, ordNoDirty,
                        FALSE,FALSE,0,pPrcLder,
                        NULL, pOrdNoList, pExpTimeList, &gOrdrBkShmAcs[set],&gOrdBookCtx ), RTN );
    /*no PBU change in order modify */
    if ( obssDirty )
    {
        /* need to update inside market information . */
        RAISE_ERR ( OrdBkOrdCntQtyAdjust
                            (oldOrdr->orderF.ordrMask, oldOrdr->orderF.ordrQty,
                                oldOrdr->orderF.remPkQty, pPrcLder, 0 ,&gOrdBookCtx), RTN );

        EXECUTE_ON_COND ( RAISE_ERR ( OrdrBkFreeOrder (set, ( pOrderT * ) &pPrcLder ), RTN ),
                            pPrcLder && pNewPrcLder != pPrcLder
                            && IS_EMPTY_PRC_LDER ( pPrcLder ) );
    }

    /* connect the order to OBSS and other related lists. */
    /* change the functional part of the order */
    memcpy ( &oldOrdr->orderF, pNewOrdr, sizeof ( OrderFT ) );
    gOrdBookCtx.pListRegister = gOrdBookCtx.listRegister;
    RAISE_ERR ( OrdBkTechConnectOrder ( oldOrdr, obssDirty, ordNoDirty,
                        FALSE, FALSE,0  ,pNewPrcLder,
                        NULL, pNewOrdNoList,pExpTimeList, &gOrdrBkShmAcs[set],
                    &gOrdBookCtx ), RTN );
    if ( obssDirty )
    {
        /* need to update inside market information. */
        RAISE_ERR ( OrdBkOrdCntQtyAdjust(oldOrdr->orderF.ordrMask, oldOrdr->orderF.ordrQty,
                                oldOrdr->orderF.remPkQty,
                                pNewPrcLder, 1 , &gOrdBookCtx), RTN );
    }

    UpdateBstLstOrders ( gOrdBookCtx.pPrdctCtrl, buySide, gOrdrBkShmAcs[set].pOrdrBkRoot );

    EXIT_BLOCK();
    RETURN_RESCODE;
}  



/******************************************************************************
 * Description:   Retrieve the next price leader from the current price leader.
 *                NB: It is assumed that the Orderbook Lib Context is "set" to
 *                CNXT_FULL each time this function is called.
 *                If the input order is a time order, then the next prc ldr of
 *                it's prc ldr is returned (if existing).
 *
 * Parameters:
 *      BuySellMask     : IN  - side order is on, buy or sell.
 *      currPrcLdr      : IN  - pointer to the current price leader.
 *      nxtPrcLdr       : OUT - pointer to the next price leader.
 * Return Value         : NO_ERR     - Successful
 *                        ERR_<DESC> - Error
 *****************************************************************************/
ResCodeT GetNxtPrcLeader(int32 setId,int32 BuySellMask,
                            int32 prdctId,
                            pOrder4PrcLeadT currPrcLdr,
                            pOrder4PrcLeadT *nxtPrcLdr )
{
    BEGIN_FUNCTION("GetNxtPrcLeader");
    SlotT nxtPrcLderSlotId = NULL_SLOT;
    int32 oSide;
    char buySide;
    pOrderT pRtOrderbook;
    pPrdctCtrlT instCtrl;
    SlotT prcLderSlotId ;
    pOrder4PrcLeadT pPrcLder;
    ASSERT(nxtPrcLdr);

    THROW_RESCODE_ON_COND(ERR_OBK_NULL_POINTER, !nxtPrcLdr);

    *nxtPrcLdr = NULL;
    pRtOrderbook = gOrdrBkShmAcs[setId].pOrdrBkRoot;;
    

    if (!currPrcLdr)
    {
        oSide = GET_ORDR_SIDE(BuySellMask);

        /* Enhance the error raised */
        //THROW_RESCODE_ON_COND(ORDR_SIDE_NONE == oSide, oSide);

        buySide = ORDR_SIDE_BUY == oSide;
        instCtrl = &gOrdrBkShmAcs[setId].pPrdctCtrlRoot[prdctId];
        nxtPrcLderSlotId = buySide ? instCtrl->prcLderBuyO.next :
            instCtrl->prcLderSellO.next;
    }
    else
    {
        if (IS_PRC_LDER(currPrcLdr))
        {
            nxtPrcLderSlotId = currPrcLdr->orderT.prcLder.next;
        }
        else if (NON_NULL_SLOT(currPrcLdr->orderT.priceLdr))
        {
            /* MKT, MTL, or LMT time orders */
            prcLderSlotId = currPrcLdr->orderT.priceLdr;
            pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlotId];
            nxtPrcLderSlotId = pPrcLder->orderT.prcLder.next;
        }
        else
        {
            /* FIXED PRICE time orders */
            THROW_RESCODE(ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER);
        }
    }

    EXIT_BLOCK();
    if (NON_NULL_SLOT(nxtPrcLderSlotId))
    {
        *nxtPrcLdr = (pOrder4PrcLeadT)&pRtOrderbook[nxtPrcLderSlotId];
    }
    RETURN_RESCODE;
}/* END - GetNxtPrcLeader */


/*** SIR 30376 BEGIN ***/
/******************************************************************************
 * Description:   Retrieve the prev price leader from the current price leader.
 *                NB: It is assumed that the Orderbook Lib Context is "set" to
 *                CNXT_FULL each time this function is called.
 *                If the input order is a time order, then the prev prc ldr of
 *                it's prc ldr is returned (if existing).
 *
 * Parameters:
 *      BuySellMask     : IN  - side order is on, buy or sell.
 *      currPrcLdr      : IN  - pointer to the current price leader.
 *      prvPrcLdr       : OUT - pointer to the next price leader.
 * Return Value         : NO_ERR     - Successful
 *                        ERR_<DESC> - Error
 *****************************************************************************/
ResCodeT GetPrvPrcLeader( int32 setId,int32 BuySellMask,
                            int32 prdctId,
                            pOrder4PrcLeadT currPrcLdr,
                            pOrder4PrcLeadT *prvPrcLdr )
{
    BEGIN_FUNCTION("GetPrvPrcLeader");
    SlotT prvPrcLderSlotId = NULL_SLOT;
    pOrderT pRtOrderbook;
    int32 oSide;
    char buySide;
    pPrdctCtrlT instCtrl;
    SlotT prcLderSlotId ;
    pOrder4PrcLeadT pPrcLder;
    ASSERT(prvPrcLdr);

    THROW_RESCODE_ON_COND(ERR_OBK_NULL_POINTER, !prvPrcLdr );

    *prvPrcLdr = NULL;
    pRtOrderbook = gOrdrBkShmAcs[setId].pOrdrBkRoot;
    

    if (!currPrcLdr)
    {
        oSide = GET_ORDR_SIDE(BuySellMask);
  
        /* Enhance the error raised */

        buySide = ORDR_SIDE_BUY == oSide;
        instCtrl = &gOrdrBkShmAcs[setId].pPrdctCtrlRoot[prdctId];
        prvPrcLderSlotId = buySide ? instCtrl->prcLderBuyO.prev :
            instCtrl->prcLderSellO.prev;
    }
    else
    {
        if (IS_PRC_LDER(currPrcLdr))
        {
            prvPrcLderSlotId = currPrcLdr->orderT.prcLder.prev;
        }
        else if (NON_NULL_SLOT(currPrcLdr->orderT.priceLdr))
        {
            /* MKT, MTL, or LMT time orders */
            prcLderSlotId = currPrcLdr->orderT.priceLdr;
            pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlotId];
            prvPrcLderSlotId = pPrcLder->orderT.prcLder.prev;
        }
        else
        {
            /* FIXED PRICE time orders */
            THROW_RESCODE(ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER);
        }
    }

    EXIT_BLOCK();
    if (NON_NULL_SLOT(prvPrcLderSlotId))
    {
        *prvPrcLdr = (pOrder4PrcLeadT)&pRtOrderbook[prvPrcLderSlotId];
    }
    RETURN_RESCODE;
}/* END - GetPrvPrcLeader */

/******************************************************************************
 * Description:   check if it is need to update mktinfo
 * Parameters:
 *  set         IN  Set Id.
 * Return Value:
 *  TRUE  need to do update operation.
 *  FALSE not need.
 *****************************************************************************/
BOOL OrdBkChkUpdMktInfo( int32 setId )
{
    BEGIN_FUNCTION("OrdBkChkUpdMktInfo");
    ResCodeT        rc = NO_ERR;
    
    pVectorT pMktInfoVec = NULL;
    
    pMktInfoVec = gOrdrBkShmAcs[setId].pMktInfoUpdVect;

    for ( int i = 0; i < gNumOfPrdct; i++ )
    {
        if ( BitCheck(pMktInfoVec, i) )
        {
            return TRUE;
        }
    };
    return FALSE;
}

/******************************************************************************
 * Description:   set mkt info update vector
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
void OrdBkSetMktUpdVec( int32 setId, int32 prdctId )
{
    BEGIN_FUNCTION("OrdBkSetMktUpdVec");
    ResCodeT        rc = NO_ERR;
    
    pVectorT pMktInfoVec = NULL;
    
    pMktInfoVec = gOrdrBkShmAcs[setId].pMktInfoUpdVect;

    BitSet( pMktInfoVec, prdctId );

}

/******************************************************************************
 * Description:   reset mkt info update vector
 * Parameters:
 *  set         IN  Set Id.
 *  prdctId     IN  product id
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
void OrdBkResetMktUpdVec( int32 setId )
{
    BEGIN_FUNCTION("OrdBkResetMktUpdVec");
    ResCodeT        rc = NO_ERR;

    int vecSize = 0;
    pVectorT pMktInfoVec = NULL;

    vecSize = GET_BIT_VECT_LEN( gNumOfPrdct );

    pMktInfoVec = gOrdrBkShmAcs[setId].pMktInfoUpdVect;

    memset( pMktInfoVec, 0x00, vecSize );

}

/******************************************************************************
 * Description:   reset mkt info update vector
 * Parameters:
 *  set         IN  Set Id.
 *  pMktVec     OUT mkt info update vector
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
void OrdBkGetMktUpdVec( int32 setId, pVectorT * pMktVec, int32 * pMaxPrdctNum )
{
    BEGIN_FUNCTION("OrdBkGetMktUpdVec");
    ResCodeT        rc = NO_ERR;

    pVectorT pMktInfoVec = NULL;

    pMktInfoVec = gOrdrBkShmAcs[setId].pMktInfoUpdVect;

    *pMktVec = pMktInfoVec;

    *pMaxPrdctNum = gNumOfPrdct;
}

/* End - OrdrBkModOrdr */

/******************************************************************************
 * Description:   Find and retrieve an order (no.) from the Orderbook Search
 *                Vector based on order number.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT OrdrBkGetOrdrIterExt( int32 set, int32 prdctId, int16 ordMask, pOrderT pCurrOrdr, pOrderT *ppNextOrdr )
{
    BEGIN_FUNCTION("OrdrBkGetOrdrIterExt");
    pOrder4PrcLeadT curPrcLdr = NULL;
    pOrder4PrcLeadT nxtPrcLdr = NULL;
    ResCodeT            rc = NO_ERR;

    if (pCurrOrdr)
    {
        rc = GetNextOrder(set, prdctId, ordMask, pCurrOrdr, ppNextOrdr );
        RAISE_ERR( rc, RTN );
    }
    else
    {
        rc = GetNxtPrcLeader( set, ordMask, prdctId, curPrcLdr, &nxtPrcLdr );
        if ( rc == ERR_OBK_NO_PRICE_LDR_FOR_FIX_PRICE_ORDER )
        {
            THROW_RESCODE( NO_ERR );
        }
        RAISE_ERR(rc, RTN);

        rc = GetFrstOrdrForPrcLeader(set, prdctId, ordMask, nxtPrcLdr, ppNextOrdr );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
