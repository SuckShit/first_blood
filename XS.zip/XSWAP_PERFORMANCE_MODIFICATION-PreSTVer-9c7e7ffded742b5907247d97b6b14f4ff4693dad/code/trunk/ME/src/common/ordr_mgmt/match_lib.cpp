/***
Created on May 30, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/

#include "../include/common_macro.h"
#include "../include/prdct_info.h"
#include "../include/mem_txn_elem.h"
#include "../include/mem_txn.h"
#include "order_book.h"
#include "match_lib.h"
#include "order_type.h"
#include "order_book.h"
#include "uti_tool.h"
#include "cfg_lib.h"
#include "prdct_info.h"
#include "nmbr_srvc.h"
#include "contract_info.h"
#include "ordr_mgmt.h"
#include "common_hash.h"
#include "order_check.h"
#include "credit_mgmt.h"
#include "usr.h"
#include "usr_flg.h"
#include "org_info.h"
#include "brdg_ordr_mgmt.h"
#include "org_onln.h"
#include "trade_mgmt.h"
#include "msg_cache.h"
#include "msg_type.h"
#include "app_shl.h"
#include "perf_stat.h"
#include "active_info.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MaintFlagTag
{
    char prcModFlg;     //price modified flag
    char scopeIncrFlg;  // ordr change flag
    char mktblFlg;      // Marketable flag
    char ordrWrtblFlg;  // can be writen in order book or not
    char ordrCncl;
}MaintFlagT, *pMaintFlagT;


typedef struct MatcherAccessS {
    int32 setId;
    int32 blockOrdersNumber;              /* 主撮合器MP处理订单数 */
    float sleepTime;                    /* 主撮合器无订单空跑时间 */
    int32 maxEventsInOnePhase;            /* 主撮合器MP最大事件数 */
    int32 execRestr;                      /* 执行限制标签 */
    int32 maxOrderInAuction;             /* 集合竞价最大订单数 */
    BOOL techTraceEnable;
    int32 filler;
} MatcherAccessT;


typedef struct MaintTag
{
    BOOL partialFill;       /* 是否部分撮合 */
    char marketable;        /* 是否可以报价转市价? */
    char filler[3];
} MaintT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

static MatcherAccessT gMatcherAccess = {0}; //todo

static int64 *         gpOrdPrdctInfo = NULL; 

static cfgValueS        gCfgValue = {0};
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static ResCodeT FmtTrdInfo(int32 set, int32 prdctId, pMtchTrdT pTrade );
static ResCodeT FmtDealCnfrm( BOOL bIncCnt, pOrderT pOrder, MtchTrdT * pMtchTrd, pNewOrderSingleRspT pOrderRsp);
static ResCodeT FmtOrdCnfrm(  pOrderT pOrder, pNewOrderSingleRspT pOrderRsp, MaintFlagT * pMaintFlag, int64 tranTime);
static ResCodeT GenOrdrCnfrm( pNewOrderSingleRspT pOrderRsp, pNewOrderCnfrmT * ppOrderInfo);
static ResCodeT GenDealCnfrm( pNewOrderSingleRspT pOrderRsp, pNewDealCnfrmT * ppDealInfo);
static ResCodeT GetOrdrCnfrm( pNewOrderSingleRspT pOrderRsp, pNewOrderCnfrmT * ppOrderInfo);
static ResCodeT GetDealCnfrm( pNewOrderSingleRspT pOrderRsp, pNewDealCnfrmT * ppDealInfo);

ResCodeT MtchrGetBstOrder( int32 set, pPrdctInfoT pPrdctInfo, int16 oMask, pOrderT pIncOrdr, pOrderT *pBstOrder, pCrdtMgmtUpdtT pCrdtMgmtUpdt );
ResCodeT CreateBrdgOrdr(int32 setId, pCntrctBaseInfoT  pCntrctInfo, int64 brdgOrgPos, pOrderT pBkOrdr, int64 ordrPrc, int64 ordrQty, int64 brdgFee, pOrderT * ppBrdgOrdr);
ResCodeT SendOrdTrdToClnt( pNewOrderSingleRspT pOrderRsp);
ResCodeT MtchLogOcoOrdr(BOOL bNeedMemTxn, int32 set, int64 ocoOrdrNo, int16 ordrAct, uint16 ordSts, int32 bidCnt, pOrderT pBidOrderArr[], int32 askCnt, pOrderT pAskOrderArr[]);
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

/******************************************************************************
 * Description:   Generate order no
 * Parameters:
 *  set         IN  Set id
 *  pOrder      IN  Incoming order
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CalcTrdVal(pMtchTrdT pMtchTrd, int64 * pTrnover)
{
    BEGIN_FUNCTION("CalcTrdVal");
    ResCodeT                rc = NO_ERR;

    * pTrnover = pMtchTrd->trade.trdQty * pMtchTrd->trade.tradMtchPrc;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   create a order for the incoming request.
 * Parameters:
 *  set         IN  Set id
 *  pOrder      IN  Incoming order
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrCreateOrdrFromOrdrInfo(int32 set, NewOrderInfoT * pNewOrder, pOrderT * ppOrder, BOOL bBilOrdr, pOrdrPrcQtyInfoT pBilAskPrcQtyInfo)
{
    BEGIN_FUNCTION("MtchrCreateOrdr");
    ResCodeT                rc = NO_ERR;

    pOrderT pTempOrder = NULL;

    rc =  OrdrBkCreateOrdr(set, &pTempOrder);
    RAISE_ERR(rc, RTN);

    if (pTempOrder)
    {
        memset(&pTempOrder->orderF,0x00, sizeof(OrderFT));
        
        pTempOrder->orderF.userIdx = pNewOrder->userIdx;
        pTempOrder->orderF.prdctId = pNewOrder->contractPos;
        
        pTempOrder->orderF.remPkQty = pNewOrder->prcQtyInfo.qty;
        pTempOrder->orderF.ordrExpTim = pNewOrder->effectTime;
        
        pTempOrder->orderF.extOrdrType = pNewOrder->extOrdType;
        pTempOrder->orderF.execInst = pNewOrder->execInst;
        pTempOrder->orderF.ordAct = pNewOrder->ordAction;
        
        pTempOrder->orderF.ordrMask = ORDR_TRDRESTR_AU;
        pTempOrder->orderF.ordrMask |= ORDR_TYPE_LIMIT;
        pTempOrder->orderF.entyIdxNo =  pNewOrder->orgIdx; 
        pTempOrder->orderF.apiLoginUsrIdx =  pNewOrder->apiLoginUsrIdx; 
        pTempOrder->orderF.apiRqstId =  pNewOrder->apiRqstId; 
        pTempOrder->orderF.forceId =  pNewOrder->forceId; 
        
        if (bBilOrdr) /* bil order */
        {
            if (pBilAskPrcQtyInfo)
            {
                pTempOrder->orderF.ordrMask |= ORDR_SIDE_SELL;
                pTempOrder->orderF.ordrExePrc = pBilAskPrcQtyInfo->price;
                pTempOrder->orderF.ordrQty = pBilAskPrcQtyInfo->qty;
                pTempOrder->orderF.remPkQty = pBilAskPrcQtyInfo->qty;
            }
            else
            {
                pTempOrder->orderF.ordrMask |= ORDR_SIDE_BUY;
                pTempOrder->orderF.ordrExePrc = pNewOrder->prcQtyInfo.price;
                pTempOrder->orderF.ordrQty = pNewOrder->prcQtyInfo.qty;
            }
           
        }
        else
        {   /* normal order */
            pTempOrder->orderF.ordrMask |= pNewOrder->side;
            pTempOrder->orderF.ordrExePrc = pNewOrder->prcQtyInfo.price;
            pTempOrder->orderF.ordrQty = pNewOrder->prcQtyInfo.qty;
        }

        * ppOrder = pTempOrder;
    }
    else
    {
        RAISE_ERR(ERR_OBK_SET_ODRBK_FULL, RTN);
    }
    
    LOG_DEBUG("Prdct %d, Amt %lld, extType %d, Qty %lld", pTempOrder->orderF.prdctId, pTempOrder->orderF.remPkQty, pTempOrder->orderF.extOrdrType,
            pTempOrder->orderF.ordrQty);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   create a order for the incoming request.
 * Parameters:
 *  set         IN  Set id
 *  pOrder      IN  Incoming order
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ChkOrdrMrktble(int32 setId, pOrderT pOrder, char *mktblFlg,
                                int64 tranTime )
{
    BEGIN_FUNCTION("ChkOrdrMrktble");
    ResCodeT                rc = NO_ERR;
    int32 buySellSide;
    int32 ordrSide = GET_ORDR_SIDE(pOrder->orderF.ordrMask);
    int32 prdctId = pOrder->orderF.prdctId;
    int32 bkOrdrMask = 0;
    BstGrpT bstGrp;
    
    /* get oppsite side */
    bkOrdrMask = (ordrSide == ORDR_SIDE_BUY)? ORDR_SIDE_SELL : ORDR_SIDE_BUY;

    rc = GetBstPrc ( setId, prdctId, bkOrdrMask, &bstGrp );
    RAISE_ERR( rc, RTN );
    TRACE("Best Buy %lld - %lld, Sell %lld - %lld" $$ bstGrp.bstBuyLmtPrc
                        $$ bstGrp.bstBuyLmtPrc
                        $$ bstGrp.bstSellLmtPrc
                        $$ bstGrp.bstSellLmtQty);
    if ( !pOrder->orderF.ordrExePrc )
        /* if market order, check need M2L or not */
    {
        if ( ordrSide == ORDR_SIDE_BUY &&
                ( bstGrp.bstSellLmtQty > 0 &&
                        bstGrp.bstSellLmtPrc != 0 ||
                        bstGrp.bstSellMktQty > 0 ) ||
                        ordrSide == ORDR_SIDE_SELL &&
                ( bstGrp.bstBuyLmtQty > 0 &&
                        bstGrp.bstBuyLmtPrc != 0 || bstGrp.bstBuyMktQty > 0 ) )
        {
            *mktblFlg = WKSG_LIT_MARKETABLE;
            pOrder->orderF.ordrApplyPrc = ordrSide == ORDR_SIDE_BUY ?
                            bstGrp.bstSellLmtPrc : bstGrp.bstBuyLmtPrc;
        }
    }
    else
        /* limit order */
    {
        if ( ordrSide == ORDR_SIDE_BUY &&
                ( pOrder->orderF.ordrExePrc >= bstGrp.bstSellLmtPrc &&
                    bstGrp.bstSellLmtPrc != 0 ||
                    bstGrp.bstSellMktQty > 0 ) ||
                    ordrSide == ORDR_SIDE_SELL &&
                ( pOrder->orderF.ordrExePrc <= bstGrp.bstBuyLmtPrc &&
                    bstGrp.bstBuyLmtPrc != 0 || bstGrp.bstBuyMktQty > 0 ) )
        {
            *mktblFlg = WKSG_LIT_MARKETABLE;
        }
    }
    
    

    EXIT_BLOCK();
    RETURN_RESCODE;

}

    
/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT GetTrdResFromPrdctInfo ( pPrdctInfoT pPrdctInfo,
                            int32 * trdResMask)
{
    BEGIN_FUNCTION ( "GetTrdResFromPrdctInfo" );

    ASSERT ( order && mtchTrd && timeStamp )


    //todo
    switch ( pPrdctInfo->baseInfo.prcsSts )
    {
        case 20:
            *trdResMask |= ORDR_TRDRESTR_AU;
            break;

        default:
            break;
    }

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}


    
/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static void PopTrdFromOrdr ( pOrderT order,
                            pOrderT pBkOrdr,
                            MtchTrdT * mtchTrd,
                            int64 timeStamp )
{
    BEGIN_FUNCTION ( "PopTrdFromOrdr" );

    ASSERT ( order && mtchTrd && timeStamp )
    mtchTrd->trade.tranDatTim = timeStamp;
    mtchTrd->trade.ordrExePrc = order->orderF.ordrExePrc;
    mtchTrd->trade.ordrNo = order->orderF.ordrNo;
    mtchTrd->trade.ordrMask = order->orderF.ordrMask;

    mtchTrd->trade.ordrExeQty = order->orderF.ordrExeQty;
    mtchTrd->trade.prdctId = order->orderF.prdctId;

    //todo

    EXIT_BLOCK (  );
}


/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT CnclRltOcoOrdr( int32 setId, pOrderT pBkOrdr,int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "CnclRltOcoOrdr" );
    ResCodeT rc = NO_ERR;
    
    pOrdrMgmtRcrdT  pOcoOrdrMgmt = NULL;
    pOrderT         pCnclOrder = NULL;
    int64           iter = -1;
   
    
    rc = OrdrMgmtOcoGet(setId, pBkOrdr->orderF.specOrdrNo,&pOcoOrdrMgmt, &pCnclOrder, &iter);
    RAISE_ERR( rc, RTN );

    do
    {
        if (pBkOrdr->orderF.ordrNo != pCnclOrder->orderF.ordrNo)
        {
            pCnclOrder->orderF.specOrdrNo = 0;
            pCnclOrder->orderF.extOrdrType = EXT_ORD_TYPE_NORMAL;

            rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_FREEZE, pCnclOrder, timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN);
        }

        rc = OrdrMgmtOcoGetNext(setId, pOcoOrdrMgmt, &pCnclOrder, &iter);
        if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
        {
            RAISE_ERR(rc, RTN);
        }
        else
        {
            break;
        }
    } while (TRUE);

    rc = MtchLogOcoOrdr(TRUE, setId, pBkOrdr->orderF.specOrdrNo, ACTN_CNCL_CMD, ORDR_STS_CANCEL, 0, NULL, 0, NULL);
    RAISE_ERR(rc, RTN); 

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT CnclRltBilOrdr( int32 setId, pOrderT pBkOrdr,int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "CnclRltBilOrdr" );
    ResCodeT rc = NO_ERR;
    
    pOrdrMgmtRcrdT  pBilOrdrMgmt = NULL;
    pOrderT         pCnclBidOrder = NULL, pCnclAskOrder = NULL;
    uint32           ordrMgmtPos = -1;
   
    rc = OrdrMgmtBilGet(setId, pBkOrdr->orderF.specOrdrNo, &pBilOrdrMgmt, &pCnclBidOrder, &pCnclAskOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );
    
    if (pBkOrdr->orderF.ordrNo == pCnclBidOrder->orderF.ordrNo)
    {
        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pCnclAskOrder, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pCnclBidOrder, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT CnclRltOrdr( int32 setId, pOrderT pBkOrdr, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "CnclRltOrdr" );
    ResCodeT rc = NO_ERR;

    switch(pBkOrdr->orderF.extOrdrType)
    {
        case EXT_ORD_TYPE_OCO:
            rc = CnclRltOcoOrdr(setId, pBkOrdr, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;
            
        case EXT_ORD_TYPE_BIL:
            rc = CnclRltBilOrdr(setId, pBkOrdr, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;     
        
        default:
            break;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT PartialMtch ( int32 setId, MtchTrdT * pMtchTrd,
                                pPrdctInfoT pPrdctInfo,
                                pOrderT pIncOrdr,
                                pOrderT pBkOrdr,
                                int64 timeStamp,
                                int64 ordrNoOld,
                                pCrdtMgmtUpdtT pCrdtMgmtUpdt,
                                pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "PartialMtch" );
    ResCodeT rc;
    uint16 actnMask;
    OrderT hldgOrdr;
    OrderT hldgInOrdr;
    MtchInfoT mtchInfo;
    int64 tmpQty;
    MaintFlagT  maintFlag;
    uint32 ordrMgmtPos;
    int32 bkOrdEntyIdxNo = 0;
    TradeDatT       tradeDat;
    uint32           tradePos;

    ASSERT ( pIncOrdr && pBkOrdr && pMtchTrd && timeStamp && pPrdctInfo )

    bkOrdEntyIdxNo = pBkOrdr->orderF.entyIdxNo;

    int32 prdctId = pIncOrdr->orderF.prdctId;
    tmpQty = pBkOrdr->orderF.ordrQty;
    pIncOrdr->orderF.ordrExeQty += tmpQty;
    pIncOrdr->orderF.ordrQty -= tmpQty;

    /* Input order field */
    pMtchTrd->trade.ordrPrtFilCod = WKSG_LIT_YES;

    PopTrdFromOrdr ( pIncOrdr, pBkOrdr, pMtchTrd, timeStamp );

    actnMask = ACTN_BOOK_CMD | ACTN_PRT_FIL_MNT | ACTN_AUD_YES |
        ACTN_CONF_NO | ACTN_ORDR_BK_NO;
        
    FmtDealCnfrm( FALSE, pBkOrdr, pMtchTrd, pOrderRsp);

    rc = MtchLogTrd(TRUE,  setId, actnMask,ordrNoOld, pMtchTrd);
    RAISE_ERR( rc, RTN );
    
    if (GET_ORDR_SIDE(pMtchTrd->trade.ordrMask) == ORDR_SIDE_BUY) 
    {
        memcpy(&tradeDat.bidTrd, &pMtchTrd->trade, sizeof(TradeT));
    }
    else
    {
        memcpy(&tradeDat.askTrd, &pMtchTrd->trade, sizeof(TradeT));
    }

    /* 由输入订单记录撮合信息 */
    mtchInfo.ordrNoOld = pIncOrdr->orderF.ordrNo;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_PRT_FIL;
    mtchInfo.tradePrc = pMtchTrd->trade.tradMtchPrc;

    actnMask = ACTN_ADD_CMD | ACTN_PRT_FIL_MNT | ACTN_AUD_YES |
                ACTN_CONF_NO | ACTN_ORDR_BK_NO;
    
    pIncOrdr->orderF.ordrSts = ORDR_STS_ACTIVE;
    
    if (GET_ORDR_TYPE(pIncOrdr->orderF.ordrMask) == ORDR_TYPE_MKTOL)
    {
        OrderT tmpOrdr;
        memcpy(&tmpOrdr, pIncOrdr, sizeof (OrderT));
        tmpOrdr.orderF.ordrExePrc = pMtchTrd->trade.tradMtchPrc;
        
        rc = MtchLogOrdr(TRUE, setId , actnMask, &tmpOrdr, &mtchInfo);
    }
    else
    {
        
        rc = MtchLogOrdr(TRUE, setId , actnMask, pIncOrdr, &mtchInfo);
    }

    RAISE_ERR(rc, RTN);
    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
                ACTN_CONF_NO | ACTN_ORDR_BK_NO;

    pBkOrdr->orderF.ordrExeQty += pBkOrdr->orderF.ordrQty;
    pBkOrdr->orderF.ordrQty = 0;
    pBkOrdr->orderF.tranTime = timeStamp;

    pMtchTrd->trade.ordrPrtFilCod = WKSG_LIT_NO;

    PopTrdFromOrdr( pBkOrdr, pIncOrdr, pMtchTrd, timeStamp );
    
    FmtDealCnfrm( TRUE, pIncOrdr, pMtchTrd, pOrderRsp);
    
    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_MARKETABLE;
        
    FmtOrdCnfrm( pBkOrdr, pOrderRsp, &maintFlag, timeStamp );

    mtchInfo.ordrNoOld = pBkOrdr->orderF.ordrNo;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_FULL_MTCH;
    mtchInfo.tradePrc = pMtchTrd->trade.tradMtchPrc;

    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_YES |
                ACTN_CONF_NO | ACTN_ORDR_BK_YES;              

    pBkOrdr->orderF.ordrSts = ORDR_STS_DEAL;
    /* Delete order after matching */
    rc = MtchDelOrdr(TRUE, setId, &pBkOrdr,
                    timeStamp,
                    actnMask,
                    &mtchInfo,
                    pPrdctInfo,
                    TRUE);
    RAISE_ERR(rc, RTN);

    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
                ACTN_CONF_NO | ACTN_ORDR_BK_NO;

    rc = MtchLogTrd(TRUE,  setId, actnMask,0, pMtchTrd);
    RAISE_ERR( rc, RTN );

    if ( !pBkOrdr->orderF.ordrQty && (pIncOrdr->orderF.extOrdrType != EXT_ORD_TYPE_BRDG) )
    {
        rc = CnclRltOrdr ( setId, pBkOrdr,timeStamp, pOrderRsp);
        RAISE_ERR( rc, RTN );
    }

    /* Add deal */
    tradeDat.trdKey.trdNo = pMtchTrd->trade.tranIdNo;
    rc = TradeAdd(setId, &tradeDat, &tradePos);
    RAISE_ERR( rc, RTN );
    
    PerfStatInc(MDealEntry);

    pPrdctInfo->baseInfo.totTrdQty += tmpQty;

    /* update credit */
    rc = MtchUpdCrdtByTrd(TRUE, setId,pCrdtMgmtUpdt);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   perform full matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT FullMtch(int32 set, MtchTrdT  *pMtchTrd,
                            pPrdctInfoT pPrdctInfo,
                            pOrderT pIncOrdr,
                            pOrderT pBkOrdr,
                            int64 timeStamp,
                            int64 ordrNoOld,
                            pCrdtMgmtUpdtT pCrdtMgmtUpdt,
                            pNewOrderSingleRspT pOrderRsp)
{

    BEGIN_FUNCTION("FullMtch");
    ResCodeT        rc;
    uint16          actnMask;
    OrderT          hldgOrdr;
    int64           exeQty;
    MtchInfoT       mtchInfo;
    MaintFlagT      maintFlag;
    int64           ordrMgmtPos;
    int32           bkOrdEntyIdxNo = 0;
    TradeDatT       tradeDat;
    uint32           tradePos;

    ASSERT(pIncOrdr && pBkOrdr && pMtchTrd && timeStamp && pPrdctInfo)

    bkOrdEntyIdxNo = pBkOrdr->orderF.entyIdxNo;

    /* update input order field */
    exeQty                       = pIncOrdr->orderF.ordrQty;
    pIncOrdr->orderF.ordrExeQty += pIncOrdr->orderF.ordrQty;
    pIncOrdr->orderF.ordrQty     = 0;
    //pIncOrdr->orderF.remPkQty    = 0;


    pMtchTrd->trade.ordrPrtFilCod = WKSG_LIT_NO;
    PopTrdFromOrdr(pIncOrdr, pBkOrdr, pMtchTrd, timeStamp);


    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
                ACTN_CONF_NO | ACTN_ORDR_BK_NO;



    rc = MtchLogTrd(TRUE,  set, actnMask,ordrNoOld, pMtchTrd);
    RAISE_ERR( rc, RTN );
    
    if (GET_ORDR_SIDE(pMtchTrd->trade.ordrMask) == ORDR_SIDE_BUY) 
    {
        memcpy(&tradeDat.bidTrd, &pMtchTrd->trade, sizeof(TradeT));
    }
    else
    {
        memcpy(&tradeDat.askTrd, &pMtchTrd->trade, sizeof(TradeT));
    }
    
    /* format deal response*/
    FmtDealCnfrm( FALSE, pBkOrdr, pMtchTrd, pOrderRsp);

    /*write the trade into the working page*/
    memcpy(&hldgOrdr, pBkOrdr, sizeof (OrderT));

    if ( pBkOrdr->orderF.ordrQty == exeQty)
    /* full mathed of order book order */
    {
        OrderT tmpOrder;
        memcpy(&tmpOrder, pBkOrdr, sizeof (OrderFT));
        tmpOrder.orderF.ordrExeQty = exeQty;
        tmpOrder.orderF.ordrQty = tmpOrder.orderF.remPkQty = 0;
        tmpOrder.orderF.tranTime = timeStamp;

        pMtchTrd->trade.ordrPrtFilCod = WKSG_LIT_NO;

        PopTrdFromOrdr(&tmpOrder, pIncOrdr, pMtchTrd, timeStamp);
        
        FmtDealCnfrm( TRUE, pIncOrdr, pMtchTrd, pOrderRsp);
        
        maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
        maintFlag.mktblFlg = WKSG_LIT_MARKETABLE;
            
        FmtOrdCnfrm( &tmpOrder, pOrderRsp, &maintFlag, timeStamp );

        /*fill rltrade with pBkOrdr*/
        mtchInfo.ordrNoOld = pBkOrdr->orderF.ordrNo;
        mtchInfo.ordrPrtFilCod = MTCH_TYPE_FULL_MTCH;

        mtchInfo.tradePrc = pMtchTrd->trade.tradMtchPrc; 

        pBkOrdr->orderF.ordrQty -= exeQty;
        pBkOrdr->orderF.ordrExeQty += exeQty;
        pBkOrdr->orderF.ordrSts = ORDR_STS_DEAL;
        
        actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_YES |
                    ACTN_CONF_NO | ACTN_ORDR_BK_YES;
        /* Delete order after full matching */
        rc = MtchDelOrdr(TRUE, set, &pBkOrdr,
                        timeStamp,
                        actnMask,
                        &mtchInfo,
                        pPrdctInfo,
                        TRUE);
        RAISE_ERR(rc, RTN);

        /* log trade into memory txn */
        actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
                    ACTN_CONF_NO | ACTN_ORDR_BK_NO;
        rc = MtchLogTrd(TRUE,  set, actnMask,0, pMtchTrd);
        RAISE_ERR( rc, RTN );
        
        if (GET_ORDR_SIDE(pMtchTrd->trade.ordrMask) == ORDR_SIDE_BUY) 
        {
            memcpy(&tradeDat.bidTrd, &pMtchTrd->trade, sizeof(TradeT));
        }
        else
        {
            memcpy(&tradeDat.askTrd, &pMtchTrd->trade, sizeof(TradeT));
        }

        if ( !pBkOrdr->orderF.ordrQty && (pIncOrdr->orderF.extOrdrType != EXT_ORD_TYPE_BRDG) )
        {
            rc = CnclRltOrdr ( set, pBkOrdr, timeStamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
        }

    }   /*end if full mathing of order book order */
    else  /* input order full mathed, order book order partial matched */
    {
        /* update date order book */

        actnMask = ACTN_BOOK_CMD | ACTN_PRT_FIL_MNT | ACTN_AUD_YES |
                    ACTN_CONF_NO  | ACTN_ORDR_BK_YES;
        /* partial match, update order book qty */
        rc = MtchModOrdrQty(TRUE, set, pBkOrdr,
                        exeQty,
                        pMtchTrd->trade.tradMtchPrc,
                        timeStamp,
                        actnMask);
        RAISE_ERR(rc, RTN);

        pMtchTrd->trade.ordrPrtFilCod = WKSG_LIT_YES;

        PopTrdFromOrdr(pBkOrdr, pIncOrdr, pMtchTrd, timeStamp);
        
        FmtDealCnfrm( TRUE, pIncOrdr, pMtchTrd, pOrderRsp);
        
        maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
        maintFlag.mktblFlg = WKSG_LIT_MARKETABLE;

        FmtOrdCnfrm( pBkOrdr, pOrderRsp, &maintFlag, timeStamp );

        actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
                    ACTN_CONF_NO | ACTN_ORDR_BK_NO;

        rc = MtchLogTrd(TRUE,  set, actnMask,0, pMtchTrd);
        RAISE_ERR( rc, RTN );
    } /*end if partial matched of order book order */
    
    /* Trade Add */
    tradeDat.trdKey.trdNo = pMtchTrd->trade.tranIdNo;
    rc = TradeAdd(set, &tradeDat, &tradePos);
    RAISE_ERR( rc, RTN );
    
    PerfStatInc(MDealEntry);

    pPrdctInfo->baseInfo.totTrdQty += exeQty;
    
    //update credit data
    rc = MtchUpdCrdtByTrd(TRUE, set,pCrdtMgmtUpdt);
    RAISE_ERR( rc, RTN );


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   create a order for the incoming request.
 * Parameters:
 *  bkSide          IN  Order bookside
 *  pIncOrdr        IN  Incoming order
 *  pBkOrdr         IN  order book order
 *  ordrNoOld       IN  old order number
 *  pPrdctInfo      OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static void CalcPotExecPrc ( int32 set, uint16 bkSide,
                                pOrderT pIncOrdr,
                                pOrderT pBkOrdr,
                                HoldT * hold,
                                pMtchTrdT pMtchTrd,
                                pPrdctInfoT pPrdctInfo)
{

    BEGIN_FUNCTION ( "CalcPotExecPrc" );
    BstGrpT bstGrp;

    /* Get best order group */
    GetBstGrp( set, pIncOrdr->orderF.prdctId, ORDR_TRDRESTR_NO | ORDR_SIDE_NONE,
                &bstGrp );

    ASSERT ( pIncOrdr && pBkOrdr && hold && pMtchTrd && pPrdctInfo )

    pMtchTrd->trade.tradMtchPrc = pBkOrdr->orderF.ordrExePrc;
    if ( bkSide == ORDR_SIDE_BUY )
    {
        hold->bstBkPrc = bstGrp.bstBuyLmtPrc;
        hold->mktQty = bstGrp.bstBuyMktQty;
    }
    else
    {
        hold->bstBkPrc = bstGrp.bstSellLmtPrc;
        hold->mktQty = bstGrp.bstSellMktQty;
    }

    /* input order mathing with market order in orderbook
    *  consider 2 prices
    *  1: last trade price
    *  2. best order price in orderbook
    */
    if (GET_ORDR_TYPE(pIncOrdr->orderF.ordrMask) == ORDR_TYPE_MARKT &&
        hold->mktQty > 0)
    /* market vs market */
    {
        /* has limit order in order book */
        if (hold->bstBkPrc)
        {
            if (bkSide == ORDR_SIDE_SELL)
            {

                pMtchTrd->trade.tradMtchPrc =
                    pPrdctInfo->baseInfo.lstTrdPrc < hold->bstBkPrc
                    ? pPrdctInfo->baseInfo.lstTrdPrc : hold->bstBkPrc;
                /* Sell: min(last trade price, best order book price)*/
            }
            else    /*bkSide = buy*/
            {
                pMtchTrd->trade.tradMtchPrc =
                    pPrdctInfo->baseInfo.lstTrdPrc < hold->bstBkPrc
                    ? hold->bstBkPrc : pPrdctInfo->baseInfo.lstTrdPrc;
                /* Buy: max(last trade price, best order book price)*/
            }
        }
        else   /* only market order in order book */
        {
            pMtchTrd->trade.tradMtchPrc = pPrdctInfo->baseInfo.lstTrdPrc;
            /* Use last trade price */
        }
        return;
    }   /* market vs market done */


    /* input order mathing with non-market order in orderbook
    *  consider 3 prices
    *  1. last trade price
    *  2. best order price in orderbook
    *  3. input order limit price
    */

    if (GET_ORDR_TYPE(pIncOrdr->orderF.ordrMask) != ORDR_TYPE_MARKT &&
        hold->mktQty > 0)
    /* Limit vs Market*/
    {
        if (bkSide == ORDR_SIDE_SELL) /* pIncOrdr->ordBuyCod == WKSG_LIT_BUY */
        {
            /* no limit order in order book */
            if (!hold->bstBkPrc)
            {
                pMtchTrd->trade.tradMtchPrc =
                    pIncOrdr->orderF.ordrExePrc < pPrdctInfo->baseInfo.lstTrdPrc
                    ? pIncOrdr->orderF.ordrExePrc : pPrdctInfo->baseInfo.lstTrdPrc;
                 /* min(last trade price, order price) */
            }
            else    /* there is limit order in order book, min(limit order price, last trade price, best order book price)*/
            {
                pMtchTrd->trade.tradMtchPrc = MIN(MIN(pIncOrdr->orderF.ordrExePrc,
                                                pPrdctInfo->baseInfo.lstTrdPrc),
                                                hold->bstBkPrc);
            }
        }   /*end if bkSide == ORDR_SIDE_SELL*/
        else        /*bkSdie = BUY*/
        {
            if (!hold->bstBkPrc)    /* 订单簿中无限价订单 */
            {
                pMtchTrd->trade.tradMtchPrc =
                    pIncOrdr->orderF.ordrExePrc < pPrdctInfo->baseInfo.lstTrdPrc
                    ? pPrdctInfo->baseInfo.lstTrdPrc : pIncOrdr->orderF.ordrExePrc;
                    /* max(last trade price, order price) */
            }
            else   /* max(limit order price, last trade price, best order book price)*/
            {
                pMtchTrd->trade.tradMtchPrc = MAX(MAX(pIncOrdr->orderF.ordrExePrc,
                                            pPrdctInfo->baseInfo.lstTrdPrc),
                                            hold->bstBkPrc);
            }   /*end else consider limit order prc*/

        }   /*end bkSide BUY*/
    }   /*limit vs market over*/
    EXIT_BLOCK();
}


    
/******************************************************************************
 * Description:   perform partial matching
 * Parameters:
 *  set         IN  Set id
 *  pMtchTrd    IN  trade info
 *  ppOrder     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT CheckBestOrdrExt( pOrderT pInOrder, pOrderT pBkOrder, BOOL* pIsChkOK)
{
    BEGIN_FUNCTION ( "CheckBestOrdrExt" );
    
    * pIsChkOK = TRUE;
    
    if ((pInOrder->orderF.specOrdrNo ==  pBkOrder->orderF.specOrdrNo) && 
            (pInOrder->orderF.extOrdrType == EXT_ORD_TYPE_BIL))
    {
        //THROW_RESCODE(ERR_CODE_INVLD_ORDER_ACTION);
        * pIsChkOK = FALSE;
        THROW_RESCODE(NO_ERR);
    }

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   create a order for the incoming request.
 * Parameters:
 *  set             IN  Set id
 *  pIncOrdr        IN  Incoming order
 *  pPrdctInfo      IN  prdct infomation
 *  ordrNoOld       IN  old order number
 *  pPrdctInfo     OUT output order address.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT PerformMtchg ( int32 set,
                        pOrderT pIncOrdr,
                        pPrdctInfoT pPrdctInfo,
                        uint64 ordrNoOld,
                        int64 timeStamp,
                        pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "PerformMtchg" );
    ResCodeT rc = NO_ERR;

    uint16 bkSide = 0;
    int32 tempMask = 0, trdResMask = 0;
    MaintT maint;
    HoldT hold = { 0 };
    pOrderT pBkOrdr;
    MtchTrdT mtchTrd;
    int64 tmpQty;
    int64 tmpTrnover;
    int32 currentMktDepth;
    int64 crntPrc, lstPrc;
    CrdtMgmtUpdtT  crdtUpdInfo = {0};


    int32 prdctId = pIncOrdr->orderF.prdctId;

    /* Set trade information */
    memset ( &mtchTrd, 0x00, sizeof ( MtchTrdT ) );

    rc = FmtTrdInfo(set, prdctId, &mtchTrd);
    RAISE_ERR( rc, RTN );

    bkSide = ORDR_SIDE_SELL ^ GET_ORDR_SIDE(pIncOrdr->orderF.ordrMask);


    hold.trnover = 0;
    maint.partialFill = TRUE;
    maint.marketable = WKSG_LIT_MARKETABLE;

    /* get best order */
    rc = GetTrdResFromPrdctInfo(pPrdctInfo, &trdResMask);
    RAISE_ERR( rc, RTN );

    tempMask = bkSide | trdResMask;
    crdtUpdInfo.prdctPos = pPrdctInfo->pos;
    rc = MtchrGetBstOrder( set, pPrdctInfo, tempMask, pIncOrdr, &pBkOrdr, &crdtUpdInfo );
    RAISE_ERR( rc, RTN );

    currentMktDepth = 1;

    if ( pBkOrdr )
    {
        lstPrc = crntPrc = pBkOrdr->orderF.ordrExePrc;

        while ( maint.partialFill && maint.marketable == WKSG_LIT_MARKETABLE )
        {

            mtchTrd.trade.trdSts = DEAL_STS_OK;
            
            /* Calculate trade price */
            if (pPrdctInfo->baseInfo.prcsSts == PROD_STAT_TRADE)
            /* Continuse Matching */
            {
                CalcPotExecPrc(set, bkSide,
                                pIncOrdr,
                                pBkOrdr,
                                &hold,
                                &mtchTrd,
                                pPrdctInfo);
            }
            else /* OBB */
            {
                /* OBB open price is the trade price */
                mtchTrd.trade.tradMtchPrc = pPrdctInfo->baseInfo.auctOpenPrc;

            }

            pIncOrdr->orderF.ordrMtchPrc = mtchTrd.trade.tradMtchPrc;
            pBkOrdr->orderF.ordrMtchPrc = mtchTrd.trade.tradMtchPrc;


            /* check the market data price info */
            if (mtchTrd.trade.tradMtchPrc > pPrdctInfo->baseInfo.dlyHghPrc)
            {
                pPrdctInfo->baseInfo.dlyHghPrc = mtchTrd.trade.tradMtchPrc;
            }
            if ( !pPrdctInfo->baseInfo.dlyLowPrc ||
                mtchTrd.trade.tradMtchPrc < pPrdctInfo->baseInfo.dlyLowPrc)
            {
                pPrdctInfo->baseInfo.dlyLowPrc = mtchTrd.trade.tradMtchPrc;
            }

            /* Generate trade no */
            rc = NmbrSrvcGenNo(set, NMBR_TYPE_TRD, &mtchTrd.trade.tranIdNo);
            RAISE_ERR(rc, RTN);

            /* matching qty */
            tmpQty = pBkOrdr->orderF.ordrQty;

            /* Partial matching */
            if ( tmpQty < pIncOrdr->orderF.ordrQty )
            {
                /* actual matching qty */
                mtchTrd.trade.trdQty = tmpQty;

                hold.totalTrdQty += tmpQty;
                /* total matching trade */
                hold.totalNumOfTrd++;
                /* perform partial matching */
                rc = PartialMtch (set,  &mtchTrd, pPrdctInfo, pIncOrdr,
                                    pBkOrdr, timeStamp, ordrNoOld,&crdtUpdInfo,pOrderRsp );
                RAISE_ERR( rc, RTN );
            }
            else                /*Fully Mathing with order book order */
            {
                /* actual matching qty */
                mtchTrd.trade.trdQty = pIncOrdr->orderF.ordrQty;
                hold.totalTrdQty += pIncOrdr->orderF.ordrQty;
                hold.totalNumOfTrd++;
                /* perform full matching */
                rc = FullMtch ( set, &mtchTrd, pPrdctInfo,
                                pIncOrdr, pBkOrdr, timeStamp, ordrNoOld,&crdtUpdInfo ,pOrderRsp);
                RAISE_ERR( rc, RTN );

                maint.partialFill = FALSE;
            }

            /* Calculate trade value */
            //todo need check the data number is overflow or not
           //tmpTrnover = MULT ( mtchTrd.trade.tradMtchPrc, 5, mtchTrd.trade.trdQty, 3, 5 );
            CalcTrdVal(&mtchTrd, &tmpTrnover);

            if ( tmpTrnover > 0 )
            {
                hold.trnover += tmpTrnover;
            }
            else
            {
                hold.trnover = tmpTrnover * 10;
            }

            /*TRADE, update market data */
            pPrdctInfo->baseInfo.lstTrdDatTim = timeStamp;
            pPrdctInfo->baseInfo.lstUpdateTim = timeStamp;
            pPrdctInfo->baseInfo.lstTrdPrc = mtchTrd.trade.tradMtchPrc;
            pPrdctInfo->baseInfo.lstTrdQty = mtchTrd.trade.trdQty;
            if ( !pPrdctInfo->baseInfo.opnPrc )
            {
                /* if opening price is 0, use the first matched price */
                pPrdctInfo->baseInfo.opnPrc = pPrdctInfo->baseInfo.lstTrdPrc;
            }

            /*TRADE, update for calc weight price */
            UpdWghtPrcAndQty( pPrdctInfo, mtchTrd.trade.tradMtchPrc, mtchTrd.trade.trdQty );

            if ( maint.partialFill )   /* still let some qty need to be matched. */
            {
                /* get another best order */
                rc = MtchrGetBstOrder( set, pPrdctInfo, tempMask, pIncOrdr, &pBkOrdr, &crdtUpdInfo );
                RAISE_ERR( rc, RTN );
                if ( pBkOrdr )
                {
                    /* check marketable or not */
                    rc = ChkOrdrMrktble (set, pIncOrdr, &maint.marketable,
                                                timeStamp );
                    RAISE_ERR( rc, RTN );
                    crntPrc = pBkOrdr->orderF.ordrExePrc;
                    /* if the market order or M2L order, need to check the allow market depth */
                    if ( !pIncOrdr->orderF.ordrExePrc && crntPrc != lstPrc )
                    {
                        currentMktDepth++;
                        lstPrc = crntPrc;
                        //todo get market depth
                        if ( currentMktDepth > 5 )
                        {
                            maint.marketable = WKSG_LIT_NO;
                        }
                    }
                }
                else
                {
                    maint.marketable = WKSG_LIT_NO;
                }
            }/*end if partial match */
        }/*end while partialFill and marketable */

        /* update MTOL order to last trading price */
        if ( GET_ORDR_TYPE(pIncOrdr->orderF.ordrMask) == ORDR_TYPE_MKTOL)
        {
            pIncOrdr->orderF.ordrExePrc = mtchTrd.trade.tradMtchPrc;
        }
    }/*end if (pBkOrdr) */

    EXIT_BLOCK (  );
    if (hold.trnover)
    {
        //todo , WrapUpTrd(&hold, &mtchTrd, pPrdctInfo);
        pPrdctInfo->baseInfo.lstTrdDatTim = timeStamp;
        
        rc = MtchUpdtPrdctInfo(TRUE,pPrdctInfo->pos, &pPrdctInfo->baseInfo);
        RAISE_ERR(rc, RTN);
    }
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pPrdctInfo  IN  product info
 *  pOrder      IN  Incoming order
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT ChkOrdrWritable ( pPrdctInfoT pPrdctInfo, pOrderT pOrder,
                                        MaintFlagT * pMaintFlag )
{
    BEGIN_FUNCTION ( "ChkOrdrWritable" );
    ResCodeT rc = NO_ERR;
    uint16 ordrExeRestrMask = 0;
    uint16 ordrTypeMask = 0;

    SECTION ( "ChkOrdrWritable" );
    ASSERT (  pOrder && pMaintFlag )


    pMaintFlag->ordrWrtblFlg = WKSG_LIT_YES;


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT FmtTrdInfo(int32 set, int32 prdctId, pMtchTrdT pTrade )
{
    BEGIN_FUNCTION ( "FmtTrdInfo" );
    ResCodeT rc = NO_ERR;
    ASSERT (  pOrder && pMaintFlag )
    
    pTrade->trade.prdctId = prdctId;
    //todo

    EXIT_BLOCK();
    RETURN_RESCODE;
}





/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT GenOrdrCnfrm( pNewOrderSingleRspT pOrderRsp, pNewOrderCnfrmT * ppOrderInfo)
{
    BEGIN_FUNCTION ( "GenOrdrCnfrm" );
    ResCodeT rc = NO_ERR;

    SlotT slotId;
    pMsgCacheSlotT  pReqSlot;
    
    if ( pOrderRsp->slotCnt >= MAX_RSP_SLOT_CNT)
    {
        LOG_DEBUG("response slot cnt exceed %ld", pOrderRsp->slotCnt);
        RAISE_ERR(ERR_OBK_SET_ODRBK_FULL, RTN);
    }
    LOG_DEBUG("Reserv Slot in GenOrdrCnfrm");
    rc = MsgRsrvSlot(&slotId, &pReqSlot);
    RAISE_ERR( rc, RTN );
    
    *ppOrderInfo = (pNewOrderCnfrmT)&pReqSlot->msgBody;
    
    (*ppOrderInfo)->cnfrmCnt = 0;
    (*ppOrderInfo)->cnfrmType = CNFRM_TYPE_ORDR;
    
    pOrderRsp->currOrdrSlot = slotId;
    pOrderRsp->rspSlot[pOrderRsp->slotCnt] = slotId;
    
    pOrderRsp->slotCnt ++;
     
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT GetOrdrCnfrm( pNewOrderSingleRspT pOrderRsp, pNewOrderCnfrmT * ppOrderInfo)
{
    BEGIN_FUNCTION ( "GetOrdrCnfrm" );
    ResCodeT rc = NO_ERR;
    
    SlotT slotId;
    pMsgCacheSlotT  pReqSlot;
    
    if (pOrderRsp->currOrdrSlot == -1)
    {
        rc = GenOrdrCnfrm(pOrderRsp, ppOrderInfo);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        slotId = pOrderRsp->currOrdrSlot;
    
        rc = MsgGetSlot(slotId, &pReqSlot);
        RAISE_ERR(rc, RTN);
        
        *ppOrderInfo = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
        if ((*ppOrderInfo)->cnfrmCnt >= (MAX_ORDR_SLOT_CNT-1))
        {
            rc = GenOrdrCnfrm(pOrderRsp,ppOrderInfo);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT GetDealCnfrm( pNewOrderSingleRspT pOrderRsp, pNewDealCnfrmT * ppDealInfo)
{
    BEGIN_FUNCTION ( "GetDealCnfrm" );
    ResCodeT rc = NO_ERR;
   
    SlotT slotId;
    pMsgCacheSlotT  pReqSlot;
    
    if (pOrderRsp->currDealSlot == -1)
    {
        rc = GenDealCnfrm(pOrderRsp, ppDealInfo);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        slotId = pOrderRsp->currDealSlot;
    
        rc = MsgGetSlot(slotId, &pReqSlot);
        RAISE_ERR(rc, RTN);
        
        *ppDealInfo = (pNewDealCnfrmT)&pReqSlot->msgBody;
        
        if ((*ppDealInfo)->cnfrmCnt >= (MAX_DEAL_SLOT_CNT-1))
        {
            rc = GenDealCnfrm(pOrderRsp,ppDealInfo);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT GenDealCnfrm( pNewOrderSingleRspT pOrderRsp, pNewDealCnfrmT * ppDealInfo)
{
    BEGIN_FUNCTION ( "GenDealCnfrm" );
    ResCodeT rc = NO_ERR;

    SlotT slotId;
    pMsgCacheSlotT  pReqSlot;
    
    if ( pOrderRsp->slotCnt >= MAX_RSP_SLOT_CNT)
    {
        LOG_DEBUG("response slot cnt exceed %ld", pOrderRsp->slotCnt);
        RAISE_ERR(ERR_OBK_SET_ODRBK_FULL, RTN);
    }
    LOG_DEBUG("Reserv Slot in GenDealCnfrm");
    rc = MsgRsrvSlot(&slotId, &pReqSlot);
    RAISE_ERR( rc, RTN );
    
    *ppDealInfo = (pNewDealCnfrmT)&pReqSlot->msgBody;
    
    (*ppDealInfo)->cnfrmCnt = 0;
    (*ppDealInfo)->cnfrmType = CNFRM_TYPE_DEAL;
    
    pOrderRsp->currDealSlot = slotId;
    pOrderRsp->rspSlot[pOrderRsp->slotCnt] = slotId;
    
    pOrderRsp->slotCnt ++;
     
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT FmtDealCnfrm( BOOL bIncCnt, pOrderT pOrder, MtchTrdT * pMtchTrd, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "FmtDealCnfrm" );
    ResCodeT rc = NO_ERR;
    int16 oSide =  GET_ORDR_SIDE(pOrder->orderF.ordrMask);
    ASSERT (  pOrder && pMaintFlag )
    pNewDealCnfrmT pDealCnfrm = NULL;
    pDealInfoT  pDealInfo = NULL;    
    
    
    rc = GetDealCnfrm( pOrderRsp, &pDealCnfrm);
    RAISE_ERR(rc, RTN);
   
    pDealInfo = (pDealInfoT)ADDRESS_ADD_OFFSET(&pDealCnfrm->rspDeal, pDealCnfrm->cnfrmCnt * sizeof(DealInfoT));
 
    if ( ORDR_SIDE_BUY == oSide )
    {
        pDealInfo->bidOrdNo = pOrder->orderF.ordrNo;
        pDealInfo->bidOrgIdx = pOrder->orderF.entyIdxNo; 
        pDealInfo->bidUsrIdx = pOrder->orderF.userIdx; 
    }
    else if  ( ORDR_SIDE_SELL == oSide )
    {
        pDealInfo->askOrdNo = pOrder->orderF.ordrNo; 
        pDealInfo->askOrgIdx = pOrder->orderF.entyIdxNo;      
        pDealInfo->askUsrIdx = pOrder->orderF.userIdx; 
    }
    
    if (bIncCnt)
    {
        pDealInfo->tradeNo = pMtchTrd->trade.tranIdNo;
        pDealInfo->contractPos = pMtchTrd->trade.prdctId;
        pDealInfo->trdAmount = pMtchTrd->trade.trdQty;
        pDealInfo->trdPrice = pMtchTrd->trade.tradMtchPrc;;
        pDealInfo->trdDateTime = pMtchTrd->trade.tranDatTim;
        pDealInfo->trdSts  = pMtchTrd->trade.trdSts;
    
        pDealCnfrm->cnfrmCnt ++;
    }
    
     
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   format deal cancle
 * Parameters:
 *  pTradeDat   IN  trade info
 *  pOrderRsp   OUT changed trade info
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT FmtDealCnclCnfrm( int32 setId, pTradeDatT pTradeDat, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION ( "FmtDealCnclCnfrm" );
    ResCodeT rc = NO_ERR;
    
    pNewDealCnfrmT  pDealCnfrm = NULL;
    uint32          ordrPos = 0;
    pOrderT         pOrder = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    pDealInfoT      pDealInfo = NULL;
    
    
    rc = GetDealCnfrm( pOrderRsp, &pDealCnfrm);
    RAISE_ERR(rc, RTN);
   
    pDealInfo = (pDealInfoT)ADDRESS_ADD_OFFSET(&pDealCnfrm->rspDeal, pDealCnfrm->cnfrmCnt * sizeof(DealInfoT));
    
    rc = OrdrMgmtNrmlGet( setId, pTradeDat->bidTrd.ordrNo, &pOrdrMgmt, &pOrder, &ordrPos );
    RAISE_ERR(rc,RTN);

    pDealInfo->bidOrdNo = pTradeDat->bidTrd.ordrNo;
    pDealInfo->bidOrgIdx = pOrder->orderF.entyIdxNo;
    pDealInfo->bidUsrIdx = pOrder->orderF.userIdx;
    
    rc = OrdrMgmtNrmlGet( setId, pTradeDat->askTrd.ordrNo, &pOrdrMgmt, &pOrder, &ordrPos );
    RAISE_ERR(rc,RTN);
    
    pDealInfo->askOrdNo = pTradeDat->askTrd.ordrNo;
    pDealInfo->askOrgIdx = pOrder->orderF.entyIdxNo;
    pDealInfo->askUsrIdx = pOrder->orderF.userIdx;

    pDealInfo->tradeNo = pTradeDat->bidTrd.tranIdNo;
    pDealInfo->contractPos = pTradeDat->bidTrd.prdctId;
    pDealInfo->trdAmount = pTradeDat->bidTrd.ordrExeQty;
    pDealInfo->trdPrice = pTradeDat->bidTrd.tradMtchPrc;
    pDealInfo->trdDateTime = pTradeDat->bidTrd.tranDatTim;
    pDealInfo->trdSts = DEAL_STS_CANCEL;
    
    pDealCnfrm->cnfrmCnt ++;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT FmtOrdCnfrm(  pOrderT pOrder, pNewOrderSingleRspT pOrderRsp, MaintFlagT * pMaintFlag, int64 tranTime )
{
    BEGIN_FUNCTION ( "FmtOrdCnfrm" );
    ResCodeT rc = NO_ERR;
    pNewOrderCnfrmT  pOrderCnfrm = NULL;
    pOrderInfoT  pOrdrInfo = NULL;
    ASSERT (  pOrder && pMaintFlag )

    rc = GetOrdrCnfrm( pOrderRsp, &pOrderCnfrm);
    RAISE_ERR(rc, RTN);
    
    
    pOrdrInfo = (pOrderInfoT)ADDRESS_ADD_OFFSET(&pOrderCnfrm->rspOrder, pOrderCnfrm->cnfrmCnt * sizeof(OrderInfoT));

    pOrdrInfo->qty  = pOrder->orderF.ordrQty + pOrder->orderF.ordrExeQty;
    
    pOrdrInfo->ordrMask = pOrder->orderF.ordrMask;
    
    pOrdrInfo->extOrdrType = pOrder->orderF.extOrdrType; 
    
    pOrdrInfo->contractPos = pOrder->orderF.prdctId;
    
    pOrdrInfo->price = pOrder->orderF.ordrExePrc;
    
    
    pOrdrInfo->remain = pOrder->orderF.ordrQty;
    
    pOrdrInfo->traderId = pOrder->orderF.userIdx;
    pOrdrInfo->orgId = pOrder->orderF.entyIdxNo;
    pOrdrInfo->orderNo = pOrder->orderF.ordrNo;
    
    pOrdrInfo->createTime = pOrder->orderF.ordrEntTim;
    pOrdrInfo->activateTime = pOrder->orderF.ordrActiveTim; 
    pOrdrInfo->updateTime = pOrder->orderF.tranTime;
    pOrdrInfo->expireTime = pOrder->orderF.ordrExpTim;

    pOrdrInfo->specOrdrId = pOrder->orderF.specOrdrNo;

    if (WKSG_LIT_MARKETABLE == pMaintFlag->mktblFlg)
    {
        pOrdrInfo->status = ORDR_STS_DEAL;
        pOrdrInfo->qty = pOrder->orderF.ordrQty + pOrder->orderF.ordrExeQty;
    }
    
    if (pOrdrInfo->remain)
    {
        pOrdrInfo->status = ORDR_STS_ACTIVE;
    }
    
    if (pMaintFlag->ordrCncl == WKSG_LIT_YES)
    {
        pOrdrInfo->status = pOrder->orderF.ordrSts;
    }

    if ( pOrdrInfo->status == ORDR_STS_CANCEL || 
           pOrdrInfo->status == ORDR_STS_FREEZE ||
           pOrdrInfo->status == ORDR_STS_INACTIVE )
    {
        pOrdrInfo->activateTime = 0;
    }

    memset( pOrdrInfo->rqstId, 0x00, sizeof(pOrdrInfo->rqstId) );
    if ( pOrder->orderF.apiRqstId )
    {
        itoa(pOrder->orderF.apiRqstId, pOrdrInfo->rqstId, 2);
    }

    LOG_DEBUG("OrdrInfo OrdrNo %lld, specOrdrNo %lld, sts %d ", pOrder->orderF.ordrNo,  pOrder->orderF.specOrdrNo, pOrder->orderF.ordrSts);
            
    LOG_DEBUG("OrdrInfo Prdct %d, Amt %lld, extType %d, Qty %lld", pOrder->orderF.prdctId, pOrder->orderF.remPkQty, pOrder->orderF.extOrdrType,
            pOrder->orderF.ordrQty);
    
    pOrderCnfrm->cnfrmCnt ++;
     
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pTrade      IN  format trade
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
void InitRspDat(pNewOrderSingleRspT pOrderRsp )
{ 
    pOrderRsp->slotCnt = 0;
    pOrderRsp->currOrdrSlot = -1;
    pOrderRsp->currDealSlot = -1;
}


/******************************************************************************
 * Description:   delete order and log order delete into mem txn
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchDelOrdr(BOOL bNeedMemTxn, int32 setId, pOrderT *order,
                int64 tranTime,
                uint16 actnMask,
                pMtchInfoT pMtchInfo,
                pPrdctInfoT pPrdctInfo,
                BOOL delFlg)
{
    BEGIN_FUNCTION("MtchDelOrdr");
    ResCodeT rc = NO_ERR;
    int wrtPtr;
    pMDelOrdrT pDelOrdAddr;
    pOrderT ordr = *order;
    int64       ordrMgmtPos = 0;

    uint32          brdgOrdrPos;
    BrdgOrdrKeyT    brdgOrdrKey = {0};
    pBrdgOrdrRcrdT  pBrdgOrdr = NULL;

    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_ORD_DEL, sizeof(MDelOrdrT) , (void **)&pDelOrdAddr);
        RAISE_ERR( rc, RTN );
    
    
        /* start logging the data */
        pDelOrdAddr->slot  = ordr->orderT.slotNo;
        pDelOrdAddr->orderF = ordr->orderF;
        pDelOrdAddr->tranTime= tranTime;
        pDelOrdAddr->setId = setId;
        pDelOrdAddr->delFlg = delFlg;
        memcpy(&pDelOrdAddr->mtchInfo, pMtchInfo, sizeof (MtchInfoT));
        pDelOrdAddr->actnMask = actnMask;
    
        /* confirm writing two trades*/
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    
    rc = OrdrMgmtNrmlUpdt(setId, ordr->orderF.ordrNo, ordr->orderF.ordrSts, ordr);
    RAISE_ERR(rc, RTN);  
    
    /* do the action */
    if ( delFlg )
    {
        rc = OrdrBkDeleteOrdr( setId, order,tranTime);
        RAISE_ERR(rc, RTN);
        
    }

    if ( ordr->orderF.brdgFlag == INT_ORD_FLAG_BRDG &&
        ordr->orderF.ordrSts != ORDR_STS_DEAL ) 
    {
        brdgOrdrKey.entyIdxNo = ordr->orderF.entyIdBrdg;
        brdgOrdrKey.prdctId = ordr->orderF.prdctId;
        brdgOrdrKey.ordrSide = GET_ORDR_SIDE(ordr->orderF.ordrMask);

        rc = BrdgOrdrChk(setId, &brdgOrdrKey, &pBrdgOrdr, &brdgOrdrPos);
        if (rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
        {
            rc = MtchBrdgOrdrUpdt( FALSE, setId, ACTN_BRDG_DEL, pBrdgOrdr ); 
            RAISE_ERR(rc, RTN);
        }

        ordr->orderF.brdgFlag = 0x00;
        ordr->orderF.entyIdBrdg = CMN_LIST_NULL_NODE;
    }

    SetMktInfoUpdVec( setId, ordr->orderF.prdctId );

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* MtchDelOrdr */

/******************************************************************************
 * Description:   delete order and log order delete into mem txn
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchBrdgMktPush(BOOL bNeedMemTxn, int32 setId, pOrderFT pBrdgOrdr)
{
    BEGIN_FUNCTION("MtchBrdgMktPush");
    ResCodeT rc = NO_ERR;
    pMBrdgMktDatPushT pMBrdgMktDatPush;

    
    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_BRDG_MKT_DAT_PUSH, sizeof(MBrdgMktDatPushT) , (void **)&pMBrdgMktDatPush);
        RAISE_ERR( rc, RTN );
    
    
        /* start logging the data */
        pMBrdgMktDatPush->setId = setId;
        memcpy(&pMBrdgMktDatPush->brdgOrdrF, pBrdgOrdr, sizeof(OrderFT));
        /* confirm writing two trades*/
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* MtchBrdgMktPush */



/******************************************************************************
 * Description:   delete order and log order delete into mem txn
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchBrdgOrdrUpdt(BOOL bNeedMemTxn, int32 setId, int32 updtType, pBrdgOrdrRcrdT pBrdgOrdrRcrd)
{
    BEGIN_FUNCTION("MtchBrdgOrdrUpdt");
    ResCodeT        rc = NO_ERR;
    pMBrdgOrdrUpdtT     pMBrdgOrdrUpdt;
    uint32               brdgOrdrPos ;
    
    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_BRDG_ORD_UPDT, sizeof(MBrdgOrdrUpdtT) , (void **)&pMBrdgOrdrUpdt);
        RAISE_ERR( rc, RTN );
    
    
        /* start logging the data */
        pMBrdgOrdrUpdt->setId = setId;
        pMBrdgOrdrUpdt->updtType = updtType;
        memcpy(&pMBrdgOrdrUpdt->brdgOrdr, pBrdgOrdrRcrd, sizeof(BrdgOrdrRcrdT));
        /* confirm writing two trades*/
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    if (updtType == ACTN_BRDG_ADD)
    {
        rc = BrdgOrdrAdd(setId, pBrdgOrdrRcrd, &brdgOrdrPos);
        RAISE_ERR(rc, RTN); 
    }
    else if (updtType == ACTN_BRDG_MTCH || updtType == ACTN_BRDG_DEL )
    {
        rc = BrdgOrdrDel( setId, &pBrdgOrdrRcrd->ordrKey );
        RAISE_ERR(rc, RTN);
    }
    else if (updtType == ACTN_BRDG_DEL_ALL)
    {
        rc = BrdgOrdrMgmtDelAll( setId );
        RAISE_ERR(rc, RTN);
    }
    else if (updtType == ACTN_BRDG_DEL_BRDG)
    {
        rc = BrdgOrdrMgmtDelAllByBrdgOrgId( setId, pBrdgOrdrRcrd->brdgOrgId );
        RAISE_ERR(rc, RTN);
    }
    else if (updtType == ACTN_BRDG_DEL_ORG)
    {
        rc = BrdgOrdrMgmtDelAllByOrgId( setId, pBrdgOrdrRcrd->ordrKey.entyIdxNo );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* MtchBrdgOrdrUpdt */


/******************************************************************************
 * Description:   delete order and log order delete into mem txn
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchUpdCrdtByTrd(BOOL bNeedMemTxn, int32 setId,pCrdtMgmtUpdtT pCrdtMgmtUpdt)
{
    BEGIN_FUNCTION("MtchUpdCrdtByTrd");
    ResCodeT rc = NO_ERR;
    int wrtPtr;
    pMUpdtCrdtByTrdT pUpdtCrdtByTrd;
    
    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_CRDT_UPDT_BY_TRD, sizeof(MUpdtCrdtByTrdT) , (void **)&pUpdtCrdtByTrd);
        RAISE_ERR( rc, RTN );
    
    
        /* start logging the data */
        pUpdtCrdtByTrd->setId = setId;
        memcpy(&pUpdtCrdtByTrd->crdtMgmtUpdt, pCrdtMgmtUpdt, sizeof (CrdtMgmtUpdtT));

        /* confirm writing two trades*/
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    rc = CreditDeduction( pCrdtMgmtUpdt);
    RAISE_ERR( rc, RTN );
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* MtchUpdCrdtByTrd */

/******************************************************************************
 * Description:   Log trade date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchLogTrd(BOOL bNeedMemTxn, int32 set, uint16 actnMask, int64 oldOrdrNo, MtchTrdT * pMtchTrd)
{
    BEGIN_FUNCTION("MtchLogTrd");
    ResCodeT rc = NO_ERR;
    pMLogTrdT pLogTrdAddr = NULL;
    static BOOL bFirstTime = 1;
    int i;
    static TradeT tmpTrade;
    static uint64 tmpOldOrdrNo;
    static uint16 tmpActnMask;
    ASSERT(pMtchTrd);

    if (bFirstTime)
    /*for the first time only save in tmp variables.
        MtchLogTrd(TRUE, ) should ALWAYS be called by application modules in pairs (buy
        and sell side). Else the trade is not completely logged.
        As broadcast image need to send TC in pairs to downstream modules,
        the pair of MLogTrdT data should be stored in the same txn,
    */
    {
        /* Buffer the first time */
        memcpy(&tmpTrade, &pMtchTrd->trade, sizeof (TradeT));
        tmpOldOrdrNo = oldOrdrNo;
        tmpActnMask = actnMask;
        THROW_RESCODE(NO_ERR);
    }

    if (bNeedMemTxn)
    {
        /* for the second time start logging the data */
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_TRD_LOG, sizeof(MLogTrdT)*2 , (void **)&pLogTrdAddr);
        RAISE_ERR( rc, RTN );
    
        /* log the data for twice*/
        for (i = 0; i <= 1; i ++, pLogTrdAddr ++)
        {
            memcpy(&pLogTrdAddr->trade, i ? &pMtchTrd->trade : &tmpTrade,
                sizeof (TradeT));
            pLogTrdAddr->actnMask = i ? actnMask : tmpActnMask;
            pLogTrdAddr->oldOrdrNo = i ? oldOrdrNo : tmpOldOrdrNo;
            pLogTrdAddr->setId = set;    
    
        }
        /* confirm writing two trades*/
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    
    SetMktInfoUpdVec( set, pMtchTrd->trade.prdctId );

    EXIT_BLOCK();
    /*toggle bFirstTime*/
    bFirstTime ^= 1;
    RETURN_RESCODE;
}


/*******************************************************************************
 * Description: Modify the quantity of an order
 *
 * Parameters:
 *      oldOrdr     : IN  - pointer to a copy of the to be modified order
 *      modOrdr     : IN  - pointer to the modified order
 *     actnMask     : IN  - action mask
 *
 * Return Value     : NO_ERR               - Successful
 *                    ERR_<DESC>           - Error
 ******************************************************************************/
ResCodeT MtchModOrdrQty(BOOL bNeedMemTxn, int32 set, pOrderT oldOrdr,
                int64 exeQty,
                int64 exePrc,
                int64 tranTime,
                uint16 actnMask)
{
    BEGIN_FUNCTION("MtchModOrdrQty");
    ResCodeT rc = NO_ERR;

    pMModOrdQtyT pModOrdQtyAddr = NULL;

    ASSERT(oldOrdr);
    
    if (bNeedMemTxn)
    {
        /* for the second time start logging the data */
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_ORD_MOD_QTY, sizeof(MModOrdQtyT) , (void **)&pModOrdQtyAddr);
        RAISE_ERR( rc, RTN );
        /* log the data */
    
        pModOrdQtyAddr->slot  = oldOrdr->orderT.slotNo;
        pModOrdQtyAddr->exeQty = exeQty;
        pModOrdQtyAddr->exePrc = exePrc;
        pModOrdQtyAddr->tranTime = tranTime;
        pModOrdQtyAddr->actnMask = actnMask;
        pModOrdQtyAddr->setId = set; 
        RAISE_ERR(OrdBkModOrdrQty(set, oldOrdr, exeQty, tranTime), RTN);

        memcpy(&pModOrdQtyAddr->oldOrdr, &oldOrdr->orderF, sizeof (OrderFT));
        pModOrdQtyAddr->remPkQty = oldOrdr->orderF.remPkQty;
    
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
int32 MtchGetOrdrStsByActMnt(int32 actnMask)
{
    int32 actMnt = GET_ACTN_MAINT(actnMask);
    int32 ordrSts = 0;
    
    switch(actMnt)
    {
        case ACTN_MATCH_MNT:
            ordrSts = ORDR_STS_DEAL;
            break;
        
        case ACTN_CANCEL_MNT: 
        case ACTN_DEL_MNT:   
            ordrSts = ORDR_STS_CANCEL;
            break;   
        case ACTN_ADD_MNT: 
        case ACTN_PRT_FIL_MNT:              
            ordrSts = ORDR_STS_ACTIVE;   
            break;
        default:
            break;
    }
    
    return ordrSts;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchLogOrdr(BOOL bNeedMemTxn, int32 set, uint16 actnMask,pOrderT pOrder, MtchInfoT * pMtchInfo)
{
    BEGIN_FUNCTION( "MtchLogOrdr" );
    ResCodeT        rc = NO_ERR;

    pMLogOrdrT      pLogOrdrAddr = NULL;
    int32           ordrSts = 0;
    int64           ordrMgmtPos = 0;
    
    if (bNeedMemTxn)
    {

        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_ODR_LOG, sizeof(MLogOrdrT) , (void **)&pLogOrdrAddr);
        RAISE_ERR( rc, RTN );
    
        pLogOrdrAddr->slot  = pOrder->orderT.slotNo;
        pLogOrdrAddr->actnMask = actnMask;
        pLogOrdrAddr->setId = set;
        memcpy(&pLogOrdrAddr->ordr, &pOrder->orderF, sizeof (OrderFT));
        memcpy(&pLogOrdrAddr->mtchInfo, pMtchInfo, sizeof (MtchInfoT));
    
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    ordrSts = MtchGetOrdrStsByActMnt(actnMask);
    
    rc = OrdrMgmtNrmlUpdt(set, pOrder->orderF.ordrNo,  ordrSts, pOrder);
    RAISE_ERR(rc, RTN);  
    
    SetMktInfoUpdVec( set, pOrder->orderF.prdctId );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchAddOrdr(BOOL bNeedMemTxn, BOOL bRcvrFlg, int32 set, uint16 actnMask,pOrderT pOrder, MtchInfoT * pMtchInfo, pMAddOrdrT  pRcvrAddOrdrAddr)
{
    BEGIN_FUNCTION( "MtchAddOrdr" );
    ResCodeT        rc = NO_ERR;

    pMAddOrdrT      pAddOrdrAddr = NULL;
    int64           ordrMgmtPos = 0;
    
    if (bNeedMemTxn)
    {

        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_ODR_ADD, sizeof(MAddOrdrT) , (void **)&pAddOrdrAddr);
        RAISE_ERR( rc, RTN );
        
        if (bRcvrFlg && pRcvrAddOrdrAddr)
        {
            pAddOrdrAddr->prcLder = pRcvrAddOrdrAddr->prcLder;
            pAddOrdrAddr->fNewPrcLder = pRcvrAddOrdrAddr->fNewPrcLder;
        }
    
        pAddOrdrAddr->slot  = pOrder->orderT.slotNo;
        pAddOrdrAddr->actnMask = actnMask;
        pAddOrdrAddr->setId = set;
        memcpy(&pAddOrdrAddr->ordr, &pOrder->orderF, sizeof (OrderFT));
        memcpy(&pAddOrdrAddr->mtchInfo, pMtchInfo, sizeof (MtchInfoT));
    
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    else
    {
        pAddOrdrAddr = pRcvrAddOrdrAddr;
    }
    
    rc = OrdrBkAddOrdr(bRcvrFlg, set, &pOrder, pAddOrdrAddr);
    RAISE_ERR( rc, RTN );
    
    rc = OrdrMgmtNrmlUpdt(set, pOrder->orderF.ordrNo,  ORDR_STS_ACTIVE, pOrder);
    RAISE_ERR(rc, RTN);  
    
    SetMktInfoUpdVec( set, pOrder->orderF.prdctId );
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchMktDatPush(BOOL bNeedMemTxn,  int32 set)
{
    BEGIN_FUNCTION( "MtchMktDatPush" );
    ResCodeT        rc = NO_ERR;

    pMMktDatPushT   pMMktDatPush = NULL;
    
    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_MKT_DAT_PUSH, sizeof(MMktDatPushT) , (void **)&pMMktDatPush);
        RAISE_ERR( rc, RTN );
        
        pMMktDatPush->eventId  = 0;
    
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchSaveOrdr(BOOL bNeedMemTxn, int32 set, uint16 actnMask,pOrderT pOrder)
{
    BEGIN_FUNCTION( "MtchSaveOrdr" );
    ResCodeT        rc = NO_ERR;

    pMSaveOrdrT      pSaveOrdrAddr = NULL;
    int64           ordrMgmtPos = 0;
    
    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_ORD_SAVE, sizeof(MSaveOrdrT) , (void **)&pSaveOrdrAddr);
        RAISE_ERR( rc, RTN );
    
        pSaveOrdrAddr->slot  = pOrder->orderT.slotNo;
        pSaveOrdrAddr->actnMask = actnMask;
        pSaveOrdrAddr->setId = set;   
        memcpy(&pSaveOrdrAddr->ordrF, &pOrder->orderF, sizeof (OrderFT));
    
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    rc = OrdrMgmtNrmlUpdt(set, pOrder->orderF.ordrNo, ORDR_STS_FREEZE, pOrder);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchSaveBilOrdr(BOOL bNeedMemTxn, int32 set, int16 ordrAct, uint16 ordSts,pOrderT pBidOrder, pOrderT pAskOrder, SlotT bidSlot, SlotT askSlot)
{
    BEGIN_FUNCTION( "MtchSaveBilOrdr" );
    ResCodeT            rc = NO_ERR;
    pMSaveBilOrdrT      pSaveBilOrdrAddr = NULL;
    int64               ordrMgmtPos = 0;

    UsrFlgKeyT          usrFlgKey = {0};

    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_BIL_ORD_SAVE, sizeof(MSaveBilOrdrT) , (void **)&pSaveBilOrdrAddr);
        RAISE_ERR( rc, RTN );
    
        pSaveBilOrdrAddr->bidSlot  = bidSlot;
        pSaveBilOrdrAddr->askSlot  = askSlot;
        pSaveBilOrdrAddr->ordrSts = ordSts;
        pSaveBilOrdrAddr->ordrAct = ordrAct;
        pSaveBilOrdrAddr->setId = set;   
        memcpy(&pSaveBilOrdrAddr->bidOrdrF, &pBidOrder->orderF, sizeof (OrderFT));
        memcpy(&pSaveBilOrdrAddr->askOrdrF, &pAskOrder->orderF, sizeof (OrderFT));
    
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }

    usrFlgKey.usrPos = (uint32)pBidOrder->orderF.userIdx;
    usrFlgKey.cntrctPos = (uint32)pBidOrder->orderF.prdctId;
    if ( ordrAct == ACTN_ADD_CMD ||
            ordrAct == ACTN_BOOK_CMD )
    {
        rc = SetUsrFlg( &usrFlgKey, USR_BIL_ORD_FLG );
        RAISE_ERR( rc, RTN );
    }
    else if ( ordrAct == ACTN_CNCL_CMD && ordSts == ORDR_STS_CANCEL )
    {
        rc = ResetUsrFlg( &usrFlgKey, USR_BIL_ORD_FLG );
        RAISE_ERR( rc, RTN );
    }

    rc = OrdrMgmtBilUpdt(set, pBidOrder->orderF.specOrdrNo,ordSts,pBidOrder, pAskOrder,bidSlot,askSlot);
    RAISE_ERR(rc, RTN);
    
    rc = OrdrMgmtNrmlUpdt(set, pBidOrder->orderF.ordrNo, ordSts, pBidOrder);
    RAISE_ERR(rc, RTN);  

    rc = OrdrMgmtNrmlUpdt(set, pAskOrder->orderF.ordrNo, ordSts, pAskOrder);
    RAISE_ERR(rc, RTN);  

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchLogOcoOrdr(BOOL bNeedMemTxn, int32 set, int64 ocoOrdrNo, int16 ordrAct, uint16 ordSts, int32 bidCnt, pOrderT pBidOrderArr[], int32 askCnt, pOrderT pAskOrderArr[])
{
    BEGIN_FUNCTION( "MtchLogOcoOrdr" );
    ResCodeT            rc = NO_ERR;
    pMLogOcoOrdrT       pMLogOcoOrdr = NULL;
    //pSubOrdrT           pSubOrdr = NULL;
    OrdrMgmtRcrdT       ordrMgmt;
    pOrdrMgmtRcrdT      pOrdrMgmt;
    pUsrBaseInfoT       pUsrInfo = NULL;
    pOrderT             pCnclOrder = NULL;
    int64               iter;
    int64               ordrMgmtPos = 0;
    int32               i = 0;
    
    SlotT *             pOrdSlot;
    int32               ttlOrdrSize;
    
    memset(&ordrMgmt.ordrKey, 0x00, sizeof(OrdrMgmtKeyT));
    ordrMgmt.ordrCnt = 0;

    /* Process Bid Side */
    for (i = 0; i < bidCnt; i++)
    {
        rc = OrdrMgmtOcoDatPrpr(ordSts, &ordrMgmt, pBidOrderArr[i]);
        RAISE_ERR( rc, RTN );
    }
    
    /* Process Bid Side */
    for (i = 0; i < askCnt; i++)
    {
        rc = OrdrMgmtOcoDatPrpr(ordSts, &ordrMgmt, pAskOrderArr[i]);
        RAISE_ERR( rc, RTN );
    }
    
    rc = OrdrMgmtOcoUpdt(set, ocoOrdrNo, ordSts, &ordrMgmt);
    RAISE_ERR(rc, RTN);
    
    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId, MT_TYP_LOG_OCO, sizeof(MLogOcoOrdrT)+sizeof(OrdrMgmtRcrdT), (void **)&pMLogOcoOrdr);
        RAISE_ERR( rc, RTN );
        
        pMLogOcoOrdr->specOrdrNo = ocoOrdrNo;
        pMLogOcoOrdr->bidSlotCnt = bidCnt;
        pMLogOcoOrdr->askSlotCnt = askCnt;
        pMLogOcoOrdr->ordrSts    = ordSts;
        pMLogOcoOrdr->ordrAct    = ordrAct;
        pMLogOcoOrdr->setId = set;
        
        pOrdrMgmt = (pOrdrMgmtRcrdT)ADDRESS_ADD_OFFSET(pMLogOcoOrdr, sizeof(MLogOcoOrdrT));
        
        memcpy( pOrdrMgmt, &ordrMgmt, sizeof(OrdrMgmtRcrdT) );
        
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }

    if ( ordrAct == ACTN_BOOK_CMD || ordrAct == ACTN_CNCL_CMD )
    {
        rc = OrdrMgmtOcoGet(set, ocoOrdrNo, &pOrdrMgmt, &pCnclOrder, &iter);
        RAISE_ERR( rc, RTN );

        rc = IrsUsrInfoGetByPosExt( pCnclOrder->orderF.userIdx, &pUsrInfo );
        RAISE_ERR( rc, RTN );
    }

    if ( ordrAct == ACTN_BOOK_CMD )
    {
        pUsrInfo->ocoOrdCnt++;
    }
    else if ( ordrAct == ACTN_CNCL_CMD )
    {
        pUsrInfo->ocoOrdCnt--;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT DelOrdrFromMgmtLst(int32 set, int64 ordrNo, int32 ordrType)
{
    BEGIN_FUNCTION( "DelOrdrFromMgmtLst" );
    ResCodeT        rc = NO_ERR;
    
    OrdrMgmtKeyT    orderKey = {0};
     
    orderKey.ordrNo = ordrNo;
    orderKey.ordrType = ordrType; 
    
    rc = OrdrMgmtDel(set, &orderKey);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/*******************************************************************************
 * Description: Modify an order
 *
 * Parameters:
 *      oldOrdr     : IN  - pointer to a copy of the to be modified order
 *      modOrdr     : IN  - pointer to the modified order
 * trdResChgFlg     : IN  - flag for orderbook to indicate modified restriction
 *     actnMask     : IN  - action mask
 *
 * Return Value     : NO_ERR               - Successful
 *                    ERR_<DESC>           - Error
 ****************************************************************************/
ResCodeT MtchModOrdr(BOOL bNeedMemTxn, BOOL bRcvrFlg, int32 set, pOrderT *pOldOrdr,
                    const pOrderFT newOrdr,
                    int32 actnMask,
                    MtchInfoT * pMtchInfo,
                    pMModOrdrT      pRcvrModOrdrAddr)
{
    ResCodeT rc = NO_ERR;
    int wrtPtr;

    pMModOrdrT      pModOrdrAddr = NULL;

    BEGIN_FUNCTION("MtchModOrdr");

    if (bNeedMemTxn)
    {
        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_ODR_MOD, sizeof(MModOrdrT) , (void **)&pModOrdrAddr);
        RAISE_ERR( rc, RTN );
        
        if (bRcvrFlg)
        {
            pModOrdrAddr->oldPrcLder = pRcvrModOrdrAddr->oldPrcLder;
            pModOrdrAddr->newPrcLder = pRcvrModOrdrAddr->newPrcLder; 
            pModOrdrAddr->fNewPrcLder = pRcvrModOrdrAddr->fNewPrcLder; 
        }
    
        pModOrdrAddr->slot  = (*pOldOrdr)->orderT.slotNo;
        pModOrdrAddr->setId = set;   
        memcpy(&pModOrdrAddr->oldOrdr, &(*pOldOrdr)->orderF, sizeof (OrderFT));
        memcpy(&pModOrdrAddr->newOrdr, newOrdr, sizeof (OrderFT));
    
        memcpy(&pModOrdrAddr->mtchInfo, pMtchInfo, sizeof (MtchInfoT));
    
        pModOrdrAddr->actnMask = actnMask;
        
        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }

    rc = OrdrBkModOrdr (bRcvrFlg, set, pOldOrdr,newOrdr,pModOrdrAddr);
    RAISE_ERR( rc, RTN );          
    
    SetMktInfoUpdVec( set, (*pOldOrdr)->orderF.prdctId );
                  
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* MlModOrdr */



       
/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pPrdctInfo  IN  product info
 *  pOrder      IN  Incoming order
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT DoMtchBrdgOrdr ( int32 setId,
                                pCntrctBaseInfoT pCntrctInfo, 
                                pPrdctInfoT  pPrdctInfo, 
                                int64 brdgOrgId,
                                pOrderT     pNeedBrdgBkOrdr, 
                                pOrderT     pBkOrdr,
                                pMtchInfoT  pMtchInfo,
                                int64 brdgFee,
                                int64 timestamp,
                                pNewOrderSingleRspT pOrderRsp)
{

    BEGIN_FUNCTION ( "DoMtchBrdgOrdr" );
    ResCodeT            rc = NO_ERR;
    MtchInfoT           mtchInfo;
    pOrderT             pBrdgOrderForBk = NULL;
    MtchTrdT            mtchTrd;
    CrdtMgmtUpdtT       crdtMgmtUpdt;
    pOrgInfoT           pBrdgOrgInfo = NULL;
    int64               brdgOrdrPrc = 0, brdgOrdrQty = 0;

    rc = OrgInfoGetByIdExt(brdgOrgId, &pBrdgOrgInfo);
    RAISE_ERR(rc, RTN);
    
    if (GET_ORDR_SIDE(pNeedBrdgBkOrdr->orderF.ordrMask) == ORDR_SIDE_BUY)
    {
        brdgOrdrPrc = pBkOrdr->orderF.ordrExePrc + brdgFee;
    }
    else
    {
        brdgOrdrPrc = pBkOrdr->orderF.ordrExePrc - brdgFee;
    }

    brdgOrdrQty = pBkOrdr->orderF.ordrQty < pNeedBrdgBkOrdr->orderF.ordrQty ?
                    pBkOrdr->orderF.ordrQty : pNeedBrdgBkOrdr->orderF.ordrQty;

    /* Caculate a bridge order */
    rc = CreateBrdgOrdr( setId, pCntrctInfo, pBrdgOrgInfo->pos, pNeedBrdgBkOrdr, 
                            brdgOrdrPrc, brdgOrdrQty, brdgFee, &pBrdgOrderForBk );
    RAISE_ERR( rc, RTN );
            
    pMtchInfo->ordrNoOld = 0;
    pMtchInfo->ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    pMtchInfo->tradePrc = 0;
    
    rc = MtchrPrcsOrdrAdd(FALSE, FALSE, setId, pPrdctInfo, pBrdgOrderForBk, timestamp, pOrderRsp, pMtchInfo);
    RAISE_ERR(rc, RTN);

    /* Match them both */
    /* Caculate another bridge order */
    rc = CreateBrdgOrdr(setId,pCntrctInfo, pBrdgOrgInfo->pos, pBkOrdr, 
                    pBkOrdr->orderF.ordrExePrc, brdgOrdrQty, 0, &pBrdgOrderForBk);
    RAISE_ERR( rc, RTN );
    
    pMtchInfo->ordrNoOld = 0;
    pMtchInfo->ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    pMtchInfo->tradePrc = 0;

    /* Match for the Need Bridage order  */
    rc = MtchrPrcsOrdrAdd(FALSE, FALSE, setId, pPrdctInfo, pBrdgOrderForBk, timestamp, pOrderRsp, pMtchInfo);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
  
       
/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pPrdctInfo  IN  product info
 *  pOrder      IN  Incoming order
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT GetOrdrAndDoBrdgMtch ( int32 setId,
                                int32 ordrSide, 
                                pOrderT pOrder,
                                pCntrctBaseInfoT  pCntrctInfo,
                                pPrdctInfoT pPrdctInfo,
                                int64 brdgOrgId,
                                pMtchInfoT pMtchInfo,
                                int64 tranTime,
                                pNewOrderSingleRspT pOrderRsp,
                                pBrdgOrdrRcrdT      pBrdgOrdrInfo)
{

    BEGIN_FUNCTION ( "GetOrdrAndDoBrdgMtch" );
    ResCodeT            rc = NO_ERR;
    pOrderT             pBkOrder = NULL;
    
    int64               brdgPrc = 0;
    
    rc = OrdrBkGetOrdr(setId,pBrdgOrdrInfo->ordrBkSlot,&pBkOrder);
    RAISE_ERR(rc, RTN);
    
    if ( ordrSide == ORDR_SIDE_BUY )
    {
        brdgPrc = pBkOrder->orderF.ordrExePrc + pBrdgOrdrInfo->brdgFee;
    }
    else
    {
        brdgPrc = pBkOrder->orderF.ordrExePrc - pBrdgOrdrInfo->brdgFee;
    }
    
    if ( (ordrSide == ORDR_SIDE_BUY && pOrder->orderF.ordrExePrc >= brdgPrc) ||
            (ordrSide == ORDR_SIDE_SELL && pOrder->orderF.ordrExePrc <= brdgPrc) )
    {
        /* Caculate a bridge order */
        rc = DoMtchBrdgOrdr ( setId,pCntrctInfo,pPrdctInfo, 
                                brdgOrgId,
                                pOrder, 
                                pBkOrder,
                                pMtchInfo,
                                pBrdgOrdrInfo->brdgFee,tranTime,pOrderRsp);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}
  
/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pPrdctInfo  IN  product info
 *  pOrder      IN  Incoming order
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT TryBrdgOrdrMtch ( int32 setId,
                                pOrderT pOrder,
                                pPrdctInfoT pPrdctInfo,
                                pMtchInfoT pMtchInfo,
                                int64 tranTime,
                                pNewOrderSingleRspT pOrderRsp,
                                BOOL   * pbBrdgMtchFlg)
{

    BEGIN_FUNCTION ( "TryBrdgOrdrMtch" );
    ResCodeT            rc = NO_ERR;
    BrdgOrdrKeyT        brdgOrdrKey = {0};
    pOrgInfoT           pOrgInfo = NULL;
    pCntrctBaseInfoT    pCntrctBaseInfo = NULL;
    int32               ordrSide = GET_ORDR_SIDE(pOrder->orderF.ordrMask);  
    pBrdgOrdrRcrdT      pBrdgOrdr = NULL;
    uint32               brdgOrdrPos ;
   
    rc = OrgInfoGetByPosExt(pOrder->orderF.entyIdxNo, &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    rc = IrsCntrctInfoGetByPosExt(pOrder->orderF.prdctId, &pCntrctBaseInfo);
    RAISE_ERR(rc, RTN);
    

    brdgOrdrKey.entyIdxNo = (uint32)pOrder->orderF.entyIdxNo;
    brdgOrdrKey.prdctId = pPrdctInfo->pos;
    brdgOrdrKey.ordrSide = (ordrSide == ORDR_SIDE_BUY)? ORDR_SIDE_SELL : ORDR_SIDE_BUY;

    rc = BrdgOrdrChk(setId, &brdgOrdrKey, &pBrdgOrdr, &brdgOrdrPos);
    if (rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        /* Find the bridge order ,try matching*/
        rc = GetOrdrAndDoBrdgMtch(setId,ordrSide,pOrder,pCntrctBaseInfo, pPrdctInfo,
                        pBrdgOrdr->brdgOrgId,pMtchInfo,tranTime,pOrderRsp,pBrdgOrdr);
        RAISE_ERR(rc, RTN);
        *pbBrdgMtchFlg = TRUE;

        /* Delete that record in brdgmgmt */
        rc = MtchBrdgOrdrUpdt( TRUE, setId, ACTN_BRDG_MTCH, pBrdgOrdr ); 
        RAISE_ERR(rc, RTN);
    }
    else
    {
        RAISE_ERR(rc, RTN);
        /* no avaliable bridge order , exit */
        *pbBrdgMtchFlg = FALSE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   check the order is allow to entry order book or not
 * Parameters:
 *  pPrdctInfo  IN  product info
 *  pOrder      IN  Incoming order
 *  pMaintFlag  OUT maint flag
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
static ResCodeT DoMtchOrdr ( int32 setId,
                                pOrderT pOrder,
                                uint16 actnMask,
                                MtchInfoT * pMtchInfo,
                                pPrdctInfoT pPrdctInfo,
                                int64 tranTime,
                                char modFlg,
                                pOrderT * pCurrOrder,
                                pNewOrderSingleRspT pOrderRsp)
{

    BEGIN_FUNCTION ( "DoMtchOrdr" );
    ResCodeT rc = NO_ERR;
    int64 remainPeakQty;
    uint16 localActnMask;
    OrderFT newOrder;
    int32 ordrTypeMask;
    int64 ordrMgmtPos;


    int32 prdctId = pOrder->orderF.prdctId;


    SECTION ( "DoMtchOrdr" );
    ASSERT ( pOrder && pMtchInfo && pPrdctInfo && tranTime )

    localActnMask = 0;
    localActnMask |= actnMask;
    localActnMask |= ACTN_ADD_MNT;
    localActnMask |= ACTN_CONF_NO;
    localActnMask |= ACTN_ORDR_BK_NO;
    /* Log order */
    rc = MtchLogOrdr(TRUE, setId , localActnMask, pOrder, pMtchInfo);
    RAISE_ERR( rc, RTN );

    /* perform matchg */
    rc = PerformMtchg ( setId, pOrder, pPrdctInfo, pMtchInfo->ordrNoOld, tranTime , pOrderRsp);
    RAISE_ERR( rc, RTN );
    pOrder->orderF.tranTime = tranTime;
    

    ordrTypeMask = GET_ORDR_TYPE(pOrder->orderF.ordrMask);
    /* unmatch the qty */
    if (pOrder->orderF.ordrQty > 0)
    {
        /* WP */
        localActnMask = 0;
        localActnMask |= actnMask;
        localActnMask |= ACTN_PRT_FIL_MNT;
 
        localActnMask |= ACTN_CONF_NO;
        localActnMask |= ACTN_ORDR_BK_NO;
        pMtchInfo->ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
        pMtchInfo->tradePrc = pPrdctInfo->baseInfo.lstTrdPrc;
        /* not matching */
        if (!pOrder->orderF.ordrExeQty)
        {   
            pOrder->orderF.ordrSts = ORDR_STS_ACTIVE;
            rc = MtchLogOrdr(TRUE, setId , localActnMask, pOrder, pMtchInfo);
            RAISE_ERR( rc, RTN );
        }

        /* ordrExeRestrMask == ORDR_EXERESTR_IOC */
        if (pOrder->orderF.extOrdrType == EXT_ORD_TYPE_CLICK)
        {
            /* WP */
            localActnMask = 0;
            localActnMask |= actnMask;
            localActnMask |= ACTN_CANCEL_MNT;
            localActnMask |= ACTN_AUD_YES;
            localActnMask |= !pOrder->orderF.ordrExeQty ?
                            ACTN_CONF_ORDER : ACTN_CONF_NO;

            localActnMask |= ACTN_ORDR_BK_NO;
            pOrder->orderF.ordrSts = ORDR_STS_CANCEL;
            rc = MtchLogOrdr(TRUE, setId , localActnMask, pOrder, pMtchInfo);
            RAISE_ERR(rc, RTN);
        }
        else /* non IOC */
        {

            /* WP */
            localActnMask = 0;
            localActnMask |= actnMask;
            localActnMask |= ACTN_ADD_MNT;
            localActnMask |= !pOrder->orderF.ordrExeQty ?
                    ACTN_CONF_NO : ACTN_CONF_ORDER;

            localActnMask |= ACTN_ORDR_BK_YES;

            if (pOrder->orderF.ordrExeQty)
            {
                pMtchInfo->ordrPrtFilCod = MTCH_TYPE_PRT_FIL;
            }

            if (modFlg == WKSG_LIT_YES)
            {
                pOrder->orderF.ordrSts = ORDR_STS_ACTIVE;
                rc = MtchLogOrdr(TRUE, setId , localActnMask, pOrder, pMtchInfo);
                RAISE_ERR(rc, RTN);
                
                localActnMask = 0;
                localActnMask |= actnMask;
                localActnMask |= ACTN_ADD_MNT;
                localActnMask |= ACTN_AUD_NO;
                localActnMask |= ACTN_CONF_NO;
                localActnMask |= ACTN_ORDR_BK_NO;
                memcpy(&newOrder, &pOrder->orderF, sizeof (OrderFT));

                rc = MtchModOrdr(TRUE, FALSE, setId, pCurrOrder,&newOrder,localActnMask,pMtchInfo, NULL);
                RAISE_ERR(rc, RTN);
            }
            else
            {
                /* New order */
                rc = MtchAddOrdr(TRUE, FALSE, setId , localActnMask, pOrder, pMtchInfo, NULL);
                RAISE_ERR(rc, RTN);
            }
        } /*end of if the order restriction is not FOK & IOC*/
    }
    else   /*when pOrder->orderF.ordrQty <= 0*/
    {
        //　Full matched, just log the order
        /* WP */
        localActnMask = 0;
        localActnMask |= actnMask;
        localActnMask |= ACTN_MATCH_MNT;
        localActnMask |= ACTN_AUD_YES;
        localActnMask |= ACTN_CONF_NO;
        localActnMask |= ACTN_ORDR_BK_NO;

        pMtchInfo->ordrPrtFilCod = MTCH_TYPE_FULL_MTCH;
        pMtchInfo->tradePrc = pPrdctInfo->baseInfo.lstTrdPrc;
        pOrder->orderF.ordrSts = ORDR_STS_DEAL;
        rc = MtchLogOrdr(TRUE, setId , localActnMask, pOrder, pMtchInfo);
        RAISE_ERR( rc, RTN );
    }/*end if pOrder->orderF.ordrQty > 0*/
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrAdd(BOOL bRcrvOrdrFlg, BOOL bBrdgMtchOn, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp, pMtchInfoT pMtchInfo)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrAdd");
    ResCodeT                rc = NO_ERR;
    int32       prdctId = 0;
    MaintFlagT  maintFlag;
    MtchInfoT   mtchInfo;
    int32       actnMask = 0;
    BstGrpT             bstGrp;
    int32       bstOwnPrc = 0;
    int64       intrnlOrdrNo = 0;
    int64       ordrMgmtPos = 0;
    int32       ordrSide = GET_ORDR_SIDE(pOrder->orderF.ordrMask);
    BOOL        bBrdgMtchFlg = FALSE;
    prdctId = pOrder->orderF.prdctId;
    
    if (!bRcrvOrdrFlg)
    {
        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_ORD, &pOrder->orderF.ordrNo);
        RAISE_ERR(rc, RTN);
        
        pOrder->orderF.ordrEntTim = timestamp;
    
    }
    
    
    PerfStatInc(MOrdrEntry);

    pOrder->orderF.tranTime = timestamp;
    pOrder->orderF.ordrActiveTim = timestamp;

    /*---------------- initialize matchi info ----------------*/
    pMtchInfo->ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    pMtchInfo->ordrFreeCod = WKSG_LIT_NO;
    pMtchInfo->tradePrc = 0;

    rc = ChkOrdrMrktble (setId, pOrder, &maintFlag.mktblFlg,timestamp);
    RAISE_ERR( rc, RTN );

    rc = ChkOrdrWritable (pPrdctInfo,  pOrder, &maintFlag );
    RAISE_ERR( rc, RTN );

    /*----------------           Execute order logic           ----------------*/
    /* can be matched, do match logic */
    actnMask = 0;
    if ( maintFlag.mktblFlg == WKSG_LIT_MARKETABLE )
    {
        

        actnMask |= ACTN_ADD_CMD;

        /* Order match  */
        rc = DoMtchOrdr (setId, pOrder, actnMask, pMtchInfo, pPrdctInfo, timestamp, WKSG_LIT_NO,NULL , pOrderRsp);
        RAISE_ERR( rc, RTN );

        if ( pMtchInfo->ordrPrtFilCod != MTCH_TYPE_FULL_MTCH && bBrdgMtchOn )
        {
            rc = TryBrdgOrdrMtch(setId, pOrder,pPrdctInfo,pMtchInfo, timestamp, pOrderRsp, &bBrdgMtchFlg);
            RAISE_ERR(rc, RTN);
            
            if (bBrdgMtchFlg)
            {
                THROW_RESCODE(NO_ERR);
            }
        }

        /* no remaining amount */
        if (0) //todo if order type is FOK
        {

            /* cancel the order */
//            rc = OrdrBkFreeOrder(setId, &pOrder);
//            RAISE_ERR(rc, RTN);
        }
        else if ( pOrder->orderF.ordrQty == 0 )
        {
            /* format order response */
            rc = FmtOrdCnfrm( pOrder, pOrderRsp, &maintFlag, timestamp);
            RAISE_ERR(rc, RTN);
            
            pMtchInfo->ordrFreeCod = WKSG_LIT_YES;

//            rc = OrdrBkFreeOrder ( setId, &pOrder );
//            RAISE_ERR( rc, RTN );
        }
        else
        {
            
            maintFlag.mktblFlg = pMtchInfo->ordrPrtFilCod;
            /* format order response for no deal order or partial deal order. */
            rc = FmtOrdCnfrm( pOrder, pOrderRsp, &maintFlag, timestamp);
            RAISE_ERR(rc, RTN);

        }
    }
    /* in the else section, the order can't be matched. */
    else
    {
        /* market to limit order need check if it has order in order book or not */
        if (pOrder && 
            GET_ORDR_TYPE(pOrder->orderF.ordrMask) == ORDR_TYPE_MKTOL &&
            GET_ORDR_EXERESTR(pOrder->orderF.ordrMask) == ORDR_EXERESTR_NON)
        {
            /* Get best order */
            rc = GetBstGrp(setId, pOrder->orderF.prdctId,
                        ORDR_TRDRESTR_NO|ORDR_SIDE_NONE,
                        &bstGrp);
            RAISE_ERR(rc, RTN);

            /* if it has limit order in order book,then market order can convert to limit order */
            bstOwnPrc = (&bstGrp.bstBuyLmtPrc)[ordrSide];
            if (bstOwnPrc)
            {
                maintFlag.ordrWrtblFlg = WKSG_LIT_YES;
                pOrder->orderF.ordrExePrc = bstOwnPrc;
            }
            else
            {
                maintFlag.ordrWrtblFlg = WKSG_LIT_NO;
            }
        }

        /* need write into order book */
        if (maintFlag.ordrWrtblFlg == WKSG_LIT_YES)
        {
            actnMask = 0;
            actnMask |= ACTN_ADD_CMD;
            actnMask |= ACTN_ADD_MNT;
            actnMask |= ACTN_AUD_YES;
            actnMask |= ACTN_CONF_ORDER;
            actnMask |= ACTN_ORDR_BK_YES;
            
            rc = MtchAddOrdr(TRUE, FALSE, setId , actnMask, pOrder,pMtchInfo, NULL);
            RAISE_ERR( rc, RTN );
            
            /* format order response */
            rc = FmtOrdCnfrm( pOrder, pOrderRsp, &maintFlag, timestamp);
            RAISE_ERR(rc, NORTN);
        }
        else
        {
            actnMask = 0;
            actnMask |= ACTN_ADD_CMD;
            actnMask |= ACTN_ADD_MNT;
            actnMask |= ACTN_CONF_NO;
            actnMask |= ACTN_ORDR_BK_NO;

            //todo wrtie order qty as pOrder Qty

            /* log the order entry */
            rc = MtchLogOrdr(TRUE, setId,  actnMask,pOrder, pMtchInfo);
            RAISE_ERR(rc, RTN);

            actnMask = 0;
            actnMask |= ACTN_ADD_CMD;
            actnMask |= ACTN_CANCEL_MNT;
            actnMask |= ACTN_CONF_ORDER;
            actnMask |= ACTN_ORDR_BK_NO;

            /* log the order cancel */
            rc = MtchLogOrdr(TRUE, setId, actnMask,pOrder, pMtchInfo);
            RAISE_ERR(rc, RTN);
            
            /* format order response */
            rc = FmtOrdCnfrm( pOrder, pOrderRsp, &maintFlag, timestamp);
            RAISE_ERR(rc, NORTN);
            
            pMtchInfo->ordrFreeCod = WKSG_LIT_YES;
//            rc = OrdrBkFreeOrder(setId, &pOrder);
//            RAISE_ERR(rc, RTN);

//            if ( orderTypeMask == ORDR_TYPE_MARKT) todo
//            {
//               RAISE_ERR(ERCD_INVALID_MKT_ORDER, RTN);
//            }
//            else if (orderTypeMask == ORDR_TYPE_MKTOL )
//            {
//               RAISE_ERR(ERCD_INVALID_MKT_TO_LMT_ORDER, RTN);
//            }
        }
    }                           /* End of order process */
    EXIT_BLOCK();

    

    RETURN_RESCODE;;
}





/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsBilOrdrAdd(BOOL bRcrvOrdrFlg, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pAskOrder,pOrderT pBidOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp, pMtchInfoT pMtchInfo)
{
    BEGIN_FUNCTION("MtchrPrcsBilOrdrAdd");
    ResCodeT                rc = NO_ERR;
    int32 prdctId = 0;
    int64 bilOrdrNo = 0;
    MtchInfoT mtchInfo;

    int64 ordrMgmtPos = 0;
    int32 actnMask = 0;
    
   

    prdctId = pAskOrder->orderF.prdctId;
    
    if (!bRcrvOrdrFlg)
    {
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_BIL_ORD, &bilOrdrNo);
        RAISE_ERR(rc, RTN);
        
        pAskOrder->orderF.specOrdrNo = bilOrdrNo;
        pBidOrder->orderF.specOrdrNo = bilOrdrNo;
    }
    
    rc = MtchrPrcsOrdrAdd(bRcrvOrdrFlg, TRUE, setId, pPrdctInfo, pBidOrder, timestamp, pOrderRsp,&mtchInfo);
    RAISE_ERR(rc, RTN);
    
    if ( mtchInfo.ordrPrtFilCod == MTCH_TYPE_FULL_MTCH )
    {
        /* Save the order entry */
        rc = MtchSaveBilOrdr(TRUE, setId, ACTN_DEL_CMD, ORDR_STS_DEAL,pBidOrder, pAskOrder,pBidOrder->orderT.slotNo,pAskOrder->orderT.slotNo);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        rc = MtchrPrcsOrdrAdd(bRcrvOrdrFlg, TRUE, setId, pPrdctInfo, pAskOrder, ++timestamp, pOrderRsp,&mtchInfo);
        RAISE_ERR(rc, RTN);

        if ( mtchInfo.ordrPrtFilCod == MTCH_TYPE_FULL_MTCH )
        {   /* Ask side matched, cancel the bid side */
            rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pBidOrder, ++timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN);
            
            /* Save the order entry */
            rc = MtchSaveBilOrdr(TRUE, setId, ACTN_DEL_CMD, ORDR_STS_DEAL,pBidOrder, pAskOrder,pBidOrder->orderT.slotNo,pAskOrder->orderT.slotNo);
            RAISE_ERR(rc, RTN);
        }
        else
        {
            /* Save the order entry */
            rc = MtchSaveBilOrdr(TRUE, setId, ACTN_BOOK_CMD, ORDR_STS_ACTIVE,pBidOrder, pAskOrder,pBidOrder->orderT.slotNo,pAskOrder->orderT.slotNo);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsBilOrdrSave(BOOL bRcrvOrdrFlg, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pAskOrder,pOrderT pBidOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsBilOrdrSave");
    ResCodeT            rc = NO_ERR;
    int32               actnMask = 0;
    int32               prdctId = 0;
    int64               bilOrdrNo = 0;
    MaintFlagT          maintFlag;

    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;

    prdctId = pAskOrder->orderF.prdctId;
    
    if (!bRcrvOrdrFlg)
    {
        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_BIL_ORD, &bilOrdrNo);
        RAISE_ERR(rc, RTN);

        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_ORD, &pBidOrder->orderF.ordrNo);
        RAISE_ERR(rc, RTN);

        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_ORD, &pAskOrder->orderF.ordrNo);
        RAISE_ERR(rc, RTN);

        pAskOrder->orderF.specOrdrNo = bilOrdrNo;
        pBidOrder->orderF.specOrdrNo = bilOrdrNo;

        pAskOrder->orderF.ordrEntTim = timestamp;
        pBidOrder->orderF.ordrEntTim = timestamp;
    }
    
    pBidOrder->orderF.extOrdrType = EXT_ORD_TYPE_BIL;
    pAskOrder->orderF.extOrdrType = EXT_ORD_TYPE_BIL;
    
    pBidOrder->orderF.ordrSts = ORDR_STS_FREEZE;
    pAskOrder->orderF.ordrSts = ORDR_STS_FREEZE; /* the status will be the same as order freeze*/
    /*----------------           Execute order logic           ----------------*/
    /* Save the order entry */
    rc = MtchSaveBilOrdr(TRUE, setId, ACTN_ADD_CMD, ORDR_STS_FREEZE, pBidOrder, pAskOrder,pBidOrder->orderT.slotNo,pAskOrder->orderT.slotNo);
    RAISE_ERR(rc, RTN);
    
    /* format order response */
    rc = FmtOrdCnfrm( pBidOrder, pOrderRsp, &maintFlag, timestamp);
    RAISE_ERR(rc, RTN);

    /* format order response */
    rc = FmtOrdCnfrm( pAskOrder, pOrderRsp, &maintFlag, timestamp);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}






/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrSave(BOOL bRcrvOrdrFlg, int32 setId, pPrdctInfoT pPrdctInfo, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrSave");
    ResCodeT            rc = NO_ERR;
    int32               prdctId = 0;
    int32               actnMask = 0;
    int64               ordrMgmtPos = 0;
    MaintFlagT          maintFlag;

    
    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;
    

    prdctId = pOrder->orderF.prdctId;
    
    if (!bRcrvOrdrFlg)
    {
        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_ORD, &pOrder->orderF.ordrNo);
        RAISE_ERR(rc, RTN);
        
        pOrder->orderF.ordrEntTim = timestamp;
    }

    pOrder->orderF.tranTime = timestamp;
    pOrder->orderF.ordrActiveTim = 0;
    pOrder->orderF.ordrSts = ORDR_STS_FREEZE; /* the status will be the same as order freeze*/
    /*----------------           Execute order logic           ----------------*/
    /* can be matched, do match logic */

    actnMask = 0;
    actnMask |= ACTN_ADD_CMD;
    actnMask |= ACTN_ADD_MNT;
    actnMask |= ACTN_CONF_NO;
    actnMask |= ACTN_ORDR_BK_NO;

    /* Save the order entry */
    rc = MtchSaveOrdr(TRUE, setId,  actnMask,pOrder);
    RAISE_ERR(rc, RTN);

    /* format order response */
    rc = FmtOrdCnfrm( pOrder, pOrderRsp, &maintFlag, timestamp);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrCancel(int32 setId, int32 ordrSts, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrCancel");
    ResCodeT        rc = NO_ERR;
    pOrderT         pCnclOrder = NULL;
    int32           actnMask  = 0;
    MtchInfoT       mtchInfo = {0};
    int32           prdctId= 0;
    uint32           ordrMgmtPos = 0;
    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt  = NULL;  
    int32           oldOrdSts;

    MaintFlagT          maintFlag = {0};
    
    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;

    mtchInfo.ordrNoOld = 0;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    mtchInfo.tradePrc = 0;
    
    rc = OrdrMgmtNrmlGet(setId, pOrder->orderF.ordrNo, &pOrdrMgmt, &pCnclOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    oldOrdSts =  pCnclOrder->orderF.ordrSts;
    pCnclOrder->orderF.ordrSts = ordrSts;
    pCnclOrder->orderF.ordrActiveTim = 0;

    rc = PrdctInfoGetByPosExt(pCnclOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );
    
    actnMask = 0;
    actnMask |= ACTN_DEL_CMD;
    actnMask |= ACTN_DEL_MNT;
    actnMask |= ACTN_AUD_YES;
    actnMask |= ACTN_CONF_ORDER;
    actnMask |= ACTN_ORDR_BK_YES;
    
    mtchInfo.ordrNoOld = pCnclOrder->orderF.ordrNo;
    
    /* Delete order after matching */
    rc = MtchDelOrdr(TRUE, setId, &pCnclOrder,
                    timestamp,
                    actnMask,
                    &mtchInfo,
                    pPrdctInfo,
                    oldOrdSts == ORDR_STS_ACTIVE);
    RAISE_ERR(rc, RTN);

    FmtOrdCnfrm(  pCnclOrder, pOrderRsp, &maintFlag, timestamp);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ChkAndCnclOrdrExpByPrdctId(int32 setId, int32 prdctId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("ChkAndCnclOrdrExpByPrdctId");
    ResCodeT        rc = NO_ERR;
    osSListModeT *  pExpOrdrListMode = NULL;
    OrderT          tmpOrdr;
    int32           iter = -1;
    
    pOrderT         pTmpOrdr = NULL;

    OrdrMgmtRcrdT OrdrMgmtInfo;
    uint32 nodePos = CMN_HASH_ITER_START;

    rc = SetOrdrExpListMode(setId, prdctId,&pExpOrdrListMode);
    RAISE_ERR(rc, RTN);
    
    do
    {
        /* Get next one */
        rc = IterNextOrdrExpListMode(pExpOrdrListMode, &pTmpOrdr, &iter);
        RAISE_ERR(rc, RTN); 
        
        if (pTmpOrdr != NULL)
        {
            memset( &tmpOrdr, 0x00, sizeof(OrderT) );

            /* Cancel the expired order */
            LOG_INFO("orderNo %lld, exptime %lld, now %lld", pTmpOrdr->orderF.ordrNo, pTmpOrdr->orderF.ordrExpTim,timestamp);
            if (pTmpOrdr->orderF.ordrExpTim < timestamp)
            {
                switch (pTmpOrdr->orderF.extOrdrType)
                {
                    case EXT_ORD_TYPE_NORMAL:
                        LOG_INFO("Invalid Normal order %lld", pTmpOrdr->orderF.ordrNo);
                        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_INVALID, pTmpOrdr, timestamp, pOrderRsp);
                        RAISE_ERR(rc, RTN);
                        break;

                    case EXT_ORD_TYPE_BIL:
                        tmpOrdr.orderF.ordrNo = pTmpOrdr->orderF.specOrdrNo;
                        LOG_INFO("Invalid BIL order %lld", tmpOrdr.orderF.ordrNo);
                        rc = MtchrPrcsBilOrdrCancel(setId, ORDR_STS_INVALID, &tmpOrdr, timestamp, pOrderRsp);
                        RAISE_ERR(rc, RTN);
                        break;

                    case EXT_ORD_TYPE_OCO:
                        tmpOrdr.orderF.ordrNo = pTmpOrdr->orderF.specOrdrNo;
                        LOG_INFO("Invalid OCO order %lld", tmpOrdr.orderF.ordrNo);
                        rc = MtchrPrcsOcoOrdrCancel(setId, ORDR_STS_INVALID, &tmpOrdr, timestamp, pOrderRsp);
                        RAISE_ERR(rc, RTN);
                        break;

                    default:
                        break;
                }
            }
        }
        else
        {
            break;
        }
    }while (TRUE);

    /* TODO:Deal expire freeze order */
    while (TRUE)
    {
        rc = OrdrMgmtIter( setId, &nodePos, &OrdrMgmtInfo );
        if (nodePos == CMN_LIST_NULL_NODE)
        {
            break;
        }
        else if ( OrdrMgmtInfo.ordrSts != ORDR_STS_FREEZE )
        {
            continue;
        }
        else
        {  
            RAISE_ERR(rc,RTN);

            rc = OrdrBkGetOrdr( setId, OrdrMgmtInfo.ordrSlot[0], &pTmpOrdr );
            RAISE_ERR( rc, RTN );

            if (pTmpOrdr->orderF.ordrExpTim < timestamp)
            {
                switch (pTmpOrdr->orderF.extOrdrType)
                {
                    case EXT_ORD_TYPE_NORMAL:
                        LOG_INFO("Invalid Normal order %lld", pTmpOrdr->orderF.ordrNo);
                        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_INVALID, pTmpOrdr, timestamp, pOrderRsp);
                        RAISE_ERR(rc, RTN);
                        break;

                    case EXT_ORD_TYPE_BIL:
                        tmpOrdr.orderF.ordrNo = pTmpOrdr->orderF.specOrdrNo;
                        LOG_INFO("Invalid BIL order %lld", tmpOrdr.orderF.ordrNo);
                        rc = MtchrPrcsBilOrdrCancel(setId, ORDR_STS_INVALID, &tmpOrdr, timestamp, pOrderRsp);
                        RAISE_ERR(rc, RTN);
                        break;

                    case EXT_ORD_TYPE_OCO:
                        tmpOrdr.orderF.ordrNo = pTmpOrdr->orderF.specOrdrNo;
                        LOG_INFO("Invalid OCO order %lld", tmpOrdr.orderF.ordrNo);
                        rc = MtchrPrcsOcoOrdrCancel(setId, ORDR_STS_INVALID, &tmpOrdr, timestamp, pOrderRsp);
                        RAISE_ERR(rc, RTN);
                        break;

                    default:
                        break;
                }
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;;
}






/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT FreezeOrdrByOrg(int32 setId, int32 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("FreezeOrdrByOrg");
    ResCodeT        rc = NO_ERR;
    pOrderT         pTmpOrdr = NULL;


    EXIT_BLOCK();
    RETURN_RESCODE;;
}




/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT FreezeOrgOrdrByPrdctId(int32 setId, int64 prdctPos, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("FreezeOrgOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pNextOrgOrdr = NULL;
    
    rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
    RAISE_ERR(rc, RTN); 
    
    while (pNextOrgOrdr)
    {
        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_FREEZE, pNextOrgOrdr, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN); 
        
        rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
        RAISE_ERR(rc, RTN); 
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CnclOrgOrdrByPrdctId(int32 setId, int64 prdctPos, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("CnclOrgOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pNextOrgOrdr = NULL;
    
    rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
    RAISE_ERR(rc, RTN); 
    
    while (pNextOrgOrdr)
    {
        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pNextOrgOrdr, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN); 
        
        rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
        RAISE_ERR(rc, RTN); 
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}





/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CnclUserOrdrByPrdctId(int32 setId, int64 prdctPos, int64 orgId,int32 usrPos, int64 timestamp, int32 * pOrdCnt, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("CnclUserOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pNextOrgOrdr = NULL;
    int32           bkOrdCnt = 0;
    
    rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
    RAISE_ERR(rc, RTN); 
    
    while (pNextOrgOrdr)
    {
        if (usrPos != pNextOrgOrdr->orderF.userIdx)
        {
            continue;
        }
        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pNextOrgOrdr, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN); 
        
        bkOrdCnt++;
        
        rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
        RAISE_ERR(rc, RTN); 
    }
    RAISE_ERR(rc, RTN);

    * pOrdCnt = bkOrdCnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT FreezeUserOrdrByPrdctId(int32 setId, int64 prdctPos, int64 orgId,int32 usrPos, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("FreezeUserOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pNextOrgOrdr = NULL;
    
    rc = OrdrBkGetOrdrByOrgPos( setId, orgId, prdctPos, &pNextOrgOrdr, &nxtSlt);
    RAISE_ERR(rc, RTN); 
    
    while (pNextOrgOrdr)
    {
        if (usrPos != pNextOrgOrdr->orderF.userIdx)
        {
            continue;
        }
        rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_FREEZE, pNextOrgOrdr, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN); 
        
        rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
        RAISE_ERR(rc, RTN); 
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsFreezeOrgOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsFreezeOrgOrdrBySet");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    pOrgInfoT           pOrgInfo = NULL;    
    
    rc = OrgInfoGetByIdExt(orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = FreezeOrgOrdrByPrdctId(setId, pData->pos, pOrgInfo->pos, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
        
    }
    
    if (pOrderRsp->slotCnt )
    {
        rc = SendOrdTrdToClnt(pOrderRsp);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        THROW_RESCODE( APIERR_CODE_INVLD_ORDR );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsCnclOrgOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsCnclOrgOrdrBySet");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    pOrgInfoT           pOrgInfo = NULL;    
    
    rc = OrgInfoGetByIdExt(orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = CnclOrgOrdrByPrdctId(setId, pData->pos, pOrgInfo->pos, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
        
    }
    
    if (pOrderRsp->slotCnt )
    {
        rc = SendOrdTrdToClnt(pOrderRsp);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsFreezeOrgOrdr(int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsFreezeOrgOrdr");
    ResCodeT            rc = NO_ERR;
    int32   set = -1;

    static vectorT *       pSetVct = NULL;
    
    if (!pSetVct)
    {
        rc = GetAllSetIdsPtr(&pSetVct);
        RAISE_ERR(rc, RTN);
    }
    
    while (1)
    {
        /*找到当前主机所负责set*/
        BitFindFS(pSetVct, set + 1, MAX_SET_CNT, &set);
        if (set == -1)
        {
            break;
        }

        rc = MtchrPrcsFreezeOrgOrdrBySet(set, orgId, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}





/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsCnclOrgOrdrByUsr(uint32 usrPos, uint32 orgPos, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsCnclOrgOrdrByUsr");
    ResCodeT            rc = NO_ERR;
    int32   set = -1;

    static vectorT *       pSetVct = NULL;
    
    if (!pSetVct)
    {
        rc = GetAllSetIdsPtr(&pSetVct);
        RAISE_ERR(rc, RTN);
    }
    
    while (1)
    {
        /*找到当前主机所负责set*/
        BitFindFS(pSetVct, set + 1, MAX_SET_CNT, &set);
        if (set == -1)
        {
            break;
        }
        
        rc = MtchrPrcsOrdrCnclByUser(set, timestamp,usrPos, orgPos, pOrderRsp);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrCnclByUser(int32 setId, int64 timestamp,int32 usrPos,int32 orgPos, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrCnclByUser");
    ResCodeT            rc = NO_ERR;
    uint32             contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    int32               ordCnt = 0;
    int32               ordTotCnt = 0;
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = CnclUserOrdrByPrdctId(setId, pData->pos, orgPos, usrPos, timestamp, &ordCnt, pOrderRsp );
        RAISE_ERR(rc, RTN);

        ordTotCnt += ordCnt;
    }
    
    if ( !ordTotCnt )
    {
        RAISE_ERR( APIERR_CODE_INVLD_USR_ORDR, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrFreezeByUser(int32 setId, int64 timestamp,int32 usrPos,int32 orgPos, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrFreezeByUser");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = FreezeUserOrdrByPrdctId(setId, pData->pos, orgPos, usrPos, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
        
    }
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}





/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrExpireChk(int32 setId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrExpireChk");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = ChkAndCnclOrdrExpByPrdctId(setId, pData->pos, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
        
    }
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchFlushMktDat(BOOL bNeedMemTxn,int32 set, int64 timestamp )
{
    BEGIN_FUNCTION( "MtchFlushMktDat" );
    ResCodeT        rc = NO_ERR;

    pMFlushMktDatT      pMFlushMktDat = NULL;
    
    if (bNeedMemTxn)
    {

        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_FLUSH_MKT, sizeof(MFlushMktDatT) , (void **)&pMFlushMktDat);
        RAISE_ERR( rc, RTN );
         
        pMFlushMktDat->setId  = set;
        pMFlushMktDat->timestamp  = timestamp;

        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    rc = UpdInsideMktInfo(set, timestamp);
    RAISE_ERR(rc, RTN);
    
    ResetMktInfoUpdVec(set); 

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Log order date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchUpdtPrdctInfo(BOOL bNeedMemTxn,int64 prdctId, pPrdctBaseInfoT pPrdctBaseInfo)
{
    BEGIN_FUNCTION( "MtchUpdtPrdctInfo" );
    ResCodeT        rc = NO_ERR;

    pMPrdctInfoUpdtT        pMPrdctInfoUpdt = NULL;
    pPrdctInfoT             pPrdctInfo = NULL;
    
    if (bNeedMemTxn)
    {

        rc = MemTxnAddElemPrep(gCfgValue.setId,MT_TYP_PRDCT_INFO_UPDT, sizeof(MPrdctInfoUpdtT) , (void **)&pMPrdctInfoUpdt);
        RAISE_ERR( rc, RTN );
         
        pMPrdctInfoUpdt->prdctId  = prdctId;
        
        memcpy(&pMPrdctInfoUpdt->prdctBaseInfo, pPrdctBaseInfo, sizeof(PrdctBaseInfoT));

        rc = MemTxnAddElemClose();
        RAISE_ERR( rc, RTN );
    }
    
    
    rc = PrdctInfoGetByPosExt(prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );
    
    memcpy(&pPrdctInfo->baseInfo, pPrdctBaseInfo, sizeof(PrdctBaseInfoT));

    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsFlushMktDat(int32 setId)
{
    BEGIN_FUNCTION("MtchrPrcsFlushMktDat");
    ResCodeT            rc = NO_ERR;
    
    int64   timestamp;

    GetSysTimestamp( &timestamp );

    if ( NeedUpdMktInfo(setId))
    {
        rc = MtchFlushMktDat(TRUE,setId,timestamp);
        RAISE_ERR(rc, RTN);
        
        PerfStatInc(MktPushTrgr);
    }
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ChkMktbleAmnt( pPrdctInfoT pPrdctInfo, int64 orgPos, 
                        pOrderT pBkOrdr, BOOL * pMktbleFlg, int64 * pMktbleAmnt )
{
    BEGIN_FUNCTION("ChkMktbleAmnt");
    ResCodeT            rc = NO_ERR;

    int64   tmpAmnt = 0;
    BOOL    avalFlag = FALSE;
    pOrgInfoT       pBookOrdrOrgInfo = NULL;
    pOrgInfoT       pNeedBrdgOrgInfo = NULL;

    * pMktbleAmnt = 0;
    * pMktbleFlg = FALSE; 

    /* skip the self org order */  
    if (pBkOrdr->orderF.entyIdxNo == orgPos)
    {
        LOG_DEBUG("Found the org id in best order list %d", orgPos);
        THROW_RESCODE(NO_ERR);
    }

    if ( pBkOrdr->orderF.brdgFlag == INT_ORD_FLAG_BRDG )
    {
        //LOG_DEBUG("Order [%lld] has been bridged", pBkOrdr->orderF.ordrNo);
        THROW_RESCODE(NO_ERR);
    }

    //todo
    rc = OrgInfoGetByPosExt( orgPos, &pNeedBrdgOrgInfo );
    RAISE_ERR( rc, RTN );

    rc = OrgInfoGetByPosExt( pBkOrdr->orderF.entyIdxNo, &pBookOrdrOrgInfo );
    RAISE_ERR( rc, RTN );

    /* check credit operating status */
    if ( pBookOrdrOrgInfo->crdtOprtngSt )
    {
        * pMktbleFlg = FALSE;
        THROW_RESCODE( NO_ERR );
    }

    /* check normal credit of bk and onln*/
    rc = GetCreditRmnAmnt( pNeedBrdgOrgInfo->orgId, pBookOrdrOrgInfo->orgId, &avalFlag, &tmpAmnt );
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR( rc, RTN );

    /* Must not have credit between bookordr org and onln org */
    if ( !avalFlag )
    {
        * pMktbleAmnt = pBkOrdr->orderF.ordrExePrc;
        * pMktbleFlg = TRUE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CreateBrdgOrdr(int32 setId, pCntrctBaseInfoT  pCntrctInfo, int64 brdgOrgPos, pOrderT pBkOrdr, int64 ordrPrc, int64 ordrQty, int64 brdgFee, pOrderT * ppBrdgOrdr)
{
    BEGIN_FUNCTION("CreateBrdgOrdr");
    ResCodeT            rc = NO_ERR;
    int32 ordrSide = GET_ORDR_SIDE(pBkOrdr->orderF.ordrMask);
    
    pOrgInfoT       pBrdgOrgRec = NULL;
    pBrdgOrgInfoT   pBrdgOrgInfo = NULL;
    pUsrBaseInfoT   pBrdgDefTrdr = NULL;
    
    rc =  OrdrBkCreateOrdr(setId, ppBrdgOrdr);
    RAISE_ERR(rc, RTN);
    
    memcpy(&(*ppBrdgOrdr)->orderF, &pBkOrdr->orderF, sizeof(OrderFT));

    if (ordrSide == ORDR_SIDE_BUY)
    {
        (*ppBrdgOrdr)->orderF.ordrMask |= ORDR_SIDE_SELL;
    }
    else if (ordrSide == ORDR_SIDE_SELL)
    {
        (*ppBrdgOrdr)->orderF.ordrMask &= ORDR_SIDE_BUY;
    }
    
    (*ppBrdgOrdr)->orderF.remPkQty = ordrQty;
    (*ppBrdgOrdr)->orderF.ordrExePrc = ordrPrc;
    (*ppBrdgOrdr)->orderF.ordrQty = ordrQty;
    (*ppBrdgOrdr)->orderF.brdgFee = brdgFee;
    (*ppBrdgOrdr)->orderF.extOrdrType = EXT_ORD_TYPE_BRDG;

    rc = OrgInfoGetByPosExt( brdgOrgPos, &pBrdgOrgRec );
    RAISE_ERR( rc, RTN );

    rc = BrdgOrgInfoGetByIdExt( pBrdgOrgRec->orgId, &pBrdgOrgInfo );
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByNameExt( pBrdgOrgInfo->usrLgnNm, &pBrdgDefTrdr );
    RAISE_ERR( rc, RTN );

    (*ppBrdgOrdr)->orderF.entyIdxNo =  brdgOrgPos;
    (*ppBrdgOrdr)->orderF.userIdx =  pBrdgDefTrdr->pos;
       
    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   check if brdg org has credit for both side
 * Parameters:
 *  needBrdgOrgPos  IN  need bridge org position
 *  ordrbkOrgPos    IN  order in
 *  brdgOrgPos      IN  Incoming order
 *  pAvalFlag       OUT bridge org available flag.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CheckBrdgOrg( int64 needBrdgOrgPos, int64 ordrbkOrgPos, 
                pBrdgOrgInfoT pBrdgOrgInfo, BOOL * pAvalFlag, int64 * pBrdgFee )
{
    BEGIN_FUNCTION("CheckBrdgOrg");
    ResCodeT            rc = NO_ERR;

    pOrgInfoT       pBrdgOrgRec = NULL;
    pOrgInfoT       pNeedBrdgOrgInfo = NULL;
    pOrgInfoT       pOrdrBookOrgInfo = NULL;
    pCreditBrdgT    pBrdg2NeedCrdtInfo = NULL;
    pCreditBrdgT    pBrdg2OdbkCrdtInfo = NULL;

    int64           tmpAmnt = 0;
    int64           currBrdgFee = 0;

    * pAvalFlag = FALSE;
    * pBrdgFee = -1;

    if ( !pBrdgOrgInfo->brdgOrgSt )
    {
        * pAvalFlag = FALSE;
        THROW_RESCODE( NO_ERR );
    }

    /* check bridge credit */
    rc = OrgInfoGetByPosExt( needBrdgOrgPos, &pNeedBrdgOrgInfo );
    RAISE_ERR( rc, RTN );

    rc = OrgInfoGetByPosExt( ordrbkOrgPos, &pOrdrBookOrgInfo );
    RAISE_ERR( rc, RTN );

    /* These 3 org must be different */
    if ( pNeedBrdgOrgInfo->orgId == pBrdgOrgInfo->orgId ||
            pOrdrBookOrgInfo->orgId == pBrdgOrgInfo->orgId )
    {
        THROW_RESCODE( NO_ERR );
    }

    rc = BridgeCreditInfoGetByKeyExt( pBrdgOrgInfo->orgId, pNeedBrdgOrgInfo->orgId, &pBrdg2NeedCrdtInfo );
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR( rc, RTN );
    if ( !pBrdg2NeedCrdtInfo->st || !pBrdg2NeedCrdtInfo->brdgRlFlag )
    {
        * pAvalFlag = FALSE;
        THROW_RESCODE( NO_ERR );
    }

    rc = BridgeCreditInfoGetByKeyExt( pBrdgOrgInfo->orgId, pOrdrBookOrgInfo->orgId, &pBrdg2OdbkCrdtInfo );
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR( rc, RTN );
    if ( !pBrdg2OdbkCrdtInfo->st || !pBrdg2OdbkCrdtInfo->brdgRlFlag )
    {
        * pAvalFlag = FALSE;
        THROW_RESCODE( NO_ERR );
    }

    /* check credit operating status */
    rc = OrgInfoGetByIdExt( pBrdgOrgInfo->orgId, &pBrdgOrgRec );
    RAISE_ERR( rc, RTN );

    if ( pBrdgOrgRec->crdtOprtngSt )
    {
        * pAvalFlag = FALSE;
        THROW_RESCODE( NO_ERR );
    }

    /* check normal credit */
    rc = GetCreditRmnAmnt( pNeedBrdgOrgInfo->orgId, pBrdgOrgInfo->orgId, pAvalFlag, &tmpAmnt );
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR( rc, RTN );

    rc = GetCreditRmnAmnt( pOrdrBookOrgInfo->orgId, pBrdgOrgInfo->orgId, pAvalFlag, &tmpAmnt );
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR( rc, RTN );

    * pBrdgFee = pBrdg2OdbkCrdtInfo->brdgFee;

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT SelectBrdgOrg( int32 setId, int64 needBrdgOrgPos, int64 ordrbkOrgPos,  
                        pOrderT pBkOrdr, int64 *pBrdgOrgPos, int64*  pBrdgFee )
{
    BEGIN_FUNCTION("SelectBrdgOrg");
    ResCodeT            rc = NO_ERR;
    uint32              currBrdgOrgPos = CMN_LIST_NULL_NODE;
    uint32              lstBrdgOrgPos = CMN_LIST_NULL_NODE;
    uint32              selectBrdgOrgPos = CMN_LIST_NULL_NODE;
    pBrdgOrgInfoT       pBrdgOrgInfo = NULL;
    int64               currBrdgFee = 0, lstBrdgFee = 0, selectBrdgFee = 0;
    
    pOrgInfoT           pOrgInfo     = NULL;
    pBrdgOrgCtrlT       pBrdgOrgCtrl = NULL;
    BOOL                avalFlag     = FALSE;
    
    rc = BrdgOrgGetCtrl(&pBrdgOrgCtrl);
    RAISE_ERR( rc, RTN );
    
    while (TRUE)
    {
        rc = BrdgOrgInfoIterExt(&currBrdgOrgPos, &pBrdgOrgInfo);
        RAISE_ERR( rc, RTN );

        if (CMN_LIST_NULL_NODE == currBrdgOrgPos)
        {
            break;
        }

        rc = CheckBrdgOrg( needBrdgOrgPos, ordrbkOrgPos, pBrdgOrgInfo, &avalFlag, &currBrdgFee );
        RAISE_ERR( rc, RTN );

        if ( !avalFlag )
        {
            continue;
        }

        if ((selectBrdgFee == 0) || (selectBrdgFee && currBrdgFee<selectBrdgFee))
        {
            selectBrdgFee = currBrdgFee;
            selectBrdgOrgPos = currBrdgOrgPos;
        }        
    }

    if (CMN_LIST_NULL_NODE == selectBrdgOrgPos)
    {
        *pBrdgOrgPos = CMN_LIST_NULL_NODE;
        THROW_RESCODE( NO_ERR );
    }

    rc = BrdgOrgInfoGetByPosExt( selectBrdgOrgPos, &pBrdgOrgInfo );
    RAISE_ERR( rc, RTN );

    rc = OrgInfoGetByIdExt( pBrdgOrgInfo->orgId, &pOrgInfo );
    RAISE_ERR( rc, RTN );

    *pBrdgFee = selectBrdgFee;
    *pBrdgOrgPos = pOrgInfo->pos;
  
    EXIT_BLOCK();
    RETURN_RESCODE;;
}
/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT ChkNeedBrdgOrgInOrdrBk( int32 setId, int32 ordrSide, int32 needBrdgMask, 
                                    int64 needBrdgOrgPos, pPrdctInfoT pPrdctInfo, int64 brdgFee,
                                    BOOL * pNeedBrdgOrdrHasBstOrdr, pOrderT * ppOutOrder )
{
    BEGIN_FUNCTION("ChkNeedBrdgOrgInOrdrBk");
    ResCodeT            rc = NO_ERR;
    pOrderT             pNeedBrdgBkOrdr = NULL,pNxtNeedBrdgBkOrdr = NULL;
    
    int32 needOrdrSide = GET_ORDR_SIDE( needBrdgMask );
    
    * pNeedBrdgOrdrHasBstOrdr = FALSE;
    
    rc = GetBest(setId, pPrdctInfo->pos, needBrdgMask,  &pNeedBrdgBkOrdr );
    RAISE_ERR( rc, RTN );
  
    while (pNeedBrdgBkOrdr)
    {
        PerfStatInc(MOrdrBrdgng);
        if ( ordrSide == ORDR_SIDE_BUY &&
            pNeedBrdgBkOrdr->orderF.ordrExePrc + brdgFee > (&pPrdctInfo->bstMktInfoGrp[0].bstBidPrc)[ordrSide] )
        {
            break;
        }
        if ( ordrSide == ORDR_SIDE_SELL &&
            pNeedBrdgBkOrdr->orderF.ordrExePrc - brdgFee < (&pPrdctInfo->bstMktInfoGrp[0].bstBidPrc)[ordrSide] )
        {
            break;
        }

        if (pNeedBrdgBkOrdr->orderF.entyIdxNo == needBrdgOrgPos)
        {
            LOG_DEBUG("The select org which need to build bridge order has the best order in the opposite side ");
            * pNeedBrdgOrdrHasBstOrdr = TRUE;
            * ppOutOrder = pNeedBrdgBkOrdr;
            break;
        }
        
        rc = GetNextOrder(setId, pPrdctInfo->pos, needBrdgMask,  pNeedBrdgBkOrdr, &pNxtNeedBrdgBkOrdr );
        RAISE_ERR( rc, RTN );
        
        pNeedBrdgBkOrdr = pNxtNeedBrdgBkOrdr;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT DoBrdgByOrdrBkSide(int32 ordrBkSide,int64 orgPos, pCntrctBaseInfoT pCntrctInfo, int64 timestamp, pNewOrderSingleRspT pOrderRsp, BOOL * pBrdgScsFlg)
{
    BEGIN_FUNCTION("DoBrdgByOrdrBkSide");
    ResCodeT            rc = NO_ERR;
    pPrdctInfoT         pPrdctInfo = NULL;
    int32               trdResMask = 0, tempMask = 0, needBrdgMask = 0;
    pOrderT             pBkOrdr = NULL,  pNxtOrdr = NULL, pBrdgOrderForBk = NULL, pNeedBrdgBkOrdr = NULL;
    BstGrpT             bstGrp;
    int64               mktbleAmnt = 0, brdgFee = 0, brdgOrgPos = 0;
    BOOL                bMktbleFlg = FALSE, bHasBrdgOrgFlg = FALSE, bNeedBrdgOrdrHasBstOrdr = FALSE;
    MtchInfoT           mtchInfo = {0};
    BrdgOrdrRcrdT       brdgOrdr;
    pBrdgOrdrRcrdT      pBrdgOrdr = NULL;
    pOrgInfoT           pOrgInfo = NULL, pBrdgOrgInfo = NULL;
    uint32               brdgOrdrPos;
    int64               brdgOrdrPrc = 0, brdgOrdrQty = 0;
    /* Need bridge order means the entity which select as the entity who need to build a bridge. 
        Order BK order means the best order in the order book. 
        bridge org is the valid bridge org who will play the bridging role. */
    
    rc = PrdctInfoGetByNameExt(pCntrctInfo->cntrctName, &pPrdctInfo);
    RAISE_ERR( rc, RTN );
    
    /* get best order for the o*/
    rc = GetTrdResFromPrdctInfo(pPrdctInfo, &trdResMask);
    RAISE_ERR( rc, RTN );
    
    tempMask = ordrBkSide | trdResMask;
    needBrdgMask = (ordrBkSide == ORDR_SIDE_BUY)? (ORDR_SIDE_SELL | trdResMask) : (ORDR_SIDE_BUY | trdResMask);
    
    rc = GetBstPrc( pCntrctInfo->setId, pPrdctInfo->pos, tempMask, &bstGrp );
    RAISE_ERR( rc, RTN );
    
    /* if no best qty in order book, skip this */ //todo replace 15 to config 
    if ( ordrBkSide == ORDR_SIDE_BUY && bstGrp.bstBuyLmtQty == 0 || bstGrp.bstBuyLmtOrdCnt > 15 )
    {
//        LOG_DEBUG(" No best qty for buy side orderbook for %s",pCntrctInfo->cntrctName );
        THROW_RESCODE(NO_ERR);
    }
    else if ( ordrBkSide == ORDR_SIDE_SELL && bstGrp.bstSellLmtQty == 0 || bstGrp.bstSellLmtOrdCnt > 15 )
    {
//        LOG_DEBUG(" No best qty for sell side orderbookfor %s",pCntrctInfo->cntrctName );
        THROW_RESCODE(NO_ERR);
    }

    /*check bridge order to the related org */
    //rc = OrgInfoGetByPosExt(orgPos, &pOrgInfo);
    //RAISE_ERR(rc, RTN);

    memset(&brdgOrdr,0x00, sizeof(BrdgOrdrKeyT));
    
    brdgOrdr.ordrKey.entyIdxNo = orgPos;
    brdgOrdr.ordrKey.prdctId = pPrdctInfo->pos;
    brdgOrdr.ordrKey.ordrSide = ordrBkSide;

    rc = BrdgOrdrChk( pCntrctInfo->setId, &brdgOrdr.ordrKey, &pBrdgOrdr, &brdgOrdrPos );
    if ( rc == ERR_CMN_HASH_LIST_NODE_EXISTED )
    {
        THROW_RESCODE( NO_ERR );
    }
    RAISE_ERR( rc, RTN );

    /* check the best order one by one  */
    rc = GetBest(pCntrctInfo->setId, pPrdctInfo->pos, tempMask, &pBkOrdr );
    RAISE_ERR( rc, RTN );
    
    if ( !pBkOrdr )
    {
        THROW_RESCODE(NO_ERR);
    }
    
    do
    {
        bMktbleFlg = FALSE;
        bHasBrdgOrgFlg = FALSE;

        rc = ChkMktbleAmnt( pPrdctInfo, orgPos, pBkOrdr, &bMktbleFlg, &mktbleAmnt );
        RAISE_ERR( rc, RTN );

        if (bMktbleFlg)
        {
            /* we have deal-able amnout, let's do the real bridge. Ops need select a qualified bridge org first */
            rc = SelectBrdgOrg(pCntrctInfo->setId, orgPos, pBkOrdr->orderF.entyIdxNo, pBkOrdr, &brdgOrgPos, &brdgFee);
            RAISE_ERR( rc, RTN );

            if ( brdgOrgPos == CMN_LIST_NULL_NODE )
            {
                rc = GetNextOrder(pCntrctInfo->setId, pPrdctInfo->pos, tempMask,  pBkOrdr, &pNxtOrdr );
                RAISE_ERR( rc, RTN );

                pBkOrdr = pNxtOrdr;
                continue;
            }

            /* Check whether the needBrdgOrg has the best order in order book or not, if there is then we deal them directly, other wise 
            we need sent the market data to the select org to show the bridge order market data.*/
            rc = ChkNeedBrdgOrgInOrdrBk( pCntrctInfo->setId, ordrBkSide, needBrdgMask, orgPos, 
                                        pPrdctInfo, brdgFee, &bNeedBrdgOrdrHasBstOrdr, &pNeedBrdgBkOrdr);
            RAISE_ERR( rc, RTN );
            
            if (bNeedBrdgOrdrHasBstOrdr)
            {
                LOG_DEBUG(" Bridge order matching: orgpos:%d, bkOrgPos:%d, brdgOrgPos:%d \n ", orgPos, pBkOrdr->orderF.entyIdxNo, brdgOrgPos );

                /* Match them both */
                /* Caculate bridge order price and quantity */
                if (ordrBkSide == ORDR_SIDE_BUY)
                {
                    brdgOrdrPrc = pBkOrdr->orderF.ordrExePrc - brdgFee;
                }
                else
                {
                    brdgOrdrPrc = pBkOrdr->orderF.ordrExePrc + brdgFee;
                }
                brdgOrdrQty = pBkOrdr->orderF.ordrQty < pNeedBrdgBkOrdr->orderF.ordrQty ?
                                pBkOrdr->orderF.ordrQty : pNeedBrdgBkOrdr->orderF.ordrQty;

                /* Caculate a bridge order */
                rc = CreateBrdgOrdr(pCntrctInfo->setId,pCntrctInfo, brdgOrgPos, pNeedBrdgBkOrdr, 
                                brdgOrdrPrc, brdgOrdrQty, brdgFee, &pBrdgOrderForBk);
                RAISE_ERR( rc, RTN );
                
                mtchInfo.ordrNoOld = 0;
                mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
                mtchInfo.tradePrc = 0;

                /* Match for the Need Bridage order  */
                rc = MtchrPrcsOrdrAdd(FALSE, FALSE, pCntrctInfo->setId, pPrdctInfo, pBrdgOrderForBk, timestamp, pOrderRsp, &mtchInfo);
                RAISE_ERR(rc, RTN);
                
                /* Match them both */
                /* Caculate a another bridge order */
                rc = CreateBrdgOrdr(pCntrctInfo->setId,pCntrctInfo, brdgOrgPos, pBkOrdr, 
                                pBkOrdr->orderF.ordrExePrc, brdgOrdrQty, 0, &pBrdgOrderForBk);
                RAISE_ERR( rc, RTN );
                
                mtchInfo.ordrNoOld = 0;
                mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
                mtchInfo.tradePrc = 0;

                /* Match for the Need Bridage order  */
                rc = MtchrPrcsOrdrAdd(FALSE, FALSE, pCntrctInfo->setId, pPrdctInfo, pBrdgOrderForBk, timestamp, pOrderRsp, &mtchInfo);
                RAISE_ERR(rc, RTN);
                
                LOG_DEBUG(" Bridge order matching END \n " );
            }
            else
            {
                LOG_DEBUG(" Bridge order mgmt ADD \n " );
                
                /*need send the bridge order market data out to the related org */
                brdgOrdrPos = CMN_LIST_NULL_NODE;
                
                rc = OrgInfoGetByPosExt(brdgOrgPos, &pBrdgOrgInfo);
                RAISE_ERR(rc, RTN);

                brdgOrdr.brdgFee = brdgFee;
                brdgOrdr.brdgOrgId = pBrdgOrgInfo->orgId;
                brdgOrdr.ordrBkSlot = pBkOrdr->orderT.slotNo;

                pBkOrdr->orderF.brdgFlag = INT_ORD_FLAG_BRDG;
                pBkOrdr->orderF.entyIdBrdg = orgPos;

                rc = MtchBrdgOrdrUpdt(TRUE,pCntrctInfo->setId, ACTN_BRDG_ADD, &brdgOrdr); 
                RAISE_ERR(rc, RTN);
                
                LOG_DEBUG(" Bridge order mgmt add END \n " );
            }
            
            * pBrdgScsFlg = TRUE;
            break;
            /* we break here because we have tried to build the bridge some how. */
        }
        /* if we reaches here, it means we still need check next best order and try to build the bridge */
       
        rc = GetNextOrder(pCntrctInfo->setId, pPrdctInfo->pos, tempMask,  pBkOrdr, &pNxtOrdr );
        RAISE_ERR( rc, RTN );

        pBkOrdr = pNxtOrdr;
        
    }while ( pBkOrdr );

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT DoBrdgByPrdct(int64 orgPos, pCntrctBaseInfoT  pCntrctInfo, int64 timestamp, pNewOrderSingleRspT pOrderRsp, BOOL * pBrdgScsFlg)
{
    BEGIN_FUNCTION("DoBrdgByPrdct");
    ResCodeT            rc = NO_ERR;
    
    
    rc = DoBrdgByOrdrBkSide(ORDR_SIDE_BUY,orgPos, pCntrctInfo, timestamp, pOrderRsp, pBrdgScsFlg);
    RAISE_ERR(rc, RTN);
    
    rc = DoBrdgByOrdrBkSide(ORDR_SIDE_SELL,orgPos, pCntrctInfo, timestamp, pOrderRsp, pBrdgScsFlg);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrBrdg(int32 setId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrBrdg");
    ResCodeT            rc = NO_ERR;
    uint32              lstOnlOrgPos = CMN_LIST_NULL_NODE, currOnlOrgPos = CMN_LIST_NULL_NODE;
    uint32              cntrtPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pCntrctInfo = NULL;
    BOOL                bBrdgScsFlg = FALSE;
    
    pOrgInfoT           pOrgInfo = NULL;
    pOrgOnlineT         pOrgOnln = NULL;
    
    
    
    //THROW_RESCODE(NO_ERR);
    
    /* Get last org pos for next iterate */
    rc = GetLstBrdgOrg(&lstOnlOrgPos);
    RAISE_ERR(rc, RTN);
    
    /* Iterate next org id */
    rc = IterOnlOrg(lstOnlOrgPos, &currOnlOrgPos);
    RAISE_ERR(rc, RTN);
    
    if (currOnlOrgPos == CMN_LIST_NULL_NODE && lstOnlOrgPos == CMN_LIST_NULL_NODE)
    {
        LOG_DEBUG("No online org");
        THROW_RESCODE(NO_ERR);
    }
    else if (currOnlOrgPos == CMN_LIST_NULL_NODE)
    {
        LOG_DEBUG("at the end, start over again");
        lstOnlOrgPos = CMN_LIST_NULL_NODE;
        
        rc = IterOnlOrg(lstOnlOrgPos, &currOnlOrgPos);
        RAISE_ERR(rc, RTN);
        
        if (currOnlOrgPos == CMN_LIST_NULL_NODE && lstOnlOrgPos == CMN_LIST_NULL_NODE)
        {
            LOG_DEBUG("again, No online org");
            THROW_RESCODE(NO_ERR);
        }
    }
    
    rc = OrgOnlnGetByPosExt(currOnlOrgPos, &pOrgOnln);
    RAISE_ERR(rc, RTN);
    
    rc = OrgInfoGetByIdExt(pOrgOnln->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&cntrtPos, &pCntrctInfo);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == cntrtPos )
        {
            LOG_DEBUG("No more contract for bridge for org %d ", currOnlOrgPos);
            break;
        }
        //LOG_DEBUG("contract %d for %s", currOnlOrgPos, pCntrctInfo->cntrctName);
        rc = DoBrdgByPrdct(pOrgInfo->pos, pCntrctInfo, timestamp, pOrderRsp, &bBrdgScsFlg);
        RAISE_ERR(rc, RTN);
        
        if (bBrdgScsFlg)
        {
            break; /* we did the bridge, so break the loop*/
        }
    }
    
    
    /* Update last bridge org  */
    rc = UpdtLstBrdgOrg(currOnlOrgPos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsBilOrdrCancel(int32 setId, int32 ordrSts, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrCancel");
    ResCodeT        rc = NO_ERR;
    pOrderT         pCnclBidOrder = NULL, pCnclAskOrder = NULL;
    int32           actnMask  = 0;
    MtchInfoT       mtchInfo = {0};
    int32           prdctId= 0;
    uint32           ordrMgmtPos = 0;
    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    int64           bilOrdrNo = 0;
    pOrdrMgmtRcrdT  pBilOrdrMgmt = NULL;

    int32           oldOrdSts;
    
    MaintFlagT          maintFlag = {0};
    
    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;

    mtchInfo.ordrNoOld = 0;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    mtchInfo.tradePrc = 0;
    
    bilOrdrNo = pOrder->orderF.ordrNo;   
    
    rc = OrdrMgmtBilGet(setId, bilOrdrNo, &pBilOrdrMgmt, &pCnclBidOrder, &pCnclAskOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );
    
    LOG_DEBUG("Cancel bilOrder %lld start ", bilOrdrNo);
    
    oldOrdSts = pBilOrdrMgmt->ordrSts;
    
    pCnclAskOrder->orderF.ordrSts = ordrSts;
    pCnclBidOrder->orderF.ordrSts = ordrSts;
    pCnclAskOrder->orderF.ordrActiveTim = 0;
    pCnclBidOrder->orderF.ordrActiveTim = 0;
    
    rc = PrdctInfoGetByPosExt(pCnclBidOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );
    
    actnMask = 0;
    actnMask |= ACTN_DEL_CMD;
    actnMask |= ACTN_DEL_MNT;
    actnMask |= ACTN_AUD_YES;
    actnMask |= ACTN_CONF_ORDER;
    actnMask |= ACTN_ORDR_BK_YES;
    
    mtchInfo.ordrNoOld = pCnclBidOrder->orderF.ordrNo;
   
    /* Delete order after matching */
    rc = MtchDelOrdr(TRUE, setId, &pCnclBidOrder,
                    timestamp,
                    actnMask,
                    &mtchInfo,
                    pPrdctInfo,
                    oldOrdSts == ORDR_STS_ACTIVE);
    RAISE_ERR(rc, RTN);
    
    FmtOrdCnfrm(  pCnclBidOrder, pOrderRsp, &maintFlag, timestamp);
    
    
    mtchInfo.ordrNoOld = pCnclAskOrder->orderF.ordrNo;
    
    
    /* Delete order after matching */
    rc = MtchDelOrdr(TRUE, setId, &pCnclAskOrder,
                    timestamp,
                    actnMask,
                    &mtchInfo,
                    pPrdctInfo,
                    oldOrdSts == ORDR_STS_ACTIVE);
    RAISE_ERR(rc, RTN);
    
    FmtOrdCnfrm(  pCnclAskOrder, pOrderRsp, &maintFlag, timestamp);

    /* Save the order entry */
    rc = MtchSaveBilOrdr(TRUE, setId, ACTN_CNCL_CMD, ordrSts, pCnclBidOrder, pCnclAskOrder,pCnclBidOrder->orderT.slotNo,pCnclAskOrder->orderT.slotNo);
    RAISE_ERR(rc, RTN);
    
    LOG_DEBUG("Cancel bilOrder %lld End ", bilOrdrNo);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}





/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsBilOrdrActive(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsBilOrdrActive");
    ResCodeT        rc = NO_ERR;
    int32           actnMask  = 0;
    MtchInfoT       mtchInfo = {0};
    int32           prdctId= 0;
    uint32           ordrMgmtPos = 0;
    pPrdctInfoT             pPrdctInfo = NULL;
    pOrderT         pNewAskOrder = NULL, pNewBidOrder = NULL;
    uint32           ordrPos = 0;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    
    rc = OrdrMgmtBilGet(setId, pOrder->orderF.ordrNo, &pOrdrMgmt, &pNewBidOrder, &pNewAskOrder, &ordrPos);
    RAISE_ERR( rc, RTN );
         
    
    pOrder->orderF.prdctId = pNewBidOrder->orderF.prdctId;
    
    rc = PrdctInfoGetByPosExt(pOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );

    pNewBidOrder->orderF.ordrSts = ORDR_STS_ACTIVE;
    pNewAskOrder->orderF.ordrSts = ORDR_STS_ACTIVE;

    rc = MtchrPrcsBilOrdrAdd(TRUE, setId, pPrdctInfo, pNewAskOrder, pNewBidOrder, timestamp, pOrderRsp, &mtchInfo);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsBilOrdrWthdr(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsBilOrdrWthdr");
    ResCodeT        rc = NO_ERR;
    pPrdctInfoT     pPrdctInfo = NULL;
    pOrderT         pNewAskOrder = NULL, pNewBidOrder = NULL;
    uint32           ordrPos = 0;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    MaintFlagT      maintFlag;

    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;

    rc = OrdrMgmtBilGet(setId, pOrder->orderF.ordrNo, &pOrdrMgmt, &pNewBidOrder, &pNewAskOrder, &ordrPos);
    RAISE_ERR( rc, RTN );

    pOrder->orderF.prdctId = pNewBidOrder->orderF.prdctId;
    
    rc = PrdctInfoGetByPosExt(pOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );
    
    pNewBidOrder->orderF.ordrSts = ORDR_STS_FREEZE;
    pNewAskOrder->orderF.ordrSts = ORDR_STS_FREEZE;
    
    rc = MtchSaveBilOrdr(TRUE, setId, ACTN_ADD_CMD, ORDR_STS_FREEZE, pNewBidOrder, pNewAskOrder,pNewBidOrder->orderT.slotNo,pNewAskOrder->orderT.slotNo);
    RAISE_ERR(rc, RTN);

    /* format order response */
    rc = FmtOrdCnfrm( pNewBidOrder, pOrderRsp, &maintFlag, timestamp);
    RAISE_ERR(rc, RTN);

    rc = FmtOrdCnfrm( pNewAskOrder, pOrderRsp, &maintFlag, timestamp);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrActive(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrActive");
    ResCodeT        rc = NO_ERR;
    int32           actnMask  = 0;
    MtchInfoT       mtchInfo = {0};
    int32           prdctId= 0;
    uint32           ordrMgmtPos = 0;
    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    pOrderT         pNewOrder = NULL, pTmpOrder = NULL;
    uint32           ordrPos = 0;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;

    
    rc = OrdrMgmtNrmlGet(setId, pOrder->orderF.ordrNo, &pOrdrMgmt, &pNewOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );
    
    pOrder->orderF.prdctId = pNewOrder->orderF.prdctId;
    pNewOrder->orderF.ordrActiveTim = timestamp;
    pNewOrder->orderF.tranTime = timestamp;
    
    rc = PrdctInfoGetByPosExt(pOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );


    pNewOrder->orderF.ordrSts = ORDR_STS_ACTIVE;
   

    rc = MtchrPrcsOrdrAdd(TRUE, TRUE, setId, pPrdctInfo, pNewOrder, timestamp, pOrderRsp, &mtchInfo);
    RAISE_ERR(rc, RTN);
  

    EXIT_BLOCK();
    RETURN_RESCODE;;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOrdrWthdr(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrWthdr");
    ResCodeT        rc = NO_ERR;
    int32           actnMask  = 0;
    MtchInfoT       mtchInfo = {0};
    int32           prdctId= 0;
    uint32           ordrMgmtPos = 0;
    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    pOrderT         pNewOrder = NULL, pTmpOrder = NULL;
    uint32           ordrPos = 0;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;


    rc = OrdrMgmtNrmlGet(setId, pOrder->orderF.ordrNo, &pOrdrMgmt, &pNewOrder, &ordrMgmtPos);
    RAISE_ERR( rc, RTN );

    pNewOrder->orderF.tranTime = timestamp;
    pNewOrder->orderF.ordrActiveTim = 0;

    rc = PrdctInfoGetByPosExt(pNewOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsOrdrSave( TRUE, setId, pPrdctInfo, pNewOrder, timestamp, pOrderRsp);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}


/******************************************************************************
 * Description:   Log trade date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchrInit(int32 set)
{
    BEGIN_FUNCTION("MtchrInit");
    ResCodeT rc = NO_ERR;
    
    rc = OrdrBkShmAttach(set);
    RAISE_ERR(rc, RTN);
    
    rc = NmbrSrvcInit(set);
    RAISE_ERR(rc, RTN);
   

    rc = OrdrMgmtShmAttach(set);
    RAISE_ERR(rc, RTN);
    
    
    /* Get config value for the system  */
    rc = GetCfgValue(&gCfgValue);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   Log trade date to memory txn data
 * Parameters:
 *      set         IN  set
 *      pOrder      IN  order info
 *      pMtchInfo   IN  match info
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
ResCodeT MtchrDetach(int32 set)
{
    BEGIN_FUNCTION("MtchrDetach");
    ResCodeT rc = NO_ERR;
    
    rc = OrdrBkShmDetach(set);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOcoOrdrAdd(BOOL bRcrvOrdrFlg, int32 setId,
                            OCOFirstT *       pOcoHdr, 
                            int32 bidOrdrCnt, NewOrderInfoT * pBidOrder,
                            int32 askOrdrCnt, NewOrderInfoT * pAskOrder, 
                            int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOcoOrdrAdd");
    ResCodeT            rc = NO_ERR;
    int64               ocoOrdrNo = 0;
    int64               mtchrOrdrNo = 0;
    int32               i = 0;
    int32               ordrSts;
    pOrderT             pOrder = NULL;
    MtchInfoT           mtchInfo;
    pPrdctInfoT         pPrdctInfo = NULL;
    BOOL                bMatchFlg = FALSE;
    OrderT              tmpOrder = {0};
    pOrderT             pCnclOrder = &tmpOrder;
    
    int64           remQty = 0;

    pOrderT         pTmpBidOrder[MAX_ORDR_IN_OCO];
    pOrderT         pTmpAskOrder[MAX_ORDR_IN_OCO];
   
    if (bRcrvOrdrFlg)
    {
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_OCO_ORD, &ocoOrdrNo);
        RAISE_ERR(rc, RTN);
    } 
    
    LOG_DEBUG("Start OCO %lld process", ocoOrdrNo);
    
    for (i=0; i<bidOrdrCnt; i++)
    {
        memset( &mtchInfo, 0x00, sizeof(MtchInfoT) );
        rc = PrdctInfoGetByPosExt(pBidOrder[i].contractPos, &pPrdctInfo);
        RAISE_ERR( rc, RTN );

        rc = MtchrCreateOrdrFromOrdrInfo(setId, &pBidOrder[i], &pOrder, FALSE, NULL);
        RAISE_ERR( rc, RTN );

        pOrder->orderF.specOrdrNo = ocoOrdrNo;
        pOrder->orderF.extOrdrType = EXT_ORD_TYPE_OCO;
        //pOrder->orderF.ordrSts = ORDR_STS_ACTIVE;
        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_ORD, &pOrder->orderF.ordrNo);
        RAISE_ERR(rc, RTN);
        
        pTmpBidOrder[i] = pOrder;
        
        if ( !bMatchFlg || remQty )
        {
            rc = MtchrPrcsOrdrAdd(bRcrvOrdrFlg, TRUE, setId, pPrdctInfo, pOrder, timestamp, pOrderRsp,&mtchInfo );
            RAISE_ERR(rc, RTN);
        }
        else
        {
            rc = MtchrPrcsOrdrSave( bRcrvOrdrFlg, setId, pPrdctInfo, pOrder, timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN);
        }

        if ( mtchInfo.ordrPrtFilCod != MTCH_TYPE_NO_MTCH )
        {
            bMatchFlg = TRUE;
            remQty    = pOrder->orderF.ordrQty;
            mtchrOrdrNo = pOrder->orderF.ordrNo;
        }

        LOG_DEBUG("Bid Single OrderO %lld processed", pOrder->orderF.ordrNo);
    }
    
    for (i=0; i<askOrdrCnt; i++)
    {
        memset( &mtchInfo, 0x00, sizeof(MtchInfoT) );
        rc = PrdctInfoGetByPosExt(pAskOrder[i].contractPos, &pPrdctInfo);
        RAISE_ERR( rc, RTN );
        
        rc = MtchrCreateOrdrFromOrdrInfo(setId, &pAskOrder[i], &pOrder, FALSE, NULL);
        RAISE_ERR( rc, RTN );

        pOrder->orderF.specOrdrNo = ocoOrdrNo;
        pOrder->orderF.extOrdrType = EXT_ORD_TYPE_OCO;
        /* Gen order number*/
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_ORD, &pOrder->orderF.ordrNo);
        RAISE_ERR(rc, RTN);

        pTmpAskOrder[i] = pOrder;

        if ( !bMatchFlg || remQty )
        {
            rc = MtchrPrcsOrdrAdd(bRcrvOrdrFlg, TRUE, setId, pPrdctInfo, pOrder, timestamp, pOrderRsp,&mtchInfo);
            RAISE_ERR(rc, RTN);
        }
        else
        {
            rc = MtchrPrcsOrdrSave( bRcrvOrdrFlg, setId, pPrdctInfo, pOrder, timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN);
        }

        if ( mtchInfo.ordrPrtFilCod != MTCH_TYPE_NO_MTCH )
        {
            bMatchFlg = TRUE;
            remQty    = pOrder->orderF.ordrQty;
            mtchrOrdrNo = pOrder->orderF.ordrNo;
        }

        LOG_DEBUG("Ask Single OrderO %lld processed", pOrder->orderF.ordrNo);
    }

    ordrSts = bMatchFlg ? ORDR_STS_DEAL : ORDR_STS_ACTIVE;

    rc = MtchLogOcoOrdr(TRUE, setId, ocoOrdrNo, ACTN_BOOK_CMD, ordrSts,
                    bidOrdrCnt, pTmpBidOrder, askOrdrCnt, pTmpAskOrder);
    RAISE_ERR(rc, RTN);

    /* If matched one order, cancel all others */
    if ( bMatchFlg && !remQty )
    {
        pCnclOrder->orderF.ordrNo = mtchrOrdrNo;
        pCnclOrder->orderF.specOrdrNo = ocoOrdrNo;

        rc = CnclRltOcoOrdr( setId, pCnclOrder, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOcoOrdrSave(BOOL bRcrvOrdrFlg, int32 setId,
                            OCOFirstT *       pOcoHdr, 
                            int32 bidOrdrCnt, NewOrderInfoT * pBidOrder,
                            int32 askOrdrCnt, NewOrderInfoT * pAskOrder, 
                            int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOcoOrdrSave");
    ResCodeT            rc = NO_ERR;
    int64               ocoOrdrNo = 0;
    int32               i = 0;
    pOrderT             pOrder = NULL;
    pPrdctInfoT         pPrdctInfo = NULL;
        
    pOrderT         pTmpBidOrder[MAX_ORDR_IN_OCO];
    pOrderT         pTmpAskOrder[MAX_ORDR_IN_OCO];
    
    MaintFlagT          maintFlag;

    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;

   
    if (!bRcrvOrdrFlg)
    {
        rc = NmbrSrvcGenNo(setId, NMBR_TYPE_OCO_ORD, &ocoOrdrNo);
        RAISE_ERR(rc, RTN);
    } 
    
    LOG_DEBUG("Start OCO %lld Save process", ocoOrdrNo);
    
    for (i=0; i<bidOrdrCnt; i++)
    {
        rc = PrdctInfoGetByPosExt(pBidOrder[i].contractPos, &pPrdctInfo);
        RAISE_ERR( rc, RTN );

        rc = MtchrCreateOrdrFromOrdrInfo(setId, &pBidOrder[i], &pOrder, FALSE, NULL);
        RAISE_ERR( rc, RTN );
        
        pTmpBidOrder[i] = pOrder;

        pOrder->orderF.specOrdrNo = ocoOrdrNo;
        pOrder->orderF.extOrdrType = EXT_ORD_TYPE_OCO;

        rc = MtchrPrcsOrdrSave( bRcrvOrdrFlg, setId, pPrdctInfo, pOrder, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN);

        LOG_DEBUG("Bid Single OrderO %lld processed", pOrder->orderF.ordrNo);
    }
    
    for (i=0; i<askOrdrCnt; i++)
    {
        rc = PrdctInfoGetByPosExt(pAskOrder[i].contractPos, &pPrdctInfo);
        RAISE_ERR( rc, RTN );
        
        rc = MtchrCreateOrdrFromOrdrInfo(setId, &pAskOrder[i], &pOrder, FALSE, NULL);
        RAISE_ERR( rc, RTN );
        
        pTmpAskOrder[i] = pOrder;

        pOrder->orderF.specOrdrNo = ocoOrdrNo;
        pOrder->orderF.extOrdrType = EXT_ORD_TYPE_OCO;

        rc = MtchrPrcsOrdrSave( bRcrvOrdrFlg, setId, pPrdctInfo, pOrder, timestamp, pOrderRsp);
        RAISE_ERR(rc, RTN);

        LOG_DEBUG("Ask Single OrderO %lld processed", pOrder->orderF.ordrNo);
    }
    
    rc = MtchLogOcoOrdr(TRUE, setId, ocoOrdrNo, ACTN_ADD_CMD, ORDR_STS_FREEZE,
                    bidOrdrCnt, pTmpBidOrder, askOrdrCnt, pTmpAskOrder);
    RAISE_ERR(rc, RTN);
    
       
    EXIT_BLOCK();
    RETURN_RESCODE;;
}




/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOcoOrdrCancel(int32 setId, int32 ordrSts, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrCancel");
    ResCodeT            rc = NO_ERR;
    pOrderT             pCnclOrder = NULL;
    int32               actnMask  = 0;
    MtchInfoT           mtchInfo = {0};
    int32               prdctId= 0;
    uint32               ordrMgmtPos = 0;
    pPrdctInfoT         pPrdctInfo = NULL;
    pCntrctBaseInfoT    pIrsCntrctInfo = NULL;
    int64               ocoOrdrNo = 0;
    pOrdrMgmtRcrdT      pOcoOrdrMgmt = NULL;
    MaintFlagT          maintFlag = {0};
    int64               iter;
    int32               oldOrdSts;

    
    maintFlag.ordrWrtblFlg = WKSG_LIT_NO; 
    maintFlag.mktblFlg = WKSG_LIT_NO;
    maintFlag.ordrCncl = WKSG_LIT_YES;

    mtchInfo.ordrNoOld = 0;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    mtchInfo.tradePrc = 0;
    
    ocoOrdrNo = pOrder->orderF.ordrNo; 
    LOG_DEBUG("Cancel OCO Order %lld  ", ocoOrdrNo);
    
    rc = OrdrMgmtOcoGet(setId, ocoOrdrNo,&pOcoOrdrMgmt, &pCnclOrder, &iter);
    RAISE_ERR( rc, RTN );
    
    oldOrdSts = pOcoOrdrMgmt->ordrSts;
    
    actnMask = 0;
    actnMask |= ACTN_DEL_CMD;
    actnMask |= ACTN_DEL_MNT;
    actnMask |= ACTN_AUD_YES;
    actnMask |= ACTN_CONF_ORDER;
    actnMask |= ACTN_ORDR_BK_YES;
    
    
    rc = PrdctInfoGetByPosExt(pCnclOrder->orderF.prdctId, &pPrdctInfo);
    RAISE_ERR( rc, RTN );
    
    do
    {
        mtchInfo.ordrNoOld = pCnclOrder->orderF.ordrNo;
        pCnclOrder->orderF.ordrSts = ordrSts;
        pCnclOrder->orderF.ordrActiveTim = 0;
        
        FmtOrdCnfrm(  pCnclOrder, pOrderRsp, &maintFlag, timestamp);
        
        /* Delete order after matching */
        rc = MtchDelOrdr(TRUE, setId, &pCnclOrder,
                        timestamp,
                        actnMask,
                        &mtchInfo,
                        pPrdctInfo,
                        oldOrdSts == ORDR_STS_ACTIVE);
        RAISE_ERR(rc, RTN);
        
        rc = OrdrMgmtOcoGetNext(setId, pOcoOrdrMgmt, &pCnclOrder, &iter);
        if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
        {
            RAISE_ERR(rc, RTN);
        }
        else
        {
            break;
        }
    } while (TRUE);
    
 
    /* Save the order entry */
    rc = MtchLogOcoOrdr(TRUE, setId, ocoOrdrNo, ACTN_CNCL_CMD, ordrSts, 0, NULL, 0, NULL);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("Cancel ocoOrdrNo %lld End ", ocoOrdrNo);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}



/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOcoOrdrActive(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOcoOrdrActive");
    ResCodeT            rc = NO_ERR;
    pOrderT             pAddOrder = NULL;
    MtchInfoT           mtchInfo = {0};
    int32               prdctId= 0;
    uint32               ordrMgmtPos = 0;
    pPrdctInfoT         pPrdctInfo = NULL;
    pCntrctBaseInfoT    pIrsCntrctInfo = NULL;
    int64               ocoOrdrNo = 0;
    int64               mtchrOrdrNo = 0;
    pOrdrMgmtRcrdT      pOcoOrdrMgmt = NULL;
    int64               iter;
    BOOL                bMatchFlg = FALSE;
    int32               ordrSts;

    OrderT              tmpOrder = {0};
    pOrderT             pCnclOrder = &tmpOrder;

    mtchInfo.ordrNoOld = 0;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    mtchInfo.tradePrc = 0;
    
    ocoOrdrNo = pOrder->orderF.ordrNo; 
    LOG_DEBUG("Cancel OCO Order %lld  ", ocoOrdrNo);
    
    rc = OrdrMgmtOcoGet(setId, ocoOrdrNo,&pOcoOrdrMgmt, &pAddOrder, &iter);
    RAISE_ERR( rc, RTN );

    do
    {
        //pOrder->orderF.prdctId = pAddOrder->orderF.prdctId;
        //pOrder->orderF.ordrSts = ORDR_STS_ACTIVE;

        rc = PrdctInfoGetByPosExt(pAddOrder->orderF.prdctId, &pPrdctInfo);
        RAISE_ERR( rc, RTN );

        rc = MtchrPrcsOrdrAdd(TRUE, TRUE, setId, pPrdctInfo, pAddOrder, timestamp, pOrderRsp,&mtchInfo );
        RAISE_ERR(rc, RTN);

        if ( (mtchInfo.ordrPrtFilCod != MTCH_TYPE_NO_MTCH) &&
            !pAddOrder->orderF.ordrQty )
        {
            bMatchFlg = TRUE;
            break;
        }

        rc = OrdrMgmtOcoGetNext(setId, pOcoOrdrMgmt, &pAddOrder, &iter);
        if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
        {
            RAISE_ERR(rc, RTN);
        }
        else
        {
            break;
        }
    } while (TRUE);

    ordrSts = bMatchFlg ? ORDR_STS_DEAL : ORDR_STS_ACTIVE;

    /* Save the order entry */
    rc = MtchLogOcoOrdr(TRUE, setId, ocoOrdrNo, ACTN_BOOK_CMD, ordrSts, 0, NULL, 0, NULL);
    RAISE_ERR(rc, RTN);

    /* If matched one order, cancel all others */
    if ( bMatchFlg )
    {
        pCnclOrder->orderF.ordrNo = mtchrOrdrNo;
        pCnclOrder->orderF.specOrdrNo = ocoOrdrNo;

        rc = CnclRltOcoOrdr( setId, pCnclOrder, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
    }

    LOG_DEBUG("Activate ocoOrdrNo %lld End ", ocoOrdrNo);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsOcoOrdrWthdr(int32 setId, pOrderT pOrder, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOcoOrdrWthdr");
    ResCodeT            rc = NO_ERR;
    pOrderT             pAddOrder = NULL;
    MtchInfoT           mtchInfo = {0};
    int32               prdctId= 0;
    uint32               ordrMgmtPos = 0;
    pPrdctInfoT         pPrdctInfo = NULL;
    pCntrctBaseInfoT    pIrsCntrctInfo = NULL;
    int64               ocoOrdrNo = 0;
    pOrdrMgmtRcrdT      pOcoOrdrMgmt = NULL;
    int64               iter;

    mtchInfo.ordrNoOld = 0;
    mtchInfo.ordrPrtFilCod = MTCH_TYPE_NO_MTCH;
    mtchInfo.tradePrc = 0;
    
    ocoOrdrNo = pOrder->orderF.ordrNo; 
    LOG_DEBUG("Withdraw OCO Order %lld  ", ocoOrdrNo);
    
    rc = OrdrMgmtOcoGet( setId, ocoOrdrNo, &pOcoOrdrMgmt, &pAddOrder, &iter );
    RAISE_ERR( rc, RTN );

    rc = PrdctInfoGetByPosExt( pAddOrder->orderF.prdctId, &pPrdctInfo );
    RAISE_ERR( rc, RTN );
    
    do
    {
        rc = MtchrPrcsOrdrSave( TRUE, setId, pPrdctInfo, pAddOrder, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);

        rc = OrdrMgmtOcoGetNext(setId, pOcoOrdrMgmt, &pAddOrder, &iter);
        if (rc != ERR_CMN_HASH_LIST_NODE_EXISTED)
        {
            RAISE_ERR(rc, RTN);
        }
        else
        {
            break;
        }
    } while (TRUE);
 
    /* Save the order entry */
    rc = MtchLogOcoOrdr(TRUE, setId,ocoOrdrNo, ACTN_ADD_CMD, ORDR_STS_FREEZE, 0, NULL, 0, NULL);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("Activate ocoOrdrNo %lld End ", ocoOrdrNo);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

/******************************************************************************
 * Description:   do order check for matching
 * Parameters:
 *  pPrdctInfo  IN  Product information
 *  pIncOrdr    IN  Incoming order
 *  pBstOrder   OUT Incoming order timestamp
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrChkBstOrder( pPrdctInfoT pPrdctInfo, pOrderT pIncOrdr, 
                            pOrderT pBstOrder, pCrdtMgmtUpdtT pCrdtMgmtUpdt, BOOL* pIsChkOK )
{
    BEGIN_FUNCTION("MtchrChkBstOrder");
    ResCodeT            rc = NO_ERR;

    rc = CheckBestOrdrExt( pIncOrdr, pBstOrder, pIsChkOK );
    RAISE_ERR( rc, RTN );
    
    /* If the first check not passed, no need to do the rests */
    if ( !(*pIsChkOK) )
    {
        THROW_RESCODE(NO_ERR);
    }

    rc = CreditCheck( pIncOrdr, pBstOrder, pCrdtMgmtUpdt, pIsChkOK );
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK( );
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   get best order from order book
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pIncOrdr    IN  Incoming order
 *  pBstOrder   OUT Incoming order timestamp
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrGetBstOrder( int32 set, pPrdctInfoT pPrdctInfo, int16 oMask,
                            pOrderT pIncOrdr, pOrderT *pBstOrder, pCrdtMgmtUpdtT pCrdtMgmtUpdt )
{
    BEGIN_FUNCTION("MtchrGetBstOrder");
    ResCodeT            rc = NO_ERR;

    pOrderT pBstBkOrdr = NULL;
    pOrderT pNxtBkOrdr = NULL;

    BOOL    isCheckOK = TRUE;

    *pBstOrder = NULL;

    rc = GetBest( set, pPrdctInfo->pos, oMask, &pBstBkOrdr );
    RAISE_ERR( rc, RTN );
    
    if (!pBstBkOrdr)
    {

        THROW_RESCODE(NO_ERR);
    }

    do
    {
        pNxtBkOrdr = NULL;

        /* check best order */
        rc = MtchrChkBstOrder( pPrdctInfo, pIncOrdr, pBstBkOrdr, pCrdtMgmtUpdt, &isCheckOK );
        RAISE_ERR( rc, RTN );

        if ( isCheckOK )
        {
            break;
        }

        rc = GetNextOrder( set, pPrdctInfo->pos, oMask, pBstBkOrdr, &pNxtBkOrdr );
        RAISE_ERR( rc, RTN );

        pBstBkOrdr = pNxtBkOrdr;

    } while ( pBstBkOrdr );

    *pBstOrder = pBstBkOrdr;

    EXIT_BLOCK( );
    RETURN_RESCODE;
}




/******************************************************************************
 * Description:     Send the message to TDPS
 * Parameters:
 *      pRunInfo    IN  run time info
 *      msgHndl     IN  message queue handle
 *      N/A         OUT
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to Process the queue message .
 ******************************************************************************/
ResCodeT SendOrdTrdToClnt( pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION( "SendOrdTrdToClnt" );
    ResCodeT  rc = NO_ERR;
    SlotT slotId;
    pMsgCacheSlotT  pReqSlot;
    pMsgCacheSlotT  pRespSlot;
    pIntrnlMsgT     pReqMsg;
    pIntrnlMsgT     pRespMsg;
    LOG_DEBUG("Reserv Slot in SendOrdTrdToClnt");
    rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot, &pRespSlot);
    RAISE_ERR( rc, RTN );
    
    pReqMsg = (pIntrnlMsgT)&pReqSlot->msgBody;
    pRespMsg = (pIntrnlMsgT)&pRespSlot->msgBody;
    
    pRespMsg->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    
    memcpy(pRespMsg->msgBody,pOrderRsp, sizeof(NewOrderSingleRspT) );
    
    pRespMsg->msgHdr.msgLen += sizeof(MsgHdrT);
    pRespMsg->msgHdr.msgType = MSG_TYPE_ORDTRD_TO_CLNT;
    pRespMsg->msgHdr.errCode = NO_ERR;
    
    memcpy(&pReqMsg->msgHdr,&pRespMsg->msgHdr, sizeof(sizeof(MsgHdrT)));
    
    rc = AppShlWriteSlotToBuff(slotId);
    RAISE_ERR( rc, RTN );
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of PrcsQueueMsg */


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CnclAllApiOrdrByPrdctId(int32 setId, int64 prdctPos, int16 ordMask, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("CnclAllApiOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pCurrOrdr = NULL;
    pOrderT         pNextOrdr = NULL;

    rc = OrdrBkGetOrdrIterExt( setId, prdctPos, ordMask, pCurrOrdr, &pNextOrdr );
    RAISE_ERR(rc, RTN); 

    while (pNextOrdr)
    {
        if (0 != pNextOrdr->orderF.apiRqstId)
        {
            rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pNextOrdr, timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN); 
        }

        pCurrOrdr = pNextOrdr;
        pNextOrdr = NULL;
        rc = OrdrBkGetOrdrIterExt( setId, prdctPos, ordMask, pCurrOrdr, &pNextOrdr );
        RAISE_ERR(rc, RTN);
        
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsApiOrdrCncl(int32 setId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsOrdrCnclByApi");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);

        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }

        rc = CnclAllApiOrdrByPrdctId(setId, pData->pos, ORDR_SIDE_BUY, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);

        rc = CnclAllApiOrdrByPrdctId(setId, pData->pos, ORDR_SIDE_SELL, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT CnclClsPosnOrgOrdrByPrdctId(int32 setId, int64 prdctPos, int64 orgId, 
            int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("CnclClsPosnOrgOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pNextOrgOrdr = NULL;
    
    rc = OrdrBkGetOrdrByOrgPos( setId, orgId, prdctPos, &pNextOrgOrdr, &nxtSlt);
    RAISE_ERR(rc, RTN); 
    
    while (pNextOrgOrdr)
    {
        if (pNextOrgOrdr->orderF.forceId)
        {
            rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_CANCEL, pNextOrgOrdr, timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN); 
        }
        rc = OrdrBkGetOrdrByOrgPos( setId, orgId, prdctPos, &pNextOrgOrdr, &nxtSlt);
        RAISE_ERR(rc, RTN); 
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsCnclClsPosnOrgOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsCnclClsPosnOrgOrdrBySet");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    pOrgInfoT           pOrgInfo = NULL;    
    
    rc = OrgInfoGetByIdExt(orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = CnclClsPosnOrgOrdrByPrdctId(setId, pData->pos, pOrgInfo->pos, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
    }
    
    if (pOrderRsp->slotCnt )
    {
        rc = SendOrdTrdToClnt(pOrderRsp);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT FreezeOrgClsPosnOrdrByPrdctId(int32 setId, int64 prdctPos, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("FreezeOrgClsPosnOrdrByPrdctId");
    ResCodeT            rc = NO_ERR;
    
    SlotT           nxtSlt = -1;
    pOrderT         pNextOrgOrdr = NULL;
    
    rc = OrdrBkGetOrdrByOrgPos( setId, orgId,prdctPos, &pNextOrgOrdr, &nxtSlt);
    RAISE_ERR(rc, RTN); 
    
    while (pNextOrgOrdr)
    {
        /* freeze ordrs non close position */
        if (!pNextOrgOrdr->orderF.forceId)
        {
            rc = MtchrPrcsOrdrCancel(setId, ORDR_STS_FREEZE, pNextOrgOrdr, timestamp, pOrderRsp);
            RAISE_ERR(rc, RTN); 
        }
        rc = OrdrBkGetOrdrByOrgPos( setId, orgId, prdctPos, &pNextOrgOrdr, &nxtSlt);
        RAISE_ERR(rc, RTN); 
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   process a order entry
 * Parameters:
 *  set         IN  Set id
 *  pPrdctInfo  IN  Product information
 *  pOrder      IN  Incoming order
 *  timestamp   IN  Incoming order timestamp
 *  pOrderRsp   OUT output order response.
 * Return Value:
 *  NO_ERR  successful.
 *  ERR_<DSCR>      error happens.
 *****************************************************************************/
ResCodeT MtchrPrcsFreezeOrgClsPosnOrdrBySet(int32 setId, int64 orgId, int64 timestamp, pNewOrderSingleRspT pOrderRsp)
{
    BEGIN_FUNCTION("MtchrPrcsFreezeOrgClsPosnOrdrBySet");
    ResCodeT            rc = NO_ERR;
    uint32              contrctPos = CMN_LIST_NULL_NODE;
    pCntrctBaseInfoT    pData = NULL;
    pOrgInfoT           pOrgInfo = NULL;    
    
    rc = OrgInfoGetByIdExt(orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    while (TRUE)
    {
        rc = IrsCntrctInfoIterExt(&contrctPos, &pData);
        RAISE_ERR(rc, RTN);
        
        if ( CMN_LIST_NULL_NODE == contrctPos )
        {
            LOG_DEBUG("No more contract ");
            break;
        }
        
        rc = FreezeOrgClsPosnOrdrByPrdctId(setId, pData->pos, pOrgInfo->pos, timestamp, pOrderRsp );
        RAISE_ERR(rc, RTN);
    }
    
    if (pOrderRsp->slotCnt )
    {
        rc = SendOrdTrdToClnt(pOrderRsp);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}