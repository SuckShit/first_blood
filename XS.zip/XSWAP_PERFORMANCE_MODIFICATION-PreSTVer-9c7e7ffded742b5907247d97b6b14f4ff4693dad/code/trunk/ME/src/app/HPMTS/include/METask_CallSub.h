/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _METASK_CALLSUB_H_
#define _METASK_CALLSUB_H_

#include "internal_function_def.h"
#include "intrnl_msg.h"
#include "user_order.h"

ResCodeT InitOcoOrderCnt();
ResCodeT GetOcoOrderCnt(int32* pSecCnt, int32* pSecAskCnt);
ResCodeT InsertIntoOrderArray(NewOrderInfoT* pParamsOffer, NewOrderInfoT* pOrder, int16 flg);
ResCodeT OnOcoSubmitFirstSpStartExe(IMIX20::DataSet& message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox);
ResCodeT OnOcoSubmitFirstSpStart(IMIX20::NewOrderList& message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox);
ResCodeT OnOcoSubmitSecondSpStart(IMIX20::NewOrderList& message, NewOrderInfoT* pOcoSecBid, NewOrderInfoT* pOcoSecAsk, OCO_CHECKBOX eCheckBox);
ResCodeT OnOcoSaveFirstSpStart(IMIX20::NewOrderList&  message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox);
ResCodeT OnOcoSaveFirstSpStartExe(IMIX20::DataSet& message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox);
ResCodeT OnOcoSaveSecondSpStart(IMIX20::NewOrderList& message, NewOrderInfoT* pSec, OCO_CHECKBOX eCheckBox);
ResCodeT GetOrdNewSubmitParams(IMIX20::NewOrderList& message, NewOrderInfoT* pParamsBid, NewOrderInfoT* pParamsOffer, OCO_CHECKBOX eCheckBox);
ResCodeT GetOrdModifySubmitParams(IMIX20::OrderCancelReplaceRequest& message, NewOrderInfoT* pParamsBid, NewOrderInfoT* pParamsOffer, OCO_CHECKBOX eCheckBox);
ResCodeT OnOrderModifySaveStartByOco(const IMIX::BasicMessage& inMessage, NewOrderInfoT* pOrderMsg, OCO_CHECKBOX eOcoCheckBox);

#endif