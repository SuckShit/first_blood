/***
Created on June 08, 2017
@author: Ming.Kong
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#pragma once
/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/
#include "METask.h"
#include "matching_listener.h"
#include "UTILITY/Mutex.h"
#include "data_type.h"
 
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
#define      RESPONSE_RUN_FLUG_RUN         1
#define      RESPONSE_RUN_FLUG_END         0

typedef struct RspThreadConfigS
{
    ServiceList* pm_ServiceList;
    CMUTEX*      pm_ClientMutex;
    METask*      pm_METask;
    int32        msgHdl;
    int32*       pRunFlg;
} RspThreadConfigT, *pRspThreadConfigT;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
void* MatchingResponseThread(void * pConfig);