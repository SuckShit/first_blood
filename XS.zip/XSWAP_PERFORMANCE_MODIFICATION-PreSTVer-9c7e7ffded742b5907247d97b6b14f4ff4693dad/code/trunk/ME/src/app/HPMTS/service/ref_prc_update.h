/***
Created on 11th, Sep, 2017
@author: Longyun.Hao
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _REF_PRC_UPDATE_H_
#define _REF_PRC_UPDATE_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files */
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT PrcsCalcRefPrcByTrgr(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx);                
ResCodeT GetMktStIRS(char* pValue);
ResCodeT GetRefPrcClcTime(time_t* pValue);
ResCodeT GetLastBrdgeTime(time_t* pValue);
ResCodeT GetBridgeFlag(BOOL* pFlag);
ResCodeT GetBypassFrequency(int64* pValue);
ResCodeT GetBridgePercent(int64* pValue);
#endif /* _REF_PRC_UPDATE_H_ */
