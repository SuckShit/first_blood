/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
#pragma once


#include "DEP/Service.h"
#include "DEP/ServiceID.h"
#include "DEP/DEPTimer.h"
#include "matching_listener.h"
#include "MatchingTimer.h"


using namespace CFETS;


//class ServerTimer;
class MatchingListener;
class ServerTimer : public DEP::DEPTimer {
public:
    
    ServerTimer(MatchingListener* pServerTimer,
        long startTime,
        long endTime,
        long interval,IMIX::BasicMessage* Msg);
    
    virtual ~ServerTimer();
    
    virtual void OnTimer();
     
    IMIX::BasicMessage* GetMsg();
    
    void SetMsg(IMIX::BasicMessage* Msg);
    
    int GetInterval();
    
    void SetInterval(int Interval);

public:
    ServerTimer* m_pServerTimer;
    MatchingListener* m_pMatchingListener;
    IMIX::BasicMessage* m_inMessage;
    int m_Interval;
    
};

