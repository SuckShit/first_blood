/***
Created on July 20, 2017
@author: kong
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "pck_irs_dicdata.h"
#include "usr.h"
#include "org_info.h"
#include "intrnl_msg.h"
#include "app_shl.h"
#include "org_setting.h"
#include "ref_dat_updt.h"
#include "org_def_ref.h"
#include "uti_tool.h"
#include "pck_irs_util.h"
#include "match_lib.h"
#include "internal_base_def.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
#define   FREEZE_ORD_SET_ID_IRS         1
#define   FREEZE_ORD_SET_ID_SIRS        2
#define   FREEZE_ORD_SET_ID_SBF         3
#define   FREEZE_ORD_SET_ID_SIRSCCP     4
#define   FREEZE_ORD_SET_ID_SBFCCP      5

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 **
 ** Detail Service Callback : OrgBankFreezeMessage
 **
 ******************************************************************************/
ResCodeT OrgBankFreezeMessage(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OrgBankFreezeMessage" );
    ResCodeT rc = NO_ERR;

    PartyDetailsListReportReqT* pFreezeReq;
    PartyDetailsListReportRspT* pFreezeRsp;
    OrgMemDataRefT    data;
    OrgInfoT         *pOrgInfoData = NULL;

    pFreezeReq = (PartyDetailsListReportReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(PartyDetailsListReportReqT);
    pFreezeRsp = (PartyDetailsListReportRspT*)&pRsp->msgBody[0];

    memset(&data, 0x00, sizeof(OrgMemDataRefT));
    memcpy(data.strUserId, pFreezeReq->strUserId, sizeof(data.strUserId));
    data.rqstType = pFreezeReq->rqstType;
    data.eMessageType = MSG_TYPE_ORG_BANK_FREEZE;

    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);

    rc = CommonChk( pFreezeReq->strUserId,
                    atoi(pFreezeReq->strOrgId), 
                    pFreezeReq->iFuncId, 
                    pFreezeReq->strToken, 
                    &data.intOrgId );

    if (C_REQUEST_FORBID == pFreezeReq->rqstType)
    {
        /* freeze order */
        InitRspDat(&pFreezeRsp->orderRsp);

        /*All Market */
        rc = MtchrPrcsFreezeOrgOrdr(data.intOrgId, timestamp, &pFreezeRsp->orderRsp);
        RAISE_ERR(rc, RTN);
    }
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, sizeof(OrgMemDataRefT));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrgMarkerRoleUpadateMessage(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OrgMarkerRoleUpadateMessage" );
    ResCodeT rc = NO_ERR;

    SecurityDefinitionReqT* pRoleUpdateReq;
    SecurityDefinitionRspT* pRoleUpdateRsp;

    OrgInfoT orgInfo;
    BrdgOrgInfoT brdgOrgInfo;
    UsrBaseInfoT usrInfo;

    BrdgOrdrRcrdT brdgOrdr;

    int32 prevBrdgSt;
    int32 postBrdgSt;

    OrgMemDataRefT data;
    int32 dataLen;
    /*---------------------------出参和过程变量的初始化--------------------*/
    memset(&orgInfo, 0x00, sizeof(OrgInfoT));
    memset(&brdgOrgInfo, 0x00, sizeof(BrdgOrgInfoT));
    memset(&usrInfo, 0x00, sizeof(UsrBaseInfoT));
    memset(&brdgOrdr, 0x00, sizeof(BrdgOrdrRcrdT));

    //RequestMessage 
    pRoleUpdateReq  = (SecurityDefinitionReqT*)&pReq->msgBody[0];
    //ResponseMessage 
    pRoleUpdateRsp  = (SecurityDefinitionRspT*)&pRsp->msgBody[0];
    memset(pRoleUpdateRsp, 0x00, sizeof(SecurityDefinitionRspT));
    pRsp->msgHdr.msgLen = sizeof(SecurityDefinitionReqT);

    memset(&data, 0x00, sizeof(OrgMemDataRefT));
    dataLen = sizeof(OrgMemDataRefT);

    // [IN]Set Parameters.
    data.eMessageType = MSG_TYPE_ORG_MARKET_ROLE_UPDATE;
    strcpy(data.strUserId,   pRoleUpdateReq->strUserId);
    strcpy(data.strOpOrgId,  pRoleUpdateReq->strOpOrgId);
    data.intOrgMktSt[0] = pRoleUpdateReq->intPrvlgIRS;
    data.intOrgMktSt[1] = pRoleUpdateReq->intPrvlgSIRS;
    data.intOrgMktSt[2] = pRoleUpdateReq->intPrvlgSBF;
    data.intOrgMktSt[3] = pRoleUpdateReq->intPrvlgSIRSCCP;
    data.intOrgMktSt[4] = pRoleUpdateReq->intPrvlgSBFCCP;
    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);
    /*-----------------------------通用检查--------------------------------*/
    rc = CommonChk( pRoleUpdateReq->strUserId, 
                    atoi(pRoleUpdateReq->strOpOrgId), 
                    pRoleUpdateReq->iFuncId, 
                    pRoleUpdateReq->strToken, 
                    &data.intOrgId );
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    rc = OrgInfoGetById(atoi(data.strOpOrgId), &orgInfo);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    // 桥机构信息(前)状态取得
    rc = BrdgOrgInfoGetById(atoi(data.strOpOrgId), &brdgOrgInfo);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    prevBrdgSt = brdgOrgInfo.brdgOrgSt;

    // 桥机构信息(后)状态取得
    if (0 == strcmp("", brdgOrgInfo.usrLgnNm)) {
        postBrdgSt = 0;
    }
    else {
        rc = IrsUsrInfoGetByName(brdgOrgInfo.usrLgnNm, &usrInfo);
        if (NOTOK(rc)) {
            postBrdgSt = 0;
        }
        else {
            if (C_USR_ST_ACTIVE == usrInfo.mktSt[0] &&      // 用户的IRS市场权限
                C_ORG_ST_ACTIVE == data.intOrgMktSt[0] &&   // 机构的IRS市场权限
                C_CRT_NONE == brdgOrgInfo.crdtOprtngSt &&   // 当前无授信操作
                1 == brdgOrgInfo.brdgPrvlgFlag &&           // 该机构为桥机构
                1 == brdgOrgInfo.brdgIntntnFlag ) {         // 该机构愿意成为桥机构
                postBrdgSt = 1;
            }
            else {
                postBrdgSt = 0;
            }
        }
    }

    //IRS市场(有)
    if (data.intOrgMktSt[0]  == C_ORG_ST_FORBID &&
        orgInfo.mktTypeSt[0] == C_ORG_ST_ACTIVE) {
        // IRS权限(有->无)
        data.intSt = data.intOrgMktSt[0];
        data.intMktTp = C_MKT_TP_IRS;
        data.intUpdUsrMktFlg = C_USR_MKT_UPDATE_YES;
        // 刷新桥单
        if (0 == prevBrdgSt && 1 == postBrdgSt) {
            // 刷新全市场
            rc = MtchBrdgOrdrUpdt( TRUE, SET_MKT_IRS, ACTN_BRDG_DEL_ALL, &brdgOrdr );
            RAISE_ERR(rc, RTN);
        }
        else if (1 == prevBrdgSt && 0 == postBrdgSt) {
            // 刷新该机构
            brdgOrdr.brdgOrgId = orgInfo.pos;
            rc = MtchBrdgOrdrUpdt( TRUE, SET_MKT_IRS, ACTN_BRDG_DEL_BRDG, &brdgOrdr );
            RAISE_ERR(rc, RTN);
        }
        else{
            // 不刷新桥单
        }

        // 撤销订单
        /* init NewOrderSingleRspT */
       InitRspDat(&pRoleUpdateRsp->rspOrderCancel);
       rc = MtchrPrcsCnclOrgOrdrBySet(
               SET_MKT_IRS, 
               orgInfo.orgId, 
               timestamp, 
               &pRoleUpdateRsp->rspOrderCancel);
        RAISE_ERR(rc, RTN);

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);
    }
    else {
        // IRS权限(无->有)
        data.intSt = data.intOrgMktSt[0];
        data.intMktTp = C_MKT_TP_IRS;
        data.intUpdUsrMktFlg = C_USR_MKT_UPDATE_NO;
        // 刷新桥单
        if (0 == prevBrdgSt && 1 == postBrdgSt) {
            // 刷新全市场
            rc = MtchBrdgOrdrUpdt( TRUE, SET_MKT_IRS, ACTN_BRDG_DEL_ALL, &brdgOrdr );
            RAISE_ERR(rc, RTN);
        }
        else if (1 == prevBrdgSt && 0 == postBrdgSt) {
            // 刷新该机构
            brdgOrdr.brdgOrgId = orgInfo.pos;
            rc = MtchBrdgOrdrUpdt( TRUE, SET_MKT_IRS, ACTN_BRDG_DEL_BRDG, &brdgOrdr );
            RAISE_ERR(rc, RTN);
        }
        else{
            // 不刷新桥单
        }

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);
    }

    //SIRS市场(有)
    if (data.intOrgMktSt[1]  == C_ORG_ST_FORBID &&
        orgInfo.mktTypeSt[1] == C_ORG_ST_ACTIVE) {
        data.intSt = data.intOrgMktSt[1];
        data.intMktTp = C_MKT_TP_SIRS;
        data.intUpdUsrMktFlg = C_USR_MKT_UPDATE_YES;

        // 撤销订单
        /* init NewOrderSingleRspT */
       InitRspDat(&pRoleUpdateRsp->rspOrderCancel);
       rc = MtchrPrcsCnclOrgOrdrBySet(
               SET_MKT_SIRS, 
               orgInfo.orgId, 
               timestamp, 
               &pRoleUpdateRsp->rspOrderCancel);
        RAISE_ERR(rc, RTN);

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);
    }
    else {
        data.intSt = data.intOrgMktSt[1];
        data.intMktTp = C_MKT_TP_SIRS;
        data.intUpdUsrMktFlg = C_USR_MKT_UPDATE_NO;

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);
    }

    //SBF市场(mktTypeSt[2]无)
    //SIRSCCP市场(mktTypeSt[3]无)

    //SBFCCP市场(mktTypeSt[4]有)
    if (data.intOrgMktSt[4]  == C_ORG_ST_FORBID &&
        orgInfo.mktTypeSt[4] == C_ORG_ST_ACTIVE) {
        data.intSt = data.intOrgMktSt[4];
        data.intMktTp = C_MKT_TP_SBFCCP;
        data.intUpdUsrMktFlg = C_USR_MKT_UPDATE_YES;

        // 撤销订单
        /* init NewOrderSingleRspT */
       InitRspDat(&pRoleUpdateRsp->rspOrderCancel);
       rc = MtchrPrcsCnclOrgOrdrBySet(
               SET_MKT_SBFCCP, 
               orgInfo.orgId, 
               timestamp, 
               &pRoleUpdateRsp->rspOrderCancel);
        RAISE_ERR(rc, RTN);

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);
    }
    else {
        data.intSt = data.intOrgMktSt[4];
        data.intMktTp = C_MKT_TP_SBFCCP;
        data.intUpdUsrMktFlg = C_USR_MKT_UPDATE_NO;

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
