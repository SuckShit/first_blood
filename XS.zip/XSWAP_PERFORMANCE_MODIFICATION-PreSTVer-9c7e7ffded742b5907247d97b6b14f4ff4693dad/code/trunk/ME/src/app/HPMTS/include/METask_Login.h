/***
Created on July 20, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _METASK_LOGIN_H_
#define _METASK_LOGIN_H_

#include "internal_function_def.h"
#include "intrnl_msg.h"

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

// 用户登录
ResCodeT OnLoginStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnLoginStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

// 用户登出
ResCodeT OnLogoutStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnLogoutStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

// 强制移除在线用户
ResCodeT OnRemoveOnlineUserStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnRemoveOnlineUserStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);



#endif /* _METASK_LOGIN_H_ */
