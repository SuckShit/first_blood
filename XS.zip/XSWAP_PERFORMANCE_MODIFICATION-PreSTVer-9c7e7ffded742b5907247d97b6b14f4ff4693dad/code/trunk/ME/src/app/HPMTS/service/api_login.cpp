/***
Created on Aug 3, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "login.h"
#include "api_login.h"
#include "user_login.h"
#include "user_order.h"
#include "api_common.h"
#include "match_lib.h"

#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "OrgInfoDb.h"
#include "OrgInfoBrdgDb.h"
#include "usr.h"
#include "org_info.h"
#include "base_param.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/******************************************************************************
 **
 ** Detail Service Callback : ApiLogin
 **
 ******************************************************************************/
ResCodeT ApiLogin(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiLogin" );
    ResCodeT rc = NO_ERR;

    ApiLoginReqT*   pLoginReq;
    ApiLoginRespT*  pLoginResp;

    pLoginReq = (ApiLoginReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(ApiLoginRespT);
    pLoginResp = (ApiLoginRespT*)&pRsp->msgBody[0];

    memset(pLoginResp, 0, sizeof(ApiLoginRespT));


    // common check
    if (strcmp(pLoginReq->strInitUserId, pLoginReq->strUserId) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }

    if (pLoginReq->iLoginType != 1)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }

    // get market state, OUT_MRKTSTATE (BASE_PARAM)
    pBaseParamT pParamData;

    rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pParamData);
    RAISE_ERR(rc, RTN);
    pLoginResp->iMktState = atoi(pParamData->paramValue);


    // ��ȡ��¼ʱ��, updateTime
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);
    RAISE_ERR(rc, RTN);

    strcpy(pLoginResp->strUpdateTime, strTimestamp);


    // ��ȡ�û���Ϣ
    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pLoginReq->strUserId, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(APIERR_CODE_INVLD_USER, RTN);
    }

    // �Ƿ�API�û�
    if (strcmp(pUserInfo->apiF, "1") != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_USER, RTN);
    }

    // ��ȡ������Ϣ
    pOrgInfoT   pOrgInfo;
    rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(APIERR_CODE_INVLD_USER, RTN);
    }

    if (strcmp(pOrgInfo->orgCd, pLoginReq->strOrgCd) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_USER, RTN);
    }


    // ����û�״̬
    if (strcmp(pUserInfo->usrSt, "1") != 0)
    {
        RAISE_ERR(APIERR_CODE_USER_FORBID, RTN);
    }

    // ������״̬ 0���� 1��Ծ
    if (pOrgInfo->orgSt != 1)
    {
        RAISE_ERR(APIERR_CODE_ORG_FORBID, RTN);
    }


    // get token
    int64 nowtime;
    nowtime = 0;
    GetSysTimestamp(&nowtime);
    nowtime %= 1000000000000000;
    sprintf(pLoginResp->strToken, "%15lld", nowtime);



    // ��ȡ�û����ͣ�ÿ��API�û�����Ӧһ��Ȩ��
    rc = CheckApiUserRole(pUserInfo->roleId, pLoginResp->iUserRole);
    RAISE_ERR(rc, RTN);

    if (pLoginResp->iUserRole = C_APIUSER_ROLE_DEAL)
    {
        // ����Ƿ��б�Ľ���API�û�����
        int iCount = 0;
        rc = GetResultCntOfOtherApiUsrOnln(connId, pUserInfo->orgId, pLoginReq->strUserId, &iCount);
        RAISE_ERR(rc, RTN);

        if (iCount > 0)
        {
            RAISE_ERR(APIERR_CODE_ALREADY_LOGIN, RTN);
        }
    }


    strcpy(pLoginResp->strUserId, pLoginReq->strUserId);
    strcpy(pLoginResp->strOrgCd, pLoginReq->strOrgCd);
    strcpy(pLoginResp->strRequestId, pLoginReq->strRequestId);


    UsrOnln userData;
    UsrLgnHstry sHistory;
    memset(&sHistory, 0, sizeof(UsrLgnHstry));
    strcpy(sHistory.usrNm, pLoginReq->strUserId);
    itoa(C_OPTION_TP_IN, sHistory.oprtTp, 10);
    strcpy(sHistory.lgnIp, " ");
    strcpy(sHistory.oprtTm, pLoginResp->strUpdateTime);

    if (!pUserInfo->usrOnlnStatus)
    {
        // insert online user table
        memset(&userData, 0, sizeof(UsrOnln));
        strcpy(userData.usrNm, pLoginReq->strUserId);
        strcpy(userData.sesnId, pLoginResp->strToken);
        userData.lgnTp = pLoginResp->iUserRole;
        strcpy(userData.lgnTm, pLoginResp->strUpdateTime);
        strcpy(userData.apiF, "1");

//        rc = InsertUserOnline(connId, &userData);
//        RAISE_ERR(rc, RTN);
    }
    else
    {
        // update online user table
        memset(&userData, 0, sizeof(UsrOnln));
        strcpy(userData.sesnId, pLoginResp->strToken);
        strcpy(userData.lgnTm, pLoginResp->strUpdateTime);

//        rc = UpdateApiUserOnline(connId, &userData);
//        RAISE_ERR(rc, RTN);

/*
        // insert history
        memset(&sHistory, 0, sizeof(UsrLgnHstry));
        strcpy(sHistory.usrNm, pLoginReq->strUserId);
        itoa(C_OPTION_TP_IN, sHistory.oprtTp, 10);
        strcpy(sHistory.lgnIp, " ");
        strcpy(sHistory.oprtTm, pLoginResp->strUpdateTime);
*/
//        rc = InsertUserLoginHistory(connId, &sHistory);
//        RAISE_ERR(rc, RTN);


        if (pLoginResp->iUserRole = C_APIUSER_ROLE_DEAL)
        {
            // ������API�û����߳������� PCK_API_ORD.SP_IRSAPI_ORDCANCELBYAPIUSR
            NewOrderSingleRspT  sApiResp;
            // todo setid
//            rc = MtchrPrcsOrdrCnclByUser(1, timestamp, pUserInfo->pos, pOrgInfo->pos, &sApiResp);
//            rc = MtchrPrcsOrdrCnclByUser(pReq->msgHdr.setId, timestamp, pUserInfo->pos, pOrgInfo->pos, &sApiResp);
            RAISE_ERR(rc, RTN);

//            PCK_API_ORD.SP_SIRSAPI_ORDCANCELBYAPIUSR
//            PCK_SBFCCPAPI_ORD.SP_SBFCCPAPI_ORDCANCELBYUSR
        }
        else if (pLoginResp->iUserRole = C_APIUSER_ROLE_QUOT)
        {
            // �������鶩��
//            DELETE QT_SBSCRPTN_API WHERE USR_LGN_NM = IN_USRID;
        }
    }

//    pUserInfo->usrOnlnStatus = TRUE;

    rc = SerializeUsrRefData(connId, MSG_TYPE_API_LOGIN, &userData, &sHistory, NULL, 0);
    RAISE_ERR(rc, RTN);



    // ��ȡIRS market state
    pBaseParamT pIrsParamData;

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);
    pLoginResp->iMktStIrs = atoi(pParamData->paramValue);

    strcpy(pLoginResp->strUpdateTimeIrs, pLoginResp->strUpdateTime);


    // todo OUT_ORDINFO
    // todo OUT_SIRSORDINFO
    // todo OUT_SBFCCPORDINFO
    // todo OUT_BRDGINFO


    rc = GetBoundId(connId, &pLoginResp->iMaxOutboundId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : ApiLogout
 **
 ******************************************************************************/
ResCodeT ApiLogout(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiLogout" );
    ResCodeT rc = NO_ERR;

    ApiLogoutReqT*  pLogoutReq;
    ApiLogoutRespT* pLogoutResp;

    pLogoutReq = (ApiLogoutReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(ApiLogoutRespT);
    pLogoutResp = (ApiLogoutRespT*)&pRsp->msgBody[0];

    memset(pLogoutResp, 0, sizeof(ApiLogoutRespT));


    if (pLogoutReq->iLoginType != 2)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }


    // API_COMMONCHK
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pLogoutReq->strUserId,
                        pLogoutReq->strOrgCd,
                        pLogoutReq->iFuncId,
                        pLogoutReq->strToken,
                        1,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // ��ȡ�ǳ�ʱ��, updateTime
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);
    RAISE_ERR(rc, RTN);


    // 1. clear online status of USR_ONLN
    // DELETE USR_ONLN WHERE USR_NM = IN_USRID;
//    rc = DeleteUserOnline(connId, pLogoutReq->strUserId);
//    RAISE_ERR(rc, RTN);


    // 2. �����û���½��ʷ��Ϣ
    UsrLgnHstry sHistory;
    memset(&sHistory, 0, sizeof(UsrLgnHstry));
    strcpy(sHistory.usrNm, pLogoutReq->strUserId);
    itoa(C_OPTION_TP_OUT, sHistory.oprtTp, 10);
    strcpy(sHistory.lgnIp, " ");
    strcpy(sHistory.oprtTm, strTimestamp);
//    rc = InsertUserLoginHistory(connId, &sHistory);
//    RAISE_ERR(rc, RTN);


    // 1. �����¼״̬���ڴ��У�
    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pLogoutReq->strUserId, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }
//    pUserInfo->usrOnlnStatus = FALSE;


    // ��ȡ�û����ͣ�ÿ��API�û�����Ӧһ��Ȩ��
    rc = CheckApiUserRole(pUserInfo->roleId, pLogoutResp->iUserRole);
    RAISE_ERR(rc, RTN);


    strcpy(pLogoutResp->strUserId, pLogoutReq->strUserId);
    strcpy(pLogoutResp->strOrgCd, pLogoutReq->strOrgCd);
    strcpy(pLogoutResp->strRequestId, pLogoutReq->strRequestId);
    strcpy(pLogoutResp->strToken, pLogoutReq->strToken);


    if (pLogoutResp->iUserRole = C_APIUSER_ROLE_DEAL)
    {
        // ����API�û����߳�������
        // PCK_API_ORD.SP_IRSAPI_ORDCANCELBYAPIUSR
        pOrgInfoT   pOrgInfo;
        rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgInfo);
        RAISE_ERR(rc, RTN);

        NewOrderSingleRspT  sApiResp;
        rc = MtchrPrcsCnclOrgOrdrByUsr(pUserInfo->pos, pOrgInfo->pos, timestamp, &sApiResp);
        RAISE_ERR(rc, RTN);

//        PCK_API_ORD.SP_SIRSAPI_ORDCANCELBYAPIUSR
//        PCK_SBFCCPAPI_ORD.SP_SBFCCPAPI_ORDCANCELBYUSR
    }
    else if (pLogoutResp->iUserRole = C_APIUSER_ROLE_QUOT)
    {
        // �������鶩��
//        DELETE QT_SBSCRPTN_API WHERE USR_LGN_NM = IN_USRID;
    }


    rc = SerializeUsrRefData(connId, MSG_TYPE_API_LOGOUT, NULL, &sHistory, NULL, 0);
    RAISE_ERR(rc, RTN);


    // todo OUT_ORDINFO
    // todo OUT_SIRSORDINFO
    // todo OUT_SBFCCPORDINFO
    // todo OUT_BRDGINFO


    rc = GetBoundId(connId, &pLogoutResp->iMaxOutboundId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
