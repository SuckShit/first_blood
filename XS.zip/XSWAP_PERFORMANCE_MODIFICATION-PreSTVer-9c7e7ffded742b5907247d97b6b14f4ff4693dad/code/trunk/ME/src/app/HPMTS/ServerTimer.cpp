/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "ServerTimer.h"

ServerTimer::ServerTimer(MatchingListener* pSessionListener,
                        long startTime,
                        long endTime,
                        long interval,IMIX::BasicMessage* Msg)
            :DEPTimer(startTime,endTime,interval)
{
    this->m_pMatchingListener = pSessionListener;
    m_inMessage=Msg;
}

ServerTimer::~ServerTimer()
{

}

void ServerTimer::OnTimer()
{
    m_pMatchingListener->OnImixMEMsg(*m_inMessage);
}

