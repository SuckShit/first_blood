/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "internal_function_def.h"
#include "UTILITY/logfile.h"
#include "IMIX20/Component/RiskInstrumentScopeGrp.h"
using namespace IMIX20;

/************************************
*��������DoubleToString
*���ܣ� long��ת��Ϊʮ�����ַ���
*��Σ�
        lValue: ��Ҫת������ֵ
        strValue: ת������ַ���
*************************************/
PREFIX_FUNC void DoubleToString(double dValue, IRS_STRING& strValue)
{
    strValue = "0.0";
    char pcCode[64] = {0x00};
    sprintf(pcCode, "%.4f", dValue);
    strValue = pcCode;


    char cBuffer[64] = {0x00};
    sprintf(cBuffer, "%.10f", dValue);
    int i = 0;
    int n = 0; //��?o��2??a0��???��y��?????
    int m = 0; //D?��y��?��?????
    while (cBuffer[i] != '\0')
    {
        if (cBuffer[i] != '0')
        {
            n = i;
        }

        if (cBuffer[i] == '.')
        {
            m = i;
        }
        i++;
    }

    if ( (n-m) >4) //D?��y��?��?��DD��??��y3?1y4??D����a?��??
    {
        LOG_WARNING("double precision is overflow!");
    }
}

PREFIX_FUNC void DoubleZToString(double dValue, IRS_STRING& strValue)
{
    strValue = "0";
    char pcCode[64] = {0x00};
    sprintf(pcCode, "%.0f", dValue);
    strValue = pcCode;
}

/************************************
*��������IntToString
*���ܣ� int��ת��Ϊ�ַ���
*��Σ�
        nValue: ��Ҫת������ֵ
        strValue: ת������ַ���
        nRadix����ȡ�ַ����Ľ���
*************************************/
PREFIX_FUNC void IntToString(int nValue, IRS_STRING& strValue, int nRadix)
{
    strValue = "0";
    char pcCode[64] = {0x00};
    itoa(nValue, pcCode, nRadix);
    strValue = pcCode;
}

/************************************
*��������StringToInt
*���ܣ� �ַ���ת��Ϊint
*��Σ�
        strValue: ��Ҫת�����ַ���
        nValue: ת�������ֵ
*************************************/
PREFIX_FUNC int StringToInt(IRS_STRING strValue)
{
    int nValue = atoi(strValue.c_str());
    return nValue;
}



/************************************
*��������StringToInt
*���ܣ� �ַ���ת��Ϊint
*��Σ�
        strValue: ��Ҫת�����ַ���
        nValue: ת�������ֵ
*************************************/
PREFIX_FUNC int64 PrefixStringToInt64(IRS_STRING strValue, int32 prefixLen)
{
    int64 nValue = StringToInt64(strValue.erase(0,prefixLen).c_str());
    return nValue;
}


/************************************
*��������StringToInt
*���ܣ� �ַ���ת��Ϊint
*��Σ�
        strValue: ��Ҫת�����ַ���
        nValue: ת�������ֵ
*************************************/
PREFIX_FUNC int64 StringToInt64(IRS_STRING strValue)
{
    int64 nValue = atoll(strValue.c_str());
    return nValue;
}


/************************************
*��������StringToChar
*���ܣ� ��ȡ�ַ������ַ�
*������
    strIn:  [IN]�����ַ���
    cOut:   [OUT]��ȡ�����ַ�
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC APP_ERROR_CODE StringToChar(IRS_STRING strIn, char& cOut)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    const char* pcIn = strIn.c_str();
    if (pcIn)
    {
        cOut = *pcIn;
    }
    else
    {
        nRet = APP_CODE_INCOM_PARAM_ERROR;
    }

    return nRet;
}

/************************************
*��������CharToString
*���ܣ� ���ַ�ת��Ϊ�ַ���
*������
    cIn:    [IN]�����ַ���
*����ֵ:�ַ���
*************************************/
PREFIX_FUNC IRS_STRING CharToString(char cIn)
{
    IRS_STRING strOut = "";
    char pcOut[2] = {0};
    pcOut[0] = cIn;
    strOut = pcOut;

    return strOut;
}

void SpliteDataAndTime(IRS_STRING strSource,IRS_STRING& strDate, IRS_STRING& strTime)
{
    strDate = "";
    strTime = "";
    IRS_STRING strFormat = "YYYYMMDD-HH:DD:SS";
    if (strSource.length() != strFormat.length())
    {
        return;
    }

    int nFind = strSource.find('-');
    if (IRS_STRING::npos == nFind)
    {
        return;
    }

    strDate = strSource.substr(0, nFind);
    strTime = strSource.substr(nFind + 1, strSource.length());
}

void GetTimeOfDay(irs_timeval& irstv)
{
#ifdef WIN32
    irstv.tv_sec = 0;
    irstv.tv_usec = 0;
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    irstv.tv_sec = tv.tv_sec;
    irstv.tv_usec = tv.tv_usec;
#endif
}

irs_timeval SubtractTime(irs_timeval& tvStart, irs_timeval& tvStop)
{
    irs_timeval tv;
    irs_timeval start;
    irs_timeval stop;
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    if (tvStop.tv_sec < tvStart.tv_sec ||
        (tvStop.tv_sec == tvStart.tv_sec && tvStop.tv_usec < tvStart.tv_usec))
    {
        start = tvStop;
        stop = tvStart;
        tv.bLater = false;
    }
    else
    {
        start = tvStart;
        stop = tvStop;
    }

    if (tvStop.tv_usec >= start.tv_usec)
    {
        tv.tv_sec = stop.tv_sec - start.tv_sec;
        tv.tv_usec = stop.tv_usec - start.tv_usec;
    }
    else
    {
        tv.tv_sec = stop.tv_sec - start.tv_sec - 1;
        tv.tv_usec = stop.tv_usec - start.tv_usec + 1000000;
    }
    return tv;
}

/************************************
*��������GetOrdCancelReplaceReqMsgFunction
*���ܣ� ��ȡ������ϢOrderCancelReplaceRequest�Ĺ�������
*������
        message:    [IN]OrderCancelReplaceRequest��Ϣ����
*����ֵ��������Ϣ�Ĺ�������
*************************************/
PREFIX_FUNC
MSG_G_FUNC GetOrdCancelReplaceReqMsgFunction(OrderCancelReplaceRequest message)
{
    IRS_STRING sFunction = "[GetOrdCancelReplaceReqMsgFunction]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    MSG_G_FUNC eFunctionType = MSG_G_FUNC_DEFAULT;

    IRS_STRING strExecInst = "";
    IRS_STRING strOcoOrdId = "";
    IRS_STRING strInst = "";

    strExecInst = message.GetExecInst();
    strOcoOrdId = message.GetListID();
    strInst = message.GetSecurityID();

    LOG_DEBUG("%s strExecInst = %s, strOcoOrdId = %s, strInst = %s",
            sFunction.c_str(), strExecInst.c_str(), strOcoOrdId.c_str(), strInst.c_str());

    if ((EXECINST_ORD_NEW == strExecInst ||
        EXECINST_ORD_NEW_EXEC == strExecInst) &&
        !strOcoOrdId.empty() &&
        !strInst.empty())
    {
        eFunctionType = E_OCOORD_MODIFY_SUBMIT;
    }
    else if (EXECINST_ORD_SAVING == strExecInst &&
            !strOcoOrdId.empty() &&
            !strInst.empty())
    {
        eFunctionType = E_OCOORD_MODIFY_SAVE;
    }
    else if ((EXECINST_ORD_ACTIVATE == strExecInst ||
                EXECINST_ORD_ACTIVATE_EXEC == strExecInst) &&
                !strOcoOrdId.empty())
    {
        eFunctionType = E_OCOORD_ACTIVATE;
    }
    else if (EXECINST_ORD_FREEZE == strExecInst &&
            !strOcoOrdId.empty() &&
            strInst.empty())
    {
        eFunctionType = E_OCOORD_FREEZE;
    }
    else if ((EXECINST_ORD_NEW == strExecInst ||
            EXECINST_ORD_NEW_EXEC == strExecInst) &&
            !strInst.empty())
    {
        eFunctionType = E_ORD_MODIFY_SUBMIT;
    }
    else if (EXECINST_ORD_SAVING == strExecInst &&
            !strInst.empty())
    {
        eFunctionType = E_ORD_MODIFY_SAVING;
    }
    else if (EXECINST_ORD_SAVING == strExecInst && strInst.empty())
    {
        eFunctionType = E_ORD_FREEZE;
    }
    else if ((EXECINST_ORD_ACTIVATE == strExecInst ||
            EXECINST_ORD_ACTIVATE_EXEC == strExecInst) &&
            strOcoOrdId.empty())
    {
        eFunctionType = E_ORD_ACTIVATE;
    }
    else
    {
        LOG_ERROR(APP_CODE_REQFUNC_ERR, APP_MSG_REQFUNC_ERR);
    }

    LOG_DEBUG("%s End..", sFunction.c_str());

    return eFunctionType;
}

/************************************
*��������GetNewOrderListMsgFunction
*���ܣ� ��ȡ������ϢNewOrderListMsg�Ĺ�������
*������
        message:    [IN]OrderCancelReplaceRequest��Ϣ����
*����ֵ��������Ϣ�Ĺ�������
*************************************/
PREFIX_FUNC
NewOrderListMsgFunction GetNewOrderListMsgFunction(NewOrderList message)
{
    IRS_STRING sFunction = "[GetNewOrderListMsgFunction]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    NewOrderListMsgFunction eFunctionType = E_NEWORDLIST_FUNC_DEFAULT;

    IRS_STRING strListExecInst = message.GetListExecInst();
    LOG_DEBUG("%s strListExecInst = %s", sFunction.c_str(), strListExecInst.c_str());

    if (LIST_EXECINST_ORD_SUBMIT == strListExecInst ||
        LIST_EXECINST_ORD_SUBMIT_EXEC == strListExecInst)//�����޸ĺ��ύ
    {
        eFunctionType = E_OCOORD_SUBMIT;
    }
    else if (LIST_EXECINST_ORD_SAVE == strListExecInst)//�����޸ĺ󱣴�
    {
        eFunctionType = E_OCOORD_SAVE;
    }

    LOG_DEBUG("%s End..", sFunction.c_str());
    return eFunctionType;
}

/************************************
*��������GetCSMsgFunction
*���ܣ� ��ȡ������ϢCS�Ĺ�������
*������
        message:    [IN]OrderCancelReplaceRequest��Ϣ����
*����ֵ��������Ϣ�Ĺ�������
*************************************/
PREFIX_FUNC
CSMsgFunction GetCSMsgFunction(PartyRiskLimitsDefinitionRequest message)
{
    IRS_STRING sFunction = "[GetCSMsgFunction]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    CSMsgFunction eFunctionType = (CSMsgFunction)E_DEFAULT;

    char cListUpdateAction = CHAR_DEFAULT;
    IRS_STRING strRiskInstrumentMultiplier = "";
    IRS_STRING strRiskLimitAmtUpdateMethod = "";

    PartyRiskLimitsUpdateGrp* pPartyRiskLimitsUpdateGrp = message.GetPartyRiskLimitsUpdateGrp();
    if (NULL != pPartyRiskLimitsUpdateGrp)
    {
        PartyRiskLimitsUpdateGrp::NoPartyRiskLimits* pNoPartyRiskLimits = pPartyRiskLimitsUpdateGrp->GetNoPartyRiskLimits();
        if (NULL != pNoPartyRiskLimits)
        {
            cListUpdateAction = pNoPartyRiskLimits->GetListUpdateAction();
            RiskLimitsGrp* pRiskLimitsGrp = pNoPartyRiskLimits->GetRiskLimitsGrp();
            if (NULL != pRiskLimitsGrp)
            {
                RiskLimitsGrp::NoRiskLimits* pNoRiskLimits = pRiskLimitsGrp->GetNoRiskLimits();
                if (NULL != pNoRiskLimits)
                {
                    RiskInstrumentScopeGrp* pRiskInstrumentScopeGrp = pNoRiskLimits->GetRiskInstrumentScopeGrp();
                    if (NULL != pRiskInstrumentScopeGrp)
                    {
                        RiskInstrumentScopeGrp::NoRiskInstruments* pNoRiskInstrumentScopes = pRiskInstrumentScopeGrp->GetNoRiskInstruments();
                        if (NULL != pNoRiskInstrumentScopes)
                        {
                            strRiskInstrumentMultiplier = pNoRiskInstrumentScopes->GetRiskInstrumentMultiplier();
                        }
                    }

                    RiskLimitTypesGrp* pRiskLimitTypesGrp = pNoRiskLimits->GetRiskLimitTypesGrp();
                    if (NULL != pRiskLimitTypesGrp)
                    {
                        RiskLimitTypesGrp::NoRiskLimitTypes* pNoRiskLimitTypes = pRiskLimitTypesGrp->GetNoRiskLimitTypes();
                        if (NULL != pNoRiskLimitTypes)
                        {
                            strRiskLimitAmtUpdateMethod = pNoRiskLimitTypes->GetRiskLimitAmountUpdateMethod();
                        }
                    }
                }
            }
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoPartyRiskLimits error!", sFunction.c_str());
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetPartyRiskLimitsUpdateGrp error!", sFunction.c_str());
    }


    LOG_DEBUG("%s cListUpdateAction = %s, strRiskInstrumentMultiplier = %s, strRiskLimitAmtUpdateMethod = %s",
            sFunction.c_str(), CharToString(cListUpdateAction).c_str(), strRiskInstrumentMultiplier.c_str(), strRiskLimitAmtUpdateMethod.c_str());

    if (!strRiskLimitAmtUpdateMethod.empty())
    {
        eFunctionType = E_CSMSG_CREDIT_REFRESH_METHOD_UPDATE;
    }
    else if (!strRiskInstrumentMultiplier.empty() &&
                E_LISTUPDATEACTION_SUBMIT == cListUpdateAction)
    {
        eFunctionType = E_CSMSG_RISKCOFE_UPDATE;
    }
    else if (E_LISTUPDATEACTION_CANCEL == cListUpdateAction || E_LISTUPDATEACTION_CANCEL_CONFIRM == cListUpdateAction)
    {
        eFunctionType = E_CSMSG_CREDIT_RISK_SET_CANCEL;
    }
    else if (E_LISTUPDATEACTION_MODIFY == cListUpdateAction)
    {
        eFunctionType = E_CSMSG_CREDIT_RISK_MODIFY;
    }
    else if (E_LISTUPDATEACTION_SUBMIT == cListUpdateAction)
    {
        eFunctionType = E_CSMSG_CREDIT_UPDATE;
    }
    else
    {
        LOG_ERROR(APP_CODE_REQFUNC_ERR, APP_MSG_REQFUNC_ERR);
    }

    LOG_DEBUG("%s End..", sFunction.c_str());
    return eFunctionType;
}


/************************************
*��������GetOrgAndTraderFromParties
*���ܣ� ͨ��IMIX��Ϣ��Parties�л�ȡ��������ͽ���ԱID
*������
        pParties:   [IN]��Ϣ�е����
        strOrg:     [OUT]������ʶ
        strTrader:  [OUT]����Ա��ʶ
*************************************/
PREFIX_FUNC
APP_ERROR_CODE GetOrgAndTraderFromParties(Parties* pParties, IRS_STRING& strOrg, IRS_STRING& strTrader, PARTY_ROLE ePartyRole)
{
    //��ʼ��Ϊ��
    strOrg = "";
    strTrader = "";

    //������Ч����֤
    if (NULL == pParties)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Income parameter (pParties) is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    Parties::NoPartyIDs* pPartyIDs = pParties->GetNoPartyIDs();
    if (NULL == pPartyIDs)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Income parameter (pParties->pPartyIDs) is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    if (ePartyRole == pPartyIDs->GetPartyRole())//����Ա
    {
        strTrader = pPartyIDs->GetPartyID();
    }

    PtysSubGrp* pSubGrp = pPartyIDs->GetPtysSubGrp();
    if (NULL == pSubGrp)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Income parameter (pParties->pPartyIDs->pSubGrp) is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    PtysSubGrp::NoPartySubIDs* pSubIDs = pSubGrp->GetNoPartySubIDs();
    if (NULL == pSubIDs)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Income parameter (pParties->pPartyIDs->pSubGrp->pSubIDs) is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    if (E_PARTYSUBID_ORG == pSubIDs->GetPartySubIDType())//����
    {
        strOrg = pSubIDs->GetPartySubID();
    }
    return APP_CODE_SUCCESS;
}

PREFIX_FUNC
ResCodeT SetOrgAndTraderToParties(Parties* pParties, IRS_STRING strOrg, IRS_STRING strTraderId,
                                        IRS_STRING strTraderName, PARTY_ROLE ePartyRole)
{
    BEGIN_FUNCTION("SetOrgAndTraderToParties");
    ResCodeT                rc = NO_ERR;
    PtysSubGrp* pSubGrp;
    PtysSubGrp::NoPartySubIDs* pSubIDs= NULL;

    Parties::NoPartyIDs* pPartyIDs = pParties->AddNoPartyIDs();
    if (NULL == pPartyIDs)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    //�����û�ID
    pPartyIDs->SetPartyRole(ePartyRole);
    pPartyIDs->SetPartyID(strTraderId);
    pSubGrp = pPartyIDs->GetPtysSubGrp();
    if (NULL == pSubGrp)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //���û�������
    pSubIDs = pSubGrp->AddNoPartySubIDs();
    if (NULL != pSubIDs)
    {
        pSubIDs->SetPartySubIDType(E_PARTYSUBID_ORG);
        pSubIDs->SetPartySubID(strOrg);
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    //�����û�����
    pSubIDs = pSubGrp->AddNoPartySubIDs();
    if (NULL != pSubIDs)
    {
        pSubIDs->SetPartySubIDType(E_PARTYSUBID_USERNAME);
        pSubIDs->SetPartySubID(strTraderName);
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

PREFIX_FUNC
ResCodeT SetDealMsgParties(IMIX20::Parties* pParties, IRS_STRING strOrgId, IRS_STRING strOrgName,
                            IRS_STRING strTraderId, IRS_STRING strTraderName, PARTY_ROLE ePartyRole)
{

    BEGIN_FUNCTION("OnOrderSubmitStart");
    ResCodeT                rc = NO_ERR;

    Parties::NoPartyIDs* pPartyIDs = pParties->AddNoPartyIDs();
    PtysSubGrp* pSubGrp;
    //���û�������
    PtysSubGrp::NoPartySubIDs* pSubIDs = NULL;

    if (NULL == pPartyIDs)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    //�����û�ID
    pPartyIDs->SetPartyRole(ePartyRole);
    pPartyIDs->SetPartyID(strTraderId);
    pSubGrp = pPartyIDs->GetPtysSubGrp();
    if (NULL == pSubGrp)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pSubIDs = pSubGrp->AddNoPartySubIDs();
    if (NULL != pSubIDs)
    {
        pSubIDs->SetPartySubIDType(E_PARTYSUBID_ORG);
        pSubIDs->SetPartySubID(strOrgId);
    }
    else
    {
//      LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Set orgid failed..");
    }


    //�����û�����
    pSubIDs = pSubGrp->AddNoPartySubIDs();
    if (NULL != pSubIDs)
    {
        pSubIDs->SetPartySubIDType(E_PARTYSUBID_USERNAME);
        pSubIDs->SetPartySubID(strTraderName);
    }
    else
    {
//      LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Add NoPartySubIDs failed..");
    }

    //���û�������
    pSubIDs = pSubGrp->AddNoPartySubIDs();
    if (NULL != pSubIDs)
    {
        pSubIDs->SetPartySubIDType(E_PARTYSUBID_ORGNAME);
        pSubIDs->SetPartySubID(strOrgName);
    }
    else
    {
//      LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Add NoPartySubIDs failed..");
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

PREFIX_FUNC
APP_ERROR_CODE SetOrgToParties(Parties* pParties, IRS_STRING strOrg, PARTY_ROLE ePartyRole)
{
    //������Ч����֤
    if (NULL == pParties)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Income parameter (pParties) is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    Parties::NoPartyIDs* pPartyIDs = pParties->AddNoPartyIDs();
    if (NULL == pPartyIDs)
    {
        LOG_ERROR(APP_CODE_IMIXAPI_ERR, "get NoPartyIDs error.");
        return APP_CODE_IMIXAPI_ERR;
    }
    //�����û�ID
    pPartyIDs->SetPartyRole(ePartyRole);
    pPartyIDs->SetPartyID(strOrg);

    return APP_CODE_SUCCESS;
}

/************************************
*��������GetTraderFromParties
*���ܣ� ͨ��IMIX��Ϣ��Parties�л�ȡ��������ͽ���ԱID
*������
        pParties:   [IN]��Ϣ�е����
        strOrg:     [OUT]������ʶ
        strTrader:  [OUT]����Ա��ʶ
*************************************/
PREFIX_FUNC
ResCodeT GetTraderFromParties(Parties* pParties, IRS_STRING& strTrader, PARTY_ROLE ePartyRole)
{
    BEGIN_FUNCTION("GetTraderFromParties");
    ResCodeT                rc = NO_ERR;

    bool bFind = false;
    int nSize = pParties->GetNoPartyIDs_Num();
    for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nSize + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
    {
        Parties::NoPartyIDs* pNoPartyIDs = pParties->GetNoPartyIDs(nIndex);
        if (NULL != pNoPartyIDs)
        {
            if (ePartyRole == pNoPartyIDs->GetPartyRole())//�ύ�����û�
            {
                strTrader = pNoPartyIDs->GetPartyID();
                bFind = true;
                break;
            }
        }
        else
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }
    }

    if (false == bFind)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

PREFIX_FUNC
IRS_STRING GetPartyDetailId(IMIX20::PartyDetailGrp* pPartyDetaiGrp, PARTY_DETAIL_ROLE ePartyDetailRole)
{
    IRS_STRING strPartyDetailId = "";
    if (NULL != pPartyDetaiGrp)
    {
        int nGrpSize = pPartyDetaiGrp->GetNoPartyDetails_Num();
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex< nGrpSize + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
        {
            IMIX20::PartyDetailGrp::NoPartyDetails* pNoPartyDetails = pPartyDetaiGrp->GetNoPartyDetails(nIndex);
            if (NULL != pNoPartyDetails)
            {
                if (pNoPartyDetails->GetPartyDetailRole() == ePartyDetailRole)
                {
                    strPartyDetailId = pNoPartyDetails->GetPartyDetailID();
                    break;
                }
            }
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pPartyDetailGrp is null.");
    }

    return strPartyDetailId;
}

/************************************
*��������SetOrderDetailToNoSides
*���ܣ� ���ö�����ŵ�NoSides�����
*������
    pNoSides:[IN/OUT]�����ַ���
    strOrderId: [IN]�������
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE SetOrderDetailToNoSides(TrdCapRptSideGrp::NoSides* pNoSides, IRS_STRING strOrderId)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    TradeReportOrderDetail* pTrdRptOrderDetail = pNoSides->GetTradeReportOrderDetail();
    if (NULL != pTrdRptOrderDetail)
    {
        pTrdRptOrderDetail->SetOrderID(strOrderId);
    }
    else
    {
        LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Get TradeReportOrderDetail error.");
    }

    return nRet;
}

/************************************
*��������SetLimitAmtsToNoSides
*���ܣ� ����(������)ʣ�����Ŷ�ȵ�NoSides�����
*������
    pNoSides:[IN/OUT]�����ַ���
    strLimitAmt:    [IN](��<->����)ʣ�����Ŷ��
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE SetLimitAmtsToNoSides(TrdCapRptSideGrp::NoSides* pNoSides, IRS_STRING strLimitAmt)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    if (NULL == pNoSides)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, APP_MSG_INCOM_PARAM_ERROR);
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    LimitAmts* pLimitAmts = pNoSides->GetLimitAmts();
    if (NULL != pLimitAmts)
    {
        LimitAmts::NoLimitAmts* pNoLimitAmts = pLimitAmts->AddNoLimitAmts();
        if (NULL != pNoLimitAmts)
        {
            pNoLimitAmts->SetLimitAmtType(-1);//������
            pNoLimitAmts->SetLimitAmtRemaining(strLimitAmt);
        }
        else
        {
            LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Get NoLimitAmts error.");
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Get LimitAmts error.");
    }

    return nRet;
}

/************************************
*��������SetPartiesToNoSides
*���ܣ� ����Parties�������������&�û�ID&�û����ƣ���NoSides�����
*������
    pNoSides:[IN/OUT]�����ַ���
    strOrgId:   [IN]��������
    strUserId�� [IN]�û�ID
    strUserName��[IN]�û�����
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE SetPartiesToNoSides(TrdCapRptSideGrp::NoSides* pNoSides, IRS_STRING strOrgId, IRS_STRING strUserId, IRS_STRING strUserName)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    //���û���������û���Ϣ
    Parties* pParties = pNoSides->GetParties();
    if (NULL != pParties)
    {
        SetOrgAndTraderToParties(pParties, strOrgId, strUserId, strUserName, E_PARTY_ROLE_DEAL_USER);
    }
    else
    {
        LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Get Parties error.");
    }

    return nRet;
}

/************************************
*��������SetOrderIdToGrp
*���ܣ� ���ö��������
*������
    pNestedRefOrderIDGrp:[IN/OUT]IMIX��Ϣ�Ķ��������
    strOrdId:   [IN]�������
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE SetOrderIdToGrp(NestedRefOrderIDGrp* pNestedRefOrderIDGrp, IRS_STRING strOrdId)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;
    NestedRefOrderIDGrp::NoNestedRefOrderID* pNoNestedRefOrderID = NULL;
    //���ö���
    if (NULL != pNestedRefOrderIDGrp)
    {
        pNoNestedRefOrderID = pNestedRefOrderIDGrp->AddNoNestedRefOrderID();
        if (NULL != pNoNestedRefOrderID)
        {
            pNoNestedRefOrderID->SetNestedRefOrderID(strOrdId);
        }
        else
        {
            LOG_ERROR(APP_CODE_IMIXAPI_ERR, "Get NoNestedRefOrderID error.");
            nRet = APP_CODE_IMIXAPI_ERR;
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Imcoming parameter pNestedRefOrderIDGrp is null.");
        nRet = APP_CODE_INCOM_PARAM_ERROR;
    }

    return nRet;
}

/************************************
*��������GetInstrumentPartyId
*���ܣ� ��ȡInstrumentParty�е�PartyId��ֵ
*������
    pInstrument:[IN/OUT]IMIX��Ϣ����Ԫ��
    ePartyRole: [IN]��ȡPartID�ı�ʶ
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
IRS_STRING GetInstrumentPartyId(Instrument* pInstrument, INSTRUMENT_PARTY_ROLE ePartyRole)
{
    IRS_STRING strPartyId = "";

    if (NULL == pInstrument)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pInstrument is null.");
        return strPartyId;
    }

    InstrumentParties* pInstrumentPaties = pInstrument->GetInstrumentParties();
    if (NULL == pInstrumentPaties)
    {
        LOG_ERROR(APP_CODE_IMIXAPI_ERR, "pInstrumentPaties is null.");
        return strPartyId;
    }

    int nGrpNum = pInstrumentPaties->GetNoInstrumentParties_Num();
    LOG_DEBUG("GetNoInstrumentParties_Num: %d", nGrpNum);
    bool bExist = false;
    for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nGrpNum + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
    {
        InstrumentParties::NoInstrumentParties* pNoInstrumentParties = pInstrumentPaties->GetNoInstrumentParties(nIndex);
        if (NULL == pNoInstrumentParties)
        {
            LOG_ERROR(APP_CODE_IMIXAPI_ERR, "pNoInstrumentParties is null.");
            return strPartyId;
        }

        int nInstrumentPartyRole = pNoInstrumentParties->GetInstrumentPartyRole();
        if (ePartyRole == nInstrumentPartyRole)
        {
            strPartyId = pNoInstrumentParties->GetInstrumentPartyID();
            bExist = true;
            break;
        }
        else
        {
            LOG_DEBUG("GetInstrumentPartyRole: %d", nGrpNum);
            continue;
        }
    }

    if (false == bExist)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "[InstrumentPartyRole: %d] is not exist.", ePartyRole);
    }

    return strPartyId;
}

/************************************
*��������GetRootPartyId
*���ܣ� ��ȡRootParty�е�PartyId��ֵ
*������
    pRootParties:[IN/OUT]IMIX��Ϣ����Ԫ��
    ePartyRole: [IN]��ȡPartID�ı�ʶ
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
IRS_STRING GetRootPartyId(RootParties* pRootParties, ROOT_PARTY_ROLE ePartyRole)
{
    IRS_STRING strPartyId = "";

    if (NULL == pRootParties)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pRootParties is null.");
        return strPartyId;
    }

    RootParties::NoRootPartyIDs* pNoRootPartyIDs = pRootParties->GetNoRootPartyIDs();
    if (NULL != pNoRootPartyIDs)
    {
        int nPartyRole = pNoRootPartyIDs->GetRootPartyRole();
        if (ePartyRole == nPartyRole)
        {
            strPartyId = pNoRootPartyIDs->GetRootPartyID();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get RootPartyID error, PartyRole = %d.", nPartyRole);
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get GetNoRootPartyIDs error.");
    }

    return strPartyId;
}
/************************************
*��������GetMarketDepth
*���ܣ� ��ȡ�г����鵵λ
*������
    pMarketSegmentGrp:[IN/OUT]IMIX��Ϣ����Ԫ��
    nMarketDepth:   [OUT]�г����鵵λֵ
*����ֵ:�ɹ���ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE GetMarketDepth(MarketSegmentGrp* pMarketSegmentGrp, int& nMarketDepth)
{
    APP_ERROR_CODE nRet = APP_CODE_INCOM_PARAM_ERROR;

    MarketSegmentGrp::NoMarketSegments* pNoMarketSegments = pMarketSegmentGrp->GetNoMarketSegments();
    if (NULL != pNoMarketSegments)
    {
        SecurityTradingRules* pSecurityTradingRules = pNoMarketSegments->GetSecurityTradingRules();
        if (NULL != pSecurityTradingRules)
        {
            TradingSessionRulesGrp* pTradingSessionRuleGrp = pSecurityTradingRules->GetTradingSessionRulesGrp();
            if (NULL != pTradingSessionRuleGrp)
            {
                TradingSessionRulesGrp::NoTradingSessionRules* pNoTradingSessionRules = pTradingSessionRuleGrp->GetNoTradingSessionRules();
                if (NULL != pNoTradingSessionRules)
                {

                    TradingSessionRules* pTradingSessionRules = pNoTradingSessionRules->GetTradingSessionRules();
                    if (NULL != pTradingSessionRules)
                    {
                        MarketDataFeedTypes* pMarketDataFeedTypes = pTradingSessionRules->GetMarketDataFeedTypes();
                        if (NULL != pMarketDataFeedTypes)
                        {
                            MarketDataFeedTypes::NoMDFeedTypes* pNoMDFeedTypes = pMarketDataFeedTypes->GetNoMDFeedTypes();
                            if (NULL != pNoMDFeedTypes)
                            {
                                nMarketDepth = pNoMDFeedTypes->GetMarketDepth();
                                nRet = APP_CODE_SUCCESS;
                            }
                        }
                    }
                }

            }

        }
    }

    return nRet;
}

/************************************
*��������GetLastLimitAmt
*���ܣ� ��ȡ��Ч���Ŷ��
*������
    pMarketSegmentGrp:  [IN]IMIX��Ϣ����Ԫ��
    eLimitType:         [IN]�ֶι��ܱ�ʶ
    strLimitSubType��   [IN]�ֶι����ӱ�ʶ
*����ֵ:��Ϊʧ�ܣ�����Ϊ�ɹ�
*************************************/
PREFIX_FUNC
IRS_STRING GetLastLimitAmt(MarketSegmentGrp* pMarketSegmentGrp, LIMITAMT_TYPE eLimitType, IRS_STRING strLimitSubType)
{
    IRS_STRING strEffectAmount = "";

    MarketSegmentGrp::NoMarketSegments* pNoMarketSegments = pMarketSegmentGrp->GetNoMarketSegments();

    if (NULL != pNoMarketSegments)
    {
        LimitAmts* pLimitAmts = pNoMarketSegments->GetLimitAmts();
        if (NULL != pLimitAmts)
        {
            LimitAmts::NoLimitAmts* pNoLimitAmts = pLimitAmts->GetNoLimitAmts();
            if (NULL != pNoLimitAmts)
            {
                int nLimitAmtType = pNoLimitAmts->GetLimitAmtType();
                IRS_STRING strLimitAmtSubTp = pNoLimitAmts->GetLimitAmtSubType();
                if (eLimitType == nLimitAmtType &&
                    strLimitSubType == strLimitAmtSubTp)
                {
                    strEffectAmount = pNoLimitAmts->GetLastLimitAmt();
                }
            }
        }
    }

    return strEffectAmount;
}

/************************************
*��������GetBaseParameters
*���ܣ� ��IMIX��Ϣ�л�ȡ����������Ϣ
*������
    pMarketSegmentGrp:  [IN]IMIX��Ϣ����Ԫ��
    param:              [IN]���������ṹ��
*����ֵ:�ɹ�&ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE GetBaseParameters(MarketSegmentGrp* pMarketSegmentGrp, BASE_PARAM& param)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    MarketSegmentGrp::NoMarketSegments* pNoMarketSegments = pMarketSegmentGrp->GetNoMarketSegments();

    if (NULL != pNoMarketSegments)
    {
        IntToString(pNoMarketSegments->GetMaxNumListOrder(), param.m_sOcoMaxNum);
        RiskParties* pRiskParties = pNoMarketSegments->GetRiskParties();
        if (NULL != pRiskParties)
        {
            //IntToString(pRiskParties->GetTotNoRiskParties(), param.m_sCreditNum);
            param.m_sCreditNum = pRiskParties->GetTotNoRiskParties();
        }

        SecurityTradingRules* pSecurityTradingRules = pNoMarketSegments->GetSecurityTradingRules();
        if (NULL != pSecurityTradingRules)
        {
            BaseTradingRules* pBaseTradingRules = pSecurityTradingRules->GetBaseTradingRules();
            if (NULL != pBaseTradingRules)
            {
                param.m_sOcoMaxOrderNum = pBaseTradingRules->GetMaxTradeVol();
                param.m_sOcoMinOrderNum = pBaseTradingRules->GetMinTradeVol();
                param.m_sMaxPriceVariation = pBaseTradingRules->GetMaxPriceVariation();
                IntToString(pBaseTradingRules->GetPriceType(), param.m_sPriceType);
            }
            else
            {
                LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get BaseTradingRules error.");
                nRet = APP_CODE_INCOM_PARAM_ERROR;
            }
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get SecurityTradingRules error.");
            nRet = APP_CODE_INCOM_PARAM_ERROR;
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get NoMarketSegments error.");
        nRet = APP_CODE_INCOM_PARAM_ERROR;
    }

    return nRet;
}

/************************************
*��������Analyze_PartyRiskLimitsDefinitionRequest
*���ܣ� ����PartyRiskLimitsDefinitionRequest��Ϣ
*������
    pMarketSegmentGrp:  [IN]IMIX��Ϣ����Ԫ��
    param:              [IN]���������ṹ��
*����ֵ:�ɹ�&ʧ��
*************************************/
PREFIX_FUNC
APP_ERROR_CODE Analyze_PartyRiskLimitsDefinitionRequest(PartyRiskLimitsDefinitionRequest message, PARTY_RISK_LMT_DEF_REQ& oRet)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    oRet.m_sToken = message.GetApplToken();
    //��ȡά�����û�
    RequestingPartyGrp* pRequestingPartyGrp = message.GetRequestingPartyGrp();
    if (NULL != pRequestingPartyGrp)
    {
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < pRequestingPartyGrp->GetNoRequestingPartyIDs_Num() + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
        {
            RequestingPartyGrp::NoRequestingPartyIDs* pNoRequestingPartyIDs = pRequestingPartyGrp->GetNoRequestingPartyIDs(nIndex);
            if (pNoRequestingPartyIDs)
            {
                if (E_REQUESTING_PARTY_ROLE_USER == pNoRequestingPartyIDs->GetRequestingPartyRole())
                {
                    oRet.m_sUser = pNoRequestingPartyIDs->GetRequestingPartyID();
                }
            }
        }
    }

    PartyRiskLimitsUpdateGrp* pPartyRiskLimitsUpdateGrp = message.GetPartyRiskLimitsUpdateGrp();
    if (NULL != pPartyRiskLimitsUpdateGrp)
    {
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < pPartyRiskLimitsUpdateGrp->GetNoPartyRiskLimits_Num() + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
        {
            //��ȡ��������
            PartyRiskLimitsUpdateGrp::NoPartyRiskLimits* pNoPartyRiskLimits = pPartyRiskLimitsUpdateGrp->GetNoPartyRiskLimits(nIndex);
            if (NULL != pNoPartyRiskLimits)
            {
                PartyDetailGrp* pPartyDetailGrp = pNoPartyRiskLimits->GetPartyDetailGrp();
                if (NULL != pPartyDetailGrp)
                {
                        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < pPartyDetailGrp->GetNoPartyDetails_Num() + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
                        {
                            PartyDetailGrp::NoPartyDetails* pNoPartyDetails = pPartyDetailGrp->GetNoPartyDetails(nIndex);
                            if (NULL != pNoPartyDetails)
                            {
                                if ( E_PARTY_DETAIL_ROLE_ORG == pNoPartyDetails->GetPartyDetailRole())
                                {
                                    oRet.m_sModifyOrgId = pNoPartyDetails->GetPartyDetailID();
                                }
                                else if (E_PARTY_DETAIL_ROLE_MODIFY_ORG == pNoPartyDetails->GetPartyDetailRole())
                                {
                                    oRet.m_sOrgId = pNoPartyDetails->GetPartyDetailID();
                                }
                                else if (E_PARTY_DETAIL_ROLE_NORLT_ORG == pNoPartyDetails->GetPartyDetailRole())
                                {
                                    oRet.m_sNoRelaOrgId = pNoPartyDetails->GetPartyDetailID();
                                }
                            }
                        }
                }

                RiskLimitsGrp* pRiskLimitsGrp = pNoPartyRiskLimits->GetRiskLimitsGrp();
                if (NULL != pRiskLimitsGrp)
                {
                    for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < pRiskLimitsGrp->GetNoRiskLimits_Num() + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
                    {
                        RiskLimitsGrp::NoRiskLimits* pNoRiskLimits = pRiskLimitsGrp->GetNoRiskLimits(nIndex);
                        if (NULL != pNoRiskLimits)
                        {
                            RiskLimitTypesGrp* pRiskLimitTypesGrp = pNoRiskLimits->GetRiskLimitTypesGrp();
                            if (NULL != pRiskLimitTypesGrp)
                            {
                                for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < pRiskLimitTypesGrp->GetNoRiskLimitTypes_Num() + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
                                {
                                    RiskLimitTypesGrp::NoRiskLimitTypes* pNoRiskLimitTypes = pRiskLimitTypesGrp->GetNoRiskLimitTypes(nIndex);
                                    //���ŷ�ʽ
                                    oRet.m_nCrdtType = pNoRiskLimitTypes->GetRiskLimitType();
                                    if (E_RISK_LIMIT_TYPE_AMT == pNoRiskLimitTypes->GetRiskLimitType())
                                    {
                                        //��ȡ���Ŷ��
                                        oRet.m_sInitCrdtAmt = pNoRiskLimitTypes->GetRiskLimitAmount();
                                        oRet.m_sUsedCrdtAmt = pNoRiskLimitTypes->GetRiskLimitUtilizationAmount();
                                        oRet.m_sRemainCrdtAmt = pNoRiskLimitTypes->GetRiskLimitRemainingAmt();
                                    }
                                }
                            }
                            //��ȡ��Լ����
                            RiskInstrumentScopeGrp* pRiskInstrumentScopeGrp = pNoRiskLimits->GetRiskInstrumentScopeGrp();
                            if (NULL != pRiskInstrumentScopeGrp)
                            {
                                for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < pRiskInstrumentScopeGrp->GetNoRiskInstruments_Num() + IMIX_GRP_INDEX_BEGIN; ++ nIndex)
                                {
                                    RiskInstrumentScopeGrp::NoRiskInstruments* pNoRiskInstrumentScopes = pRiskInstrumentScopeGrp->GetNoRiskInstruments(nIndex);
                                    if (NULL != pNoRiskInstrumentScopes)
                                    {
                                        IntToString(pNoRiskInstrumentScopes->GetInstrumentScopeSecurityTerm(), oRet.m_sCrdtTerm);
                                        InstrumentScope* pInstrumentScope = pNoRiskInstrumentScopes->GetInstrumentScope();
                                        if (NULL != pInstrumentScope)
                                        {
                                            oRet.m_sContractId = pInstrumentScope->GetInstrumentScopeSecurityID();
                                        }
                                        //����ϵ��
                                        oRet.m_sRiskCof = pNoRiskInstrumentScopes->GetRiskInstrumentMultiplier();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    return nRet;
}

PREFIX_FUNC
bool IsCombContract(IRS_STRING strContractName)
{
    bool bRet = false;
    //���ڲ��Լ�б��в��ң�������ҵ��򷵻�true
    for (int nIndex = 0; nIndex < CONTRACT_COMB_NUM; ++nIndex)
    {
        if (strContractName == CONTRACT_COMB[nIndex])
        {
            bRet = true;
            break;
        }
    }

    return bRet;
}
//��׼������Լ
PREFIX_FUNC bool IsBasContract(IRS_STRING strContractName)
{
    //���ڲ��Լ�б��в��ң�������ҵ��򷵻�true
    return (strContractName == "S3M/R07_5Y"||strContractName == "S3M/R07_1Y")?true:false;
}
PREFIX_FUNC void DoubleToString2(double dValue, IRS_STRING& strValue)
{
    strValue = "0.0";
    char pcCode[64] = {0x00};
    sprintf(pcCode, "%.2f", dValue);
    strValue = pcCode;


    char cBuffer[64] = {0x00};
    sprintf(cBuffer, "%.10f", dValue);
    int i = 0;
    int n = 0;
    int m = 0;
    while (cBuffer[i] != '\0')
    {
        if (cBuffer[i] != '0')
        {
            n = i;
        }

        if (cBuffer[i] == '.')
        {
            m = i;
        }
        i++;
    }

    if ( (n-m) > 2)
    {
        LOG_WARNING("double precision is overflow!");
    }
}

PREFIX_FUNC void DoubleToString4(double dValue, IRS_STRING& strValue)
{
    strValue = "0.0";
    char pcCode[64] = {0x00};
    sprintf(pcCode, "%.4f", dValue);
    strValue = pcCode;


    char cBuffer[64] = {0x00};
    sprintf(cBuffer, "%.10f", dValue);
    int i = 0;
    int n = 0;
    int m = 0;
    while (cBuffer[i] != '\0')
    {
        if (cBuffer[i] != '0')
        {
            n = i;
        }

        if (cBuffer[i] == '.')
        {
            m = i;
        }
        i++;
    }

    if ( (n-m) > 4)
    {
        LOG_WARNING("double precision is overflow!");
    }
}

char *hexStringToByteArray(char* hex, size_t len, char *out, size_t *olen)
{
    char *b = out;
    int hb, lb;
    for (int i = 0; i < len; i+=2)
    {
        if (hex[i] >= '0' && hex[i] <= '9') {
            hb = hex[i] - '0';
        } else if (hex[i] >= 'a' && hex[i] <= 'f' ){
            hb = hex[i] - 'a' + 10;
        } else {
            hb = hex[i] - 'A' + 10;
        }

        if (hex[i + 1] >= '0' && hex[i + 1] <= '9') {
            lb = hex[i + 1] - '0';
        } else if (hex[i+ 1] >= 'a' && hex[i+ 1] <= 'f' ){
            lb = hex[i+ 1] - 'a' + 10;
        } else {
            lb = hex[i+ 1] - 'A' + 10;
        }

        *b++ = ( ((hb << 4)  | lb) & 0xff );
    }
    *olen = len / 2;

    return out;
}

char _hex_chs[] = {
        '0', '1', '2', '3',
        '4', '5', '6', '7',
        '8', '9', 'a', 'b',
        'c', 'd', 'e', 'f'
};

char *ArraytoHex(char* inArr, size_t len, char *out, size_t *olen)
{
    char *p = out;
    for (int i = 0; i < len; i++)
    {
        *p++ = _hex_chs[(inArr[i] >> 4) & 0xf];
        *p++ = _hex_chs[inArr[i] & 0xf];
    }
    *olen = len * 2;

    return out;
}

//��ȡϵͳʱ��
char *getfmttime(char* outTime)
{
    static char tstr[80];
    struct tm tmloc;
    time_t timet;

    //localtime_r(&tm,&tmloc);
    time(&timet);
    memcpy(&tmloc,localtime(&timet),sizeof(tmloc));

    strftime(outTime,79,"%Y%m%d-%H:%M:%S",&tmloc);

    return(outTime);
}

