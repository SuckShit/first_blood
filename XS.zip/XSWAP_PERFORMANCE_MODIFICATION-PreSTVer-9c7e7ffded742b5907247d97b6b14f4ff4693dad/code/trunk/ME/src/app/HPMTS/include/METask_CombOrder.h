/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#ifndef METASK_COMBORDER_H
#define METASK_COMBORDER_H

#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "internal_function_def.h"

// 订单提交
ResCodeT OnCombOrderSubmitStart(int32 msgType, IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnCombOrderCnclRplcStart(int msgType, IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);

#endif