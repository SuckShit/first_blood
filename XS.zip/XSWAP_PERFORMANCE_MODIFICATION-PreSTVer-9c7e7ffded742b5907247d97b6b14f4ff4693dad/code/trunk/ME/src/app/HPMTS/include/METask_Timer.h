/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
#ifndef _METASK_TIMER_H_
#define _METASK_TIMER_H_

#include "internal_function_def.h"

// 订单过期检查
ResCodeT OnPeriodValidateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnPeriodValidateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
// for build bridge order
ResCodeT OnBrdgOrdrStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnBrdgOrdrStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);

// 盘中参考价计算
ResCodeT OnRefPrcUpdateStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq);

ResCodeT OnRefPrcUpdateStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList, 
    int nExceptionFlag);
ResCodeT OnMktDatPushStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnMktDatPushStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnTimerCalRefPrcStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
    ResCodeT OnTimerCalRefPrcStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
#endif