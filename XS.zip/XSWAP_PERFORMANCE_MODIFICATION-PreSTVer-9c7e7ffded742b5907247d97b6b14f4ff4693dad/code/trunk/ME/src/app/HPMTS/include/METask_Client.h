/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef METASK_CLIENT_H
#define METASK_CLIENT_H

#include "internal_function_def.h"
#include "CwPb.pb.h"
#include "intrnl_msg.h"

//�ӿ������
ResCodeT OnBrdgInterfaceStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnBrdgInterfaceStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//�Ž���Ա����
ResCodeT OnBrdgDealerUpdateStart(IMIX20::DataSet& inMessage, IntrnlMsgT* pReq);
ResCodeT OnBrdgDealerUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//�������޸�
ResCodeT OnBrdgCrdtModifyStart(IMIX20::DataSet& inMessage, IntrnlMsgT* pReq);
ResCodeT OnBrdgCrdtModifyStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//�����Ÿ���(ԭ���Ÿ��º����Ž����ϲ�Ϊһ��)
ResCodeT OnBrdgCrdtUpdateStart(const cwpb::BrdgCrdtUpdate& inMessage, IntrnlMsgT* pReq, IMIX20::DataSet& orginMessage);
ResCodeT OnBrdgCrdtUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

// ����Mass��Ϣ
ResCodeT AnalyzeBrdgCreditUpdateMessage(IMIX20::DataSet& inMsg, vector<cwpb::BrdgCrdtUpdate>& vectSubMsg);

//API����Ȩ������
ResCodeT OnApiPrvlgUpdateStart(IMIX20::DataSet& inMessage, IntrnlMsgT* pReq);
ResCodeT OnApiPrvlgUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);


#endif
