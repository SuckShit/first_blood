/***
Created on July 20, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "cfg_lib.h"
#include "prdct_info.h"
#include "order_submit.h"

#include "order_type.h"
#include "match_lib.h"
#include "order.h"
#include "order_book.h"
#include "user_order.h"
#include "contract_info.h"
#include "order_check.h"
#include "pck_irs_util.h"
#include "usr.h"
#include "org_info.h"
#include "pck_irs_dicdata.h"
#include "trade_mgmt.h"
#include "deal.h"
#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "internal_base_def.h"
#include "../../common/msg_def/msg_credit_position_sbfccp.h" 
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : OrderSubmitMessage
 **
 ******************************************************************************/
ResCodeT OrderSubmitMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OrderSubmitMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderSingleReqT pNewOrderReq = (pNewOrderSingleReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;


    pPrdctInfoT             pPrdctInfo = NULL;
    pOrderT                 pOrderReq = NULL;
    MtchInfoT               mtchInfo;

    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pNewOrderReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    if (pReq->msgHdr.msgType != MSG_TYPE_API_ORD_SUBMIT
                && pReq->msgHdr.msgType != MSG_TYPE_SIRS_API_ORD_SUBMIT
                && pReq->msgHdr.msgType != MSG_TYPE_SBFCCP_API_ORD_SUBMIT
                )
    {
        rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_ORDSUBMIT_FUNCID, pNewOrderReq->token, &orgId);
        RAISE_ERR( rc, RTN );
    }

    InitRspDat(pOrderRsp );

    rc = PrdctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pPrdctInfo);
    RAISE_ERR( rc, RTN );

    if (pReq->msgHdr.msgType != MSG_TYPE_API_ORD_SUBMIT
                && pReq->msgHdr.msgType != MSG_TYPE_SIRS_API_ORD_SUBMIT
                && pReq->msgHdr.msgType != MSG_TYPE_SBFCCP_API_ORD_SUBMIT
                )
    {
        rc = OrderSubmitCheck( pNewOrderReq ,timestamp);
        RAISE_ERR( rc, RTN );
    }

    rc = MtchrCreateOrdrFromOrdrInfo(pReq->msgHdr.setId, &pNewOrderReq->newOrdrInfo, &pOrderReq, FALSE, NULL);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsOrdrAdd(FALSE, TRUE, pReq->msgHdr.setId,pPrdctInfo, pOrderReq, timestamp, pOrderRsp, &mtchInfo);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT FmtCnclRplcRqstToOrder(pOrderCancelReplaceRequestReqT pCnclRplcOrderReq, pOrderT pOrder)
{
    BEGIN_FUNCTION( "FmtCnclRqstToOrder" );
    ResCodeT rc = NO_ERR;

    pOrder->orderF.ordrNo = pCnclRplcOrderReq->ordId;


    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OrderSaveMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OrderSaveMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderSingleReqT pNewOrderReq = (pNewOrderSingleReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;


    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    pOrderT                 pOrderReq = NULL;
    MtchInfoT               mtchInfo;
    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pNewOrderReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_ORDSAVING_FUNCID, pNewOrderReq->token, &orgId);
    RAISE_ERR( rc, RTN );

    InitRspDat(pOrderRsp );

    rc = PrdctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pPrdctInfo);
    RAISE_ERR( rc, RTN );

    rc = OrderSaveCheck( pNewOrderReq ,timestamp);
    RAISE_ERR( rc, RTN );

    rc = IrsCntrctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pIrsCntrctInfo);
    RAISE_ERR( rc, RTN );

    rc = MtchrCreateOrdrFromOrdrInfo(pIrsCntrctInfo->setId, &pNewOrderReq->newOrdrInfo, &pOrderReq, FALSE, NULL);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsOrdrSave(FALSE, pIrsCntrctInfo->setId, pPrdctInfo, pOrderReq, timestamp, pOrderRsp);
    RAISE_ERR( rc, RTN );
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT BilOrderSubmitMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "BilOrderSubmitMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderSingleReqT pNewOrderReq = (pNewOrderSingleReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;


    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    pOrderT                 pBidOrder = NULL, pAskOrder = NULL;
    MtchInfoT               mtchInfo;

    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pNewOrderReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_BILORDSUBMIT_FUNCID, pNewOrderReq->token, &orgId);
    RAISE_ERR( rc, RTN );

    rc = BilOrderSubmitCheck( pNewOrderReq ,timestamp );
    RAISE_ERR( rc, RTN );

    InitRspDat(pOrderRsp );

    rc = PrdctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pPrdctInfo);
    RAISE_ERR( rc, RTN );

    rc = IrsCntrctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pIrsCntrctInfo);
    RAISE_ERR( rc, RTN );
    /*for bid side */
    rc = MtchrCreateOrdrFromOrdrInfo(pIrsCntrctInfo->setId, &pNewOrderReq->newOrdrInfo, &pBidOrder, TRUE, NULL);
    RAISE_ERR( rc, RTN );
    /*for ask side */
    rc = MtchrCreateOrdrFromOrdrInfo(pIrsCntrctInfo->setId, &pNewOrderReq->newOrdrInfo, &pAskOrder, TRUE, &pNewOrderReq->askPrcQtyInfo);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsBilOrdrAdd(FALSE, pIrsCntrctInfo->setId,pPrdctInfo, pAskOrder, pBidOrder, timestamp, pOrderRsp, &mtchInfo);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT BilOrderSaveMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "BilOrderSaveMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderSingleReqT pNewOrderReq = (pNewOrderSingleReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;


    pPrdctInfoT             pPrdctInfo = NULL;
    pCntrctBaseInfoT        pIrsCntrctInfo = NULL;
    pOrderT                 pOrderReq = NULL;
    MtchInfoT               mtchInfo;
    pOrderT                 pBidOrder = NULL, pAskOrder = NULL;

    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pNewOrderReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_BILORDSAVING_FUNCID, pNewOrderReq->token, &orgId);
    RAISE_ERR( rc, RTN );

    rc = BilOrderSaveCheck( pNewOrderReq ,timestamp);
    RAISE_ERR( rc, RTN );

    InitRspDat(pOrderRsp );

    rc = PrdctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pPrdctInfo);
    RAISE_ERR( rc, RTN );

    rc = IrsCntrctInfoGetByPosExt(pNewOrderReq->newOrdrInfo.contractPos, &pIrsCntrctInfo);
    RAISE_ERR( rc, RTN );

    /*for bid side */
    rc = MtchrCreateOrdrFromOrdrInfo(pIrsCntrctInfo->setId, &pNewOrderReq->newOrdrInfo, &pBidOrder, TRUE, NULL);
    RAISE_ERR( rc, RTN );
    /*for ask side */
    rc = MtchrCreateOrdrFromOrdrInfo(pIrsCntrctInfo->setId, &pNewOrderReq->newOrdrInfo, &pAskOrder, TRUE, &pNewOrderReq->askPrcQtyInfo);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsBilOrdrSave(FALSE, pIrsCntrctInfo->setId, pPrdctInfo, pAskOrder, pBidOrder, timestamp, pOrderRsp);
    RAISE_ERR( rc, RTN );
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** Detail Service Callback : OrderSubmitMessage
 **
 ******************************************************************************/
ResCodeT OrderExpireChkMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OrderExpireChkMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;

    InitRspDat(pOrderRsp );

    rc = MtchrPrcsOrdrExpireChk(1, timestamp, pOrderRsp);  //todo fix this
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT OcoOrderSubmitMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OcoOrderSubmitMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderListReqT pNewOrderListReq = (pNewOrderListReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;


    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pNewOrderListReq->frstInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_OCOORDSUBMIT_FUNCID, pNewOrderListReq->frstInfo.token, &orgId);
    RAISE_ERR( rc, RTN );

    rc = OCOOrderSubmitCheck( pNewOrderListReq, timestamp );
    RAISE_ERR( rc, RTN );

    InitRspDat(pOrderRsp );
   
    rc = MtchrPrcsOcoOrdrAdd(TRUE, pReq->msgHdr.setId,&pNewOrderListReq->frstInfo, 
                            pNewOrderListReq->secInfoCnt, pNewOrderListReq->secInfo,
                            pNewOrderListReq->secAskInfoCnt, pNewOrderListReq->secAskInfo,
                            timestamp, pOrderRsp);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT OcoOrderSaveMessage(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "OcoOrderSaveMessage" );
    ResCodeT rc = NO_ERR;
    pNewOrderListReqT pNewOrderListReq = (pNewOrderListReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;


    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pNewOrderListReq->frstInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_OCOORDSAVING_FUNCID, pNewOrderListReq->frstInfo.token, &orgId);
    RAISE_ERR( rc, RTN );

    rc = OCOOrderSaveCheck( pNewOrderListReq, timestamp );
    RAISE_ERR( rc, RTN );

    InitRspDat(pOrderRsp );

    rc = MtchrPrcsOcoOrdrSave(FALSE, pReq->msgHdr.setId,&pNewOrderListReq->frstInfo,
                            pNewOrderListReq->secInfoCnt, pNewOrderListReq->secInfo,
                            pNewOrderListReq->secAskInfoCnt, pNewOrderListReq->secAskInfo,
                            timestamp, pOrderRsp);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrcsBrdgOrdrTrgr(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsBrdgOrdrTrgr" );
    ResCodeT rc = NO_ERR;
    LOG_DEBUG("PrcsBrdgOrdrTrgr Start");
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;

    InitRspDat(pOrderRsp );

    rc = MtchrPrcsOrdrBrdg(1, timestamp,pOrderRsp);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrcsMktDatPush(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsMktDatPush" );
    ResCodeT rc = NO_ERR;
    LOG_DEBUG("PrcsMktDatPush Start");

    rc = MtchMktDatPush(TRUE, 1);
    RAISE_ERR( rc, RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrcsOrderCnclMsg(int32 msgType,
                pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsOrderCnclMsg" );
    ResCodeT rc = NO_ERR;
    pOrderCancelRequestReqT pCnclOrderReq = (pOrderCancelRequestReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;

    OrderT                  orderReq = {0};

    pUsrBaseInfoT           pUsr;
    int32                   orgId;
    pOrgInfoT               pOrgInfo = NULL;

    rc = IrsUsrInfoGetByPosExt(pCnclOrderReq->userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    FmtCnclRqstToOrder(pCnclOrderReq, &orderReq);

    InitRspDat(pOrderRsp );

    switch (msgType)
    {
        case MSG_TYPE_OCOORDER_CANCEL_MESSAGE:
            rc = OCOOrderCancelCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_OCOORDCANCEL_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOcoOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_BILORDER_CANCEL_MESSAGE:
            rc = BilOrderCancelCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_BILORDCANCEL_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsBilOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_ORDER_CANCEL_MESSAGE:
            rc = OrderCancelCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_ORDCANCEL_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;
        
        case MSG_TYPE_ORDER_CANCEL_BY_ADMIN:
            rc = OrderCancelCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_ORDCANCEL_FUNCID, pCnclOrderReq->token, &orgId);//checked
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_SBFCCP_ORDER_CANCEL_CW:
            rc = OrderCancelCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = OrgInfoGetByPosExt(pCnclOrderReq->orgIdx, &pOrgInfo);
            RAISE_ERR( rc, RTN );
    
            if (pReq->msgHdr.setId == SET_MKT_SBFCCP)
            {
                rc = SbfCcpCommonChk(pUsr->usrLgnNm, pOrgInfo->orgId, C_ORDCANCEL_FUNCID, pCnclOrderReq->token, &orgId);
                RAISE_ERR( rc, RTN );
            }

            rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        default:
            LOG_DEBUG("Invalid msg type in order cancel %d", pReq->msgHdr.msgType);
            break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrcsOrderFrzMsg(int32 msgType,pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsOrderFrzMsg" );
    ResCodeT rc = NO_ERR;
    pOrderCancelReplaceRequestReqT pCnclOrderReq = (pOrderCancelReplaceRequestReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;

    OrderT                 orderReq = {0};

    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pCnclOrderReq->userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    FmtCnclRplcRqstToOrder(pCnclOrderReq, &orderReq);

    InitRspDat(pOrderRsp );

    switch (msgType)
    {
        case MSG_TYPE_OCOORDER_FREEZE_MESSAGE:
            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_OCOORDFREEZE_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = OCOOrderFreezeCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOcoOrdrCancel(pReq->msgHdr.setId, ORDR_STS_FREEZE, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_BILORDER_FREEZE_MESSAGE:
            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_BILORDFREEZE_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = BilOrderFreezeCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsBilOrdrCancel(pReq->msgHdr.setId, ORDR_STS_FREEZE, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_ORDER_FREEZE_MESSAGE:
            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_ORDFREEZE_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = OrderFreezeCheck( pReq->msgHdr.setId, pCnclOrderReq );
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_FREEZE, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;
        default:
            LOG_DEBUG("Invalid msg type in order freeze %d", pReq->msgHdr.msgType);
            break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrcsOrderActvtMsg(int32 msgType, pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsOrderActvtMsg" );
    ResCodeT rc = NO_ERR;
    pOrderCancelReplaceRequestReqT pCnclOrderReq = (pOrderCancelReplaceRequestReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;

    OrderT                 orderReq = {0};


    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pCnclOrderReq->userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    FmtCnclRplcRqstToOrder(pCnclOrderReq, &orderReq);

    InitRspDat(pOrderRsp );

    switch (msgType)
    {
        case MSG_TYPE_OCOORDER_ACTIVATE_MESSAGE:
            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_OCOORDACTIVATE_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = OCOOrderActiveCheck( pReq->msgHdr.setId, pCnclOrderReq, timestamp );
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOcoOrdrActive(pReq->msgHdr.setId, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_BILORDER_ACTIVATE_MESSAGE:
            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_BILORDACTIVATE_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = BilOrderActiveCheck( pReq->msgHdr.setId, pCnclOrderReq, timestamp );
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsBilOrdrActive(pReq->msgHdr.setId, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_ORDER_ACTIVATE_MESSAGE:
            rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_ORDACTIVATE_FUNCID, pCnclOrderReq->token, &orgId);
            RAISE_ERR( rc, RTN );

            rc = OrderActiveCheck( pReq->msgHdr.setId, pCnclOrderReq, timestamp );
            RAISE_ERR( rc, RTN );

            rc = MtchrPrcsOrdrActive(pReq->msgHdr.setId, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;
        default:
            LOG_DEBUG("Invalid msg type in order activate %d", pReq->msgHdr.msgType);
            break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrcsOrderWthdrMsg(int32 msgType,
                pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsOrderWthdrMsg" );
    ResCodeT rc = NO_ERR;
    pOrderCancelRequestReqT pCnclOrderReq = (pOrderCancelRequestReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;

    OrderT                 orderReq = {0};

    pUsrBaseInfoT           pUsr;
    int32                   orgId;

    rc = IrsUsrInfoGetByPosExt(pCnclOrderReq->userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    FmtCnclRqstToOrder(pCnclOrderReq, &orderReq);

    InitRspDat(pOrderRsp );

    switch (msgType)
    {
        case MSG_TYPE_ORDER_WITHDRAW_MESSAGE:
            rc = MtchrPrcsOrdrWthdr(pReq->msgHdr.setId, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_BILORDER_WITHDRAW_MESSAGE:
            rc = MtchrPrcsBilOrdrWthdr(pReq->msgHdr.setId, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        case MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE:
            rc = MtchrPrcsOcoOrdrWthdr(pReq->msgHdr.setId, &orderReq, timestamp, pOrderRsp);
            RAISE_ERR( rc, RTN );
            break;

        default:
            LOG_DEBUG("Invalid msg type in order withdraw %d", pReq->msgHdr.msgType);
            break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrcsDealCnclReq(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsDealCnclReq" );
    ResCodeT rc = NO_ERR;

    pTradeDatT      pTradeDat = NULL;
    TradeKeyT       tradeKey = {0};
    uint32           tradePos = -1;
    uint32           ordrPos = -1;
    pOrderT         pOrder = NULL;
    pOrdrMgmtRcrdT  pOrdrMgmt = NULL;
    DealCnclT       dealCncl;

    pDealCancelRequestReqT pCnclDealReq = (pDealCancelRequestReqT)pReq->msgBody;
    pNewOrderSingleRspT pOrderRsp = (pNewOrderSingleRspT)pRsp->msgBody;
    
    pUsrBaseInfoT       pUsr;
    int32               orgId;

    rc = IrsUsrInfoGetByPosExt(pCnclDealReq->officerIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    InitRspDat(pOrderRsp );

    tradeKey.trdNo = pCnclDealReq->dealId;
    
    rc = CommonChk(pUsr->usrLgnNm, C_ORG_NULL, C_TRADECANCEL_FUNCID, pCnclDealReq->token, &orgId);
    RAISE_ERR( rc, RTN );


    rc = TradeChk(pReq->msgHdr.setId, &tradeKey, &pTradeDat, &tradePos);
    if (rc = ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        dealCncl.dealNo = tradeKey.trdNo;
        dealCncl.dealSt = DEAL_STS_CANCEL;
        dealCncl.updTime = timestamp;
        dealCncl.setId = pReq->msgHdr.setId;
        
        rc = RefDatUpdtCmmn(REF_TYP_UPDT_DEAL_CNCL, &dealCncl, sizeof(DealCnclT));
        RAISE_ERR( rc, RTN );
        
        rc = FmtDealCnclCnfrm( pReq->msgHdr.setId, pTradeDat, pOrderRsp);
        if (rc != NO_ERR)
        {
            RAISE_ERR(ERR_CODE_INVLD_CANCEL_F, RTN);
        }
    }
    else
    {
        RAISE_ERR(ERR_CODE_INVLD_TRD_NT_EXST, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
