/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef METASK_BILORDER_H
#define METASK_BILORDER_H

#include "internal_function_def.h"
#include "intrnl_msg.h"

// 订单提交
ResCodeT OnBilOrderSubmitStart(int32 msgType, NewOrderSingle& message,IntrnlMsgT* pReq); 
//// 订单修改后提交
ResCodeT OnBilOrderModifySubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox= E_OCO_CHECKBOX_TRUE); 
//// 订单修改后保存
ResCodeT OnBilOrderModifySaveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox= E_OCO_CHECKBOX_TRUE);

ResCodeT OnBilOrderSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);    
ResCodeT OnBilOrderModifySubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnBilOrderModifySaveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnBilOrderCnclRplcReqStart(int msgType, OrderCancelReplaceRequest& message, IntrnlMsgT* pReq);
ResCodeT OnBilOrderCnclRplcReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);

ResCodeT OnBilOrderCnclReqStart(int msgType,  OrderCancelRequest& message, IntrnlMsgT* pReq);
ResCodeT OnBilOrderCnclReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
#endif