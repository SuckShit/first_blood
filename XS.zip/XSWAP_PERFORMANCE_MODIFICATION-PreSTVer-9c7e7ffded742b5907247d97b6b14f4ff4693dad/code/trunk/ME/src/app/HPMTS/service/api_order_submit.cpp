/***
Created on Sep 15, 2017
@author: Jiawang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <regex.h>
#include <math.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"
#include "internal_base_def.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "usr_def_ref.h"
#include "contract_info.h"
#include "order_submit.h"
#include "order_check.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : ApiOrderSubmit
 **
 ******************************************************************************/
ResCodeT ApiOrderSubmit(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "ApiOrderSubmit" );
    ResCodeT rc = NO_ERR;

    NewOrderSingleReqT*     pApiReq;
    NewOrderSingleRspT*    pApiResp;

    pApiReq = (NewOrderSingleReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;
    pCntrctBaseInfoT pCntract;

    rc = IrsUsrInfoGetByPosExt(pApiReq->newOrdrInfo.apiLoginUsrIdx, &pApiUsr);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByPosExt(pApiReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByPosExt(pApiReq->newOrdrInfo.orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    rc = IrsCntrctInfoGetByPosExt(pApiReq->newOrdrInfo.contractPos, &pCntract);
    RAISE_ERR(rc, RTN);


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pApiUsr->usrLgnNm,
                        pOrgInfo->orgCd,
                        FUNC_ID_API_ORD_SUBMIT,
                        pApiReq->token,
                        1,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // SP_USRCHECK
    rc = UserCheck(pApiUsr->usrLgnNm, pOrgInfo->orgCd, pUsr->usrLgnNm, pUsr->nmDesc, pOrgInfo->orgCd, C_MKT_TP_IRS);
    RAISE_ERR(rc, RTN);


    rc = ApiSubmitOrderCheck(pApiReq, pCntract, timestamp);
    RAISE_ERR(rc, RTN);


    rc = OrderSubmitMessage(pReq, pRsp, timestamp, pCtx);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : SirsApiOrderSubmit
 **
 ******************************************************************************/
ResCodeT SirsApiOrderSubmit(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "SirsApiOrderSubmit" );
    ResCodeT rc = NO_ERR;

    NewOrderSingleReqT*     pApiReq;
    NewOrderSingleRspT*    pApiResp;

    pApiReq = (NewOrderSingleReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;
    pCntrctBaseInfoT pCntract;

    rc = IrsUsrInfoGetByPosExt(pApiReq->newOrdrInfo.apiLoginUsrIdx, &pApiUsr);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByPosExt(pApiReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByPosExt(pApiReq->newOrdrInfo.orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    rc = IrsCntrctInfoGetByPosExt(pApiReq->newOrdrInfo.contractPos, &pCntract);
    RAISE_ERR(rc, RTN);


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pApiUsr->usrLgnNm,
                        pOrgInfo->orgCd,
                        FUNC_ID_SIRSAPI_ORD_SUBMIT,
                        pApiReq->token,
                        2,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // SP_USRCHECK
    rc = UserCheck(pApiUsr->usrLgnNm, pOrgInfo->orgCd, pUsr->usrLgnNm, pUsr->nmDesc, pOrgInfo->orgCd, C_MKT_TP_SIRS);
    RAISE_ERR(rc, RTN);


    rc = SirsApiSubmitOrderCheck(pApiReq, pCntract, timestamp);
    RAISE_ERR(rc, RTN);


    rc = OrderSubmitMessage(pReq, pRsp, timestamp, pCtx);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : SbfccpApiOrderSubmit
 **
 ******************************************************************************/
ResCodeT SbfccpApiOrderSubmit(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "SbfccpApiOrderSubmit" );
    ResCodeT rc = NO_ERR;

    NewOrderSingleReqT*     pApiReq;
    NewOrderSingleRspT*    pApiResp;

    pApiReq = (NewOrderSingleReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;
    pCntrctBaseInfoT pCntract;

    rc = IrsUsrInfoGetByPosExt(pApiReq->newOrdrInfo.apiLoginUsrIdx, &pApiUsr);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByPosExt(pApiReq->newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByPosExt(pApiReq->newOrdrInfo.orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    rc = IrsCntrctInfoGetByPosExt(pApiReq->newOrdrInfo.contractPos, &pCntract);
    RAISE_ERR(rc, RTN);


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pApiUsr->usrLgnNm,
                        pOrgInfo->orgCd,
                        FUNC_ID_SBFCCPAPI_ORD_SUBMIT,
                        pApiReq->token,
                        5,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // SP_USRCHECK
    rc = UserCheck(pApiUsr->usrLgnNm, pOrgInfo->orgCd, pUsr->usrLgnNm, pUsr->nmDesc, pOrgInfo->orgCd, C_MKT_TP_SBFCCP);
    RAISE_ERR(rc, RTN);


    rc = SbfccpApiSubmitOrderCheck(pApiReq, pCntract, timestamp);
    RAISE_ERR(rc, RTN);


    rc = OrderSubmitMessage(pReq, pRsp, timestamp, pCtx);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
