/***
Created on June 08, 2017
@author: Ming.Kong
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#pragma once

/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/
#include "DEP/IDEPListener.h"

#include "IMIX20/Comm/MsgDefine.h"
#include "IMIX/BasicProtocol/MagicData.h"
#include "IMIXT10/Comm/MessageType.h"
#include "IMIXT10/Comm/MsgDefine.h"
#include "DEP/Application.h"
#include "DEP/Service.h"
#include "DEP/DEPAPIErrorDef.h"
#include "ISPTask.h"
#include "Utils.h"
#include "UTILITY/Mutex.h"
#include "ServerTimer.h"
#include "err_cod.h"
#include "data_type.h"
#include "METask.h"
#include "UTILITY/logfile.h"
#include "UTILITY/PubFunc.h"

typedef list<const DEP::Service *> ServiceList;
class ServerTimer;
class MatchingListener : public DEP::IDEPListener
{
public:
    MatchingListener(const string& FilePath);
    ~MatchingListener(void);
    
    ResCodeT CreateShm(const string& FilePath);
    ResCodeT DetachShm();

    virtual ResCodeT ToApp(const IMIX::BasicMessage&, const DEP::Service& );
    virtual ResCodeT ToAdmin(const IMIX::BasicMessage&, const DEP::Service& ) ;
    virtual ResCodeT FromApp(const IMIX::BasicMessage&, const DEP::Service& );
    virtual ResCodeT FromAdmin(const IMIX::BasicMessage&,const DEP::Service& ) ;

    virtual ResCodeT OnLogout( const DEP::Service&, int type ) ;
    virtual ResCodeT OnLogon( const DEP::Service& ) ;
    virtual ResCodeT OnAccepted( const DEP::Service& ) ;


    ResCodeT SendLogonMessage(DEP::Service &service,IMIX::BasicMessage& message);


    ResCodeT SendLogoutMessage(DEP::Service &service,IMIX::BasicMessage& message);

    ResCodeT RegisterMatchingTimer(DEP::Application * InpApplication);

    ResCodeT OnImixMEMsg(const IMIX::BasicMessage&);

    
private:
    ServiceList::iterator m_ServiceIter;
    DEP::ServiceID m_ServiceID;
    DEP::Application * m_Application;
    string  m_FastProtocol;
    //timer list
    TimerList * m_pTimerList;

    //timer
    ServerTimer* m_pServerTimer;
public:
    ServiceList m_ServiceList;
    // 互斥锁
    CMUTEX  m_ClientMutex;

    //matching engine
    METask* m_pMEtask;

    //msg handle
    int32 m_wr_msgHdl;
    int32 m_rd_msgHdl;
    int32 m_event_msgHdl;
};
