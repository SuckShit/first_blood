/***
Created on JUN 06, 2017
@author: Dongwei.Li
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File */
#include "METask_Clear_Account.h"
#include "METask_Comm.h"
#include "irs_code_convert.h"
#include "internal_base_def.h"
#include "msg_market_info_update.h"
#include "usr.h"
#include "msg_type.h"
#include "usr_role_update.h"
#include "intrnl_msg.h"
#include "usr_role_update.h"
#include "msg_credit.h"
#include "user_order.h"
#include "METask_Api.h"
#include "org_info.h"
#include "../../common/msg_def/msg_credit_position_sbfccp.h" 
#include "uti_tool.h"
#include "order_book.h"

using namespace IMIX;
using namespace IMIX20;
using namespace shch;

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT OnClearingAccountStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnClearingAccountStart ");
    ResCodeT                rc = NO_ERR;
    bool                    bRet = FALSE;
    int                     nMarketType;
    int                     nQuryType;
    IMIX20::QueryResult     message;
    std::string             strMarketType;
    std::string             strQueryType;

    bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    strMarketType       = message.GetApplID();
    nMarketType         = atoi(strMarketType.c_str());
    strQueryType        = message.GetQueryType();
    nQuryType           = atoi(strQueryType.c_str());

    switch (nQuryType)
    {
        case shch::MSG_TYPE_PARTY_RISK_LIMITS_UPDATE:
             rc = OnCCPCreditUpdateStart(inMessage, pReq);
            break;

        case shch::MSG_TYPE_CLOSE_POSITION:
            {
                if (shch::MKT_SIRS == nMarketType)
                {
 //                    rc = OnSIRSCCPClosePositionStart(inMessage, pReq);
                }
                else if (shch::MKT_SBF == nMarketType)
                {
                    pReq->msgHdr.setId  = SET_MKT_SBFCCP;
                    rc = OnSBFCCPClosePositionStart(inMessage, pReq);
                }
                else
                {
                    RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
                }
            }
            break;

        case shch::MSG_TYPE_CLOSE_UNDO_POSITION:
            {
                if (shch::MKT_SIRS == nMarketType)
                {
//                    rc = OnSIRSCCPClosePositionCancelStart(inMessage, pParamList);
                }
                else if (shch::MKT_SBF == nMarketType)
                {
                    pReq->msgHdr.setId  = SET_MKT_SBFCCP;
                    rc = OnSBFCCPClosePositionCancelStart(inMessage, pReq);
                }
                else
                {
                    RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
                }
            }
            break;

        default:
            rc = OnAPIInterfaceStart(inMessage, pReq);
            break;
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//�û��г�Ȩ������
ResCodeT OnUsrMktRoleUpdateStart(
        const IMIX::BasicMessage& inMessage,
        IntrnlMsgT* pReq
        )
{
    BEGIN_FUNCTION("OnUsrMktRoleUpdateStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnUsrMktRoleUpdateStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    SecurityListReqT* pSetting;
    UsrBaseInfoT usr;

    //��ȡ��
    std::string strUsrId;    //��ǰID
    std::string strToken;
    std::string strOpUsrId;    //�������û�ID
    SecListGrp* pSecGrp;
    int nGrpSize;
    SecListGrp::NoRelatedSym* pNoRelateSym;
    std::string strMktTp;
    std::string strMktIrsRole;        //�г�
    std::string strMktSirsRole;       //Ȩ��
    std::string strMktSirsccpRole;    //�г�
    std::string strMktSbfRole;        //Ȩ��
    std::string strMktSbfccpRole;     //�г�

//    std::string strFuncId;
//    IntToString(SP_FUNCID(SP_ID_USER_MARKET_ROLE_UPDATE), strFuncId);

    // ��Ϣ����,����167SecurityType�ж��г�
    SecurityList message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    strUsrId = message.GetSecurityResponseID();
    strToken = message.GetApplToken();
    strOpUsrId = message.GetSecurityReqID();
    pSecGrp = message.GetSecListGrp();
    nGrpSize = pSecGrp->GetNoRelatedSym_Num();

    for (int i = 1; i <= nGrpSize; ++i) {
        pNoRelateSym = pSecGrp->GetNoRelatedSym(i);
        strMktTp = pNoRelateSym->GetCurrency();
        if (MKT_TYPE_IRS == strMktTp) {
            strMktIrsRole = pNoRelateSym->GetEncodedText();
        }
        else if (MKT_TYPE_SIRS == strMktTp) {
            strMktSirsRole = pNoRelateSym->GetEncodedText();
        }
        else if (MKT_TYPE_SBF == strMktTp) {
            strMktSbfRole = pNoRelateSym->GetEncodedText();
        }
        else if (MKT_TYPE_SIRSCCP == strMktTp) {
            strMktSirsccpRole = pNoRelateSym->GetEncodedText();
        }
        else if (MKT_TYPE_SBFCCP == strMktTp) {
            strMktSbfccpRole = pNoRelateSym->GetEncodedText();
        }
        else {
            LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
            return APP_CODE_INCOM_MSG_INVALID;
        }
        LOG_INFO("lidw 20171016 strMktTp=%s, strMktRole=%s", strMktTp.c_str(), pNoRelateSym->GetEncodedText().c_str());
    }

    // ������Ϣ��ӡ��־��ӡ
    LOG_INFO("In condition: strUsrId = %s, strToken = %s, strOpUsrId = %s, \
             strMktIrsRole = %s, strMktSirsRole = %s, strMktSbfRole = %s, strMktSirsccpRole = %s, strMktSbfccpRole = %s",
             strUsrId.c_str(), strToken.c_str(), strOpUsrId.c_str(), strMktIrsRole.c_str(), strMktSirsRole.c_str(),
             strMktSbfRole.c_str(), strMktSirsccpRole.c_str(), strMktSbfccpRole.c_str());

    //�������б�
    pSetting = (SecurityListReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen  = sizeof(SecurityListReqT);
    pReq->msgHdr.msgType = MSG_TYPE_USR_MARKET_ROLE_UPDATE;

    // SP���
    pSetting->iFuncId = FUNC_ID_USER_MARKET_ROLE_UPDATE;         //���ܱ�ʶ
    strcpy(pSetting->strUserId, strUsrId.c_str());               //�û���ʶ
    strcpy(pSetting->strToken,  strToken.c_str());               //Token
    strcpy(pSetting->strOpUsrId, strOpUsrId.c_str());            //�������û�ID

    pSetting->iMktIrsRole = StringToInt(strMktIrsRole);          //Irs�г�Ȩ��
    pSetting->iMktSirsRole = StringToInt(strMktSirsRole);        //Sirs�г�Ȩ��
    pSetting->iMktSbfRole = StringToInt(strMktSbfRole);          //Sbf�г�Ȩ��
    pSetting->iMktSirsccpRole = StringToInt(strMktSirsccpRole);  //Sirsccp�г�Ȩ��
    pSetting->iMktSbfccpRole = StringToInt(strMktSbfccpRole);    //Sbfccp�г�Ȩ��

    //check
//    CCP_SpUsrMktRoleCheck(strFuncId, strUsrId, strToken, pParamList);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("%s End..", sFunction.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnUsrMktRoleUpdateStop(
        IntrnlMsgT* pRsp,
        SENDMSGLIST* pSendMsgList,
        int nExceptionFlag
        )
{
    BEGIN_FUNCTION("OnUsrMktRoleUpdateStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnUsrMktRoleUpdateStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    SecurityListRspT *pSettingRst;
    /*---------------------------------------
    **********    ��ʱ���� ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 applRefSeqNum = 0;

    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/
    // ����Ӧ����Ϣ
    ExecutionReport* pRspMessage = new ExecutionReport;
    if (NULL == pRspMessage) {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    pRspMessage->SetApplToken("----");

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    //���ִ��SP����ʧ��
    if (NO_ERR != nExceptionFlag) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    else {
        pSettingRst = (SecurityListRspT*)pRsp->msgBody;
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pSettingRst->rspOrderCancel.rspSlot,
                                                    pSettingRst->rspOrderCancel.slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
        // ������������Ϣ
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pSettingRst->rspOrder, pSettingRst->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN); //todo
    }

/*
    // ������������Ϣ
    if (SP_RET_SUCCESS == oRetParam.m_nErrorCode) {
        int nOutBoundId = oRetCheckParam.m_nOutBoundId;

        SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOrders, pSendMsgList);
        SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);

        SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);

        SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSBFOrders, pSendMsgList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFOrders, nOutBoundId, pSendMsgList, pParamList);

        CCP_SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSIRSCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSIRSCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        CCP_SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
    }
*/

    LOG_DEBUG("%s End..", sFunction.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//SBF�޶����
ResCodeT OnCCPCreditUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnCCPCreditUpdateStart");
    ResCodeT                rc = NO_ERR;
    bool                    bRet = FALSE;
    pCCPCreditUptReqT       pCCPCredit = NULL;
    int                     nMarketType = 0;

    IMIX20::QueryResult     message;
    MassMessageGrp*         pMassMessageGrp;
    MarketInfoUpdateReqT*   pMrktInfoUpdReq;

    std::string             strMsgId = "";         /* ȫ��ָ���� */
    std::string             strRiskLmtId = "";     /* �޲�ָ���� */
    std::string             stPartyDtlId = "";     /* ��ԱΨһ��� */
    std::string             strLmtVal = "";        /* ���³ֲ��޶� */
    std::string             strMarketType;


    bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    pCCPCredit              = (pCCPCreditUptReqT)&pReq->msgBody[0];
    pReq->msgHdr.msgType    = MSG_TYPE_CCP_CREDIT_UPDATE;

    strMarketType           = message.GetApplID();
    nMarketType             = atoi(strMarketType.c_str());
    if ( shch::MKT_SBF == nMarketType)
    {
        pCCPCredit->iFuncId     = FUNC_ID_SBFCCP_CREDIT_UPDATE;
    }

    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            shch::PartyRiskLimitsUpdate partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            strMsgId        = partyUpdate.message_id();
            strRiskLmtId    = partyUpdate.risk_limit_id();
            stPartyDtlId    = partyUpdate.party_detail_id();
            strLmtVal       = partyUpdate.limit_value();
        }
        else
        {
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }
    }
    else
    {
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%s] In condition: strMsgId = %s, strRiskLmtId = %s, stPartyDtlId = %s, strLmtVal = %s",
             "OnCCPCreditUpdateStart", strMsgId.c_str(), strRiskLmtId.c_str(), stPartyDtlId.c_str(), strLmtVal.c_str());


    memcpy(pCCPCredit->strOrgCd, stPartyDtlId.c_str(), sizeof(pCCPCredit->strOrgCd));
    pCCPCredit->msgSrno     = atoll(strMsgId.c_str());
    pCCPCredit->crdtLmtSrno = atoll(strRiskLmtId.c_str());
    CnvtPriceToIntnlVal(strLmtVal.c_str(), &pCCPCredit->crdtAmnt);

    pReq->msgHdr.msgLen = sizeof(CCPCreditUptReqT);

    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnCCPCreditUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnCCPCreditUpdateStop");

    shch::PartyRiskLimitsUpdateAck partyAck;
    MassMessageGrp::NoMassMessage *pNoMassMsg;
    ResCodeT                rc = NO_ERR;
    int32                   applRefSeqNum = 0, len = 0;
    size_t                  olen = 0;
    IRS_STRING              strErrCode = "";
    IRS_STRING              strErrMsg = "";
    std::string             strMsgId = "";         /* ȫ��ָ���� */
    std::string             strRiskLmtId = "";     /* �޲�ָ���� */
    std::string             strQryType;
    char                    time[MAX_TIME_LENGTH] = {0};
    char                    *pBuf = NULL;
    char                    *pTmp = NULL;
    char                    *pOut = NULL;


    pCCPCreditUptRspT       pCCPCrdt =NULL;
    pCCPCrdt       = (pCCPCreditUptRspT)pRsp->msgBody;

    IMIX20::QueryResult* pRspMessage = new QueryResult;
    if (NULL == pRspMessage)
    {
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc))
    {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    IntToString(MSG_TYPE_PARTY_RISK_LIMITS_UPDATE_ACK,strQryType);
    pRspMessage->SetQueryType(strQryType);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        delete pRspMessage;
        pRspMessage = NULL;
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    IntToString(pCCPCrdt->crdtLmtSrno, strMsgId);
    partyAck.set_risk_limit_id(strMsgId);

    partyAck.set_tran_time(getfmttime(time));
    IntToString(pCCPCrdt->crdtLmtSrno, strRiskLmtId);
    partyAck.set_message_id(strRiskLmtId);
    if (pCCPCrdt->setId == SET_MKT_SBFCCP)
    {
        partyAck.set_market_id(shch::MKT_SBF);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    if (SP_RET_SUCCESS == nExceptionFlag)
    {
        partyAck.set_status(CREDITUPDATE_SUCCESS);
    }
    else
    {
        partyAck.set_status(CREDITUPDATE_ERROR);
        partyAck.set_text(strErrMsg);
    }

    len         = partyAck.ByteSize();
    pBuf        = new char[len];
    partyAck.SerializeToArray(pBuf, len);
    pOut        = new char[len * 2 + 1];
    pTmp        = ArraytoHex(pBuf, len, pOut, &olen);
    pTmp[olen]  = 0;
    pNoMassMsg->SetMessageData(pTmp, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] pBuf;
    pBuf        = NULL;
    delete[] pOut;
    pOut        = NULL;
    SendMessage(pSendMsgList, pRspMessage);


    if (NO_ERR == nExceptionFlag)
    {

        //�����漰�û���Ϣ the same as market state change
//        CCP_SBF_SendCreditLimitMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOnlineUser, oRetParam, pSendMsgList);
        //���ض���״̬������Ϣ
//    CCP_SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
//    CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
//RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/* ������ǿƽ by qss */
ResCodeT OnSBFCCPClosePositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSBFCCPClosePositionStart");
    ResCodeT rc = NO_ERR;

    SbfCcpOrdrSubmitByCwReqT* pOrdrReq = NULL;
    pUsrBaseInfoT             pUsr = NULL;
    pOrgInfoT                 pOrgInfo = NULL;
    pCntrctBaseInfoT          pCntract = NULL;
    pNewOrderSingleReqT       pNewOrder = NULL; 
    // ��Ϣ����
    IMIX20::QueryResult     msg;
    /// ǿƽָ����
    string scls_pstn_cd = "";
    /// ��ԱΨһ���
    string sorg_id = "";
    /// ��Ʒ����
    MarketID market_id;
    /// ��Լ����
    string scntrct_cd = "";
    /// ƽ�ּ۸�
    string sordr_prc = "";
    /// ƽ�ֽ��
    string sordr_amnt = "";
    /// �ҵ����� 1-��4-��
    string sdl_dir = "";
    /// �����ύʱ��
    string sordr_exprd_tm =  "";
    //����ȫ�����
	string message_id = "";

    User usr;
    std::string sToken = "";
    std::string sUserId = "";
    MassMessageGrp* pMassMessageGrp;
    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    ClosePosition message;
    int len, nSide;
    char *out;
    size_t nLen;
    char *p;
    
    bool bRet = msg.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    //��ȡ����Ϣ
    pMassMessageGrp = msg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {        
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        
        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            out = new char[len / 2 + 1];
            
            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            message.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;
            /// ǿƽָ����
            scls_pstn_cd = message.close_position_inst_id();
            /// ��ԱΨһ���
            sorg_id = message.party_id();
            /// ��Ʒ����
            market_id = message.market_id();
            /// ��Լ����
            scntrct_cd = message.security_id();
            /// ƽ�ּ۸�
            sordr_prc = message.price();
            /// ƽ�ֽ��
            sordr_amnt = message.gross_trade_amount();
            /// �ҵ����� 1-��4-��
            nSide = (1 == message.side()) ? 0 : 1;
            IntToString(nSide, sdl_dir);
            /// �����ύʱ��
            sordr_exprd_tm = message.tran_time();
            /// ����ȫ�����
            message_id = message.message_id();
        }
    }
    
    //�������б�
    pOrdrReq = (SbfCcpOrdrSubmitByCwReqT*)&pReq->msgBody[0];
    pNewOrder = (NewOrderSingleReqT*)&pOrdrReq->orderReq;
    pReq->msgHdr.msgLen = sizeof(SbfCcpOrdrSubmitByCwReqT);
    pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_ORDER_SUBMIT_QSS;
    
    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(atoi(sorg_id.c_str()), &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    pNewOrder->newOrdrInfo.orgIdx = pOrgInfo->pos;

    strcpy(pNewOrder->token, sToken.c_str() );

    rc = IrsCntrctInfoGetByNameExt((char *)scntrct_cd.c_str(), &pCntract);
    RAISE_ERR(rc, RTN);
    pNewOrder->newOrdrInfo.contractPos = pCntract->pos;

    //��������    
    rc = SideConvertByCw(sdl_dir, &pNewOrder->newOrdrInfo.side);
    RAISE_ERR(rc, RTN);    
    
    CnvtPriceToIntnlVal(sordr_prc, &pNewOrder->newOrdrInfo.prcQtyInfo.price);
    
    pNewOrder->newOrdrInfo.prcQtyInfo.qty = StringToInt64( sordr_amnt );
    
    //(char* pString, time_t* pTime)
    DateTimeToTimestamp((char *)sordr_exprd_tm.c_str(), &pNewOrder->newOrdrInfo.effectTime);

    pNewOrder->newOrdrInfo.ordType = ImixToIrs_OrdType(E_IMIX_ORDTP_LIMIT);
    pNewOrder->newOrdrInfo.extOrdType = pNewOrder->newOrdrInfo.ordType;
    
    rc = ExecInstConvert(EXECINST_ORD_NEW, &pNewOrder->newOrdrInfo.execInst);
    RAISE_ERR(rc, RTN);
 
    pNewOrder->newOrdrInfo.ordAction = ORDR_ACT_NEW;

    pNewOrder->newOrdrInfo.apiLoginUsrIdx = -1;
    pNewOrder->newOrdrInfo.apiRqstId = 0;

    pNewOrder->newOrdrInfo.forceId = atoi(scls_pstn_cd.c_str());
	pOrdrReq->messageId = atoll(message_id.c_str());
    
    rc = ResrveReqMsg(&msg, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnSBFCCPClosePositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnSBFCCPClosePositionStop");

	pSbfCcpOrdrSubmitByCwRespT pCnclRsp = NULL;
	pNewOrderSingleRspT        pNewOrder = NULL;
	ResCodeT                   rc = NO_ERR;

    ClosePositionAck           partyAck;
    MassMessageGrp::NoMassMessage *pNoMassMsg;

    IRS_STRING                 strErrCode = "";
    IRS_STRING                 strErrMsg = "";
    string                     strQryType;
    string                     message_id = "";
    string                     sinst_id;
	int32                      applRefSeqNum = 0, len = 0;
	size_t                     olen = 0;
    char                       time[MAX_TIME_LENGTH] = {0};
    char                       *pBuf = NULL;
    char                       *pTmp = NULL;
    char                       *pOut = NULL;
    
    pCnclRsp       = (pSbfCcpOrdrSubmitByCwRespT)pRsp->msgBody;

    IMIX20::QueryResult* pRspMessage = new QueryResult;
    if (NULL == pRspMessage)
    {
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc))
    {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    IntToString(MSG_TYPE_CLOSE_POSITION_ACK,strQryType);
    pRspMessage->SetQueryType(strQryType);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        delete pRspMessage;
        pRspMessage = NULL;
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    IntToString(pCnclRsp->forceId, sinst_id);
    partyAck.set_close_position_inst_id(sinst_id);
	rc = GetStrDateTimeByFormat(pCnclRsp->effectTime, time);
    RAISE_ERR(rc, RTN);
    partyAck.set_tran_time(time);
    IntToString(pCnclRsp->messageId, message_id);
    partyAck.set_message_id(message_id);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    if (SP_RET_SUCCESS == nExceptionFlag)
    {
        partyAck.set_status(CREDITUPDATE_SUCCESS);
    }
    else
    {
        partyAck.set_status(CREDITUPDATE_ERROR);
        partyAck.set_text(strErrMsg);
    }

    if (pRsp->msgHdr.setId == SET_MKT_SBFCCP)
    {
        partyAck.set_market_id(shch::MKT_SBF);
    }

    len         = partyAck.ByteSize();
    pBuf        = new char[len];
    partyAck.SerializeToArray(pBuf, len);
    pOut        = new char[len * 2 + 1];
    pTmp        = ArraytoHex(pBuf, len, pOut, &olen);
    pTmp[olen]  = 0;
    pNoMassMsg->SetMessageData(pTmp, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] pBuf;
    pBuf        = NULL;
    delete[] pOut;
    pOut        = NULL;
    SendMessage(pSendMsgList, pRspMessage);

    if (NO_ERR == nExceptionFlag)
    {
        pNewOrder = (pNewOrderSingleRspT)&pCnclRsp->orderRsp;
		rc = SendClsPosnOrdrDealStsUpdtMsgToTrdr(pCnclRsp->forceId, pCnclRsp->orgIdx, 
							RDP_COMPID, pNewOrder->rspSlot, pNewOrder->slotCnt, 
							pSendMsgList);
        RAISE_ERR(rc, RTN); 

//        CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
//SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//CCP_SBF_SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//CCP_SBF_SendDealMsgToTDPSToSHCH(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);// 客户端成交信�?
//
//CCP_SBF_SendDealMsgToTrader(RDP_COMPID, oRetParamRst.m_vecDeals, oRetParamRst.m_vecOnlineUser, pSendMsgList);
//CCP_SendDescMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOnlineUser,oRetParamRst.m_vecCrdtLmts, DESC_CLOSE_POSITION_STATE, pSendMsgList);    //提示消息给客户端
//
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/* SBFǿ��ƽ�ֳ��� */
ResCodeT OnSBFCCPClosePositionCancelStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSBFCCPClosePositionCancelStart");
    ResCodeT                  rc = NO_ERR;
    bool                      bRet = FALSE;
	pSbfCcpOrdrCancelByCwReqT pOrdrCncl = NULL;
	pOrderCancelRequestReqT   pOrderMsg = NULL;
	pUsrBaseInfoT             pUsr = NULL;

    IMIX20::QueryResult       msg;
    MassMessageGrp*           pMassMessageGrp;
    int                       nMassSize;
    int                       len;
    char                      *out;
    size_t                    nLen;
    char                      *p;
    UndoClosePosition         message;
    string                    sInst_Id = "";
    string                    sInst_Cxl_Id = "";
    string                    sTran_Time =  "";
    string                    sMessage_Id = "";

    bRet = msg.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    pMassMessageGrp = msg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            out = new char[len / 2 + 1];

            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            message.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            sInst_Id = message.close_position_inst_id();
            sInst_Cxl_Id = message.close_position_inst_cxl_id();
            sTran_Time = message.tran_time();
            sMessage_Id = message.message_id();
        }
    }


    LOG_DEBUG("[%s] In condition: sInst_Id = %s, sInst_Cxl_Id = %s, sTran_Time = %s, sMessage_Id = %s",
             "OnSBFCCPClosePositionCancelStart", sInst_Id.c_str(), sInst_Cxl_Id.c_str(), sTran_Time.c_str(), sMessage_Id.c_str());

	pOrdrCncl = (SbfCcpOrdrCancelByCwReqT*)&pReq->msgBody[0];
	pReq->msgHdr.msgLen = sizeof(SbfCcpOrdrCancelByCwReqT);
	pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_ORDER_CANCEL_QSS;
		
	pOrderMsg = (OrderCancelRequestReqT*)&pOrdrCncl->orderCnclReq; 
		
	rc = IrsUsrInfoGetByNameExt((char *)ORDR_OPER_BY_SYS_USR, &pUsr);
	RAISE_ERR(rc, RTN);
	pOrderMsg->userIdx =  pUsr->pos;

	pOrdrCncl->forceId    = atoll(sInst_Id.c_str());
	pOrdrCncl->srcForceId = atoll(sInst_Cxl_Id.c_str());
	pOrdrCncl->messageId  = atoll(sMessage_Id.c_str());
	DateTimeToTimestamp((char *)sTran_Time.c_str(), &pOrdrCncl->tranTime);
		
	//reserve message header
    rc = ResrveReqMsg(&msg, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnSBFCCPClosePositionCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnSBFCCPClosePositionCancelStop");

    pSbfCcpOrdrCancelByCwRespT   pCnclRsp = NULL;
	pNewOrderSingleRspT          pNewOrder = NULL;
    ResCodeT                     rc = NO_ERR;

    UndoClosePositionAck         partyAck;
    MassMessageGrp::NoMassMessage *pNoMassMsg;

    int32                        applRefSeqNum = 0, len = 0;
    size_t                       olen = 0;
    IRS_STRING                   strErrCode = "";
    IRS_STRING                   strErrMsg = "";
    string                       sInst_Cxl_Id = "";// ǿƽ�������
    string                       sMessage_Id = ""; //����ȫ�����
    string                       strQryType;
    char                         *pBuf = NULL;
    char                         *pTmp = NULL;
    char                         *pOut = NULL;
    char                         time[MAX_TIME_LENGTH] = {0};

    pCnclRsp   = (pSbfCcpOrdrCancelByCwRespT)pRsp->msgBody;

    IMIX20::QueryResult* pRspMessage = new QueryResult;
    if (NULL == pRspMessage)
    {
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc))
    {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    IntToString(MSG_TYPE_CLOSE_UNDO_POSITION_ACK, strQryType);
    pRspMessage->SetQueryType(strQryType);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        delete pRspMessage;
        pRspMessage = NULL;
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    IntToString(pCnclRsp->srcForceId, sInst_Cxl_Id);
    partyAck.set_close_position_inst_cxl_id(sInst_Cxl_Id);
    rc = GetStrDateTimeByFormat(pCnclRsp->tranTime, time);
    RAISE_ERR(rc, RTN);
    partyAck.set_tran_time(time);

    IntToString(pCnclRsp->messageId, sMessage_Id);
    partyAck.set_message_id(sMessage_Id);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    if (SP_RET_SUCCESS == nExceptionFlag)
    {
        partyAck.set_status(CREDITUPDATE_SUCCESS);
    }
    else
    {
        partyAck.set_status(CREDITUPDATE_ERROR);
        partyAck.set_text(strErrMsg);
    }

    if (pRsp->msgHdr.setId == SET_MKT_SBFCCP)
    {
        partyAck.set_market_id(shch::MKT_SBF);
    }

    len         = partyAck.ByteSize();
    pBuf        = new char[len];
    partyAck.SerializeToArray(pBuf, len);
    pOut        = new char[len * 2 + 1];
    pTmp        = ArraytoHex(pBuf, len, pOut, &olen);
    pTmp[olen]  = 0;
    pNoMassMsg->SetMessageData(pTmp, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] pBuf;
    pBuf        = NULL;
    delete[] pOut;
    pOut        = NULL;
    SendMessage(pSendMsgList, pRspMessage);


    if (NO_ERR == nExceptionFlag)
    {
        pNewOrder = (pNewOrderSingleRspT)&pCnclRsp->orderRsp;
		//todo modify orgid
        rc = SendClsPosnOrdrDealStsUpdtMsgToTrdr(1, pCnclRsp->orgIdx, RDP_COMPID, 
                pNewOrder->rspSlot, pNewOrder->slotCnt, pSendMsgList);
  //      RAISE_ERR(rc, RTN); 
//        CCP_SBF_SendCreditLimitMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOnlineUser, oRetParam, pSendMsgList);
//     CCP_SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
//     CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
//RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
