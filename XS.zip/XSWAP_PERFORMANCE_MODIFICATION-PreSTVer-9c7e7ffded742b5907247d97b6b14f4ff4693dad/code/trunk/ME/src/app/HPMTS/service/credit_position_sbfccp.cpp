/***
Created on Oct 13, 2017
@author: Xiaoping Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "cfg_lib.h"
#include "db_comm.h"
#include "common_macro.h"
#include "uti_tool.h"

#include "contract_info.h"
#include "prdct_info.h"
#include "credit_info_sbfccp.h"
#include "credit_position_sbfccp.h"
#include "msg_credit_position_sbfccp.h"
#include "pck_irs_util.h"
#include "pck_irs_dicdata.h"
#include "ref_dat_updt.h"
#include "usr_def_ref.h"
#include "usr.h"
#include "order_type.h"
#include "internal_base_def.h"
#include "match_lib.h"
#include "ordr_mgmt.h"
#include "order_book.h"
#include "order_check.h"
#include "acnt_info.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
static ResCodeT ClearHoldCredit(uint32 orgId, ClrHoldCrdtResultT* pResult);

/******************************************************************************
 **
 ** Detail Service Callback : BaseParamUpdate
 **
 ******************************************************************************/
/* 合约转换比例 */ 
ResCodeT SbfCcpCntrctCnvrtModify(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp)
{
    BEGIN_FUNCTION( "SbfCcpCntrctCnvrtModify" );
    ResCodeT rc = NO_ERR;

    SbfCcpCntrctCnvrtModifyReqT *pCntrctCnvrtMdfyReq;
    int32 v_OutOrgId;
    pCntrctBaseInfoT pCntrctInfo;
    
    pCntrctCnvrtMdfyReq = (SbfCcpCntrctCnvrtModifyReqT*)&pReq->msgBody[0];
    
    /* 通用检查 */
    rc = SbfCcpCommonChk(pCntrctCnvrtMdfyReq->strUserId, C_ORG_NULL, pCntrctCnvrtMdfyReq->intFuncId,
                pCntrctCnvrtMdfyReq->strToken, &v_OutOrgId);
    RAISE_ERR(rc, RTN);
    
    rc = IrsCntrctInfoGetByNameExt(pCntrctCnvrtMdfyReq->strCntrctCd, &pCntrctInfo);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST){
        RAISE_ERR(ERR_CODE_INVLD_CNTRCT_NOTEXIST, RTN);
    }else{
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

/* 场务限仓 */
ResCodeT SbfCcpCrdtLimitByCw(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp)
{
    BEGIN_FUNCTION( "SbfCcpCrdtLimitByCw" );
    ResCodeT rc = NO_ERR;
    
    SbfCcpCrdtLimitByCwReqT *pCrdtLimitReq;
    SbfCcpCrdtLimitByCwRespT *pCrdtLimitResp;
    pCreditSbfCcpT pCrdtData;
    SbfCcpCrdtLimitDataRefT crdtLimitDataRef;
    int32 v_OutOrgId;
    double v_CrdtAmnt, v_IntlAmnt;
    double v_BidUsed, v_OfrUsed, v_BidTotl, v_OfrTotl;
    double v_BidRmn, v_OfrRmn;
    char hitMsg[50] = {0};
    char sysUptDateStr[MAX_TIME_LEN];
    ClrHoldCrdtResultT clrHldCrdtData;
    
    
    pCrdtLimitReq = (SbfCcpCrdtLimitByCwReqT*)&pReq->msgBody[0];
    pCrdtLimitResp = (SbfCcpCrdtLimitByCwRespT*)&pRsp->msgBody[0];
    
    memset(pCrdtLimitResp, 0x00, sizeof(SbfCcpCrdtLimitByCwRespT));
    memset(&crdtLimitDataRef, 0x00, sizeof(SbfCcpCrdtLimitDataRefT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
    
    /* 通用检查 */
    rc = SbfCcpCommonChk(pCrdtLimitReq->strUserId, pCrdtLimitReq->intOrgId, pCrdtLimitReq->intFuncId,
                pCrdtLimitReq->strToken, &v_OutOrgId);
    RAISE_ERR(rc, RTN);
    
    
    /* 限仓 */
    
    /* Check if the credit value beyond the valid range */
    if (pCrdtLimitReq->intCrdtAmnt < 0 || (1.0*pCrdtLimitReq->intCrdtAmnt/pow10(FIGURES_OF_CREDIT_AMOUNT_SBFCCP)) > 99999900000000){
        RAISE_ERR(ERR_CODE_INVLD_CRDT_PSTN, RTN);
    } 
    
    v_CrdtAmnt = 1.0*pCrdtLimitReq->intCrdtAmnt/pow10(FIGURES_OF_CREDIT_AMOUNT_SBFCCP)/2.0;
    
    rc = CreditSbfCcpInfoGetByKeyExt(pCrdtLimitReq->intOrgId, &pCrdtData);
    RAISE_ERR(rc, RTN);
    
    v_IntlAmnt = pCrdtData->intlAmnt/2.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    v_BidUsed = pCrdtData->bidUsedAmnt*1.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    v_OfrUsed = pCrdtData->ofrUsedAmnt*1.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    v_BidTotl = (pCrdtData->bidHoldAmnt + pCrdtData->bidUsedAmnt)*1.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    v_OfrTotl = (pCrdtData->ofrHoldAmnt + pCrdtData->ofrUsedAmnt)*1.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    
    /* 更新各初始额度 */
    crdtLimitDataRef.intlAmnt = (1.0*pCrdtLimitReq->intCrdtAmnt)/pow10(FIGURES_OF_CREDIT_AMOUNT_SBFCCP);
    crdtLimitDataRef.bidIntlAmnt = v_CrdtAmnt;
    crdtLimitDataRef.ofrIntlAmnt = -1 * v_CrdtAmnt;
    
    crdtLimitDataRef.intOrgId = pCrdtLimitReq->intOrgId;
    
    
    crdtLimitDataRef.ordFrzFlag = FALSE;
    
    if (pCrdtData->lmtPstnFlag == C_SHCH_LMTPSTN_ON){
        if (v_CrdtAmnt > v_IntlAmnt && 
            v_CrdtAmnt > v_BidUsed && 
            (-1.0 * v_CrdtAmnt) < v_OfrUsed){
            /* 退出限仓模式，冻结订单 */
            strcpy(hitMsg, "限仓模式解除");
            
            rc = ClearHoldCredit(pCrdtLimitReq->intOrgId, &clrHldCrdtData);
            RAISE_ERR(rc, RTN);
            
            crdtLimitDataRef.ordFrzFlag = TRUE;
            crdtLimitDataRef.isLmtPstnUpdated = clrHldCrdtData.isLmtPstnUpdated;
            crdtLimitDataRef.lmtPstnFlagValue = clrHldCrdtData.lmtPstnFlagValue;
            crdtLimitDataRef.bidUsedAmnt = clrHldCrdtData.bidUsedAmnt;
            crdtLimitDataRef.bidRmnAmnt = clrHldCrdtData.bidRmnAmnt;
            crdtLimitDataRef.ofrUsedAmnt = clrHldCrdtData.ofrUsedAmnt;
            crdtLimitDataRef.ofrRmnAmnt = clrHldCrdtData.ofrRmnAmnt;
            
            crdtLimitDataRef.bidHoldAmnt = 0;
            crdtLimitDataRef.ofrHoldAmnt = 0;
            crdtLimitDataRef.pstnBidHoldAmnt = 0;
            crdtLimitDataRef.pstnOfrHoldAmnt = 0;
            
            // TODO: 更新OCO_ORDR_SBFCCP、ORDR_SBFCCP和in_OrgId相关联的数据，冻结相关订单
            
            
        }else{
            strcpy(hitMsg, "持仓额度更新");
        }            
    
    }else{
        if (v_CrdtAmnt > v_IntlAmnt || 
            (v_CrdtAmnt > v_BidTotl && 
             (-1.0 * v_CrdtAmnt) < v_OfrTotl)){
             
            strcpy(hitMsg, "持仓额度更新");
        
        }else{
            /* 冻结和in_OrgId相关的所有订单 */
            // TODO: PCK_SBFCCP_Ord.sp_SBFCCP_OrdFreezeByQss
            rc = ClearHoldCredit(pCrdtLimitReq->intOrgId, &clrHldCrdtData);
            RAISE_ERR(rc, RTN);
            
            crdtLimitDataRef.ordFrzFlag = TRUE;
            crdtLimitDataRef.isLmtPstnUpdated = clrHldCrdtData.isLmtPstnUpdated;
            crdtLimitDataRef.lmtPstnFlagValue = clrHldCrdtData.lmtPstnFlagValue;
            crdtLimitDataRef.bidUsedAmnt = clrHldCrdtData.bidUsedAmnt;
            crdtLimitDataRef.bidRmnAmnt = clrHldCrdtData.bidRmnAmnt;
            crdtLimitDataRef.ofrUsedAmnt = clrHldCrdtData.ofrUsedAmnt;
            crdtLimitDataRef.ofrRmnAmnt = clrHldCrdtData.ofrRmnAmnt;
            
            crdtLimitDataRef.bidHoldAmnt = 0;
            crdtLimitDataRef.ofrHoldAmnt = 0;
            crdtLimitDataRef.pstnBidHoldAmnt = 0;
            crdtLimitDataRef.pstnOfrHoldAmnt = 0;
            
            // TODO: 更新OCO_ORDR_SBFCCP、ORDR_SBFCCP和in_OrgId相关联的数据，冻结相关订单
            
            
            if (v_CrdtAmnt > v_BidUsed && 
                (-1.0 * v_CrdtAmnt) < v_OfrUsed){
            
                strcpy(hitMsg, "持仓额度更新");
            
            }else{
                strcpy(hitMsg, "进入限仓模式");
            
            }
        }    
    }
    
    v_BidRmn = v_CrdtAmnt - v_BidUsed;
    v_OfrRmn = (-1.0 * v_CrdtAmnt) - v_OfrUsed;
    
    if (v_BidRmn < 0){
        v_BidRmn = 0;
    }
    
    if (v_OfrRmn > 0){
       v_OfrRmn = 0;
    }
    
    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);
    
    /* 更新限额 */
    crdtLimitDataRef.bidRmnAmnt = v_BidRmn;
    crdtLimitDataRef.ofrRmnAmnt = v_OfrRmn;
    
    strcpy(crdtLimitDataRef.strSysTime, sysUptDateStr);
    
    /* Do shared memory update & DB update */
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_SBFCCP_CREDIT_LIMIT_DAT, &crdtLimitDataRef, sizeof(SbfCcpCrdtLimitDataRefT));
    RAISE_ERR(rc, RTN);

    strcpy(pCrdtLimitResp->strHitMsg, hitMsg);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


static ResCodeT ClearHoldCredit(uint32 inOrgId, ClrHoldCrdtResultT* pResult)
{
    BEGIN_FUNCTION( "ClearHoldCredit" );
    ResCodeT rc = NO_ERR;
    
    pCreditSbfCcpT pCrdtData;
    pCntrctPstnSbfCcpT pCntrctPstnData;
    pCntrctBaseInfoT pCntrctInfo;
    double v_Bid_Used, v_Ofr_Used;
    double v_Bid_Restrict, v_Ofr_Restrict;
    double v_Bid_Rmn, v_Ofr_Rmn;
    uint32 pstnPos = CMN_LIST_NULL_NODE;
    
    
    memset(pResult, 0x00, sizeof(ClrHoldCrdtResultT));
    
    rc = CreditSbfCcpInfoGetByKeyExt(inOrgId, &pCrdtData);
    RAISE_ERR(rc, RTN);
    
    v_Bid_Restrict = pCrdtData->bidIntlAmnt*1.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);
    v_Ofr_Restrict = pCrdtData->ofrIntlAmnt*1.0/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT);

    v_Bid_Used = 0;
    v_Ofr_Used = 0;
    
    /* 计算总头寸（净头寸*转换系数） */
    /* Iterate all the contract position data, the org id of which is equal to the parameter.
       Then use the contract code as key to get the convert rate and calculate the Bid/Offer position. */
    while (TRUE)
    {   
        rc = CntrctPstnSbfCcpIterExt(&pstnPos, &pCntrctPstnData);
        RAISE_ERR(rc,RTN);
        
        if ( CMN_LIST_NULL_NODE == pstnPos )
        {
            break;
        }
        
        /* Check if the org id is equal to the parameter. */
        if (pCntrctPstnData->orgId == inOrgId){
            /* Use the contract code to get the info of this contract. */
            rc = IrsCntrctInfoGetByNameExt(pCntrctPstnData->cntrctCd, &pCntrctInfo);
            RAISE_ERR(rc, RTN);
            
            /* Check if the status of this contract is valid. */
            if (pCntrctInfo->st == 1 || pCntrctInfo->st == 3){
                /* Calculate the values of the Bid/Offer position and add them to the total values. */
                /* The Offer side */
                if (pCntrctPstnData->netPstn < 0){
                    v_Ofr_Used += (1.0*pCntrctPstnData->netPstn)/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT)
                                       * (1.0*pCntrctInfo->cnvrtRate/pow10(FIGURES_OF_CONVERT_RATE));
                }
                
                /* The Bid side */
                if (pCntrctPstnData->netPstn > 0){
                    v_Bid_Used += (1.0*pCntrctPstnData->netPstn)/pow10(FIGURES_OF_CREDIT_SBFCCP_AMOUNT)
                                       * (1.0*pCntrctInfo->cnvrtRate/pow10(FIGURES_OF_CONVERT_RATE));
                }
            }
        }
    }
    
    
    pResult->isLmtPstnUpdated = FALSE;
    
    if (pCrdtData->lmtPstnFlag == C_SHCH_LMTPSTN_ON){
        if ((v_Bid_Used < v_Bid_Restrict && v_Ofr_Used > v_Ofr_Restrict)
            || (v_Bid_Used == v_Bid_Restrict && v_Ofr_Used > v_Ofr_Restrict)
            || (v_Bid_Used < v_Bid_Restrict && v_Ofr_Used == v_Ofr_Restrict)
            || (v_Bid_Used == 0 && v_Ofr_Used == 0 && v_Bid_Restrict == 0 && v_Ofr_Restrict == 0)){
            /* 退出限仓模式 */
            pResult->isLmtPstnUpdated = TRUE;
            pResult->lmtPstnFlagValue = C_SHCH_LMTPSTN_OFF;
            
        }
    }else if (pCrdtData->lmtPstnFlag == C_SHCH_LMTPSTN_OFF){
        if (v_Bid_Used > v_Bid_Restrict
            || v_Ofr_Used < v_Ofr_Restrict
            || (v_Bid_Used == v_Bid_Restrict && v_Ofr_Used == v_Ofr_Restrict)){
            /* 进入限仓模式 */
            pResult->isLmtPstnUpdated = TRUE;
            pResult->lmtPstnFlagValue = C_SHCH_LMTPSTN_ON;
         
        }
    }
    
    
    v_Bid_Rmn = v_Bid_Restrict - v_Bid_Used;
    v_Ofr_Rmn = v_Ofr_Restrict - v_Ofr_Used;
    if (v_Bid_Rmn < 0){
      v_Bid_Rmn = 0;
    }
    if (v_Ofr_Rmn > 0){
      v_Ofr_Rmn = 0;
    }
    
    // Update the result with the values from the calculations above.
    pResult->bidUsedAmnt = v_Bid_Used;
    pResult->bidRmnAmnt = v_Bid_Rmn;
    pResult->ofrUsedAmnt = v_Ofr_Used;
    pResult->ofrRmnAmnt = v_Ofr_Rmn;
    

    EXIT_BLOCK();
    RETURN_RESCODE;

}

/* CW端强平 */
ResCodeT SbfCcpOrdrSubmitByCw(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "SbfCcpOrdrSubmitByCw" );
    ResCodeT rc = NO_ERR;

    SbfCcpOrdrSubmitByCwReqT    *pOrdrReq  = NULL;
    SbfCcpOrdrSubmitByCwRespT   *pOrdrRsp = NULL;
    pNewOrderSingleReqT         pNewOrdrReq = NULL;
    pNewOrderSingleRspT         pNewOrdrRsp = NULL;
    pOrgInfoT                   pOrgInfo = NULL;
    pUsrBaseInfoT               pUsr = NULL;
    pUsrBaseInfoT               pUsrEmgc = NULL;
    pOrderT                     pOrderReq = NULL;
    pPrdctInfoT                 pPrdctInfo = NULL;
    ClrHoldCrdtResultT          clrHldCrdtData = {0};
    SbfCcpCrdtLimitDataRefT     crdtLmtData;
    MtchInfoT                   mtchInfo;
    NewOrderSingleRspT          ordrSingl;
    int32                       orgId = 0;
    char                        sysUptDateStr[MAX_TIME_LEN] = {0};

    pOrdrReq    = (SbfCcpOrdrSubmitByCwReqT*)&pReq->msgBody[0];
    pOrdrRsp    = (SbfCcpOrdrSubmitByCwRespT*)&pRsp->msgBody[0];
    pNewOrdrReq = (pNewOrderSingleReqT)&pOrdrReq->orderReq;
    pNewOrdrRsp = (pNewOrderSingleRspT)&pOrdrRsp->orderRsp;

    rc = IrsUsrInfoGetByPosExt(pOrdrReq ->orderReq.newOrdrInfo.userIdx, &pUsr);
    RAISE_ERR( rc, RTN );
    
    rc = OrgInfoGetByPosExt(pOrdrReq ->orderReq.newOrdrInfo.orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    pOrdrRsp->orgIdx     = pNewOrdrReq->newOrdrInfo.orgIdx;
    pOrdrRsp->forceId    = pNewOrdrReq->newOrdrInfo.forceId;

    /* 通用检查 */
    if (pReq->msgHdr.setId == SET_MKT_SBFCCP)
    {
        rc = SbfCcpCommonChk(pUsr->usrLgnNm, pOrgInfo->orgId, C_ORDSUBMIT_FUNCID, pNewOrdrReq->token, &orgId);
        RAISE_ERR( rc, RTN );
    } 
    
    if (pUsr->lgnTp == C_USER_ROLE_GROUND || pUsr->lgnTp == C_USER_ROLE_EMGCY_GROUND)
    {
        rc = IrsUsrInfoGetByNameExt((char*)ORDR_SUBMIT_USR_EMG, &pUsrEmgc);
        RAISE_ERR( rc, RTN );
        pNewOrdrReq->newOrdrInfo.userIdx = pUsrEmgc->pos;
    }

    rc = PrdctInfoGetByPosExt(pNewOrdrReq->newOrdrInfo.contractPos, &pPrdctInfo);
    RAISE_ERR( rc, RTN );   

    /* 订单有效性检查 */
    rc = SbfCcpOrdrValidate(&pNewOrdrReq->newOrdrInfo, timestamp);
    RAISE_ERR(rc, RTN);

    rc = ClearHoldCredit(pOrgInfo->orgId, &clrHldCrdtData);
    RAISE_ERR(rc, RTN);
    
    memset(&crdtLmtData, 0x00, sizeof(SbfCcpCrdtLimitDataRefT));
    crdtLmtData.intOrgId = pOrgInfo->orgId;
    crdtLmtData.ordFrzFlag = TRUE;
    crdtLmtData.isLmtPstnUpdated = clrHldCrdtData.isLmtPstnUpdated;
    crdtLmtData.lmtPstnFlagValue = clrHldCrdtData.lmtPstnFlagValue;
    crdtLmtData.bidUsedAmnt = clrHldCrdtData.bidUsedAmnt;
    crdtLmtData.bidRmnAmnt = clrHldCrdtData.bidRmnAmnt;
    crdtLmtData.ofrUsedAmnt = clrHldCrdtData.ofrUsedAmnt;
    crdtLmtData.ofrRmnAmnt = clrHldCrdtData.ofrRmnAmnt;
    
    crdtLmtData.bidHoldAmnt = 0;
    crdtLmtData.ofrHoldAmnt = 0;
    crdtLmtData.pstnBidHoldAmnt = 0;
    crdtLmtData.pstnOfrHoldAmnt = 0;

    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);

    strcpy(crdtLmtData.strSysTime, sysUptDateStr);

    /* Do shared memory update & DB update */
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORDRSBMT_BYCW_DAT, &crdtLmtData, 
            sizeof(SbfCcpCrdtLimitDataRefT));
    RAISE_ERR(rc, RTN);
    
    // TODO: 更新OCO_ORDR_SBFCCP、ORDR_SBFCCP和in_OrgId相关联的数据，冻结相关订单
    InitRspDat(pNewOrdrRsp);
    rc = MtchrPrcsFreezeOrgClsPosnOrdrBySet(pReq->msgHdr.setId, pOrgInfo->orgId, 
            timestamp, pNewOrdrRsp);
    RAISE_ERR( rc, RTN );
    /* 订单处理 */
    rc = MtchrCreateOrdrFromOrdrInfo(pReq->msgHdr.setId, &pNewOrdrReq->newOrdrInfo, 
            &pOrderReq, FALSE, NULL);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsOrdrAdd(FALSE, TRUE, pReq->msgHdr.setId, pPrdctInfo, pOrderReq, 
            timestamp, pNewOrdrRsp, &mtchInfo);
    RAISE_ERR( rc, RTN );
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/* CW端强平撤销 */
ResCodeT SbfCcpOrdrCancelByCw(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "SbfCcpOrdrCancelByCw" );
    ResCodeT                    rc = NO_ERR;
    SbfCcpOrdrCancelByCwReqT    *pOrdrCancelReq = NULL; 
    SbfCcpOrdrCancelByCwRespT   *pOrdrCancelResp = NULL; 
    SbfCcpCrdtLimitDataRefT     ordrCancelDataRef;
    OrderCancelRequestReqT      *pOrderMsg = NULL; 
    int32                       v_OutOrgId;
    char                        sysUptDateStr[MAX_TIME_LEN];
    pUsrBaseInfoT               pUsr =NULL;
    pOrgInfoT                   pOrgInfo = NULL;
    int32                       orgId;
    
    memset(&ordrCancelDataRef, 0x00, sizeof(SbfCcpCrdtLimitDataRefT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));

    pOrdrCancelReq  = (SbfCcpOrdrCancelByCwReqT*)&pReq->msgBody[0];
    pOrdrCancelResp = (SbfCcpOrdrCancelByCwRespT*)&pRsp->msgBody[0];
    pOrderMsg = (OrderCancelRequestReqT*)&pOrdrCancelReq->orderCnclReq;
    pOrdrCancelResp->orgIdx = pOrderMsg->orgIdx;
    
    rc = OrgInfoGetByPosExt(pOrdrCancelReq->orderCnclReq.orgIdx, &pOrgInfo);
    RAISE_ERR( rc, RTN );

    rc = IrsUsrInfoGetByPosExt(pOrderMsg->userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    if (pReq->msgHdr.setId == SET_MKT_SBFCCP)
    {
        rc = SbfCcpCommonChk(pUsr->usrLgnNm, pOrgInfo->orgId, C_ORDCANCEL_FUNCID, 
                pOrderMsg->token, &orgId);
        RAISE_ERR( rc, RTN );
    }

    InitRspDat(&pOrdrCancelResp->orderRsp );

    rc = MtchrPrcsCnclClsPosnOrgOrdrBySet(pReq->msgHdr.setId, pOrgInfo->orgId, 
           timestamp, &pOrdrCancelResp->orderRsp);
    RAISE_ERR(rc, RTN);
    
    ordrCancelDataRef.intOrgId = pOrgInfo->orgId;
    /* Do shared memory update & DB update */
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORDRCNCL_BYCW_DAT, &ordrCancelDataRef, 
            sizeof(SbfCcpCrdtLimitDataRefT));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/* 订单验证 */
ResCodeT SbfCcpOrdrValidate(pNewOrderInfoT pOrder, int64 timestamp)
{
    BEGIN_FUNCTION( "SbfCcpOrdrValidate" );
    ResCodeT rc = NO_ERR;

    pCntrctBaseInfoT pCntrctInfo;
    int64 expireTimestamp;
    int32 acntInfoCnt;
    double v_RefPrc;
    pPrdctInfoT pPrdctData;
    pOrgInfoT pOrgData;
    pAcntInfoT pAcntData;
    pDpstAcntInfoSbfT pDpstAcntData;
    char sysDateStr[MAX_TIME_LEN];
    char sysTimeStr[MAX_TIME_LEN];
    char paramDateStr[MAX_TIME_LEN];
    char paramTimeStr[MAX_TIME_LEN];
    char orderExpireTime[MAX_TIME_LEN];
    
    
    memset(sysDateStr, 0x00, sizeof(sysDateStr));
    memset(sysTimeStr, 0x00, sizeof(sysTimeStr));
    memset(paramDateStr, 0x00, sizeof(paramDateStr));
    memset(paramTimeStr, 0x00, sizeof(paramTimeStr));
    memset(orderExpireTime, 0x00, sizeof(orderExpireTime));
    
    /* 检查是否有默认账号 */
    rc = OrgInfoGetByPosExt(pOrder->orgIdx, &pOrgData);
    RAISE_ERR(rc, RTN);
    
    if (pOrgData->dfltAcntPos == -1){
        /* The value of positon equals -1 means that this org has no default account. */
        RAISE_ERR(ERR_CODE_INVLD_CAPICALACT, RTN);
    }
    
    if (pOrgData->dfltDpstAcntSbfPos == -1){
        /* The value of positon equals -1 means that this org has no default SBF deposit account. */
        RAISE_ERR(ERR_CODE_INVLD_DPST_CAPICALACT, RTN);
    }
    
    /* 如果资金账户和托管账户都存在默认值，判断关联信息 */
    if (pOrgData->dfltDpstAcntSbfPos != -1){
        /* The position value of SBF deposit account in org info doesn't equal to initial value(-1), so it has default SBF deposit account. */
        
        /* Get default account info & default SBF deposit account info by position value. */
        rc = AcntInfoGetByPosExt(pOrgData->dfltAcntPos, &pAcntData);
        RAISE_ERR(rc, RTN);
        
        rc = DpstAcntInfoSbfGetByPosExt(pOrgData->dfltDpstAcntSbfPos, &pDpstAcntData);
        RAISE_ERR(rc, RTN);
        
        /* Check if the account serial numbers matches. */
        if (pAcntData->acntSrno != pDpstAcntData->acntSrno){
            RAISE_ERR(ERR_CODE_ACNT_NO_LINKED, RTN);
        }
    }else{
        RAISE_ERR(ERR_CODE_DPST_ACNT_NO_LINKED, RTN);
    }
    
    
    /* 获取合约信息 */
    rc = IrsCntrctInfoGetByPosExt(pOrder->contractPos, &pCntrctInfo);
    RAISE_ERR(rc, RTN);

    /* -----------------------------参数有效性验证----------------------------- */

    /* 判断时间是否有效 */
    // if (strlen(pOrder->ordrSbmtTp) == 0){
        // strcpy(v_OrdrSbmtTp, C_ORD_TYPE_LIMIT);
    // }else{
        // strcpy(v_OrdrSbmtTp, pOrder->ordrSbmtTp);
    // }
    
    // if ((strcmp(pOrder->ordrAct, C_ORD_ACT_ACTIVATE) != 0)
        // && (pOrder->ordType == EXT_ORD_TYPE_NORMAL)){
    
    /* 强平订单属于普通新增订单，需要做时间有效性检查 */
    rc = GetStrDateTime(timestamp, sysDateStr, sysTimeStr);
    RAISE_ERR(rc, RTN);
    
    rc = GetStrDateTime(pOrder->effectTime, paramDateStr, paramTimeStr);
    RAISE_ERR(rc, RTN);
    
    strcpy(orderExpireTime, sysDateStr);
    strcpy(orderExpireTime + 8, "-");
    strcpy(orderExpireTime + 9, paramTimeStr);
    
    rc = DateTimeToTimestamp(orderExpireTime, &expireTimestamp);
    RAISE_ERR(rc, RTN);
    
    if (expireTimestamp < timestamp){
        RAISE_ERR(ERR_CODE_INVLD_EXPIRE_TIME, RTN);
    }
    // }
    
    /* 判断合约状态 */
    if (pCntrctInfo->st != 1){
        RAISE_ERR(ERR_CODE_PARAM_CNTRCT_ERR_ST, RTN);
    }
    
    /* 判断手数是否在最大最小区间内 */
    if (1.0*pOrder->prcQtyInfo.qty/(pCntrctInfo->amntPerUnit/pow10(FIGURES_OF_AMNT_PER_UNIT)) > 
        pCntrctInfo->maxAmntPerDeal)
    {
        if (pOrder->ordType != EXT_ORD_TYPE_CLICK){
            RAISE_ERR(ERR_CODE_INVLD_ORDR_QTY, RTN);
        }
    
    }
    
    if (1.0*pOrder->prcQtyInfo.qty/(pCntrctInfo->amntPerUnit/pow10(FIGURES_OF_AMNT_PER_UNIT)) < 
        pCntrctInfo->minAmntPerDeal)
    {
        RAISE_ERR(ERR_CODE_INVLD_ORDR_QTY, RTN);
    }
    
    
    /* ----- 强平的情况下，强平订单不是OCO订单，因此不需要下面的判断 ------- */
    // /* OCO编号和客户端临时OCO编号不可以同时有值 */
    // if ((strlen(pOrder->ordrId) != 0) && (strlen(pOrder->tempOcoId) != 0)){
        // RAISE_ERR(ERR_CODE_INVLD_OCO_ID, RTN);    
    // }
    
    /* ----- 强平的情况下，强平订单不需要判断盘中参考价 ------- */
    // /* 提交订单检查 */
    // if (funcId == C_ORDSUBMIT_FUNCID ||
        // funcId == C_ORDACTIVATE_FUNCID){
        
        // /* 是否需要判断盘中参考价 */
        // if (pOrder->isExecute == C_CHK_REF_PRC_Y){
        
            // // Get the product info of the contract.
            // rc = PrdctInfoGetByNameExt(pOrder->cntrctNm, &pPrdctData);
            // RAISE_ERR(rc, RTN);
            
            // // Get the reference price of the contract.
            // v_RefPrc = pPrdctData->baseInfo.intraRefPrc * 1.0 / PRICE_BASE;
            
            // /* 订单价格与盘中参考价的差需要在点差以内 */
            // if ( ( pOrder->ordrPrc > v_RefPrc * (1 + pCntrctInfo->prcLimit*1.0/pow10(FIGURES_OF_PRICE_LIMIT)/C_BP_FCTR) ) ||
                 // ( pOrder->ordrPrc < v_RefPrc * (1 - pCntrctInfo->prcLimit*1.0/pow10(FIGURES_OF_PRICE_LIMIT)/C_BP_FCTR) ) ){
                
                // RAISE_ERR(ERR_CODE_MORE_THAN_REF, RTN);
            // }
        // }
    // }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


// /* 订单激活处理 */
// ResCodeT SbfCcpOrdrProcess(int32 connId, pCcpOrderT pOrder, char *outOrderId, int64 timestamp )
// {
    // BEGIN_FUNCTION( "SbfCcpOrdrProcess" );
    // ResCodeT rc = NO_ERR;

    // CcpOrderT v_NewOrder = {0};
    // char v_OrderId[CCP_ORDER_ID_LENGTH] = {0};
    
    
    // /* 新订单赋值 */
    // memcpy(&v_NewOrder, pOrder, sizeof(CcpOrderT));
    
    // /* 新增订单记录 */
    // rc = SbfCcpOrdrAdd(connId, &v_NewOrder, v_OrderId, timestamp);
    // RAISE_ERR(rc, RTN);
    
    // /* 修改orderID */
    // memset(v_NewOrder.ordrId, 0x00, CCP_ORDER_ID_LENGTH);
    // strcpy(v_NewOrder.ordrId, v_OrderId);
    
    // if (strlen(v_NewOrder.forceCd) == 0){
        // // TODO: 场务强平功能界面上，强平指令是必须输入项目，因此不会运行到这个分支中
    // }
    
    // // TODO: 订单撮合  此功能应在新增强平订单后由ME进行，在此应不用处理
    
    
    // strcpy(outOrderId, v_OrderId);
    
    
    // EXIT_BLOCK();
    // RETURN_RESCODE;

// }


// /* 订单保存处理 */
// ResCodeT SbfCcpOrdrAdd(int32 connId, pCcpOrderT pOrder, char *outOrderId, int64 timestamp )
// {
    // BEGIN_FUNCTION( "SbfCcpOrdrAdd" );
    // ResCodeT rc = NO_ERR;

    // char v_St[CCP_ORDER_ST_LENGTH] = {0};
    // char v_OcoId[CCP_OCO_ORDER_ID_LENGTH] = {0};
    // char v_OrdrSbmtTp[CCP_ORDER_SUBMIT_TYPE_LENGTH] = {0};
    // char v_OrdrTp[CCP_ORDER_TYPE_LENGTH] = {0};
    // char v_CurrTime[MAX_TIME_LEN] = {0};
    // char v_ActiveTime[MAX_TIME_LEN] = {0};
    // char v_OrderId[CCP_ORDER_ID_LENGTH] = {0};
    
    
    // rc = SbfCcpGetOcoId(connId, pOrder, v_St, v_OcoId);
    // RAISE_ERR(rc, RTN);
    
    // /* 如果订单类型为空，则默认为限价订单 */
    // if (strlen(pOrder->ordrSbmtTp) == 0){
        // strcpy(v_OrdrSbmtTp, C_ORD_TYPE_LIMIT);
    // } else {
        // strcpy(v_OrdrSbmtTp, pOrder->ordrSbmtTp);
    // }
    
    // if (strlen(v_OcoId) == 0){
        // strcpy(v_OrdrTp, C_ORD_TYPE_R);
    // } else {
        // strcpy(v_OrdrTp, C_ORD_TYPE_OCO);
    // }
    
    // rc = GetStrDateTimeByFormat(timestamp, v_CurrTime);
    // RAISE_ERR(rc, RTN);
    
    // /* 激活时间默认为空，如果订单状态为激活，则激活时间为当前时间 */
    // if (strcmp(v_St, C_ORD_STATUS_ACTIVE) == 0){
        // strcpy(v_ActiveTime, v_CurrTime);
    // }
    
    // /* 新增或修改订单则在数据库中新增一条记录 */
    // if ( strcmp(pOrder->ordrAct, C_ORD_ACT_INSERT) == 0 || 
         // strcmp(pOrder->ordrAct, C_ORD_ACT_UPDATE) == 0 ){
    
        // // TODO: 获取订单编号
        // // TODO: 获取机构中文全称
        // // TODO: 新增订单
        
        // // TODO: v_OcoId有值的情况下，要做相应处理，强平处理不需要
        
        // // TODO: 修改订单设置原订单状态为撤销  强平处理不需要
    
    // } else if ( strcmp(pOrder->ordrAct, C_ORD_ACT_ACTIVATE) == 0 ){
        // /* 订单激活 */
        // // TODO: 订单激活处理   强平处理不需要
    // } else {
        // /* 其它类型则报错 */
        // RAISE_ERR(ERR_CODE_INVLD_ORDER_ACTION, RTN);
    // }
    
    // /* 返回OrderId */
    // strcpy(outOrderId, v_OrderId);
    
    // EXIT_BLOCK();
    // RETURN_RESCODE;

// }


// /* 通过客户端临时ID获取OCO编号 */
// ResCodeT SbfCcpGetOcoId(int32 connId, pCcpOrderT pOrder, char *outSt, char *outOcoId )
// {
    // BEGIN_FUNCTION( "SbfCcpGetOcoId" );
    // ResCodeT rc = NO_ERR;
    
    // BOOL v_OcoCnt = FALSE;
    // BOOL v_TempOcoCnt = FALSE;
    // BOOL v_OcoCntCancel = FALSE;
    

    // /* 订单初始状态 */
    // strcpy(outSt, pOrder->st);
    
    
    // /* 如果客户端临时号码不为空则通过前台临时OCO编号获取后台OCO编号 */
    // // TODO: 根据pOrder的ocoId，到SBFCCP的OCO订单列表中寻找对应的数据，
    // //       有三种不同的找寻方式，根据寻找的结果，返回对应的ocoId
    // // 1. check if v_OcoCnt == TRUE??
    // // 2. check if v_TempOcoCnt == TRUE??
    // // 3. check if v_OcoCntCancel == TRUE?? (实际代码中未使用，可以不必实现)
    // // 场务强平的情况下，因为强平订单不是OCO订单，pOrder的ocoId为空，
    // // 返回的ocoId也是空，那强平情况下没有必要调用这个方法，
    
    
    // if (v_OcoCnt == TRUE){
        // /* 如果订单中oco编号存在，则返回oco编号 */
        // strcpy(outOcoId, pOrder->ocoId);
    // } else if (v_TempOcoCnt == TRUE){
        // /* 如果订单中temp oco编号存在则获取对应的oco编号 */
        // // TODO: Get the corresponding OCO Id
        
    // } else if (strlen(pOrder->ocoId) != 0){
        // /* 如果都不存在，但oco编号不为空，则说明该oco被成交了 */
        // memset(outOcoId, 0x00, CCP_OCO_ORDER_ID_LENGTH);
        // strcpy(outSt, C_ORD_STATUS_FROZEN);
    // } else {
        // /* 其余情况说明该订单为普通订单 */
        // memset(outOcoId, 0x00, CCP_OCO_ORDER_ID_LENGTH);
    // }
    
    // EXIT_BLOCK();
    // RETURN_RESCODE;

// }


ResCodeT SbfCcpOrdrSubmitByQss(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "SbfCcpOrdrSubmitByQss" );
    ResCodeT rc = NO_ERR;

    SbfCcpOrdrSubmitByCwReqT    *pOrdrReq  = NULL;
    SbfCcpOrdrSubmitByCwRespT   *pOrdrRsp = NULL;
    pNewOrderSingleReqT         pNewOrdrReq = NULL;
    pNewOrderSingleRspT         pNewOrdrRsp = NULL;
    pOrgInfoT                   pOrgInfo = NULL;
    pUsrBaseInfoT               pUsr = NULL;
    pUsrBaseInfoT               pUsrEmgc = NULL;
    pOrderT                     pOrderReq = NULL;
    pPrdctInfoT                 pPrdctInfo = NULL;
    ClrHoldCrdtResultT          clrHldCrdtData = {0};
    SbfCcpCrdtLimitDataRefT     crdtLmtData;
    MtchInfoT                   mtchInfo;
    NewOrderSingleRspT          ordrSingl;
    int32                       orgId = 0;
    char                        sysUptDateStr[MAX_TIME_LEN] = {0};

    pOrdrReq    = (SbfCcpOrdrSubmitByCwReqT*)&pReq->msgBody[0];
    pOrdrRsp    = (SbfCcpOrdrSubmitByCwRespT*)&pRsp->msgBody[0];
    pNewOrdrReq = (pNewOrderSingleReqT)&pOrdrReq->orderReq;
    pNewOrdrRsp = (pNewOrderSingleRspT)&pOrdrRsp->orderRsp;
    
    rc = OrgInfoGetByPosExt(pOrdrReq ->orderReq.newOrdrInfo.orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    pOrdrRsp->forceId    = pNewOrdrReq->newOrdrInfo.forceId;
	pOrdrRsp->messageId    = pOrdrReq->messageId;
	pOrdrRsp->effectTime   = pNewOrdrReq->newOrdrInfo.effectTime;

    rc = PrdctInfoGetByPosExt(pNewOrdrReq->newOrdrInfo.contractPos, &pPrdctInfo);
    RAISE_ERR( rc, RTN );   

    rc = SbfCcpOrdrValidate(&pNewOrdrReq->newOrdrInfo, timestamp);
    RAISE_ERR(rc, RTN);

    rc = ClearHoldCredit(pOrgInfo->orgId, &clrHldCrdtData);
    RAISE_ERR(rc, RTN);
    
    memset(&crdtLmtData, 0x00, sizeof(SbfCcpCrdtLimitDataRefT));
    crdtLmtData.intOrgId         = pOrgInfo->orgId;
    crdtLmtData.ordFrzFlag       = TRUE;
    crdtLmtData.isLmtPstnUpdated = clrHldCrdtData.isLmtPstnUpdated;
    crdtLmtData.lmtPstnFlagValue = clrHldCrdtData.lmtPstnFlagValue;
    crdtLmtData.bidUsedAmnt      = clrHldCrdtData.bidUsedAmnt;
    crdtLmtData.bidRmnAmnt       = clrHldCrdtData.bidRmnAmnt;
    crdtLmtData.ofrUsedAmnt      = clrHldCrdtData.ofrUsedAmnt;
    crdtLmtData.ofrRmnAmnt       = clrHldCrdtData.ofrRmnAmnt;
    
    crdtLmtData.bidHoldAmnt = 0;
    crdtLmtData.ofrHoldAmnt = 0;
    crdtLmtData.pstnBidHoldAmnt = 0;
    crdtLmtData.pstnOfrHoldAmnt = 0;

    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);

    strcpy(crdtLmtData.strSysTime, sysUptDateStr);

    /* Do shared memory update & DB update */
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORDRSBMT_BYCW_DAT, &crdtLmtData, 
            sizeof(SbfCcpCrdtLimitDataRefT));
    RAISE_ERR(rc, RTN);
    
    InitRspDat(pNewOrdrRsp);
    rc = MtchrPrcsFreezeOrgClsPosnOrdrBySet(pReq->msgHdr.setId, pOrgInfo->orgId, 
            timestamp, pNewOrdrRsp);
    RAISE_ERR( rc, RTN );

    rc = MtchrCreateOrdrFromOrdrInfo(pReq->msgHdr.setId, &pNewOrdrReq->newOrdrInfo, 
            &pOrderReq, FALSE, NULL);
    RAISE_ERR( rc, RTN );

    rc = MtchrPrcsOrdrAdd(FALSE, TRUE, pReq->msgHdr.setId, pPrdctInfo, pOrderReq, 
            timestamp, pNewOrdrRsp, &mtchInfo);
    RAISE_ERR( rc, RTN );
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SbfCcpOrdrCancelByQss(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "SbfCcpOrdrCancelByQss" );
    ResCodeT                    rc = NO_ERR;
    SbfCcpOrdrCancelByCwReqT    *pOrdrCancelReq = NULL; 
    SbfCcpOrdrCancelByCwRespT   *pOrdrCancelResp = NULL; 
    SbfCcpCrdtLimitDataRefT     ordrCancelDataRef;
    OrderCancelRequestReqT      *pOrderMsg = NULL; 
    int32                       v_OutOrgId;
    char                        sysUptDateStr[MAX_TIME_LEN];
    pUsrBaseInfoT               pUsr =NULL;
    pOrgInfoT                   pOrgInfo = NULL;
    int32                       orgId;
    
    memset(&ordrCancelDataRef, 0x00, sizeof(SbfCcpCrdtLimitDataRefT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));

    pOrdrCancelReq  = (SbfCcpOrdrCancelByCwReqT*)&pReq->msgBody[0];
    pOrdrCancelResp = (SbfCcpOrdrCancelByCwRespT*)&pRsp->msgBody[0];
    pOrderMsg = (OrderCancelRequestReqT*)&pOrdrCancelReq->orderCnclReq;
    pOrdrCancelResp->orgIdx = pOrderMsg->orgIdx;
    
    rc = OrgInfoGetByPosExt(pOrdrCancelReq->orderCnclReq.orgIdx, &pOrgInfo);
    RAISE_ERR( rc, RTN );

    rc = IrsUsrInfoGetByPosExt(pOrderMsg->userIdx, &pUsr);
    RAISE_ERR( rc, RTN );

    if (pReq->msgHdr.setId == SET_MKT_SBFCCP)
    {
        rc = SbfCcpCommonChk(pUsr->usrLgnNm, pOrgInfo->orgId, C_ORDCANCEL_FUNCID, 
                pOrderMsg->token, &orgId);
        RAISE_ERR( rc, RTN );
    }

    InitRspDat(&pOrdrCancelResp->orderRsp );

    rc = MtchrPrcsCnclClsPosnOrgOrdrBySet(pReq->msgHdr.setId, pOrgInfo->orgId, 
           timestamp, &pOrdrCancelResp->orderRsp);
    RAISE_ERR(rc, RTN);
    
    ordrCancelDataRef.intOrgId = pOrgInfo->orgId;

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORDRCNCL_BYCW_DAT, &ordrCancelDataRef, 
            sizeof(SbfCcpCrdtLimitDataRefT));
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

