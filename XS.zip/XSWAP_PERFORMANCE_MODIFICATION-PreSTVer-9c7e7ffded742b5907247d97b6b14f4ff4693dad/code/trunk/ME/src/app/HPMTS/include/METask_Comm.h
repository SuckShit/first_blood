/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef METASK_COMM_H
#define METASK_COMM_H

#include "internal_function_def.h"
#include "err_lib.h"
#include "METask_Login.h"
#include "login.h"
#include "user_order.h"
#include "XAPIPbMessage.pb.h"
#include "IMIX20/Component/PartyDetailGrp.h"
#include "msg_timer.h"
#include "../service/credit_risk.h"
#include "msg_risk.h"
#include "msg_setlprc.h"
#include "msg_market_info_update.h"
#include "msg_common_value.h"
#include "msg_credit_position_sbfccp.h"

using namespace IMIX20;

typedef struct CreditRiskMsgRespS {
    char strUserId[MAX_USR_ID_LENTH];
    char strOrgId[MAX_ORG_ID_LENTH];
    char strDesc[MAX_MSG_LENTH];
    char strUpdTime[MAX_TIME_LENGTH];
} CreditRiskMsgRespT, *pCreditRiskMsgRespT;


//ResCodeT InitReqMsg();
ResCodeT ResrveReqMsg(IMIX::BasicMessage*  pMsg, ImixHdrT* pImixHdr);
//ResCodeT GetReqMsg(uint16 reqMessageIdx, IMIX::BasicMessage* pMessage);
//ResCodeT ReleaseReqMsg(uint16 index);
ResCodeT ExecInstConvert(IRS_STRING execInst, int32* pExecInst);
ResCodeT SideConvert(char cSide, int16* pSide);
ResCodeT SideConvertByCw(string sSide, int16* pSide);
ResCodeT OrderTypeConvert(char ordType, int32* pOrdType);

ResCodeT ResponeExceptionMsg(SENDMSGLIST* pSendMsgList, IMIX::BasicMessage* pRspMessage, int nExceptionFlag);
ResCodeT SendMessage(SENDMSGLIST* pSendMsgList, IMIX::BasicMessage* pMsg, string log_description="");
void ClearSendMsgList(SENDMSGLIST* pSendMsgList);
ResCodeT GetApplRefSeqNum(ImixHdrT* pImixHdr, int32* pApplRefSeqNum);
ResCodeT SetRespMsgHeader(ImixHdrT* pImixHdr, IMIX::BasicMessage* pRspMessage);

ResCodeT SendLoginRespMsg(IMIX20::UserResponse* pRspMessage, UserLoginRespT* pRsp, SENDMSGLIST* pSendMsgList);
ResCodeT SendOrdrDealStsUpdtMsgToTrdr(IRS_STRING strCompId, SlotT * pSlotList, int32 slotCnt, SENDMSGLIST* pSendMsgList);
//ResCodeT SendOrderStatusUpdateMsgToTrader(IRS_STRING strCompId, OrderInfoT* pOrders, int32 orderCnt, SENDMSGLIST* pSendMsgList);
//
//ResCodeT SendDealMsgToTrader(IRS_STRING strCompId, DealInfoT* pDeals, int32 rspDealCnt, SENDMSGLIST* pSendMsgList);

ResCodeT GetErrCodeMsg(ResCodeT inRc, IRS_STRING& strErrCode, IRS_STRING& strErrMsg);

ResCodeT CnvtPriceToImixVal(int64 iPrice, IRS_STRING& strPrice);
ResCodeT CnvtPriceToIntnlVal(IRS_STRING strPrice, int64 * pPrice );
ResCodeT FmtOrderStatusFromOrderInfo(IRS_STRING strCompId, OrderInfoT* pOrderInfo, ExecutionReport* pOrderStatusMsg);

ResCodeT SendMsgToGatewayStop(IntrnlMsgT* pRsp, SENDMSGLIST* pOutImixMsg);
ResCodeT MakeMsgToGateway(int32 seqNum, int32 buffLen, char* pBuff, IMIX20::QueryResult* pRspMessage);

ResCodeT SendMsgToTDPS(IntrnlMsgT* pRsp, SENDMSGLIST* pOutImixMsg);
ResCodeT MakeMsgToTDPS(int32 seqNum, int32 buffLen, char* pBuff, IMIX20::QueryResult* pRspMessage);
ResCodeT AnalyzeMassMessage(IMIX20::DataSet inMsg, DATASET_HEADER_DATA& headerData, vector<IMIX::BasicMessage>& vectSubMsg);

OCO_CHECKBOX GetOcoCheckBox(DataSet& message);

// credit_update
void SendCreditUpdReportMsgToTrader(IRS_STRING strCompId, pCreditRiskMsgRespT pMsgResp, SENDMSGLIST* pSendMsgList);
void SendFreezeStatusNotifyMsgToTrader(IRS_STRING strCompId, pCreditRiskMsgRespT pMsgResp, SENDMSGLIST* pSendMsgList);

ResCodeT SendBilNoteUsrMsgToTrader(IRS_STRING strCompId, BilNoteUsrT* pBilUsr, int32 rspUsrCnt, SENDMSGLIST* pSendMsgList);
ResCodeT SendFreezeStatusNotifyMsgToTrader(IRS_STRING strCompId, RiskInfoRespT* pRiskRsp , SENDMSGLIST* pSendMsgList);
ResCodeT SendMktStatusToOnlineUser(IRS_STRING strCompId, pMarketInfoUpdateRespT pMktRsp, SENDMSGLIST* pSendMsgList);
void GetPriceXMLContent(const string& src, pSetlPrcModifyReqT pSetlPrc);
ResCodeT SendClsPosnOrdrDealStsUpdtMsgToTrdr(int64 forceId, uint32 orgIdx, IRS_STRING strCompId, SlotT * pSlotList, int32 slotCnt, SENDMSGLIST* pSendMsgList);
#endif
