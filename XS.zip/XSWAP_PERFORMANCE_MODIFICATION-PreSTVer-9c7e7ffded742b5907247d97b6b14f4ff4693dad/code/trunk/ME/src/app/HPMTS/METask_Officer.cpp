/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "METask_Officer.h"
#include "METask_Comm.h"
#include "irs_code_convert.h"
#include "internal_function_def.h"
#include "internal_base_def.h"
#include "msg_base_param_update.h"
#include "msg_credit.h"
#include "msg_risk.h"
#include "common_macro.h"
#include "uti_tool.h"
#include "pck_irs_dicdata.h"

using namespace IMIX;
using namespace IMIX20;

/*========================================================
* Start处理函数实现
=========================================================*/
// 基本参数设置
ResCodeT OnBaseParamUpdateStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBaseParamUpdateStart");
    ResCodeT rc = NO_ERR;

    BaseParamUpdateReqT *pBaseParamMsg;
    int nRet = APP_CODE_SUCCESS;

    Instrument* pInstrument;
    MarketSegmentGrp* pMarketSegmentGrp;

    //功能标识
    IRS_STRING strFuncId = "";
    //用户ID
    IRS_STRING strUserId = "";
    //Tocken
    IRS_STRING strToken = "";
    //行情展示档位
    IRS_STRING strMarketDepth = "";
    //距盘中价报价点差限制
    IRS_STRING strPriceSpreadLimit = "";
    //1.5.1.1 add 每日结算利率报价点差利率
    IRS_STRING strDayStlPrice = "";
    //1.6.0.0 add SBF市场每日结算利率报价点差利率
    IRS_STRING strSBFDayStlPrice = "";
    //1.6.0.0 add SIRSCCP市场每日结算利率报价点差利率
    IRS_STRING strSIRSCCPDayStlPrice = "";
    //1.6.0.0 add SBFCCP市场每日结算利率报价点差利率
    IRS_STRING strSBFCCPDayStlPrice = "";
    //OCO包含订单最大值
    IRS_STRING strOCOMaxLimit = "";
    //OCO包含订单最小值
    IRS_STRING strOCOMinLimit = "";
    //有效授信限额
    IRS_STRING strEffectAmount = "";
    //有效授信参考合约
    IRS_STRING strEffectContract = "";
    //OCO篮子最大个数
    IRS_STRING strOCOMaxNum = "";
    //授信机构数
    IRS_STRING strCreditNum = "";
    //双边订单提醒频率
    IRS_STRING strCapPrice = "";
    //桥频率
    IRS_STRING strBrdgFreq = "3";
    //采样频率
    IRS_STRING strRate = "";
    //最大价差
    IRS_STRING strMaxPrc = "";
    
    BASE_PARAM baseParam;
    int nMarketDepth = 0;
    int nPos;
    string DayStlPrice1;
    string DayStlPrice2;
    
    // 消息解析
    SecurityDefinition message;
    
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                获取消息字段
    *************************************/
        
    strBrdgFreq = message.GetCurrency();
    strRate = message.GetFloorPrice();
    strMaxPrc = message.GetCountryOfIssue();
    
    strToken = message.GetApplToken();

    //获取用户ID
    pInstrument = message.GetInstrument();
    strUserId = GetInstrumentPartyId(pInstrument, E_INSTRUMENT_PARTY_ROLE_USER);
    if ("" == strUserId)
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get user failed.");
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pMarketSegmentGrp = message.GetMarketSegmentGrp();
    
    
    if (APP_CODE_SUCCESS != GetBaseParameters(pMarketSegmentGrp, baseParam))
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get base parameters error.");
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }    

    strOCOMaxLimit = baseParam.m_sOcoMaxOrderNum;
    strOCOMinLimit = baseParam.m_sOcoMinOrderNum;
    strOCOMaxNum = baseParam.m_sOcoMaxNum;

    // 距盘中报价点差限制和每日结算利率报价点差限制放在一个字段里，以&符号连接

    nPos = baseParam.m_sMaxPriceVariation.find("&");
    strPriceSpreadLimit = baseParam.m_sMaxPriceVariation.substr(0, nPos);
    DayStlPrice1 = baseParam.m_sMaxPriceVariation.substr(nPos + 1, baseParam.m_sMaxPriceVariation.size() - nPos - 1);
    nPos = DayStlPrice1.find("&");
    strDayStlPrice = DayStlPrice1.substr(0, nPos);
    DayStlPrice2 = DayStlPrice1.substr(nPos + 1, DayStlPrice1.size() - nPos - 1);
    nPos = DayStlPrice2.find("&");
    strSBFDayStlPrice = DayStlPrice2.substr(0, nPos);
    strSBFCCPDayStlPrice = DayStlPrice2.substr(nPos + 1, DayStlPrice2.size() - nPos - 1);

    strCreditNum = baseParam.m_sCreditNum;


    //获取有效额度
    strEffectAmount = GetLastLimitAmt(pMarketSegmentGrp, E_LIMITAMT_TYPE_CREDIT_AMT, E_LIMITAMT_SUBTP_EFFECT_AMT);
    if ("" == strEffectAmount)
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get effect Amount failed.");
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //获取市场行情档位
    
    if (APP_CODE_SUCCESS == GetMarketDepth(pMarketSegmentGrp, nMarketDepth))
    {
        IntToString(nMarketDepth, strMarketDepth);        
    }
    else
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get market depth failed.");
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strEffectContract = message.GetSecurityID();
    strCapPrice = message.GetCapPrice();
        

    pBaseParamMsg = (BaseParamUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(BaseParamUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_BASE_PARAM_UPDATE;
    
    pBaseParamMsg->intFuncId = FUNC_ID_PARAM_UPDATE;
    strcpy(pBaseParamMsg->strUserId, strUserId.c_str());
    strcpy(pBaseParamMsg->strToken, strToken.c_str());
    strcpy(pBaseParamMsg->strMrktStallsLvl, strMarketDepth.c_str());
    strcpy(pBaseParamMsg->strPrcSpreadLmt, strPriceSpreadLimit.c_str());
    strcpy(pBaseParamMsg->strSetmntPrcSirs, strDayStlPrice.c_str());
    strcpy(pBaseParamMsg->strSetmntPrcSbf, strSBFDayStlPrice.c_str());
    strcpy(pBaseParamMsg->strOcoMaxNumLmt, strOCOMaxLimit.c_str());
    strcpy(pBaseParamMsg->strOcoMinNumLmt, strOCOMinLimit.c_str());
    strcpy(pBaseParamMsg->strEffCreditAmtLmt, strEffectAmount.c_str());
    strcpy(pBaseParamMsg->strEffCreditCntrct, strEffectContract.c_str());
    strcpy(pBaseParamMsg->strOcoMaxNum, strOCOMaxNum.c_str());
    strcpy(pBaseParamMsg->strMinCreditOrgNum, strCreditNum.c_str());
    strcpy(pBaseParamMsg->strBrdgSqnc, strBrdgFreq.c_str());
    strcpy(pBaseParamMsg->strSetmntPrcSbfccp, strSBFCCPDayStlPrice.c_str());
    strcpy(pBaseParamMsg->strBilNtfSqnc, strCapPrice.c_str());
    strcpy(pBaseParamMsg->strOrdrStatInterval, strRate.c_str());
    strcpy(pBaseParamMsg->strOrdrDifference, strMaxPrc.c_str());
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE; 
}


ResCodeT OnBaseParamUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBaseParamUpdateStop");
    ResCodeT rc = NO_ERR;
    int32 applRefSeqNum;
    
    /*---------------------------------------
    **********    临时变量 ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    
    // 定义应答消息
    SecurityDefinition* pRspMessage = new SecurityDefinition;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);
    
    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    // 设置应答的结果码和结果描述信息，发送应答消息    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);    

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 授信和风险系数修改
ResCodeT OnCreditAndRiskModifyStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq
)
{
    BEGIN_FUNCTION("OnCreditAndRiskModifyStart");
    ResCodeT rc = NO_ERR;
    //用户ID
    IRS_STRING strUserId = "";
    //Token
    IRS_STRING strToken = "";
    //机构标识
    IRS_STRING strOrgId = "";
    //Message
    CreditRiskModifyReqT *pCreditRiskModifyMsg = NULL;
    PARTY_RISK_LMT_DEF_REQ msgAnalyzeData;

    // 消息解析
    PartyRiskLimitsDefinitionRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    if (APP_CODE_SUCCESS != Analyze_PartyRiskLimitsDefinitionRequest(message, msgAnalyzeData)) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    
    //用户ID
    strUserId = msgAnalyzeData.m_sUser;
    //Token
    strToken = msgAnalyzeData.m_sToken;
    //机构标识
    strOrgId = msgAnalyzeData.m_sOrgId;    

    pCreditRiskModifyMsg = (CreditRiskModifyReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(CreditRiskModifyReqT);
    pReq->msgHdr.msgType = MSG_TYPE_CREDIT_MODIFY;
    
    pCreditRiskModifyMsg->iFuncId = FUNC_ID_CREDIT_RISK_MODIFY;          //机能标识
    strcpy(pCreditRiskModifyMsg->strUserId, strUserId.c_str());          //用户标识
    strcpy(pCreditRiskModifyMsg->strToken,  strToken.c_str());           //Token
    strcpy(pCreditRiskModifyMsg->strOrgId,  strOrgId.c_str());           //机构代码
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnCreditAndRiskModifyStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag
)
{
    BEGIN_FUNCTION("OnCreditAndRiskModifyStop");
    ResCodeT rc = NO_ERR;

    CreditRiskModifyRespT *pCreditRiskModifyResp;
    CreditRiskMsgRespT crdtMsgResp;
    /*---------------------------------------
    **********    临时变量 ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // 定义应答消息
    PartyRiskLimitsReport* pRspMessage = new PartyRiskLimitsReport();
    int32 applRefSeqNum = 0;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    pRspMessage->SetApplToken("----");

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    else{
        pCreditRiskModifyResp = (CreditRiskModifyRespT*)pRsp->msgBody;
        
        
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pCreditRiskModifyResp->orderRsp.rspSlot,  
                                                    pCreditRiskModifyResp->orderRsp.slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);   
    }

    //授信更新通知到前台用户
    memset(&crdtMsgResp, 0x00, sizeof(CreditRiskMsgRespT));
    strcpy(crdtMsgResp.strUserId,  pCreditRiskModifyResp->strUserId);
    strcpy(crdtMsgResp.strOrgId,   pCreditRiskModifyResp->strOrgId);
    strcpy(crdtMsgResp.strDesc,    MSG_ORG_CREDIT_MODIFING);
    strcpy(crdtMsgResp.strUpdTime, pCreditRiskModifyResp->strUpdTime);

    SendFreezeStatusNotifyMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), &crdtMsgResp, pSendMsgList);

//    if (SP_RET_SUCCESS == oRetParam.m_nErrorCode) {    
//        int nOutBoundId = oRetParam.m_nOutBoundId;
//        SendFreezeStatusNotifyMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecFreezeInfo, pSendMsgList);
//        SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

//        SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
//        SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

//        SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SBF_vecOrders, pSendMsgList);
//        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
//        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
//        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SBF_vecOrders, nOutBoundId, pSendMsgList, pParamList);
//        SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
//        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);
//
//        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
//    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 授信更新
ResCodeT OnCreditUpdateStart(
    vector<IMIX::BasicMessage> inVectMsg,
    IntrnlMsgT* pReq,
    IMIX20::DataSet& orginMessage)
{
    BEGIN_FUNCTION("OnCreditUpdateStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnCreditUpdateStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    CreditUpdateReqT *pCreditUpdateMsg = NULL;
    PartyRiskLimitsDefinitionRequest message;
    PARTY_RISK_LMT_DEF_REQ msgAnalyzeData;
    int32 nIndex;
    bool bRet;

    IRS_STRING strUserId;                   // 用户ID
    IRS_STRING strToken;                    // Token
    IRS_STRING strOrgId;                    // 机构标识
    IRS_STRING strCrdtMethod;               // 授信方式
    IRS_STRING strCrdtOrgId;                // 被授信机构标识
    IRS_STRING strNoRelaOrgId;              // 授信无关机构标识
    IRS_STRING strAmt;                      // 初始授信额度
    IRS_STRING strUsedAmt;                  // 已使用授信额度
    IRS_STRING strRemainAmt;                // 剩余授信额度
    IRS_STRING strCrdtTerm;                 // 最长年限
    IRS_STRING strCrdtRelationId;           // 授信标识

    pCreditUpdateMsg = (CreditUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(CreditUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_CREDIT_UPDATE;
    
    // 消息解析
    for (nIndex = 0; nIndex < inVectMsg.size(); nIndex++) {
        bRet = message.crack(const_cast<IMIX::BasicMessage&>(inVectMsg[nIndex]));
        if (!bRet) {
            LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
            return APP_CODE_INCOM_MSG_INVALID;
        }

        /************************************
                    获取消息字段
        *************************************/
        msgAnalyzeData.m_sModifyOrgId = "";
        msgAnalyzeData.m_sNoRelaOrgId = "";
        if (APP_CODE_SUCCESS != Analyze_PartyRiskLimitsDefinitionRequest(message, msgAnalyzeData)) {
            LOG_ERROR(APP_CODE_ANALYZE_IMIXMSG_ERR, APP_MSG_ANALYZE_IMIXMSG_ERR);
            return APP_CODE_ANALYZE_IMIXMSG_ERR;
        }
        
        //用户ID
        strUserId = msgAnalyzeData.m_sUser;
        //Token
        strToken = msgAnalyzeData.m_sToken;
        //机构标识
        strOrgId = msgAnalyzeData.m_sOrgId;
        //授信方式
        strCrdtMethod = "";
        IntToString(ImixToIrs_CreditMethod(msgAnalyzeData.m_nCrdtType), strCrdtMethod);
        //被授信机构标识
        strCrdtOrgId = msgAnalyzeData.m_sModifyOrgId;
        //授信无关机构标识
        strNoRelaOrgId = msgAnalyzeData.m_sNoRelaOrgId;
        //初始授信额度
        strAmt = msgAnalyzeData.m_sInitCrdtAmt;
        //已使用授信额度
        strUsedAmt = msgAnalyzeData.m_sUsedCrdtAmt;
        //剩余授信额度
        strRemainAmt = msgAnalyzeData.m_sRemainCrdtAmt;
        //最长年限
        strCrdtTerm = msgAnalyzeData.m_sCrdtTerm;
        //授信标识
        strCrdtRelationId = "";
        if ("" != strNoRelaOrgId) {
            // 如果无关被授信机构不为空，则为无关系授信
            strCrdtRelationId = E_CREDIT_RELA_NO;
            strCrdtOrgId = strNoRelaOrgId;
        }
        else if ("" != strCrdtOrgId) {
            // 如果被授信机构不为空，则为有关系授信
            strCrdtRelationId = E_CREDIT_RELA_YES;
        }
        else {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%d Get credit relation error.", FUNC_ID_CREDIT_UPDATE);
        }

        // 输入信息打印日志打印
        LOG_INFO("[%d]In condition: strUserId = %s, strToken = %s, strOrgId = %s, strCrdtMethod = %s, strCrdtOrgId = %s, strAmt = %s, strCrdtTerm = %s, strCrdtRelationId = %s",
                    FUNC_ID_CREDIT_UPDATE, strUserId.c_str(), strToken.c_str(), strOrgId.c_str(), strCrdtMethod.c_str(), strCrdtOrgId.c_str(), strAmt.c_str(), strCrdtTerm.c_str(), strCrdtRelationId.c_str());

        // SP入参
        pCreditUpdateMsg->iFuncId = FUNC_ID_CREDIT_UPDATE;                          // 机能标识
        strcpy(pCreditUpdateMsg->strUserId, strUserId.c_str());                     // 用户标识
        strcpy(pCreditUpdateMsg->strToken,  strToken.c_str());                      // Token
        strcpy(pCreditUpdateMsg->strOrgId,  strOrgId.c_str());                      // 授信机构标识
        pCreditUpdateMsg->iCrdtMthd = atoi(strCrdtMethod.c_str());                  // 授信方式

        pCreditUpdateMsg->iCrdtedOrgIdLst[nIndex] = atoi(strCrdtOrgId.c_str());     // 被授信机构标识
        pCreditUpdateMsg->iIntlCrdtAmntLst[nIndex] = StringToInt64(strAmt.c_str()); // 初始授信额度
        pCreditUpdateMsg->iCrdtTermLst[nIndex] = atoi(strCrdtTerm.c_str());         // 最长期限
        pCreditUpdateMsg->iCrdtRlfLst[nIndex] = atoi(strCrdtRelationId.c_str());    // 授信关系标识
    }
    pCreditUpdateMsg->iCrdtCount = nIndex;

    //reserve message header
    rc = ResrveReqMsg(&orginMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("%s End..", sFunction.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnCreditUpdateStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag)
{
    BEGIN_FUNCTION("OnCreditUpdateStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnCreditUpdateStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    CreditUpdateRespT *pCreditUpdateResp;
    CreditRiskMsgRespT crdtMsgResp;
    /*---------------------------------------
    **********    临时变量 ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // 定义应答消息
    PartyRiskLimitsReport* pRspMessage = new PartyRiskLimitsReport();
    int32 applRefSeqNum = 0;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    pRspMessage->SetApplToken("----");

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);

    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    else {
        pCreditUpdateResp = (CreditUpdateRespT*)pRsp->msgBody;
        if (C_ORG_CRT_USELESS == pCreditUpdateResp->iResult) {
            strErrMsg = MSG_ORG_CREDIT_USELESS;
        }
        else if (C_ORG_CRT_USEFULL == pCreditUpdateResp->iResult) {
            strErrMsg = MSG_ORG_CREDIT_USEFULL;
        }
        else {
        }

        pRspMessage->SetApplErrorDesc(strErrMsg);
        SendMessage(pSendMsgList, pRspMessage);
    }
    //授信更新通知到前台用户
    memset(&crdtMsgResp, 0x00, sizeof(CreditRiskMsgRespT));
    strcpy(crdtMsgResp.strUserId,  pCreditUpdateResp->strUserId);
    strcpy(crdtMsgResp.strOrgId,   pCreditUpdateResp->strOrgId);
    strcpy(crdtMsgResp.strUpdTime, pCreditUpdateResp->strUpdTime);
    strcpy(crdtMsgResp.strDesc, MSG_ORG_CREDIT_MODIFIED);
    SendCreditUpdReportMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), &crdtMsgResp, pSendMsgList);

//    // 发送其他的消息
//    if (SP_RET_SUCCESS == oRetUnlockParam.m_nErrorCode ||
//        SP_RET_CREDIT_LESS == oRetUnlockParam.m_nErrorCode)
//    {
//        int nOutBoundId = oRetUnlockParam.m_nOutBoundId;
//        //授信更新通知到前台用户
//        SendCreditUpdReportMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecFreezeInfo, pSendMsgList);
//        //授信更新通知消息到TDPS
//        SendCreditUpdReportMsgToTDPS(oRetParamRst.m_vecCredit, oRetUnlockParam.m_sCreditMethd, nOutBoundId, pSendMsgList, pParamList);
//        SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
//    }
    
    LOG_DEBUG("%s End..", sFunction.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnUnlockCreditStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq
)
{
    BEGIN_FUNCTION("OnUnlockCreditStart");
    ResCodeT rc = NO_ERR;

    CreditUnlockReqT *pCreditUnlockMsg = NULL;
    // 消息解析
    PartyRiskLimitsDefinitionRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }
    LOG_INFO("Req message string: %s", message.ToString().c_str());
    /************************************
                获取消息字段
    *************************************/
    //用户标识
    IRS_STRING strUserId = "";
    //Token
    IRS_STRING strToken = "";
    //机构标识    
    IRS_STRING strOrgId = "";
    //检查机构有效性标识
    IRS_STRING strCheckOrg = "";
    char cCheckOrg = '\0';

    strToken = message.GetApplToken();
    
    RequestingPartyGrp * pRequestingPartyGrp = message.GetRequestingPartyGrp();
    if (pRequestingPartyGrp != NULL) {
        int nSize = pRequestingPartyGrp->GetNoRequestingPartyIDs_Num();
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nSize+IMIX_GRP_INDEX_BEGIN; ++nIndex) {
            RequestingPartyGrp::NoRequestingPartyIDs * pNoRequestingPartyIDs = pRequestingPartyGrp->GetNoRequestingPartyIDs(nIndex);
            if (pNoRequestingPartyIDs != NULL) {
                if (pNoRequestingPartyIDs->GetRequestingPartyRole() == E_PARTY_DETAIL_ROLE_USER) {
                    strUserId = pNoRequestingPartyIDs->GetRequestingPartyID();
                }
            }
        }
    }    

    PartyRiskLimitsUpdateGrp * pPartyRiskLimitsUpdateGrp = message.GetPartyRiskLimitsUpdateGrp();
    if (pPartyRiskLimitsUpdateGrp != NULL) {
        PartyRiskLimitsUpdateGrp::NoPartyRiskLimits * pNoPartyRiskLimits = pPartyRiskLimitsUpdateGrp->GetNoPartyRiskLimits();
        if (pNoPartyRiskLimits != NULL) {
            PartyDetailGrp * pPartyDetailGrp = pNoPartyRiskLimits->GetPartyDetailGrp();
            if (pPartyDetailGrp != NULL) {
                PartyDetailGrp::NoPartyDetails * pNoPartyDetails = pPartyDetailGrp->GetNoPartyDetails();
                if (pNoPartyDetails != NULL) {
                    if (pNoPartyDetails->GetPartyDetailRole() == E_PARTY_DETAIL_ROLE_MODIFY_ORG) {
                        strOrgId = pNoPartyDetails->GetPartyDetailID();
                    }
                }
            }

            //获取是否检查机构有效标识位
            cCheckOrg = pNoPartyRiskLimits->GetListUpdateAction();
            if ('C' == cCheckOrg) {
                strCheckOrg = "0";
            }
            else if ('D' == cCheckOrg) {
                strCheckOrg = "1";
            }
        }
    }
    
    // 输入信息打印日志打印
    LOG_INFO("In condition: strUserId = %s,strToken = %s,strOrgId = %s,strCheckOrg=%s",
            strUserId.c_str(), strToken.c_str(), strOrgId.c_str(), strCheckOrg.c_str());

    pCreditUnlockMsg = (CreditUnlockReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(CreditUnlockReqT);
    pReq->msgHdr.msgType = MSG_TYPE_CREDIT_UNLOCK;
    
    // SP入参
    pCreditUnlockMsg->iFuncId = FUNC_ID_UNLOCK_CREDIT;                //机能标识
    strcpy(pCreditUnlockMsg->strUserId, strUserId.c_str());            //用户标识
    strcpy(pCreditUnlockMsg->strToken,  strToken.c_str());            //Token
    strcpy(pCreditUnlockMsg->strOrgId,  strOrgId.c_str());            //机构标识
    pCreditUnlockMsg->iCheckOrg = atoi(strCheckOrg.c_str());        //检查机构有效性标识

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnUnlockCreditStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag
)
{
    BEGIN_FUNCTION("OnUnlockCreditStop");
    ResCodeT rc = NO_ERR;

    CreditUnlockRespT *pCreditUnlockResp;
    CreditRiskMsgRespT crdtMsgResp;
    /*---------------------------------------
    **********    临时变量 ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // 定义应答消息
    PartyRiskLimitsReport* pRspMessage = new PartyRiskLimitsReport();
    int32 applRefSeqNum = 0;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    pRspMessage->SetApplToken("----");

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    // 设置应答的结果码和结果描述信息，发送应答消息
    pRspMessage->SetApplErrorCode(strErrCode);

    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    else {
        pCreditUnlockResp = (CreditUnlockRespT*)pRsp->msgBody;

        if (C_ORG_CRT_USELESS == pCreditUnlockResp->iResult) {
            strErrMsg = MSG_ORG_CREDIT_USELESS;
        }
        else if (C_ORG_CRT_USEFULL == pCreditUnlockResp->iResult) {
            strErrMsg = MSG_ORG_CREDIT_USEFULL;
        }
        else {
        }

        pRspMessage->SetApplErrorDesc(strErrMsg);
        SendMessage(pSendMsgList, pRspMessage);
    }

    //授信更新通知到前台用户
    memset(&crdtMsgResp, 0x00, sizeof(CreditRiskMsgRespT));
    strcpy(crdtMsgResp.strUserId,  pCreditUnlockResp->strUserId);
    strcpy(crdtMsgResp.strOrgId,   pCreditUnlockResp->strOrgId);
    strcpy(crdtMsgResp.strDesc,    MSG_ORG_CREDIT_MODIFIED);
    strcpy(crdtMsgResp.strUpdTime, pCreditUnlockResp->strUpdTime);

    SendFreezeStatusNotifyMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), &crdtMsgResp, pSendMsgList);

    //发送授信/风险系数更新完成通知给GUI
//    if ((oRetParam.m_nErrorCode == APP_CODE_SUCCESS) || 
//        (SP_RET_CREDIT_LESS == oRetParam.m_nErrorCode)) {
//        SendFreezeStatusNotifyMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecFreezeInfo, pSendMsgList);
//    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
   
ResCodeT OnRiskCoefUpdateStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnRiskCoefUpdateStart");
    ResCodeT        rc = NO_ERR;
    RiskInfoReqT *pRiskInfoMsg = NULL;
    PARTY_RISK_LMT_DEF_REQ msgAnalyzeData;
    vector<IMIX::BasicMessage> inVectMsg;
    DATASET_HEADER_DATA header;
    PartyRiskLimitsDefinitionRequest message;
    DataSet         srcMessage;
    int32           nIndex;
    bool            bRet;
    
    IRS_STRING      strUserId;  
    IRS_STRING      strToken;
    IRS_STRING      strOrgId;
    IRS_STRING      strContractId;
    IRS_STRING      strRiskCofCnt;
    
    pRiskInfoMsg           = (RiskInfoReqT*)&pReq->msgBody[0];
    
    pReq->msgHdr.msgType = MSG_TYPE_RISK_UPDATE;
    if (SET_MKT_IRS == pReq->msgHdr.setId)
    {
        pRiskInfoMsg->iFuncId = FUNC_ID_RISK_UPDATE;
    }
    else if (SET_MKT_SIRS == pReq->msgHdr.setId)
    {
        pRiskInfoMsg->iFuncId = FUNC_ID_SIRS_RISK_UPDATE;
    }
    else
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }


    bRet = srcMessage.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    rc = AnalyzeMassMessage(srcMessage, header, inVectMsg);
    RAISE_ERR(rc, RTN); 

    for (nIndex = 0; nIndex < inVectMsg.size(); nIndex++) 
    {
        bRet = message.crack(const_cast<IMIX::BasicMessage&>(inVectMsg[nIndex]));
        if (!bRet) 
        {
            RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
        }

        if (APP_CODE_SUCCESS != Analyze_PartyRiskLimitsDefinitionRequest(message, msgAnalyzeData)) 
        {
            RAISE_ERR(APP_CODE_ANALYZE_IMIXMSG_ERR, RTN);
        }
        
        if (0 == nIndex)
        {
            strUserId       = msgAnalyzeData.m_sUser;      
            strToken        = msgAnalyzeData.m_sToken;    
            strOrgId        = msgAnalyzeData.m_sModifyOrgId;
    
            memcpy(pRiskInfoMsg->strUserId, strUserId.c_str(), sizeof(pRiskInfoMsg->strUserId));
            memcpy(pRiskInfoMsg->strToken,  strToken.c_str(), sizeof(pRiskInfoMsg->strToken)); 
            memcpy(pRiskInfoMsg->strOrgId,  strOrgId.c_str(), sizeof(pRiskInfoMsg->strOrgId)); 
        }

        strContractId   = msgAnalyzeData.m_sContractId;
        strRiskCofCnt   = msgAnalyzeData.m_sRiskCof;

        memcpy(pRiskInfoMsg->riskCfcnt[nIndex].strCntrctNm, strContractId.c_str(), 
            sizeof(pRiskInfoMsg->riskCfcnt[nIndex].strCntrctNm));       

        CnvtPriceToIntnlVal(strRiskCofCnt.c_str(), 
            (int64 *)&pRiskInfoMsg->riskCfcnt[nIndex].intRiskCfcnt);

        LOG_INFO("[%d] In condition: strUserId = %s, strToken = %s, strOrgId = %s, strContractId = %s, strRiskCofCnt = %s",
                pRiskInfoMsg->iFuncId, strUserId.c_str(), strToken.c_str(), strOrgId.c_str(),
                strContractId.c_str(), strRiskCofCnt.c_str());
    }
    pRiskInfoMsg->iRiskCount = nIndex;
    pReq->msgHdr.msgLen = sizeof(RiskDataBaseT) + sizeof(int32) + nIndex*sizeof(RiskDataT);

    rc = ResrveReqMsg(&srcMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnRiskCoefUpdateStop(
    IntrnlMsgT*    pRsp,
    SENDMSGLIST*   pSendMsgList,
    int            nExceptionFlag)
{
    BEGIN_FUNCTION("OnRiskCoefUpdateStop");
    RiskInfoRespT*  pRiskCoefStop; 
    ResCodeT        rc = NO_ERR;
    char            strUpdTm[MAX_TIME_LENGTH] = {0};
    
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    PartyRiskLimitsReport* pRspMessage = new PartyRiskLimitsReport();   
    int32 applRefSeqNum = 0;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc)) 
    {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
        
    if (NO_ERR != nExceptionFlag)
    {
        IntToString(0, strErrCode);
    }
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
   
    rc = SendMessage(pSendMsgList, pRspMessage);   
    RAISE_ERR(rc, RTN);
    
    if (NO_ERR == nExceptionFlag || SP_RET_CREDIT_LESS == nExceptionFlag) 
    {
        pRiskCoefStop = (RiskInfoRespT*)pRsp->msgBody;
        rc = SendFreezeStatusNotifyMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), 
            pRiskCoefStop , pSendMsgList);
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}
