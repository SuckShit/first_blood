/***
Created on Aug 02, 2017
@author: Xiaoping Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "cfg_lib.h"
#include "db_comm.h"
#include "uti_tool.h"

#include "base_param.h"
#include "BaseParamDb.h"
#include "MktStCfgDb.h"
#include "base_param_update.h"
#include "msg_base_param_update.h"
#include "pck_irs_util.h"
#include "pck_irs_dicdata.h"
#include "ref_dat_updt.h"
#include "usr_def_ref.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : BaseParamUpdate
 **
 ******************************************************************************/
ResCodeT BaseParamUpdate(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp)
{
    BEGIN_FUNCTION( "BaseParamUpdate" );
    ResCodeT rc = NO_ERR;
    BaseParamUpdateReqT *pParamUptReq;
//	int32 minCrdtOrgNum;
//	int32 bilNtfSqnc;
//	int32 orgId;
//	BaseParamNameLst key;
//	BaseParamMulti data;
//	BaseParamUpdFlag flag;
//	char paramNameArray[BASE_PARAM_NUM][PARAM_NAME_LEN+1];
//	char paramValueArray[BASE_PARAM_NUM][PARAM_VALUE_LEN+1];
//	char updUsrArray[BASE_PARAM_NUM][UPDATE_USER_LEN+1];
//	pBaseParamT pBaseParamData;
//
//
//
//	pParamUptReq = (BaseParamUpdateReqT*)&pReq->msgBody[0];
//
//	minCrdtOrgNum = atoi(pParamUptReq->strMinCreditOrgNum);
//	bilNtfSqnc = atoi(pParamUptReq->strBilNtfSqnc);
//
//
//	/* 通用检查 */
//	rc = CommonChk(pParamUptReq->strUserId, C_ORG_NULL, pParamUptReq->intFuncId,
//	               pParamUptReq->strToken, &orgId);
//	RAISE_ERR(rc, RTN);
//
//	if (minCrdtOrgNum < 1){
//	    RAISE_ERR(ERR_CODE_INVLD_PARAM_CRDT_NUM, RTN);
//	}
//
//	if (minCrdtOrgNum > 11){
//	    RAISE_ERR(ERR_CODE_PARAM_CRDT_NUM_INVLD, RTN);
//	}
//
//	if (bilNtfSqnc > 1440 || bilNtfSqnc < 5){
//	    RAISE_ERR(ERR_CODE_INVLD_PARAM_CRDT_NUM, RTN);
//	}
//
//
//
//	/* Init the variables used to update the DB */
//	memset(&key, 0x00, sizeof(BaseParamNameLst));
//	memset(&data, 0x00, sizeof(BaseParamMulti));
//	memset(&flag, 0x00, sizeof(BaseParamUpdFlag));
//	memset(paramNameArray, 0x00, sizeof(paramNameArray));
//	memset(paramValueArray, 0x00, sizeof(paramValueArray));
//	memset(updUsrArray, 0x00, sizeof(updUsrArray));
//
//	/* 主体过程 */
//	/* First, update the values in the DB */
//
//	/* Set the update information */
//	/* 行情展示档位 */
//	strcpy(paramNameArray[0], C_MKTLVL);
//	strcpy(paramValueArray[0], pParamUptReq->strMrktStallsLvl);
//	strcpy(updUsrArray[0], pParamUptReq->strUserId);
//
//	/* IRS报价点差限制 */
//	strcpy(paramNameArray[1], C_PRCLMT);
//	strcpy(paramValueArray[1], pParamUptReq->strPrcSpreadLmt);
//	strcpy(updUsrArray[1], pParamUptReq->strUserId);
//
//	/* SIRS报价点差限制 */
//	strcpy(paramNameArray[2], C_CRT_SETMNTPRICE_SIRS);
//	strcpy(paramValueArray[2], pParamUptReq->strSetmntPrcSirs);
//	strcpy(updUsrArray[2], pParamUptReq->strUserId);
//
//	/* SBF报价点差限制 */
//	strcpy(paramNameArray[3], C_CRT_SETMNTPRICE_SBF);
//	strcpy(paramValueArray[3], pParamUptReq->strSetmntPrcSbf);
//	strcpy(updUsrArray[3], pParamUptReq->strUserId);
//
//	/* OCO最大订单数 */
//	strcpy(paramNameArray[4], C_OCO_ODR_MAX_LMT);
//	strcpy(paramValueArray[4], pParamUptReq->strOcoMaxNumLmt);
//	strcpy(updUsrArray[4], pParamUptReq->strUserId);
//
//	/* OCO最小订单数 */
//	strcpy(paramNameArray[5], C_OCO_ODR_MIN_LMT);
//	strcpy(paramValueArray[5], pParamUptReq->strOcoMinNumLmt);
//	strcpy(updUsrArray[5], pParamUptReq->strUserId);
//
//	/* 有效授信限额 */
//	strcpy(paramNameArray[6], C_CRT_LMT);
//	strcpy(paramValueArray[6], pParamUptReq->strEffCreditAmtLmt);
//	strcpy(updUsrArray[6], pParamUptReq->strUserId);
//
//	/* 有效授信参考合约 */
//	strcpy(paramNameArray[7], C_CRT_RFCCNTCT);
//	strcpy(paramValueArray[7], pParamUptReq->strEffCreditCntrct);
//	strcpy(updUsrArray[7], pParamUptReq->strUserId);
//
//	/* OCO篮子最大数额 */
//	strcpy(paramNameArray[8], C_OCO_MAX);
//	strcpy(paramValueArray[8], pParamUptReq->strOcoMaxNum);
//	strcpy(updUsrArray[8], pParamUptReq->strUserId);
//
//	/* 最低授信方数量 */
//	strcpy(paramNameArray[9], C_CRT_MINORGCOUNT);
//	strcpy(paramValueArray[9], pParamUptReq->strMinCreditOrgNum);
//	strcpy(updUsrArray[9], pParamUptReq->strUserId);
//
//	/* 搭桥频率 */
//	strcpy(paramNameArray[10], C_BRDG_BYPASSFREQUENCY);
//	strcpy(paramValueArray[10], pParamUptReq->strBrdgSqnc);
//	strcpy(updUsrArray[10], pParamUptReq->strUserId);
//
//	/* SBFCCP报价点差限制 */
//	strcpy(paramNameArray[11], C_CRT_SETMNTPRICE_SBFCCP);
//	strcpy(paramValueArray[11], pParamUptReq->strSetmntPrcSbfccp);
//	strcpy(updUsrArray[11], pParamUptReq->strUserId);
//
//	/* 双边订单提醒频率 */
//	strcpy(paramNameArray[12], C_BIL_NOTIFYFREQUENCY);
//	strcpy(paramValueArray[12], pParamUptReq->strBilNtfSqnc);
//	strcpy(updUsrArray[12], pParamUptReq->strUserId);
//
//	/* 报价次数统计时间间隔16:30前，单位：秒 */
//	strcpy(paramNameArray[13], C_ORDR_STAT_INTERVAL);
//	strcpy(paramValueArray[13], pParamUptReq->strOrdrStatInterval);
//	strcpy(updUsrArray[13], pParamUptReq->strUserId);
//
//	/* 价差阀值，单位：BP */
//	strcpy(paramNameArray[14], C_ORDR_DIFFERENCE);
//	strcpy(paramValueArray[14], pParamUptReq->strOrdrDifference);
//	strcpy(updUsrArray[14], pParamUptReq->strUserId);
//
//	// key information
//	key.keyRow = BASE_PARAM_NUM;
//	key.paramNmMaxSize = PARAM_NAME_LEN;
//	key.baseParamNameLst = (char**)paramNameArray;
//
//	// columns to be updated
//	data.dataRow = BASE_PARAM_NUM;
//	data.paramVlLst = (char**)paramValueArray;
//	data.paramVlMaxSize = PARAM_VALUE_LEN;
//	flag.bParamVl = TRUE;
//
//	data.updUsrNmLst = (char**)updUsrArray;
//	data.updUsrNmMaxSize = UPDATE_USER_LEN;
//	flag.bUpdUsrNm = TRUE;
//
//	flag.bUpdTm = TRUE;
//
//	// Update the table [BASE_PARAM].
//	rc = BatchUpdateBaseParamByName(connId, &key, &data, &flag, BASE_PARAM_UPD_COLUMN_NUM);
//	RAISE_ERR(rc, RTN);
//
//	rc = DbCmmnCommit(connId);
//	RAISE_ERR(rc, RTN);
//
//
//	/* Second, update the values in the shared memory */
//	/* 行情展示档位 */
//	rc = BaseParamGetByNameExt((char*)C_MKTLVL, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strMrktStallsLvl);
//
//	/* IRS报价点差限制 */
//	rc = BaseParamGetByNameExt((char*)C_PRCLMT, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strPrcSpreadLmt);
//
//	/* SIRS报价点差限制 */
//	rc = BaseParamGetByNameExt((char*)C_CRT_SETMNTPRICE_SIRS, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strSetmntPrcSirs);
//
//	/* SBF报价点差限制 */
//	rc = BaseParamGetByNameExt((char*)C_CRT_SETMNTPRICE_SBF, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strSetmntPrcSbf);
//
//	/* OCO最大订单数 */
//	rc = BaseParamGetByNameExt((char*)C_OCO_ODR_MAX_LMT, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strOcoMaxNumLmt);
//
//	/* OCO最小订单数 */
//	rc = BaseParamGetByNameExt((char*)C_OCO_ODR_MIN_LMT, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strOcoMinNumLmt);
//
//	/* 有效授信限额 */
//	rc = BaseParamGetByNameExt((char*)C_CRT_LMT, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strEffCreditAmtLmt);
//
//	/* 有效授信参考合约 */
//	rc = BaseParamGetByNameExt((char*)C_CRT_RFCCNTCT, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strEffCreditCntrct);
//
//	/* OCO篮子最大数额 */
//	rc = BaseParamGetByNameExt((char*)C_OCO_MAX, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strOcoMaxNum);
//
//	/* 最低授信方数量 */
//	rc = BaseParamGetByNameExt((char*)C_CRT_MINORGCOUNT, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strMinCreditOrgNum);
//
//	/* 搭桥频率 */
//	rc = BaseParamGetByNameExt((char*)C_BRDG_BYPASSFREQUENCY, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strBrdgSqnc);
//
//	/* SBFCCP报价点差限制 */
//	rc = BaseParamGetByNameExt((char*)C_CRT_SETMNTPRICE_SBFCCP, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strSetmntPrcSbfccp);
//
//	/* 双边订单提醒频率 */
//	rc = BaseParamGetByNameExt((char*)C_BIL_NOTIFYFREQUENCY, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strBilNtfSqnc);
//
//	/* 报价次数统计时间间隔16:30前，单位：秒 */
//	rc = BaseParamGetByNameExt((char*)C_ORDR_STAT_INTERVAL, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strOrdrStatInterval);
//
//	/* 价差阀值，单位：BP */
//	rc = BaseParamGetByNameExt((char*)C_ORDR_DIFFERENCE, &pBaseParamData);
//	RAISE_ERR(rc, RTN);
//	strcpy(pBaseParamData->paramValue, pParamUptReq->strOrdrDifference);
//

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT MarketStateTimeUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp)
{
    BEGIN_FUNCTION( "MarketStateTimeUpdate" );
    ResCodeT rc = NO_ERR;

    // vectorT  keyVct[GET_BIT_VECT_LEN(11)] = {0};
    // vectorT  datVct[GET_BIT_VECT_LEN(11)] = {0};

    MarketStCfgModifyReqT* pMktStCfgMdfyReq;

    MarketInfoCfgDataRefT mktInfoCfgRefData;
    // MktStCfg mktStCfgData = {0};
    char sysUptDateStr[MAX_TIME_LEN];

    pMktStCfgMdfyReq = (MarketStCfgModifyReqT*)&pReq->msgBody[0];

    // memset(&mktStCfgData, 0x00, sizeof(MktStCfg));
    memset(&mktInfoCfgRefData, 0x00, sizeof(MarketInfoCfgDataRefT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));

    // /* Get current timestamp */
    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);
    // rc = GetCurrentTime(sysUptDateStr);


    // mktStCfgData.mktStCfgId = pMktStCfgMdfyReq->intMktStCfgId;
    mktInfoCfgRefData.intMktStCfgId = pMktStCfgMdfyReq->intMktStCfgId;
    strcpy(mktInfoCfgRefData.strTime, pMktStCfgMdfyReq->strTime);
    strcpy(mktInfoCfgRefData.strSysTime, sysUptDateStr);
    // DbCmmnSetColBit( keyVct, 0 );

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_MARKET_INFO_CONFIG_DAT, &mktInfoCfgRefData, sizeof(MarketInfoCfgDataRefT));
    RAISE_ERR(rc, RTN);

    // strcpy(mktStCfgData.updTm, sysUptDateStr);
    // strcpy(mktStCfgData.updUsrNm, C_SYSTEM);
    // strcpy(mktStCfgData.nextStrtTm, pMktStCfgMdfyReq->strTime);

    // DbCmmnSetColBit( datVct, 5 );
    // DbCmmnSetColBit( datVct, 6 );
    // DbCmmnSetColBit( datVct, 7 );

    // rc = UpdateMktStCfgByKey(connId, &mktStCfgData, keyVct, datVct);
    // RAISE_ERR(rc, RTN);

    // rc = DbCmmnCommit(connId);
    // RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}
