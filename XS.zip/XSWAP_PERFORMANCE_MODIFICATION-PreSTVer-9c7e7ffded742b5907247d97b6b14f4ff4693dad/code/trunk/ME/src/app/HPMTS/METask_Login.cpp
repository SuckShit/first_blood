/***
Created on July 20, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */

/* Project Header File*/
#include "METask_Login.h"
#include "METask_Comm.h"
#include "LogInfo.pb.h"
#include "XAPIPbMessage.pb.h"

#include "irs_code_convert.h"
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "intrnl_msg.h"
#include "login.h"

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
using namespace IMIX;
using namespace IMIX20;
using namespace CFETS::Common;
using namespace xapi;

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
// 用户登录
ResCodeT OnLoginStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnLoginStart");
    ResCodeT            rc = NO_ERR;

    UserLoginReqT*      pLoginMsg;

    /************************************
                获取消息字段
    *************************************/
    // 用户ID
    IRS_STRING strUserId = "";
    // 客户端唯一编码
    IRS_STRING strUniqueKey = "";
    //
    int32 iLoginType = -1;

    PartyDetailGrp* pPartyDetailGrp;
    PartyDetailGrp::NoPartyDetails* pNoPartyDetails;
    int nPartyDetailRole;

    // 消息解析
    UserRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strUniqueKey = message.GetApplUniqueKey();

    pPartyDetailGrp = message.GetPartyDetailGrp();
    if (NULL != pPartyDetailGrp)
    {
        pNoPartyDetails = pPartyDetailGrp->GetNoPartyDetails();
        if (NULL != pNoPartyDetails)
        {
            strUserId = pNoPartyDetails->GetPartyDetailID();
            nPartyDetailRole = pNoPartyDetails->GetPartyDetailRole();

            if (11 == nPartyDetailRole)
            {
                iLoginType = 0;
            }
            else if (201 == nPartyDetailRole)
            {
                iLoginType = 1;
            }
            else if (73 == nPartyDetailRole)
            {
                iLoginType = 2;
            }
            else
            {
                LOG_WARNING(APP_MSG_INCOM_PARAM_ERROR);
            }
        }
    }

    if (iLoginType == -1)
    {
        LOG_WARNING(APP_MSG_REQFUNC_ERR);
    }
    pLoginMsg = (UserLoginReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(UserLoginReqT);
    pReq->msgHdr.msgType = MSG_TYPE_USER_LOGIN;

    pLoginMsg->iFuncId = FUNC_ID_USER_LOGIN;
    strcpy(pLoginMsg->strUserId, strUserId.c_str() );
    pLoginMsg->iLoginType = iLoginType;
    strcpy(pLoginMsg->strUniqueKey, strUniqueKey.c_str() );

    LOG_DEBUG("task write: iFuncId = %d \n", pLoginMsg->iFuncId);
    LOG_DEBUG("task write: strUserId = %s \n", pLoginMsg->strUserId);
    LOG_DEBUG("task write: iLoginType = %d \n", pLoginMsg->iLoginType);
    LOG_DEBUG("task write: strUniqueKey = %s \n", pLoginMsg->strUniqueKey);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnLoginStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnLoginStop");
    ResCodeT                rc = NO_ERR;

    UserLoginRespT*         pLoginStop;
    IRS_STRING              strErrCode = "";
    IRS_STRING              strErrMsg = "";

    UserResponse* pRspMessage = new UserResponse;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    if (NO_ERR != nExceptionFlag)
    {
        rc = ResponeExceptionMsg(pSendMsgList, pRspMessage, nExceptionFlag);
        RAISE_ERR(rc, RTN);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    if (NO_ERR == nExceptionFlag)
    {
        pLoginStop = (UserLoginRespT*)pRsp->msgBody;
        rc = SendLoginRespMsg(pRspMessage, pLoginStop, pSendMsgList);
        RAISE_ERR(rc, RTN);

        //如果非场务用户，发送市场状态更新消息
        if(E_USER_ROLE_OFFICER != pLoginStop->m_sUserRole)
        {
            TradingSessionStatus* pMktUpdStMsg = new TradingSessionStatus();
            if (NULL != pMktUpdStMsg)
            {
                pMktUpdStMsg->GetHeader()->SetTargetCompID(pRsp->msgHdr.imixHdr.senderCompID);
                pMktUpdStMsg->GetHeader()->SetDeliverToSubID(pRsp->msgHdr.imixHdr.onBehalfOfSubID);
                pMktUpdStMsg->GetHeader()->SetDeliverToCompID(pRsp->msgHdr.imixHdr.onBehalfOfCompID);
                pMktUpdStMsg->SetTradSesStatus(IrsToImix_MktFlag(pLoginStop->m_iMktSt));
                pMktUpdStMsg->SetEncodedTextLen(IrsToImix_MktFlag(pLoginStop->m_iMktStSirs));
                //设置市场状态变化时间
                switch(pLoginStop->m_iMktSt)
                {
                case E_MKT_ST_START://开市
                    {
                        pMktUpdStMsg->SetTradSesStartTime(pLoginStop->m_sUpTime);
                        break;
                    }
                case E_MKT_ST_OPEN://开盘
                    {
                        pMktUpdStMsg->SetTradSesOpenTime(pLoginStop->m_sUpTime);
                        break;
                    }
                case E_MKT_ST_PAUSE://休市
                case E_MKT_ST_CLOSE://收盘
                    {
                        pMktUpdStMsg->SetTradSesCloseTime(pLoginStop->m_sUpTime);
                        break;
                    }
                case E_MKT_ST_END://闭市
                    {
                        pMktUpdStMsg->SetTradSesEndTime(pLoginStop->m_sUpTime);
                        break;
                    }
                default:
                    break;
                }
                SendMessage(pSendMsgList, pMktUpdStMsg);
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



// 用户登出
ResCodeT OnLogoutStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnLogoutStart");
    ResCodeT            rc = NO_ERR;

    UserLogoutReqT*     pLogOutMsg;

    /************************************
                获取消息字段
    *************************************/
    // 用户ID
    IRS_STRING strUserId = "";
    // Token
    IRS_STRING strToken = "";


    // 消息解析
    UserRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strUserId = message.GetUsername();
    strToken = message.GetApplToken();

    pLogOutMsg = (UserLogoutReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(UserLogoutReqT);
    pReq->msgHdr.msgType = MSG_TYPE_USER_LOGOUT;

    pLogOutMsg->iFuncId = FUNC_ID_USER_LOGOUT;
    strcpy(pLogOutMsg->strUserId, strUserId.c_str() );
    strcpy(pLogOutMsg->strToken, strToken.c_str() );

    LOG_DEBUG("task write: iFuncId = %d \n", pLogOutMsg->iFuncId);
    LOG_DEBUG("task write: strUserId = %s \n", pLogOutMsg->strUserId);
    LOG_DEBUG("task write: strToken = %s \n", pLogOutMsg->strToken);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnLogoutStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnLogoutStop");
    ResCodeT        rc = NO_ERR;

    IRS_STRING      strErrCode = "";
    IRS_STRING      strErrMsg = "";

    UserResponse* pRspMessage = new UserResponse;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    if (NO_ERR != nExceptionFlag)
    {
        rc = ResponeExceptionMsg(pSendMsgList, pRspMessage, nExceptionFlag);
        RAISE_ERR(rc, RTN);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    if (NO_ERR == nExceptionFlag)
    {
        rc = SendMessage(pSendMsgList, pRspMessage);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



// 应急踢出在线用户
ResCodeT OnRemoveOnlineUserStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnRemoveOnlineUserStart");
    ResCodeT        rc = NO_ERR;

    RemoveUserReqT* pRemoveUserMsg;

    /************************************
                获取消息字段
    *************************************/
    // 用户ID
    IRS_STRING strOfficer = "";
    // Token
    IRS_STRING strToken = "";
    // Org Id
    IRS_STRING strOrgId = "";
    // Remove User Id
    IRS_STRING strRemoveUserId = "";


    PartyDetailGrp* pPartyDetailGrp;
    PartyDetailGrp::NoPartyDetails* pNoPartyDetails;
    int nPartyDetailRole;

    // 消息解析
    UserRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strOfficer = GetPartyDetailId(message.GetPartyDetailGrp(), E_PARTY_DETAIL_ROLE_OFFICER);
    if (strOfficer == "")
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Get officer id error.");
    }
    strToken = message.GetApplToken();
    strRemoveUserId = message.GetUsername();


    pRemoveUserMsg = (RemoveUserReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(RemoveUserReqT);
    pReq->msgHdr.msgType = MSG_TYPE_REMOVE_ONLINE_USER;

    pRemoveUserMsg->iFuncId = FUNC_ID_REMOVE_USER;
    strcpy(pRemoveUserMsg->strOfficer, strOfficer.c_str() );
    strcpy(pRemoveUserMsg->strToken, strToken.c_str() );
    strcpy(pRemoveUserMsg->strRemoveUserId, strRemoveUserId.c_str() );

    LOG_DEBUG("task write: iFuncId = %d \n", pRemoveUserMsg->iFuncId);
    LOG_DEBUG("task write: strUserId = %s \n", pRemoveUserMsg->strOfficer);
    LOG_DEBUG("task write: strToken = %s \n", pRemoveUserMsg->strToken);
    LOG_DEBUG("task write: strRemoveUserId = %s \n", pRemoveUserMsg->strRemoveUserId);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnRemoveOnlineUserStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnRemoveOnlineUserStop");
    ResCodeT            rc = NO_ERR;

    RemoveUserRespT*    pRemoveUserStop;
    IRS_STRING          strErrCode = "";
    IRS_STRING          strErrMsg = "";

    UserResponse* pRspMessage = new UserResponse;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    if (NO_ERR != nExceptionFlag)
    {
        rc = ResponeExceptionMsg(pSendMsgList, pRspMessage, nExceptionFlag);
        RAISE_ERR(rc, RTN);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    rc = SendMessage(pSendMsgList, pRspMessage);
    RAISE_ERR(rc, RTN);

    // 发送其他的消息
    if (NO_ERR == nExceptionFlag)
    {
        RiskInfoRespT*  pRiskCoefStop;
        pRiskCoefStop = (RiskInfoRespT*)pRsp->msgBody;
        rc = SendFreezeStatusNotifyMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pRiskCoefStop , pSendMsgList);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
