/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include <math.h>
#include "METask_CW.h"
#include "METask_Comm.h"
#include "irs_code_convert.h"
#include "internal_function_def.h"
#include "CwPb.pb.h"
#include "Enum.pb.h"
#include "XAPIPbMessage.pb.h"
#include "org_setting.h"
#include "msg_bridge_update.h"
#include "msg_base_param_update.h"
#include "usr.h"
#include "msg_type.h"
#include "org_info.h"
#include "api.h"
#include "msg_market_info_update.h"
#include "msg_credit_position_sbfccp.h"
#include "user_order.h"
#include "uti_tool.h"
#include "order_book.h"

using namespace IMIX;
using namespace IMIX20;
using namespace cwpb;
using namespace constants;

ResCodeT OnCWStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnCGMsgStart");
    ResCodeT                rc = NO_ERR;

    // 消息解析
    SecurityDefinition message;

    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    switch(message.GetDataType())
    {
    case 1:
        {
//          OnBaseParamUpdateStart(inMessage,pParamList);
        }
        break;
        //CCPSBF业务
    case CCPSBF_CLS_POS:
        {
            //SBF强行平仓
            rc = OnSBFCCP_ClosePositionStart(inMessage,pReq);
        }
        break;
    case CCPSBF_UNDO_CLS_POS:
        {
            //撤销平仓
            pReq->msgHdr.setId  = SET_MKT_SBFCCP;
            rc = OnSBFCCP_UndoClosePositionStart(inMessage, pReq);
        }
        break;
    case CCPSBF_LMT_POS:
        {
            //限仓
            rc = OnSBFCCP_LimitPositionStart(inMessage, pReq);
        }
        break;
    case CCPSBF_UNDO_DL:
        {
            //成交撤销
//          nRet = OnSBFCCP_UndoDealStart(inMessage, pParamList);
        }
        break;
    case ORG_PRVLG:
        {
            //机构权限
            rc = OnOrgMktRoleUpdateStart(inMessage, pReq);
        }
        break;
    case CCPSBF_NEW_ORDER:
        {
            //报价
//          nRet = OnSBFCCP_NewOrderStart(inMessage, pParamList);
        }
        break;
    case CCPSBF_UNDO_ORDER:
        {
            //撤销报价
            pReq->msgHdr.setId = SET_MKT_SBFCCP;
            rc = OnAdminOrderCancelStart(inMessage, pReq);
        }
        break;
    case CCPSBF_MDFY_REF_PRC:
        {
            //每日结算价修改
//          nRet = OnSBFCCP_DlySttlmntRtMdfyStart(inMessage, pParamList);
        }
        break;
    case CCPSBF_ADD_CNTRCT:
        {
//          nRet = OnSBFCCP_ConCtractAddStart(inMessage, pParamList);
        }
        break;
    case CCPSBF_DEL_CNTRCT:
        {
//          nRet = OnSBFCCP_ConCtractRemoveStart(inMessage, pParamList);
        }
        break;
        //zghtodo 合约复核 没有相应的datatype

    case CCPSBF_MDFY_CNTRCT:
        {
            //合约修改
//          nRet = OnSBFCCP_ConCtractUpdateStart(inMessage, pParamList);
        }
        break;
    case CCPSBF_DLVY_BONDS:
        {
            //可交割债券
//          nRet = OnSBFCCP_DlvryBondInfoUpdateStart(inMessage, pParamList);
        }
        break;
    case CCPSBF_CNVRT_RATE:
        {
            //合约可转换因子
//          nRet = OnSBFCCP_CntrctCnvrtRateStart(inMessage, pParamList);
        }
        break;
        //CCPSIRS业务
    case CCPSIRS_CLS_POS:
        {
            //强行平仓
//          nRet = OnSIRSCCP_ClosePositionStart(inMessage,pParamList);
        }
        break;
    case CCPSIRS_UNDO_CLS_POS:
        {
            //撤销平仓
//          nRet = OnSIRSCCP_UndoClosePositionStart(inMessage,pParamList);
        }
        break;
    case CCPSIRS_LMT_POS:
        {
            //限仓
//          nRet = OnSIRSCCP_LimitPositionStart(inMessage,pParamList);
        }
        break;
    case CCPSIRS_UNDO_DL:
        {
            //成交撤销
//          nRet = OnSIRSCCP_UndoDealStart(inMessage, pParamList);
        }
        break;
    case CCPSIRS_NEW_ORDER:
        {
            //报价
//          nRet = OnSIRSCCP_NewOrderStart(inMessage, pParamList);
        }
        break;
    case CCPSIRS_UNDO_ORDER:
        {
            //报价撤销
    //      nRet = OnSIRSCCP_OrderCancelStart(inMessage, pParamList);
        }
        break;
    case CCPSIRS_MDFY_REF_PRC:
        {
            //每日结算价修改
//          nRet = OnSIRSCCP_DlySttlmntRtMdfyStart(inMessage, pParamList);
        }
        break;
    case CCPSIRS_ADD_CNTRCT:
        {
//          nRet = OnSIRSCCP_ConCtractAddStart(inMessage, pParamList);
        }
        break;
    case CCPSIRS_DEL_CNTRCT:
        {
//          nRet = OnSIRSCCP_ConCtractRemoveStart(inMessage, pParamList);
        }
        break;
        //zghtodo 合约复核 没有相应的datatype

    //case CCPSIRS_MDFY_CNTRCT:
    //  {
    //      //合约修改
    //      nRet = OnSIRSCCP_ConCtractUpdateStart(inMessage, pParamList);
    //  }
    //  break;
    case CCPSIRS_MDFY_CNTRCT_PARAM:
        {
            //合约修改
//          nRet = OnSIRSCCP_ConCtractUpdateStart(inMessage, pParamList);
        }
        break;
    case CCPSIRS_CNVRT_RATE:
        {
            //合约转换系数
//          nRet = OnSIRSCCP_CntrctCnvrtRateStart(inMessage, pParamList);
        }
        break;
    case MARKET_ST_TM_SET:
        {
            rc = OnMarketStateTimeSetStart(inMessage, pReq);
        }
        break;
    case MARKET_ST_CHG:
        {
            rc = OnMarketStateChangeStart(inMessage, pReq);
        }
        break;
    case INTERFASE_PARAM:
        {
//            rc = OnAPIParamUpdateStart(inMessage, pReq);
        }
        break;
    case USER_API_MANAGERPRO:
        {
            //api用户禁用启用
            rc = OnAPIUserFreezeStart(inMessage, pReq);
        }
        break;
    case USER_API_MANAGERTMP:
        {
            //紧急踢出API用户
            rc = OnAPIUserRemoveStart(inMessage, pReq);
        }
        break;
    case BRDG_PRIVLG_UPDATE:
        {
            //桥机构设置
//          nRet = OnBrdgPrvlgUpdateStart(inMessage, pParamList);
        }
        break;
    case BRDG_PERCENTAGE_UPDATE:
        {
            //桥百分比设置
            rc = OnBrdgPercentageUpdateStart(inMessage, pReq);
        }
        break;
    case IRS_UNDO_ORDER:
        {
            //IRS应急撤销报价
            pReq->msgHdr.setId = SET_MKT_IRS;
            rc = OnAdminOrderCancelStart(inMessage, pReq);
        }break;
    case SIRS_UNDO_ORDER:
        {
            //SIRS应急撤销报价
            pReq->msgHdr.setId = SET_MKT_SIRS;
            rc = OnAdminOrderCancelStart(inMessage, pReq);
        }break;
    default:
        {
            LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        }
        break;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//机构市场权限设置
ResCodeT OnOrgMktRoleUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrgMktRoleUpdateStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnOrgMktRoleUpdateStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    SecurityDefinitionReqT* pSetting;

//    std::string strFuncId="";
//    IntToString(SP_FUNCID(SP_ID_ORG_MARKET_ROLE_UPDATE), strFuncId);

    std::string sToken = "";
    std::string sUserId = "";
    std::string sOrgId = "";            //机构id
    std::string sPrvlg_Str="";          //权限字符串
    // 全局指令编号
    std::string strMarket_id = "";
    std::string strPrvlgIRS = "";       //IRS市场权限
    std::string strPrvlgSIRS = "";      //SIRS市场权限
    std::string strPrvlgSBF = "";       //SBF市场权限
    std::string strPrvlgSIRSCCP = "";   //SIRSCCP市场权限
    std::string strPrvlgSBFCCP = "";    //SBFCCP市场权限
    User usr;                           //用户信息

    int nMassSize = 0;

    MktPrvlg partyUpdate;
    int len;
    //16进制转成2进制，再解析
    char *out;
    size_t nLen;
    char *p;

    string strFlag = ";";   //市场字符串的分隔符
    int iStart = 0;         //市场字符串的开始
    int iEnd;               //市场字符串的结束
    std::string strTemp;//各市场的所有字符串
    std::string strPrvlg;//市场权限字符
    std::string strMktNum;//市场标号 1 2 3 4 5

    SecurityDefinition message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    //获取子消息
    MassMessageGrp* pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp) {        
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1) {
//            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", strFuncId.c_str(), nMassSize);
            return APP_CODE_INCOM_PARAM_ERROR;
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage) {
//            MktPrvlg partyUpdate;
//            int len = pNoMassMessage->GetMessageLen();
            len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
//            char *out = new char[len / 2 + 1];
            out = new char[len / 2 + 1];
//            size_t nLen;
//            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            sOrgId = partyUpdate.org_id();                //合约代码
            strMarket_id = partyUpdate.market_id();                //结算日期
            sPrvlg_Str = partyUpdate.prvlg_str();            //结算价

//            string strFlag = ";";//市场字符串的分隔符
//            int iStart=0;//市场字符串的开始
//            int iEnd = sPrvlg_Str.find(strFlag);//市场字符串的结束

            strFlag = ";";                      //市场字符串的分隔符
            iStart = 0;                         //市场字符串的开始
            iEnd = sPrvlg_Str.find(strFlag);    //市场字符串的结束
            while (-1 != iEnd) {
//                std::string strTemp;//各市场的所有字符串
//                std::string strPrvlg;//市场权限字符
//                std::string strMktNum;//市场标号 1 2 3 4 5

                strTemp = sPrvlg_Str.substr(iStart,iEnd-iStart);
                iStart = iEnd + 1;
                iEnd = sPrvlg_Str.find(strFlag, iEnd + 1);
                strPrvlg = strTemp.substr(2, strTemp.length()-2);

                strMktNum = strTemp.substr(0,1);
                if (MKT_TYPE_IRS ==strMktNum) {
                    strPrvlgIRS = strPrvlg;
                }
                else if (MKT_TYPE_SIRS ==strMktNum) {
                    strPrvlgSIRS = strPrvlg;
                }
                else if (MKT_TYPE_SBF ==strMktNum) {
                    strPrvlgSBF = strPrvlg;
                }
                else if (MKT_TYPE_SIRSCCP ==strMktNum) {
                    strPrvlgSIRSCCP = strPrvlg;
                }
                else if (MKT_TYPE_SBFCCP ==strMktNum) {
                    strPrvlgSBFCCP = strPrvlg;
                }
            }
            // 会员信息
//            User usr = partyUpdate.user();            //身份认证信息
            usr = partyUpdate.user();            //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();
        }
        else {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            return APP_CODE_INCOM_PARAM_ERROR;
        }
    }
    else {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    LOG_INFO("In condition: sUserId = %s, sToken = %s, sOrgId = %s,strPrvlgIRS = %s,strPrvlgSIRS = %s\
             , strPrvlgSBF = %s,strPrvlgSIRSCCP = %s,strPrvlgSBFCCP = %s",
             sUserId.c_str(), sToken.c_str(), sOrgId.c_str(), strPrvlgIRS.c_str(), strPrvlgSIRS.c_str(),
             strPrvlgSBF.c_str(), strPrvlgSIRSCCP.c_str(), strPrvlgSBFCCP.c_str());

    pSetting = (SecurityDefinitionReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(SecurityDefinitionReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORG_MARKET_ROLE_UPDATE;

    // SP入参
    pSetting->iFuncId = FUNC_ID_ORG_MARKET_ROLE_UPDATE;        //机能标识
    strcpy(pSetting->strUserId,  sUserId.c_str());             //用户标识
    strcpy(pSetting->strToken,   sToken.c_str());              //Token
    strcpy(pSetting->strOpOrgId, sOrgId.c_str());              //被处理机构ID

    pSetting->intPrvlgIRS = StringToInt(strPrvlgIRS);          //Irs市场权限
    pSetting->intPrvlgSIRS = StringToInt(strPrvlgSIRS);        //Sirs市场权限
    pSetting->intPrvlgSBF = StringToInt(strPrvlgSBF);          //Sbf市场权限
    pSetting->intPrvlgSIRSCCP = StringToInt(strPrvlgSIRSCCP);  //Sirsccp市场权限
    pSetting->intPrvlgSBFCCP = StringToInt(strPrvlgSBFCCP);    //Sbfccp市场权限

    //check
//    CCP_SpOrgMktRoleCheck(strFuncId, sUserId, sToken, pParamList);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("%s End..", sFunction.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT OnOrgMktRoleUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOrgMktRoleUpdateStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnOrgMktRoleUpdateStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    SecurityDefinitionRspT*  pSettingRst;
    /*---------------------------------------
    *******    执行结果参数据临时变量 **********
    ----------------------------------------*/    
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 applRefSeqNum = 0;

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // 定义应答消息
    SecurityDefinition* pRspMessage = new SecurityDefinition;
    if (NULL == pRspMessage) {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    pRspMessage->SetApplToken("----");

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    else {
        pSettingRst = (SecurityDefinitionRspT*)pRsp->msgBody;

        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pSettingRst->rspOrderCancel.rspSlot,
                                                    pSettingRst->rspOrderCancel.slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);

        // 发送其他的消息
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pSettingRst->rspOrder, pSettingRst->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN); //todo
    }


/*
    // 发送其他的消息
    if (SP_RET_SUCCESS == oRetParam.m_nErrorCode)
    {    
        int nOutBoundId = oRetCheckParam.m_nOutBoundId;

        SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOrders, pSendMsgList);
        SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);

        SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);

        SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSBFOrders, pSendMsgList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFOrders, nOutBoundId, pSendMsgList, pParamList);

        CCP_SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSIRSCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSIRSCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        CCP_SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
    }
*/

    LOG_DEBUG("%s End..", sFunction.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//桥百分比设置
ResCodeT OnBrdgPercentageUpdateStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBrdgPercentageUpdateStart");
    ResCodeT rc = NO_ERR;

    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    BrdgPercentageUpdateReqT* pBrdgPrcntgUpdReq;

    SecurityDefinition message;
    IRS_STRING strBrdgPercentage = "";
    IRS_STRING strBrdgFlag = "";
    IRS_STRING strTm = "";
    MassMessageGrp* pMassMessageGrp;
    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    BrdgParamUpdate partyUpdate;
    int len;
    char *out;
    size_t nLen;
    char *p;

    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    //获取子消息
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", strFuncId.c_str(), nMassSize);
            // return APP_CODE_INCOM_PARAM_ERROR;
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {

            len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            out = new char[len / 2 + 1];

            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            strBrdgPercentage = partyUpdate.percentage();
            strBrdgFlag = partyUpdate.brdgflag();
            strTm = partyUpdate.tm();
        }
        else
        {
            // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            // return APP_CODE_INCOM_PARAM_ERROR;
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

    }
    else
    {
        // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        // return APP_CODE_INCOM_PARAM_ERROR;
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    pBrdgPrcntgUpdReq = (BrdgPercentageUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(BrdgPercentageUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_BRIDGE_PERCENTAGE_UPDATE;

    strcpy(pBrdgPrcntgUpdReq->strBrdgFlag, strBrdgFlag.c_str());
    strcpy(pBrdgPrcntgUpdReq->strBrdgPercentage, strBrdgPercentage.c_str());
    strcpy(pBrdgPrcntgUpdReq->strBrdgReturn, strTm.c_str());

    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnBrdgPercentageUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBrdgPercentageUpdateStop");
    ResCodeT rc = NO_ERR;

    // 默认的返回值定义
    int nRet = APP_CODE_SUCCESS;

    BrdgPercentageUpdateRespT* pBrdgPrcntgUpdResp;

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // 定义应答消息

    SecurityDefinition* pRspMessage = new SecurityDefinition;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    pBrdgPrcntgUpdResp = (BrdgPercentageUpdateRespT*)pRsp->msgBody;

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        // TODO:
        // int nOutBoundId = oRetParam.m_nOutBoundId;
        // SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


// API参数设置
ResCodeT OnAPIParamUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnAPIParamUpdateStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnBrdgPercentageUpdateStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    std::string strFuncId ="";
    IntToString(FUNC_ID_API_PARAM_UPDATE, strFuncId);
    std::string sToken = "";
    std::string sUserId = "";
    std::string sFlowNm = "";               // 授信流控值
    std::string strLogin_sFlowNm = "";      // 登录指令流控值
    std::string strTrade_sFlowNm = "";      // 交易流控值
    std::string strMkt_sFlowNm = "";        // 行情流控值
    User usr;                               // 用户信息
    IRS_STRING strCrdt_Tm_Start = "";
    IRS_STRING strCrdt_Tm_End = "";

    MassMessageGrp* pMassMessageGrp;
    ApiParamUpdateReqT* pApiReq;

    SecurityDefinition message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    // 获取子消息
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", strFuncId.c_str(), nMassSize);
            return APP_CODE_INCOM_PARAM_ERROR;
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            APIParam partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            // 16进制转成2进制，再解析
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            sFlowNm = partyUpdate.flow_cont_nm();   //流控值
            strTrade_sFlowNm = partyUpdate.trade_flow_cont_nm();
            strLogin_sFlowNm = partyUpdate.logon_flow_cont_nm();
            strMkt_sFlowNm = partyUpdate.mkt_flow_cont_nm();

            // 会员信息
            User usr = partyUpdate.user();          //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();
            strCrdt_Tm_Start = partyUpdate.crdt_time_st();
            strCrdt_Tm_End = partyUpdate.crdt_time_end();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            return APP_CODE_INCOM_PARAM_ERROR;
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    LOG_INFO("[%d] In condition: sFunctionId = %s, sUserId = %s, sToken = %s, sFlowNm = %s, strCrdt_Tm_Start = %s, strCrdt_Tm_End = %s",
        FUNC_ID_API_PARAM_UPDATE, strFuncId.c_str(), sUserId.c_str(), sToken.c_str(),sFlowNm.c_str(), strCrdt_Tm_Start.c_str(), strCrdt_Tm_End.c_str());

    pApiReq = (ApiParamUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(ApiParamUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_PARAM_UPDATE;

    pApiReq->iFuncId = FUNC_ID_API_PARAM_UPDATE;
    strcpy(pApiReq->strUserId, sUserId.c_str());
    strcpy(pApiReq->strToken, sToken.c_str());
    pApiReq->iCrdtFlowCtrl = atoi(sFlowNm.c_str());
    pApiReq->iTradeFlowCtrl = atoi(strTrade_sFlowNm.c_str());
    pApiReq->iLoginFlowCtrl = atoi(strLogin_sFlowNm.c_str());
    pApiReq->iMktFlowCtrl = atoi(strMkt_sFlowNm.c_str());
    strcpy(pApiReq->strMdfyCrdtBegin, strCrdt_Tm_Start.c_str());
    strcpy(pApiReq->strMdfyCrdtEnd, strCrdt_Tm_End.c_str());

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnAPIParamUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnAPIParamUpdateStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnAPIParamUpdateStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/

    // 定义应答消息
    SecurityDefinition* pRspMessage = new SecurityDefinition;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        return APP_CODE_INCOM_PARAM_ERROR;
    }
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//API用户冻结、启用
ResCodeT OnAPIUserFreezeStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnAPIUserFreezeStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnAPIUserFreezeStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    std::string strFuncId="";

    IntToString(FUNC_ID_API_USER_FREEZE, strFuncId);
    std::string sToken = "";
    std::string sUserId = "";
    std::string sApiUserId = "";        //要处理的用户ID
    IRS_STRING strType = "";        //请求类型

    SecurityDefinition message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //获取子消息
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", strFuncId.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            APIUserForb partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            // 会员信息
            User usr = partyUpdate.user();          //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();

            sApiUserId = partyUpdate.user_id();
            strType = partyUpdate.st();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%d] In condition: sFunctionId = %s, sUserId = %s, sToken = %s, sApiUserId = %s, strType = %s",
        FUNC_ID_API_USER_FREEZE, strFuncId.c_str(), sUserId.c_str(), sToken.c_str(),sApiUserId.c_str(), strType.c_str());

    // SP入参
    ApiUserFreezeReqT* pApiReq;
    pApiReq = (ApiUserFreezeReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(ApiUserFreezeReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_USER_FREEZE;

    pApiReq->iFuncId = FUNC_ID_API_USER_FREEZE;
    strcpy(pApiReq->strUserId, sUserId.c_str());
    strcpy(pApiReq->strToken, sToken.c_str());
    strcpy(pApiReq->strOpApiUserId, sApiUserId.c_str());
    pApiReq->iRequestType = atoi(strType.c_str());

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnAPIUserFreezeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnAPIUserFreezeStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnAPIUserFreezeStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    // 定义应答消息
    SecurityDefinition* pRspMessage = new SecurityDefinition;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    ApiUserFreezeRespT* pApiResp;
    pApiResp = (ApiUserFreezeRespT*)pRsp->msgBody;

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);


    if (NO_ERR == nExceptionFlag && "" != pApiResp->strToken)
    {
        //组装强退消息发给TDPS->X
        IMIX20::QueryResult* pKickUserMsg = new QueryResult;
        if (NULL == pKickUserMsg)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pKickUserMsg is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }
        pKickUserMsg->GetHeader()->SetTargetCompID(TDPS_COMPID);
        std::string strQryType;
        IntToString(xapi::KICK_USER,strQryType);
        pKickUserMsg->SetQueryType(strQryType);
        pKickUserMsg->SetApplSeqNum(pApiResp->iMaxOutboundId++);

        MassMessageGrp::NoMassMessage *pKickUserNoMassMsg = pKickUserMsg->GetMassMessageGrp()->AddNoMassMessage();
        xapi::KickUser kickUserAck;

        kickUserAck.set_request_type(200);
        xapi::User* user = kickUserAck.mutable_user();
        if (NULL == user)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s user is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }
        user->set_token(pApiResp->strToken);
//        user->set_user_id(sUserId.c_str());
//        user->set_org_id(pApiResp->strOrgCd);

//        LOG_DEBUG("[%d] send msg: sUserId = %s, m_sToken = %s, m_sOrgCd = %s",
//                    FUNC_ID_API_USER_FREEZE, sUserId.c_str(), oRetParam.m_sToken.c_str(), oRetParam.m_sOrgCd.c_str());

        int len = kickUserAck.ByteSize();
        char *buf = new char[len];
        kickUserAck.SerializeToArray(buf, len);
        char *out = new char[len * 2 + 1];
        size_t olen;
        char *p = ArraytoHex(buf, len, out, &olen);
        p[olen] = 0;
        pKickUserNoMassMsg->SetMessageData(p, olen);
        pKickUserNoMassMsg->SetMessageLen(olen);
        delete[] buf;
        buf = NULL;
        delete[] out;
        out = NULL;
        if (SP_RET_SUCCESS == SendMessage(pSendMsgList, pKickUserMsg))
        {
//            OutBoundMsg(pKickUserMsg->GetApplSeqNum(), static_cast<IMIX::BasicMessage*>(pKickUserMsg), pParamList);
        }
    }


    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        int nOutBoundId = pApiResp->iMaxOutboundId;

        //发给TDPS踢出用户
        if (pApiResp->iUserRole == E_USER_ROLE_API_HQ)
        {
//            API_SendSubscribeClsMsgToTDPS(CLEAR_SUBSCRIBE_ONE, nOutBoundId, pSendMsgList, pParamList,sUserId,pApiResp->strOrgCd);
        }

/*
        SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, pSendMsgList);
        //SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        //SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
        CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        //CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
*/
    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}


//紧急踢出API用户
ResCodeT OnAPIUserRemoveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnAPIUserRemoveStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnAPIUserRemoveStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    std::string strFuncId="";

    IntToString(FUNC_ID_API_ONLINE_USER_REMOVE, strFuncId);
    std::string sToken = "";
    std::string sUserId = "";
    std::string sApiUserId = "";        //要处理的用户ID

    SecurityDefinition message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //获取子消息
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", strFuncId.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            APIUserTemDiscon partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            // 会员信息
            User usr = partyUpdate.user();          //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();

            if (partyUpdate.has_user_id())
            {
                sApiUserId = partyUpdate.user_id();
            }
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%d] In condition: sFunctionId = %s, sUserId = %s, sToken = %s, sApiUserId = %s",
        FUNC_ID_API_ONLINE_USER_REMOVE, strFuncId.c_str(), sUserId.c_str(), sToken.c_str(),sApiUserId.c_str());


    // SP入参
    ApiUserRemoveReqT* pApiReq;
    pApiReq = (ApiUserRemoveReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(ApiUserRemoveReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_USER_REMOVE;

    pApiReq->iFuncId = FUNC_ID_API_ONLINE_USER_REMOVE;
    strcpy(pApiReq->strUserId, sUserId.c_str());
    strcpy(pApiReq->strToken, sToken.c_str());
    strcpy(pApiReq->strRemoveUsrId, sApiUserId.c_str());

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnAPIUserRemoveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnAPIUserRemoveStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnAPIUserRemoveStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    SecurityDefinition* pRspMessage = new SecurityDefinition;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    NewOrderSingleRspT* pApiResp;
    pApiResp = (NewOrderSingleRspT*)pRsp->msgBody;

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);


    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
//        int nOutBoundId = pApiResp->iMaxOutboundId;

        //组装强退消息发给TDPS, 清除订阅消息发给TDPS
//        API_SendRemoveOnlineUserMsgToTDPS(oRetParamRst.m_vecOnlineUser, nOutBoundId, pSendMsgList, pParamList);
        //清除订阅消息发给TDPS 在发送强退消息时同步发送
        SendOrdrDealStsUpdtMsgToTrdr(RDP_COMPID, pApiResp->rspSlot, pApiResp->slotCnt, pSendMsgList);
        //SendOrderStatusUpdateMsgToTrader(RDP_COMPID, pApiResp->rspOrder, pApiResp->rspOrderCnt, pSendMsgList);
/*
        //SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);    //用户退出后发了也没啥用

        SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        //SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        //CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
*/
    }


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//市场应急
ResCodeT OnMarketStateTimeSetStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMarketStateTimeSetStart");
    ResCodeT rc = NO_ERR;

    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    MarketStCfgModifyReqT* pMarketStCfgMdfyReq;

    std::string sFunctionId="";
    std::string sToken = "";
    User usr;                       //用户信息

    std::string sMktStCfgId = "";   //合约品种
    std::string sTm = "";   //转换系数
    MassMessageGrp* pMassMessageGrp;
    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    int len;
    MarketSt partyUpdate;
    char *out;
    size_t nLen;
    char *p;

    SecurityDefinition message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //获取子消息
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            out = new char[len / 2 + 1];

            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            sMktStCfgId = partyUpdate.mkt_st_cfg_id();
            sTm = partyUpdate.strt_tm();

            // 会员信息
            usr = partyUpdate.user();           //身份认证信息
            sToken = usr.token();
        }
        else
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    pMarketStCfgMdfyReq = (MarketStCfgModifyReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(MarketStCfgModifyReqT);
    pReq->msgHdr.msgType = MSG_TYPE_MARKET_CONFIG_MODIFY_CW;

    pMarketStCfgMdfyReq->intFuncId = FUNC_ID_MKTINFO_CFG_MODIFY_BY_CW;
    strcpy(pMarketStCfgMdfyReq->strToken, sToken.c_str());
    pMarketStCfgMdfyReq->intMktStCfgId = atoi(sMktStCfgId.c_str());
    strcpy(pMarketStCfgMdfyReq->strTime, sTm.c_str());

    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnMarketStateTimeSetStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnMarketStateTimeSetStop");
    ResCodeT rc = NO_ERR;
    // 默认的返回值定义
    int nRet = APP_CODE_SUCCESS;

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;


    // 定义应答消息
    SecurityDefinition* pRspMessage = new SecurityDefinition;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    //应答消息
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnAdminOrderCancelStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnAdminOrderCancelStart");
    ResCodeT rc = NO_ERR;
    pUsrBaseInfoT pUsr = NULL;
    int nRet = APP_CODE_SUCCESS;

    SecurityDefinition message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }
    OrderCancelRequestReqT* pOrderMsg;

    std::string sFunctionId="";
    std::string sToken = "";
    std::string sUserId = "";
    std::string sOrdr_id = "";        //报价编号
    std::string sMessage_id = "";    //产品类型
    User usr;                        //用户信息

    pOrderMsg = (OrderCancelRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelRequestReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORDER_CANCEL_BY_ADMIN;

    //获取子消息
    MassMessageGrp* pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("Mass size: %d.",  nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "NoMassMessage_Num is %d.", nMassSize);
            return APP_CODE_INCOM_PARAM_ERROR;
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            OrderCancel partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            sOrdr_id = partyUpdate.ordr_id();                    //报价编号

            sMessage_id = partyUpdate.market_id();                // 消息ID
            // 会员信息
            User usr = partyUpdate.user();            //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "GetNoMassMessage is null.");
            return APP_CODE_INCOM_PARAM_ERROR;
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, " GetMassMessageGrp is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    rc = IrsUsrInfoGetByNameExt((char *)sUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;


    strcpy(pOrderMsg->token, sToken.c_str()  );
    pOrderMsg->ordId = StringToInt64(sOrdr_id.c_str()  );

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnOrderCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOrderCancelStop");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strErrMsg = "";

    NewOrderSingleRspT*  pOrderCnclStop;
    IRS_STRING strErrCode = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);


    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    rc = SendMessage(pSendMsgList, pRspMessage);
    RAISE_ERR(rc, RTN);

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        pOrderCnclStop = (NewOrderSingleRspT*)pRsp->msgBody;
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspSlot,  pOrderCnclStop->slotCnt, pSendMsgList);
        //rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspOrder, pOrderCnclStop->rspOrderCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//市场应急
ResCodeT OnMarketStateChangeStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMarketStateChangeStart");
    ResCodeT                rc = NO_ERR;
    int32                   intExecute = 1;  // update by cw
    SecurityDefinition      message;
    MassMessageGrp*         pMassMessageGrp;
    pMarketInfoUpdateReqT   pMktReq;
    std::string             sToken = "";
    User                    usr;//用户信息
    std::string             sOpenCloseStId = ""; //1-开市，2-开盘，3-休市，4-收盘，5-闭市
    std::string             sMktStCfgId = "";    //市场状态id

    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //获取子消息
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            MarketSt     partyUpdate;
            int          len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            char         *out = new char[len / 2 + 1];
            size_t       nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            sOpenCloseStId  = partyUpdate.mkt_st();
            sMktStCfgId     = partyUpdate.mkt_st_cfg_id();

            // 会员信息
            User usr        = partyUpdate.user();   //身份认证信息
            sToken          = usr.token();
        }
        else
        {
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }
    }
    else
    {
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%s] In condition: sToken = %s, sOpenCloseStId = %s, intExecute = %d, sMktStCfgId = %s",
     "OnMarketStateChangeStart", sToken.c_str(), sOpenCloseStId.c_str(),intExecute,
     sMktStCfgId.c_str());

    pMktReq                = (MarketInfoUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen            = sizeof(MarketInfoUpdateReqT);
    pReq->msgHdr.msgType           = MSG_TYPE_MARKET_INFO_UPDATE;

    pMktReq->intFuncId     = FUNC_ID_MKTINFO_UPDATE;
    strcpy(pMktReq->strToken, sToken.c_str());
    pMktReq->intOpenClsId  = atoi(sOpenCloseStId.c_str());
    pMktReq->intIsExecute  = intExecute;
    pMktReq->intMktStCfgId = atoi(sMktStCfgId.c_str());

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnMarketStateChangeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnMarketStateChangeStop");
    ResCodeT           rc = NO_ERR;
    IRS_STRING         strErrCode = "";
    IRS_STRING         strErrMsg = "";
    int32              nApplSeqNum = 0;
    pMarketInfoUpdateRespT  pMktRsp = NULL;

    SecurityDefinition* pRspMessage = new SecurityDefinition;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    if (NO_ERR == nExceptionFlag)
    {
        pMktRsp = (pMarketInfoUpdateRespT)pRsp->msgBody;
        rc = SendMktStatusToOnlineUser(pRspMessage->GetHeader()->GetTargetCompID(), pMktRsp, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



//限仓
ResCodeT OnSBFCCP_LimitPositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSBFCCP_LimitPositionStart");
    ResCodeT rc = NO_ERR;

    SbfCcpCrdtLimitByCwReqT* pCrdtLimitReq;

    SecurityDefinition message;
    std::string sToken = "";
    std::string sUserId = "";
    std::string sOrgId = "";
    // 全局指令编号
    std::string strMessage_id = "";
    // 最新持仓限额
    std::string strLimit_value = "";
    MassMessageGrp* pMassMessageGrp;
    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    LimitPosition partyUpdate;
    int len;
    char *out;
    char *p;
    size_t nLen;
    User usr;

    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    //获取子消息
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {

            len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            out = new char[len / 2 + 1];

            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            strMessage_id = partyUpdate.market_id();                // 消息ID
            strLimit_value = partyUpdate.intl_amnt();                   //最新持仓限额
            sOrgId = partyUpdate.org_id();
            // 会员信息
            usr = partyUpdate.user();           //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();
        }
        else
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    pCrdtLimitReq = (SbfCcpCrdtLimitByCwReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(SbfCcpCrdtLimitByCwReqT);
    pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_CREDIT_LIMIT_CW;

    pCrdtLimitReq->intFuncId = FUNC_ID_SBFCCP_ORDERCANCEL_BYCW;
    strcpy(pCrdtLimitReq->strUserId, sUserId.c_str());
    strcpy(pCrdtLimitReq->strToken, sToken.c_str());
    pCrdtLimitReq->intOrgId = atoi(sOrgId.c_str());
    pCrdtLimitReq->intCrdtAmnt = atof(strLimit_value.c_str()) * pow10(FIGURES_OF_CREDIT_AMOUNT_SBFCCP);

    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnSBFCCP_LimitPositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnSBFCCP_LimitPositionStop");
    ResCodeT rc = NO_ERR;

    // 默认的返回值定义
    int nRet = APP_CODE_SUCCESS;

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/

    // 定义应答消息
    SecurityDefinition* pRspMessage = new SecurityDefinition;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);


    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);


    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        // TODO:
        // if (DESC_LIMIT_POSITION_CANCEL_N == oRetParam.m_sDesc)
        // {
            // //限仓模式解除
            // oRetParamRst.m_sFlag = "12";
        // }

        // int nOutBoundId = oRetParam.m_nOutBoundId;
        // CCP_SBF_SendCreditLimitMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOnlineUser, oRetParam, pSendMsgList);

        // CCP_SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        // CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        // SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//撤销平仓
ResCodeT OnSBFCCP_UndoClosePositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSBFCCP_UndoClosePositionStart");
    ResCodeT rc = NO_ERR;

    SbfCcpOrdrCancelByCwReqT* pOrdrCncl = NULL;
    pOrgInfoT   pOrgInfo = NULL;

    // 消息解析
    SecurityDefinition msg;
    // 机构编号
    std::string org_id = "";
    // 市场标识
    std::string market_id = "";
    // 用户标识
    User user;
    std::string user_id = "";
    std::string token = "";
    MassMessageGrp* pMassMessageGrp;
    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    UndoClosePosition message;
    int len;
    char *out;
    size_t nLen;
    char *p;
        
    OrderCancelRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;    
    pUsrBaseInfoT pUsr = NULL;

    bool bRet = msg.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //获取子消息
    pMassMessageGrp = msg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            out = new char[len / 2 + 1];

            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            message.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            org_id = message.org_id();
            market_id = message.market_id();
            user = message.user();
            user_id = user.user_id();
            token = user.token();
        }
        else
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pOrdrCncl = (SbfCcpOrdrCancelByCwReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(SbfCcpOrdrCancelByCwReqT);
    pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_ORDER_CANCEL_CW;
    
    pOrderMsg = (OrderCancelRequestReqT*)&pOrdrCncl->orderCnclReq; 
    
    rc = IrsUsrInfoGetByNameExt((char *)user_id.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;

    strcpy(pOrderMsg->token, user.token().c_str());
    
    rc = OrgInfoGetByIdExt(atoi(org_id.c_str()), &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    pOrderMsg->orgIdx = pOrgInfo->pos;
    
    //reserve message header
    rc = ResrveReqMsg(&msg, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnSBFCCP_UndoClosePositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnSBFCCP_UndoClosePositionStop");
    ResCodeT rc = NO_ERR;

    // 默认的返回值定义
    pNewOrderSingleRspT pOrderSubmitStop = NULL;
    pSbfCcpOrdrCancelByCwRespT   pCnclRsp = NULL;

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    IMIX20::SecurityDefinition* pRspMessage = new SecurityDefinition;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    
    pCnclRsp = (pSbfCcpOrdrCancelByCwRespT)pRsp->msgBody;
    SendMessage(pSendMsgList, pRspMessage);

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        pOrderSubmitStop = (NewOrderSingleRspT*)&pCnclRsp->orderRsp;
        rc = SendClsPosnOrdrDealStsUpdtMsgToTrdr(1, pCnclRsp->orgIdx, RDP_COMPID, 
                pOrderSubmitStop->rspSlot, pOrderSubmitStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN); 
        // int nOutBoundId = oRetParam.m_nOutBoundId;

        // CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        // CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        // SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);// 客户端成交信息
        // CCP_SendDescMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOnlineUser,oRetParamRst.m_vecCrdtLmts, DESC_CLOSE_POSITION_CANCEL_STATE, pSendMsgList);    //提示消息给客户端
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//强平
ResCodeT OnSBFCCP_ClosePositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSBFCCP_ClosePositionStart");
    ResCodeT rc = NO_ERR;

    pSbfCcpOrdrSubmitByCwReqT pOrdrReq = NULL;
    pUsrBaseInfoT             pUsr = NULL;
    pOrgInfoT                 pOrgInfo = NULL;
    pCntrctBaseInfoT          pCntract = NULL;
    pNewOrderSingleReqT       pNewOrder = NULL;
    // 消息解析
    SecurityDefinition msg;
    /// 强平指令编号
    string scls_pstn_cd = "";
    /// 会员唯一编号
    string sorg_id = "";
    /// 产品类型
    MarketID market_id;
    /// 合约代码
    string scntrct_cd = "";
    /// 平仓价格
    string sordr_prc = "";
    /// 平仓金额
    string sordr_amnt = "";
    /// 挂单方向 1-买；4-卖
    string sdl_dir = "";
    /// 请求提交时间
    string sordr_exprd_tm =  "";
    User usr;
    std::string sToken = "";
    std::string sUserId = "";
    MassMessageGrp* pMassMessageGrp;
    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    ClosePosition message;
    int len;
    char *out;
    size_t nLen;
    char *p;
    
    bool bRet = msg.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    //获取子消息
    pMassMessageGrp = msg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {        
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        
        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            len = pNoMassMessage->GetMessageLen();
            //16进制转成2进制，再解析
            out = new char[len / 2 + 1];
            
            p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            message.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;
            /// 强平指令编号
            scls_pstn_cd = message.cls_pstn_cd();
            /// 会员唯一编号
            sorg_id = message.org_id();
            /// 产品类型
            market_id = message.market_id();
            /// 合约代码
            scntrct_cd = message.cntrct_cd();
            /// 平仓价格
            sordr_prc = message.ordr_prc();
            /// 平仓金额
            sordr_amnt = message.ordr_amnt();
            /// 挂单方向 1-买；4-卖
            sdl_dir = message.dl_dir();
            /// 请求提交时间
            sordr_exprd_tm = message.ordr_exprd_tm();

            // 会员信息
            usr = message.user();            //身份认证信息
            sToken = usr.token();
            sUserId = usr.user_id();
        }
    }

    
    //填充参数列表
    
 
    pOrdrReq = (SbfCcpOrdrSubmitByCwReqT*)&pReq->msgBody[0];
    pNewOrder = (NewOrderSingleReqT*)&pOrdrReq->orderReq;
    pReq->msgHdr.msgLen = sizeof(SbfCcpOrdrSubmitByCwReqT);
    pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_ORDER_SUBMIT_CW;
    pReq->msgHdr.setId = SET_MKT_SBFCCP;

    /* Get User ID*/
    // get userIdx from userId  to be done
    rc = IrsUsrInfoGetByNameExt((char *)sUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pNewOrder->newOrdrInfo.userIdx =  pUsr->pos;
    
    LOG_DEBUG("OrgId %ld, Usr %s", atoi(sorg_id.c_str()), sUserId.c_str());
    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(atoi(sorg_id.c_str()), &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    pNewOrder->newOrdrInfo.orgIdx = pOrgInfo->pos;

    strcpy(pNewOrder->token, sToken.c_str() );

    rc = IrsCntrctInfoGetByNameExt((char *)scntrct_cd.c_str(), &pCntract);
    RAISE_ERR(rc, RTN);
    pNewOrder->newOrdrInfo.contractPos = pCntract->pos;
    

    //买卖方向    
    rc = SideConvertByCw(sdl_dir, &pNewOrder->newOrdrInfo.side);
    RAISE_ERR(rc, RTN);    
    
    CnvtPriceToIntnlVal(sordr_prc, &pNewOrder->newOrdrInfo.prcQtyInfo.price);
    
    pNewOrder->newOrdrInfo.prcQtyInfo.qty = StringToInt64( sordr_amnt );
    
    //(char* pString, time_t* pTime)
    DateTimeToTimestamp((char *)sordr_exprd_tm.c_str(), &pNewOrder->newOrdrInfo.effectTime);

    pNewOrder->newOrdrInfo.ordType = ImixToIrs_OrdType(E_IMIX_ORDTP_LIMIT);
    pNewOrder->newOrdrInfo.extOrdType = pNewOrder->newOrdrInfo.ordType;
    
    rc = ExecInstConvert(EXECINST_ORD_NEW, &pNewOrder->newOrdrInfo.execInst);
    RAISE_ERR(rc, RTN);
 
    pNewOrder->newOrdrInfo.ordAction = ORDR_ACT_NEW;

    pNewOrder->newOrdrInfo.apiLoginUsrIdx = -1;
    pNewOrder->newOrdrInfo.apiRqstId = 0;

    pNewOrder->newOrdrInfo.forceId = atoi(scls_pstn_cd.c_str());
    
    rc = ResrveReqMsg(&msg, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnSBFCCP_ClosePositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnSBFCCP_ClosePositionStop");
	pSbfCcpOrdrSubmitByCwRespT pClsRsp = NULL;
    pNewOrderSingleRspT     pNewOrder = NULL;

    ResCodeT                rc = NO_ERR;
    IRS_STRING              strErrCode = "";
    IRS_STRING              strErrMsg = "";
    int32                   nApplSeqNum = 0;
    
    // oRetParamRst.m_sFlag = "13";
    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
     // 定义应答消息
    IMIX20::SecurityDefinition* pRspMessage = new SecurityDefinition;
        
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);
    

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    SendMessage(pSendMsgList, pRspMessage);

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        pClsRsp = (pSbfCcpOrdrSubmitByCwRespT)pRsp->msgBody;
        pNewOrder = (NewOrderSingleRspT*)pRsp->msgBody;
        rc = SendClsPosnOrdrDealStsUpdtMsgToTrdr(pClsRsp->forceId, pClsRsp->orgIdx, 
                    RDP_COMPID, pNewOrder->rspSlot, pNewOrder->slotCnt, 
                    pSendMsgList);
        RAISE_ERR(rc, RTN); 
        // int nOutBoundId = oRetParam.m_nOutBoundId;

        // CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        // CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        // SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
        // CCP_SBF_SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
        // CCP_SBF_SendDealMsgToTDPSToSHCH(oRetParamRst.m_vecDeals,nOutBoundId, pSendMsgList, pParamList);
        // SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);// 客户端成交信息
        // CCP_SBF_SendDealMsgToTrader(RDP_COMPID, oRetParamRst.m_vecDeals, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        // CCP_SendDescMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOnlineUser,oRetParamRst.m_vecCrdtLmts, DESC_CLOSE_POSITION_STATE, pSendMsgList);    //提示消息给客户端
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
