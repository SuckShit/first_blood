/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "METask_Client.h"
#include "METask_Comm.h"
#include "irs_code_convert.h"
#include "internal_function_def.h"
#include "internal_base_def.h"
#include "CwPb.pb.h"
#include "Enum.pb.h"
#include "XAPIPbMessage.pb.h"
#include "org_setting.h"
#include "msg_type.h"
#include "msg_bridge_update.h"
#include "api.h"

using namespace IMIX;
using namespace IMIX20;
using namespace cwpb;
using namespace constants;

ResCodeT OnBrdgInterfaceStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBrdgInterfaceStart");
    ResCodeT rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;

    DataSet message;
    int nDateType;

    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //�ͻ���    protobuf��¼�ǳ�������ʱ����
    nDateType = message.GetDataType();

    switch (nDateType)
    {
        case BRDG_DEALER_UPDATE:
            {
                //�Ž���Ա��������
                rc = OnBrdgDealerUpdateStart(message, pReq);
            }
            break;
        case BRDG_CRDT_MODIFY:
            {
                //�������޸�
                rc = OnBrdgCrdtModifyStart(message, pReq);
            }
            break;
        case BRDG_CRDT_UPDATE:
            {
                 //�����Ÿ���
                vector<BrdgCrdtUpdate> vectMsg;
                AnalyzeBrdgCreditUpdateMessage(message, vectMsg);
                // ��Ӧ�ó����£���ѭ��ֻ��ѭ��һ��
                for (int nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
                {
                    OnBrdgCrdtUpdateStart(vectMsg[nIndex], pReq, message);
                    // OnBrdgCrdtUnlockStart(vectMsg[nIndex], pParamList);
                }
            }
            break;
        case DEALAPI_TRADERPRIVIL_UPDATE:
            {
                //API����Ȩ������
                nRet = OnApiPrvlgUpdateStart(message, pReq);
            }
            break;
        default:
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            break;
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//�Ž���Ա����
ResCodeT OnBrdgDealerUpdateStart(IMIX20::DataSet& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBrdgDealerUpdateStart");
    ResCodeT rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;

    BrdgDealerUpdateReqT* pBrdgDealerUpdReq;

    int nMassSize;
    MassMessageGrp* pMassMessageGrp;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    BrdgDealerUpdate tRequest;
    int len;
    User user;

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    // std::string strFuncId="";
    // IntToString(SP_FUNCID(SP_ID_BRDG_DEALER_UPDATE), strFuncId);

    std::string sToken = "";
    std::string sUserId = "";

    IRS_STRING strBrdgDealerId = "";
    IRS_STRING strBrdgPrvlgSt = "";

    pMassMessageGrp = inMessage.GetMassMessageGrp();

    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            len = pNoMassMessage->GetMessageLen();
            tRequest.ParseFromArray(pNoMassMessage->GetMessageData(), len);

            strBrdgDealerId = tRequest.brdgdealer();
            strBrdgPrvlgSt = tRequest.brdgprvlgst();

            user = tRequest.user();
            sUserId = user.user_id();
            sToken = user.token();
        }
        else
        {
            // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            // return APP_CODE_INCOM_PARAM_ERROR;
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }
    }
    else
    {
        // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        // return APP_CODE_INCOM_PARAM_ERROR;
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pBrdgDealerUpdReq = (BrdgDealerUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(BrdgDealerUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_BRIDGE_DEALER_UPDATE;

    pBrdgDealerUpdReq->intFuncId = FUNC_ID_BRDG_DEALER_UPDATE;
    strcpy(pBrdgDealerUpdReq->strUserId, sUserId.c_str());
    strcpy(pBrdgDealerUpdReq->strToken, sToken.c_str());
    pBrdgDealerUpdReq->intBrdgPrvlgSt = atoi(strBrdgPrvlgSt.c_str());
    strcpy(pBrdgDealerUpdReq->strBrdgDealer, strBrdgDealerId.c_str());

    //reserve message header
    rc = ResrveReqMsg(&inMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnBrdgDealerUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBrdgDealerUpdateStop");
    ResCodeT rc = NO_ERR;
    // Ĭ�ϵķ���ֵ����
    int nRet = APP_CODE_SUCCESS;

    BrdgDealerUpdateRespT* pBrdgDealerUpdResp;

    /*---------------------------------------
    **********    ��ʱ���� ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/
    // ����Ӧ����Ϣ
    DataSet* pRspMessage = new DataSet;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);


    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    pBrdgDealerUpdResp = (BrdgDealerUpdateRespT*)pRsp->msgBody;

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        // TODO:
        // int nOutBoundId = oRetParam.m_nOutBoundId;
        // SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//�Ž������޸�
ResCodeT OnBrdgCrdtModifyStart(IMIX20::DataSet& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBrdgCrdtModifyStart");
    ResCodeT rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;

    BrdgCreditModifyReqT* pBrdgCrdtMdfyReq;

    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    BrdgCrdtModify tRequest;
    User user;
    int len;

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    std::string sToken = "";
    std::string sUserId = "";

    MassMessageGrp* pMassMessageGrp = inMessage.GetMassMessageGrp();

    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {

            len = pNoMassMessage->GetMessageLen();
            tRequest.ParseFromArray(pNoMassMessage->GetMessageData(), len);

            user = tRequest.user();
            sUserId = user.user_id();
            sToken = user.token();
        }
        else
        {
            // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            // return APP_CODE_INCOM_PARAM_ERROR;
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }
    }
    else
    {
        // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        // return APP_CODE_INCOM_PARAM_ERROR;
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }


    pBrdgCrdtMdfyReq = (BrdgCreditModifyReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(BrdgCreditModifyReqT);
    pReq->msgHdr.msgType = MSG_TYPE_BRIDGE_CREDIT_MODIFY;

    pBrdgCrdtMdfyReq->intFuncId = FUNC_ID_BRDG_CRDT_MODIFY;
    strcpy(pBrdgCrdtMdfyReq->strUserId, sUserId.c_str());
    strcpy(pBrdgCrdtMdfyReq->strToken, sToken.c_str());

    //reserve message header
    rc = ResrveReqMsg(&inMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnBrdgCrdtModifyStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBrdgCrdtModifyStop");
    ResCodeT rc = NO_ERR;
    // Ĭ�ϵķ���ֵ����
    int nRet = APP_CODE_SUCCESS;

    BrdgCreditModifyRespT* pBrdgCrdtMdfyResp;

    /*---------------------------------------
    **********    ��ʱ���� ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/

    // ����Ӧ����Ϣ
    DataSet* pRspMessage = new DataSet;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);


    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    pBrdgCrdtMdfyResp = (BrdgCreditModifyRespT*)pRsp->msgBody;

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        // TODO:
        // int nOutBoundId = oRetParam.m_nOutBoundId;
        // SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//�����Ÿ���
ResCodeT OnBrdgCrdtUpdateStart(const cwpb::BrdgCrdtUpdate& inMessage, IntrnlMsgT* pReq, IMIX20::DataSet& orginMessage)
{
    BEGIN_FUNCTION("OnBrdgCrdtUpdateStart");
    ResCodeT rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;

    BrdgCreditUpdateReqT* pBrdgCrdtUpdReq;

    BrdgCrdtLimit crdtLimit;
    int nCrdtSize;
    IRS_STRING strOpOrgId;
    IRS_STRING strCrdtRlf;
    IRS_STRING strBrdgFee;
    IRS_STRING strTerm;
    int32 intMdfyFlag = 0;

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/

    User user = inMessage.user();

    std::string sToken = user.token();
    std::string sUserId = user.user_id();

    pBrdgCrdtUpdReq = (BrdgCreditUpdateReqT*)&pReq->msgBody[0];

    pReq->msgHdr.msgLen = sizeof(BrdgCreditUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_BRIDGE_CREDIT_UPDATE;

    pBrdgCrdtUpdReq->intFuncId = FUNC_ID_BRDG_CRDT_UPDATE;
    strcpy(pBrdgCrdtUpdReq->strUserId, sUserId.c_str());
    strcpy(pBrdgCrdtUpdReq->strToken, sToken.c_str());

    nCrdtSize = inMessage.crdtlimits_size();

    /* ���������ѡ�е����ݸ���������Ϣ�����ɵ����������򱨴����� */
    if (nCrdtSize > BRIDGE_CREDIT_INFO_MAX_COUNT){
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    if (nCrdtSize > 0)
    {
        intMdfyFlag = 1;
    }

    for (int i = 0; i < nCrdtSize; i++)
    {
        crdtLimit = inMessage.crdtlimits(i);

        strOpOrgId = crdtLimit.oporgid();    //���ַ�����id
        strCrdtRlf = crdtLimit.crdtrlf();    //��ϵ
        strBrdgFee = crdtLimit.brdgfee();    //�ŷ�
        strTerm = crdtLimit.term();            //����

        //���ַ�����ID
        pBrdgCrdtUpdReq->brdgCrdtInfo[i].intOpOrgId = atoi(strOpOrgId.c_str());
        //��ϵ
        pBrdgCrdtUpdReq->brdgCrdtInfo[i].intCrdtRlf = atoi(strCrdtRlf.c_str());
        //�ŷ�
        strcpy(pBrdgCrdtUpdReq->brdgCrdtInfo[i].strBrdgFee, strBrdgFee.c_str());
        //�����
        pBrdgCrdtUpdReq->brdgCrdtInfo[i].intTerm = atoi(strTerm.c_str());

    }

    // brdgCrdtInfo��ʵ�ʸ���
    pBrdgCrdtUpdReq->intInfoCount = nCrdtSize;
    // �Ƿ����޸�
    pBrdgCrdtUpdReq->intMdfyF = intMdfyFlag;


    //reserve message header
    rc = ResrveReqMsg(&orginMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnBrdgCrdtUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBrdgCrdtUpdateStop");
    ResCodeT rc = NO_ERR;
    // Ĭ�ϵķ���ֵ����
    int nRet = APP_CODE_SUCCESS;

    BrdgCreditUpdateRespT* pBrdgCrdtUpdResp;

    /*---------------------------------------
    **********    ��ʱ���� ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/

    // ����Ӧ����Ϣ
    DataSet* pRspMessage = new DataSet;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);


    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    pBrdgCrdtUpdResp = (BrdgCreditUpdateRespT*)pRsp->msgBody;

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        // TODO:
        // int nOutBoundId = oRetParam.m_nOutBoundId;
        // SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


// ����Mass��Ϣ
ResCodeT AnalyzeBrdgCreditUpdateMessage(IMIX20::DataSet& inMsg, vector<cwpb::BrdgCrdtUpdate>& vectSubMsg)
{
    BEGIN_FUNCTION("AnalyzeBrdgCreditUpdateMessage");
    ResCodeT rc = NO_ERR;

    int nMassSize;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    BrdgCrdtUpdate creditUpate;
    int len;

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp = inMsg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();

        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nMassSize + IMIX_GRP_INDEX_BEGIN; ++nIndex)
        {
            pNoMassMessage = pMassMessageGrp->GetNoMassMessage(nIndex);
            if (NULL != pNoMassMessage)
            {

                len = pNoMassMessage->GetMessageLen();
                creditUpate.ParseFromArray(pNoMassMessage->GetMessageData(), len);

                vectSubMsg.push_back(creditUpate);
            }
            else
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }
        }
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//API����Ȩ������
ResCodeT OnApiPrvlgUpdateStart(IMIX20::DataSet& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiPrvlgUpdateStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiPrvlgUpdateStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    int nRet = APP_CODE_SUCCESS;

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    std::string strFuncId="";
    IntToString(FUNC_ID_TRADERPRIVILCONFIG, strFuncId);

    std::string sToken = "";
    std::string sUserId = "";
    IRS_STRING strApiUserId = "";//����������Աid ����ǰ̨�û�����������userid���һ��
    IRS_STRING  strAppId = "";  //ǰ̨1 �к�̨2
    IRS_STRING strPrvlgFlag = "";   //�ᵥȨ�ޱ�־��ö��ֵ��1-�ͻ��ˣ�2-API
    IRS_STRING strPrvlgMdfFlag = "";//�ᵥȨ���޸ı�־��ǰ̨�û��Ƿ�����޸ģ���ö��ֵ��0-��1-��
    IRS_STRING strPrvlgFlag_sirs = "";  //�ᵥȨ�ޱ�־��ö��ֵ��1-�ͻ��ˣ�2-API
    IRS_STRING strPrvlgMdfFlag_sirs = "";//�ᵥȨ���޸ı�־��ǰ̨�û��Ƿ�����޸ģ���ö��ֵ��0-��1-��
    IRS_STRING strPrvlgFlag_sbfccp = "";    //�ᵥȨ�ޱ�־��ö��ֵ��1-�ͻ��ˣ�2-API
    IRS_STRING strPrvlgMdfFlag_sbfccp = "";//�ᵥȨ���޸ı�־��ǰ̨�û��Ƿ�����޸ģ���ö��ֵ��0-��1-��

    MassMessageGrp* pMassMessageGrp = inMessage.GetMassMessageGrp();

    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            TraderPrivilUpdateRequest tRequest;
            int len = pNoMassMessage->GetMessageLen();
            tRequest.ParseFromArray(pNoMassMessage->GetMessageData(), len);

            strAppId = tRequest.appid();
            strApiUserId = tRequest.traderid();
            strPrvlgFlag = tRequest.ordr_prvlg_f();
            if (tRequest.has_ordr_prvlg_mdfy_f())
            {
                strPrvlgMdfFlag = tRequest.ordr_prvlg_mdfy_f();
            }

            strPrvlgFlag_sirs = tRequest.ordr_prvlg_f_sirs();
            if (tRequest.has_ordr_prvlg_mdfy_f_sirs())
            {
                strPrvlgMdfFlag_sirs = tRequest.ordr_prvlg_mdfy_f_sirs();
            }

            strPrvlgFlag_sbfccp = tRequest.ordr_prvlg_f_sbfccp();
            if (tRequest.has_ordr_prvlg_mdfy_f_sbfccp())
            {
                strPrvlgMdfFlag_sbfccp = tRequest.ordr_prvlg_mdfy_f_sbfccp();
            }


            User user = tRequest.user();
            sUserId = user.user_id();
            sToken = user.token();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    // ��ѯ������־��ӡ
    LOG_INFO("[%d] In condition:strFuncId = %s, sToken = %s, sUserId = %s, strApiUserId = %s, strAppId = %s, strPrvlgFlag = %s, strPrvlgMdfFlag = %s\
            strPrvlgFlag_sirs = %s, strPrvlgMdfFlag_sirs = %s, strPrvlgFlag_sbfccp = %s, strPrvlgMdfFlag_sbfccp = %s",
            FUNC_ID_TRADERPRIVILCONFIG, strFuncId.c_str(), sToken.c_str(), sUserId.c_str(), strApiUserId.c_str(), strAppId.c_str(), strPrvlgFlag.c_str(), strPrvlgMdfFlag.c_str(),
            strPrvlgFlag_sirs.c_str(), strPrvlgMdfFlag_sirs.c_str(), strPrvlgFlag_sbfccp.c_str(), strPrvlgMdfFlag_sbfccp.c_str());


    // SP���
    ApiTradePrivilConfigReqT* pApiReq;
    pApiReq = (ApiTradePrivilConfigReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(ApiTradePrivilConfigReqT));
    pReq->msgHdr.msgLen = sizeof(ApiTradePrivilConfigReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_TRADER_PRIVIL_CONFIG;

    pApiReq->iFuncId = FUNC_ID_TRADERPRIVILCONFIG;
    strcpy(pApiReq->strToken, sToken.c_str());
    strcpy(pApiReq->strUsrId, sUserId.c_str());
    strcpy(pApiReq->strTrdId, strApiUserId.c_str());
    pApiReq->iAppId = atoi(strAppId.c_str());
    pApiReq->iOrdrPrvlgFlag = atoi(strPrvlgFlag.c_str());
    pApiReq->iOrdrPrvlgMdfyFlag = atoi(strPrvlgMdfFlag.c_str());
    pApiReq->iOrdrPrvlgFlagSirs = atoi(strPrvlgFlag_sirs.c_str());
    pApiReq->iOrdrPrvlgMdfyFlagSirs = atoi(strPrvlgMdfFlag_sirs.c_str());
    pApiReq->iOrdrPrvlgFlagSbfccp = atoi(strPrvlgFlag_sbfccp.c_str());
    pApiReq->iOrdrPrvlgMdfyFlagSbfccp = atoi(strPrvlgMdfFlag_sbfccp.c_str());

    //reserve message header
    rc = ResrveReqMsg(&inMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnApiPrvlgUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiPrvlgUpdateStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiPrvlgUpdateStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());


    IRS_STRING          strErrCode = "";
    IRS_STRING          strErrMsg = "";

    // ����Ӧ����Ϣ
    DataSet* pRspMessage = new DataSet;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);


    // ���͵ǳ�Ӧ����Ϣ
    SendMessage(pSendMsgList, pRspMessage);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}
