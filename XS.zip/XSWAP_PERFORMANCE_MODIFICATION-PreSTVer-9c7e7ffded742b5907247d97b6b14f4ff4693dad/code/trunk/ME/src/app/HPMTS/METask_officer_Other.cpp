/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "METask_Officer.h"
#include "METask_Comm.h"
#include "irs_code_convert.h"
#include "internal_base_def.h"
#include "msg_market_info_update.h"
#include "msg_credit.h"
#include "org_setting.h"
#include "usr.h"
#include "msg_type.h"
#include "org_info.h"

using namespace IMIX;
using namespace IMIX20;

// 机构禁用/解禁
ResCodeT OnBankFreezeStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBankFreezeStart ");
    ResCodeT                rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;
    int nSize, nSize2;
    //功能标识
    IRS_STRING strFuncId = "";
    //用户标识
    IRS_STRING strUserId = "";
    //Token
    IRS_STRING strToken = "";
    //机构标识（被处理的机构）
    IRS_STRING strOrgId = "";
    //请求类型
    IRS_STRING strRqstTp = "";

    UsrBaseInfoT usr;    
    PartyDetailsListReportReqT*  pSetting = NULL; 
    
    PartyDetailGrp* pPartyDetailGrp;
    PartyDetailGrp::NoPartyDetails* pNoPartyDetails;
    RelatedPartyDetailGrp* pRelatedPartyDetailGrp;
    RelatedPartyDetailGrp::NoRelatedPartyDetails * pNoRelatedPartyDetails;
    OrgInfoT org;
    
    // 消息解析
    PartyDetailsListReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                获取消息字段
    *************************************/
    strToken = message.GetApplToken();
    pPartyDetailGrp = message.GetPartyDetailGrp();
    if (pPartyDetailGrp)
    {
        nSize = pPartyDetailGrp->GetNoPartyDetails_Num();
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex< nSize + IMIX_GRP_INDEX_BEGIN; ++nIndex)
        {
            pNoPartyDetails = pPartyDetailGrp->GetNoPartyDetails(nIndex);
            if (pNoPartyDetails)
            {
                if (E_PARTY_DETAIL_ROLE_MODIFY_ORG == pNoPartyDetails->GetPartyDetailRole())
                {
                    strOrgId = pNoPartyDetails->GetPartyDetailID(); //机构标识（被处理的机构)
                    IntToString(pNoPartyDetails->GetPartyDetailStatus(),strRqstTp); //请求类型
                }

                pRelatedPartyDetailGrp = pNoPartyDetails->GetRelatedPartyDetailGrp();
                if (pRelatedPartyDetailGrp)
                {
                    nSize2 = pRelatedPartyDetailGrp->GetNoRelatedPartyDetails_Num();
                    for (int nIndex2 = IMIX_GRP_INDEX_BEGIN; nIndex2< nSize2 + IMIX_GRP_INDEX_BEGIN; ++nIndex2)
                    {
                        pNoRelatedPartyDetails = pRelatedPartyDetailGrp->GetNoRelatedPartyDetails();
                        if (pNoRelatedPartyDetails)
                        {
                            if (E_PARTY_DETAIL_ROLE_USER == pNoRelatedPartyDetails->GetRelatedPartyDetailRole())
                                strUserId = pNoRelatedPartyDetails->GetRelatedPartyDetailID();
                        }
                    }
                }                
            }
        }
    }
    
    pSetting = (PartyDetailsListReportReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen  = sizeof(PartyDetailsListReportReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORG_BANK_FREEZE;  
    pSetting->iFuncId    = FUNC_ID_ORG_FREEZE;    

    memcpy(pSetting->strUserId, strUserId.c_str(), sizeof(pSetting->strUserId));
    memcpy(pSetting->strToken, strToken.c_str(), sizeof(pSetting->strToken)); 
    memcpy(pSetting->strOrgId, strOrgId.c_str(), sizeof(pSetting->strOrgId)); 
    pSetting->rqstType = StringToInt(strRqstTp);

    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnBankFreezeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBankFreezeStop");
    ResCodeT                rc = NO_ERR;
    NewOrderSingleRspT      *pSettingRst = NULL;
    IRS_STRING              strErrCode = "";
    IRS_STRING              strErrMsg = "";
    int32                   applRefSeqNum;
    PartyDetailsListReport* pRspMessage = new PartyDetailsListReport;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {
        pSettingRst = (NewOrderSingleRspT *)pRsp->msgBody;
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pSettingRst->rspSlot,  pSettingRst->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);  
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;        
}


// 市场状态更新
ResCodeT OnUpdMktInfoStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnUpdMktInfoStart");
    ResCodeT rc = NO_ERR;

    MarketInfoUpdateReqT *pMrktInfoUpdReq;
    TradingSessionStatus message;
    
    //Token
    IRS_STRING strToken = "";
    //市场状态标识
    IRS_STRING strOpenClsId= "";
    //是否强制执行
    int32 intExecute = 0;    //0-消息来自宝宝， 1-消息来自占叔
    //市场状态编号
    IRS_STRING strMktStId = "";        //宝宝发的消息，填空
    
    bool bRet;
    
    //过虑本币消息
    IMIX::BasicMessage& tMessage = const_cast<IMIX::BasicMessage&>(inMessage);
    if ("CW" != tMessage.GetHeader()->GetCstmApplVerID())
    {
        // LOG_WARNING("message come from RMB, do nothing!");
        // return nRet;
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    // 消息解析
    bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        // LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        // return APP_CODE_INCOM_MSG_INVALID;
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                获取消息字段
    *************************************/
    strToken = message.GetApplToken();    
    IntToString(ImixToIrs_MktFlag(message.GetTradSesStatus()), strOpenClsId);

    pMrktInfoUpdReq = (MarketInfoUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(MarketInfoUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_MARKET_INFO_UPDATE;
    
    // 入参
    pMrktInfoUpdReq->intFuncId = FUNC_ID_MKTINFO_UPDATE;
    strcpy(pMrktInfoUpdReq->strToken, strToken.c_str());
    pMrktInfoUpdReq->intOpenClsId = atoi(strOpenClsId.c_str());
    pMrktInfoUpdReq->intIsExecute = intExecute;
    pMrktInfoUpdReq->intMktStCfgId = 0;
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnUpdMktInfoStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnUpdMktInfoStop");
    ResCodeT rc = NO_ERR;
    // 默认的返回值定义
    int nRet = APP_CODE_SUCCESS;    
    
    MarketInfoUpdateRespT *pMktInfoUptResp;
    
    /*---------------------------------------
    **********    临时变量 ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    bool bOutBoundStop = false;
    int32 nApplSeqNum = 0;
    // SPRET_NOMAL oRetParam;//SP的普通类型出参数据结构
    // SPRET_NOMAL oRetOutBoundParam;//OutBoundSP的普通类型出参数据结构
    // SpParamResultSet oRetParamRst;//SP结果集出参数据
    // oRetParamRst.m_sFlag = "3";
    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // TODO: 在Start方法中已经做过判断，那么在Stop中应该没有必要再次判断
    //过滤本币消息
    // if ("CW" != message.GetHeader()->GetCstmApplVerID())
    // {
        // // LOG_WARNING("message come from RMB, do nothing!");
        // // return nRet;
        // RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    // }
    
    //应答消息
    TradingSessionStatus* pRspMessage = new TradingSessionStatus();
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplToken("----");
        
    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    
    // 获取普通类型出参列表
    // pRSDataListSet = pRSnMap->GetRSDatalistSet();
    // // 获取结果集出参列表
    // pRSListSet = pRSnMap->GetRSListSet();
    // 遍历普通类型出参列表
    // if(pRSDataListSet != NULL && pRSDataListSet->size()>0)
    // {                                
        // for(itrSet = pRSDataListSet->begin(); itrSet != pRSDataListSet->end(); ++itrSet)
        // {
            // if (GetSpMktUpdNormalRet(*itrSet, oRetParam))
            // {
                // if (SP_RET_SUCCESS != oRetParam.m_nErrorCode)
                // {
                    // nRet = APP_CODE_SPRET_ERR;
                    // break;
                // }
            // }
            // else if (GetSpOutBoundMsgNormalRet(*itrSet, oRetOutBoundParam))
            // {
                // bOutBoundStop = true;
                // if (SP_RET_SUCCESS != oRetOutBoundParam.m_nErrorCode)
                // {
                    // nRet = APP_CODE_SPRET_ERR;
                    // break;
                // }
            // }
            // else if (GetSpInBoundMsgNormalRet(*itrSet, oRetParam))
            // {
                // if (SP_RET_SUCCESS != oRetParam.m_nErrorCode)
                // {
                    // nRet = APP_CODE_SPRET_ERR;
                    // break;
                // }
            // }
            // else
            // {
                // LOG_WARNING(APP_MSG_SPRET_ERR);
            // }
        // }
    // }
    // else
    // {
        // //如果获取普通出参失败，则直接返回应答消息，并返回参数出错到SPADE    
        // IntToString(APP_CODE_SPRET_ERR, strErrCode);
        // pRspMessage->SetApplErrorCode(strErrCode);
        // pRspMessage->SetApplErrorDesc(APP_MSG_SPRET_ERR);
        // SendMessage(pSendMsgList, pRspMessage);    
        // LOG_ERROR(APP_CODE_SPRET_ERR, APP_MSG_SPRET_ERR);
        // return APP_CODE_SPRET_ERR;
    // }
    
    // TODO :结果集出参列表遍历
    
    // if(pRSListSet != NULL && 
        // pRSListSet->size() > 0 &&
        // SP_RET_SUCCESS == oRetParam.m_nErrorCode)
    // {    
        // for(itrRetSet = pRSListSet->begin(); itrRetSet!=pRSListSet->end(); ++itrRetSet)
        // {
            // pRSListMap = *itrRetSet;
            // if (pRSListMap == NULL)
            // {
                // continue;
            // }
            // // 查找对应SP的结果集出参        
            // GetSpMktUpdResultSet(pRSListMap, oRetParamRst);
        // }
    // }
        
    // if (true == bOutBoundStop)
    // {
        // // 调用OutBoundMsg时，并且调用失败
        // if (SP_RET_SUCCESS != oRetOutBoundParam.m_nErrorCode)
        // {
            // IntToString(oRetOutBoundParam.m_nErrorCode, strErrCode);
            // pRspMessage->SetApplErrorCode(strErrCode);
            // pRspMessage->SetApplErrorDesc(oRetOutBoundParam.m_sErrorDesc);
            // //清空之前的消息发送列表    
            // ClearSendMsgList(pSendMsgList);    
            // SendMessage(pSendMsgList, pRspMessage);
        // }
        // else
        // {
            // if(NULL != pRspMessage)
            // {
                // delete pRspMessage;
                // pRspMessage = NULL;
            // }
        // }
    // }
    // else
    // {    
    // IntToString(oRetParam.m_nErrorCode, strErrCode);
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
        
    //本币发送的市场状态变更消息
    // if (SP_RET_SUCCESS == oRetParam.m_nErrorCode)
    if (NO_ERR == nExceptionFlag)
    {
        pMktInfoUptResp = (MarketInfoUpdateRespT*)pRsp->msgBody;
        //发送成交笔数消息
        pRspMessage->SetProduct(IMIX_PRODUCT_DERIVATIVE);
        pRspMessage->SetSecurityType(IMIX_SECURITY_TYPE_IRS);
        pRspMessage->SetTransactTime(pMktInfoUptResp->strUpdTime);
        pRspMessage->SetTotalNumDeals(pMktInfoUptResp->intTrdNum);
        pRspMessage->SetExecType(E_IMIX_DLST_OK);
        pRspMessage->SetApplErrorCode(strErrCode);
        pRspMessage->SetApplErrorDesc(strErrMsg);
        SendMessage(pSendMsgList, pRspMessage);

        //发送成交撤销数消息
        pRspMessage = new TradingSessionStatus();
        pRspMessage->SetApplRefSeqNum(nApplSeqNum);
        pRspMessage->SetProduct(IMIX_PRODUCT_DERIVATIVE);
        pRspMessage->SetSecurityType(IMIX_SECURITY_TYPE_IRS);
        rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
        RAISE_ERR(rc, RTN);
        pRspMessage->SetApplToken("----");
        pRspMessage->SetTransactTime(pMktInfoUptResp->strUpdTime);
        pRspMessage->SetTotalNumDeals(pMktInfoUptResp->intTrdCancelNum);
        pRspMessage->SetExecType(E_IMIX_DLST_CANCEL);
        pRspMessage->SetApplErrorCode(strErrCode);
        pRspMessage->SetApplErrorDesc(strErrMsg);
        SendMessage(pSendMsgList, pRspMessage);

        uint64 nOutBoundId = pMktInfoUptResp->intMaxOutBoundId;
        //发送市场状态变更通知给每个登录用户
        // SendMktStatusToOnlineUser(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOnlineUser, oRetParam, pSendMsgList, nOutBoundId, pParamList);
        // //发送市场价格到TDPS            
        // SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecOrders, pSendMsgList);
        // SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        // SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        // SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        // SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SBF_vecOrders, pSendMsgList);
        // CCP_SIRS_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_SIRSCCP_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        
        // CCP_SBF_SendOrderStatusUpdateMsgToTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        // CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        // SendMaketDataMsgToTDPS(oRetParamRst.m_vecContractPrice, nOutBoundId, pSendMsgList, pParamList);    
        // SendMaketStatusMsgToTDPS(oRetParam, nOutBoundId, pSendMsgList, pParamList);

        // SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRSCCP_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        // SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);
        // SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        // SendMaketDataMsgToTDPSToOutside(IMIX_SECURITY_TYPE_IRS,oRetParamRst.m_vecSIRSSttlemntInfo, nOutBoundId, pSendMsgList, pParamList);
        // SendMaketDataMsgToTDPSToOutside(IMIX_SECURITY_TYPE_SBFWD,oRetParamRst.m_vecSBFSttlemntInfo, nOutBoundId, pSendMsgList, pParamList);
        // SendMaketDataMsgToTDPSToOutside(IMIX_SECURITY_TYPE_IRS,oRetParamRst.m_vecSIRSCCPSttlemntInfo, nOutBoundId, pSendMsgList, pParamList);
        // SendMaketDataMsgToTDPSToOutside(IMIX_SECURITY_TYPE_SBFWD,oRetParamRst.m_vecSBFCCPSttlemntInfo, nOutBoundId, pSendMsgList, pParamList);
        
        // SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
    }
    else
    {
        pRspMessage->SetApplErrorCode(strErrCode);
        pRspMessage->SetApplErrorDesc(strErrMsg);
        SendMessage(pSendMsgList, pRspMessage);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 授信更新方式设置
ResCodeT OnCreditRefreshMethodUpdateStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBankFreezeStart ");
    ResCodeT rc = NO_ERR;

    CreditRefreshMethodUpdateReqT* pCreditRefreshMethodUpdateMsg;
    /************************************
                获取消息字段
    *************************************/
    //功能标识
//    IRS_STRING strFuncId = "";
    //用户标识
    IRS_STRING strUserId = "";
    ///token
    IRS_STRING strToken = "";
    //机构标识
    IRS_STRING strOrgId = "";
    //额度更新方式
    IRS_STRING strUpdMthd = "";

    // 消息解析
    PartyRiskLimitsDefinitionRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

//    IntToString(SP_FUNCID(SP_ID_CREDIT_REFMETHOD_UPDATE),strFuncId);
    strToken = message.GetApplToken();//token
    
    RequestingPartyGrp * pRequestingPartyGrp = message.GetRequestingPartyGrp();
    if (pRequestingPartyGrp) {
        int nSize = pRequestingPartyGrp->GetNoRequestingPartyIDs_Num();
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex<nSize + IMIX_GRP_INDEX_BEGIN; ++nIndex) {
            RequestingPartyGrp::NoRequestingPartyIDs * pNoRequestingPartyIDs = pRequestingPartyGrp->GetNoRequestingPartyIDs(nIndex);
            if (pNoRequestingPartyIDs) {
                if (E_PARTY_DETAIL_ROLE_USER == pNoRequestingPartyIDs->GetRequestingPartyRole()) {
                    strUserId = pNoRequestingPartyIDs->GetRequestingPartyID();//用户标识
                }
            }
        }
    }
    
    PartyRiskLimitsUpdateGrp * pPartyRiskLimitsUpdateGrp = message.GetPartyRiskLimitsUpdateGrp();
    if (pPartyRiskLimitsUpdateGrp != NULL) {
        int nSize = pPartyRiskLimitsUpdateGrp->GetNoPartyRiskLimits_Num();
        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex<nSize + IMIX_GRP_INDEX_BEGIN; ++nIndex) {
            PartyRiskLimitsUpdateGrp::NoPartyRiskLimits * pNoPartyRiskLimits = pPartyRiskLimitsUpdateGrp->GetNoPartyRiskLimits(nIndex);
            if (pNoPartyRiskLimits != NULL) {
                PartyDetailGrp * pPartyDetailGrp = pNoPartyRiskLimits->GetPartyDetailGrp();
                if (pPartyDetailGrp != NULL) {
                    int nSize2 = pPartyDetailGrp->GetNoPartyDetails_Num();
                    for (int nIndex2 = IMIX_GRP_INDEX_BEGIN; nIndex2<nSize2 + IMIX_GRP_INDEX_BEGIN; ++nIndex2) {
                        PartyDetailGrp::NoPartyDetails * pNoPartyDetails =  pPartyDetailGrp->GetNoPartyDetails(nIndex2);
                        if (pNoPartyDetails->GetPartyDetailRole() == E_PARTY_DETAIL_ROLE_MODIFY_ORG) {
                            strOrgId = pNoPartyDetails->GetPartyDetailID(); //机构标识
                        }
                    }
                }

                RiskLimitsGrp * pRiskLimitsGrp = pNoPartyRiskLimits->GetRiskLimitsGrp();
                if (pRiskLimitsGrp != NULL) {
                    RiskLimitsGrp::NoRiskLimits * pNoRiskLimitTypes = pRiskLimitsGrp->GetNoRiskLimits();
                    if (pNoRiskLimitTypes != NULL) {
                        RiskLimitTypesGrp * pRiskLimitTypesGrp = pNoRiskLimitTypes->GetRiskLimitTypesGrp();
            
                        if (pRiskLimitTypesGrp != NULL) {
                            RiskLimitTypesGrp::NoRiskLimitTypes * pNoRiskLimitTypes = pRiskLimitTypesGrp->GetNoRiskLimitTypes();
                            strUpdMthd = pNoRiskLimitTypes->GetRiskLimitAmountUpdateMethod();
                        }
                    }
                }
            }
        }
    }

    // 输入信息打印日志打印
    LOG_INFO("[%d] In condition: strUserId = %s, strToken = %s, strOrgId = %s, strUpdMthd = %s",
                FUNC_ID_CREDIT_REFMETHOD_UPDATE, strUserId.c_str(), strToken.c_str(), 
                strOrgId.c_str(), strUpdMthd.c_str());

    pCreditRefreshMethodUpdateMsg = (CreditRefreshMethodUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(CreditRefreshMethodUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE;
    
    // SP入参
    pCreditRefreshMethodUpdateMsg->iFuncId = FUNC_ID_CREDIT_REFMETHOD_UPDATE;    //机能标识
    strcpy(pCreditRefreshMethodUpdateMsg->strUserId, strUserId.c_str());        //用户标识
    strcpy(pCreditRefreshMethodUpdateMsg->strToken,  strToken.c_str());            //Token
    strcpy(pCreditRefreshMethodUpdateMsg->strOrgId,  strOrgId.c_str());            //授信机构标识
    pCreditRefreshMethodUpdateMsg->iUpdMthd = atoi(strUpdMthd.c_str());            //额度更新方式

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnCreditRefreshMethodUpdateStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag)
{
    BEGIN_FUNCTION("OnCreditRefreshMethodUpdateStop");
    ResCodeT rc = NO_ERR;

    CreditRefreshMethodUpdateRespT *pCreditRefreshMethodUpdateResp;
    /*---------------------------------------
    **********    临时变量 ***************
    ----------------------------------------*/
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    /*---------------------------------------
    ************ 应答消息初始化 ************
    ---------------------------------------*/
    // 定义应答消息
    PartyRiskLimitsReport* pRspMessage = new PartyRiskLimitsReport();
    int32 applRefSeqNum = 0;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    pRspMessage->SetApplToken("----");

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    // 设置应答的结果码和结果描述信息，发送应答消息
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);

    //框架执行SP返回失败
    if (NO_ERR != nExceptionFlag) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    else {
        pCreditRefreshMethodUpdateResp = (CreditRefreshMethodUpdateRespT*)pRsp->msgBody;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
