/***
Created on Sep 13, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */

/* Project Header File */
#include "METask_Comm.h"
#include "METask_API_Comm.h"
//#include "SPTask_CallSubSp.h"
#include "irs_code_convert.h"
//#include "UTILITY/base64.h"
//#include <vector>
#include "XAPIPbMessage.pb.h"
#include "METask_Clear_Account.h"
#include "login.h"
#include "api.h"

using namespace IMIX;
using namespace IMIX20;
using namespace xapi;



ResCodeT OldSetRespMsgHeader(IMIX::BasicMessage* pReqMessage, IMIX::BasicMessage* pRspMessage)
{
    BEGIN_FUNCTION("OldSetRespMsgHeader");
    ResCodeT                rc = NO_ERR;

    if (NULL == pReqMessage || NULL == pRspMessage)
    {
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    pRspMessage->GetHeader()->SetTargetCompID(pReqMessage->GetHeader()->GetSenderCompID());
    pRspMessage->GetHeader()->SetTargetSubID(pReqMessage->GetHeader()->GetSenderSubID());
    pRspMessage->GetHeader()->SetDeliverToSubID(pReqMessage->GetHeader()->GetOnBehalfOfSubID());
    pRspMessage->GetHeader()->SetDeliverToCompID(pReqMessage->GetHeader()->GetOnBehalfOfCompID());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendMktMsgToApi_IRS( IRS_STRING &sFunction, IMIX20::QueryResult message, ApiLoginRespT* pRsp, SENDMSGLIST* pSendMsgList )
{
    BEGIN_FUNCTION("SendMktMsgToApi_IRS");
    ResCodeT                rc = NO_ERR;

    User* user;
    std::string strQryType;
    TradeSessionStatus marketStAck;
    IRS_STRING debugString;

    int nRet = APP_CODE_SUCCESS;
    IRS_STRING strMarketId = "X-Swap";
    int nMarketIndicator = 2;
    IRS_STRING strSecurityType = "IRS";
    //�����г�״̬��API�û�
    IMIX20::QueryResult* pMktUpdStMsg = new QueryResult;
    if (NULL == pMktUpdStMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    OldSetRespMsgHeader(&message, pMktUpdStMsg);

    IntToString(MARKET_STATUE,strQryType);
    pMktUpdStMsg->SetQueryType(strQryType);

    MassMessageGrp::NoMassMessage *pMktNoMassMsg;
    pMktNoMassMsg = pMktUpdStMsg->GetMassMessageGrp()->AddNoMassMessage();

    marketStAck.set_market_id(strMarketId.c_str());
    marketStAck.set_market_indicator(nMarketIndicator);
    marketStAck.set_inst_scope_security_type(strSecurityType.c_str());
    int nMktStatue;
    nMktStatue = pRsp->iMktStIrs;
    if (nMktStatue==6)
    {
        nMktStatue=4;
    }
    marketStAck.set_trade_session_status(IrsToImix_MktFlag(nMktStatue));
    marketStAck.set_session_start_time(pRsp->strUpdateTimeIrs);

    user = marketStAck.mutable_user();
    if (NULL == user)
    {
        delete pMktUpdStMsg;
        pMktUpdStMsg = NULL;
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    user->set_token(pRsp->strToken);
    user->set_user_id(pRsp->strUserId);
    user->set_org_id(pRsp->strOrgCd);

    LOG_INFO("[%s] send msg: strMarketId = %s, nMarketIndicator = %d, strSecurityType = %s, \
             nMktStatue = %d, start_time = %s, strUserId = %s, m_sToken = %s, strOrgCd = %s",
              "APIMKT", strMarketId.c_str(), nMarketIndicator, strSecurityType.c_str(),
             IrsToImix_MktFlag(nMktStatue), pRsp->strUpdateTimeIrs, pRsp->strUserId, pRsp->strToken, pRsp->strOrgCd);

    int len;
    len = marketStAck.ByteSize();
    char *buf;
    buf = new char[len];
    marketStAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pMktNoMassMsg->SetMessageData(p, olen);
    pMktNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;
    SendMessage(pSendMsgList, pMktUpdStMsg);

    debugString = marketStAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API marketStAck Msg[%s]", debugString.c_str());


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendMktMsgToApi_SIRS( IRS_STRING &sFunction, IMIX20::QueryResult message, ApiLoginRespT* pRsp, SENDMSGLIST* pSendMsgList )
{
    BEGIN_FUNCTION("SendMktMsgToApi_SIRS");
    ResCodeT                rc = NO_ERR;

    User* user;
    std::string strQryType;
    TradeSessionStatus marketStAck;
    IRS_STRING debugString;

    int nRet = APP_CODE_SUCCESS;
    IRS_STRING strMarketId = "X-Swap";
    int nMarketIndicator = 42;
    IRS_STRING strSecurityType = "SIRS";
    //�����г�״̬��API�û�
    IMIX20::QueryResult* pMktUpdStMsg = new QueryResult;
    if (NULL == pMktUpdStMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    OldSetRespMsgHeader(&message, pMktUpdStMsg);
    IntToString(MARKET_STATUE,strQryType);
    pMktUpdStMsg->SetQueryType(strQryType);

    MassMessageGrp::NoMassMessage *pMktNoMassMsg;
    pMktNoMassMsg = pMktUpdStMsg->GetMassMessageGrp()->AddNoMassMessage();

    marketStAck.set_market_id(strMarketId.c_str());
    marketStAck.set_market_indicator(nMarketIndicator);
    marketStAck.set_inst_scope_security_type(strSecurityType.c_str());

    int nMktStatue;
    nMktStatue = pRsp->iMktState;
    marketStAck.set_trade_session_status(IrsToImix_MktFlag(nMktStatue));
    marketStAck.set_session_start_time(pRsp->strUpdateTime);
    marketStAck.set_clearingmethod(13);

    user = marketStAck.mutable_user();
    if (NULL == user)
    {
        delete pMktUpdStMsg;
        pMktUpdStMsg = NULL;
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    user->set_token(pRsp->strToken);
    user->set_user_id(pRsp->strUserId);
    user->set_org_id(pRsp->strOrgCd);

    LOG_INFO("[%s] send msg: strMarketId = %s, nMarketIndicator = %d, strSecurityType = %s,\
             nMktStatue = %d, start_time = %s, strUserId = %s, m_sToken = %s, strOrgCd = %s",
              "APIMKT", strMarketId.c_str(), nMarketIndicator, strSecurityType.c_str(),
             IrsToImix_MktFlag(nMktStatue), pRsp->strUpdateTime, pRsp->strUserId, pRsp->strToken, pRsp->strOrgCd);

    int len;
    len = marketStAck.ByteSize();
    char *buf;
    buf = new char[len];
    marketStAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pMktNoMassMsg->SetMessageData(p, olen);
    pMktNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;
    SendMessage(pSendMsgList, pMktUpdStMsg);

    debugString = marketStAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API marketStAck Msg[%s]", debugString.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendMktMsgToApi_SBFCCP( IRS_STRING &sFunction, IMIX20::QueryResult message, ApiLoginRespT* pRsp, SENDMSGLIST* pSendMsgList )
{
    BEGIN_FUNCTION("SendMktMsgToApi_SBFCCP");
    ResCodeT                rc = NO_ERR;

    User* user;
    std::string strQryType;
    TradeSessionStatus marketStAck;
    IRS_STRING debugString;

    int nRet = APP_CODE_SUCCESS;
    IRS_STRING strMarketId = "X-Swap";
    int nMarketIndicator = 43;
    IRS_STRING strSecurityType = "SBFWD";
    //�����г�״̬��API�û�
    IMIX20::QueryResult* pMktUpdStMsg = new QueryResult;
    if (NULL == pMktUpdStMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    OldSetRespMsgHeader(&message, pMktUpdStMsg);
    IntToString(MARKET_STATUE,strQryType);
    pMktUpdStMsg->SetQueryType(strQryType);

    MassMessageGrp::NoMassMessage *pMktNoMassMsg;
    pMktNoMassMsg = pMktUpdStMsg->GetMassMessageGrp()->AddNoMassMessage();
    marketStAck.set_market_id(strMarketId.c_str());
    marketStAck.set_market_indicator(nMarketIndicator);
    marketStAck.set_inst_scope_security_type(strSecurityType.c_str());
    //if (IMIX_MKT_TYPE_IRS != nMarketIndicator)
    //{
    //  marketStAck.set_clearingmethod(nClearingMethod);
    //}

    int nMktStatue;
    nMktStatue = pRsp->iMktState;
    marketStAck.set_trade_session_status(IrsToImix_MktFlag(nMktStatue));
    marketStAck.set_session_start_time(pRsp->strUpdateTime);
    marketStAck.set_clearingmethod(6);

    user = marketStAck.mutable_user();
    if (NULL == user)
    {
        delete pMktUpdStMsg;
        pMktUpdStMsg = NULL;
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    user->set_token(pRsp->strToken);
    user->set_user_id(pRsp->strUserId);
    user->set_org_id(pRsp->strOrgCd);

    LOG_INFO("[%s] send msg: strMarketId = %s, nMarketIndicator = %d, strSecurityType = %s, \
             nMktStatue = %d, start_time = %s, strUserId = %s, m_sToken = %s, strOrgCd = %s",
              "APIMKT", strMarketId.c_str(), nMarketIndicator, strSecurityType.c_str(),
             IrsToImix_MktFlag(nMktStatue), pRsp->strUpdateTime, pRsp->strUserId, pRsp->strToken, pRsp->strOrgCd);

    int len;
    len = marketStAck.ByteSize();
    char *buf;
    buf = new char[len];
    marketStAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pMktNoMassMsg->SetMessageData(p, olen);
    pMktNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;
    SendMessage(pSendMsgList, pMktUpdStMsg);

    debugString = marketStAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API marketStAck Msg[%s]", debugString.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT API_SendLoginRspMsgToApi(IMIX20::QueryResult* pRspMessage, ApiLoginRespT* pRsp, SENDMSGLIST* pSendMsgList, int nErrCode)
{
    BEGIN_FUNCTION("API_SendLoginRspMsgToApi");
    ResCodeT                rc = NO_ERR;

    IRS_STRING sFunction = "[API_SendLoginRspMsgToApi]: ";

    TokenReply partyAck;
    std::string strQryType;
    IRS_STRING debugString;

    // ����Ӧ����Ϣ
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
//    pRspMessage->SetApplRefSeqNum(StringToInt(message.GetFieldStr(IMIX_SEQ_FIELD_NAME)));
//    SetRespMsgHeader(&message, pRspMessage);
    IntToString(TOKEN_RSP,strQryType);
    pRspMessage->SetQueryType(strQryType);

    MassMessageGrp::NoMassMessage *pNoMassMsg;
    pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    partyAck.set_user_name(pRsp->strUserId);
    partyAck.set_request_id(pRsp->strRequestId);
    if ("0" == pRspMessage->GetApplErrorCode())
    {
        partyAck.set_user_status(LOGIN_STATUS_SUCCESS);
    }
    else
    {
        partyAck.set_user_status(LOGIN_STATUS_FAIL);

        partyAck.set_user_status_text(pRspMessage->GetApplErrorDesc());
    }

    User* user;
    user = partyAck.mutable_user();
    if (NULL == user)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    user->set_token(pRsp->strToken);
    user->set_org_id(pRsp->strOrgCd);
    user->set_user_id(pRsp->strUserId);

    LOG_INFO("[%s] rsp msg: strUserId = %s, strRequestId = %s, status = %s, text = %s",
        sFunction.c_str(), pRsp->strUserId, pRsp->strRequestId, pRspMessage->GetApplErrorCode().c_str(), pRspMessage->GetApplErrorDesc().c_str());

    int len;
    len = partyAck.ByteSize();
    char *buf;
    buf = new char[len];
    partyAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pNoMassMsg->SetMessageData(p, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;

    SendMessage(pSendMsgList, pRspMessage);

    debugString = partyAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API partyAck Msg[%s]", debugString.c_str());

    if (NO_ERR == nErrCode &&
        E_USER_ROLE_API_JY == pRsp->iUserRole)
    {

        if (NO_ERR != SendMktMsgToApi_IRS(sFunction, *pRspMessage, pRsp, pSendMsgList)||
            NO_ERR != SendMktMsgToApi_SIRS(sFunction, *pRspMessage, pRsp, pSendMsgList)||
            NO_ERR != SendMktMsgToApi_SBFCCP(sFunction, *pRspMessage, pRsp, pSendMsgList))
        {

            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT API_SendLogoutRspMsgToApi(IMIX20::QueryResult* pRspMessage, ApiLogoutRespT* pRsp, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("API_SendLogoutRspMsgToApi");
    ResCodeT                rc = NO_ERR;

    IRS_STRING sFunction = "[API_SendLogoutRspMsgToApi]: ";

    LogoutReply partyAck;
    IRS_STRING debugString;


    MassMessageGrp::NoMassMessage *pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    partyAck.set_user_name(pRsp->strUserId);
    partyAck.set_request_id(pRsp->strRequestId);
    if ("0" == pRspMessage->GetApplErrorCode())
    {
        partyAck.set_user_status(LOGOUT_STATUS_SUCCESS);
    }
    else
    {
        partyAck.set_user_status(LOGOUT_STATUS_FAIL);

//        API_GetLogoutErrorDesc(oRetParam.m_nErrorCode, strErrDesc);
        partyAck.set_user_status_text(pRspMessage->GetApplErrorDesc());
    }

    User* user;
    user = partyAck.mutable_user();
    if (NULL == user)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s user is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    user->set_user_id(pRsp->strUserId);
    user->set_org_id(pRsp->strOrgCd);
    user->set_token(pRsp->strToken);

    LOG_INFO("[%s] rsp msg: strOrgCd = %s, strUserId = %s, strToken = %s, m_nErrorCode = %s, strErrDesc = %s",
        sFunction.c_str(), pRsp->strOrgCd, pRsp->strUserId, pRsp->strToken, pRspMessage->GetApplErrorCode().c_str(), pRspMessage->GetApplErrorDesc().c_str());

    int len;
    len = partyAck.ByteSize();
    char *buf;
    buf = new char[len];
    partyAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pNoMassMsg->SetMessageData(p, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;
    SendMessage(pSendMsgList, pRspMessage);

    debugString = partyAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API partyAck Msg[%s]", debugString.c_str());

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//��API���Ͷ��ķ�����Ϣ
ResCodeT API_SendSubcribeRspMsgToApi(IMIX20::QueryResult* pRspMessage, ApiSubscribeRespT* pRsp, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("API_SendSubcribeRspMsgToApi");
    ResCodeT                rc = NO_ERR;

    IRS_STRING sFunction = "[API_SendSubcribeRspMsgToApi]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    int nRet = APP_CODE_SUCCESS;

    // �û�ID
    std::string strUserId = "";

    // ����CD 21λ����
    std::string strOrgCd = "";

    // token
    std::string strToken = "";

    IRS_STRING strReqId = "";
    int nMktIndicator = 0;
    IRS_STRING strMktIndicator = "";
    IRS_STRING strInstSecurityTy = "";
    int nClearMethod = 0;
    IRS_STRING strClearingMethod = "";
    int nSubTy = 0; //���ı�ʶ
    IRS_STRING strSubTyp = "";
    IRS_STRING strExecUserId = "";
    IRS_STRING strExecOrgId = "";
    IRS_STRING strSecurityId = "";//��ԼƷ��
    int nMdBookTy = -1;//��������
    IRS_STRING strMdBookTy = "";
    int nMktDepth = -1; //��λ���鵵��
    IRS_STRING strMktDepth = "";
    IRS_STRING strTm = "";

    SubscribeRequest partyUpdate;

    IRS_STRING strErrDesc = "";
    SubscribeReply partyAck;
    IRS_STRING strErrCode;
    IRS_STRING debugString;


    MassMessageGrp::NoMassMessage *pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    partyAck.set_sub_req_id(strReqId);
    partyAck.set_market_indicator(nMktIndicator);
    if (partyUpdate.has_inst_scope_security_type())
    {
        partyAck.set_inst_scope_security_type(strInstSecurityTy);
    }
    if (partyUpdate.has_clearingmethod())
    {
        partyAck.set_clearingmethod(nClearMethod);
    }
    if (partyUpdate.has_securityid())
    {
        partyAck.set_securityid(strSecurityId);
    }

    partyAck.set_subtype(nSubTy);
    partyAck.set_mdbooktype(nMdBookTy);
    partyAck.set_tran_time(strTm);

    strErrCode = pRspMessage->GetApplErrorCode();
    int iErrCode;
    iErrCode = atoi(strErrCode.c_str());
    if (NO_ERR == iErrCode)
    {
        partyAck.set_result(SUBCRIBE_STATUS_SUCCESS);
    }
    else
    {
        partyAck.set_result(SUBCRIBE_STATUS_FAIL);

        strErrDesc = pRspMessage->GetApplErrorDesc();
//        API_GetSubscribeErrorDesc(oRetParam.m_nErrorCode, strErrDesc);
        partyAck.set_text(strErrDesc.c_str());
    }

    User* user;
    user = partyAck.mutable_user();
    if (NULL == user)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s user is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }
    user->set_user_id(strUserId.c_str());
    user->set_org_id(strOrgCd.c_str());
    user->set_token(strToken.c_str());

    LOG_INFO("[%d] rsp msg: strOrgCd = %s, strUserId = %s, strToken = %s, strReqId = %s, nMktIndicator = %d, \
                strInstSecurityTy = %s, nClearMethod = %d, strSecurityId = %s, nSubTy = %d, nMdBookTy = %d, strTm = %s, m_nErrorCode = %d, strErrDesc = %s",
                FUNC_ID_API_SUBSCRIBE, strOrgCd.c_str(), strUserId.c_str(), strToken.c_str(), strReqId.c_str(), nMktIndicator,
                strInstSecurityTy.c_str(), nClearMethod, strSecurityId.c_str(), nSubTy, nMdBookTy, strTm.c_str(), iErrCode, strErrDesc.c_str());

    int len;
    len = partyAck.ByteSize();
    char *buf;
    buf = new char[len];
    partyAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pNoMassMsg->SetMessageData(p, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;

    debugString = partyAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API partyAck Msg[%s]", debugString.c_str());

    SendMessage(pSendMsgList, pRspMessage);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//��API����ȡ�����ķ�����Ϣ
ResCodeT API_SendUnSubcribeRspMsgToApi(IMIX20::QueryResult* pRspMessage, ApiUnSubscribeAllRespT* pRsp, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("API_SendUnSubcribeRspMsgToApi");
    ResCodeT                rc = NO_ERR;

    IRS_STRING sFunction = "[API_SendUnSubcribeRspMsgToApi]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    int nRet = APP_CODE_SUCCESS;

    IRS_STRING strErrCode;
    IRS_STRING strErrDesc;
    IRS_STRING debugString;
    SubscribeClearReply partyAck;

    MassMessageGrp::NoMassMessage *pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();
    if (NULL == pNoMassMsg)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    strErrCode = pRspMessage->GetApplErrorCode();
    int iErrCode;
    iErrCode = atoi(strErrCode.c_str());
    strErrDesc = pRspMessage->GetApplErrorDesc();

    LOG_INFO("[%d] rsp msg: nErrorCode = %d, strErrorDesc = %s",
                FUNC_ID_API_UNSUBSCRIBE_ALL, iErrCode, strErrDesc.c_str());

    partyAck.set_result(iErrCode);
    partyAck.set_text(strErrDesc);

    int len;
    len = partyAck.ByteSize();
    char *buf;
    buf = new char[len];
    partyAck.SerializeToArray(buf, len);
    char *out;
    out = new char[len * 2 + 1];
    size_t olen;
    char *p;
    p = ArraytoHex(buf, len, out, &olen);
    p[olen] = 0;
    pNoMassMsg->SetMessageData(p, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] buf;
    buf = NULL;
    delete[] out;
    out = NULL;

    debugString = partyAck.DebugString();
    replace(debugString.begin(), debugString.end(), '\n', ' ');
    LOG_DEBUG("API partyAck Msg[%s]", debugString.c_str());

    SendMessage(pSendMsgList, pRspMessage);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT GetCrdtTerm(const IRS_STRING& srcTerm, IRS_STRING& strTerm)
{
    BEGIN_FUNCTION("GetCrdtTerm");
    ResCodeT rc = NO_ERR;

    if ("Y1" == srcTerm)
    {
        strTerm = "1";
    }
    else if ("Y2" == srcTerm)
    {
        strTerm = "2";
    }
    else if ("Y3" == srcTerm)
    {
        strTerm = "3";
    }
    else if ("Y4" == srcTerm)
    {
        strTerm = "4";
    }
    else if ("Y5" == srcTerm)
    {
        strTerm = "5";
    }
    else if ("Y6" == srcTerm)
    {
        strTerm = "6";
    }
    else if ("Y7" == srcTerm)
    {
        strTerm = "7";
    }
    else
    {
        LOG_DEBUG("GetCrdtTerm invalid!");
        strTerm = "0";
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
