/***
Created on Aug 09, 2017
@author: Xiaoping Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "db_comm.h"
#include "uti_tool.h"

#include "base_param.h"
#include "BaseParamDb.h"
#include "mkt_st_cfg.h"
#include "MktStCfgDb.h"
#include "market_info_update.h"
#include "msg_market_info_update.h"
#include "pck_irs_dicdata.h"
#include "pck_irs_etl.h"
#include "pck_irs_util.h"
#include "usr_def_ref.h"
#include "ref_dat_updt.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : MarketInfoUpdate
 **
 ******************************************************************************/
ResCodeT MarketInfoUpdate(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp)
{
    BEGIN_FUNCTION( "MarketInfoUpdate" );
    ResCodeT rc = NO_ERR;

    // vectorT  keyVct[GET_BIT_VECT_LEN(11)] = {0};
    // vectorT  datVct[GET_BIT_VECT_LEN(11)] = {0};

    // vectorT  keyVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    // vectorT  datVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};

    MarketInfoUpdateReqT *pMktInfoUpdReq;
    MarketInfoUpdateRespT *pMktInfoUpdResp;
    pBaseParamT pParamData;
    char sysDateStr[10];
    char sysTimeStr[10];
    BOOL isBsnsDay;
    // MktStCfg mktStCfgData = {0};
    char sysUptDateStr[MAX_TIME_LEN];
    // char strOpenClsId[2];
    // BaseParam updData = {0};
    pBaseParamT pBaseParamData;
    pMktStCfgT pMktStCfgData;

    MktInfoDataRefT mktInfoRefData;

    int64 v_OpnClsSeq;     //开闭市信息序列号
    int32 v_MktStOld;
    int32 v_MktStIrsOld;
    int32 v_Flag;
    uint64 maxBoundId;

    pMktInfoUpdReq = (MarketInfoUpdateReqT*)&pReq->msgBody[0];
    pMktInfoUpdResp = (MarketInfoUpdateRespT*)&pRsp->msgBody[0];

    memset(pMktInfoUpdResp, 0x00, sizeof(MarketInfoUpdateRespT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
    memset(&mktInfoRefData, 0x00, sizeof(MktInfoDataRefT));

    v_OpnClsSeq = 0;

    // TODO: select Max   Table: OPEN_CLS_MKT_INFO

    /* -----------------主体过程--------------------- */
    v_OpnClsSeq = v_OpnClsSeq + 1;

    rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pParamData);
    RAISE_ERR(rc, RTN);
    v_MktStOld = atoi(pParamData->paramValue);

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);
    v_MktStIrsOld = atoi(pParamData->paramValue);

    /* Get current timestamp */
    // rc = GetSysTimestamp(&sysTimeStamp);
    // RAISE_ERR(rc, RTN);
    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);

    /* Convert the timestamp into string */
    rc = GetStrDateTime(timestamp, sysDateStr, sysTimeStr);
    RAISE_ERR(rc, RTN);

    /* Check if the current day is business day */
    isBsnsDay = FALSE;
    rc = IsBusinessDay(connId, sysDateStr, &isBsnsDay);
    RAISE_ERR(rc, RTN);


    mktInfoRefData.intMktStCfgId = pMktInfoUpdReq->intMktStCfgId;
    mktInfoRefData.intOpenClsId = pMktInfoUpdReq->intOpenClsId;
    strcpy(mktInfoRefData.strSysTime, sysUptDateStr);

    /* Initiate the update flag */
    mktInfoRefData.intMktStCfgUpdFlag = 0;
    mktInfoRefData.intBaseParamUpdFlag = 0;

    
    if (pMktInfoUpdReq->intIsExecute == 0 || isBsnsDay == TRUE){
        /* 不需要检查 或者 是交易日 */
        v_Flag = 0;
        if (pMktInfoUpdReq->intIsExecute == 1){
            // rc = GetMktStCfgByKey(connId, pMktInfoUpdReq->intMktStCfgId, &mktStCfgData);
            // RAISE_ERR(rc, RTN);
            // v_Flag = atoi(mktStCfgData.sendF);
            rc = MktStCfgGetByKeyExt(pMktInfoUpdReq->intMktStCfgId, &pMktStCfgData);
            RAISE_ERR(rc, RTN);
            v_Flag = pMktStCfgData->sendFlag;

            if ((pMktInfoUpdReq->intOpenClsId == 6 && v_MktStIrsOld == pMktInfoUpdReq->intOpenClsId) ||
                v_MktStOld == pMktInfoUpdReq->intOpenClsId)
            {
                v_Flag = 1;
            
            }else if (v_Flag == 0){
            
                mktInfoRefData.intMktStCfgUpdFlag = 1;
                
                // memset(&mktStCfgData, 0x00, sizeof(MktStCfg));
                // memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
                
                // /* Get current timestamp */
                // rc = GetCurrentTime(sysUptDateStr);
                // RAISE_ERR(rc, RTN);
                

                // mktStCfgData.mktStCfgId = pMktInfoUpdReq->intMktStCfgId;
                
                // DbCmmnSetColBit( keyVct, 0 );
                
                // strcpy(mktStCfgData.updTm, sysUptDateStr);
                // mktStCfgData.sendF[0] = '1';
                
                // DbCmmnSetColBit( datVct, 5 );
                // DbCmmnSetColBit( datVct, 8 );
                
                // rc = UpdateMktStCfgByKey(connId, &mktStCfgData, keyVct, datVct);
                // RAISE_ERR(rc, RTN);
                
                // rc = DbCmmnCommit(connId);
                // RAISE_ERR(rc, RTN);
            
            }
        
        }
        
        if (v_Flag == 0){
            
            mktInfoRefData.intBaseParamUpdFlag = 1;
            
            /* Update the table BASE_PARAM and the corresponding shared memory */
            /* Init the variables used to update the DB */
            // memset(strOpenClsId, 0x00, sizeof(strOpenClsId));
            // memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
        
            // sprintf(strOpenClsId, "%d", pMktInfoUpdReq->intOpenClsId);
                
            // /* Get current timestamp */
            // rc = GetCurrentTime(sysUptDateStr);
            // RAISE_ERR(rc, RTN);
            
            
            // /* First, update the values in the DB */
            // DbCmmnSetColBit( keyVctBaseParam, 1 );
                
            // DbCmmnSetColBit( datVctBaseParam, 2 );
            // DbCmmnSetColBit( datVctBaseParam, 5 );
            // DbCmmnSetColBit( datVctBaseParam, 6 );
            
            // /* Set the update information */
            // /* 市场状态 */
            // if (pMktInfoUpdReq->intOpenClsId != C_MKT_ST_CLOSEQT_IRS){
                // memset(&updData, 0x00, sizeof(BaseParam));
                
                // strcpy(updData.paramVl, strOpenClsId);
                // strcpy(updData.paramNm, C_MKT_ST);
                // strcpy(updData.updUsrNm, C_SYSTEM);
                // strcpy(updData.updTm, sysUptDateStr);
                
                
                // rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
                // RAISE_ERR(rc, RTN);
                // // strcpy(paramNameArray[paramIndex], C_MKT_ST);
                // // strcpy(paramValueArray[paramIndex], strOpenClsId);
                // // strcpy(updUsrArray[paramIndex], C_SYSTEM);
                // // paramIndex++;
            // }
            
            // /* 市场状态 */
            // if (pMktInfoUpdReq->intOpenClsId != C_MKT_ST_CLOSEQT){
                // memset(&updData, 0x00, sizeof(BaseParam));
                
                // strcpy(updData.paramVl, strOpenClsId);
                // strcpy(updData.paramNm, C_MKT_ST_IRS);
                // strcpy(updData.updUsrNm, C_SYSTEM);
                // strcpy(updData.updTm, sysUptDateStr);
                
                // rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
                // RAISE_ERR(rc, RTN);
                // // strcpy(paramNameArray[paramIndex], C_MKT_ST_IRS);
                // // strcpy(paramValueArray[paramIndex], strOpenClsId);
                // // strcpy(updUsrArray[paramIndex], C_SYSTEM);
                // // paramIndex++;
            // }
            
            // rc = DbCmmnCommit(connId);
            // RAISE_ERR(rc, RTN);
        
            
            // /* Second, update the values in the shared memory */
            // /* 市场状态 */
            // if (pMktInfoUpdReq->intOpenClsId != C_MKT_ST_CLOSEQT_IRS){
                // rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pBaseParamData);
                // RAISE_ERR(rc, RTN);
                // strcpy(pBaseParamData->paramValue, strOpenClsId);
            // }
            
            // /* 市场状态 */
            // if (pMktInfoUpdReq->intOpenClsId != C_MKT_ST_CLOSEQT){
                // rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pBaseParamData);
                // RAISE_ERR(rc, RTN);
                // strcpy(pBaseParamData->paramValue, strOpenClsId);
            // }
            
            // TODO: CASE WHEN different value of market status. line 829-1131
            
            
        
        }
    }
    
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_MARKET_INFO_UPDATE_DAT, &mktInfoRefData, sizeof(MktInfoDataRefT));
    RAISE_ERR(rc, RTN);
    
    
    /* 返回当前市场状态 */
    rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pBaseParamData);
    RAISE_ERR(rc, RTN);
    pMktInfoUpdResp->intMktSt = atoi(pBaseParamData->paramValue);
    
    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pBaseParamData);
    RAISE_ERR(rc, RTN);
    pMktInfoUpdResp->intMktStIrs = atoi(pBaseParamData->paramValue);
    
    if (pMktInfoUpdResp->intMktSt != v_MktStOld){
        pMktInfoUpdResp->intMktStFlag = 1;
    }
    
    if (pMktInfoUpdResp->intMktStIrs != v_MktStIrsOld){
        pMktInfoUpdResp->intMktStIrsFlag = 1;
    }
    
    
    // TODO: open cursors which consists of OUT_OUTORDINFO OUT_OUTSIRSORDINFO OUT_OUTSBFORDINFO OUT_OUTSBFCCPORDINFO
    //      OUT_OUTSIRSCCPORDINFO  OUT_BRDGORDRC  OUT_TRDSCHRSLTC_SIRS  OUT_TRDSCHRSLTC_SBF  OUT_TRDSCHRSLTC_SIRSCCP
    //      OUT_TRDSCHRSLTC_SBFCCP
    
    
    // TODO: 返回当前已成交数目
    
    // TODO: 返回当前已撤销成交数目
    
    /* 返回当前时间 */
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
                
    /* Get current timestamp */
    rc = GetCurrentTime(sysUptDateStr);
    RAISE_ERR(rc, RTN);
    
    strcpy(pMktInfoUpdResp->strUpdTime, sysUptDateStr);
    
    // TODO: 返回盘中参考价
    
    
    /* 返回BoundId */
    rc = GetBoundId(connId, &maxBoundId);
    RAISE_ERR(rc, RTN);
    pMktInfoUpdResp->intMaxOutBoundId = maxBoundId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
