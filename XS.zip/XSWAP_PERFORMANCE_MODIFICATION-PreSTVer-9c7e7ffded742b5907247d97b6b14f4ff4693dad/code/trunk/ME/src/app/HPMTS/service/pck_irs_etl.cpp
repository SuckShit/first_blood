/***
Created on Aug 15, 2017
@author: Xiaoping Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "HldyInfoDb.h"

#include "pck_irs_etl.h"
#include "pck_irs_dicdata.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : IsBusinessDay
 **
 ******************************************************************************/
ResCodeT IsBusinessDay(int32 connId, char* inDate, BOOL* isBsnsDay)
{
    BEGIN_FUNCTION("IsBusinessDay");
    ResCodeT rc = NO_ERR;
    int32 dataCnt;

    rc = GetResultCntOfHldyInfoByKey(connId, C_MKT_TP_SIRS, C_CLNDR_TP_DL, inDate, &dataCnt);
    RAISE_ERR(rc, RTN);

    if (dataCnt == 0){
        *isBsnsDay = TRUE;
    }
    else
    {
        *isBsnsDay = FALSE;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
