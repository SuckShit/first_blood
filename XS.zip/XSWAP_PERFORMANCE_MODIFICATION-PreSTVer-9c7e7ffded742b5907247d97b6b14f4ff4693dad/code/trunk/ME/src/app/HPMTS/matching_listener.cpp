/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "matching_listener.h" 
#include "IMIXT10/Message/Logon.h"
#include "IMIXT10/Comm/MessageType.h"
#include "DEP/DEPAPIErrorDef.h"
#include "msg_cache.h"
#include "msg_queue.h"
#include "shm.h"
#include "shm_name.h"
#include "METask.h"
#include "ref_data.h"
#include "cfg_lib.h"
#include "uti_tool.h"
#include "perf_stat.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MSG_SLOT_CNT     1024
#define MSG_SEC_LV_CNT   100
#define MSG_THREAD_CNT   12

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/


MatchingListener::MatchingListener(const string& FilePath)
{
    // 获取协议类型，发送数据时使用
    m_FastProtocol = string( IMIX::FastProtocol );
    m_pTimerList=new TimerList;
    m_pMEtask = new METask();
}

MatchingListener::~MatchingListener(void)
{
    BEGIN_FUNCTION("MatchingListener");
    ResCodeT                rc = NO_ERR;

    
}

int MatchingListener::CreateShm(const string& FilePath)
{
    BEGIN_FUNCTION("MatchingListener::CreateShm");
    ResCodeT                rc = NO_ERR;
    
    int32 pMsgHndl;
    void* pRoot;
    string shmPath;
    
    pPerfStatT pShmRoot = NULL;
    
    char shmName[SHM_NAME_LEN] = {0};
    
    struct cfgValueS cfgValue;
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
    
//    //performace statics shm
//    
//    rc = PerfStatShmCreate(&pShmRoot);
//    RAISE_ERR(rc, RTN);

    //create msg data shm
    rc = MsgCreate(cfgValue.iMaxMsgCacheSlotCnt, 
                        cfgValue.iMaxSecondLevelSlotCnt, 
                        cfgValue.iMaxThreadCnt);
    if (rc != NO_ERR)
    {
        TRACE("msg cache create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    //create mq shm(from ME).
    MsgQueueCfgT msgQueueCfg;
    msgQueueCfg.type = Q_TYPE_MW1R;
    msgQueueCfg.itemCnt = cfgValue.iIntrnlQueueSize;
    msgQueueCfg.itemSize = sizeof(int64);
    msgQueueCfg.threadCnt = MSG_THREAD_CNT;

    uint32 totalSize;
    rc = MsgQueueCalcSize(&msgQueueCfg, &totalSize);
    if (rc != NO_ERR)
    {
        TRACE("msg que(me to HPMTS) calculate size falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }
    
    memset(shmName,0x00, SHM_NAME_LEN);
    strcpy(shmName, SHM_MSG_CACHE_FROM_ME_SLOT_NAME);
    rc = ShmCreate(GetShmNm(shmName), totalSize, (int64**)&pRoot);
    if (rc != NO_ERR)
    {
        TRACE("msg que share memory(me to HPMTS) create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = MsgQueueCreate(&msgQueueCfg, &m_rd_msgHdl, pRoot);
    if (rc != NO_ERR)
    {
        TRACE("msg que(me to HPMTS) create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    //create msg que(to ME).
    memset(shmName,0x00, SHM_NAME_LEN);
    strcpy(shmName, SHM_MSG_CACHE_TO_ME_SLOT_NAME);
    rc = ShmCreate(GetShmNm(shmName), totalSize, (int64**)&pRoot);
    if (rc != NO_ERR)
    {
        TRACE("msg que share memory(HPMTS to me) create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = MsgQueueCreate(&msgQueueCfg, &m_wr_msgHdl, pRoot);
    if (rc != NO_ERR)
    {
        TRACE("msg que(HPMTS to me) create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    //create msg que(to event).
    memset(shmName,0x00, SHM_NAME_LEN);
    strcpy(shmName, SHM_MSG_CACHE_EVENT_SLOT_NAME);
    rc = ShmCreate(GetShmNm(shmName), totalSize, (int64**)&pRoot);
    if (rc != NO_ERR)
    {
        TRACE("msg que share memory(HPMTS to me) create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = MsgQueueCreate(&msgQueueCfg, &m_event_msgHdl, pRoot);
    if (rc != NO_ERR)
    {
        TRACE("msg que(HPMTS to me) create falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = RefDataLoadFromDB();
    if (rc != NO_ERR)
    {
        TRACE("RefDataLoadFromDB falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


int MatchingListener::DetachShm()
{
    BEGIN_FUNCTION("MatchingListener::DetachShm");
    ResCodeT                rc = NO_ERR;
    
    rc = MsgQueueDispose(m_event_msgHdl);
    if (rc != NO_ERR)
    {
        TRACE("msg que(HPMTS to me) dispose falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = MsgQueueDispose(m_wr_msgHdl);
    if (rc != NO_ERR)
    {
        TRACE("msg que(HPMTS to me) dispose falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = MsgQueueDispose(m_rd_msgHdl);
    if (rc != NO_ERR)
    {
        TRACE("msg que(me to HPMTS) dispose falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }

    rc = MsgDetach();
    if (rc != NO_ERR)
    {
        TRACE("msg cache destory falied errcode =  %lld" $$ rc);
        RAISE_ERR(rc, RTN);
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


int MatchingListener::FromApp( const IMIX::BasicMessage& msg, const DEP::Service& service)
{
    BEGIN_FUNCTION("FromApp");
    ResCodeT                rc = NO_ERR;

    rc = OnImixMEMsg(msg);
    if (rc != NO_ERR)
    {
        TRACE("OnImixMEMsg falied errcode =  %lld" $$ rc);
    }

    return 0;
}

int MatchingListener::FromAdmin(const IMIX::BasicMessage &inMessage,
                const  DEP::Service &inService )
{
    IMIX::BasicMessage &message = ( IMIX::BasicMessage &)inMessage;
    DEP::Service &service = ( DEP::Service &)inService;
    //  assert( message.GetHeader() != NULL );

    // 获取消息ID，用于判断消息类型
    std::string msgid = message.GetHeader()->GetMsgType();

    // 根据消息号进行处理,增加对不同类型消息的判断
    if ( msgid == IMIXT10::LogonMessageID )
    {

        return SendLogonMessage(service,message);
    }
    else
        if ( msgid == IMIXT10::LogoutMessageID )
        {

            return SendLogoutMessage(service,message);
        }

    return 0;
}

int MatchingListener::ToApp( const IMIX::BasicMessage& msg, const DEP::Service& service)
{
    if (&service)
    {};
    if (&msg)
    {};
    return 0;
}

int MatchingListener::ToAdmin( const IMIX::BasicMessage& msg, const DEP::Service& service)
{
    if (&service)
    {};
    if (&msg)
    {};
    return 0;
}

int MatchingListener::OnLogout( const DEP::Service& service, int type )
{
    AutoLock locker( &m_ClientMutex );

    if (type == 1)
    {};
    //1.遍历servicelist，并找到service
    //2.删除这个Service
    //printf("========= service list size: [%d]. \n", m_ServiceList.size());
    std::list<const DEP::Service*>::iterator iter;
    for(iter=m_ServiceList.begin(); iter!=m_ServiceList.end(); )
    {
        const DEP::Service* pService =  *iter;
        if (pService->GetServiceID() == service.GetServiceID())
        {
            iter = m_ServiceList.erase(iter);
        }
        else
        {
            iter++;
        }
    }

    return 0;
}

int MatchingListener::OnLogon( const DEP::Service& service)
{
    AutoLock locker( &m_ClientMutex );

    m_ServiceList.push_back(&service);
    return 0;
}

ResCodeT MatchingListener::SendLogonMessage(DEP::Service &service,
            IMIX::BasicMessage& message )
{
    BEGIN_FUNCTION("SendLogoutMessage");
    ResCodeT                rc = NO_ERR;

    IMIXT10::Logon SendMsg;
    IMIX::BasicHeader *pHeader = SendMsg.GetHeader();
    IMIX::BasicHeader *pMsgHeader = message.GetHeader();

    /**
    *构造一个登陆应答消息，当登陆消息是经过commserver转发的才需要自己回logon消息
    *m_SenderSubID和m_SenderCompID是SPADE的ID和GROUPID
    *m_TargetSubID和m_TargetCompID是SenderID
    *m_OnBehalfOfSubID和m_OnBehalfOfCompID是SPADE的ID
    *m_DeliverToSubID和m_DeliverToCompID是OnBehalfID
    */

    if (pMsgHeader->GetSenderSubID()!=pMsgHeader->GetOnBehalfOfSubID() && pMsgHeader->GetSenderSubID()!="")
    {
        pHeader->SetTargetCompID( pMsgHeader->GetSenderCompID() );
        pHeader->SetTargetSubID( pMsgHeader->GetSenderSubID() );

        pHeader->SetDeliverToCompID( pMsgHeader->GetOnBehalfOfCompID() );
        pHeader->SetDeliverToSubID( pMsgHeader->GetOnBehalfOfSubID() );

        pHeader->SetOnBehalfOfCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetOnBehalfOfSubID( pMsgHeader->GetTargetSubID() );

        pHeader->SetSenderCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetSenderSubID( pMsgHeader->GetTargetSubID() );

        // SendMsg.SetSessionStatus( LOGONSUCCESSSTATUS );
        service.Send(SendMsg);

    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MatchingListener::SendLogoutMessage(DEP::Service &service,
        IMIX::BasicMessage& message )
{
    BEGIN_FUNCTION("SendLogoutMessage");
    ResCodeT                rc = NO_ERR;

    IMIXT10::Logout SendMsg;
    IMIX::BasicHeader *pHeader = SendMsg.GetHeader();
    IMIX::BasicHeader *pMsgHeader = message.GetHeader();

    if (pMsgHeader->GetSenderSubID()!=pMsgHeader->GetOnBehalfOfSubID() && pMsgHeader->GetSenderSubID()!="")
    {
        pHeader->SetTargetCompID( pMsgHeader->GetSenderCompID() );
        pHeader->SetTargetSubID( pMsgHeader->GetSenderSubID() );

        pHeader->SetDeliverToCompID( pMsgHeader->GetOnBehalfOfCompID() );
        pHeader->SetDeliverToSubID( pMsgHeader->GetOnBehalfOfSubID() );

        pHeader->SetOnBehalfOfCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetOnBehalfOfSubID( pMsgHeader->GetTargetSubID() );

        pHeader->SetSenderCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetSenderSubID( pMsgHeader->GetTargetSubID() );

        service.Send(SendMsg);

    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

int MatchingListener::OnAccepted( const DEP::Service& )
{
    return 0;
}

ResCodeT MatchingListener::RegisterMatchingTimer(DEP::Application * InpApplication)
{
    BEGIN_FUNCTION("RegisterMatchingTimer");
    ResCodeT                rc = NO_ERR;
    
    m_pMEtask->DefineTimer(m_pTimerList);

    TimerList::iterator TimerIter;

    for(TimerIter=m_pTimerList->begin();TimerIter!=m_pTimerList->end();TimerIter++)
    {

        if (*TimerIter!=NULL)
        {
            //4. 注册Timer
            m_pServerTimer = new ServerTimer(this,0,0,(*TimerIter)->GetInterval(),(*TimerIter)->GetMsg());
            InpApplication->RegistTimer(m_pServerTimer);
            //InpApplication
        }
        else
        {
            //RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MatchingListener::OnImixMEMsg(const IMIX::BasicMessage& msg)
{
    BEGIN_FUNCTION("OnImixMEMsg");
    ResCodeT                rc = NO_ERR;
    SlotT   slot = NULL_SLOT;
    pMsgCacheSlotT pReqSlot;
    pMsgCacheSlotT pRespSlot;
    IntrnlMsgT *pReq;
    int32           maxCnt = 0, usedCnt = 0;
    LOG_DEBUG("Reserv Slot in OnImixMEMsg");
    
    PerfStatInc(ReqMsgIn);
    
    rc = MsgRsrvSlotsPaired(&slot, &pReqSlot, &pRespSlot);
    if(NOTOK(rc))
    {
         GetMsgCount(&maxCnt, &usedCnt);
         LOG_DEBUG("left msgcache cnt %ld", maxCnt-usedCnt);
    }
    RAISE_ERR(rc, RTN);
    
    pReq = (IntrnlMsgT*)&pReqSlot->msgBody;
 
  
    pReq->msgHdr.slotNo = slot;

    rc = m_pMEtask->OnMEStartPlus(msg, pReq);
    RAISE_ERR(rc, RTN);

    rc = MsgQueueWriteSlot(m_wr_msgHdl, slot);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    if (NOTOK(GET_RESCODE()) && slot != NULL_SLOT)
    {
        LOG_DEBUG("Free Slot in OnImixMEMsg");
        rc = MsgDelete(slot);
        RAISE_ERR(rc, NORTN);
    }
    RETURN_RESCODE;
}
