/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
#ifndef _METASK_OFFICER_H_
#define _METASK_OFFICER_H_

#include "internal_function_def.h"
#include "intrnl_msg.h"

// 基本参数设置
ResCodeT OnBaseParamUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);


// 授信和风险系数修改(Start)
ResCodeT OnCreditAndRiskModifyStart(
    const IMIX::BasicMessage& inMessage, 
    IntrnlMsgT* pReq);
// 授信和风险系数修改(Stop)
ResCodeT OnCreditAndRiskModifyStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag);


// 授信更新(Start)
ResCodeT OnCreditUpdateStart(
    vector<IMIX::BasicMessage> inVectMsg,
    IntrnlMsgT* pReq,
    IMIX20::DataSet& orginMessage);
// 授信更新(Stop)
ResCodeT OnCreditUpdateStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag);


// 授信更新方式设置(Start)
ResCodeT OnCreditRefreshMethodUpdateStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq);
// 授信更新方式设置(Stop)
ResCodeT OnCreditRefreshMethodUpdateStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag);


// 取消风险or授信设置(Start)
ResCodeT OnUnlockCreditStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq);
// 取消风险or授信设置(Stop)
ResCodeT OnUnlockCreditStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag);


//风险系数更新（start）
ResCodeT OnRiskCoefUpdateStart(
                    const IMIX::BasicMessage& inMessage,
                    IntrnlMsgT* pReq);


// 风险系数更新（stop）
ResCodeT OnRiskCoefUpdateStop(
                IntrnlMsgT* pRsp,
                SENDMSGLIST* pSendMsgList,
                int nExceptionFlag);


/*
// 风险系数更新
int OnRiskCoefUpdateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
// 风险系数更新解锁SP调用
int OnRiskCoefUpdateUnlockStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
// 合约参数设置
int OnContractParamUpdateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);        
// 交易撤销
int OnTrdCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList); 
*/
// 机构禁用/解禁
ResCodeT OnBankFreezeStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);

// 市场状态更新
ResCodeT OnUpdMktInfoStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq); 

ResCodeT OnBaseParamUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
int OnRiskCoefUpdateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
int OnContractParamUpdateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
int OnTrdCancelStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/
ResCodeT OnBankFreezeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);

ResCodeT OnUpdMktInfoStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

#endif
