/***
Created on Aug 24, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _BRIDGE_UPDATE_H_
#define _BRIDGE_UPDATE_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/* 桥交易员设置 */
ResCodeT BridgeDealerUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);

/* 桥授信修改 */
ResCodeT BridgeCreditModify(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);

/* 桥授信更新 */
ResCodeT BridgeCreditUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);

/* 桥授信解锁 */
// ResCodeT BridgeCreditUnlock(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int32 orgId);

/* 桥百分比设置 */
ResCodeT BridgePercentageUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);

#endif /* _BRIDGE_UPDATE_H_ */
