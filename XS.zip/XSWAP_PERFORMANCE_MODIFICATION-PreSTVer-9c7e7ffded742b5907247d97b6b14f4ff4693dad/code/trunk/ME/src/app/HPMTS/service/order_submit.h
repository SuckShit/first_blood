/***
Created on July 20, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _ORDER_SUBMIT_H_
#define _ORDER_SUBMIT_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT PrcsOrderCnclMsg(int32 msgType,pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT PrcsOrderFrzMsg(int32 msgType,pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT PrcsOrderActvtMsg(int32 msgType,pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT PrcsOrderWthdrMsg(int32 msgType,pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

ResCodeT OrderSubmitMessage(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT OrderSaveMessage(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT OrderSubmitMessageByCW(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

ResCodeT BilOrderSubmitMessage(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT BilOrderSaveMessage(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

ResCodeT OcoOrderSubmitMessage(pIntrnlMsgT pReq,pIntrnlMsgT pRsp, int64 timestamp,pCallBackCtxT pCtx);
ResCodeT OcoOrderSaveMessage(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

ResCodeT OrderExpireChkMessage(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT PrcsMktDatPush(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT PrcsBrdgOrdrTrgr(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT PrcsDealCnclReq(pIntrnlMsgT pReq,pIntrnlMsgT pRsp,int64 timestamp,pCallBackCtxT   pCtx);
#endif /* _ORDER_SUBMIT_H_ */
