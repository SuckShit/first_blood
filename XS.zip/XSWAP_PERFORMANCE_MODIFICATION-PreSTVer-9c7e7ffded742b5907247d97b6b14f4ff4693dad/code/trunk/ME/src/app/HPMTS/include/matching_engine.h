/***
Created on June 08, 2017
@author: Ming.Kong
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#pragma once

/*****************************************************************************
 **
 ** Header File
 **
 *****************************************************************************/
#include "matching_listener.h"
#include "UTILITY/Mutex.h"
#include "data_type.h"

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
#define      ENGINE_RUN_FLUG_RUN         1
#define      ENGINE_RUN_FLUG_END         0
 
typedef struct EngThreadConfigS
{
    int32       rdMsgHdl;
    int32       wrMsgHdl;
    int32       eventMsgHdl;
    int32*      pRunFlg;
} EngThreadConfigT, *pEngThreadConfigT;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
void* MatchingEngineThread(void * pConfig);
