/***
Created on Sep 11, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"
#include "internal_base_def.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "usr_def_ref.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/******************************************************************************
 **
 ** SerializeApiSbRefData
 **
 ******************************************************************************/
ResCodeT SerializeApiSbRefData(
                int32               connId,
                IntrnlMsgTypeT      eMessageType,
                int16               mktTp,
                char*               strTimestamp,
                ApiSubscribeReqT*   pApiReq
                )
{
    BEGIN_FUNCTION( "SerializeApiSbRefData" );
    ResCodeT rc = NO_ERR;

    int32 iRefSize;
    iRefSize = sizeof(ApiSubscribeDataRefT);

    ApiSubscribeDataRefT  s;
    memset(&s, 0, sizeof(ApiSubscribeDataRefT));

    s.eMessageType = eMessageType;
    s.mktTp = mktTp;
    strcpy(s.oprtTm, strTimestamp);
    if (pApiReq != NULL)
    {
        strcpy(s.strUserName, pApiReq->strUsrId);
        s.iRequestType = pApiReq->iRequestType;
        strcpy(s.strCntRctCd, pApiReq->strCntRctCd);
        s.iMdBookType = pApiReq->iMdBookType;
        s.iMarketDepth = pApiReq->iMarketDepth;
        s.iReqId = pApiReq->iReqId;
    }

    rc = ApiSubscribeDbtRef(connId, &s, iRefSize);
    RAISE_ERR(rc, RTN);

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_API_SUBSCRIBE_DAT, &s, iRefSize);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** CheckSbscribeParam
 **
 ******************************************************************************/
ResCodeT CheckSbscribeParam(
            int32               connId,
            int64               timestamp,
            ApiSubscribeReqT*   pApiReq,
            int                 iMktType,
            int                 iMktSetType
            )
{
    BEGIN_FUNCTION( "CheckSbscribeParam" );
    ResCodeT rc = NO_ERR;

    if ((pApiReq->iRequestType == 1 || pApiReq->iRequestType == 2)
        && ((pApiReq->iMdBookType == 1 && pApiReq->iMarketDepth == 0)
                || (pApiReq->iMdBookType == 105 && pApiReq->iMarketDepth == 0)
                || (pApiReq->iMdBookType == 2 && pApiReq->iMarketDepth == 5)))
    {
        char strTimestamp[MAX_TIME_LEN];
        memset(strTimestamp, 0, sizeof(strTimestamp));
        // get current time
        rc = GetStrDateTimeByFormat(timestamp, strTimestamp);
        RAISE_ERR(rc, RTN);

        char temp[10];
        int32 iIrsApiCnt = 0;
        // get the irs api cnt
        rc = GetResultCntByUsrAndQttp(connId, pApiReq->strUsrId, itoa(iMktType, temp, 10), itoa(pApiReq->iMdBookType, temp, 10), &iIrsApiCnt);
        RAISE_ERR(rc, RTN);

        if (pApiReq->iRequestType == 2)
        {
            if (iIrsApiCnt <= 0)
            {
                RAISE_ERR(APIERR_CODE_INVLD_DUP_UNSUBQT, RTN);
            }
        }

        rc = SerializeApiSbRefData(connId, MSG_TYPE_API_SUBSCRIBE, iMktSetType, strTimestamp, pApiReq);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_SUBQT_INCOME, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : ApiSubscribe
 **
 ******************************************************************************/
ResCodeT ApiSubscribe(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiSubscribe" );
    ResCodeT rc = NO_ERR;

    ApiSubscribeReqT*      pApiReq;
    ApiSubscribeRespT*     pApiResp;

    pApiReq = (ApiSubscribeReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(ApiSubscribeRespT);
    pApiResp = (ApiSubscribeRespT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(ApiSubscribeRespT));


    // parameter check
    if (strlen(pApiReq->strOrgCdHeader) == 0
            || strlen(pApiReq->strOrgCd) == 0
            || strcmp(pApiReq->strOrgCdHeader, pApiReq->strOrgCd) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_ORG_CD, RTN);
    }

    if (strlen(pApiReq->strUsrIdHeader) == 0
            || strlen(pApiReq->strUsrId) == 0
            || strcmp(pApiReq->strUsrIdHeader, pApiReq->strUsrId) != 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(pApiReq->strUsrId,
                        pApiReq->strOrgCd,
                        pApiReq->iFuncId,
                        pApiReq->strToken,
                        1,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // IRS
    if (pApiReq->iMarketIndic == 2
        && (strlen(pApiReq->strSecurityTp) == 0 || strcmp(pApiReq->strSecurityTp, "IRS") == 0)
        && strlen(pApiReq->strCleaningMthd) == 0)
    {
        // CHECK IRS param
        rc = CheckSbscribeParam(connId, timestamp, pApiReq, C_MKT_TP_IRS, SET_MKT_IRS);
        RAISE_ERR(rc, RTN);
    }
    // SIRS
    else if (pApiReq->iMarketIndic == 42
            && (strlen(pApiReq->strSecurityTp) == 0 || strcmp(pApiReq->strSecurityTp, "SIRS") == 0)
            && strcmp(pApiReq->strCleaningMthd, "13") == 0)
    {
        // CHECK SIRS param
        rc = CheckSbscribeParam(connId, timestamp, pApiReq, C_MKT_TP_SIRS, SET_MKT_SIRS);
        RAISE_ERR(rc, RTN);
    }
    // SBFWDCCP
    else if (pApiReq->iMarketIndic == 43
            && (strlen(pApiReq->strSecurityTp) == 0 || strcmp(pApiReq->strSecurityTp, "SBFWD") == 0)
            && strcmp(pApiReq->strCleaningMthd, "6") == 0)
    {
        // CHECK SBFWDCCP param
        rc = CheckSbscribeParam(connId, timestamp, pApiReq, C_MKT_TP_SBFCCP, SET_MKT_SBFCCP);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        RAISE_ERR(APIERR_CODE_INVLD_MARKET_ID, RTN);
    }


    // get the max outbound id
    rc = GetBoundId(connId, &pApiResp->iMaxOutboundId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
