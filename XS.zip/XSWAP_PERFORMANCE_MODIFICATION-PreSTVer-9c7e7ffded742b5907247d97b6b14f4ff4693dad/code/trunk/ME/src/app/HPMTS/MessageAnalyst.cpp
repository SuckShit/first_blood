#include "MessageAnalyst.h"

using namespace IMIX20;

//NewOrderMultileg消息解析
APP_ERROR_CODE MessageAnalyst_NewOrderMultileg::AnalyzeMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;
    int rc = NO_ERR;

    NewOrderMultileg* pInMessage = NULL;
    AnalystRet_NewOrderMultileg* pResult = static_cast<AnalystRet_NewOrderMultileg*>(pRet);
    pInMessage = static_cast<NewOrderMultileg*>(pMsg);

    if (NULL == pInMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pInMessage is null."); 
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    if (NULL == pResult)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pResult is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    pResult->m_sApplSeqNum = pInMessage->GetApplSeqNum();
    pResult->m_sToken = pInMessage->GetApplToken();
    pResult->m_sSecurityId = pInMessage->GetSecurityID();
    pResult->m_sSide = pInMessage->GetSide();
    pResult->m_sPrice = pInMessage->GetPrice();
    pResult->m_sOrderQty = pInMessage->GetOrderQty();
    pResult->m_sEffectTime = pInMessage->GetEffectiveTime();
    pResult->m_sExecInst = pInMessage->GetExecInst();
    pResult->m_sOrdType = CharToString(pInMessage->GetOrdType());
    pResult->m_sPrice2 = pInMessage->GetCapPrice();
    pResult->m_sOrderQty2 = pInMessage->GetCashOrderQty();

    //获取用户ID
    rc = GetTraderFromParties(pInMessage->GetParties(), pResult->m_sUserId, E_PARTY_ROLE_ORD_USER);
    if (NO_ERR != rc)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "GetTraderFromParties error.");
    }    

    return nRet;
}

APP_ERROR_CODE MessageAnalyst_NewOrderMultileg::CreateMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    return nRet;
}

//MultilegOrderCancelReplace消息解析
APP_ERROR_CODE MessageAnalyst_MultilegOrderCancelReplace::AnalyzeMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;
    int rc = NO_ERR;
    
    MultilegOrderCancelReplace* pInMessage = NULL;
    AnalystRet_MultilegOrderCancelReplace* pResult = static_cast<AnalystRet_MultilegOrderCancelReplace*>(pRet);
    pInMessage = static_cast<MultilegOrderCancelReplace*>(pMsg);

    if (NULL == pInMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pInMessage is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    if (NULL == pResult)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pResult is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    pResult->m_sApplSeqNum = pInMessage->GetApplSeqNum();
    pResult->m_sToken = pInMessage->GetApplToken();
    pResult->m_sSecurityId = pInMessage->GetSecurityID();
    pResult->m_sSide = pInMessage->GetSide();
    pResult->m_sPrice = pInMessage->GetPrice();
    pResult->m_sOrderQty = pInMessage->GetOrderQty();
    pResult->m_sPrice2 = pInMessage->GetCapPrice();
    pResult->m_sOrderQty2 = pInMessage->GetCashOrderQty();  

    pResult->m_sEffectTime = pInMessage->GetEffectiveTime();
    pResult->m_sExecInst = pInMessage->GetExecInst();
    pResult->m_sOrdType = pInMessage->GetOrdType();
    //获取用户ID
    
    rc = GetTraderFromParties(pInMessage->GetParties(), pResult->m_sUserId, E_PARTY_ROLE_ORD_USER);
    if (NO_ERR != rc)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "GetTraderFromParties error.");
    }

    pResult->m_sOrdId = pInMessage->GetOrderID();

    return nRet;
}

APP_ERROR_CODE MessageAnalyst_MultilegOrderCancelReplace::CreateMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet)
{
    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;

    return nRet;
}
