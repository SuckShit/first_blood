/***
Created on Sep 19, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _API_ORDER_CANCEL_H_
#define _API_ORDER_CANCEL_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files */
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT ApiOrderCancel(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT SirsApiOrderCancel(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT SbfccpApiOrderCancel(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);


#endif /* _API_ORDER_CANCEL_H_ */
