/***
Created on June 13, 2017
@author: No One
@version $Id
***/

#ifndef IRS_MATCH_ERROR_DEF_H
#define IRS_MATCH_ERROR_DEF_H


enum SPADE_EXCSP_CODE
{
    SPADE_EXCSP_CODE_SUC = 0,//成功
    SPADE_EXCSP_CODE_EXCEPTION = 1//异常发生
};


//SP执行结果码定义
enum SP_RET_CODE
{
    SP_RET_EXCEPTION = -1,  //SP的执行结果为未知异常
    SP_RET_SUCCESS = 0,     //SP的执行结果成功 
    SP_RET_INVLD_EXPIRE_TIME = 500000,  //有效时间应晚于当前时间
    SP_RET_ORDER_NOT_EXIST = 500006,    //订单不存在
    SP_RET_INVLD_NOT_LOGON = 500008,    //用户未登录或已登出
    SP_RET_CREDIT_LESS = 500028,//未满足有效授信要求
    SP_RET_REF_CHECK_REQ = 500035,//是否需要盘中参考价验证
    SP_RET_INVLD_ORDR_QTY = 500052, //无效的订单数量
    SP_RET_INVLD_CRDT_MDFING = 500060,//正在进行授信管理，请稍候
    SP_RET_ORD_CLOSED_NO_C = 500066,    //订单已成交，无法撤销
    SP_RET_INVLD_CAPICALACT = 500077,//该机构没有设置默认资金帐户，请先设置
    SP_RET_UNKNOW_EXCEPTION = 500099,//数据库异常
    SP_RET_CCP_CRDT_OVER_LIMIT = 500101,    //您的剩余持仓头寸不足
    SP_RET_CCP_CRDT_ST_LIMIT = 500102,  //当前处于限仓模式，无法提交当前方向的订单
    SP_RET_INVLD_USRMKT_PRV = 500104,   //您没有此市场权限
    SP_RET_CCP_CRDT_ST_OFF = 500105,    //当前处于强平模式，无法提交订单！
    SP_RET_FORCE_MODIFY = 500113,   //当前处于强平模式，强平订单无法修改
    SP_RET_INVLD_ORDR_PRV = 500122,//当前交易员无交易权限

    SP_RET_CRT_MODIFYING = 600002,      //其他用户授信操作正在进行
    SP_RET_INVLD_RSK_CFCNT_TP = 600004, //当前风险系数设置方式不满足要求
    SP_RET_INVLD_INCOME = 600005,       //指令要素验证不通过
    SP_RET_INVLD_ORGCD = 600006,        //机构不存在
    SP_RET_INVLD_OTHERS = 600007,       //其他
    SP_RET_INVLD_CRDTPAIR = 600008, //机构授信关系不存在
    SP_RET_INVLD_CRDTMTHD = 600009, //授信方式填写错误
    SP_RET_INVLD_LOGOUT = 600011,       //用户已断线
    SP_RET_INVLD_USER = 600012,     //用户不存在
    SP_RET_INVLD_TOKEN = 600014,        //token认证不一致请重新登录
    SP_RET_USER_FORBID = 600015,        //用户已禁用
    SP_RET_ORG_FORBID = 600016,     //机构已禁用
    SP_RET_INVLD_MKT_NOT_PMT = 600017,  //此时段无法修改
    SP_RET_INVLD_ROLE_PRV = 600018, //权限错误
    SP_RET_INVLD_CRDT_MDFY_TM = 600019, //当前不是授信设置有效时间区间
    SP_RET_INVLD_OWNR_ORG_CD = 600020,//本方机构填写有误    
    SP_RET_INVLD_RSK_CNTRCT = 600022,//合约品种不存在
    SP_RET_UNSUPPORT_CRT_TYPE = 600023,//关系授信下不支持风险系数设置相关指令
    SP_RET_INVLD_OWNR_USRID = 600024,//本方用户ID填写有误
    SP_RET_INVLD_MARKET_ID = 600025,//市场不存在
    SP_RET_INVLD_SUBQT_INCOME = 600026,//订阅要素有误
    SP_RET_INVLD_DUP_UNSUBQT = 600027,//指令无效
    SP_RET_INVLD_DUP_SUBQT = 600028,//指令重复
    SP_RET_INVLD_ORDR_AMNT = 600029,//报价量不符合要求
    SP_RET_INVLD_APIUSR = 600030,   //当前交易员无API权限
    SP_RET_INVLD_PRC    = 600031,   //报价要素填写错误
    SP_RET_INVLD_ORDRINCOME = 600032,//指令要素填写错误
    SP_RET_INVLD_ORDR = 600033, //当前指令无对应订单
    SP_RET_INVLD_REQID = 600034,//指令不存在
    SP_RET_REP_CANCEL = 600035, //订单已撤销
    SP_RET_ORD_CLOSED_NO_C_N = 600036,//订单已提交
    SP_RET_ORD_BOOF = 600037,   //本方BID/OFFER价格出现倒挂
    SP_RET_INVALID_ORDR_ID = 600038,//订单编号填写错误
    SP_RET_ALREADY_LOGIN = 600039,  //交易接口已登录
    SP_RET_INVLD_ORDR_ST = 600040,//当前指令无对应的有效订单
    SP_RET_INVLD_EXPRT = 600041,    //有效时间填写有误
    SP_RET_NO_ACTIVEORD = 600042,   //当前用户无有效订单,同时执行成功
    SP_RET_INVLD_TRDNM = 600044,    //交易员姓名有误


};


#define APP_ERROR_CODE_START 510000
//程序错误码
enum APP_ERROR_CODE
{
    APP_CODE_FAILD = -1,//未知异常
    APP_CODE_SUCCESS = 0,   //成功
    APP_CODE_INCOM_PARAM_ERROR = APP_ERROR_CODE_START + 1,
    APP_CODE_INCOM_MSG_INVALID = APP_ERROR_CODE_START + 2,
    APP_CODE_USER_NOT_LOGON = APP_ERROR_CODE_START + 3,
    APP_CODE_UNKNOW_EXCEPTION = APP_ERROR_CODE_START + 4,
    APP_CODE_HEAP_NEW_ERR = APP_ERROR_CODE_START + 5,
    APP_CODE_IMIXAPI_ERR = APP_ERROR_CODE_START + 6,
    APP_CODE_SPEXEC_ERR = APP_ERROR_CODE_START + 7,
    APP_CODE_SPRET_ERR = APP_ERROR_CODE_START + 8,
    APP_CODE_SPRETSET_ERR = APP_ERROR_CODE_START + 9,
    APP_CODE_ANALYZE_IMIXMSG_ERR = APP_ERROR_CODE_START + 10,
    //APP_CODE_UNHANDLE_MSG = APP_ERROR_CODE_START + 11,
    APP_CODE_REQFUNC_ERR = APP_ERROR_CODE_START + 12,
    APP_CODE_IRSINIT_ERR = APP_ERROR_CODE_START + 13,
    APP_CODE_SQL_EXCEPTION = APP_ERROR_CODE_START + 14,
    APP_CODE_MARKET_ERR = APP_ERROR_CODE_START + 15,
};

// 程序错误码描述预定义
static const char* APP_MSG_INCOM_MSG_INVALID = "无效的请求消息";
static const char* APP_MSG_INCOM_PARAM_ERROR = "错误的入参";
static const char* APP_MSG_UNKNOW_EXCEPTION = "调用存储过程异常";
static const char* APP_MSG_USER_NOT_LOGON   = "用户未登陆";
static const char* APP_MSG_HEAP_NEW_ERR     = "申请堆空间错误";
static const char* APP_MSG_SPEXEC_ERR       = "数据库执行错误";
static const char* APP_MSG_SPRET_ERR        = "获取数据库执行普通出参错误";
static const char* APP_MSG_SPRETSET_ERR     = "获取数据库执行结果集出参错误";
static const char* APP_MSG_ANALYZE_IMIXMSG_ERR = "解析IMIX消息错误";
static const char* APP_MSG_UNHANDLE_MSG = "IRS未处理的消息类型[%s]";
static const char* APP_MSG_REQFUNC_ERR = "消息请求类型错误";
static const char* APP_MSG_IRSINIT_ERR = "程序退出[IRS初始化失败]";
static const char* APP_MSG_SQL_EXCEPTION = "SQL异常";

// 描述信息
static const char* DESC_CREDIT_SUCCESS = "授信/风险系数修改成功!";
static const char* DESC_RISK_SUCCESS = "授信/风险系数修改成功!";
static const char* DESC_CLOSE_POSITION_STATE = "进入强平模式!";
static const char* DESC_CLOSE_POSITION_CANCEL_STATE = "强平模式撤销!";
static const char* DESC_LIMIT_POSITION_STATE = "进入限仓模式!";
static const char* DESC_LIMIT_POSITION_CANCEL = "进入正常模式!";
static const char* DESC_LIMIT_POSITION_CANCEL_N = "限仓模式解除";
//CCP对手方机构显示
static const char* CCP_DISPLAY_ORG = "上海清算所";

static const char* DESC_USR_NO_BILORD = "当前机构下无双边订单,请及时提交！";
//API接口功能返回的错误描述
static const char* DESC_OTHER = "其他";

#endif