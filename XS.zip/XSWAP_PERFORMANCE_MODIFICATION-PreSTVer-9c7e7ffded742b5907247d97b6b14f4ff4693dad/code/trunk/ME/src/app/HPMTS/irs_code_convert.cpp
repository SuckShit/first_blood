/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "irs_code_convert.h"
#include "order_book.h"

/************************************************************************/
/* ��������ת��                                                         */
/************************************************************************/
IRS_STRING ImixToIrs_Side(IRS_STRING strIn)
{
    IRS_STRING strRet = strIn;
    
    if (E_IMIX_SIDE_BID == strIn)
    {
        strRet = E_IRS_SIDE_BID;
    }
    else if (E_IMIX_SIDE_ASK == strIn)
    {
        strRet = E_IRS_SIDE_ASK;
    }

    return strRet;
}
//IRS_STRING IrsToImix_Side(IRS_STRING strIn)
//{
//  IRS_STRING strRet = strIn;
//
//  if (E_IRS_SIDE_BID == strIn)
//  {
//      strRet = E_IMIX_SIDE_BID;
//  }
//  else if (E_IRS_SIDE_ASK == strIn)
//  {
//      strRet = E_IMIX_SIDE_ASK;
//  }
//
//  return strRet;
//}

IRS_STRING IrsToImix_Side(int32 intrnlSide)
{
    IRS_STRING strRet = "";

    switch (intrnlSide)
    {
        case ORDR_SIDE_BUY:
            strRet = E_IMIX_SIDE_BID;
            break;
            
        case ORDR_SIDE_SELL:
            strRet = E_IMIX_SIDE_ASK;
            break;
        default:
            break;        
    }

    return strRet;
}

/************************************************************************/
/* �����ύ����ת��                                                     */
/************************************************************************/
//��IMIX������Ϣ��ֻ��Ҫ���������ύ�����޼ۡ����ת����IRS�е�ֵ
int32 ImixToIrs_OrdType(IRS_STRING strIn)
{
    int32 strRet = 0;

    if (E_IMIX_ORDTP_CLICK == strIn)
    { 
        strRet = EXT_ORD_TYPE_CLICK;
    }
    else if (E_IMIX_ORDTP_LIMIT == strIn)
    {
        strRet = EXT_ORD_TYPE_NORMAL;
    }
    else if (E_IMIX_ORDTP_IMP == strIn)
    {
        strRet = EXT_ORD_TYPE_IMP;
    }
    else if (E_IMIX_ORDTP_OCO == strIn)
    {
        strRet = EXT_ORD_TYPE_OCO;
    }
    else if (E_IMIX_ORDTP_IMPOCO == strIn)
    {
        strRet = EXT_ORD_TYPE_IMPOCO;
    }
    else if (E_IMIX_ORDTP_BILORD == strIn)
    {
        strRet = EXT_ORD_TYPE_BIL;
    }

    return strRet;
}


IRS_STRING IrsToImix_OrdType(int32 intrnlOrdTpye)
{
    IRS_STRING strRet = "";

    if (EXT_ORD_TYPE_CLICK == intrnlOrdTpye)
    { 
        strRet = E_IMIX_ORDTP_CLICK;
    }
    else if (EXT_ORD_TYPE_NORMAL == intrnlOrdTpye)
    {
        strRet = E_IMIX_ORDTP_LIMIT;
    }
    else if (EXT_ORD_TYPE_IMP == intrnlOrdTpye)
    {
        strRet = E_IMIX_ORDTP_IMP;
    }
    else if (EXT_ORD_TYPE_OCO == intrnlOrdTpye)
    {
        strRet = E_IMIX_ORDTP_OCO;
    }
    else if (EXT_ORD_TYPE_IMPOCO == intrnlOrdTpye)
    {
        strRet = E_IMIX_ORDTP_IMPOCO;
    }
    else if (EXT_ORD_TYPE_BIL == intrnlOrdTpye )
    {
        strRet = E_IMIX_ORDTP_BILORD;
    }
    

    return strRet;
}

//��IRSӦ����Ϣ��ֻ��Ҫ����������ת��ΪIMIX��ֵ
//IRS_STRING IrsToImix_OrdType(IRS_STRING strIn)
//{
//  IRS_STRING strRet = strIn;
//
//  if (E_IRS_ORDTP_NORMAL == strIn)
//  {
//      strRet = E_IMIX_ORDTP_NORMAL;
//  }
//  else if (E_IRS_ORDTP_IMP == strIn)
//  {
//      strRet = E_IMIX_ORDTP_IMP;
//  }
//  else if (E_IRS_ORDTP_OCO == strIn)
//  {
//      strRet = E_IMIX_ORDTP_OCO;
//  }
//  else if (E_IRS_ORDTP_IMPOCO == strIn)
//  {
//      strRet = E_IMIX_ORDTP_IMPOCO;
//  }
//  else if(E_IRS_ORDTP_BIL == strIn)
//  {
//      strRet = E_IMIX_ORDTP_BILORD;
//  }
//
//  return strRet;
//}
//
//IRS_STRING IrsToImix_OrdType(int32 intrnlOrdTpye)
//{
//  IRS_STRING strRet = "";
//
//  if (EXT_ORD_TYPE_NORMAL == intrnlOrdTpye)
//  {
//      strRet = E_IMIX_ORDTP_NORMAL;
//  }
//  else if (EXT_ORD_TYPE_IMP == intrnlOrdTpye)
//  {
//      strRet = E_IMIX_ORDTP_IMP;
//  }
//  else if (EXT_ORD_TYPE_OCO == intrnlOrdTpye)
//  {
//      strRet = E_IMIX_ORDTP_OCO;
//  }
//  else if (EXT_ORD_TYPE_IMPOCO == intrnlOrdTpye)
//  {
//      strRet = E_IMIX_ORDTP_IMPOCO;
//  }
//  else if(EXT_ORD_TYPE_BIL == intrnlOrdTpye)
//  {
//      strRet = E_IMIX_ORDTP_BILORD;
//  }
//
//  return strRet;
//}




IRS_STRING IrsToImixOutSide_OrdType(IRS_STRING strIn)
{
    IRS_STRING strRet = strIn;

    if (E_IRS_ORDTP_NORMAL == strIn)
    {
        strRet = E_IMIX_ORDTP_NORMAL;
    }
    else if (E_IRS_ORDTP_IMP == strIn)
    {
        strRet = E_IMIX_ORDTP_IMP;
    }
    else if (E_IRS_ORDTP_OCO == strIn)
    {
        strRet = E_IMIX_ORDTP_OUTSIDEOCO;
    }
    else if (E_IRS_ORDTP_IMPOCO == strIn)
    {
        strRet = E_IMIX_ORDTP_IMPOCO;
    }
    else if (E_IRS_ORDTP_BIL == strIn)
    {
        strRet = E_IMIX_ORDTP_OUTSIDEBILORD;
    }

    return strRet;
}

/************************************************************************/
/* �Ƿ�ǿ��ִ��                                                          */
/************************************************************************/
IRS_STRING ImixToIrs_IsExec(IRS_STRING strIn)
{
    IRS_STRING strRet = E_IRS_ISEXECUTE_FALSE;
    int nFind = strIn.find(E_IMIX_ISEXECUTE_TRUE);
    //����Ƿ�ǿ��ִ�У�����Ҫ������вο���
    if (nFind == IRS_STRING::npos)
    {       
        strRet = E_IRS_ISEXECUTE_TRUE;
    }
    return strRet;
}

/************************************************************************/
/* �ɽ�״̬ת��                                                     */
/************************************************************************/
IRS_STRING ImixToIrs_DealStatus(char cIn)
{
    IRS_STRING strRet = "";

    if (E_IMIX_DLST_OK == cIn)
    {
        strRet = E_IRS_DLST_OK;
    }
    else if (E_IMIX_DLST_CANCEL == cIn)
    {
        strRet = E_IRS_DLST_CANCEL;
    }

    return strRet;
}
//
//char IrsToImix_DealStatus(IRS_STRING strIn)
//{
//  char cRet = CHAR_DEFAULT;
//
//  if (E_IRS_DLST_OK == strIn)
//  {
//      cRet = E_IMIX_DLST_OK;
//  }
//  else if (E_IRS_DLST_CANCEL == strIn)
//  {
//      cRet = E_IMIX_DLST_CANCEL;
//  }
//  else if ("3" == strIn)
//  {
//      cRet = '3';
//  }
//
//  return cRet;
//}

char IrsToImix_DealStatus(int16 dealSts)
{
    char cRet = CHAR_DEFAULT;

    if (DEAL_STS_OK == dealSts)
    {
        cRet = E_IMIX_DLST_OK;
    }
    else if (DEAL_STS_CANCEL == dealSts)
    {
        cRet = E_IMIX_DLST_CANCEL;
    }

    return cRet;
}


char SIrsToImix_DealStatus(IRS_STRING strIn)
{
    char cRet = CHAR_DEFAULT;

    if (E_IRS_DLST_OK == strIn)
    {
        cRet = '2';
    }
    else if (E_IRS_DLST_CANCEL == strIn)
    {
        cRet = E_IMIX_DLST_CANCEL;
    }
    else if ("3" == strIn)
    {
        cRet = '3';
    }
    return cRet;
}

// ��Ϣ��������
char SIrsToImix_AccDayAdjmnt(IRS_STRING strIn)
{
    char cRet = CHAR_DEFAULT;

    if (E_SIRS_ACCURAL_DAY_ADJUSTMENT_DAY == strIn)
    {
        cRet = E_IMIX_ACCURAL_DAY_ADJUSTMENT_DAY;
    }
    else if (E_SIRS_ACCURAL_DAY_ADJUSTMENT_FIXED == strIn)
    {
        cRet = E_IMIX_ACCURAL_DAY_ADJUSTMENT_FIXED;
    }

    return cRet;
}

// ���㷽ʽ
string SIrsToImix_ClearingMethod(IRS_STRING strIn)
{
    string sRet = CHAR_DEFAULT;

    if (E_SIRS_CLEARING_METHOD_SEPARATE== strIn)
    {
        sRet = E_IMIX_CLEARING_METHOD_SEPARATE;
    }
    else if (E_SIRS_CLEARING_METHOD_SHANGHAI == strIn)
    {
        sRet = E_IMIX_CLEARING_METHOD_SHANGHAI;
    }
    else
    {
        sRet = E_IMIX_CLEARING_METHOD_SEPARATE;
    }

    return sRet;
}

// ֧���յ���
char SIrsToImix_PayDateReset(IRS_STRING strIn)
{
    char cRet = CHAR_DEFAULT;

    if (E_SIRS_PAYMENT_DATE_RESET_NEXT_DAY == strIn)
    {
        cRet = E_IMIX_PAYMENT_DATE_RESET_NEXT_DAY;
    }
    else if (E_SIRS_PAYMENT_DATE_RESET_AFTER_DAY == strIn)
    {
        cRet = E_IMIX_PAYMENT_DATE_RESET_AFTER_DAY;
    }
    else if (E_SIRS_PAYMENT_DATE_RESET_BEFORE_DAY == strIn)
    {
        cRet = E_IMIX_PAYMENT_DATE_RESET_BEFORE_DAY;
    }

    return cRet;
}

// ֧������
string SIrsToImix_PaymentFrequency(IRS_STRING strIn)
{
    string sRet = "";

    if (E_SIRS_PAYMENT_FREQUENCY_EXPIRE == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_EXPIRE;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_DAY == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_DAY;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_WEEK == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_WEEK;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_2WEEK == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_2WEEK;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_MONTH == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_MONTH;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_SEASON == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_SEASON;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_HALF_YEAR == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_HALF_YEAR;
    }
    else if (E_SIRS_PAYMENT_FREQUENCY_YEAR == strIn)
    {
        sRet = E_IMIX_PAYMENT_FREQUENCY_YEAR;
    }

    return sRet;
}

// ������������Ƶ��
string SIrsToImix_ResetFrequency(IRS_STRING strIn)
{
    string sRet = "";

        if (E_SIRS_RESET_FREQUENCY_EXPIRE == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_EXPIRE;
    }
    else if (E_SIRS_RESET_FREQUENCY_DAY == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_DAY;
    }
    else if (E_SIRS_RESET_FREQUENCY_WEEK == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_WEEK;
    }
    else if (E_SIRS_RESET_FREQUENCY_2WEEK == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_2WEEK;
    }
    else if (E_SIRS_RESET_FREQUENCY_MONTH == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_MONTH;
    }
    else if (E_SIRS_RESET_FREQUENCY_SEASON == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_SEASON;
    }
    else if (E_SIRS_RESET_FREQUENCY_HALF_YEAR == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_HALF_YEAR;
    }
    else if (E_SIRS_RESET_FREQUENCY_YEAR == strIn)
    {
        sRet = E_IMIX_RESET_FREQUENCY_YEAR;
    }

    return sRet;
}

// ��Ϣ��׼
char SIrsToImix_DayCount(IRS_STRING strIn)
{
    char cRet = CHAR_DEFAULT;

    if (E_SIRS_DAY_COUNT_ACTUAL_365 == strIn)
    {
        cRet = E_IMIX_DAY_COUNT_ACTUAL_365;
    }
    else if (E_SIRS_DAY_COUNT_ACTUAL_360 == strIn)
    {
        cRet = E_IMIX_DAY_COUNT_ACTUAL_360;
    }
    else if (E_SIRS_DAY_COUNT_ACTUAL_ACTUAL == strIn)
    {
        cRet = E_IMIX_DAY_COUNT_ACTUAL_ACTUAL;
    }
    else if (E_SIRS_DAY_COUNT_30E_360 == strIn)
    {
        cRet = E_IMIX_DAY_COUNT_30E_360;
    }
    else if (E_SIRS_DAY_COUNT_ACTUAL_365F == strIn)
    {
        cRet = E_IMIX_DAY_COUNT_ACTUAL_365F;
    }

    return cRet;
}

/************************************************************************/
/* �ɽ�����ת��                                                          */
/************************************************************************/
int ImixToIrs_TrdType(int nIn)
{
    int nRet = E_IRS_TRDSUBTP_DEFAULT;
    switch (nIn)
    {
    case E_IMIX_TRDSUBTP_COMBTOCOMB:
        nRet = E_IRS_TRDSUBTP_COMBTOCOMB;
        break;
    case E_IMIX_TRDSUBTP_COMBTOCOMBIMP:
        nRet = E_IRS_TRDSUBTP_COMBTOCOMBIMP;
        break;
    case E_IMIX_TRDSUBTP_DIRTODIR:
        nRet = E_IRS_TRDSUBTP_DIRTODIR;
        break;
    case E_IMIX_TRDSUBTP_DIRTODIRIMP:
        nRet = E_IRS_TRDSUBTP_DIRTODIRIMP;
        break;
    case E_IMIX_TRDSUBTP_BRDGTOCOMB:
        nRet = E_IRS_TRDSUBTP_BRDGTOCOMB;
        break;
    case E_IMIX_TRDSUBTP_DIRTOBRDG:
        nRet = E_IRS_TRDSUBTP_DIRTOBRDG;
        break;
    default:
        break;
    }
    return nRet;
}

int IrsToImix_TrdType(int nIn)
{
    int nRet = E_IMIX_TRDSUBTP_DEFAULT;
    switch (nIn)
    {
    case E_IRS_TRDSUBTP_COMBTOCOMB:
        nRet = E_IMIX_TRDSUBTP_COMBTOCOMB;
        break;
    case E_IRS_TRDSUBTP_COMBTOCOMBIMP:
        nRet = E_IMIX_TRDSUBTP_COMBTOCOMBIMP;
        break;
    case E_IRS_TRDSUBTP_DIRTODIR:
        nRet = E_IMIX_TRDSUBTP_DIRTODIR;
        break;
    case E_IRS_TRDSUBTP_DIRTODIRIMP:
        nRet = E_IMIX_TRDSUBTP_DIRTODIRIMP;
        break;
    case E_IRS_TRDSUBTP_BRDGTOCOMB:
        nRet = E_IMIX_TRDSUBTP_BRDGTOCOMB;
        break;
    case E_IRS_TRDSUBTP_DIRTOBRDG:
        nRet = E_IMIX_TRDSUBTP_DIRTOBRDG;
        break;
    case E_IRS_TRDSUBTP_BASTOBRDG:
        nRet = E_IMIX_TRDSUBTP_BASTOBRDG;
        break;
    case E_IRS_TRDSUBTP_BASTOBAS:
        nRet = E_IMIX_TRDSUBTP_BASTOBAS;
        break;
    default:
        break;
    }
    return nRet;
}

/************************************************************************/
/* �г�״̬��ʶת��                                                     */
/************************************************************************/
int ImixToIrs_MktFlag(int nIn)
{
    int nRet = 0;
    int nIndex = 0; 
    while (nIndex < MKT_FLAG_NUM)
    {
        if (IMIX_MKT_FLAGS[nIndex] == nIn)
        {
            break;
        }
        nIndex ++;
    }

    nRet = IRS_MKT_FLAGS[nIndex];

    return nRet;
}

int IrsToImix_MktFlag(int nIn)
{
    int nRet = 0;
    int nIndex = 0; 
    while (nIndex < MKT_FLAG_NUM)
    {
        if (IRS_MKT_FLAGS[nIndex] == nIn)
        {
            break;
        }
        nIndex ++;
    }

    nRet = IMIX_MKT_FLAGS[nIndex];

    return nRet;
}

/************************************************************************/
/* ���ŷ�ʽ��ʶת��                                                     */
/************************************************************************/
int ImixToIrs_CreditMethod(int nIn)
{
    int nRet = IRS_CREDIT_METHOD_RELA;
    
    if (IMIX_CREDIT_METHOD_AMT == nIn)
    {
        nRet = IRS_CREDIT_METHOD_AMT;
    }
    return nRet;
}

int IrsToImix_CreditMethod(int nIn)
{
    int nRet = IMIX_CREDIT_METHOD_RELA;

    if (IRS_CREDIT_METHOD_AMT == nIn)
    {
        nRet = IMIX_CREDIT_METHOD_AMT;
    }
    return nRet;
}
/************************************************************************/
/* ����״̬ת��                                                     */
/************************************************************************/
char ImixToIrs_OrdStatus(char cIn)
{
    char cRet = CHAR_DEFAULT;
    int nIndex = 0; 
    while (nIndex < ORD_ST_NUM)
    {
        if (IMIX_ORD_STATUS[nIndex] == cIn)
        {
            break;
        }
        nIndex ++;
    }

    cRet = IRS_ORD_STATUS[nIndex];

    return cRet;    
}



char IrsToImix_OrdStatus(int32 intrnlOrdSts)
{
    char cRet = CHAR_DEFAULT;

    switch(intrnlOrdSts)
    {
        case ORDR_STS_ACTIVE:
            cRet = E_IRS_ORD_STS_ACTIVE;
            break;
            
        case ORDR_STS_DEAL:
            cRet = E_IRS_ORD_STS_FILLED;
            break;
        case ORDR_STS_CANCEL:
            cRet = E_IRS_ORD_STS_CANCEL;
            break;
        case ORDR_STS_FREEZE:
        case ORDR_STS_INACTIVE:
            cRet = E_IRS_ORD_STS_FREEZE;
            break;
        case ORDR_STS_INVALID:
            cRet = E_IRS_ORD_STS_INVLID;
            break;

        default:
            break;
    }
    return cRet;
}

int ImixToIrs_PriceUnit(int nIn)
{
    int nRet = IRS_PRICE_UNIT_BP;

    switch(nIn)
    {
    case IMIX_PRICE_UNIT_BP:
        nRet = IRS_PRICE_UNIT_BP;
        break;
    case IMIX_PRICE_UNIT_PERCENTAGE:
        nRet = IRS_PRICE_UNIT_PERCENTAGE;
        break;
    default:
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Input imix price unit value error. value: %d", nIn);
        break;
    }

    return nRet;
}

int IrsToImix_PriceUnit(int nIn)
{
    int nRet = PRICE_UNIT_VALID;

    switch(nIn)
    {
    case IRS_PRICE_UNIT_BP:
        nRet = IMIX_PRICE_UNIT_BP;
        break;
    case IRS_PRICE_UNIT_PERCENTAGE:
        nRet = IMIX_PRICE_UNIT_PERCENTAGE;
        break;
    default:
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "Input irs price unit value error. value: %d", nIn);
        break;
    }

    return nRet;
}

IRS_STRING ImixToIrs_TrdMethod(IRS_STRING strIn)
{
    IRS_STRING strRet = "";

    if (E_IMIX_TRDMETHOD_MATCH == strIn)
    {
        strRet = E_IRS_TRDMETHOD_MATCH;
    }

    return strRet;
}

IRS_STRING IrsToImix_TrdMethod(IRS_STRING strIn)
{
    IRS_STRING strRet = "";

    if (E_IRS_TRDMETHOD_MATCH == strIn)
    {
        strRet = E_IMIX_TRDMETHOD_MATCH;
    }

    return strRet;
}

IRS_STRING ImixToIrs_ContractSt(IRS_STRING strIn)
{
    IRS_STRING strRet = "";

    if (IMIX_CONTRACT_ST_ACTIVE == strIn)
    {
        strRet = IRS_CONTRACT_ST_ACTIVE;
    }
    else if (IMIX_CONTRACT_ST_INACTIVE == strIn)
    {
        strRet = IRS_CONTRACT_ST_INACTIVE;
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "In put imix contract status: %s.", strIn.c_str());
    }

    return strRet;
}

IRS_STRING IrsToImix_ContractSt(IRS_STRING strIn)
{
    IRS_STRING strRet = "";

    if (IRS_CONTRACT_ST_ACTIVE == strIn)
    {
        strRet = IMIX_CONTRACT_ST_ACTIVE;
    }
    else if (IRS_CONTRACT_ST_INACTIVE == strIn ||
            IRS_CONTRACT_ST_UNKNOW == strIn)
    {
        strRet = IRS_CONTRACT_ST_INACTIVE;
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "In put irs contract status: %s.", strIn.c_str());
    }

    return strRet;
}
