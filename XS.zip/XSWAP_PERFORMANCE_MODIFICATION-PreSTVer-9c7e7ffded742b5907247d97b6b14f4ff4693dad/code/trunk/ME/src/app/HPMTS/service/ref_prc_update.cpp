/***
Created on 11th, Sep, 2017
@author: Longyun.Hao
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_cod.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "msg_type.h"
#include "common_macro.h"
#include "pck_irs_dicdata.h"

#include "base_param.h"
#include "prdct_info.h"
#include "ref_dat_updt.h"
#include "ref_prc_update.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define HALF_HOUR 30*60 // 30min(单位级:秒)

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/******************************************************************************
 * Description:   Calculate the reference price by timer.
 *
 * Parameters:
 *      ordrNoGet       : IN  - order no. to be searched for and retrieved from
 *                              the search vector.
 *      set             : IN  - the set identification number.
 *      pOrdrNoGet      : OUT - pointer to the retrieved order.
 * Return Value         : NO_ERR                       - Successful
 *                        ERR_<DESC>                   - Error
 *                        ERR_OBK_OBSV_ORDRNO_NOTFOUND - Order number not found.
 *****************************************************************************/
ResCodeT PrcsCalcRefPrcByTrgr(pIntrnlMsgT     pReq,
                pIntrnlMsgT     pRsp,
                int64           timestamp,
                pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "PrcsCalcRefPrcByTrgr" );
    ResCodeT rc = NO_ERR;

    LOG_DEBUG("Start PrcsCalcRefPrcByTrgr");

    int32           datasize = 0;
    PrdRefPrcUpdT   refPrcUpdInfo = {0};

    refPrcUpdInfo.refPrcUpdTime = timestamp;
    refPrcUpdInfo.iterPos = CMN_LIST_NULL_NODE;

    /* MKT SBFCCP */
    do
    {
        memset( &refPrcUpdInfo.refPrcNode[0], 0x00, sizeof(RefPrcNodeT) * REFPRC_NODE_NUM_MAX );
        rc = CalcIntradayRefPrc( &refPrcUpdInfo );
        RAISE_ERR( rc, RTN );

        if ( !refPrcUpdInfo.updCnt )
        {
            break;
        }

        datasize = sizeof(PrdRefPrcUpdT) * refPrcUpdInfo.updCnt;
        rc = RefDatUpdtCmmn( REF_TYP_UPDT_REFPRC_DAT, (void *)&refPrcUpdInfo, datasize );
        RAISE_ERR( rc, RTN );

    } while(refPrcUpdInfo.iterPos != CMN_LIST_NULL_NODE);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** GetMktStIRS(IRS市场状态)
 **
 ******************************************************************************/
ResCodeT GetMktStIRS(char* pValue)
{
    ResCodeT rc = NO_ERR;
    BaseParamT bsParamData;

    BEGIN_FUNCTION( "GetMktStIRS" );
    memset(&bsParamData, 0x00, sizeof(BaseParamT));

    // get --市场状态
    rc = BaseParamGetByName((char*)C_MKT_ST_IRS, &bsParamData);
    if (NOTOK(rc)) {
        LOG_INFO("BaseParamGetByName(%s) is not exist.\n", C_MKT_ST_IRS);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (!bsParamData.paramValue) {
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }
    strcpy(pValue, bsParamData.paramValue);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetRefPrcClcTime(盘中参考价最后一次计算时间)
 **
 ******************************************************************************/
ResCodeT GetRefPrcClcTime(time_t* pValue)
{
    ResCodeT rc = NO_ERR;
    BaseParamT bsParamData;
    char strTm[18];

    BEGIN_FUNCTION( "GetRefPrcClcTime" );
    memset(&bsParamData, 0x00, sizeof(BaseParamT));
    memset(strTm, 0x00, sizeof(strTm));

    // get --盘中参考价最后一次计算时间
    rc = BaseParamGetByName((char*)C_REFPRC_CLC_TIME, &bsParamData);
    if (NOTOK(rc)) {
        LOG_INFO("BaseParamGetByName(%s) is not exist.\n", C_REFPRC_CLC_TIME);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (!bsParamData.paramValue) {
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }
    strcpy(strTm, bsParamData.paramValue);

    rc = ConvertFromCharToTime(strTm, pValue);
    if (NOTOK(rc)) {
        LOG_INFO("Failed to ConvertFromCharToTime(%s).\n", strTm);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetLastBrdgeTime(上次搭桥时间)
 **
 ******************************************************************************/
ResCodeT GetLastBrdgeTime(time_t* pValue)
{
    ResCodeT rc = NO_ERR;
    BaseParamT bsParamData;
    char strTm[18];

    BEGIN_FUNCTION( "GetLastBrdgeTime" );
    memset(&bsParamData, 0x00, sizeof(BaseParamT));
    memset(strTm, 0x00, sizeof(strTm));

    // get --上次搭桥时间
    rc = BaseParamGetByName((char*)C_BRDG_LASTBRDGETIME, &bsParamData);
    if (NOTOK(rc)) {
        LOG_INFO("BaseParamGetByName(%s) is not exist.\n", C_BRDG_LASTBRDGETIME);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (!bsParamData.paramValue) {
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }
    strcpy(strTm, bsParamData.paramValue);

    rc = ConvertFromCharToTime(strTm, pValue);
    if (NOTOK(rc)) {
        LOG_INFO("Failed to ConvertFromCharToTime(%s).\n", strTm);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetBridgeFlag(搭桥开关)
 **
 ******************************************************************************/
ResCodeT GetBridgeFlag(BOOL* pFlag)
{
    ResCodeT rc = NO_ERR;
    BaseParamT bsParamData;

    BEGIN_FUNCTION( "GetBridgeFlag" );
    memset(&bsParamData, 0x00, sizeof(BaseParamT));

    // get --搭桥开关
    rc = BaseParamGetByName((char*)C_BRDG_BRIDGEFLAG, &bsParamData);
    if (NOTOK(rc)) {
        LOG_INFO("BaseParamGetByName(%s) is not exist.\n", C_BRDG_BRIDGEFLAG);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (!bsParamData.paramValue) {
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (0 == strcmp("Y", bsParamData.paramValue)) {
        //桥接开关(打开)
        *pFlag = TRUE;
    }
    else if (0 == strcmp("N", bsParamData.paramValue)) {
        //桥接开关(关闭)
        *pFlag = FALSE;
    }
    else {
        // default error.
        LOG_INFO("this flag is not exist.");
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetBypassFrequency(搭桥频率)
 **
 ******************************************************************************/
ResCodeT GetBypassFrequency(int64* pValue)
{
    ResCodeT rc = NO_ERR;
    BaseParamT bsParamData;

    BEGIN_FUNCTION( "GetBypassFrequency" );
    memset(&bsParamData, 0x00, sizeof(BaseParamT));

    // get --搭桥频率
    rc = BaseParamGetByName((char*)C_BRDG_BYPASSFREQUENCY, &bsParamData);
    if (NOTOK(rc)) {
        LOG_INFO("BaseParamGetByName(%s) is not exist.\n", C_BRDG_BYPASSFREQUENCY);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (!bsParamData.paramValue) {
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }
    *pValue = atoi(bsParamData.paramValue);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetBridgePercent(桥接百分比(%))
 **
 ******************************************************************************/
ResCodeT GetBridgePercent(int64* pValue)
{
    ResCodeT rc = NO_ERR;
    BaseParamT bsParamData;

    BEGIN_FUNCTION( "GetBridgePercent" );
    memset(&bsParamData, 0x00, sizeof(BaseParamT));

    // get --搭桥百分比
    rc = BaseParamGetByName((char*)C_BRDG_BRIDGEPERCENT, &bsParamData);
    if (NOTOK(rc)) {
        LOG_INFO("BaseParamGetByName(%s) is not exist.\n", C_BRDG_BRIDGEPERCENT);
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }

    if (!bsParamData.paramValue) {
        RAISE_ERR(ERR_CODE_MKTSTATE_EMPTY, RTN);
    }
    *pValue = atoi(bsParamData.paramValue);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
