/***
Created on Sep 14, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"
#include "internal_base_def.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "usr_def_ref.h"
#include "match_lib.h"
#include "api_subscribe.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/******************************************************************************
 **
 ** Detail Service Callback : ApiUnSubscribeAll
 **
 ******************************************************************************/
ResCodeT ApiUnSubscribeAll(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiUnSubscribeAll" );
    ResCodeT rc = NO_ERR;

    ApiUnSubscribeAllReqT*  pApiReq;
    NewOrderSingleRspT*     pApiResp;

    pApiReq = (ApiUnSubscribeAllReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    // ���IN_UNSUBID �ǲ���3
    if (pApiReq->iUnSubId != 3)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }

    // get current time
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);
    RAISE_ERR(rc, RTN);

    // ȡ��ȫ������
//    rc = DeleteAllQtSbscrptnApi(connId);
//    RAISE_ERR(rc, RTN);


    // ����ȫ������
    // SP_IRSAPI_ORDCANCELALL
    // todo temporary using 1 to test
    rc = MtchrPrcsApiOrdrCncl(1, timestamp, pApiResp);
//    rc = MtchrPrcsApiOrdrCncl(pReq->msgHdr.setId, timestamp, pApiResp);
    RAISE_ERR(rc, RTN);

    // SP_SIRSAPI_ORDCANCELALL
    // SP_SBFCCPAPI_ORDCANCELALL


    // todo ���ض����仯״̬


    // get the max outbound id
//    rc = GetBoundId(connId, &pApiResp->iMaxOutboundId);
//    RAISE_ERR(rc, RTN);

    rc = SerializeApiSbRefData(connId, MSG_TYPE_API_UNSUBSCRIBE_ALL, SET_MKT_IRS, strTimestamp, NULL);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
