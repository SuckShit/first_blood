/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#ifndef MESSAGEANALYST_H
#define MESSAGEANALYST_H

#include "internal_function_def.h"
#include "irs_code_convert.h"
/*
* 消息解析结果数据结构基类
*/
class AnalystRet_Basic
{
public:
	AnalystRet_Basic(void)
	{
	
	}
	virtual ~AnalystRet_Basic(void)
	{
	
	}
public:
	//定义消息头部分字段结构体
	class MsgHeader
	{
	public:
		IRS_STRING m_sSendCmpId;
		IRS_STRING m_sSendSubId;
		IRS_STRING m_sTargetCmpId;
		IRS_STRING m_sTargetSubId;
		IRS_STRING m_sOnBehalfCmpId;
		IRS_STRING m_sOnBehalfSubId;
		IRS_STRING m_sDeliverToCompId;
		IRS_STRING m_sDeliverToSubId;
	
	public:
		MsgHeader()
		{
			m_sSendCmpId = "";
			m_sSendSubId = "";
			m_sTargetCmpId = "";
			m_sTargetSubId = "";
			m_sOnBehalfCmpId = "";
			m_sOnBehalfSubId = "";
			m_sDeliverToCompId = "";
			m_sDeliverToSubId = "";	
		}
	};
};

/*
* 消息解析处理基类
*/
class MessageAnalyst_Basic
{
public:
	MessageAnalyst_Basic(void)
	{
	
	}
	virtual ~MessageAnalyst_Basic(void)
	{
	
	}

public:
	/*
	函数名称：	AnalyzeMessage
	功能：		消息解析函数，解析输入的消息进行解析结果输出
	参数：
				pMsg: [入参]待解析的消息
				pRet: [出参]解析后的数据元素				
	*/
	virtual APP_ERROR_CODE AnalyzeMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet) = 0;
	/*
	函数名称：	CreateMessage
	功能：		根据pRet中的值进行消息的组成
	参数：
				pRet: [入参]提供组成消息必要的数据元素
				pMsg: [出参]输出的消息，消息的内存空间需要调用者管理
	*/
	virtual APP_ERROR_CODE CreateMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet) = 0;
	/*
	函数名称：	SetMsgHeader
	功能：		设置消息头数据
	参数：
				pMsg: [出参]设置头数据的目标消息
				msgHeader: [入参]消息头数据				
	*/
	//virtual void SetMsgHeader(IMIX::BasicMessage* pMsg, const AnalystRet_Basic::MsgHeader& msgHeader);
};

/*
* NewOrderMultileg消息解析
* 1)结果数据结构类
* 2)消息解析类
*/
class AnalystRet_NewOrderMultileg : public AnalystRet_Basic
{
public:
	AnalystRet_NewOrderMultileg(void)
	{
	
	}
	virtual ~AnalystRet_NewOrderMultileg(void)
	{
	
	}

public:
	PREFIX IRS_STRING GetApplSeqNum()
	{
		return m_sApplSeqNum;
	}
	PREFIX IRS_STRING GetToken()
	{
		return m_sToken;
	}
	PREFIX IRS_STRING GetUserId()
	{
		return m_sUserId;
	}
	PREFIX IRS_STRING GetSecurityId()
	{
		return m_sSecurityId;
	}
	PREFIX char GetSide()
	{
		return m_sSide;
	}
	PREFIX IRS_STRING GetPrice()
	{
		return m_sPrice;
	}
	PREFIX IRS_STRING GetOrderQty()
	{
		return m_sOrderQty;
	}
	PREFIX IRS_STRING GetPrice2()
	{
		return m_sPrice2;
	}
	PREFIX IRS_STRING GetOrderQty2()
	{
		return m_sOrderQty2;
	}
	PREFIX IRS_STRING GetEffectTime()
	{
		return m_sEffectTime;
	}
	PREFIX IRS_STRING GetOrdType()
	{
		return m_sOrdType;
	}
	PREFIX IRS_STRING GetExecInst()
	{
		return m_sExecInst;
	}

public:
	IRS_STRING m_sApplSeqNum;	//消息序列号
	IRS_STRING m_sToken;		//Token
	IRS_STRING m_sUserId;		//用户ID
	IRS_STRING m_sSecurityId;	//合约品种
	char m_sSide;			//买卖方向
	IRS_STRING m_sPrice;		//订单报价
	IRS_STRING m_sOrderQty;		//名义本金
	IRS_STRING m_sPrice2;		//订单报价
	IRS_STRING m_sOrderQty2;	//名义本金
	IRS_STRING m_sEffectTime;	//有效时间
	IRS_STRING m_sOrdType;		//订单提交类型
	IRS_STRING m_sExecInst;		//执行指令&是否强制执行（S-保存，2-提交，2c-强制执行提交）
};

class MessageAnalyst_NewOrderMultileg : public MessageAnalyst_Basic
{
public:
	MessageAnalyst_NewOrderMultileg(void)
	{
	
	}
	virtual ~MessageAnalyst_NewOrderMultileg(void)
	{
	
	}

public:
	virtual APP_ERROR_CODE AnalyzeMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet);
	virtual APP_ERROR_CODE CreateMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet);

};

/*
* MultilegOrderCancelReplace消息解析
* 1)结果数据结构类
* 2)消息解析类
*/
class AnalystRet_MultilegOrderCancelReplace : public AnalystRet_NewOrderMultileg
{
public:
	AnalystRet_MultilegOrderCancelReplace(void)
	{
	
	}
	virtual ~AnalystRet_MultilegOrderCancelReplace(void)
	{
	
	}

public:
	PREFIX IRS_STRING GetOrdId()
	{
		return m_sOrdId;
	}
public:
	IRS_STRING m_sOrdId;		//订单编号
};

class MessageAnalyst_MultilegOrderCancelReplace : public MessageAnalyst_Basic
{
public:
	MessageAnalyst_MultilegOrderCancelReplace(void)
	{
	
	}
	virtual ~MessageAnalyst_MultilegOrderCancelReplace(void)
	{
	
	}

public:
	virtual APP_ERROR_CODE AnalyzeMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet);
	virtual APP_ERROR_CODE CreateMessage(IMIX::BasicMessage* pMsg, AnalystRet_Basic* pRet);

};


#endif