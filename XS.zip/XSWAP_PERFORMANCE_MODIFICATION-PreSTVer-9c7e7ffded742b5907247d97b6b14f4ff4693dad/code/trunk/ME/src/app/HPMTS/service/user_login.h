/***
Created on July 20, 2017
@author: Jiawang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _USER_LOGIN_H_
#define _USER_LOGIN_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files */
#include "app_shl.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "msg_type.h"
#include "login.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT SerializeUsrRefData(int32 connId, IntrnlMsgTypeT eMessageType, UsrOnln* pUsrOnln, UsrLgnHstry* pUsrHstry, char* strCWUsrNm, int32 intOrgId);

ResCodeT UpdateOrgInfo(int32 connId, char* strUserName, char* strRemoveUserId, char* sUpdateTime);
ResCodeT UpdateOrgInfoBrdg(int32 connId, RemoveUserReqT* pRemoveReq, char* sUpdateTime);
ResCodeT SelectFreezeInfo(int32 connId, char* strRemoveId, char* sUpdateTime, int32* count, FreezeInfoT* freezeInfo);


ResCodeT UserLogin(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);
ResCodeT UserLogout(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);
ResCodeT RemoveOnlineUser(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);


#endif /* _USER_LOGIN_H_ */
