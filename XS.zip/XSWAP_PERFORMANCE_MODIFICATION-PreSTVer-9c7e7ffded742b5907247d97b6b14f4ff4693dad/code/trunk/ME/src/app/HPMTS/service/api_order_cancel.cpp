/***
Created on Sep 19, 2017
@author: Jiawang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <regex.h>
#include <math.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"
#include "internal_base_def.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "usr_def_ref.h"
#include "contract_info.h"
#include "order_submit.h"
#include "order_check.h"
#include "order_book.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : ApiOrderCancel
 **
 ******************************************************************************/
ResCodeT ApiOrderCancel(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "ApiOrderCancel" );
    ResCodeT rc = NO_ERR;

    pOrderCancelRequestReqT pApiReq;
    pNewOrderSingleRspT     pApiResp;

    pApiReq = (OrderCancelRequestReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;

    rc = IrsUsrInfoGetByPosExt(pApiReq->apiLoginUsrIdx, &pApiUsr);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByPosExt(pApiReq->userIdx, &pUsr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByPosExt(pApiReq->orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pApiUsr->usrLgnNm,
                        pOrgInfo->orgCd,
                        FUNC_ID_API_ORD_CANCEL,
                        pApiReq->token,
                        1,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // SP_USRCHECK
    rc = UserCheck(pApiUsr->usrLgnNm, pOrgInfo->orgCd, pUsr->usrLgnNm, pUsr->nmDesc, pOrgInfo->orgCd, C_MKT_TP_IRS);
    RAISE_ERR(rc, RTN);


    rc = ApiCancelOrderCheck(pReq->msgHdr.setId, pApiReq);
    RAISE_ERR(rc, RTN);


    if (pApiReq->apiCancelType == C_API_CANCEL_ONE)
    {
        OrderT  orderReq = {0};
        orderReq.orderF.ordrNo = pApiReq->ordId;
        rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pApiResp);
        RAISE_ERR(rc, RTN);
    }
    else if (pApiReq->apiCancelType == C_API_CANCEL_ALL)
    {
        rc = MtchrPrcsOrdrCnclByUser(pReq->msgHdr.setId, timestamp, pApiReq->userIdx, pApiReq->orgIdx, pApiResp);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : SirsApiOrderCancel
 **
 ******************************************************************************/
ResCodeT SirsApiOrderCancel(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "SirsApiOrderCancel" );
    ResCodeT rc = NO_ERR;

    pOrderCancelRequestReqT pApiReq;
    pNewOrderSingleRspT     pApiResp;

    pApiReq = (OrderCancelRequestReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;

    rc = IrsUsrInfoGetByPosExt(pApiReq->apiLoginUsrIdx, &pApiUsr);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByPosExt(pApiReq->userIdx, &pUsr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByPosExt(pApiReq->orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pApiUsr->usrLgnNm,
                        pOrgInfo->orgCd,
                        FUNC_ID_SIRSAPI_ORD_CANCEL,
                        pApiReq->token,
                        2,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // SP_USRCHECK
    rc = UserCheck(pApiUsr->usrLgnNm, pOrgInfo->orgCd, pUsr->usrLgnNm, pUsr->nmDesc, pOrgInfo->orgCd, C_MKT_TP_SIRS);
    RAISE_ERR(rc, RTN);


    rc = ApiCancelOrderCheck(pReq->msgHdr.setId, pApiReq);
    RAISE_ERR(rc, RTN);


    if (pApiReq->apiCancelType == C_API_CANCEL_ONE)
    {
        OrderT  orderReq = {0};
        orderReq.orderF.ordrNo = pApiReq->ordId;
        rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pApiResp);
        RAISE_ERR(rc, RTN);
    }
    else if (pApiReq->apiCancelType == C_API_CANCEL_ALL)
    {
        rc = MtchrPrcsOrdrCnclByUser(pReq->msgHdr.setId, timestamp, pApiReq->userIdx, pApiReq->orgIdx, pApiResp);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : SbfccpApiOrderCancel
 **
 ******************************************************************************/
ResCodeT SbfccpApiOrderCancel(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "SbfccpApiOrderCancel" );
    ResCodeT rc = NO_ERR;

    pOrderCancelRequestReqT pApiReq;
    pNewOrderSingleRspT     pApiResp;

    pApiReq = (OrderCancelRequestReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;

    rc = IrsUsrInfoGetByPosExt(pApiReq->apiLoginUsrIdx, &pApiUsr);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByPosExt(pApiReq->userIdx, &pUsr);
    RAISE_ERR(rc, RTN);

    rc = OrgInfoGetByPosExt(pApiReq->orgIdx, &pOrgInfo);
    RAISE_ERR(rc, RTN);


    // common check
    int32 iOrgId;
    rc = ApiCommonCheck(
                        pApiUsr->usrLgnNm,
                        pOrgInfo->orgCd,
                        FUNC_ID_SBFCCPAPI_ORD_CANCEL,
                        pApiReq->token,
                        5,
                        timestamp,
                        &iOrgId);
    RAISE_ERR(rc, RTN);


    // SP_USRCHECK
    rc = UserCheck(pApiUsr->usrLgnNm, pOrgInfo->orgCd, pUsr->usrLgnNm, pUsr->nmDesc, pOrgInfo->orgCd, C_MKT_TP_SBFCCP);
    RAISE_ERR(rc, RTN);


    rc = ApiCancelOrderCheck(pReq->msgHdr.setId, pApiReq);
    RAISE_ERR(rc, RTN);


    if (pApiReq->apiCancelType == C_API_CANCEL_ONE)
    {
        OrderT  orderReq = {0};
        orderReq.orderF.ordrNo = pApiReq->ordId;
        rc = MtchrPrcsOrdrCancel(pReq->msgHdr.setId, ORDR_STS_CANCEL, &orderReq, timestamp, pApiResp);
        RAISE_ERR(rc, RTN);

        // todo �������

    }
    else if (pApiReq->apiCancelType == C_API_CANCEL_ALL)
    {
        rc = MtchrPrcsOrdrCnclByUser(pReq->msgHdr.setId, timestamp, pApiReq->userIdx, pApiReq->orgIdx, pApiResp);
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}
