/***
Created on Sep 19, 2017
@author: xuetao.bai
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "msg_type.h"
#include "common_macro.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "msg_risk.h"
#include "risk_update.h"
#include "user_order.h"
#include "match_lib.h"
#include "contract_info.h"
#include "api_common.h"
#include "internal_base_def.h"
#include "credit_common.h"
#include "usr.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/*****************************************************************************
 ** 
 ** FunctionName: RiskUpdate
 ** Description:  Update for RiskVL
 *****************************************************************************/
ResCodeT RiskInfoUpdate(
    int32           connId, 
    pIntrnlMsgT     pReq, 
    pIntrnlMsgT     pRsp, 
    int64           timestamp, 
    pCallBackCtxT   pCtx
)
{
    BEGIN_FUNCTION( "RiskUpdate" );
    ResCodeT                rc = NO_ERR;
    RiskInfoReqT            *pRiskInfoReq;
    RiskInfoRespT           *pRiskInfoResp;
    pUsrBaseInfoT           pUsrData = NULL;
    RiskUpdateDataT         data;
    pCntrctBaseInfoT        dataStr;
    uint64                  maxBoundId;
    int32                   index;
    int32                   dataLen;
    int32                   reqOrgId = 0;
    int32                   usrOrgId = 0;

    pRiskInfoReq    = (RiskInfoReqT*)&pReq->msgBody[0];
    pRiskInfoResp   = (RiskInfoRespT*)&pRsp->msgBody[0];
    memset(pRiskInfoResp, 0x00, sizeof(RiskInfoRespT));

    memset(&data, 0x00, sizeof(RiskUpdateDataT));
    
    data.riskDataBase.eMessageType = (IntrnlMsgTypeT)pReq->msgHdr.msgType;
    data.riskDataBase.setId     = pReq->msgHdr.setId;
    reqOrgId  = atoi(pRiskInfoReq->strOrgId);

    memcpy(data.riskDataBase.strUpdUsrNm, pRiskInfoReq->strUserId,
        sizeof(data.riskDataBase.strUpdUsrNm));
    data.riskDataBase.timestamp = timestamp;
    data.intCount               = pRiskInfoReq->iRiskCount;
    pRiskInfoReq->timestamp     = timestamp;

    dataLen = sizeof(RiskDataBaseT) + sizeof(int32);
    
    rc = IrsUsrInfoGetByNameExt(pRiskInfoReq->strUserId, &pUsrData);
    if (OK(rc))
    {
        if (pUsrData->lgnTp != C_USER_ROLE_GROUND && pUsrData->lgnTp != C_USER_ROLE_EMGCY_GROUND)
        {
            usrOrgId = pUsrData->orgId;
        }
    }

    if (MSG_TYPE_RISK_UPDATE == data.riskDataBase.eMessageType)
    {
        if(FUNC_ID_RISK_UPDATE == data.riskDataBase.setId)
        {
            rc = CommonChk( pRiskInfoReq->strUserId, 
                            reqOrgId, 
                            pRiskInfoReq->iFuncId, 
                            pRiskInfoReq->strToken, 
                            &data.riskDataBase.intOrgId );
        }
        else
        {
            rc = SirsCommonChk( pRiskInfoReq->strUserId, 
                            reqOrgId, 
                            pRiskInfoReq->iFuncId, 
                            pRiskInfoReq->strToken, 
                            &data.riskDataBase.intOrgId );
        }
        RAISE_ERR(rc, RTN);
    }
    else if (MSG_TYPE_API_RISK_UPDATE == data.riskDataBase.eMessageType)
    {
        rc = ApiCommonCheck(
                            pRiskInfoReq->strUserId, 
                            pRiskInfoReq->strOrgId, 
                            pRiskInfoReq->iFuncId, 
                            pRiskInfoReq->strToken,
                            C_MKT_TP_IRS,
                            timestamp,
                            &data.riskDataBase.intOrgId
                             );
        RAISE_ERR(rc, RTN);
    }

    pRiskInfoResp->intOrgId = data.riskDataBase.intOrgId;
    /* 验证授信有效 */
    rc = CreditOrgCheckForRisk(data.riskDataBase.intOrgId);
    if (NOTOK(rc)) 
    {
        data.riskDataBase.intCrdtVldOrgFlag = C_ORG_CRT_USELESS;
        RAISE_ERR(rc, RTN);
    }
    else 
    {
        data.riskDataBase.intCrdtVldOrgFlag = C_ORG_CRT_USEFULL;
    }

    for (index = 0; index < pRiskInfoReq->iRiskCount; index++) 
    {
        if ( pRiskInfoReq->riskCfcnt[index].intRiskCfcnt >= C_RISK_MIN_UNIT && 
            pRiskInfoReq->riskCfcnt[index].intRiskCfcnt <= C_RISK_MAX_UNIT )
        {
            data.riskData[index].intRiskCfcnt  = 
                pRiskInfoReq->riskCfcnt[index].intRiskCfcnt;
            memcpy(data.riskData[index].strCntrctNm, 
                pRiskInfoReq->riskCfcnt[index].strCntrctNm, MAX_CNTRCT_NM);
        }
        else
        {
            RAISE_ERR(ERR_CODE_INVLD_RCKCNF_OR, RTN);
        }

        rc = IrsCntrctInfoGetByNameExt(data.riskData[index].strCntrctNm, 
                &dataStr);
        RAISE_ERR(rc, RTN);
        dataLen += sizeof(RiskDataT);
    }

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_RISK_DAT, &data, dataLen);
    RAISE_ERR(rc, RTN);

    /* 更新风险系数后验证授信有效 */
    rc = CreditOrgCheckForRisk(data.riskDataBase.intOrgId);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    if (NOTOK(rc))
    {
        if (C_ORG_NULL == data.riskDataBase.intOrgId)
        {
            if (C_ORG_NULL != usrOrgId)
            {
                data.riskDataBase.intOrgId = usrOrgId;
            }
            else if (C_ORG_NULL != reqOrgId)
            {
                data.riskDataBase.intOrgId = reqOrgId;
            }
        }
        
        if (C_ORG_NULL != data.riskDataBase.intOrgId)
        {
            RefDatUpdtCmmn(REF_TYP_UNLCK_RISK_DAT, &data, dataLen);
        }
    }

    RETURN_RESCODE;
}
