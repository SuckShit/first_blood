/***
Created on May 30, 2017
@author: Brian.Ping
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "METask_Order.h"
#include "user_order.h"
#include "msg_type.h"
#include "METask_Comm.h"
#include "order_book.h"
#include "contract_info.h"
#include "irs_code_convert.h"
#include "org_info.h"
#include "usr.h"
#include "uti_tool.h"
using namespace IMIX;
using namespace IMIX20;

// Order submit and save
ResCodeT OnOrderSubmitStart(int32 msgType, NewOrderSingle& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrderSubmitStart");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleReqT* pOrderMsg; 
    IRS_STRING strUserId;
    CntrctBaseInfoT cntract;
    char securityId[30];
    pUsrBaseInfoT pUsr = NULL;
    pOrgInfoT pOrgInfo = NULL;
    pCntrctBaseInfoT pCntract = NULL;
    float price = 0;
    
    LOG_INFO("%s: Req message string: %s", "OnOrderSubmitStart", message.ToString().c_str());
    /************************************
                获取消息字段
    *************************************/
    
    pOrderMsg = (NewOrderSingleReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(NewOrderSingleReqT);
    pReq->msgHdr.msgType = msgType;    
    
    //获取机构代码和交易员
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    /* Get User ID*/
    // get userIdx from userId  to be done
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->newOrdrInfo.userIdx =  pUsr->pos;
    
    LOG_DEBUG("OrgId %ld, Usr %s", pUsr->orgId, strUserId.c_str());
    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(pUsr->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);
    
    pOrderMsg->newOrdrInfo.orgIdx = pOrgInfo->pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );

    rc = IrsCntrctInfoGetByNameExt((char *)message.GetSecurityID().c_str(), &pCntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->newOrdrInfo.contractPos = pCntract->pos;
    
    LOG_DEBUG("Get User [%s] pos [%d],contract [%s] pos [%d]",
                            strUserId.c_str(),
                            pOrderMsg->newOrdrInfo.userIdx,
                            message.GetSecurityID().c_str(),
                            pOrderMsg->newOrdrInfo.contractPos);      
    
    //买卖方向    
    rc = SideConvert(message.GetSide(), &pOrderMsg->newOrdrInfo.side);
    RAISE_ERR(rc, RTN);    
    
    CnvtPriceToIntnlVal(message.GetPrice(), &pOrderMsg->newOrdrInfo.prcQtyInfo.price);
    
    pOrderMsg->newOrdrInfo.prcQtyInfo.qty = StringToInt64( message.GetOrderQty() );
    
    //(char* pString, time_t* pTime)
    DateTimeToTimestamp((char *)message.GetEffectiveTime().c_str(), &pOrderMsg->newOrdrInfo.effectTime);

    pOrderMsg->newOrdrInfo.ordType = ImixToIrs_OrdType(CharToString(message.GetOrdType()));
    
    if ( msgType == MSG_TYPE_ORDER_SAVE_MESSAGE )
    {
        pOrderMsg->newOrdrInfo.extOrdType = EXT_ORD_TYPE_NORMAL;
    }
    else
    {
        pOrderMsg->newOrdrInfo.extOrdType = pOrderMsg->newOrdrInfo.ordType;
    }
    
    rc = ExecInstConvert(message.GetExecInst(), &pOrderMsg->newOrdrInfo.execInst);
    RAISE_ERR(rc, RTN);
 
    pOrderMsg->newOrdrInfo.ordAction = ORDR_ACT_NEW;
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.apiLoginUsrIdx = -1;
    pOrderMsg->newOrdrInfo.apiRqstId = 0;
    pOrderMsg->newOrdrInfo.forceId = 0;
    
    EXIT_BLOCK();
    RETURN_RESCODE;     
}

// 订单修改后提交
ResCodeT OnOrderModifySubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox)
{
    BEGIN_FUNCTION("OnOrderModifySubmitStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;
    IRS_STRING strordAction = E_ORD_EXEC_TYPE_MODIFY;
    char  securityId[30];
    CntrctBaseInfoT cntract;
    
    // 消息解析
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORDER_MODIFY_SUBMIT_MESSAGE;
    
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    // get userIdx from userId  to be done
    //rc = getUserId(strUserId.c_str(), &pOrderMsg->userIdx);
    
    //strcpy(pOrderMsg->userId, strUserId.c_str() );
    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId = StringToInt(message.GetOrderID()  );
    
    //strcpy(pOrderMsg->securityId, message.GetSecurityID().c_str()  );
  
    strcpy(securityId, message.GetSecurityID().c_str() );
    rc = IrsCntrctInfoGetByName(&securityId[0], &cntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->contractPos = cntract.pos;
  
    //买卖方向    
    rc = SideConvert(message.GetSide(), &pOrderMsg->side);
    RAISE_ERR(rc, RTN);    
    
    pOrderMsg->price = StringToInt64( message.GetPrice() );
    pOrderMsg->orderQty = StringToInt64( message.GetOrderQty() );
    if (E_OCO_CHECKBOX_TRUE == eOcoCheckBox)
    {
        pOrderMsg->ocoId = StringToInt( message.GetListID() );
    }
    
    pOrderMsg->effectTime = StringToInt(message.GetEffectiveTime());
    rc = OrderTypeConvert(message.GetOrdType(), &pOrderMsg->ordType);
    RAISE_ERR(rc, RTN);
    rc = ExecInstConvert(message.GetExecInst(), &pOrderMsg->execInst);
    RAISE_ERR(rc, RTN);
    pOrderMsg->ordAction = ORDR_ACT_MOD;    

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;        
}

// 订单修改后保存
ResCodeT OnOrderModifySaveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox)
{
    BEGIN_FUNCTION("OnOrderModifySubmitStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;
    IRS_STRING strordAction = E_ORD_EXEC_TYPE_MODIFY;
    char  securityId[30];
    CntrctBaseInfoT cntract;
    
    // 消息解析
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                获取消息字段
    *************************************/
    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORDER_MODIFY_SAVE_MESSAGE;    

    //获取交易员
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    //strcpy(pOrderMsg->userId, strUserId.c_str() );
    // get userIdx from userId  to be done
    //rc = getUserId(strUserId.c_str(), &pOrderMsg->userIdx);
    
    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
//    strcpy(pOrderMsg->ordId, message.GetOrderID().c_str()  );
    pOrderMsg->ordId = StringToInt(message.GetOrderID()  );

    strcpy(securityId, message.GetSecurityID().c_str() );
    rc = IrsCntrctInfoGetByName(&securityId[0], &cntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->contractPos = cntract.pos;
    
    //买卖方向    
    rc = SideConvert(message.GetSide(), &pOrderMsg->side);
    RAISE_ERR(rc, RTN);    
    
    pOrderMsg->price = StringToInt64( message.GetPrice() );
    pOrderMsg->orderQty = StringToInt64( message.GetOrderQty() );
    if (E_OCO_CHECKBOX_TRUE == eOcoCheckBox)
    {
        pOrderMsg->ocoId = StringToInt( message.GetListID()  );
    }    
    
    pOrderMsg->effectTime = StringToInt(message.GetEffectiveTime());
    pOrderMsg->ordAction =   ORDR_ACT_MOD;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE; 
}

ResCodeT OnOrderCnclRplcReqStart(int msgType, OrderCancelReplaceRequest& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrderCnclRplcReqStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;    
    pUsrBaseInfoT pUsr = NULL;
//    // 消息解析
//    OrderCancelReplaceRequest message;
//    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
//    if (!bRet)
//    {
//        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
//    }
    LOG_INFO("%s: Req message string: %s", "OnOrderCnclRplcReqStart", message.ToString().c_str());
    
    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = msgType;    

    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId = StringToInt64(message.GetOrderID().c_str()  );
    
    ExecInstConvert(message.GetExecInst(), &pOrderMsg->execInst);
    RAISE_ERR(rc, RTN);
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;      
}


ResCodeT OnOrderCnclReqStart(int msgType,  OrderCancelRequest& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrderCnclReqStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;    
    pUsrBaseInfoT pUsr = NULL;
    
    LOG_INFO("%s: Req message string: %s", "OnOrderCnclReqStart", message.ToString().c_str());
    
    pOrderMsg = (OrderCancelRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelRequestReqT);
    pReq->msgHdr.msgType = msgType;    

    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;
    

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId = StringToInt64(message.GetOrderID().c_str()  );
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;      
}


ResCodeT OnOrderSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOrderSubmitStop");
    ResCodeT                rc = NO_ERR;
    
    NewOrderSingleRspT*  pOrderSubmitStop;
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
   
    rc = SendMessage(pSendMsgList, pRspMessage);   
    RAISE_ERR(rc, RTN); 

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderSubmitStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspOrder, pOrderSubmitStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspDeal,pOrderSubmitStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspSlot,  pOrderSubmitStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);        
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;        
}



ResCodeT OnOrderModifySubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOrderModifySubmitStop");
    ResCodeT                rc = NO_ERR;
    
    rc = OnOrderSubmitStop(pRsp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;  
}

int OnOrderModifySaveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{

    BEGIN_FUNCTION("OnOrderModifySaveStop");
    ResCodeT                rc = NO_ERR;
    
    rc = OnOrderSubmitStop(pRsp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;  
}

ResCodeT OnOrderCnclRplcReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOrderCnclRplcReqStop");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strErrMsg = "";
    
    NewOrderSingleRspT*  pOrderFreezeStop;
    IRS_STRING strErrCode = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
   
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    
    rc = SendMessage(pSendMsgList, pRspMessage);    
    RAISE_ERR(rc, RTN);
    
    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderFreezeStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderFreezeStop->rspOrder, pOrderFreezeStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderFreezeStop->rspSlot,  pOrderFreezeStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);             
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;        
}



ResCodeT OnOrderCnclReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOrderCnclReqStop");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strErrMsg = "";
    
    NewOrderSingleRspT*  pOrderCnclStop;
    IRS_STRING strErrCode = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
   
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    
    rc = SendMessage(pSendMsgList, pRspMessage);    
    RAISE_ERR(rc, RTN);
    
    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderCnclStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspOrder, pOrderCnclStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspSlot,  pOrderCnclStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);      
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;        
}


ResCodeT OnTrdCancelStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnTrdCancelStart");
    ResCodeT                rc = NO_ERR;
    DealCancelRequestReqT* pDealCnclMsg; 
    pUsrBaseInfoT pUsr = NULL;
    pDealCnclMsg = (DealCancelRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(DealCancelRequestReqT);
    pReq->msgHdr.msgType = MSG_TYPE_DEAL_CNCL_MESSAGE; 
    
    IRS_STRING  strOfficerId;   
    
    // 消息解析
    ExecutionReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    LOG_DEBUG(" Req message string: %s", message.ToString().c_str());
    /************************************
                获取消息字段
    *************************************/
    pDealCnclMsg->dealId = PrefixStringToInt64(message.GetExecID(),3  );
    strcpy(pDealCnclMsg->token, message.GetApplToken().c_str()  );
    
        //获取机构代码和交易员
    rc = GetTraderFromParties(message.GetParties(), strOfficerId,  E_PARTY_ROLE_USER);
    RAISE_ERR(rc, RTN);
    
    // get userIdx from userId  to be done
    rc = IrsUsrInfoGetByNameExt((char *)strOfficerId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    
    pDealCnclMsg->officerIdx =  pUsr->pos;  
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;    
}

ResCodeT OnTrdCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnTrdCancelStop");
    ResCodeT                rc = NO_ERR;
    
    NewOrderSingleRspT*  pOrderSubmitStop;
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
   
    rc = SendMessage(pSendMsgList, pRspMessage);   
    RAISE_ERR(rc, RTN); 

    // 发送推送消息
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderSubmitStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspDeal,pOrderSubmitStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspSlot,  pOrderSubmitStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;        
}

ResCodeT SendOrdTrdToClntStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendOrdTrdToClntStop");
    ResCodeT                rc = NO_ERR;
    
    NewOrderSingleRspT*  pOrderSubmitStop = (NewOrderSingleRspT*)pRsp->msgBody;

//    rc = SendOrderStatusUpdateMsgToTrader(RDP_COMPID, pOrderSubmitStop->rspOrder, pOrderSubmitStop->rspOrderCnt, pSendMsgList);
//    RAISE_ERR(rc, RTN);
//    rc = SendDealMsgToTrader(RDP_COMPID, pOrderSubmitStop->rspDeal,pOrderSubmitStop->rspDealCnt, pSendMsgList);
//    RAISE_ERR(rc, RTN);
//    
    rc = SendOrdrDealStsUpdtMsgToTrdr(RDP_COMPID, pOrderSubmitStop->rspSlot,  pOrderSubmitStop->slotCnt, pSendMsgList);
    RAISE_ERR(rc, RTN);  
        
    EXIT_BLOCK();
    RETURN_RESCODE;        
}

ResCodeT OnSetmentPriceModifyStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSetmentPriceModifyStart");
    ResCodeT                    rc = NO_ERR;
    pSetlPrcModifyReqT          pSetlPrcMsg; 
    string                      strCWXML;
    string                      strSubMarket;
    DATASET_HEADER_DATA         header;
    vector<IMIX::BasicMessage>  vectMsg;

    // 消息解析
    DataSet message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    strSubMarket = message.GetApplID();

    pSetlPrcMsg = (pSetlPrcModifyReqT)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(SetlPrcModifyReqT);
    pReq->msgHdr.msgType = MSG_TYPE_SETL_PRC_MODIFY;
    
    if (IMIX_SECURITY_TYPE_SIRS_M == strSubMarket)
	{
		pSetlPrcMsg->iFuncId = FUNC_ID_SIRS_SETTLEMENT_MODIFY;
	}
	else if (IMIX_SECURITY_TYPE_CCP_SBF_M == strSubMarket)
	{
		pSetlPrcMsg->iFuncId = FUNC_ID_SBFCCP_SETTLEMENT_MODIFY;
	}

    strCWXML            = message.GetApplToken();
    LOG_INFO("strCWXML:%s", strCWXML.c_str());
    GetPriceXMLContent(strCWXML, pSetlPrcMsg);

    LOG_INFO("[%s] In condition: strUserId = %s, strToken = %s, strContract = %s,strPriceDate = %s, strPrice = %lld",
             "OnSetmentPriceModifyStart", pSetlPrcMsg->strUserId, pSetlPrcMsg->strToken, 
             pSetlPrcMsg->strCntrctNm, pSetlPrcMsg->strPriceDate, pSetlPrcMsg->stlPrice);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnSetmentPriceModifyStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnSetmentPriceModifyStop");
    ResCodeT                rc = NO_ERR;
    pSetlPrcModifyReqT      pSetlPrc = NULL;
    IRS_STRING              strErrCode = "";
    IRS_STRING              strErrMsg = "";
    string                  strResult;
    int32                   applRefSeqNum;

    ExecutionReport* pRspMessage = new ExecutionReport;

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
   
    rc = SendMessage(pSendMsgList, pRspMessage);   
    RAISE_ERR(rc, RTN); 

       
    EXIT_BLOCK();
    RETURN_RESCODE;
}
