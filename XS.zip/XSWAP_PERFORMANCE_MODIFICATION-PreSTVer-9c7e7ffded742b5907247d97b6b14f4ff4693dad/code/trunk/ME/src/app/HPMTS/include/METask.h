/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef SPTask_H
#define SPTask_H

#include <iomanip>
#include <vector>
#include "ISPTask.h"
#include "intrnl_msg.h"
#include "MatchingTimer.h"
#include "internal_function_def.h"
#include "err_lib.h"

/********************
���SOʵ����
*********************/
class METask : public ISPTask
{
public:
    METask();
    ~METask();

    virtual int DefineTimer(TimerList* lTimerList);
    ResCodeT OnMEStartPlus(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq); 
    ResCodeT OnMEStopPlus(IntrnlMsgT* pInterMsg, SENDMSGLIST* pOutImixMsg);
private:
    ResCodeT InitStartFunctionHash();
    // ��Ϣ��������ӳ���
    map<IRS_STRING, ResCodeT (*)(const IMIX::BasicMessage&, IntrnlMsgT*)> m_mapStart;

    //�������ڼ����Ϣ
    IMIX20::ExecutionReport* m_pOrderCheckMsg;
    //���вο��ۼ�����Ϣ
    IMIX20::ExecutionReport* m_pMarketDataReqMsg;
    
    IMIX20::ExecutionReport* m_pMktDatPushMsg;
        
    IMIX20::ExecutionReport* m_pBrdgOrdrMsg;    
};


extern "C" {
#if WIN32
    __declspec(dllexport)
#endif
    void* Create();
}

#endif 