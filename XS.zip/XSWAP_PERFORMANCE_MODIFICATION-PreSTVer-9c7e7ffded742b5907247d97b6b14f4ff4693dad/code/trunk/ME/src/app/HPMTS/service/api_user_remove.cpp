/***
Created on Sep 7, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "usr_def_ref.h"
#include "user_login.h"
#include "match_lib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback : ApiUserRemove
 **
 ******************************************************************************/
ResCodeT ApiUserRemove(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiUserRemove" );
    ResCodeT rc = NO_ERR;

    ApiUserRemoveReqT*      pApiReq;
    NewOrderSingleRspT*     pApiResp;

    pApiReq = (ApiUserRemoveReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(NewOrderSingleRspT);
    pApiResp = (NewOrderSingleRspT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(NewOrderSingleRspT));


    // common check
    int32 iOrgId;
    rc = CommonChk(pApiReq->strUserId, C_ORG_NULL, pApiReq->iFuncId, pApiReq->strToken, &iOrgId);
    RAISE_ERR(rc, RTN);


    // get current time
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);


    if (strcmp(pApiReq->strRemoveUsrId, "") == 0)
    {
        // ������ʷ��
        UsrLgnHstry sHistory;
        memset(&sHistory, 0, sizeof(UsrLgnHstry));
        strcpy(sHistory.usrNm, " ");
        itoa(C_OPTION_TP_OUT, sHistory.oprtTp, 10);
        strcpy(sHistory.lgnIp, " ");
        strcpy(sHistory.oprtTm, strTimestamp);
//        rc = InsertUserLoginHistory(connId, &sHistory);
//        RAISE_ERR(rc, RTN);

        // todo ��ȡȫ��api�û���Ϣ����
        // GetOnlnApiUsrInfo();

        // ɾ�����߱�
//        rc = DeleteApiUsrByFlag(connId, C_API_USRFLAG);
//        RAISE_ERR(rc, RTN);

        // ��Ϊ����Ȩ��API�û�����������api��Ч����
        // SP_IRSAPI_ORDCANCELALL
        NewOrderSingleRspT  sApiResp;
        rc = MtchrPrcsApiOrdrCncl(pReq->msgHdr.setId, timestamp, &sApiResp);
        RAISE_ERR(rc, RTN);
        // SP_SIRSAPI_ORDCANCELALL
        // SP_SBFCCPAPI_ORDCANCELALL

        // ��Ϊ����Ȩ��API�û���ȡ�����ģ�ɾ��API���鶩�ı���Ӧ�� ???
//        rc = DeleteAllQtSbscrptnApi(connId);
//        RAISE_ERR(rc, RTN);

        // �������API�����û���status
//        rc = ClearAllOnlnApiStatus(connId);
//        RAISE_ERR(rc, RTN);

        // for user login ref
        rc = SerializeUsrRefData(connId, MSG_TYPE_API_USER_REMOVE, NULL, &sHistory, pApiReq->strUserId, 0);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        // �����û��ǳ�

        // ��ȡ�û�cnt
        pUsrBaseInfoT pUserInfo;
        pOrgInfoT pOrgInfo;

        rc = IrsUsrInfoGetByNameExt(pApiReq->strRemoveUsrId, &pUserInfo);
        if (rc != NO_ERR)
        {
            RAISE_ERR(ERR_CODE_INVLD_NOT_LOGON, RTN);
        }
        int iApiF;
        iApiF = atoi(pUserInfo->apiF);
        if (iApiF != C_API_USRFLAG)
        {
            RAISE_ERR(ERR_CODE_INVLD_NOT_LOGON, RTN);
        }

        rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgInfo);
        RAISE_ERR(rc, RTN);


        // todo ��ȡ��api�û���Ϣ����
        // GetOnlnApiUsrInfo(pApiReq->strRemoveUsrId);


        // ɾ�����߱�
//        rc = DeleteApiUsrByNameAndFlag(connId, pApiReq->strRemoveUsrId, C_API_USRFLAG);
//        RAISE_ERR(rc, RTN);

        // ������ʷ��
        UsrLgnHstry sHistory;
        memset(&sHistory, 0, sizeof(UsrLgnHstry));
        strcpy(sHistory.usrNm, pApiReq->strRemoveUsrId);
        itoa(C_OPTION_TP_OUT, sHistory.oprtTp, 10);
        strcpy(sHistory.lgnIp, " ");
        strcpy(sHistory.oprtTm, strTimestamp);
//        rc = InsertUserLoginHistory(connId, &sHistory);
//        RAISE_ERR(rc, RTN);

        // ��ȡ�û����ͣ�ÿ��API�û�����Ӧһ��Ȩ��
        int32       iUserRole;
        rc = CheckApiUserRole(pUserInfo->roleId, iUserRole);
        RAISE_ERR(rc, RTN);

        // get role_id
        if (C_APIUSER_ROLE_DEAL == iUserRole)
        {
            // ����API�û����߳�������

            // SP_IRSAPI_ORDCANCELBYAPIUSR
            rc = MtchrPrcsOrdrCnclByUser(pReq->msgHdr.setId, timestamp, pUserInfo->pos, pOrgInfo->pos, pApiResp);
            RAISE_ERR(rc, RTN);

            // SP_SIRSAPI_ORDCANCELBYAPIUSR
            // SP_SBFCCPAPI_ORDCANCELBYUSR
        }
/*
        else if (C_APIUSER_ROLE_QUOT == iUserRole)
        {
            // �������鶩��
            QtSbscrptnApi key;
            strcpy(key.usrLgnNm, pApiReq->strRemoveUsrId);
            rc = DeleteQtSbscrptnApi(connId, &key);
        }
        else if (C_APIUSER_ROLE_CRDT == iUserRole)
        {
            // ����������״̬��Ϊ�޲���
            rc = UpdateOrgInfo(connId, pApiReq->strUserId, pApiReq->strRemoveUsrId, strTimestamp);
            RAISE_ERR(rc, RTN);
        }
*/

        // �����API�����û���status
//        pUserInfo->usrOnlnStatus = FALSE;

        // for user login ref
        rc = SerializeUsrRefData(connId, MSG_TYPE_API_USER_REMOVE, NULL, &sHistory, pApiReq->strUserId, pUserInfo->orgId);
        RAISE_ERR(rc, RTN);
    }


//    rc = GetBoundId(connId, &pApiResp->iMaxOutboundId);
//    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
