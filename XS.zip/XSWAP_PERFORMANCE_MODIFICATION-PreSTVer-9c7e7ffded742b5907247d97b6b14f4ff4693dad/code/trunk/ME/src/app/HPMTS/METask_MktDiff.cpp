/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "METask_MktDiff.h"
#include "METask_Layer2.h"
#include "METask_Order.h"
#include "METask_BilOrder.h"
#include "METask_OcoOrder.h"
#include "METask_Officer.h"
#include "METask_Client.h"
#include "METask_Timer.h"
#include "Enum.pb.h"
#include "msg_type.h"

using namespace IMIX;
using namespace IMIX20;
using namespace constants;


/***********************************************************
* ��Ϣ����
* ���ܣ����ͻ��˷���������Ϣ�����г���ʶ��������ͬ�ĺ�������
************************************************************/

//�������ύStart����������Start��
ResCodeT OnMktNewOrderSingleMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktNewOrderSingleMsgStart");
    ResCodeT                rc = NO_ERR;

    IMIX20::Instrument *pInstrument;
    string strMarket;
    string strSubMarket;

    // ��Ϣ����,����167SecurityType�ж��г�
    NewOrderSingle message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    pInstrument = message.GetInstrument();
    strMarket = pInstrument->GetSecurityType();
    strSubMarket = pInstrument->GetSecuritySubType();

    if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_NONSIRS == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_IRS;
        rc = OnNewOrderSingleMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SIRS;
        rc = OnNewOrderSingleMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
//        nRet = SBF_OnNewOrderSingleMsgStart(inMessage, pParamList);
    }
    //zgh add 20150527
    else if (IMIX_SECURITY_TYPE_CCP_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SBFCCP;
        rc = OnNewOrderSingleMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_CCP_SIRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
//        nRet = CCP_SIRS_OnNewOrderSingleMsgStart(inMessage, pParamList);
    }
    //end by zgh
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//����������Start����������Start�������޸ĺ󱣴�Start�ȵȡ�
ResCodeT OnMktOrdCancelReplaceReqMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktOrdCancelReplaceReqMsgStart");
    ResCodeT                rc = NO_ERR;

    IMIX20::Instrument *pInstrument;
    string strMarket;
    string strSubMarket;
    char cOrdType;
    bool bBilOrd;

    // ��Ϣ����
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pInstrument = message.GetInstrument();
    strMarket = pInstrument->GetSecurityType();
    strSubMarket = pInstrument->GetSecuritySubType();
    cOrdType = message.GetCommType();
    bBilOrd = (cOrdType==BIL_TYPE)?true:false;

    if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_NONSIRS == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_IRS;
        if (bBilOrd)
        {
            rc = OnBilOrdCancelReplaceReqMsgStart(inMessage, pReq);
        }
        else
        {
            rc = OnOrdCancelReplaceReqMsgStart(inMessage, pReq);
        }
    }
    else if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SIRS;
        rc = OnOrdCancelReplaceReqMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
//        rc = SBF_OnOrdCancelReplaceReqMsgStart(inMessage, pReq);
    }
    // zgh 20150528
    else if (IMIX_SECURITY_TYPE_CCP_SIRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
//        rc = CCP_SIRS_OnOrdCancelReplaceReqMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_CCP_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SBFCCP;
        rc = OnOrdCancelReplaceReqMsgStart(inMessage, pReq);
    }
    // end by zgh

    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//����������start��
ResCodeT OnMktOrderCancelStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktOrderCancelStart");
    ResCodeT                rc = NO_ERR;

    IMIX20::Instrument *pInstrument;
    string strMarket;
    string strSubMarket;
    char cOrdType;
    bool bBilOrd;

    // ��Ϣ����,����167SecurityType�ж��г�
    OrderCancelRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pInstrument = message.GetInstrument();
    strMarket = pInstrument->GetSecurityType();
    strSubMarket = pInstrument->GetSecuritySubType();
    cOrdType = message.GetOptAttribute();
    bBilOrd = (cOrdType==BIL_TYPE)?true:false;

    if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_NONSIRS == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_IRS;
        if (bBilOrd)
        {
            if (message.GetOrderCancelType() == 2)
            {
                rc = OnBilOrderCnclReqStart(MSG_TYPE_BILORDER_WITHDRAW_MESSAGE, message, pReq);
            }
            else
            {
                rc = OnBilOrderCnclReqStart(MSG_TYPE_BILORDER_CANCEL_MESSAGE, message, pReq);
            }
        }
        else
        {
            if (message.GetOrderCancelType() == 2)
            {
                rc = OnOrderCnclReqStart(MSG_TYPE_ORDER_WITHDRAW_MESSAGE, message, pReq);
            }
            else
            {
                rc = OnOrderCnclReqStart(MSG_TYPE_ORDER_CANCEL_MESSAGE, message, pReq);
            }
        }
    }
    else if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SIRS;
        if (message.GetOrderCancelType() == 2)
        {
            rc = OnOrderCnclReqStart(MSG_TYPE_ORDER_WITHDRAW_MESSAGE, message, pReq);
        }
        else
        {
            rc = OnOrderCnclReqStart(MSG_TYPE_ORDER_CANCEL_MESSAGE, message, pReq);
        }
    }
    else if (IMIX_SECURITY_TYPE_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
//        rc = SBF_OnOrderCancelStart(inMessage, pReq);
    }
    // zgh 20150528
    else if (IMIX_SECURITY_TYPE_CCP_SIRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
//        rc = CCP_SIRS_OnOrderCancelStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_CCP_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SBFCCP;
        if (message.GetOrderCancelType() == 2)
        {
            rc = OnOrderCnclReqStart(MSG_TYPE_ORDER_WITHDRAW_MESSAGE, message, pReq);
        }
        else
        {
            rc = OnOrderCnclReqStart(MSG_TYPE_ORDER_CANCEL_MESSAGE, message, pReq);
        }
    }
    // end by zgh
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/***********************************************************
* ��Ϣ����
* ���ܣ����ͻ��˷���������Ϣ�����г���ʶ��������ͬ�ĺ�������
************************************************************/
ResCodeT OnCGMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnCGMsgStart");
    ResCodeT                rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;
    char cActionType = CHAR_DEFAULT;
    char cType;

    // ��Ϣ����,����167SecurityType�ж��г�
    PartyDetailsListReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    cActionType = message.GetPartyDetailsListReportUpdateAction();
    cType = message.GetPartyInfoType();//�����˻���Ϣ

    // M��ʾ�ʽ��˻�����
    if ('M' == cActionType && '2' == cType )
    {
    //    rc = OnAccountUpdateStart(inMessage, pReq);//�ʽ��˻�����
    }
    else if ('M' == cActionType && '3' == cType)//�й��˻�����
    {
    //    rc = SBF_OnAccountUpdateStart(inMessage, pReq);
    }
    else if (CHAR_DEFAULT == cActionType)
    {
        rc = OnBankFreezeStart(inMessage, pReq);
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnMktNewOrderListMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktNewOrderListMsgStart");


    int nRet = APP_CODE_SUCCESS;
    ListOrdGrp* pListOrdGrp ;
    ListOrdGrp::NoOrders*pNoOrders;
    Instrument* pInstrument;
    string strMarket;
    string strSubMarket;
    // ��Ϣ����,����167SecurityType�ж��г�
    NewOrderList message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //message.GetApplID();

    pListOrdGrp = message.GetListOrdGrp();
    pNoOrders = pListOrdGrp->GetNoOrders();
    pInstrument = pNoOrders->GetInstrument();

    strMarket = pInstrument->GetSecurityType();
    strSubMarket = pInstrument->GetSecuritySubType();

    LOG_DEBUG("strExecInst: %s .", strSubMarket.c_str());

    if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_NONSIRS == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_IRS;
        nRet = OnNewOrderListMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SIRS;
        nRet = OnNewOrderListMsgStart(inMessage, pReq);
    }
    else if (IMIX_SECURITY_TYPE_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        //nRet = SBF_OnNewOrderListMsgStart(inMessage, pParamList);
    }
    else if (IMIX_SECURITY_TYPE_CCP_SIRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        //nRet = CCP_SIRS_OnNewOrderListMsgStart(inMessage, pParamList);
    }
    else if (IMIX_SECURITY_TYPE_CCP_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SBFCCP;
        nRet = OnNewOrderListMsgStart(inMessage, pReq);
    }
    // end by zgh
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT OnMktOcoOrderCancelStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktOcoOrderCancelStart");
    ResCodeT                rc = NO_ERR;
    string strSubMarket;

    // ��Ϣ����,����167SecurityType�ж��г�
    ListCancelRequest message;
    //OrderCancelRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strSubMarket = message.GetApplID();

    if (IMIX_SECURITY_TYPE_NONSIRS_M == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_IRS;
        
        if ( !memcmp(message.GetText().c_str(), "R", 1) )
        {
            rc = OnOcoOrderCnclReqStart(MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE,message, pReq);
        }
        else
        {
            rc = OnOcoOrderCnclReqStart(MSG_TYPE_OCOORDER_CANCEL_MESSAGE,message, pReq);
        }
    }
    else if (IMIX_SECURITY_TYPE_SIRS_M == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SIRS;
        
        if ( !memcmp(message.GetText().c_str(), "R", 1) )
        {
            rc = OnOcoOrderCnclReqStart(MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE,message, pReq);
        }
        else
        {
            rc = OnOcoOrderCnclReqStart(MSG_TYPE_OCOORDER_CANCEL_MESSAGE,message, pReq);
        }
    }
    else if (IMIX_SECURITY_TYPE_SBF_M == strSubMarket)
    {
//        rc = SBF_OnOcoOrderCancelStart(inMessage, pParamList);
    }
    // zgh 20150528
    else if (IMIX_SECURITY_TYPE_CCP_SIRS_M == strSubMarket)
    {
//        rc = CCP_SIRS_OnOcoOrderCancelStart(inMessage, pParamList);
    }
    else if (IMIX_SECURITY_TYPE_CCP_SBF_M == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SBFCCP;
        
        if ( !memcmp(message.GetText().c_str(), "R", 1) )
        {
            rc = OnOcoOrderCnclReqStart(MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE,message, pReq);
        }
        else
        {
            rc = OnOcoOrderCnclReqStart(MSG_TYPE_OCOORDER_CANCEL_MESSAGE,message, pReq);
        }
    }
    // end by zgh
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//���ɽ���������Start��
ResCodeT OnMktExecutionReportStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktExecutionReportStart");
    ResCodeT                rc = NO_ERR;

    // ��Ϣ����,����167SecurityType�ж��г�
    ExecutionReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        return APP_CODE_INCOM_MSG_INVALID;
    }

    IMIX20::Instrument *pInstrument = message.GetInstrument();
    string strMarket = pInstrument->GetSecurityType();
    string strSubMarket = pInstrument->GetSecuritySubType();
    string strExecInst = message.GetExecInst();

    if ( EXECINST_ORD_CHECK == strExecInst)
    {
        rc = OnPeriodValidateStart(inMessage, pReq);//�������ڼ��
    }
    else if ( EXECINST_MKT_DAT_PUSH == strExecInst)
    {
        rc = OnMktDatPushStart(inMessage, pReq);//�������ڼ��
    }
    else if ( EXECINST_BRDG_ORDR_TRGR == strExecInst)
    {
        rc = OnBrdgOrdrStart(inMessage, pReq);//to build bridge order
    }
    else if ( EXECINST_CAL_REF_PRC_TRGR == strExecInst)
    {
        rc = OnTimerCalRefPrcStart(inMessage, pReq);//to re calculate the reference price
    }
    else if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_NONSIRS == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_IRS;
        rc = OnTrdCancelStart(inMessage, pReq);////IRS deal cancellation
    }
    else if (IMIX_SECURITY_TYPE_IRS == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SIRS;
        rc = OnTrdCancelStart(inMessage, pReq);//SIRS�г���������
    }
    else if (IMIX_SECURITY_TYPE_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        //rc = OnTrdCancelStart(inMessage, pReq);//SBF�г���������
    }
    else if (IMIX_SECURITY_TYPE_CCP_SBF == strMarket && IMIX_SECURITY_TYPE_STANDARD == strSubMarket)
    {
        pReq->msgHdr.setId = SET_MKT_SBFCCP;
        rc = OnTrdCancelStart(inMessage, pReq);//SBFCCP�г���������
    }
    else
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s MarketType error!", sFunction.c_str());
        //nRet = APP_CODE_MARKET_ERR;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//��DataSet��Ϣ����Start��
ResCodeT OnMktDataSetMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktDataSetMsgStart");
    ResCodeT rc = NO_ERR;

    int nRet = APP_CODE_SUCCESS;

    int nDateType;
    string strSubMarket;

    // ��Ϣ����,����167SecurityType�ж��г�
    DataSet message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strSubMarket = message.GetApplID();

    //�ͻ���    protobuf��¼�ǳ�������ʱ����
    nDateType = message.GetDataType();

    if (BRDG_DEALER_UPDATE == nDateType ||
        BRDG_CRDT_MODIFY == nDateType ||
        BRDG_CRDT_UPDATE == nDateType ||
        DEALAPI_TRADERPRIVIL_UPDATE == nDateType)
    {
        rc = OnBrdgInterfaceStart(inMessage, pReq);
    }
    else
    {

        if (IMIX_SECURITY_TYPE_NONSIRS_M == strSubMarket)
        {
            pReq->msgHdr.setId = SET_MKT_IRS;
            nRet = OnDataSetMsgStart(inMessage, pReq);
        }
        else if (IMIX_SECURITY_TYPE_SIRS_M == strSubMarket)
        {
            pReq->msgHdr.setId = SET_MKT_SIRS;
            nRet = OnDataSetMsgStart(inMessage, pReq);
        }
        else if (IMIX_SECURITY_TYPE_SBF_M == strSubMarket)
        {
            pReq->msgHdr.setId = SET_MKT_SBFCCP;
            nRet = OnDataSetMsgStart(inMessage, pReq);
        }
        else if (IMIX_SECURITY_TYPE_CCP_SIRS_M == strSubMarket)
        {
            // nRet = CCP_SIRS_OnDataSetMsgStart(inMessage, pParamList);
        }
        else if (IMIX_SECURITY_TYPE_CCP_SBF_M == strSubMarket)
        {
            // nRet = CCP_SBF_OnDataSetMsgStart(inMessage, pParamList);
        }
        else
        {
            // LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s MarketType error!", sFunction.c_str());
            // nRet = APP_CODE_MARKET_ERR;
        }
    }   //�ͻ���protobuf

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}