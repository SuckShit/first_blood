/***
Created on Aug 02, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _BASE_PARAM_UPDATE_H_
#define _BASE_PARAM_UPDATE_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define PARAM_VALUE_LEN               100
#define UPDATE_USER_LEN               100
#define PARAM_NAME_LEN                100
#define BASE_PARAM_UPD_COLUMN_NUM     2

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT BaseParamUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp);

ResCodeT MarketStateTimeUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);
#endif /* _BASE_PARAM_UPDATE_H_ */
