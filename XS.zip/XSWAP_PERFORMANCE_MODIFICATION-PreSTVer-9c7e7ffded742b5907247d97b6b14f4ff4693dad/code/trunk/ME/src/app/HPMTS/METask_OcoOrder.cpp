/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "METask_OcoOrder.h"
#include "METask_Comm.h"
#include "METask_Order.h"
#include "irs_code_convert.h"
#include "METask_CallSub.h"
#include "usr.h"
#include "contract_info.h"
#include "uti_tool.h"
#include "msg_type.h"
#include "internal_base_def.h"

using namespace IMIX;
using namespace IMIX20;
/*======================================================
* Start��������ʵ�ֿ�
========================================================*/
// OCO order activate, freeze process function
ResCodeT OnOcoOrderCnclRplcReqStart(int msgType, const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOcoOrderCnclRplcReqStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;
    pUsrBaseInfoT pUsr = NULL;
    
    // ��Ϣ����
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    
    LOG_INFO("%s: Req message string: %s", "OnOcoOrderCnclRplcReqStart", message.ToString().c_str());

    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = msgType;    
    
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;    
    
    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId =  PrefixStringToInt64(message.GetListID(),3  );

    ExecInstConvert(message.GetExecInst(), &pOrderMsg->execInst);
    RAISE_ERR(rc, RTN);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;  
}

// OCO order activate, freeze process function
ResCodeT OnOcoOrderCnclReqStart(int msgType, ListCancelRequest& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOcoOrderCnclReqStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;
    pUsrBaseInfoT pUsr = NULL;
    
    LOG_INFO("%s: Req message string: %s", "OnOcoOrderCnclReqStart", message.ToString().c_str());
    
    pOrderMsg = (OrderCancelRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelRequestReqT);
    pReq->msgHdr.msgType = msgType;    
    
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;    
    
    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId =  PrefixStringToInt64(message.GetListID(),3  );

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;  
}


// OCOC�����ύ
ResCodeT OnOcoOrderSubmitStart(int32 msgType, NewOrderList &message, IntrnlMsgT* pReq, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOrderCancelStart");
    ResCodeT                rc = NO_ERR;

    NewOrderListReqT* pOrderMsg; 
    OCOFirstT*  pOcoFirst;
    NewOrderInfoT*    pOcoSecBid;
    NewOrderInfoT*    pOcoSecAsk;
    
    LOG_INFO("%s: Req message string: %s", "OnOrderCancelStart", message.ToString().c_str());

    pOrderMsg = (NewOrderListReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(NewOrderListReqT);
    pReq->msgHdr.msgType = msgType;       

    pOcoFirst = &pOrderMsg->frstInfo;
    pOcoSecBid = &pOrderMsg->secInfo[0];
    pOcoSecAsk = &pOrderMsg->secAskInfo[0];

    // ����OCO�ύSP
    rc = OnOcoSubmitFirstSpStart(message, pOcoFirst, eCheckBox);
    RAISE_ERR(rc, RTN);
    
    rc = InitOcoOrderCnt();
    RAISE_ERR(rc, RTN);

    rc = OnOcoSubmitSecondSpStart(message, pOcoSecBid, pOcoSecAsk, eCheckBox);    
    RAISE_ERR(rc, RTN);

    rc = GetOcoOrderCnt(&pOrderMsg->secInfoCnt, &pOrderMsg->secAskInfoCnt);
    RAISE_ERR(rc, RTN);    

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;  
}

// OCO�����޸ĺ��ύ
ResCodeT OnOcoOrderModifySubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOcoOrderModifySubmitStart");
    ResCodeT                rc = NO_ERR;
    IMIX::BasicMessage baseMsg;
    IRS_STRING strMsgId;
    int nRet;
    int nIndex;
    NewOrderListReqT* pOcoOrderMsg;
    NewOrderList newOrderMessage;
    OrderCancelReplaceRequest cancelOrderMessage;
    OCOFirstT* pFirst;
    NewOrderInfoT*  pBidInfo;
    NewOrderInfoT*  pAskInfo;
    OCO_CHECKBOX eCheckBox;
    vector<IMIX::BasicMessage> vectMsg;
    DATASET_HEADER_DATA header;
    
    pOcoOrderMsg = (NewOrderListReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(NewOrderListReqT);
    pReq->msgHdr.msgType = MSG_TYPE_OCOORDER_MODIFY_SUBMIT_MESSAGE;

    pFirst = &(pOcoOrderMsg->frstInfo);
    pBidInfo = &pOcoOrderMsg->secInfo[0];
    pAskInfo = &pOcoOrderMsg->secAskInfo[0];
    
    // ��Ϣ����
    DataSet message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    
    //��ȡOCO��״̬
    eCheckBox = GetOcoCheckBox(message);
    if (E_DEFAULT == eCheckBox)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    // ���������Ķ����߼�
    rc = OnOcoSubmitFirstSpStartExe(message, pFirst, eCheckBox);
    RAISE_ERR(rc, RTN); 


    rc = AnalyzeMassMessage(message, header, vectMsg);
    RAISE_ERR(rc, RTN);   

    rc = InitOcoOrderCnt();
    RAISE_ERR(rc, RTN);
    
    for(nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
    {
        baseMsg = vectMsg[nIndex];
        strMsgId = baseMsg.GetHeader()->GetMsgType();
        if (NewOrderListMessageID == strMsgId)
        {
            // ��Ϣ����
            bRet = newOrderMessage.crack(baseMsg);
            if (!bRet)
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            rc = GetOrdNewSubmitParams(newOrderMessage, pBidInfo, pAskInfo, eCheckBox);
            RAISE_ERR(rc, RTN);    
        }
        else if (OrderCancelReplaceRequestMessageID == strMsgId)
        {
            bRet = cancelOrderMessage.crack(baseMsg);
            if (!bRet)
            {
                LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
                nRet = APP_CODE_INCOM_MSG_INVALID;
                break;
            }

            rc = GetOrdModifySubmitParams(cancelOrderMessage, pBidInfo, pAskInfo, eCheckBox);
            RAISE_ERR(rc, RTN);    
        }
    }
    
    rc = GetOcoOrderCnt(&pOcoOrderMsg->secInfoCnt, &pOcoOrderMsg->secAskInfoCnt);
    RAISE_ERR(rc, RTN);
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);    
    
    EXIT_BLOCK();
    RETURN_RESCODE; 
}

// OCOC�����޸ĺ󱣴�
ResCodeT OnOcoOrderModifySaveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOcoOrderModifySaveStart");
    ResCodeT                rc = NO_ERR;
    IMIX::BasicMessage baseMsg;
    IRS_STRING strMsgId;
    int nRet;
    int nIndex;
    NewOrderListReqT* pOcoOrderMsg;
    NewOrderList newOrderMessage;
    OrderCancelReplaceRequest cancelOrderMessage;
    OCOFirstT* pFirst;
    NewOrderInfoT*  pSecInfo;
    NewOrderInfoT*  pTmp;
    OCO_CHECKBOX eCheckBox;
    vector<IMIX::BasicMessage> vectMsg;
    DATASET_HEADER_DATA header;
    
    pOcoOrderMsg = (NewOrderListReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(NewOrderListReqT);
    pReq->msgHdr.msgType = MSG_TYPE_OCOORDER_MODIFY_SUBMIT_MESSAGE;

    pFirst = &(pOcoOrderMsg->frstInfo);
    pSecInfo = &pOcoOrderMsg->secInfo[0];
    
    // ��Ϣ����
    DataSet message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    
    //��ȡOCO��״̬
    eCheckBox = GetOcoCheckBox(message);
    if (E_DEFAULT == eCheckBox)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    // ���������Ķ����߼�
    rc = OnOcoSaveFirstSpStartExe(message, pFirst, eCheckBox);
    RAISE_ERR(rc, RTN); 

    rc = AnalyzeMassMessage(message, header, vectMsg);
    RAISE_ERR(rc, RTN);   

    pTmp = pSecInfo;
    for(nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
    {
        baseMsg = vectMsg[nIndex];
        strMsgId = baseMsg.GetHeader()->GetMsgType();
        if (NewOrderListMessageID == strMsgId)
        {
            // ��Ϣ����
            bRet = newOrderMessage.crack(baseMsg);
            if (!bRet)
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            rc = OnOcoSaveSecondSpStart(newOrderMessage, pTmp, eCheckBox);
            RAISE_ERR(rc, RTN);    
        }
        else if (OrderCancelReplaceRequestMessageID == strMsgId)
        {
            rc = OnOrderModifySaveStartByOco(baseMsg, pTmp, eCheckBox);
            RAISE_ERR(rc, RTN);    
        }
        pTmp= pTmp + 1;
    }
    
    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);    
    
    EXIT_BLOCK();
    RETURN_RESCODE; ;
}


ResCodeT OnOcoOrderCnclRplcReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOcoOrderCnclRplcReqStop");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strErrMsg = "";
    
    NewOrderSingleRspT*  pOrderFreezeStop;
    IRS_STRING strErrCode = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    rc = SendMessage(pSendMsgList, pRspMessage);    
    RAISE_ERR(rc, RTN);
    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderFreezeStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderFreezeStop->rspOrder, pOrderFreezeStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
//        
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderFreezeStop->rspDeal,pOrderFreezeStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderFreezeStop->rspSlot,  pOrderFreezeStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;  
}


ResCodeT OnOcoOrderCnclReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOcoOrderCnclReqStop");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strErrMsg = "";
    
    NewOrderSingleRspT*  pOrderCnclStop;
    IRS_STRING strErrCode = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    rc = SendMessage(pSendMsgList, pRspMessage);    
    RAISE_ERR(rc, RTN);
    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderCnclStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspOrder, pOrderCnclStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspSlot,  pOrderCnclStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;  
}


ResCodeT OnOcoOrderSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{    
    BEGIN_FUNCTION("OnOcoOrderSubmitStop");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strErrMsg = "";
    
    NewOrderSingleRspT*  pOrderSubmitStop;
    IRS_STRING strErrCode = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    
    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    SendMessage(pSendMsgList, pRspMessage);    

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {    
        pOrderSubmitStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspOrder, pOrderSubmitStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
//
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspDeal, pOrderSubmitStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspSlot,  pOrderSubmitStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnOcoOrderModifySaveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnOcoOrderModifySaveStop");
    ResCodeT                rc = NO_ERR;
    
    rc = OnOcoOrderSubmitStop(pRsp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnOcoOrderModifySubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{    
    BEGIN_FUNCTION("OnOcoOrderModifySubmitStop");
    ResCodeT                rc = NO_ERR;
    
    rc = OnOcoOrderSubmitStop(pRsp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
