/***
Created on August 14, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>
#include <stdlib.h>

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "uti_tool.h"
#include "common_macro.h"

#include "pck_irs_util.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "msg_credit.h"
#include "credit_refresh_method_update.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 ** 
 ** FunctionName: CreditRefreshMethodUpdate
 ** Description:  Prepare for Credit Update.
 *****************************************************************************/
ResCodeT CreditRefreshMethodUpdate(
    int32 connId, 
    pIntrnlMsgT pReq, 
    pIntrnlMsgT pRsp, 
    int64 timestamp, 
    pCallBackCtxT pCtx
)
{
    BEGIN_FUNCTION( "CreditRefreshMethodUpdate" );
    ResCodeT rc = NO_ERR;

    CreditRefreshMethodUpdateReqT  *pCreditRefreshMethodUpdateReq;
    CreditRefreshMethodUpdateRespT *pCreditRefreshMethodUpdateResp;
    CreditUpdateDataT data;
    int32 dataLen;

    uint64 maxBoundId;

    /*---------------------------���κ͹��̱����ĳ�ʼ��--------------------*/
    //RequestMessage 
    pCreditRefreshMethodUpdateReq = (CreditRefreshMethodUpdateReqT*)&pReq->msgBody[0];
    //ResponseMessage 
    pCreditRefreshMethodUpdateResp = (CreditRefreshMethodUpdateRespT*)&pRsp->msgBody[0];
    memset(pCreditRefreshMethodUpdateResp, 0x00, sizeof(CreditRefreshMethodUpdateRespT));
    memset(&data, 0x00, sizeof(CreditUpdateDataT));
//    dataLen = sizeof(CreditUpdateDataT);

    // [IN]Set Parameters.
    data.eMessageType = MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE;
    strcpy(data.strUserId, pCreditRefreshMethodUpdateReq->strUserId);
    data.intUpdMthd = pCreditRefreshMethodUpdateReq->iUpdMthd;
    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);

    /*-----------------------------ͨ�ü��--------------------------------*/
    rc = CommonChk( pCreditRefreshMethodUpdateReq->strUserId, 
                    atoi(pCreditRefreshMethodUpdateReq->strOrgId), 
                    pCreditRefreshMethodUpdateReq->iFuncId, 
                    pCreditRefreshMethodUpdateReq->strToken, 
                    &data.intOrgId );
    RAISE_ERR(rc, RTN);

    // Calculate the size of common data
    dataLen  = sizeof(data.eMessageType);
    dataLen += MAX_USR_ID_LENTH;
    dataLen += sizeof(data.intOrgId); 
    dataLen += MAX_TIME_LENGTH;
    dataLen += sizeof(data.intCheckOrg);
    dataLen += sizeof(data.intUpdMthd);
    dataLen += sizeof(data.intCrdtMthd);
    dataLen += sizeof(data.intCrdtVldOrgFlag);
    dataLen += sizeof(data.intCount);

    //--���»�����Ϣ���ж�ȸ��·�ʽ
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_CREDIT_DAT, &data, dataLen);
    RAISE_ERR(rc, RTN);

    /* ����BoundId */
//    rc = GetBoundId(connId, &maxBoundId);
//    pCreditRefreshMethodUpdateResp->iMaxOutBoundId = maxBoundId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
