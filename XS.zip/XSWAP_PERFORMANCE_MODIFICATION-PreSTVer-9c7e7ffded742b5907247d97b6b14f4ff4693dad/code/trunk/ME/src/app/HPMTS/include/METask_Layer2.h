/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef _SPTASK_LAYER2_H_
#define _SPTASK_LAYER2_H_

#include "data_type.h"

#include "internal_function_def.h"
#include "intrnl_msg.h"

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT OnLogonAndOutStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnNewOrderSingleMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnOrdCancelReplaceReqMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnCSMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnBilOrdCancelReplaceReqMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnNewOrderListMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnDataSetMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
    
ResCodeT OnNewOrderMultilegStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnMultilegOrderCancelReplaceStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
#endif
