/***
Created on July 20, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "login.h"
#include "user_login.h"

#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "OrgInfoDb.h"
#include "OrgInfoBrdgDb.h"
#include "usr.h"
#include "usr_role.h"
#include "org_info.h"
#include "base_param.h"

#include "usr_def_ref.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define USRDBREF_TYPE_INSERT_LGHIST      1
#define USRDBREF_TYPE_INSERT_USER_ONLN   2
#define USRDBREF_TYPE_DELETE_USER_ONLN   3
#define USRDBREF_TYPE_UPDATE_USER_ONLN   4

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 **
 ** Function Implementation
 **
 ******************************************************************************/


/******************************************************************************
 **
 ** GetToken
 **
 ******************************************************************************/
ResCodeT GetToken(UserLoginReqT* pLoginReq, int mrktState, char* token)
{
    BEGIN_FUNCTION( "GetToken" );
    ResCodeT rc = NO_ERR;

    if (pLoginReq->iLoginType == C_USER_TYPE_GROUND)
    {
        strcpy(token, pLoginReq->strUniqueKey);
    }
    else
    {
        if (mrktState == C_MKT_ST_CLOSE)
        {
            RAISE_ERR(ERR_CODE_LGN_IN_NO_PRV, RTN);
        }
        else
        {
            int64 nowtime = 0;
            GetSysTimestamp(&nowtime);
            nowtime %= 1000000000000000;
            sprintf(token, "%15lld", nowtime);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** GetAndCheckRole
 **
 ******************************************************************************/
ResCodeT GetAndCheckRole(UserLoginReqT* pLoginReq, int32* iUserRole)
{
    BEGIN_FUNCTION( "UpdateUserOnline" );
    ResCodeT rc = NO_ERR;

    if (pLoginReq->iLoginType == C_USER_TYPE_FRONT)
    {
        BOOL blRoleFrontExist = FALSE;
        BOOL blRoleFrontLimitExist = FALSE;
        IrsUsrRoleIdIsExist(pLoginReq->strUserId, C_USER_ROLE_FRONT, &blRoleFrontExist);
        IrsUsrRoleIdIsExist(pLoginReq->strUserId, C_USER_ROLE_LIMIT_FRONT, &blRoleFrontLimitExist);
        if (blRoleFrontExist)
        {
            *iUserRole = C_USER_ROLE_FRONT;
        }
        else if (blRoleFrontLimitExist)
        {
            *iUserRole = C_USER_ROLE_FRONT;
        }
        else
        {
            RAISE_ERR(ERR_CODE_LGN_IN_NO_PRV, RTN);
        }
    }
    else if (pLoginReq->iLoginType == C_USER_TYPE_BACKGROUND)
    {
        BOOL blRoleBgExist = FALSE;
        IrsUsrRoleIdIsExist(pLoginReq->strUserId, C_USER_ROLE_BACKGROUND, &blRoleBgExist);
        if (blRoleBgExist)
        {
            *iUserRole = C_USER_ROLE_BACKGROUND;
        }
        else
        {
            RAISE_ERR(ERR_CODE_LGN_IN_NO_PRV, RTN);
        }
    }
    else
    {
        BOOL blRoleGExist = FALSE;
        BOOL blRoleEgExist = FALSE;
        IrsUsrRoleIdIsExist(pLoginReq->strUserId, C_USER_ROLE_GROUND, &blRoleGExist);
        IrsUsrRoleIdIsExist(pLoginReq->strUserId, C_USER_ROLE_EMGCY_GROUND, &blRoleEgExist);
        if (blRoleGExist)
        {
            *iUserRole = C_USER_ROLE_GROUND;
        }
        else if (blRoleEgExist)
        {
            *iUserRole = C_USER_ROLE_EMGCY_GROUND;
        }
        else
        {
            RAISE_ERR(ERR_CODE_LGN_IN_NO_PRV, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfo
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfo(
            int32           connId,
            char*           strUserName,
            char*           strRemoveUserId,
            char*           strTimestamp
            )
{
    BEGIN_FUNCTION( "UpdateOrgInfo" );
    ResCodeT rc = NO_ERR;

    OrgInfo data;
    vectorT  keyVct[GET_BIT_VECT_LEN(31)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(31)] = {0};

    memset(&data, 0, sizeof(OrgInfo));
//    strcpy(keyData.crdtOprtr, strRemoveUserId);
    itoa(C_CRT_NONE, data.crdtOprtngSt, 10);
    strcpy(data.crdtOprtr, strUserName);
    strcpy(data.updTm, strTimestamp);
    strcpy(data.updUsrNm, strUserName);

    DbCmmnSetColBit( keyVct, 18 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );
    DbCmmnSetColBit( datVct, 15 );
    DbCmmnSetColBit( datVct, 16 );

    rc = UpdateOrgInfoByKey( connId, &data, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** UpdateOrgInfoBrdg
 **
 ******************************************************************************/
ResCodeT UpdateOrgInfoBrdg(
            int32           connId,
            RemoveUserReqT* pRemoveReq,
            char*           strTimestamp )
{
    BEGIN_FUNCTION( "UpdateOrgInfoBrdg" );
    ResCodeT rc = NO_ERR;

    OrgInfoBrdg keyData;
    OrgInfoBrdg valData;
    vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};

    memset(&keyData, 0, sizeof(OrgInfoBrdg));
    memset(&valData, 0, sizeof(OrgInfoBrdg));
    strcpy(keyData.crdtOprtr, pRemoveReq->strRemoveUserId);
    itoa(C_CRT_NONE, valData.crdtOprtngSt, 10);
    strcpy(valData.crdtOprtr, pRemoveReq->strOfficer);
    strcpy(valData.updTm, strTimestamp);
    strcpy(valData.updUsrNm, pRemoveReq->strOfficer);

    DbCmmnSetColBit( keyVct, 14 );
    DbCmmnSetColBit( datVct, 13 );
    DbCmmnSetColBit( datVct, 14 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoBrdgByKeyRpt( connId, &keyData, &valData, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//static RsltCol gResColSelect[] =
//{
////    colId   colName         bndName         colType     maxSize dataRow pDataValue
//    {1,     "ORG_ID",       ":org_id",      eINTEGER,       0,      0,      0 },
//    {2,     "USR_LGN_NM",   ":usr_lgn_nm",  eVARCHAR2,      0,      0,      0 },
//};
//static int32 gColCntSel = sizeof(gResColSelect)/sizeof(gResColSelect[0]);

ResCodeT SelectFreezeInfo(int32 connId, char* strRemoveId, char* strTimestamp, int32* pCntOut, FreezeInfoT* freezeInfo)
{
    BEGIN_FUNCTION( "SelectFreezeInfo" );
    ResCodeT    rc = NO_ERR;

    BOOL        frstFlag = TRUE;

    UsrOnlnJnT  usrOnlnJn = {0};

    rc = GetResultCntOfUsrOnln( connId, strRemoveId, pCntOut );
    RAISE_ERR(rc, RTN);

    // 3. do select
    if (*pCntOut > 0)
    {
        // 4. get the result
        for (int i = 0; i < *pCntOut; i++)
        {
            memset(&usrOnlnJn, 0x00, sizeof( UsrOnlnJnT ) );
            rc = FetchNextUsrOnlnJn( &frstFlag, connId, strRemoveId, &usrOnlnJn);
            RAISE_ERR(rc, RTN);

            freezeInfo[i].orgId = usrOnlnJn.orgId;
            memcpy(freezeInfo[i].usrLgnNm, usrOnlnJn.usrLgnNm,sizeof(freezeInfo[i].usrLgnNm));
            strcpy(freezeInfo[i].crdtMdffnsh, "����/����ϵ���޸���ϣ�");
            strcpy(freezeInfo[i].currentTime, strTimestamp);
        }
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** SerializeUsrRefData
 **
 ******************************************************************************/
ResCodeT SerializeUsrRefData(
                int32           connId,
                IntrnlMsgTypeT  eMessageType,
                UsrOnln*        pUsrOnln,
                UsrLgnHstry*    pUsrHstry,
                char*           strCWUsrNm,
                int32           intOrgId
                )
{
    BEGIN_FUNCTION( "SerializeUsrRefData" );
    ResCodeT rc = NO_ERR;

    int32 iRefSize;
    iRefSize = sizeof(UserMemDataRefT);

    UserMemDataRefT  s;
    memset(&s, 0, sizeof(UserMemDataRefT));

    s.eMessageType = eMessageType;
    if (strCWUsrNm != NULL)
    {
        strcpy(s.strCWUsrNm, strCWUsrNm);
    }
    s.intOrgId = intOrgId;

    if (pUsrOnln != NULL)
    {
        strcpy(s.sesnId, pUsrOnln->sesnId);
        s.lgnTp = pUsrOnln->lgnTp;
        strcpy(s.apiF, pUsrOnln->apiF);
    }

    if (pUsrHstry != NULL)
    {
        strcpy(s.strUserName, pUsrHstry->usrNm);
        strcpy(s.oprtTp, pUsrHstry->oprtTp);
        strcpy(s.lgnIp, pUsrHstry->lgnIp);
        strcpy(s.oprtTm, pUsrHstry->oprtTm);
    }

    rc = UserDbtRef(connId, &s, iRefSize);
    RAISE_ERR(rc, RTN);

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_USR_DAT, &s, iRefSize);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : UserLogin
 **
 ******************************************************************************/
ResCodeT UserLogin(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "UserLogin" );
    ResCodeT rc = NO_ERR;

    UserLoginReqT*   pLoginReq;
    UserLoginRespT*  pLoginResp;

    pLoginReq = (UserLoginReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(UserLoginRespT);
    pLoginResp = (UserLoginRespT*)&pRsp->msgBody[0];

    memset(pLoginResp, 0, sizeof(UserLoginRespT));


    // 1. get market state, OUT_MRKTSTATE (BASE_PARAM)
    pBaseParamT pParamData;
    int         mrktState;
    rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pParamData);
    RAISE_ERR(rc, RTN);
    mrktState = atoi(pParamData->paramValue);
    pLoginResp->m_iMktSt = mrktState;

    rc = BaseParamGetByNameExt((char*)C_MKT_ST_IRS, &pParamData);
    RAISE_ERR(rc, RTN);
    pLoginResp->m_iMktStSirs = atoi(pParamData->paramValue);

    // 2. �ж��û��Ƿ����      V_USRNUM1 (USR)
    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pLoginReq->strUserId, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }


    // 3. ��ȡ�û���ɫ
    int32 iUserRole;
    rc = GetAndCheckRole(pLoginReq, &iUserRole);
    RAISE_ERR(rc, RTN);
    // out6. m_sUserRole    (USR_ROLE)
    itoa(iUserRole, pLoginResp->m_sUserRole, 10);


    // 4. ��ȡ�û�״̬
    int32 usrSt;
    usrSt = atoi(pUserInfo->usrSt);
    if (usrSt != C_USR_ST_ACTIVE)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }


    // 5. �û���¼
    // ��ȡ��¼ʱ��, updateTime
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);
    strcpy(pLoginResp->m_sUpTime, strTimestamp);


    // ����token
    // out1. m_sToken
    rc = GetToken(pLoginReq, mrktState, pLoginResp->m_sToken);
    RAISE_ERR(rc, RTN);


    // �����û���½��Ϣ
    UsrOnln userData;
    memset(&userData, 0, sizeof(UsrOnln));
    strcpy(userData.usrNm, pLoginReq->strUserId);
    strcpy(userData.sesnId, pLoginResp->m_sToken);
    userData.lgnTp = iUserRole;
    strcpy(userData.lgnTm, strTimestamp);
    strcpy(userData.lgnIp, " ");
    strcpy(userData.apiF, "0");
    if (TRUE == pUserInfo->usrOnlnStatus)
    {
        // update
//        rc = UpdateUserOnline(connId, &userData);
    }
    else
    {
        // insert
//        rc = InsertUserOnline(connId, &userData);
    }
//    RAISE_ERR(rc, RTN);


    // �����û���½��ʷ��Ϣ
    UsrLgnHstry sHistory;
    memset(&sHistory, 0, sizeof(UsrLgnHstry));
    strcpy(sHistory.usrNm, pLoginReq->strUserId);
    itoa(C_OPTION_TP_IN, sHistory.oprtTp, 10);
    strcpy(sHistory.lgnIp, " ");
    strcpy(sHistory.oprtTm, userData.lgnTm);
//    rc = InsertUserLoginHistory(connId, &sHistory);
//    RAISE_ERR(rc, RTN);

//    pUserInfo->usrOnlnStatus = TRUE;

    // out2. m_sUserName   (USR)
    strcpy(pLoginResp->m_sUserName, pUserInfo->nmDesc);

    // out3. m_strOrgId  (USR)
    itoa(pUserInfo->orgId, pLoginResp->m_strOrgId, 10);

    // out5. m_sOrgNameCN    (ORG_INFO)
    pOrgInfoT pOrgData;
    rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgData);
    RAISE_ERR(rc, RTN);
    strcpy(pLoginResp->m_sOrgNameCN, pOrgData->orgNmCn);


    // out4. m_sBrdgFlag (ORG_INFO_BRDG)
    BrdgOrgInfoT brdgOrgInfo;
    uint64 orgId;
    orgId = strtoull(pLoginResp->m_strOrgId, NULL, 0);
    rc = BrdgOrgInfoGetById(orgId, &brdgOrgInfo);
    RAISE_ERR(rc, RTN);
    pLoginResp->m_sBrdgFlag = brdgOrgInfo.brdgPrvlgFlag;


    // for user login ref
    rc = SerializeUsrRefData(connId, MSG_TYPE_USER_LOGIN, &userData, &sHistory, NULL, 0);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : UserLogout
 **
 ******************************************************************************/
ResCodeT UserLogout(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "UserLogout" );
    ResCodeT rc = NO_ERR;

    UserLogoutReqT* pLogoutReq;


    pLogoutReq = (UserLogoutReqT*)&pReq->msgBody[0];


    // do common check
    int32 iOrgId;
    rc = CommonChk(pLogoutReq->strUserId, C_ORG_NULL, pLogoutReq->iFuncId, pLogoutReq->strToken, &iOrgId);
    RAISE_ERR(rc, RTN);


    // ��ȡ�ǳ�ʱ��, updateTime
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);


    // 1. clear online status of USR_ONLN
    // DELETE USR_ONLN WHERE USR_NM = IN_USRID;
//    rc = DeleteUserOnline(connId, pLogoutReq->strUserId);
//    RAISE_ERR(rc, RTN);


    // 2. �����û���½��ʷ��Ϣ
    UsrLgnHstry sHistory;
    memset(&sHistory, 0, sizeof(UsrLgnHstry));
    strcpy(sHistory.usrNm, pLogoutReq->strUserId);
    itoa(C_OPTION_TP_OUT, sHistory.oprtTp, 10);
    strcpy(sHistory.lgnIp, " ");
    strcpy(sHistory.oprtTm, strTimestamp);
//    rc = InsertUserLoginHistory(connId, &sHistory);
//    RAISE_ERR(rc, RTN);


    // 1. �����¼״̬���ڴ��У�
    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pLogoutReq->strUserId, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }
//    pUserInfo->usrOnlnStatus = FALSE;


    // for user login ref
    rc = SerializeUsrRefData(connId, MSG_TYPE_USER_LOGOUT, NULL, &sHistory, NULL, 0);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : RemoveOnlineUser
 **
 ******************************************************************************/
ResCodeT RemoveOnlineUser(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "RemoveOnlineUser" );
    ResCodeT rc = NO_ERR;


    RemoveUserReqT* pRemoveReq;
    RemoveUserRespT* pRemoveResp;

    pRemoveReq = (RemoveUserReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(RemoveUserRespT);
    pRemoveResp = (RemoveUserRespT*)&pRsp->msgBody[0];

    memset(pRemoveResp, 0, sizeof(RemoveUserRespT));


    // do common check
    int32 iOrgId;
    rc = CommonChk(pRemoveReq->strOfficer, atoi(pRemoveReq->strOrgId), pRemoveReq->iFuncId, pRemoveReq->strToken, &iOrgId);
    RAISE_ERR(rc, RTN);


    // ��ȡ�ǳ�ʱ��, updateTime
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);


    // 1. �ж��û��Ƿ��Ѿ���¼
    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pRemoveReq->strRemoveUserId, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(ERR_CODE_INVLD_INVALID_USER, RTN);
    }

    // 1.2. �����û���½��ʷ��Ϣ
    UsrLgnHstry userLoginHistory;
    memset(&userLoginHistory, 0, sizeof(UsrLgnHstry));
    strcpy(userLoginHistory.usrNm, pRemoveReq->strRemoveUserId);
    itoa(C_OPTION_TP_OUT, userLoginHistory.oprtTp, 10);
    strcpy(userLoginHistory.lgnIp, " ");
    strcpy(userLoginHistory.oprtTm, strTimestamp);
//    rc = InsertUserLoginHistory(connId, &userLoginHistory);
//    RAISE_ERR(rc, RTN);

    if (pUserInfo->usrOnlnStatus)
    {
        // 1.1. clear online status of USR_ONLN
        // DELETE USR_ONLN WHERE USR_NM = IN_USRID;
//        rc = DeleteUserOnline(connId, pRemoveReq->strRemoveUserId);
//        RAISE_ERR(rc, RTN);

        // 1.1 �����¼״̬���ڴ��У�
//        pUserInfo->usrOnlnStatus = FALSE;
    }

/*
    // 2. ��ȡ�����û���Ϣ  SP_OT_CURSOR
    int32   count;
    memset(&(pRemoveResp->sFreezeInfo), 0, sizeof(FreezeInfoT)*(MAX_FREEZE_INFO_NUM));
    rc = SelectFreezeInfo(connId, pRemoveReq->strRemoveUserId, strTimestamp, &count, pRemoveResp->sFreezeInfo);
    RAISE_ERR(rc, RTN);
*/
    // 3. ��������
//    rc = UpdateOrgInfo(connId, pRemoveReq->strOfficer, pRemoveReq->strRemoveUserId, strTimestamp);
//    RAISE_ERR(rc, RTN);

//    rc = UpdateOrgInfoBrdg(connId, pRemoveReq, strTimestamp);
//    RAISE_ERR(rc, RTN);

    // for user login ref
    rc = SerializeUsrRefData(connId, MSG_TYPE_REMOVE_ONLINE_USER, NULL, &userLoginHistory, pRemoveReq->strOfficer, pUserInfo->orgId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
