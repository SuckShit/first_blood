/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/

#include "METask_Comm.h"
//#include "METask_CallSubSp.h"
#include "irs_code_convert.h"
#include "UTILITY/base64.h"
#include <vector>
#include "LogInfo.pb.h"
#include "XAPIPbMessage.pb.h"
#include "IMIX20/Component/PartyDetailGrp.h"

#include "irs_match_error_def.h"
#include "user_order.h"
#include "order_book.h"
#include "contract_info.h"
#include "org_info.h"
#include "usr.h"
#include "uti_tool.h"
#include "mem_txn.h"
#include "intrnl_msg.h"
#include "pck_irs_dicdata.h"
#include "msg_setlprc.h"
#include "perf_stat.h"
#include "usr_onln.h"
#include "active_info.h"

using namespace IMIX20;
using namespace xapi;

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define LOGIN_STATUS_SUCCESS 1
#define LOGIN_STATUS_FAIL    2
#define LOGOUT_STATUS_SUCCESS 1
#define LOGOUT_STATUS_FAIL   2
#define CREDITUPDATE_SUCCESS 3
#define CREDITUPDATE_ERROR  10
#define SUBCRIBE_STATUS_SUCCESS 0
#define SUBCRIBE_STATUS_FAIL    1
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT ResrveReqMsg(IMIX::BasicMessage* pReqMessage, ImixHdrT* pImixHdr)
{
    BEGIN_FUNCTION("ResrveMsgHeader");
    ResCodeT                rc = NO_ERR;

    strcpy(&pImixHdr->senderCompID[0], pReqMessage->GetHeader()->GetSenderCompID().c_str());
    strcpy(&pImixHdr->senderSubID[0], pReqMessage->GetHeader()->GetSenderSubID().c_str());
    strcpy(&pImixHdr->onBehalfOfSubID[0], pReqMessage->GetHeader()->GetOnBehalfOfSubID().c_str());
    strcpy(&pImixHdr->onBehalfOfCompID[0], pReqMessage->GetHeader()->GetOnBehalfOfCompID().c_str());
    pImixHdr->applRefSeqNum =  StringToInt(pReqMessage->GetFieldStr(IMIX_SEQ_FIELD_NAME));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetApplRefSeqNum(ImixHdrT* pImixHdr, int32* pApplRefSeqNum )
{
    BEGIN_FUNCTION("GetApplRefSeqNum");
    ResCodeT                rc = NO_ERR;

    *pApplRefSeqNum = pImixHdr->applRefSeqNum;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SetRespMsgHeader(ImixHdrT* pImixHdr, IMIX::BasicMessage* pRspMessage)
{
    BEGIN_FUNCTION("SetRespMsgHeader");
    ResCodeT                rc = NO_ERR;

    pRspMessage->GetHeader()->SetTargetCompID(&pImixHdr->senderCompID[0]);
    pRspMessage->GetHeader()->SetTargetSubID(&pImixHdr->senderSubID[0]);
    pRspMessage->GetHeader()->SetDeliverToSubID(&pImixHdr->onBehalfOfSubID[0]);
    pRspMessage->GetHeader()->SetDeliverToCompID(&pImixHdr->onBehalfOfCompID[0]);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ExecInstConvert(IRS_STRING execInst, int32* pExecInst)
{
    BEGIN_FUNCTION("ExecInstConvert");
    ResCodeT                rc = NO_ERR;

    if (EXECINST_ORD_NEW == execInst )
    {
        *pExecInst = EXEC_INST_ORD_NEW;
    }
    else if (EXECINST_ORD_NEW_EXEC == execInst )
    {
        *pExecInst = EXEC_INST_ORD_NEW_EXEC;
    }
    else if ( EXECINST_ORD_SAVING == execInst )
    {
        *pExecInst = EXEC_INST_ORD_SAVING;
    }
    else if ( EXECINST_ORD_FREEZE == execInst )
    {
        *pExecInst = EXEC_INST_ORD_FREEZE;
    }
    else if ( EXECINST_ORD_ACTIVATE == execInst )
    {
        *pExecInst = EXEC_INST_ORD_ACTIVATE;
    }
    else if ( EXECINST_ORD_ACTIVATE_EXEC == execInst )
    {
        *pExecInst = EXEC_INST_ORD_ACTIVATE_EXEC;
    }
    else if ( EXECINST_ORD_CHECK == execInst )
    {
        *pExecInst = EXEC_INST_ORD_CHECK;
    }
    else if ( EXECINST_TRD_CANCLE == execInst )
    {
        *pExecInst = EXEC_INST_TRD_CANCLE;
    }
    else if ( EXECINST_TRD_STOP == execInst )
    {
        *pExecInst = EXEC_INST_TRD_STOP;
    }
    else if ( EXECINST_TRD_ABANDON == execInst  )
    {
        *pExecInst = EXEC_INST_TRD_ABANDON;
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SideConvert(char cSide, int16* pSide)
{
    BEGIN_FUNCTION("SideConvert");
    ResCodeT                rc = NO_ERR;

    if (cSide == '1')
    {
        *pSide = ORDR_SIDE_BUY;
    }else if (cSide == '2')
    {
        *pSide = ORDR_SIDE_SELL;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SideConvertByCw(string sSide, int16* pSide)
{
    BEGIN_FUNCTION("SideConvert");
    ResCodeT                rc = NO_ERR;

    if (sSide == "0")
    {
        *pSide = ORDR_SIDE_BUY;
    }else if (sSide == "1")
    {
        *pSide = ORDR_SIDE_SELL;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT OrderTypeConvert(char ordType, int32* pOrdType)
{
    BEGIN_FUNCTION("OrderTypeConvert");
    ResCodeT                rc = NO_ERR;

    if (E_IMIX_ORD_TYPE_LIMITPRICE == ordType)
    {
        *pOrdType = ORDR_TYPE_LIMIT;
    }else if (E_IMIX_ORD_TYPE_CLICK == ordType)
    {
        //pOrderMsg->ordType = ORDR_TYPE_CLICK;
    }else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetOrderMktType(int32 setId, IRS_STRING& mktType, IRS_STRING& mktSubType)
{
    BEGIN_FUNCTION("GetOrderMktType");
    ResCodeT                rc = NO_ERR;

    switch (setId)
    {
        case SET_MKT_IRS:
            mktType = IMIX_SECURITY_TYPE_IRS;
            mktSubType = IMIX_SECURITY_TYPE_NONSIRS;
            break;

        case SET_MKT_SIRS:
            mktType = IMIX_SECURITY_TYPE_IRS;
            mktSubType = IMIX_SECURITY_TYPE_STANDARD;
            break;

        case SET_MKT_SBFCCP:
            mktType = IMIX_SECURITY_TYPE_CCP_SBF;
            mktSubType = IMIX_SECURITY_TYPE_STANDARD;
            break;

        default:
            RAISE_ERR(ERR_INVLD_SET_ID, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetErrCodeMsg(ResCodeT inRc, IRS_STRING& strErrCode, IRS_STRING& strErrMsg)
{
    BEGIN_FUNCTION("GetErrCodeMsg");
    ResCodeT                rc = NO_ERR;

    rc = (inRc == NO_ERR)? 0 : inRc;
    IntToString(rc, strErrCode);

    rc = GetErrMsg(inRc,strErrMsg);
    if (NOTOK(rc))
    {
        LOG_DEBUG("Invld Errcode %d", inRc);
    }
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("#msg_out# err code [%s] message [%s]",strErrCode.c_str(),strErrMsg.c_str());

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 统一异常处理，从SPADE返回执行SP出现异常时的处理
// 发送统一的错误应答消息
ResCodeT ResponeExceptionMsg(SENDMSGLIST* pSendMsgList, IMIX::BasicMessage* pRspMessage, int nExceptionFlag)
{
    BEGIN_FUNCTION("ResponeExceptionMsg");
    ResCodeT                rc = NO_ERR;

    IRS_STRING strErrorCode = "";
    IRS_STRING strErrorDesc = IRS_STRING(APP_MSG_UNKNOW_EXCEPTION);
    //    异常情况，先清空发送列表中的消息
    ClearSendMsgList(pSendMsgList);
    // 设置异常统一错误信息
    IntToString(APP_CODE_UNKNOW_EXCEPTION, strErrorCode);
    pRspMessage->SetField(IMIX_ERRCODE_FIELD, strErrorCode);
    pRspMessage->SetField(IMIX_ERRDESC_FIELD, strErrorDesc);
    /// 发送消息
    SendMessage(pSendMsgList, pRspMessage);

    //TBD
    //LOG_ERROR(APP_CODE_UNKNOW_EXCEPTION, APP_MSG_UNKNOW_EXCEPTION);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendMessage(SENDMSGLIST* pSendMsgList, IMIX::BasicMessage* pMsg, string log_description)
{
    BEGIN_FUNCTION("SendMessage");
    ResCodeT                rc = NO_ERR;

    if (pSendMsgList && pMsg)
    {
        pSendMsgList->push_back(pMsg);
        IRS_STRING strMsg = pMsg->ToString();

        if (pMsg->GetHeader()->GetMsgType().c_str() == "U01")
        {
            LOG_DEBUG("#msg_out#  %s  Send message: [%s] TargetCompID: %s, TargetSubID: %s, DeliverToCompID: %s, DeliverToSubID: %s",
            log_description.c_str(),
            pMsg->GetHeader()->GetMsgType().c_str(),
            pMsg->GetHeader()->GetTargetCompID().c_str(),
            pMsg->GetHeader()->GetTargetSubID().c_str(),
            pMsg->GetHeader()->GetDeliverToCompID().c_str(),
            pMsg->GetHeader()->GetDeliverToSubID().c_str());
        }
        else
        {
            LOG_DEBUG("#msg_out#  %s  Send message: [%s] TargetCompID: %s, TargetSubID: %s, DeliverToCompID: %s, DeliverToSubID: %s, strMsg:[%s]",
            log_description.c_str(),

            pMsg->GetHeader()->GetMsgType().c_str(),
            pMsg->GetHeader()->GetTargetCompID().c_str(),
            pMsg->GetHeader()->GetTargetSubID().c_str(),
            pMsg->GetHeader()->GetDeliverToCompID().c_str(),
            pMsg->GetHeader()->GetDeliverToSubID().c_str(),
            strMsg.c_str());
        }
    }
    else
    {
        if (NULL != pMsg)
        {
            delete pMsg;
            pMsg = NULL;
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

void ClearSendMsgList(SENDMSGLIST* pSendMsgList)
{
    //释放消息内存
    SENDMSGLIST::iterator itr = pSendMsgList->begin();
    for (; itr != pSendMsgList->end(); itr++)
    {
        if (NULL != *itr)
        {
            delete *itr;
            *itr = NULL;
        }
    }
    //清空消息列表
    pSendMsgList->clear();
}

ResCodeT SendMsgToGatewayStop(IntrnlMsgT* pRsp, SENDMSGLIST* pOutImixMsg)
{
    BEGIN_FUNCTION("SendMsgToGatewayStop");
    ResCodeT        rc = NO_ERR;
    pActiveInfoT    pActiveInfo = NULL;
    int32           buffLen = 0;
    DatCtrlT*       pCurrDatCtrl = NULL;

    pActiveInfo = (pActiveInfoT)&pRsp->msgBody;

    IMIX20::QueryResult* pRspMessage = new QueryResult;

    buffLen = (pRsp->msgHdr.msgLen - sizeof(MsgHdrT));

    pCurrDatCtrl = (DatCtrlT *)ADDRESS_ADD_OFFSET(&pRsp->msgBody, sizeof(pActiveInfo));

    rc = MakeMsgToGateway(pCurrDatCtrl->currMsgSqno, buffLen, (char *)pActiveInfo, pRspMessage);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("Send to gateway msgSqno %d", pCurrDatCtrl->currMsgSqno);

    rc = SendMessage(pOutImixMsg, pRspMessage);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MakeMsgToGateway(int32 seqNum, int32 buffLen, char* pBuff, IMIX20::QueryResult* pRspMessage)
{
    BEGIN_FUNCTION("MakeMsgToGateway");
    ResCodeT        rc = NO_ERR;

    pRspMessage->GetHeader()->SetTargetCompID(RDP_COMPID);
    pRspMessage->SetApplSeqNum(seqNum);

    std::string strQryType;
    IntToString(1,strQryType);
    pRspMessage->SetQueryType(strQryType);

    MassMessageGrp::NoMassMessage *pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();

    char *out = new char[buffLen * 2 + 1];
    size_t olen;
    char *p = ArraytoHex(pBuff, buffLen, out, &olen);
    p[olen] = 0;
    pNoMassMsg->SetMessageData(p, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] out;
    out = NULL;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendMsgToTDPS(IntrnlMsgT* pRsp, SENDMSGLIST* pOutImixMsg)
{

    BEGIN_FUNCTION("SendMsgToTDPS");
    ResCodeT        rc = NO_ERR;
    pMemTxnEntryT    pMemTxnTEntry = NULL;
    int32 buffLen = 0;

    DatCtrlT*       pCurrDatCtrl = NULL;

    pMemTxnTEntry = (pMemTxnEntryT)&pRsp->msgBody;

    IMIX20::QueryResult* pRspMessage = new QueryResult;

    buffLen = (pRsp->msgHdr.msgLen - sizeof(MsgHdrT));


    pCurrDatCtrl = (DatCtrlT *)ADDRESS_ADD_OFFSET(&pRsp->msgBody , sizeof(MemTxnEntryT));

    rc = MakeMsgToTDPS(pCurrDatCtrl->currMsgSqno, buffLen, (char *)pMemTxnTEntry,  pRspMessage);
    RAISE_ERR(rc, RTN);

    LOG_DEBUG("Send to TDPS msgSqno %d", pCurrDatCtrl->currMsgSqno);

    rc = SendMessage(pOutImixMsg, pRspMessage);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MakeMsgToTDPS(int32 seqNum, int32 buffLen, char* pBuff, IMIX20::QueryResult* pRspMessage)
{
    BEGIN_FUNCTION("MakeMsgToTDPS");
    ResCodeT        rc = NO_ERR;

    pRspMessage->GetHeader()->SetTargetCompID(TDPS_COMPID);
    pRspMessage->SetApplSeqNum(seqNum);

    std::string strQryType;
    IntToString(1,strQryType);
    pRspMessage->SetQueryType(strQryType);

    MassMessageGrp::NoMassMessage *pNoMassMsg = pRspMessage->GetMassMessageGrp()->AddNoMassMessage();

    char *out = new char[buffLen * 2 + 1];
    size_t olen;
    char *p = ArraytoHex(pBuff, buffLen, out, &olen);
    p[olen] = 0;
    pNoMassMsg->SetMessageData(p, olen);
    pNoMassMsg->SetMessageLen(olen);
    delete[] out;
    out = NULL;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT  SendLoginRespMsg(IMIX20::UserResponse* pRspMessage, UserLoginRespT* pRsp, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendLoginRespMsg");
    ResCodeT                rc = NO_ERR;

    pRspMessage->SetApplToken(pRsp->m_sToken);
    pRspMessage->SetUsername(pRsp->m_sUserName);
//    IRS_STRING strOrgId = "";
//    IntToString(oRetParam.m_nOrgId, strOrgId);
    pRspMessage->SetPartyID(pRsp->m_strOrgId);
    pRspMessage->SetPartySubID(pRsp->m_sOrgNameCN);

    PartyDetailGrp* pPartyDetailGrp = pRspMessage->GetPartyDetailGrp();

    PartyDetailSubGrp* pPartyDetailSubGrp;
    PartyDetailSubGrp::NoPartyDetailSubIDs* pNoPartyDetailsSubIDs;
    if (NULL != pPartyDetailGrp)
    {
        PartyDetailGrp::NoPartyDetails *pNoPartyDetails = pPartyDetailGrp->AddNoPartyDetails();
        if (NULL != pNoPartyDetails)
        {
            //设置用户名称
            if (E_USER_ROLE_ALL_PRIVILEGE_USER == pRsp->m_sUserRole)
            {
                pNoPartyDetails->SetPartyDetailStatus(E_USER_ROLE_ALL_PRIVILEGE_USER_IMIX);
                pNoPartyDetails->SetPartyDetailRole(E_USER_ROLE_TRADER_IMIX);
            }
            else if (E_USER_ROLE_NORMAL_PRIVILEGE_USER == pRsp->m_sUserRole)
            {
                pNoPartyDetails->SetPartyDetailStatus(E_USER_ROLE_NORMAL_PRIVILEGE_USER_IMIX);
                pNoPartyDetails->SetPartyDetailRole(E_USER_ROLE_TRADER_IMIX);
            }
            else if (E_USER_ROLE_MID_BACK_USER == pRsp->m_sUserRole)
            {
                pNoPartyDetails->SetPartyDetailRole(E_USER_ROLE_MID_BACK_USER_IMIX);
            }
            else if (E_USER_ROLE_OFFICER == pRsp->m_sUserRole)
            {
                pNoPartyDetails->SetPartyDetailRole(E_USER_ROLE_OFFICER_IMIX);
            }
            else if (E_USER_ROLE_SUPER == pRsp->m_sUserRole)
            {

                pNoPartyDetails->SetPartyDetailRole(E_USER_ROLE_SUPER_IMIX);
            }
            else
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }
            pNoPartyDetails->SetPartyDetailID(pRsp->m_sUserName);
            pNoPartyDetails->SetPartyDetailStatus(pRsp->m_sBrdgFlag);
            //设置机构ID和简称
            pPartyDetailSubGrp = pNoPartyDetails->GetPartyDetailSubGrp();
            if (NULL != pPartyDetailSubGrp)
            {
                pNoPartyDetailsSubIDs = pPartyDetailSubGrp->AddNoPartyDetailSubIDs();
                if (NULL != pNoPartyDetailsSubIDs)
                {
                    pNoPartyDetailsSubIDs->SetPartyDetailSubIDType(E_PARTY_DETAIL_SUBID_TP_ORGNM);
                    pNoPartyDetailsSubIDs->SetPartyDetailSubID(pRsp->m_sOrgNameCN);
                }

                pNoPartyDetailsSubIDs = pPartyDetailSubGrp->AddNoPartyDetailSubIDs();
                if (NULL != pNoPartyDetailsSubIDs)
                {
                    pNoPartyDetailsSubIDs->SetPartyDetailSubIDType(E_PARTY_DETAIL_SUBID_TP_ORGID);
                    pNoPartyDetailsSubIDs->SetPartyDetailSubID(pRsp->m_strOrgId);
                }
            }
        }
    }

    SendMessage(pSendMsgList, pRspMessage);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FmtDealFromDealInfo(int32 iDealSide, IRS_STRING strCompId ,DealInfoT* pDealInfo, ExecutionReport* pDealMsg, pCntrctBaseInfoT pContractInfo)
{
    BEGIN_FUNCTION("FmtDealFromDealInfo");
    ResCodeT                rc = NO_ERR;

    pUsrBaseInfoT pUsr = NULL;
    pOrgInfoT pOrgInfo = NULL;
    IRS_STRING strOrgId = "";
    char strOrdNo[MAX_ORD_NMBR_LEN] = {0};
    char strTrdNo[MAX_ORD_NMBR_LEN] = {0};
    char cSide;
    IRS_STRING strQty = "";
    IRS_STRING strTradePrice = "";
    IRS_STRING strCntrctType = "";
    char trdTime[MAX_DATETIME_LEN] = {0};

    /* update for buy side */
    ExecutionReport* pBidDealMsg = new ExecutionReport();
    pDealMsg->GetHeader()->SetTargetCompID(strCompId);

    if ( ORDR_SIDE_BUY == iDealSide )
    {
        rc = IrsUsrInfoGetByPosExt(pDealInfo->bidUsrIdx, &pUsr);
        RAISE_ERR(rc, RTN);
        pDealMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);

        rc = OrgInfoGetByPosExt(pDealInfo->bidOrgIdx, &pOrgInfo);
        RAISE_ERR(rc, RTN);
        IntToString(pOrgInfo->orgId, strOrgId);
        pDealMsg->GetHeader()->SetDeliverToCompID(strOrgId);

        sprintf(strOrdNo, "%ld", pDealInfo->bidOrdNo);
        pDealMsg->SetOrderID(strOrdNo);

        StringToChar(E_IMIX_SIDE_BID, cSide);
        pDealMsg->SetSide(cSide);

        //设置本方机构和用户
        SetDealMsgParties(pDealMsg->GetParties(), strOrgId, pOrgInfo->orgNmCn,
                        pUsr->usrLgnNm, pUsr->nmDesc, E_PARTY_ROLE_DEAL_USER);

        rc = IrsUsrInfoGetByPosExt(pDealInfo->askUsrIdx, &pUsr);
        RAISE_ERR(rc, RTN);
        rc = OrgInfoGetByPosExt(pDealInfo->askOrgIdx, &pOrgInfo);
        RAISE_ERR(rc, RTN);

        IntToString(pOrgInfo->orgId, strOrgId);
        //设置对手方机构和用户
        SetDealMsgParties(pDealMsg->GetParties(), strOrgId, pOrgInfo->orgNmCn,
            pUsr->usrLgnNm,  pUsr->nmDesc, E_PAPTY_ROLE_ANALOGUE_USER);
    }
    else if ( ORDR_SIDE_SELL == iDealSide )
    {
        rc = IrsUsrInfoGetByPosExt(pDealInfo->askUsrIdx, &pUsr);
        RAISE_ERR(rc, RTN);
        pDealMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);

        rc = OrgInfoGetByPosExt(pDealInfo->askOrgIdx, &pOrgInfo);
        RAISE_ERR(rc, RTN);
        IntToString(pOrgInfo->orgId, strOrgId);
        pDealMsg->GetHeader()->SetDeliverToCompID(strOrgId);

        sprintf(strOrdNo, "%ld", pDealInfo->askOrdNo);
        pDealMsg->SetOrderID(strOrdNo);

        StringToChar(E_IMIX_SIDE_ASK, cSide);
        pDealMsg->SetSide(cSide);

        //设置本方机构和用户
        SetDealMsgParties(pDealMsg->GetParties(), strOrgId, pOrgInfo->orgNmCn,
                        pUsr->usrLgnNm, pUsr->nmDesc, E_PARTY_ROLE_DEAL_USER);

        //设置对手方机构和用户
        rc = IrsUsrInfoGetByPosExt(pDealInfo->bidUsrIdx, &pUsr);
        RAISE_ERR(rc, RTN);
        rc = OrgInfoGetByPosExt(pDealInfo->bidOrgIdx, &pOrgInfo);
        RAISE_ERR(rc, RTN);

        IntToString(pOrgInfo->orgId, strOrgId);

        SetDealMsgParties(pDealMsg->GetParties(), strOrgId, pOrgInfo->orgNmCn,
                pUsr->usrLgnNm,  pUsr->nmDesc, E_PAPTY_ROLE_ANALOGUE_USER);
    }

    sprintf(strTrdNo, "%ld", pDealInfo->tradeNo);
    pDealMsg->SetExecID(IMIX_SECURITY_TYPE_IRS + strTrdNo);

    pDealMsg->SetSecurityID(pContractInfo->cntrctName);
    pDealMsg->SetSecurityType(IMIX_SECURITY_TYPE_IRS);
    pDealMsg->SetSecuritySubType(IMIX_SECURITY_TYPE_NONSIRS);


    IntToString(pContractInfo->cntrctType, strCntrctType);
    pDealMsg->SetSecurityDesc(strCntrctType);

    DoubleToString(pDealInfo->trdAmount, strQty);
    pDealMsg->SetLastQty(strQty);

    CnvtPriceToImixVal(pDealInfo->trdPrice, strTradePrice);
    pDealMsg->SetLastPx(strTradePrice);

    pDealMsg->SetExecType(IrsToImix_DealStatus(pDealInfo->trdSts));

    GetStrDateTimeByFormat(pDealInfo->trdDateTime,trdTime);
    pDealMsg->SetTransactTime(trdTime);


    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT FmtOrderStatusFromOrderInfo(IRS_STRING strCompId ,OrderInfoT* pOrderInfo, ExecutionReport* pOrderStatusMsg)
{
    BEGIN_FUNCTION("FmtOrderStatusFromOrderInfo");
    ResCodeT                rc = NO_ERR;

    pCntrctBaseInfoT pContractInfo = NULL;
    int32   oSide = 0, oType = 0;
    char    cSide;
    pUsrBaseInfoT pUsr = NULL;
    pOrgInfoT pOrgInfo = NULL;

    IRS_STRING strOrgId = "";
    IRS_STRING strMktType = "";
    IRS_STRING strMktSubType = "";

    IRS_STRING strQty = "";
    IRS_STRING strLastQty = "";
    char cType = CHAR_DEFAULT;
    IRS_STRING strPrice = "";

    char orderNo[MAX_ORD_NMBR_LEN] = {0};
    char updateTime[MAX_DATETIME_LEN] = {0};
    char createTime[MAX_DATETIME_LEN] = {0};
    char expireTime[MAX_DATETIME_LEN] = {0};
    char activateTime[MAX_DATETIME_LEN] = {0};
    char strOthrOrdNo[MAX_ORD_NMBR_LEN] = {0};

    oSide = GET_ORDR_SIDE(pOrderInfo->ordrMask);
    oType = GET_ORDR_TYPE(pOrderInfo->ordrMask);


    pOrderStatusMsg->GetHeader()->SetTargetCompID(strCompId);

    rc = IrsUsrInfoGetByPosExt(pOrderInfo->traderId, &pUsr);
    RAISE_ERR(rc, RTN);

    pOrderStatusMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);

    rc = OrgInfoGetByPosExt(pOrderInfo->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    IntToString(pOrgInfo->orgId, strOrgId);
    pOrderStatusMsg->GetHeader()->SetDeliverToCompID(strOrgId);

    sprintf(orderNo, "%ld", pOrderInfo->orderNo);
    pOrderStatusMsg->SetOrderID(orderNo);

    pOrderStatusMsg->SetOrdStatus(IrsToImix_OrdStatus(pOrderInfo->status));

    StringToChar(IrsToImix_Side(oSide), cSide);
    pOrderStatusMsg->SetSide(cSide);

    rc = IrsCntrctInfoGetByPosExt(pOrderInfo->contractPos, &pContractInfo);
    RAISE_ERR(rc, RTN);
    pOrderStatusMsg->SetSecurityID(pContractInfo->cntrctName);

    LOG_DEBUG("Send User [%s] pos [%d],contract [%s] pos [%d]",
                    pUsr->usrLgnNm,
                    pOrderInfo->traderId,
                    pContractInfo->cntrctName,
                    pOrderInfo->contractPos);

    rc = GetOrderMktType( pContractInfo->setId, strMktType, strMktSubType );
    RAISE_ERR(rc, RTN);

    pOrderStatusMsg->SetSecurityType(strMktType);
    pOrderStatusMsg->SetSecuritySubType(strMktSubType);

    DoubleToString(pOrderInfo->qty, strQty);
    pOrderStatusMsg->SetOrderQty(strQty);

    DoubleToString(pOrderInfo->remain, strLastQty);
    pOrderStatusMsg->SetLeavesQty(strLastQty);

    CnvtPriceToImixVal(pOrderInfo->price, strPrice);
    pOrderStatusMsg->SetPrice(strPrice);


    StringToChar(IrsToImix_OrdType(pOrderInfo->extOrdrType), cType);
    pOrderStatusMsg->SetOrdType(cType);

    pOrderStatusMsg->SetExecType(E_IMIX_ORDER_STATUS);

    if (pOrderInfo->extOrdrType == EXT_ORD_TYPE_BIL)
    {
        sprintf(strOthrOrdNo, "%s%ld",BIL_ORD_PREFIX, pOrderInfo->specOrdrId);
        pOrderStatusMsg->SetExecID(strOthrOrdNo);
    }
    else if (pOrderInfo->extOrdrType == EXT_ORD_TYPE_OCO)
    {
        sprintf(strOthrOrdNo, "%s%ld",OCO_ORD_PREFIX, pOrderInfo->specOrdrId);
        pOrderStatusMsg->SetListID(strOthrOrdNo);
    }

    GetStrDateTimeByFormat(pOrderInfo->updateTime,(char *)updateTime);
    pOrderStatusMsg->SetLastUpdateTime(updateTime);

    GetStrDateTimeByFormat(pOrderInfo->createTime,createTime);
    pOrderStatusMsg->SetTransactTime(createTime);


    GetStrDateTimeByFormat(pOrderInfo->expireTime, expireTime);
    pOrderStatusMsg->SetEffectiveTime(expireTime);

    if ( pOrderInfo->activateTime )
    {
        GetStrDateTimeByFormat(pOrderInfo->activateTime,activateTime);
        pOrderStatusMsg->SetActiveTime(activateTime);
    }

    pOrderStatusMsg->SetExecInst(pOrderInfo->rqstId);
    //pOrderStatusMsg->SetExecID(pOrderInfo->bilId);

    rc = SetOrgAndTraderToParties(pOrderStatusMsg->GetParties(), strOrgId, pUsr->usrLgnNm, "");
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendOrderStatusUpdateMsgToTrader(IRS_STRING strCompId, OrderInfoT* pOrders, int32 orderCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendOrderStatusUpdateMsgToTrader");
    ResCodeT                rc = NO_ERR;

    int32 nSize = orderCnt;
    int32 nIndex;
    OrderInfoT* pOrderInfo;

    LOG_DEBUG("In SendOrderStatusUpdateMsgToTrader");

    if (nSize > 0)
    {
        //发送订单状态更新消息到交易
        for (nIndex = 0; nIndex < nSize; ++nIndex)
        {
            pOrderInfo = pOrders + nIndex;
            ExecutionReport* pOrderStatusMsg =   new ExecutionReport();

            rc = FmtOrderStatusFromOrderInfo(strCompId, pOrderInfo, pOrderStatusMsg);
            RAISE_ERR(rc, RTN);

            rc = SendMessage(pSendMsgList, pOrderStatusMsg);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendDealMsgToTrader(IRS_STRING strCompId, DealInfoT* pDeals, int32 rspDealCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendDealMsgToTrader");
    ResCodeT                rc = NO_ERR;
    int32 nIndex;
    DealInfoT* pDealInfo;
    pCntrctBaseInfoT pContractInfo = NULL;

    LOG_DEBUG("In SendDealMsgToTrader");


    for (nIndex = 0; nIndex < rspDealCnt; ++nIndex)
    {
        pDealInfo = pDeals + nIndex;

        //如果是期差订单则不发送
        rc = IrsCntrctInfoGetByPosExt(pDealInfo->contractPos, &pContractInfo);
        RAISE_ERR(rc, RTN);

        if (IsCombContract(pContractInfo->cntrctName)||IsBasContract(pContractInfo->cntrctName))
        {
            continue;
        }

        ExecutionReport* pBidDealMsg = new ExecutionReport();
        rc = FmtDealFromDealInfo(ORDR_SIDE_BUY, strCompId ,pDealInfo, pBidDealMsg, pContractInfo);
        RAISE_ERR(rc, RTN);

        //消息发送
        rc = SendMessage(pSendMsgList, pBidDealMsg);
        RAISE_ERR(rc, RTN);

        ExecutionReport* pAskDealMsg = new ExecutionReport();
        rc = FmtDealFromDealInfo(ORDR_SIDE_SELL, strCompId ,pDealInfo, pAskDealMsg,pContractInfo);
        RAISE_ERR(rc, RTN);

        rc = SendMessage(pSendMsgList, pAskDealMsg);
        RAISE_ERR(rc, RTN);

    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SendOrdrDealStsUpdtMsgToTrdr(IRS_STRING strCompId, SlotT * pSlotList, int32 slotCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendOrdrDealStsUpdtMsgToTrdr");
    ResCodeT                rc = NO_ERR;
    int32 i = 0;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewDealCnfrmT  pDealCnfrm = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    for (i=0; i<slotCnt; i++ )
    {
        rc = MsgGetSlot(pSlotList[i], &pReqSlot);
        RAISE_ERR(rc, RTN);

        pDealCnfrm = (pNewDealCnfrmT)&pReqSlot->msgBody;

        if (pDealCnfrm->cnfrmType == CNFRM_TYPE_ORDR)
        {
            pOrderCnfrm = (pNewOrderCnfrmT)pDealCnfrm;

            rc = SendOrderStatusUpdateMsgToTrader(strCompId, pOrderCnfrm->rspOrder, pOrderCnfrm->cnfrmCnt, pSendMsgList);
            RAISE_ERR(rc, NORTN);

            PerfStatInc(OrdrCnfrmMsgSend);
        }
        else
        {
            rc = SendDealMsgToTrader(strCompId, pDealCnfrm->rspDeal,pDealCnfrm->cnfrmCnt, pSendMsgList);
            RAISE_ERR(rc, NORTN);

            PerfStatInc(DealCnfrmMsgSend);
        }
        LOG_DEBUG("Free Slot in SendOrdrDealStsUpdtMsgToTrdr Start");
        rc = MsgDelete(pSlotList[i]);
        RAISE_ERR(rc, NORTN);
        LOG_DEBUG("Free Slot in SendOrdrDealStsUpdtMsgToTrdr End");
    }
    LOG_DEBUG("End SendOrdrDealStsUpdtMsgToTrdr");
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CnvtPriceToIntnlVal(IRS_STRING strPrice, int64 * pPrice )
{
    BEGIN_FUNCTION("GetApplRefSeqNum");
    ResCodeT                rc = NO_ERR;
    double      dPrice = 0.0;

    dPrice = atof( strPrice.c_str());

    * pPrice = dPrice * PRICE_BASE;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CnvtPriceToImixVal(int64 iPrice, IRS_STRING& strPrice)
{
    BEGIN_FUNCTION("GetApplRefSeqNum");
    ResCodeT                rc = NO_ERR;
    double      dPrice = 0.0;

    dPrice = (double)iPrice/(double)PRICE_BASE;

    LOG_DEBUG("price [%lf]", dPrice);

    DoubleToString(dPrice, strPrice);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 解析Mass消息
ResCodeT AnalyzeMassMessage(IMIX20::DataSet inMsg, DATASET_HEADER_DATA& headerData, vector<IMIX::BasicMessage>& vectSubMsg)
{
    BEGIN_FUNCTION("AnalyzeMassMessage");
    ResCodeT                rc = NO_ERR;
    int nMassSize;
    int nIndex;
    MassMessageGrp::NoMassMessage* pNoMassMessage;
    IMIX::BasicMessage baseMsg;

    //解析消息类型
    headerData.m_nDataType = inMsg.GetDataType();

    if (E_MASS_TYPE_ACCOUNT_DELETE == headerData.m_nDataType || E_MASS_TYPE_CW_PRICE_MODITY == headerData.m_nDataType)
    {
        RETURN_RESCODE;
    }

    //获取子消息
    MassMessageGrp* pMassMessageGrp = inMsg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        if (nMassSize < 1)
        {
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        }

        for (nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nMassSize + IMIX_GRP_INDEX_BEGIN; ++nIndex)
        {
            pNoMassMessage = pMassMessageGrp->GetNoMassMessage(nIndex);
            if (NULL != pNoMassMessage)
            {

                baseMsg.setString(pNoMassMessage->GetMessageData(), pNoMassMessage->GetMessageLen());
                vectSubMsg.push_back(baseMsg);
            }
            else
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }
        }
    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 获取OCO选择框的状态
OCO_CHECKBOX GetOcoCheckBox(DataSet& message)
{
    OCO_CHECKBOX eCheck = (OCO_CHECKBOX)E_DEFAULT;
    vector<IMIX::BasicMessage> vectMsg;
    DATASET_HEADER_DATA header;
    if (APP_CODE_SUCCESS != AnalyzeMassMessage(message, header, vectMsg))
    {
        //LOG_ERROR(APP_CODE_ANALYZE_IMIXMSG_ERR, APP_MSG_ANALYZE_IMIXMSG_ERR);
        return eCheck;
    }

    bool bFind = false;
    for (int nIndex = 0; nIndex< vectMsg.size(); ++nIndex)
    {
        IMIX::BasicMessage msg = vectMsg[0];
        // 判断CheckBox逻辑
        if (msg.GetHeader()->GetMsgType() == ListCancelRequestMessageID)
        {
            eCheck = E_OCO_CHECKBOX_FALSE;
            bFind = true;
            break;
        }
    }

    if (false == bFind)
    {
        eCheck = E_OCO_CHECKBOX_TRUE;
    }

    return eCheck;
}

ResCodeT SendBilNoteUsrMsgToTrader(IRS_STRING strCompId, BilNoteUsrT* pBilUsr, int32 rspUsrCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("AnalyzeMassMessage");
    ResCodeT                rc = NO_ERR;

    int nSize = rspUsrCnt;
    if (nSize > 0)
    {
        for (int nIndex = 0; nIndex < nSize; ++nIndex)
        {
            pBilUsr = pBilUsr + nIndex;

            IRS_STRING strOrgId = "";
            IntToString(pBilUsr->orgId, strOrgId);

            SecurityDefinitionUpdateReport* pBilStatusMsg =   new SecurityDefinitionUpdateReport();
            pBilStatusMsg->GetHeader()->SetTargetCompID(strCompId);
            pBilStatusMsg->GetHeader()->SetDeliverToSubID(pBilUsr->usrLgnNm);
            pBilStatusMsg->GetHeader()->SetDeliverToCompID(strOrgId);
            pBilStatusMsg->SetSecurityDesc(DESC_USR_NO_BILORD);
            SendMessage(pSendMsgList, pBilStatusMsg);
        }
    }
    else
    {
        //LOG_DEBUG("%s No data to be sent.", sFunction.c_str());
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

void SendCreditUpdReportMsgToTrader(IRS_STRING strCompId, pCreditRiskMsgRespT pMsgResp, SENDMSGLIST* pSendMsgList)
{
    IRS_STRING sFunction = "[SendCreditUpdReportMsgToTrader]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    SendFreezeStatusNotifyMsgToTrader(strCompId, pMsgResp, pSendMsgList);
    LOG_DEBUG("%s End..", sFunction.c_str());
}

//发送授信和风险系数修改通知消息
void SendFreezeStatusNotifyMsgToTrader(IRS_STRING strCompId, pCreditRiskMsgRespT pMsgResp, SENDMSGLIST* pSendMsgList)
{
    IRS_STRING sFunction = "[SendFreezeStatusNotifyMsgToTrader]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    ResCodeT       rc = NO_ERR;
    pOrgInfoT      pOrgInfo = NULL;
    pUsrBaseInfoT  pUsr = NULL;
    uint64         tmpPos;
    IRS_STRING     strOrgId = "";
    IRS_STRING     strUserId  = pMsgResp->strUserId;
    IRS_STRING     strDesc    = pMsgResp->strDesc;
    IRS_STRING     strUpdTime = pMsgResp->strUpdTime;

    rc = OrgInfoGetByIdExt(atoi(pMsgResp->strOrgId), &pOrgInfo);
    if (NOTOK(rc)) {
        return ;
    }

    IntToString(pOrgInfo->orgId, strOrgId);
    tmpPos = pOrgInfo->usrListNode.frstPos;

    while ( TRUE ) {
        rc = IrsUsrInfoGetByPosExt(tmpPos, &pUsr);
        if (NOTOK(rc)) {
            return ;
        }

        if (pUsr->usrOnlnStatus &&
           (pUsr->lgnTp == C_USER_ROLE_FRONT || pUsr->lgnTp == C_USER_ROLE_LIMIT_FRONT)) {
            PartyRiskLimitsUpdateReport* pMsg = new PartyRiskLimitsUpdateReport();

            pMsg->GetHeader()->SetTargetCompID(strCompId);
            pMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);
            pMsg->GetHeader()->SetDeliverToCompID(strOrgId);
            pMsg->SetText(strDesc);
            pMsg->SetTransactTime(strUpdTime);
            SendMessage(pSendMsgList, pMsg);
        }

        if (tmpPos == pOrgInfo->usrListNode.lstPos) {
            break;
        }

        //next node
        tmpPos = pUsr->usrListNode.nxtPos;
    }

    LOG_DEBUG("%s End..", sFunction.c_str());
}

ResCodeT SendFreezeStatusNotifyMsgToTrader(IRS_STRING strCompId, RiskInfoRespT* pRiskRsp , SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendFreezeStatusNotifyMsgToTrader");
    ResCodeT                rc = NO_ERR;
    int64                   timestamp;
    uint64                  tmpPos;
    pUsrBaseInfoT           pUsr = NULL;
    pOrgInfoT               pOrgInfo = NULL;
    IRS_STRING              strOrgId = "";
    IRS_STRING              strDesc = C_RSK_MDFFNSH;
    char                    updTm[MAX_TIME_LENGTH] = {0};

    rc = OrgInfoGetByIdExt(pRiskRsp->intOrgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    IntToString(pOrgInfo->orgId, strOrgId);

    GetSysTimestamp(&timestamp);
    rc = GetStrDateTimeByFormat(timestamp, updTm);
    RAISE_ERR(rc, RTN);

    tmpPos = pOrgInfo->usrListNode.frstPos;

    while ( TRUE )
    {
        rc = IrsUsrInfoGetByPosExt(tmpPos, &pUsr);
        RAISE_ERR(rc, RTN);

        if (pUsr->usrOnlnStatus &&
           (pUsr->lgnTp == C_USER_ROLE_FRONT || pUsr->lgnTp == C_USER_ROLE_LIMIT_FRONT))
        {
            PartyRiskLimitsUpdateReport* pMsg = new PartyRiskLimitsUpdateReport();
            pMsg->GetHeader()->SetTargetCompID(strCompId);
            pMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);
            pMsg->GetHeader()->SetDeliverToCompID(strOrgId);
            pMsg->SetText(strDesc);
            pMsg->SetTransactTime(updTm);
            SendMessage(pSendMsgList, pMsg);
        }

        if (tmpPos == pOrgInfo->usrListNode.lstPos)
        {
            break;
        }

        //next node
        tmpPos = pUsr->usrListNode.nxtPos;
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 发送市场状态给在线用户
ResCodeT SendMktStatusToOnlineUser(IRS_STRING strCompId, pMarketInfoUpdateRespT pMktRsp, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendMktStatusToOnlineUser");
    ResCodeT                rc = NO_ERR;
    BOOL                    bFrstFlg = TRUE;
    UsrOnln                 dbData;
    uint32                  pstnPos = CMN_LIST_NULL_NODE;
    pUsrOnlnBaseInfoT       pUsr = NULL;
    UsrBaseInfoT            user;
    TradingSessionStatus*   pMsg;
    IRS_STRING              strOrgId = "";

    while (TRUE)
    {
        rc = UsrOnlnIterExt(&pstnPos, &pUsr);
        if (NOTOK(rc) && CMN_LIST_NULL_NODE == rc)
        {
            break;
        }
        else
        {
            RAISE_ERR(rc, RTN);
        }
        memset(&user, 0x00, sizeof(UsrBaseInfoT));
        rc = IrsUsrInfoGetByName(pUsr->usrNm, &user);
        RAISE_ERR(rc, RTN);

        pMsg = new TradingSessionStatus();
        IntToString(user.orgId, strOrgId);
        pMsg->GetHeader()->SetTargetCompID(strCompId);
        pMsg->GetHeader()->SetDeliverToCompID(strOrgId);
        pMsg->GetHeader()->SetDeliverToSubID(user.usrLgnNm);
        pMsg->SetTradSesStatus(IrsToImix_MktFlag(pMktRsp->intMktSt));
        pMsg->SetEncodedTextLen(IrsToImix_MktFlag(pMktRsp->intMktStIrs));

        //设置市场状态变化时间
        switch(pMktRsp->intMktSt)
        {
            case E_MKT_ST_START://开市
            {
                pMsg->SetTradSesStartTime(pMktRsp->strUpdTime);
                break;
            }
            case E_MKT_ST_OPEN://开盘
            {
                pMsg->SetTradSesOpenTime(pMktRsp->strUpdTime);
                break;
            }
            case E_MKT_ST_PAUSE://休市
            case E_MKT_ST_CLOSE://收盘
            {
                pMsg->SetTradSesCloseTime(pMktRsp->strUpdTime);
                break;
            }
            case E_MKT_ST_END://闭市
            {
                pMsg->SetTradSesEndTime(pMktRsp->strUpdTime);
                break;
            }
            default:
            break;
        }
        SendMessage(pSendMsgList, pMsg);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

int GetMidString(string &result, string &src, const char* start, const char* end)
{
    int nfind = -1;
    int nend = -1;
    int num = -1;
    num = strlen(start);
    if ((nfind = src.find(start)) == -1)
    {
        return -1;
    }
    if ((nend = src.find(end,nfind)) == -1)
    {
        return -1;
    }
    result = src.substr(nfind + num, nend -nfind-num);
    return 0;
}


void split(const string &src, string &token, vector<string> &vect)
{
    int nend = 0;
    int nbegin=0;
    while(nend != -1)
    {
        nend = src.find(token ,nbegin);
        if (nend == -1)
        {
            vect.push_back(src.substr(nbegin, src.length()-nbegin));
        }
        else if(nend == 1)
        {
            nbegin = nend + token.size();
            continue;
        }
        else
        {
            vect.push_back(src.substr(nbegin, nend-nbegin));
        }
        nbegin = nend + token.size();
    }
}

void GetPriceXMLContent(const string& src, pSetlPrcModifyReqT pSetlPrc)
{
    std::vector<string> vect;
    string token = "</";
    split(src, token, vect);

    string strMid = "";
    GetMidString(strMid, vect[0], "token", "\0");
    string strResult = "";
    GetMidString(strResult, strMid, ">", "\0");
    memcpy(pSetlPrc->strToken,  strResult.c_str(), sizeof(pSetlPrc->strToken));

    strMid = "";
    GetMidString(strMid, vect[1], "<", "\0");
    strResult = "";
    GetMidString(strResult, strMid, ">", "\0");
    memcpy(pSetlPrc->strUserId, strResult.c_str(), sizeof(pSetlPrc->strUserId));

    strMid = "";
    GetMidString(strMid, vect[2], "<", "\0");
    strResult = "";
    GetMidString(strResult, strMid, ">", "\0");
    memcpy(pSetlPrc->strCntrctNm,  strResult.c_str(), sizeof(pSetlPrc->strCntrctNm));

    strMid = "";
    GetMidString(strMid, vect[3], "<", "\0");
    strResult = "";
    GetMidString(strResult, strMid, ">", "\0");
    memcpy(pSetlPrc->strPriceDate, strResult.c_str(), sizeof(pSetlPrc->strPriceDate));

    strMid = "";
    GetMidString(strMid, vect[4], "<", "\0");
    strResult = "";
    GetMidString(strResult, strMid, ">", "\0");
    CnvtPriceToIntnlVal(strResult.c_str(), (int64 *)&pSetlPrc->stlPrice);
}
    
ResCodeT SendOrderClsPosnStatusUpdateMsgToTrader(IRS_STRING strCompId, OrderInfoT* pOrders, int32 orderCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendOrderClsPosnStatusUpdateMsgToTrader");
    ResCodeT                rc = NO_ERR;
    int32                   nSize = orderCnt;
    int32                   nIndex;
    pOrgInfoT               pOrgInfo = NULL;
    uint64                  tmpPos;
    pUsrBaseInfoT           pUsr = NULL;
    pOrderInfoT             pOrderInfo = NULL;

    LOG_DEBUG("In SendOrderClsPosnStatusUpdateMsgToTrader");

    if (nSize > 0)
    {
        //发送订单状态更新消息到交易
        rc = OrgInfoGetByPosExt(pOrders->orgId, &pOrgInfo);
        RAISE_ERR(rc, RTN);

        for (nIndex = 0; nIndex < nSize; ++nIndex)
        {
            pOrderInfo = pOrders + nIndex;
            tmpPos = pOrgInfo->usrListNode.frstPos;
    
            while (TRUE)
            {
                rc = IrsUsrInfoGetByPosExt(tmpPos, &pUsr);
                RAISE_ERR(rc, RTN);
    
                if (pUsr->usrOnlnStatus &&
                   (pUsr->lgnTp == C_USER_ROLE_FRONT || pUsr->lgnTp == C_USER_ROLE_LIMIT_FRONT))
                {
                    ExecutionReport* pOrderStatusMsg =   new ExecutionReport();
                    rc = FmtOrderStatusFromOrderInfo(strCompId, pOrderInfo, pOrderStatusMsg);
                    RAISE_ERR(rc, RTN);
                    pOrderStatusMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);
                    rc = SendMessage(pSendMsgList, pOrderStatusMsg);
                    RAISE_ERR(rc, RTN);
                }
        
                if (tmpPos == pOrgInfo->usrListNode.lstPos)
                {
                    break;
                }

                //next node
                tmpPos = pUsr->usrListNode.nxtPos;
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendDealMsgToOnlnUsrByOrg(int32 iDealSide, IRS_STRING strCompId, pOrgInfoT pOrgInfo,
            DealInfoT* pDealInfo, SENDMSGLIST* pSendMsgList, pCntrctBaseInfoT pContractInfo)
{
    BEGIN_FUNCTION("SendDealMsgToOnlnUsrByOrg");
    ResCodeT                rc = NO_ERR;
    pUsrBaseInfoT           pUsr = NULL;
    uint64                  tmpPos;

    tmpPos = pOrgInfo->usrListNode.frstPos;

    while (TRUE)
    {
        if (pUsr->usrOnlnStatus &&
           (pUsr->lgnTp == C_USER_ROLE_FRONT || pUsr->lgnTp == C_USER_ROLE_LIMIT_FRONT))
        {
            ExecutionReport* pDealMsg =   new ExecutionReport();
            rc = FmtDealFromDealInfo(iDealSide, strCompId ,pDealInfo, pDealMsg, pContractInfo);
            RAISE_ERR(rc, RTN);
            pDealMsg->GetHeader()->SetDeliverToSubID(pUsr->usrLgnNm);
            rc = SendMessage(pSendMsgList, pDealMsg);
            RAISE_ERR(rc, RTN);
        }

        if (tmpPos == pOrgInfo->usrListNode.lstPos)
        {
            break;
        }

        //next node
        tmpPos = pUsr->usrListNode.nxtPos;
    }
        
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendDealClsPosnMsgToTrader(uint32 orgId, IRS_STRING strCompId, DealInfoT* pDeals, int32 rspDealCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendDealClsPosnMsgToTrader");
    ResCodeT                rc = NO_ERR;
    int32                   nIndex;
    DealInfoT*              pDealInfo;
    pCntrctBaseInfoT        pContractInfo = NULL;
    pOrgInfoT               pOrgInfo = NULL;
    pUsrBaseInfoT           pUsr = NULL;

    LOG_DEBUG("In SendDealClsPosnMsgToTrader");

    rc = OrgInfoGetByPosExt(orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);
       
    rc = IrsUsrInfoGetByNameExt((char *)ORDR_SUBMIT_USR_EMG, &pUsr);
    RAISE_ERR(rc, RTN);

    for (nIndex = 0; nIndex < rspDealCnt; ++nIndex)
    {
        pDealInfo = pDeals + nIndex;

        //如果是期差订单则不发送
        rc = IrsCntrctInfoGetByPosExt(pDealInfo->contractPos, &pContractInfo);
        RAISE_ERR(rc, RTN);

        if (IsCombContract(pContractInfo->cntrctName)||IsBasContract(pContractInfo->cntrctName))
        {
            continue;
        }

        if (pUsr->pos == pDealInfo->bidUsrIdx)
        {
            rc = SendDealMsgToOnlnUsrByOrg(ORDR_SIDE_BUY, strCompId, pOrgInfo, 
                    pDealInfo, pSendMsgList, pContractInfo);
            RAISE_ERR(rc, RTN);
        }

        if (pUsr->pos == pDealInfo->askUsrIdx)
        {
            rc = SendDealMsgToOnlnUsrByOrg(ORDR_SIDE_SELL, strCompId, pOrgInfo, 
                    pDealInfo, pSendMsgList, pContractInfo);
            RAISE_ERR(rc, RTN);
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SendClsPosnOrdrDealStsUpdtMsgToTrdr(int64 forceId, uint32 orgIdx,IRS_STRING strCompId, SlotT * pSlotList, int32 slotCnt, SENDMSGLIST* pSendMsgList)
{
    BEGIN_FUNCTION("SendClsPosnOrdrDealStsUpdtMsgToTrdr");
    ResCodeT                rc = NO_ERR;
    int32 i = 0;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewDealCnfrmT  pDealCnfrm = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;

    for (i=0; i<slotCnt; i++ )
    {
        rc = MsgGetSlot(pSlotList[i], &pReqSlot);
        RAISE_ERR(rc, RTN);

        pDealCnfrm = (pNewDealCnfrmT)&pReqSlot->msgBody;

        if (pDealCnfrm->cnfrmType == CNFRM_TYPE_ORDR)
        {
            pOrderCnfrm = (pNewOrderCnfrmT)pDealCnfrm;

            if (forceId != 0)
            {
                rc = SendOrderClsPosnStatusUpdateMsgToTrader(strCompId, pOrderCnfrm->rspOrder, 
                            pOrderCnfrm->cnfrmCnt, pSendMsgList);
                RAISE_ERR(rc, NORTN);
            }
            else
            {
                rc = SendOrderStatusUpdateMsgToTrader(strCompId, pOrderCnfrm->rspOrder, 
                            pOrderCnfrm->cnfrmCnt, pSendMsgList);
                RAISE_ERR(rc, NORTN);
            }

            PerfStatInc(OrdrCnfrmMsgSend);
        }
        else
        {
            rc = SendDealClsPosnMsgToTrader(orgIdx, strCompId, pDealCnfrm->rspDeal,pDealCnfrm->cnfrmCnt, pSendMsgList);
            RAISE_ERR(rc, NORTN);

            PerfStatInc(DealCnfrmMsgSend);
        }
        LOG_DEBUG("Free Slot in SendClsPosnOrdrDealStsUpdtMsgToTrdr Start");
        rc = MsgDelete(pSlotList[i]);
        RAISE_ERR(rc, NORTN);
        LOG_DEBUG("Free Slot in SendClsPosnOrdrDealStsUpdtMsgToTrdr End");
    }
    LOG_DEBUG("End SendClsPosnOrdrDealStsUpdtMsgToTrdr");
    EXIT_BLOCK();
    RETURN_RESCODE;
}
