/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef METASK_CW_H
#define METASK_CW_H

#include "internal_function_def.h"
#include "intrnl_msg.h"

// 清算所实时接口
ResCodeT OnCWStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
//int OnCWStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);


//强平

ResCodeT OnSBFCCP_ClosePositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnSBFCCP_ClosePositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);
/*
int OnSIRSCCP_ClosePositionStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_ClosePositionStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/

//撤销平仓
ResCodeT OnSBFCCP_UndoClosePositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnSBFCCP_UndoClosePositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
int OnSIRSCCP_UndoClosePositionStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_UndoClosePositionStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/

//限仓
ResCodeT OnSBFCCP_LimitPositionStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnSBFCCP_LimitPositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
int OnSIRSCCP_LimitPositionStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_LimitPositionStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//成交撤销
int OnSBFCCP_UndoDealStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_UndoDealStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_UndoDealStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_UndoDealStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/

//机构市场权限设置
ResCodeT OnOrgMktRoleUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnOrgMktRoleUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
//每日结算价修改
int OnSBFCCP_DlySttlmntRtMdfyStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_DlySttlmntRtMdfyStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_DlySttlmntRtMdfyStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_DlySttlmntRtMdfyStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//应急报价
int OnSBFCCP_NewOrderStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_NewOrderStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_NewOrderStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_NewOrderStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//报价撤销
int OnSBFCCP_OrderCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_OrderCancelStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_OrderCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_OrderCancelStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//报价撤销
int OnAdminOrderCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRS_OrderCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);

//合约新增
int OnSBFCCP_ConCtractAddStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_ConCtractAddStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_ConCtractAddStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_ConCtractAddStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);


//合约修改
int OnSBFCCP_ConCtractUpdateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_ConCtractUpdateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_ConCtractUpdateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_ConCtractUpdateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//合约复核
int OnSBFCCP_ConCtractCheckStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_ConCtractCheckStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_ConCtractCheckStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_ConCtractCheckStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//合约删除
int OnSBFCCP_ConCtractRemoveStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_ConCtractRemoveStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_ConCtractRemoveStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_ConCtractRemoveStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//可交割券设置
int OnSBFCCP_DlvryBondInfoUpdateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_DlvryBondInfoUpdateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//合约可交割转换因子
int OnSBFCCP_CntrctCnvrtRateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSBFCCP_CntrctCnvrtRateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

int OnSIRSCCP_CntrctCnvrtRateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSIRSCCP_CntrctCnvrtRateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

*/
//市场应急
ResCodeT OnMarketStateTimeSetStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnMarketStateTimeSetStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
int OnMarketStateChangeStart(const IMIX::BasicMessage &inMessage, MsgList* pParamList);
int OnMarketStateChangeStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/

//API参数设置
ResCodeT OnAPIParamUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnAPIParamUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//API用户冻结、启用
ResCodeT OnAPIUserFreezeStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnAPIUserFreezeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//紧急踢出API用户
ResCodeT OnAPIUserRemoveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnAPIUserRemoveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
//桥机构设置
int OnBrdgPrvlgUpdateStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnBrdgPrvlgUpdateStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/

//桥百分比设置
ResCodeT OnBrdgPercentageUpdateStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnBrdgPercentageUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

ResCodeT OnOrderCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnAdminOrderCancelStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT OnMarketStateChangeStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
#endif
