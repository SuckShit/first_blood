/***
Created on July 11, 2017
@author: Jiawwang.Xie
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "msg_cache.h"
#include "mem_txn.h"
#include "cfg_lib.h"
#include "db_comm.h"
#include "nmbr_srvc.h"
#include "ordr_mgmt.h"
#include "order_book.h"
#include "brdg_ordr_mgmt.h"
#include "dump_ord.h"
#include "matching_engine.h"
#include "active_info.h"
#include "active_keeper.h"
#include "uti_tool.h"
#include "service/risk_update.h"
#include "service/user_login.h"
#include "service/api_login.h"
#include "service/order_submit.h"
#include "service/order_query.h"
#include "service/base_param_update.h"
#include "service/ref_prc_update.h"
#include "service/credit_modify.h"
#include "service/credit_update.h"
#include "service/credit_unlock.h"
#include "service/credit_refresh_method_update.h"
#include "service/org_function.h"
#include "service/market_usr_role.h"
#include "service/market_info_update.h"
#include "service/bridge_update.h"
#include "service/api_param_update.h"
#include "service/api_user_freeze.h"
#include "service/api_user_remove.h"
#include "service/api_subscribe.h"
#include "service/api_unsubscribe_all.h"
#include "service/api_order_submit.h"
#include "service/api_order_cancel.h"
#include "service/api_credit_update.h"
#include "service/api_trade_privil_config.h"
#include "service/api_risk_update.h"
#include "service/setlprc_modify.h"
#include "service/credit_position_sbfccp.h"
#include "mkt_init.h"
#include "trade_mgmt.h"
#include "shm_mgmt.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define TOTAL_OK_MSG_CNT    1026

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static int32    gConnId = DB_INVALID_CONN_ID;

static char     gAppName[] = "app_service_manager";



/******************************************************************************
 **
 ** ServiceCallback
 **
 ******************************************************************************/
ResCodeT ServiceCallback(
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "ServiceCallback" );
    ResCodeT rc = NO_ERR;

    LOG_DEBUG("########## ServiceCallback Start ##########, msgType = %d. ", pReq->msgHdr.msgType);

    // response head & slotNo
    memcpy(&pRsp->msgHdr, &pReq->msgHdr, sizeof(MsgHdrT));
    pRsp->msgHdr.errCode = NO_ERR;

    // each message
    switch (pReq->msgHdr.msgType) {
    case MSG_TYPE_ORDER_SUBMIT_MESSAGE:
        rc = OrderSubmitMessage(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_ORDER_SAVE_MESSAGE:
        rc = OrderSaveMessage(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_BILORDER_SUBMIT_MESSAGE:
        rc = BilOrderSubmitMessage(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_BILORDER_SAVE_MESSAGE:
        rc = BilOrderSaveMessage(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_ORDER_ACTIVATE_MESSAGE:
    case MSG_TYPE_BILORDER_ACTIVATE_MESSAGE:
    case MSG_TYPE_OCOORDER_ACTIVATE_MESSAGE:
        rc = PrcsOrderActvtMsg(pReq->msgHdr.msgType, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_PERIOD_VALIDATE:
        rc = OrderExpireChkMessage(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_OCOORDER_SUBMIT_MESSAGE:
        rc = OcoOrderSubmitMessage(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_OCOORDER_CANCEL_MESSAGE:
    case MSG_TYPE_BILORDER_CANCEL_MESSAGE:
    case MSG_TYPE_ORDER_CANCEL_MESSAGE:
    case MSG_TYPE_ORDER_CANCEL_BY_ADMIN:
        rc = PrcsOrderCnclMsg(pReq->msgHdr.msgType,pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_OCOORDER_SAVE_MESSAGE:
        rc = OcoOrderSaveMessage( pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_ORDER_WITHDRAW_MESSAGE:
    case MSG_TYPE_BILORDER_WITHDRAW_MESSAGE:
    case MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE:
        rc = PrcsOrderWthdrMsg(pReq->msgHdr.msgType, pReq, pRsp, timestamp, pCtx);
        break;

    case MSG_TYPE_ORDER_FREEZE_MESSAGE:
    case MSG_TYPE_BILORDER_FREEZE_MESSAGE:
    case MSG_TYPE_OCOORDER_FREEZE_MESSAGE:
        rc = PrcsOrderFrzMsg(pReq->msgHdr.msgType, pReq, pRsp, timestamp, pCtx);
        break;

    case MSG_TYPE_MKT_DAT_PUSH:
        rc = PrcsMktDatPush(pReq, pRsp, timestamp, pCtx);
        break;

    case MSG_TYPE_BRDG_ORDR_TRGR:
        rc = PrcsBrdgOrdrTrgr(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_DEAL_CNCL_MESSAGE:
        rc = PrcsDealCnclReq(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_ORDR_QUERY:
        rc = OrderQuery(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_API_RISK_UPDATE:
        rc = ApiRiskUpdate(gConnId, pReq, pRsp, timestamp, pCtx);
        break;

    /*** user ***/
    case MSG_TYPE_USER_LOGIN:
        rc = UserLogin(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_USER_LOGOUT:
        rc = UserLogout(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_REMOVE_ONLINE_USER:
        rc = RemoveOnlineUser(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_LOGIN:
        rc = ApiLogin(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_LOGOUT:
        rc = ApiLogout(gConnId, pReq, pRsp, timestamp);
        break;

    /*** api ***/
    case MSG_TYPE_API_PARAM_UPDATE:
        rc = ApiParamUpdate(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_USER_FREEZE:
        rc = ApiUserFreeze(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_USER_REMOVE:
        rc = ApiUserRemove(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_SUBSCRIBE:
        rc = ApiSubscribe(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_UNSUBSCRIBE_ALL:
        rc = ApiUnSubscribeAll(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_API_ORD_SUBMIT:
        rc = ApiOrderSubmit(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_API_ORD_CANCEL:
        rc = ApiOrderCancel(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SIRS_API_ORD_SUBMIT:
        rc = SirsApiOrderSubmit(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SIRS_API_ORD_CANCEL:
        rc = SirsApiOrderCancel(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SBFCCP_API_ORD_SUBMIT:
        rc = SbfccpApiOrderSubmit(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SBFCCP_API_ORD_CANCEL:
        rc = SbfccpApiOrderCancel(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_API_TRADER_PRIVIL_CONFIG:
        rc = ApiTradePrivilConfig(gConnId, pReq, pRsp, timestamp, pCtx);
        break;

    case MSG_TYPE_API_CREDIT_UPDATE:
        rc = ApiCreditUpdate(gConnId, pReq, pRsp, timestamp, pCtx);
        break;

    case MSG_TYPE_BASE_PARAM_UPDATE:
        rc = BaseParamUpdate(gConnId, pReq, pRsp);
        break;
    //��������/���
    case MSG_TYPE_ORG_BANK_FREEZE:
        rc = OrgBankFreezeMessage(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    //����Ȩ���г�����
    case MSG_TYPE_ORG_MARKET_ROLE_UPDATE:
        rc = OrgMarkerRoleUpadateMessage(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    //�û��г�Ȩ������
    case MSG_TYPE_USR_MARKET_ROLE_UPDATE:
        rc = UsrMarkerRoleUpadateMessage(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_TIMER_CAL_REF_PRC:
        rc = PrcsCalcRefPrcByTrgr(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_CREDIT_MODIFY:
        rc = CreditModify(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_CREDIT_UPDATE:
        rc = CreditUpdate(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_CREDIT_UNLOCK:
        rc = CreditUnlock(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE:
        rc = CreditRefreshMethodUpdate(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_MARKET_INFO_UPDATE:
        rc = MarketInfoUpdate(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_BRIDGE_DEALER_UPDATE:
        rc = BridgeDealerUpdate(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_BRIDGE_CREDIT_MODIFY:
        rc = BridgeCreditModify(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_BRIDGE_CREDIT_UPDATE:
        rc = BridgeCreditUpdate(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_MARKET_CONFIG_MODIFY_CW:
        rc = MarketStateTimeUpdate(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_BRIDGE_PERCENTAGE_UPDATE:
        rc = BridgePercentageUpdate(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_RISK_UPDATE:
        rc = RiskInfoUpdate(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SETL_PRC_MODIFY:
        rc = SetmentPriceModify(gConnId, pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SBFCCP_CREDIT_LIMIT_CW:
        rc = SbfCcpCrdtLimitByCw(gConnId, pReq, pRsp, timestamp);
        break;
    case MSG_TYPE_SBFCCP_ORDER_CANCEL_CW:
        rc = SbfCcpOrdrCancelByCw(pReq, pRsp, timestamp, pCtx);
        break;
    case MSG_TYPE_SBFCCP_ORDER_SUBMIT_CW:
        rc = SbfCcpOrdrSubmitByCw(pReq, pRsp, timestamp, pCtx);
        break;
	case MSG_TYPE_SBFCCP_ORDER_SUBMIT_QSS:
		rc = SbfCcpOrdrSubmitByQss(pReq, pRsp, timestamp, pCtx);
        break;
	case MSG_TYPE_SBFCCP_ORDER_CANCEL_QSS:
		rc = SbfCcpOrdrCancelByQss(pReq, pRsp, timestamp, pCtx);
        break;
    default:
        RAISE_ERR(ERR_MSG_NOT_SUPPORT_TYPE, RTN);
        break;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    pCtx->sendFlg = 1;

    rc = GET_RESCODE();
    if (NOTOK(rc)) {
        pRsp->msgHdr.errCode = rc;
        SET_RESCODE(NO_ERR);
    }

    LOG_DEBUG("########## ServiceCallback Stop ##########, msgType = %d. rc %ld ", pReq->msgHdr.msgType, rc);

    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ServiceDoneCallback
 **
 ******************************************************************************/
ResCodeT ServiceDoneCallback()
{
    BEGIN_FUNCTION( "ServiceDoneCallback" );
    ResCodeT rc = NO_ERR;
    int32   set = -1;

    static vectorT *       pSetVct = NULL;

    if (!pSetVct)
    {
        rc = GetAllSetIdsPtr(&pSetVct);
        RAISE_ERR(rc, RTN);
    }
    LOG_DEBUG("########## ServiceDoneCallback in ##########");
    while (1)
    {
        /*�ҵ���ǰ����������set*/
        BitFindFS(pSetVct, set + 1, MAX_SET_CNT, &set);
        if (set == -1)
        {
            break;
        }

        rc = MtchrPrcsFlushMktDat(set);
        RAISE_ERR(rc, RTN);
    }



    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ServiceManagerInit
 **
 ******************************************************************************/
ResCodeT ServiceManagerInit(void * pConfig)
{
    BEGIN_FUNCTION( "ServiceManagerInit" );
    ResCodeT rc = NO_ERR;
    vectorT *       pSetVct;
    int32           set = 0;


    LOG_DEBUG("########## ServiceManagerInit Begin ##########");

    OrdrBkCfgT  ordrBkCfg = {0};
    struct cfgValueS cfgValue = {0};

    MemTxnCfgT memTxnCfg[1];
    ShlCfgInfoT     shlCfgInfo = {0};


    rc = MktInit();
    RAISE_ERR(rc, RTN);


    /* Get config value for the system  */
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);

    /* Initialize Database Section  */
    rc = DbCmmnInit();
    RAISE_ERR(rc, RTN);

    rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &gConnId);
    RAISE_ERR(rc, RTN);


    rc = AppShmMgmtCreate();
    RAISE_ERR(rc, RTN);

    memTxnCfg[0].setId = cfgValue.setId;
    memTxnCfg[0].nmbrOfTxn = cfgValue.nmbrOfTxn;
    memTxnCfg[0].dataSize = cfgValue.dataSize;

    rc = MemTxnShmCreateForAllSet(memTxnCfg, 1);
    RAISE_ERR(rc, RTN);

    EngThreadConfigT*   gpEngConfig;
    gpEngConfig = (EngThreadConfigT*)pConfig;

    shlCfgInfo.inQHndl[SHL_Q_TYPE_EVENT] = gpEngConfig->eventMsgHdl;
    shlCfgInfo.inQHndl[SHL_Q_TYPE_DFLT] = gpEngConfig->rdMsgHdl;
    shlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT] = gpEngConfig->wrMsgHdl;
    shlCfgInfo.txnSize = cfgValue.shlTxn;
    shlCfgInfo.bDbSupport = cfgValue.needDbSupport;

    rc = AppShlInit(cfgValue.setId, gAppName, &shlCfgInfo, ServiceCallback, ServiceDoneCallback);
    RAISE_ERR(rc, RTN);

    rc = SendMsgToGateway(cfgValue.setId);
    RAISE_ERR(rc, NORTN);

    rc = DumpOrdInit( cfgValue.setId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ServiceManagerWait
 **
 ******************************************************************************/
ResCodeT ServiceManagerWait()
{
    BEGIN_FUNCTION("ServiceManagerWait");
    ResCodeT rc = NO_ERR;

    LOG_DEBUG("########## ServiceManagerWait Begin ##########");

    rc = AppShlRun();
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** ServiceManagerStop
 **
 ******************************************************************************/
ResCodeT ServiceManagerStop()
{
    BEGIN_FUNCTION("ServiceManagerStop");
    ResCodeT rc = NO_ERR;

    LOG_DEBUG("########## ServiceManagerStop Begin ##########");

    rc = AppShlStop();
    RAISE_ERR(rc, RTN);

    rc = DbCmmnDisconnect(gConnId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnCleanup();
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
