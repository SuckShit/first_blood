/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"

#include "METask_Comm.h"
#include "METask_Login.h"
#include "METask_Order.h"
#include "METask_Officer.h"
#include "METask_Layer2.h"
#include "METask_BilCombOrder.h"
#include "user_order.h"
#include "order_book.h"
#include "contract_info.h"
#include "usr.h"
#include "user_order.h"
#include "org_info.h"
#include "uti_tool.h"
#include "irs_code_convert.h"
#include "MessageAnalyst.h"
using namespace IMIX;
using namespace IMIX20;

// �����ύ
ResCodeT OnBilCombOrderSubmitStart(int32 msgType, IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnCombOrderSubmitStart");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleReqT* pOrderMsg;
    IRS_STRING strUserId;
    char securityId[30];
    pUsrBaseInfoT pUsr = NULL;
    pOrgInfoT pOrgInfo = NULL;
    pCntrctBaseInfoT pCntract = NULL;

    // ��Ϣ����
    NewOrderMultileg message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    LOG_INFO("%s: Req message string: %s", "OnCombOrderSubmitStart", message.ToString().c_str());
    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    MessageAnalyst_NewOrderMultileg analyst;
    AnalystRet_NewOrderMultileg analyzeRet;
    
    if (APP_CODE_SUCCESS != analyst.AnalyzeMessage(static_cast<IMIX::BasicMessage*>(&message), &analyzeRet))
    {
        LOG_ERROR(APP_CODE_ANALYZE_IMIXMSG_ERR, APP_MSG_ANALYZE_IMIXMSG_ERR);
        return APP_CODE_ANALYZE_IMIXMSG_ERR;
    }

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    pReq->msgHdr.setId = SET_MKT_IRS;

    pOrderMsg = (NewOrderSingleReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(NewOrderSingleReqT);
    pReq->msgHdr.msgType = msgType;

    //��ȡ��������ͽ���Ա

    rc = IrsUsrInfoGetByNameExt((char*)analyzeRet.GetUserId().c_str(),  &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->newOrdrInfo.userIdx   = pUsr->pos;

    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(pUsr->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.orgIdx = pOrgInfo->pos;

    strcpy(pOrderMsg->token, analyzeRet.GetToken().c_str()  );

    strcpy(securityId, analyzeRet.GetSecurityId().c_str() );
    rc = IrsCntrctInfoGetByNameExt(&securityId[0], &pCntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->newOrdrInfo.contractPos = pCntract->pos;

    //��������
    rc = SideConvert(analyzeRet.GetSide(), &pOrderMsg->newOrdrInfo.side);
    RAISE_ERR(rc, RTN);

    CnvtPriceToIntnlVal(analyzeRet.GetPrice(), &pOrderMsg->newOrdrInfo.prcQtyInfo.price);
    pOrderMsg->newOrdrInfo.prcQtyInfo.qty = StringToInt64( analyzeRet.GetOrderQty());

    CnvtPriceToIntnlVal(analyzeRet.GetPrice2(), &pOrderMsg->askPrcQtyInfo.price);
    pOrderMsg->askPrcQtyInfo.qty = StringToInt64( analyzeRet.GetOrderQty2() );


    DateTimeToTimestamp((char *)analyzeRet.GetEffectTime().c_str(), &pOrderMsg->newOrdrInfo.effectTime);

    pOrderMsg->newOrdrInfo.ordType = ImixToIrs_OrdType(analyzeRet.GetOrdType());
    pOrderMsg->newOrdrInfo.extOrdType = EXT_ORD_TYPE_BIL;

    rc = ExecInstConvert(analyzeRet.GetExecInst(), &pOrderMsg->newOrdrInfo.execInst);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.ordAction = ORDR_ACT_NEW;

    //reserve message header
    rc = ResrveReqMsg(&inMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.apiLoginUsrIdx = -1;
    pOrderMsg->newOrdrInfo.apiRqstId = 0;
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}


// ��������
ResCodeT OnBilCombOrderCnclRplcStart(int32 msgType, IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBilCombOrderCnclRplcStart");
    ResCodeT                rc = NO_ERR;
    OrderCancelReplaceRequestReqT* pOrderMsg;
    IRS_STRING strUserId;
    UsrBaseInfoT * user;

    // ��Ϣ����
    MultilegOrderCancelReplace message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    LOG_INFO("OnBilCombOrderCnclRplcStart: Req message string: %s", message.ToString().c_str());
    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    MessageAnalyst_MultilegOrderCancelReplace analyst;
    AnalystRet_MultilegOrderCancelReplace analyzeRet;

    if (APP_CODE_SUCCESS != analyst.AnalyzeMessage(static_cast<IMIX::BasicMessage*>(&message), &analyzeRet))
    {
        LOG_ERROR(APP_CODE_ANALYZE_IMIXMSG_ERR, APP_MSG_ANALYZE_IMIXMSG_ERR);
        return APP_CODE_ANALYZE_IMIXMSG_ERR;
    }

    pReq->msgHdr.setId = SET_MKT_IRS;

    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = msgType;

    rc = IrsUsrInfoGetByNameExt((char*)analyzeRet.GetUserId().c_str(),  &user);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx   = user->pos;

    strcpy(pOrderMsg->token, analyzeRet.GetToken().c_str()  );
    pOrderMsg->ordId = PrefixStringToInt64(analyzeRet.GetOrdId(),3  );

//    ExecInstConvert(message.GetExecInst(), &pOrderMsg->execInst);
//    RAISE_ERR(rc, RTN);

    //reserve message header
    rc = ResrveReqMsg(&inMessage, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

