/***
Created on Aug 02, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _METASK_API_H_
#define _METASK_API_H_

#include "internal_function_def.h"
#include "intrnl_msg.h"

#include "XAPIPbMessage.pb.h"
using namespace xapi;

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
//接口总入口
ResCodeT OnAPIInterfaceStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);

//ResCodeT OnAPIInterfaceStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

ResCodeT AnalyzeCreditUpdateMessage(IMIX20::QueryResult inMsg, vector<xapi::CreditLimitUpdateRequest>& vectSubMsg);
//ResCodeT AnalyzeRiskUpdateMessage(IMIX20::QueryResult inMsg, vector<xapi::RiskLimitUpdateRequest>& vectSubMsg);
ResCodeT AnalyzeRiskUpdateMessage(IMIX20::QueryResult inMsg, vector<xapi::RiskLimitUpdateRequest>& vectSubMsg);
// 授信修改&授信解锁
ResCodeT OnApiCreditUpdateStart(const xapi::CreditLimitUpdateRequest& inMessage, IntrnlMsgT* pReq);
ResCodeT OnApiCreditUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

// 风险修改
int OnApiRiskUpdateStart(const xapi::RiskLimitUpdateRequest& inMessage,IntrnlMsgT* pReq);
int OnApiRiskUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*****************************************************************************
 **
 ** The following API interfaces are added by xiejiawang.
 **
 *****************************************************************************/

// Api用户登录
ResCodeT OnApiLoginStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnApiLoginStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

// Api用户登出
ResCodeT OnApiLogoutStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnApiLogoutStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//API订阅
ResCodeT OnApiSubscribeStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnApiSubscribeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//API取消所有订阅
ResCodeT OnApiUnSubscribeAllStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnApiUnSubscribeAllStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//API订单成交总入口
ResCodeT OnApiOrdSubmitProcessStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
//ResCodeT OnApiOrdSubmitProcessStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//IRSAPI订单撤销总入口
ResCodeT OnApiOrdCancelProcessStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
//ResCodeT OnApiOrdCancelProcessStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//IRSAPI订单成交
ResCodeT OnApiOrdSubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, int32 funcId);
ResCodeT OnApiOrdSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

//IRSAPI订单撤销
ResCodeT OnApiOrdCancelStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, int32 funcId);
ResCodeT OnApiOrdCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);

/*
//SIRSAPI订单成交
int OnSirsApiOrdSubmitStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSirsApiOrdSubmitStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//SIRSAPI订单撤销
int OnSirsApiOrdCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSirsApiOrdCancelStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//SBFCCPAPI订单成交
int OnSbfccpApiOrdSubmitStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSbfccpApiOrdSubmitStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);

//SBFCCPAPI订单撤销
int OnSbfccpApiOrdCancelStart(const IMIX::BasicMessage& inMessage,MsgList* pParamList);
int OnSbfccpApiOrdCancelStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
*/


#endif /* _METASK_API_H_ */
