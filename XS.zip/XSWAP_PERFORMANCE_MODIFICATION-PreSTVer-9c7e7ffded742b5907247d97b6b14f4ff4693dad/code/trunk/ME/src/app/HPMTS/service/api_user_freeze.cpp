/***
Created on Sep 6, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "user_login.h"
#include "usr_def_ref.h"
#include "match_lib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/





/******************************************************************************
 **
 ** Detail Service Callback : ApiUserFreeze
 **
 ******************************************************************************/
ResCodeT ApiUserFreeze(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiUserFreeze" );
    ResCodeT rc = NO_ERR;

    ApiUserFreezeReqT*      pApiReq;
    ApiUserFreezeRespT*     pApiResp;

    pApiReq = (ApiUserFreezeReqT*)&pReq->msgBody[0];

    pRsp->msgHdr.msgLen = sizeof(ApiUserFreezeRespT);
    pApiResp = (ApiUserFreezeRespT*)&pRsp->msgBody[0];

    memset(pApiResp, 0, sizeof(ApiUserFreezeRespT));


    // common check
    int32 iOrgId;
    rc = CommonChk(pApiReq->strUserId, C_ORG_NULL, pApiReq->iFuncId, pApiReq->strToken, &iOrgId);
    RAISE_ERR(rc, RTN);


    // �ж�API�û��Ƿ����
    pUsrBaseInfoT pUserInfo;
    pOrgInfoT pOrgInfo;

    rc = IrsUsrInfoGetByNameExt(pApiReq->strOpApiUserId, &pUserInfo);
    if (rc != NO_ERR)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }
    int iApiF;
    iApiF = atoi(pUserInfo->apiF);
    if (iApiF != C_API_USRFLAG)
    {
        RAISE_ERR(APIERR_CODE_INVLD_OTHERS, RTN);
    }

    rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);


    // ��ȡ�û����ͣ�ÿ��API�û�����Ӧһ��Ȩ��
    rc = CheckApiUserRole(pUserInfo->roleId, pApiResp->iUserRole);
    RAISE_ERR(rc, RTN);


    // get current time
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);

    UsrLgnHstry sHistory;
    memset(&sHistory, 0, sizeof(UsrLgnHstry));
    strcpy(sHistory.oprtTm, strTimestamp);

    int32 usrSt;
    usrSt = atoi(pUserInfo->usrSt);
    if (pApiReq->iRequestType == C_REQUEST_FORBID)
    {
        if (usrSt == C_USR_ST_ACTIVE)
        {
            // update
//            rc = UpdateUsrDb(connId, pApiReq->strOpApiUserId, pApiReq->strUserId, C_USR_ST_LOCK, strTimestamp);
//            RAISE_ERR(rc, RTN);

            int iCnt;
            // get the user online count
            rc = GetCntByUsrNm(connId, pApiReq->strOpApiUserId, &iCnt);
            RAISE_ERR(rc, RTN);
            if (iCnt >= 1)
            {
                // get the token
                strcpy(pApiResp->strToken, pUserInfo->sesnId);

                // delete the old user
//                rc = DeleteUserOnline(connId, pApiReq->strOpApiUserId);
//                RAISE_ERR(rc, RTN);

                // insert to the USR_LGN_HSTRY
                strcpy(sHistory.usrNm, pApiReq->strOpApiUserId);
                itoa(C_OPTION_TP_OUT, sHistory.oprtTp, 10);
                strcpy(sHistory.lgnIp, " ");
//                strcpy(sHistory.oprtTm, strTimestamp);
//                rc = InsertUserLoginHistory(connId, &sHistory);
//                RAISE_ERR(rc, RTN);
            }

            if (pApiResp->iUserRole == C_APIUSER_ROLE_DEAL)
            {
                // cancel order

                // SP_IRSAPI_ORDCANCELBYAPIUSR
                NewOrderSingleRspT  sApiResp;
                rc = MtchrPrcsOrdrCnclByUser(pReq->msgHdr.setId, timestamp, pUserInfo->pos, pOrgInfo->pos, &sApiResp);
                RAISE_ERR(rc, RTN);

                // SP_SIRSAPI_ORDCANCELBYAPIUSR
                // SP_SBFCCPAPI_ORDCANCELBYUSR
                // SP_CLEARBRDGORDBYORDST
            }
/*
            else if (pApiResp->iUserRole == C_APIUSER_ROLE_QUOT)
            {
                // �������鶩��
                QtSbscrptnApi key;
                strcpy(key.usrLgnNm, pApiReq->strOpApiUserId);
                rc = DeleteQtSbscrptnApi(connId, &key);
            }

            itoa(C_USR_ST_LOCK, pUserInfo->usrSt, 10);
            pUserInfo->usrOnlnStatus = FALSE;
*/
            // for user login ref
            rc = SerializeUsrRefData(connId, MSG_TYPE_API_USER_FREEZE, NULL, &sHistory, pApiReq->strUserId, 0);
            RAISE_ERR(rc, RTN);
        }
    }
    else if (pApiReq->iRequestType == C_REQUEST_ACTIVE)
    {
        if (usrSt == C_USR_ST_LOCK)
        {
/*
            // update
            rc = UpdateUsrDb(connId, pApiReq->strOpApiUserId, pApiReq->strUserId, C_USR_ST_ACTIVE, strTimestamp);
            RAISE_ERR(rc, RTN);

            itoa(C_USR_ST_ACTIVE, pUserInfo->usrSt, 10);
*/
            // for user login ref
            rc = SerializeUsrRefData(connId, MSG_TYPE_API_USER_FREEZE, NULL, &sHistory, pApiReq->strUserId, 0);
            RAISE_ERR(rc, RTN);
        }
    }


    // get the OUT_ORGCD
    pOrgInfoT pOrgData;
    rc = OrgInfoGetByIdExt(pUserInfo->orgId, &pOrgData);
    strcpy(pApiResp->strOrgCd, pOrgData->orgCd);


    rc = GetBoundId(connId, &pApiResp->iMaxOutboundId);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
