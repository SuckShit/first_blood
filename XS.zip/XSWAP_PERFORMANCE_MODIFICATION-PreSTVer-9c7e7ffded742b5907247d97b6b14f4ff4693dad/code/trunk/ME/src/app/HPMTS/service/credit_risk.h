/***
Created on August 14, 2017
@author: liugao
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _CREDIT_RISK_H_
#define _CREDIT_RISK_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */

/* Project Header files */
#include "app_shl.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct CreditRiskUpdateReqS
{
    int32   iFuncId;
    char    iUserId[32];
    char    iToken[16];
    int32     iOrgid;
    char    iCntrctNm[50];
    float   iRikCfCnt;
} CreditRiskUpdateReqT, *pCreditRiskUpdateReqT;

typedef struct RiskCoefInfoS
{
    int32 m_nOrgId;
    char m_sUserId[32];
    char m_sDesc[32];
    char m_sUpdTime[32];

}RiskCoefInfoT, *pRiskCoefInfoT;


typedef struct CreditRiskUpdateRspS
{
    int32  CreditRiskUpdCnt;
    RiskCoefInfoT  rspRiskUpdate[50];
} CreditRiskUpdateRspT, *pCreditRiskUpdateRspT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CreditRiskUpdate(
            int32           connId,
            int64           timestamp,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp);

#endif /* _CREDIT_RISK_H_ */

