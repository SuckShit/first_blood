/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "matching_response.h"
#include "matching_listener.h"
#include "intrnl_msg.h"
#include "data_type.h"
#include "msg_cache.h"
#include "err_lib.h"
#include "err_cod.h"
#include <sys/epoll.h>             /* define wait handling functions     */
#include <errno.h>
#include <pthread.h>
#include "IMIXT10/Message/Logon.h"
#include "IMIXT10/Comm/MessageType.h"
#include "DEP/DEPAPIErrorDef.h"

#include "METask.h"
#include "UTILITY/Mutex.h"

#include "monitor_thread.h"
#include "uti_tool.h"
#include "perf_stat.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define WAIT_FD_CNT                 1
#define GET_RESPONSE_TIME_OUT       10  /* time out time, default 10 ms */

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static struct epoll_event gWaitEvent;
static int32 gWaitFd;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT SendRspMsg(ServiceList* pm_ServiceList, CMUTEX* pm_ClientMutex, SENDMSGLIST** pMsgList)
{
    BEGIN_FUNCTION("SendRspMsg");
    ResCodeT rc = NO_ERR;

    int32 CountSendMsg;
    DEP::Service * ptempService;
    SENDMSGLIST::iterator MsgIter;
    DEP::ServiceID m_ServiceID;
    ServiceList::iterator m_ServiceIter;

    if (*pMsgList != NULL)
    {
        LOG_DEBUG("SendMessage list size: %d", (*pMsgList)->size());
        for (MsgIter = (*pMsgList)->begin(); MsgIter != (*pMsgList)->end(); MsgIter++)
        {
            AutoLock locker( pm_ClientMutex );
            CountSendMsg=0;

            //ConnSession* pSession1 = NULL;
            for (m_ServiceIter = pm_ServiceList->begin(); m_ServiceIter != pm_ServiceList->end(); m_ServiceIter++)
            {

                //pSession1 = *iter;
                if ((*m_ServiceIter) != NULL)
                {
                    m_ServiceID = (**m_ServiceIter).GetServiceID();
                    //if(strcmp(pSession1->m_targetGroupName.c_str(),(((*MsgIter)->GetHeader())->GetTargetCompID()).c_str())==0)
                    //直连的情况处理，比如和 tdps以及rdp的连接，所有的消息回复都通过广播的方式
                    if (m_ServiceID.getTargetCompID()==((*MsgIter)->GetHeader())->GetTargetCompID())
                    {
                        //发给TDPS,2个域在so里留空的
                        if ((*MsgIter)->GetHeader()->GetDeliverToCompID()=="" && (*MsgIter)->GetHeader()->GetDeliverToSubID()=="")
                        {
                            (*MsgIter)->GetHeader()->SetSenderSubID(m_ServiceID.getSenderSubID());
                            (*MsgIter)->GetHeader()->SetSenderCompID(m_ServiceID.getSenderCompID());
                            (*MsgIter)->GetHeader()->SetTargetSubID(m_ServiceID.getTargetSubID());
                            (*MsgIter)->GetHeader()->SetOnBehalfOfSubID(m_ServiceID.getOnBehalfOfSubID());
                            (*MsgIter)->GetHeader()->SetOnBehalfOfCompID(m_ServiceID.getOnBehalfOfCompID());
                            (*MsgIter)->GetHeader()->SetDeliverToSubID(m_ServiceID.getDeliverToSubID());
                            (*MsgIter)->GetHeader()->SetDeliverToCompID(m_ServiceID.getDeliverToCompID());
                            CountSendMsg++;
                            ptempService = const_cast<DEP::Service *>(*m_ServiceIter);
                            (ptempService)->Send((*(*MsgIter)));
                            
                            //PerfStatInc(RspMsgSend);
                            
                        }
                        else if ((*MsgIter)->GetHeader()->GetDeliverToCompID()!="" && (*MsgIter)->GetHeader()->GetDeliverToSubID()!="")
                        {
                            //发给rdp,对手方的地址通过sp获取，客户端的地址通过session msg获取,在so里填充与commserver直接连接的情况，TargetCompID由so设置，
                            (*MsgIter)->GetHeader()->SetSenderSubID(m_ServiceID.getSenderSubID());
                            (*MsgIter)->GetHeader()->SetSenderCompID(m_ServiceID.getSenderCompID());
                            (*MsgIter)->GetHeader()->SetTargetSubID(m_ServiceID.getTargetSubID());
                            (*MsgIter)->GetHeader()->SetOnBehalfOfSubID(m_ServiceID.getOnBehalfOfSubID());
                            (*MsgIter)->GetHeader()->SetOnBehalfOfCompID(m_ServiceID.getOnBehalfOfCompID());
                            CountSendMsg++;
                            ptempService = const_cast<DEP::Service *>(*m_ServiceIter);
                            (ptempService)->Send((*(*MsgIter)));
                            
                            PerfStatInc(RspMsgOut);
                        }
                    }
                }
            }

            if (*MsgIter != NULL)
            {
                (*MsgIter)->Clear();
                delete  *MsgIter;
                *MsgIter=NULL;
            }
        }

        if (*pMsgList != NULL)
        {
            delete *pMsgList;
            *pMsgList=NULL;

        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT InitEpoll(RspThreadConfigT* pRspConfig)
{
    BEGIN_FUNCTION("initEpoll");
    ResCodeT rc = NO_ERR;

    int32 msgHdl;
    int32 waitFd;
    int32 queueFd;

    msgHdl = pRspConfig->msgHdl;

    gWaitFd = epoll_create(WAIT_FD_CNT);
    if (gWaitFd < 0)
    {
        RAISE_ERR( ERR_OPEN_ERR_LOG_ERR, RTN );
    }

    rc = MsgQueueGetFd(msgHdl, &queueFd);
    RAISE_ERR( rc, RTN );

    gWaitEvent.events = EPOLLIN| EPOLLRDHUP|EPOLLERR|EPOLLHUP;
    gWaitEvent.data.fd = queueFd;
    gWaitEvent.data.ptr = (void *)&pRspConfig->msgHdl;

    if (epoll_ctl(gWaitFd,EPOLL_CTL_ADD, queueFd, &gWaitEvent))
    {
        RAISE_ERR( ERR_APP_EPOLL_ADD_ERR, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

void dmy_func()
{
    return;
}

ResCodeT SendReceiveRsp(ServiceList* pServiceList, CMUTEX*  pm_ClientMutex, METask*  pm_METask, int32* pRunFlg)
{
    BEGIN_FUNCTION( "SendReceiveRsp" );
    ResCodeT                rc = NO_ERR;

    int32 i;
    int32 queueCnt;
    int32 msgHdl;
    SlotT slot;
    pMsgCacheSlotT pRespSlot;
    IntrnlMsgT intrnlMsg;

    SENDMSGLIST* pOutImixMsg;
    pMsgDataT pMsg;
    while (*pRunFlg == RESPONSE_RUN_FLUG_RUN)
    {
        queueCnt = epoll_wait(gWaitFd, &gWaitEvent, WAIT_FD_CNT, GET_RESPONSE_TIME_OUT);

        if (queueCnt < 0 && errno != EINTR)
        {
            RAISE_ERR( ERR_APP_EPOLL_ADD_ERR, RTN );
        }
        else if (queueCnt < 0 && errno == EINTR)
        {
            continue;
        }
        else if (queueCnt == 0)
        {

            msgHdl = *((int32 *)gWaitEvent.data.ptr);

            rc = MsgQueueReadSlot(msgHdl, &slot);
            if (rc == ERCD_ARCH_READ_TRY_AGAIN)
            {
                continue;
            }
            else
            {
                RAISE_ERR( rc, RTN );
            }
            
            LOG_DEBUG("time out got response slot %d", slot);
            
            pOutImixMsg = new SENDMSGLIST;

            // get reponse slot
            pMsgCacheSlotT pRspMsgSlot = NULL;
            rc = MsgGetSlotRsp(slot, &pRespSlot);
            RAISE_ERR( rc, RTN );

            rc = MsgGetMsg(pRespSlot->slotId, &pMsg);
            RAISE_ERR( rc, RTN );

            pm_METask->OnMEStopPlus((IntrnlMsgT*)pMsg, pOutImixMsg);
            RAISE_ERR( rc, RTN );

            rc = SendRspMsg(pServiceList, pm_ClientMutex, &pOutImixMsg);
            RAISE_ERR( rc, RTN );
            
            LOG_DEBUG("Free Slot in SendReceiveRsp time out");
            
            rc = MsgDelete(slot);
            RAISE_ERR( rc, RTN );
            
            MonThreadUpt(MON_THREAD_RESP_TYP);
        }
        else
        {

            LOG_DEBUG("activated reponse queueCnt = %d", queueCnt);

            msgHdl = *((int32 *)gWaitEvent.data.ptr);

            rc = MsgQueueReadSlot(msgHdl, &slot);
            if (rc == ERCD_ARCH_READ_TRY_AGAIN)
            {
                continue;
            }
            else
            {
                RAISE_ERR( rc, RTN );
            }
            
            LOG_DEBUG("Req slot %d", slot);
            
            pOutImixMsg = new SENDMSGLIST;

            // get reponse slot
            pMsgCacheSlotT pRspMsgSlot = NULL;
            rc = MsgGetSlotRsp(slot, &pRespSlot);
            RAISE_ERR( rc, RTN );

            
            LOG_DEBUG("Resp slot %d", pRespSlot->slotId);
            
            rc = MsgGetMsg(pRespSlot->slotId, &pMsg);
            RAISE_ERR( rc, RTN );

            pm_METask->OnMEStopPlus((IntrnlMsgT*)pMsg, pOutImixMsg);
            RAISE_ERR( rc, RTN );

            rc = SendRspMsg(pServiceList, pm_ClientMutex, &pOutImixMsg);
            RAISE_ERR( rc, RTN );
            
            LOG_DEBUG("Free Slot in SendReceiveRsp activated");
            
            rc = MsgDelete(slot);
            RAISE_ERR( rc, RTN );
            
            MonThreadUpt(MON_THREAD_RESP_TYP);
        }
    }
    EXIT_BLOCK();
    
    LOG_DEBUG("Normal exit %d", GET_RESCODE());
    
    RETURN_RESCODE;
}

void* MatchingResponseThread(void * pConfig)
{
    BEGIN_FUNCTION( "MatchingResponseThread" );

    ResCodeT     rc = NO_ERR;
    ServiceList* pServiceList;
    CMUTEX*  pm_ClientMutex;
    METask*      pm_METask;
    int32*      pRunFlg;

    RspThreadConfigT* pRspConfig = (RspThreadConfigT*)pConfig;
    pServiceList = pRspConfig->pm_ServiceList;
    pm_ClientMutex = pRspConfig->pm_ClientMutex;
    pm_METask = pRspConfig->pm_METask;
    pRunFlg = pRspConfig->pRunFlg;

    rc = InitEpoll(pRspConfig);
    if (rc != NO_ERR)
    {
        TRACE("InitEpoll falied errcode =  %lld" $$ rc);
        return NULL;
    }

    rc = MonThreadReg(MON_THREAD_RESP_TYP);
    RAISE_ERR(ENV_VAR_CONV_ERR, NORTN);

    rc = SendReceiveRsp(pServiceList, pm_ClientMutex, pm_METask, pRunFlg);
    if (rc != NO_ERR)
    {
        return NULL;
    }


    EXIT_BLOCK();
    MonThreadSetState(MON_THREAD_RESP_TYP, THREAD_EXIT);

    return NULL;
}
