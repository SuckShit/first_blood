/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "METask_Order.h"
#include "user_order.h"
#include "msg_type.h"
#include "METask_Comm.h"
#include "order_book.h"
#include "contract_info.h"
#include "usr.h"
#include "user_order.h"
#include "org_info.h"
#include "uti_tool.h"
#include "irs_code_convert.h"
using namespace IMIX;
using namespace IMIX20;


// bil order cancel activate and freeze
ResCodeT OnBilOrderCnclRplcReqStart(int msgType,OrderCancelReplaceRequest& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBilOrderActivateStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg;
    IRS_STRING strUserId;
    UsrBaseInfoT user;
    
    LOG_INFO("%s: Req message string: %s", "OnBilOrderActivateStart", message.ToString().c_str());

    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = msgType;

    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByName((char*)strUserId.c_str(),  &user);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx   = user.pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId =PrefixStringToInt64(message.GetOrderID(),3  );

    ExecInstConvert(message.GetExecInst(), &pOrderMsg->execInst);
    RAISE_ERR(rc, RTN);

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



// bil order cancel activate and freeze
ResCodeT OnBilOrderCnclReqStart(int msgType,  OrderCancelRequest& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBilOrderCnclReqStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelRequestReqT* pOrderMsg;
    IRS_STRING strUserId;
    UsrBaseInfoT user;
    
    LOG_INFO("%s: Req message string: %s", "OnBilOrderCnclReqStart", message.ToString().c_str());

    pOrderMsg = (OrderCancelRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelRequestReqT);
    pReq->msgHdr.msgType = msgType;

    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByName((char*)strUserId.c_str(),  &user);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx   = user.pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId =PrefixStringToInt64(message.GetOrderID(),3  );

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT OnBilOrderCnclRplcReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBilOrderCnclRplcReqStop");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleRspT*  pOrderActivateStop;
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    ClearSendMsgList(pSendMsgList);
    SendMessage(pSendMsgList, pRspMessage);

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        pOrderActivateStop = (NewOrderSingleRspT*)pRsp->msgBody;
        
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderActivateStop->rspSlot,  pOrderActivateStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
        
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderActivateStop->rspOrder, pOrderActivateStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderActivateStop->rspDeal,pOrderActivateStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}





ResCodeT OnBilOrderCnclReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBilOrderCnclReqStop");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleRspT*  pOrderCnclStop;
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    ClearSendMsgList(pSendMsgList);
    SendMessage(pSendMsgList, pRspMessage);

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        pOrderCnclStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspOrder, pOrderCnclStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderCnclStop->rspSlot,  pOrderCnclStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// For bil order sumit and save
ResCodeT OnBilOrderSubmitStart(int32 msgType, NewOrderSingle& message, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrderSubmitStart");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleReqT* pOrderMsg;
    IRS_STRING strUserId;
    char securityId[30];
    pUsrBaseInfoT pUsr = NULL;
    pOrgInfoT pOrgInfo = NULL;
    pCntrctBaseInfoT pCntract = NULL;

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    pOrderMsg = (NewOrderSingleReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(NewOrderSingleReqT);
    pReq->msgHdr.msgType = msgType;

    //��ȡ��������ͽ���Ա
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByNameExt((char*)strUserId.c_str(),  &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->newOrdrInfo.userIdx   = pUsr->pos;

    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(pUsr->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.orgIdx = pOrgInfo->pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );

    strcpy(securityId, message.GetSecurityID().c_str() );
    rc = IrsCntrctInfoGetByNameExt(&securityId[0], &pCntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->newOrdrInfo.contractPos = pCntract->pos;

    //��������
    rc = SideConvert(message.GetSide(), &pOrderMsg->newOrdrInfo.side);
    RAISE_ERR(rc, RTN);

    CnvtPriceToIntnlVal(message.GetPrice(), &pOrderMsg->newOrdrInfo.prcQtyInfo.price);
    pOrderMsg->newOrdrInfo.prcQtyInfo.qty = StringToInt64( message.GetOrderQty());

    CnvtPriceToIntnlVal(message.GetCapPrice(), &pOrderMsg->askPrcQtyInfo.price);
    pOrderMsg->askPrcQtyInfo.qty = StringToInt64( message.GetOrderQty2() );


    DateTimeToTimestamp((char *)message.GetEffectiveTime().c_str(), &pOrderMsg->newOrdrInfo.effectTime);

    pOrderMsg->newOrdrInfo.ordType = ImixToIrs_OrdType(CharToString(message.GetOrdType()));
    pOrderMsg->newOrdrInfo.extOrdType = EXT_ORD_TYPE_BIL;

    rc = ExecInstConvert(message.GetExecInst(), &pOrderMsg->newOrdrInfo.execInst);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.ordAction = ORDR_ACT_NEW;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    pOrderMsg->newOrdrInfo.apiLoginUsrIdx = -1;
    pOrderMsg->newOrdrInfo.apiRqstId = 0;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// �����޸ĺ��ύ
ResCodeT OnBilOrderModifySubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox)
{
    BEGIN_FUNCTION("OnBilOrderModifySubmitStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg;
    IRS_STRING strUserId;
    IRS_STRING strordAction = E_ORD_EXEC_TYPE_MODIFY;
    char  securityId[30];
    CntrctBaseInfoT cntract;
    UsrBaseInfoT user;

    // ��Ϣ����
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORDER_MODIFY_SUBMIT_MESSAGE;

    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    rc = IrsUsrInfoGetByName((char*)strUserId.c_str(),  &user);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx   = user.pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId = PrefixStringToInt64(message.GetOrderID(),3  );

    strcpy(securityId, message.GetSecurityID().c_str() );
    rc = IrsCntrctInfoGetByName(&securityId[0], &cntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->contractPos = cntract.pos;

    //��������
    rc = SideConvert(message.GetSide(), &pOrderMsg->side);
    RAISE_ERR(rc, RTN);

    pOrderMsg->price = StringToInt64( message.GetPrice() );
    pOrderMsg->orderQty = StringToInt64( message.GetOrderQty() );
    pOrderMsg->askPrice = StringToInt64( message.GetCapPrice() );
    pOrderMsg->askOrderQty = StringToInt64( message.GetOrderQty2() );

    pOrderMsg->effectTime = StringToInt(message.GetEffectiveTime());
    OrderTypeConvert(message.GetOrdType(), &pOrderMsg->ordType);
    RAISE_ERR(rc, RTN);
    rc = ExecInstConvert(message.GetExecInst(), &pOrderMsg->execInst);
    RAISE_ERR(rc, RTN);
    pOrderMsg->ordAction = ORDR_ACT_MOD;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// �����޸ĺ󱣴�
ResCodeT OnBilOrderModifySaveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox)
{
    BEGIN_FUNCTION("OnBilOrderModifySaveStart");
    ResCodeT                rc = NO_ERR;

    OrderCancelReplaceRequestReqT* pOrderMsg;
    IRS_STRING strUserId;
    IRS_STRING strordAction = E_ORD_EXEC_TYPE_MODIFY;
    char  securityId[30];
    CntrctBaseInfoT cntract;
    UsrBaseInfoT user;

    // ��Ϣ����
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    pOrderMsg = (OrderCancelReplaceRequestReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(OrderCancelReplaceRequestReqT);
    pReq->msgHdr.msgType = MSG_TYPE_ORDER_MODIFY_SAVE_MESSAGE;

    //��ȡ����Ա
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);

    rc = IrsUsrInfoGetByName((char*)strUserId.c_str(),  &user);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx   = user.pos;

    strcpy(pOrderMsg->token, message.GetApplToken().c_str()  );
    pOrderMsg->ordId = PrefixStringToInt64(message.GetOrderID(),3  );
    strcpy(securityId, message.GetSecurityID().c_str() );
    rc = IrsCntrctInfoGetByName(&securityId[0], &cntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->contractPos = cntract.pos;

    //��������
    rc = SideConvert(message.GetSide(), &pOrderMsg->side);
    RAISE_ERR(rc, RTN);

    pOrderMsg->price = StringToInt( message.GetPrice() );
    pOrderMsg->orderQty = StringToInt( message.GetOrderQty() );
    pOrderMsg->askPrice = StringToInt( message.GetCapPrice() );
    pOrderMsg->askOrderQty = StringToInt( message.GetOrderQty2() );

    pOrderMsg->effectTime = StringToInt(message.GetEffectiveTime());
    pOrderMsg->ordAction =   ORDR_ACT_MOD;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

int OnBilOrderSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBilOrderSubmitStop");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleRspT*  pOrderSubmitStop;
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);


    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    rc = SendMessage(pSendMsgList, pRspMessage);
    RAISE_ERR(rc, RTN);

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        pOrderSubmitStop = (NewOrderSingleRspT*)pRsp->msgBody;
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspOrder, pOrderSubmitStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspDeal,pOrderSubmitStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspSlot,  pOrderSubmitStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

int OnBilOrderModifySubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBilOrderModifySubmitStop");
    ResCodeT                rc = NO_ERR;

    rc = OnBilOrderSubmitStop(pRsp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

int OnBilOrderModifySaveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBilOrderModifySaveStop");
    ResCodeT                rc = NO_ERR;

    rc = OnBilOrderSubmitStop(pRsp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
