/***
Created on Sep 19, 2017
@author: xuetao.bai
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "msg_type.h"
#include "common_macro.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "contract_info.h"
#include "msg_setlprc.h"
#include "internal_base_def.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


/*****************************************************************************
 ** 
 ** FunctionName: RiskUpdate
 ** Description:  Update for RiskVL
 *****************************************************************************/
ResCodeT SetmentPriceModify(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "SetmentPriceModify" );
    ResCodeT rc = NO_ERR;

    pSetlPrcModifyReqT      pSetlPrc = NULL;
    SetlPrcDataRefT         setlPrcData = {0};
    int32                   intOrgId = 0;

    char sysUptDateStr[MAX_TIME_LEN];

    pSetlPrc = (pSetlPrcModifyReqT)&pReq->msgBody[0];

    setlPrcData.stlPrice        = pSetlPrc->stlPrice;
    memcpy(setlPrcData.strUserId, pSetlPrc->strUserId, MAX_USR_ID_LENTH);
    memcpy(setlPrcData.strCntrctNm, pSetlPrc->strCntrctNm, MAX_CNTRCT_NM);
    memcpy(setlPrcData.strPriceDate, pSetlPrc->strPriceDate, MAX_TIME_LENGTH);
    setlPrcData.timestamp = timestamp;
    setlPrcData.setId 	= pReq->msgHdr.setId;

    if (SET_MKT_SIRS == pReq->msgHdr.setId)
    {
        rc = SirsCommonChk( pSetlPrc->strUserId, 
                    0, 
                    pSetlPrc->iFuncId, 
                    pSetlPrc->strToken, 
                    &intOrgId);
        RAISE_ERR(rc, RTN);
    }
    else if (SET_MKT_SBFCCP == pReq->msgHdr.setId)
    {
        rc = SbfCcpCommonChk( pSetlPrc->strUserId, 
                    0, 
                    pSetlPrc->iFuncId, 
                    pSetlPrc->strToken, 
                    &intOrgId);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }
    

    rc = RefDatUpdtCmmn(REF_TYP_MODY_SETLPRC_DAT, &setlPrcData, sizeof(SetlPrcDataRefT));
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;

}
