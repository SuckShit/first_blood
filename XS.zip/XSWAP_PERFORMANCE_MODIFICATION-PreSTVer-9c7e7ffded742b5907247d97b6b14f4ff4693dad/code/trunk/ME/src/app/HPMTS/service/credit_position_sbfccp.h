/***
Created on Oct 13, 2017
@author: Xiaoping Zhou
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _CREDIT_POSITION_SBFCCP_UPDATE_H_
#define _CREDIT_POSITION_SBFCCP_UPDATE_H_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Project Header files*/
#include "app_shl.h"
#include "msg_common_value.h"
#include "user_order.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define CCP_ORDER_ID_LENGTH               50
#define CCP_OCO_ORDER_ID_LENGTH           50
#define CCP_ORDER_SUBMIT_TYPE_LENGTH      8
#define CCP_ORDER_ACTION_LENGTH           8
#define CCP_FORCE_CODE_LENGTH             20
#define CCP_REQUEST_ID_LENGTH             50
#define CCP_USER_LOG_NAME_API_LENGTH      100
#define CCP_ORDER_ST_LENGTH               2
#define CCP_ORDER_TYPE_LENGTH             8

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* The result of function ClearHoldCredit(SBFCCP) */
typedef struct ClrHoldCrdtResultS
{
    double  bidUsedAmnt;
	double  bidRmnAmnt;
	double  ofrUsedAmnt;
	double  ofrRmnAmnt;
    BOOL    isLmtPstnUpdated;
	uint16  lmtPstnFlagValue;

} ClrHoldCrdtResultT, *pClrHoldCrdtResultT;

/* The input parameter of function SbfCcpOrdValidate */
typedef struct CcpOrderS
{
    char    trdrId[MAX_USR_ID_LENTH];                        // 交易员标识
	uint32  orgId;                                           // 机构名称
	char    ordrId[CCP_ORDER_ID_LENGTH];                     // 订单编号
	char    cntrctNm[MAX_CNTRCT_CD_LENGTH];                  // 合约名称
    uint16  dlDir;                                           // 订单方向(0:Bid;1:Ask)
	double  ordrPrc;                                         // 订单价格
	double  ntnlAmnt;                                        // 名义本金
	double  rmngNtnlAmnt;                                    // 剩余名义本金
	char    st[CCP_ORDER_ST_LENGTH];                         // 订单状态
	char    ocoId[CCP_OCO_ORDER_ID_LENGTH];                  // OCO编号
	char    tempOcoId[CCP_OCO_ORDER_ID_LENGTH];              // 前台临时OCO编号
	char    ordrExprDtm[MAX_TIME_LENGTH];                    // 订单到期时间
	char    ordrActvTm[MAX_TIME_LENGTH];                     // 订单激活时间
	char    ordrSbmtTp[CCP_ORDER_SUBMIT_TYPE_LENGTH];        // 订单提交类型(点击/限价)
	char    ordrAct[CCP_ORDER_ACTION_LENGTH];                // 订单处理类型(新增/修改/加入退出oco)
	uint16  isExecute;                                       // 是否检查盘中参考价
	char    forceCd[CCP_FORCE_CODE_LENGTH];                  // 强平指令编号
	char    rqstId[CCP_REQUEST_ID_LENGTH];                   // api用户请求id
	char    usrLgnNmApi[CCP_USER_LOG_NAME_API_LENGTH];       // api用户登录名
	char    orgCd[MAX_ORG_CD_LENTH];

} CcpOrderT, *pCcpOrderT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/* 合约转换比例 */
ResCodeT SbfCcpCntrctCnvrtModify(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);

/* 场务限仓 */
ResCodeT SbfCcpCrdtLimitByCw(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp);

/* CW端强平 */
ResCodeT SbfCcpOrdrSubmitByCw(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

/* CW端强平撤销 */
ResCodeT SbfCcpOrdrCancelByCw(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

/* 订单验证 */
ResCodeT SbfCcpOrdrValidate(pNewOrderInfoT pOrder, int64 timestamp);

// /* 订单激活处理 */
// ResCodeT SbfCcpOrdrProcess(int32 connId, pCcpOrderT pOrder, char *outOrderId, int64 timestamp );

// /* 订单保存处理 */
// ResCodeT SbfCcpOrdrAdd(int32 connId, pCcpOrderT pOrder, char *outOrderId, int64 timestamp );

// /* 通过客户端临时ID获取OCO编号 */
// ResCodeT SbfCcpGetOcoId(int32 connId, pCcpOrderT pOrder, char *outSt, char *outOcoId );

ResCodeT SbfCcpOrdrSubmitByQss(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);
ResCodeT SbfCcpOrdrCancelByQss(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx);

#endif /* _CREDIT_POSITION_SBFCCP_UPDATE_H_ */
