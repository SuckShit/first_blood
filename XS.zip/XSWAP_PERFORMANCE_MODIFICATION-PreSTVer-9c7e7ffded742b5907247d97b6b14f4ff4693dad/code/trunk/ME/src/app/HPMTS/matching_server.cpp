/***
Created on JUN 06, 2017
@author: Ming.Kong
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "err_lib.h"
#include "err_cod.h"
#include "uti_tool.h"

#include "matching_listener.h"
#include "matching_response.h"
#include "matching_engine.h"
#include "service_manager.h"
#include "dump_ord.h"
#include "active_keeper.h"
#include "monitor_thread.h"
#include "perf_stat.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

int main(int argc, char* argv[] )
{
    BEGIN_FUNCTION("main");
    ResCodeT    rc = NO_ERR;

    MatchingListener *  pListener;
    pthread_t           rspThreadId;
    pthread_t           dmpThreadId;
    pthread_t           haThreadId;
    pthread_t           monThreadId;
    RspThreadConfigT    rspCfg;
    EngThreadConfigT    engCfg;
    int32               resRunFlg = RESPONSE_RUN_FLUG_RUN;
    int32               engRunFlg = ENGINE_RUN_FLUG_RUN;
    int32               dmpRunFlg = MEM_TXN_DUMP_TO_DB_RUN;
    int32               monRunFlg = MEM_TXN_MON_RUN;
    
    int                 nRes;
    string              InitPath;
    string              InitFilePath;

    pPerfStatT pShmRoot = NULL;
    
    if (argc != 3)
    {
        RAISE_ERR(ERR_CAR_MAIN_PARAMETER_NUMBERS_ERR, RTN);
    }

    InitFilePath = argv[2];
    PrcsInit(argv[2]);
    
    rc = PerfStatShmCreate(&pShmRoot);
    RAISE_ERR(rc, RTN);


    // create application object
    DEP::Application * pApplication;
    pApplication = new DEP::Application();
    if ( NULL == pApplication )
    {
        RAISE_ERR(ERR_CAR_DEP_API_CREATE_ERR, RTN);
    }
    
    

    pListener = new MatchingListener(InitFilePath);
    if ( NULL == pListener )
    {
        RAISE_ERR(ERR_CAR_MARCH_LISTENER_CTEATE_ERR, RTN);
    }

    /* Create Share memory */
    rc = pListener->CreateShm(InitFilePath);
    RAISE_ERR(rc, RTN);

    

    rc = MonThreadShmCreate();
    RAISE_ERR(rc, RTN);

    rspCfg.msgHdl         = pListener->m_rd_msgHdl;
    rspCfg.pm_ServiceList = (ServiceList*)&pListener->m_ServiceList;
    rspCfg.pm_ClientMutex = (CMUTEX*)&pListener->m_ClientMutex;
    rspCfg.pm_METask      =  pListener->m_pMEtask;
    rspCfg.pRunFlg        =  &resRunFlg;
    pthread_create(&rspThreadId, NULL, MatchingResponseThread, (void*)&rspCfg);
    
    rc = ActiveKeeperInitWithoutConn();
    RAISE_ERR(rc, RTN);

    pthread_create(&haThreadId, NULL, HaThreadMain, (void*)NULL);
    
    engCfg.rdMsgHdl     = pListener->m_wr_msgHdl;
    engCfg.wrMsgHdl     = pListener->m_rd_msgHdl;
    engCfg.eventMsgHdl  = pListener->m_event_msgHdl;
    engCfg.pRunFlg      = &engRunFlg;
    rc = ServiceManagerInit(&engCfg);
    RAISE_ERR(rc, RTN);

    pthread_create(&dmpThreadId, NULL, MatchingDumptxnThread, (void*)&dmpRunFlg);

    pthread_create(&monThreadId, NULL, MonitorServThread, (void*)&monRunFlg);
    
    LOG_INFO("Start to listen");
    //book Listener object into Application object
    pApplication->SetListener( pListener );


    //create the cfg file
    InitPath = MakeFilePath(InitFilePath, CFG_FILE_NM);

    //4. init
    nRes = pApplication->Init(InitPath);
    if ( UTILITY::SUCCESS != nRes )
    {
        LOG_DEBUG("ME exit with error");
        delete pListener;
        RAISE_ERR(ERR_CAR_DEP_API_INIT_ERR, RTN);
    }
    LOG_INFO("Start to register Timer ");
    rc = pListener->RegisterMatchingTimer(pApplication);
    RAISE_ERR(rc, RTN);


    //start all service
    pApplication->Start();


    pApplication->Join();

    resRunFlg = RESPONSE_RUN_FLUG_END;
    engRunFlg = ENGINE_RUN_FLUG_END;
    dmpRunFlg = MEM_TXN_DUMP_TO_DB_END;
    monRunFlg = MEM_TXN_MON_END;

    rc = ServiceManagerStop();
    RAISE_ERR(rc, RTN);

    rc = ServiceManagerWait();
    RAISE_ERR(rc, RTN);

    rc = ActiveKeeperStop();
    RAISE_ERR(rc, RTN);

    pthread_join(rspThreadId, NULL);
    pthread_join(dmpThreadId, NULL);
    pthread_join(haThreadId, NULL);
    pthread_join(monThreadId, NULL);


    EXIT_BLOCK();

    /* Detach Share memory */
    rc = pListener->DetachShm();
    RAISE_ERR(rc, NORTN);

    LOG_INFO("ME exit Normally");
    delete pListener;

    RETURN_RESCODE;
}
