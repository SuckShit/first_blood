/***
Created on July 20, 2017
@author: kong
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "pck_irs_dicdata.h"
#include "usr.h"
#include "org_info.h"
#include "intrnl_msg.h"
#include "app_shl.h"
#include "market_usr_role.h"
#include "ref_dat_updt.h"
#include "org_def_ref.h"
#include "usr_role_update.h"

#include "match_lib.h"
#include "pck_irs_util.h"
#include "uti_tool.h"
#include "internal_base_def.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/******************************************************************************
 **
 ** Detail Service Callback : UsrMarkerRoleUpadateMessage
 **
 ******************************************************************************/
ResCodeT UsrMarkerRoleUpadateMessage(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "UsrMarkerRoleUpadateMessage" );
    ResCodeT rc = NO_ERR;

    SecurityListReqT* pRoleUpdateReq;
    SecurityListRspT* pRoleUpdateRsp;

    OrgInfoT orgInfo;
    BrdgOrgInfoT brdgOrgInfo;
    UsrBaseInfoT usrBsInfo;
    UsrBaseInfoT usrInfo;

    BrdgOrdrRcrdT brdgOrdr;

    int32 prevBrdgSt;
    int32 postBrdgSt;

    OrgMemDataRefT  data;
    int32 dataLen;
    /*---------------------------出参和过程变量的初始化--------------------*/
    memset(&orgInfo, 0x00, sizeof(OrgInfoT));
    memset(&brdgOrgInfo, 0x00, sizeof(BrdgOrgInfoT));
    memset(&usrBsInfo, 0x00, sizeof(UsrBaseInfoT));
    memset(&usrInfo, 0x00, sizeof(UsrBaseInfoT));
    memset(&brdgOrdr, 0x00, sizeof(BrdgOrdrRcrdT));

    //RequestMessage 
    pRoleUpdateReq  = (SecurityListReqT*)&pReq->msgBody[0];
    //ResponseMessage 
    pRoleUpdateRsp  = (SecurityListRspT*)&pRsp->msgBody[0];
    memset(pRoleUpdateRsp, 0x00, sizeof(SecurityListRspT));

    memset(&data, 0x00, sizeof(OrgMemDataRefT));
    dataLen = sizeof(OrgMemDataRefT);

    // [IN]Set Parameters.
    data.eMessageType = MSG_TYPE_USR_MARKET_ROLE_UPDATE;
    strcpy(data.strUserId,   pRoleUpdateReq->strUserId);
    strcpy(data.strOpUserId, pRoleUpdateReq->strOpUsrId);
    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);
    /*-----------------------------通用检查--------------------------------*/
    rc = CommonChk( pRoleUpdateReq->strUserId, 
                    C_ORG_NULL, 
                    pRoleUpdateReq->iFuncId, 
                    pRoleUpdateReq->strToken, 
                    &data.intOrgId );
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    rc = OrgInfoGetById(data.intOrgId, &orgInfo);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    rc = IrsUsrInfoGetByName(data.strOpUserId, &usrBsInfo);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    // 桥机构信息(前)状态取得
    rc = BrdgOrgInfoGetById(data.intOrgId, &brdgOrgInfo);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    prevBrdgSt = brdgOrgInfo.brdgOrgSt;

    // 桥机构信息(后)状态取得
    if (0 == strcmp("", brdgOrgInfo.usrLgnNm)) {
        postBrdgSt = 0;
    }
    else if (0 == strcmp(data.strOpUserId, brdgOrgInfo.usrLgnNm)) {
        if (C_USR_ST_ACTIVE == pRoleUpdateReq->iMktIrsRole &&   // 用户的IRS市场权限
            C_ORG_ST_ACTIVE == orgInfo.mktTypeSt[0] &&          // 机构的IRS市场权限
            C_CRT_NONE == brdgOrgInfo.crdtOprtngSt &&           // 当前无授信操作
            1 == brdgOrgInfo.brdgPrvlgFlag &&                   // 该机构为桥机构
            1 == brdgOrgInfo.brdgIntntnFlag ) {                 // 该机构愿意成为桥机构
            postBrdgSt = 1;
        }
        else {
            postBrdgSt = 0;
        }
    }
    else {
        rc = IrsUsrInfoGetByName(brdgOrgInfo.usrLgnNm, &usrInfo);
        RAISE_ERR(rc, RTN);

        if (C_USR_ST_ACTIVE == usrInfo.mktSt[0] &&      // 用户的IRS市场权限
            C_ORG_ST_ACTIVE == orgInfo.mktTypeSt[0] &&  // 机构的IRS市场权限
            C_CRT_NONE == brdgOrgInfo.crdtOprtngSt &&   // 当前无授信操作
            1 == brdgOrgInfo.brdgPrvlgFlag &&           // 该机构为桥机构
            1 == brdgOrgInfo.brdgIntntnFlag ) {         // 该机构愿意成为桥机构
            postBrdgSt = 1;
        }
        else {
            postBrdgSt = 0;
        }
    }

    //IRS市场(有)
    if (orgInfo.mktTypeSt[0] == C_ORG_ST_ACTIVE) {
        data.intSt = pRoleUpdateReq->iMktIrsRole;
        data.intMktTp = C_MKT_TP_IRS;
        // 刷新桥单
        if (0 == prevBrdgSt && 1 == postBrdgSt) {
            // 刷新全市场
            rc = MtchBrdgOrdrUpdt( TRUE, SET_MKT_IRS, ACTN_BRDG_DEL_ALL, &brdgOrdr );
        }
        else if (1 == prevBrdgSt && 0 == postBrdgSt) {
            // 刷新该机构
            brdgOrdr.brdgOrgId = orgInfo.pos;
            rc = MtchBrdgOrdrUpdt( TRUE, SET_MKT_IRS, ACTN_BRDG_DEL_BRDG, &brdgOrdr );
        }
        else{
            // 不刷新桥单
        }
        RAISE_ERR(rc, RTN);

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);

        if (C_ORG_ST_FORBID == pRoleUpdateReq->iMktIrsRole &&
            C_ORG_ST_ACTIVE == orgInfo.mktTypeSt[0]) {
           // 撤销订单
           /* init NewOrderSingleRspT */
           InitRspDat(&pRoleUpdateRsp->rspOrderCancel);

           rc = MtchrPrcsOrdrCnclByUser(
                    SET_MKT_IRS, 
                    timestamp,
                    usrBsInfo.pos, 
                    orgInfo.pos, 
                    &pRoleUpdateRsp->rspOrderCancel);
           if (NOTOK(rc) && APIERR_CODE_INVLD_USR_ORDR != rc) {
                RAISE_ERR(rc, RTN);
           }
        }
    }
    else if (pRoleUpdateReq->iMktIrsRole == C_ORG_ST_ACTIVE) {
        RAISE_ERR(ERR_CODE_PERMISSION_INEDITABLE, RTN);
    }

    //SIRS市场(有)
    if (orgInfo.mktTypeSt[1] == C_ORG_ST_ACTIVE) {
        data.intSt = pRoleUpdateReq->iMktSirsRole;
        data.intMktTp = C_MKT_TP_SIRS;

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);

        if (C_ORG_ST_FORBID == pRoleUpdateReq->iMktSirsRole && 
            C_ORG_ST_ACTIVE == orgInfo.mktTypeSt[1]) {
            // 撤销订单
            /* init NewOrderSingleRspT */
            InitRspDat(&pRoleUpdateRsp->rspOrderCancel);
            rc = MtchrPrcsOrdrCnclByUser(
                    SET_MKT_SIRS, 
                    timestamp,
                    usrBsInfo.pos, 
                    orgInfo.pos, 
                    &pRoleUpdateRsp->rspOrderCancel);
           if (NOTOK(rc) && APIERR_CODE_INVLD_USR_ORDR != rc) {
                RAISE_ERR(rc, RTN);
           }
        }
    }
    else if (pRoleUpdateReq->iMktSirsRole == C_ORG_ST_ACTIVE) {
        RAISE_ERR(ERR_CODE_PERMISSION_INEDITABLE, RTN);
    }
    
    //SBF市场(mktTypeSt[2]无)
    //SIRSCCP市场(mktTypeSt[3]无)

    //SBFCCP市场(mktTypeSt[4]有)
    if (orgInfo.mktTypeSt[4] == C_ORG_ST_ACTIVE) {
        data.intSt = pRoleUpdateReq->iMktSbfccpRole;
        data.intMktTp = C_MKT_TP_SBFCCP;

        rc = RefDatUpdtCmmn(REF_TYP_UPDT_ORG_DAT, &data, dataLen);
        RAISE_ERR(rc, RTN);

        if (C_ORG_ST_FORBID == pRoleUpdateReq->iMktSbfccpRole && 
            C_ORG_ST_ACTIVE == orgInfo.mktTypeSt[4]) {
           // 撤销订单
           /* init NewOrderSingleRspT */
           InitRspDat(&pRoleUpdateRsp->rspOrderCancel);
           rc = MtchrPrcsOrdrCnclByUser(
                    SET_MKT_SBFCCP, 
                    timestamp,
                    usrBsInfo.pos, 
                    orgInfo.pos, 
                    &pRoleUpdateRsp->rspOrderCancel);
           if (NOTOK(rc) && APIERR_CODE_INVLD_USR_ORDR != rc) {
                RAISE_ERR(rc, RTN);
           }
        }
    }
    else if (pRoleUpdateReq->iMktSbfccpRole == C_ORG_ST_ACTIVE) {
        RAISE_ERR(ERR_CODE_PERMISSION_INEDITABLE, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
