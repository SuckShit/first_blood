/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "intrnl_msg.h"
#include "err_lib.h"
#include "msg_type.h"
#include "IMIXT10/Message/Logon.h"
#include "IMIXT10/Comm/MessageType.h"
#include "IMIX20/Comm/MessageType.h"
#include "DEP/DEPAPIErrorDef.h"

#include "METask.h"
#include "METask_Layer2.h"
#include "METask_Login.h"
#include "METask_Order.h"
#include "METask_BilOrder.h"
#include "METask_OcoOrder.h"
#include "METask_Clear_Account.h"

#include "METask_MktDiff.h"
#include "METask_CW.h"
#include "METask_Api.h"
#include "METask_Officer.h"
#include "METask_Client.h"
#include "METask_Timer.h"
#include "METask_Comm.h"
#include "perf_stat.h"
#include "cfg_lib.h"
#include "../service/ref_prc_update.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define RESRVE_MSG_HEADER_MAX_CNT       10000
#define MAX_MSG_ID_LEN                  15

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
using namespace IMIX20;
using ::IMIX::BasicHeader;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
METask::METask ()
{
    // 初始化消息处理函数映射表
    InitStartFunctionHash();
    //InitStopFunctionHash();
}

METask::~METask ()
{

}

ResCodeT METask::InitStartFunctionHash( )
{
    BEGIN_FUNCTION("InitStartFunctionHash");
    ResCodeT                rc = NO_ERR;

    m_mapStart[UserRequestMessageID] = &OnLogonAndOutStart;

    //订单提交,订单保存
    m_mapStart[NewOrderSingleMessageID] = &OnMktNewOrderSingleMsgStart;
    //基本参数设置(不分市场)
//  m_mapStart[SecurityDefinitionMessageID] = &OnBaseParamUpdateStart;

    m_mapStart[SecurityDefinitionMessageID] = &OnCWStart;
    //订单激活,订单冻结,订单修改后保存,修改后提交,OCO订单激活,OCO订单冻结
    m_mapStart[OrderCancelReplaceRequestMessageID] = &OnMktOrdCancelReplaceReqMsgStart;
    //订单撤销
    m_mapStart[OrderCancelRequestMessageID] = &OnMktOrderCancelStart;
//delete by kong start
  //期差订单:提交
    m_mapStart[NewOrderMultilegMessageID] = &OnNewOrderMultilegStart;//期差订单
    //期差订单:修改后提交,修改后保存,冻结,激活 (不分市场)
    m_mapStart[MultilegOrderCancelReplaceMessageID] = &OnMultilegOrderCancelReplaceStart;//期差订单

   //OCO订单撤销请求,应答
    m_mapStart[ListCancelRequestMessageID] = &OnMktOcoOrderCancelStart;

    //OCO订单保存,提交
    m_mapStart[NewOrderListMessageID] = &OnMktNewOrderListMsgStart;

    //风险系数修改,授信更新,风险系数维护,,授信更新方式更新,取消授信、风险系数设置
    m_mapStart[PartyRiskLimitsDefinitionRequestMessageID] = &OnCSMsgStart;
/*
    //合约参数设置
    m_mapStart[SecurityDefinitionRequestMessageID] = &OnContractParamUpdateStart;
*/
    //成交撤销
    m_mapStart[ExecutionReportMessageID] = &OnMktExecutionReportStart;
/*
    //机构禁用/解禁,资金账户更新
    m_mapStart[PartyDetailsListReportMessageID] = &OnCGMsgStart;
*/  //delete end
    //市场状态更新
    m_mapStart[TradingSessionStatusMessageID] = &OnUpdMktInfoStart;

    /*  mass消息:
    E_MASS_TYPE_OCO_SUBMIT_REQ = 1, //OCO订单修改后提交
    E_MASS_TYPE_OCO_SAVE_REQ,       //OCO订单修改后保存
    E_MASS_TYPE_CREDIT_UPD_REQ = 3, //授信维护请求
    E_MASS_TYPE_RISK_UPD_REQ = 4,   //风险系数维护
    E_MASS_TYPE_CONTRACT_UPD_REQ = 5,//合约参数维护

    E_MASS_TYPE_ORD_QUERY = 6,      //订单查询结果
    E_MASS_TYPE_DEAL_QUERY = 7,     //成交查询结果
    E_MASS_TYPE_IMPORD = 8,         //隐含订单（TDPS)通知消息
    E_MASS_TYPE_CONTRACT_QUERY = 9, //合约参数查询结果消息
    E_MASS_TYPE_ACCOUNT_DELETE = 11,//资金账户删除
    E_MASS_TYPE_CW_PRICE_MODITY = 12,//场务每日结算价修改*/

    m_mapStart[DataSetMessageID] = &OnMktDataSetMsgStart;

    /*
//SIS新增消息类型
    m_mapStart[ParameterDefinitionMessageID] = &OnMktContractParamUpdateStart;
        //SIRS_OnContractParamUpdateStart;

    //会员限额调整
    m_mapStart[PartyRiskLimitsUpdateReportMessageID] = &OnPartyRiskLimitsUpdateReportStart;

*/
    //集中清算产品权限设置
    m_mapStart[SecurityListMessageID] = &OnUsrMktRoleUpdateStart;

/*
    //对外接口 提前终止
    m_mapStart[TradeCaptureReportMessageID] = &SIRS_OnTrdAbandonStart;
*/

    //清算所交互消息
    m_mapStart[QueryResultMessageID] = &OnClearingAccountStart;

    //机构禁用/解禁,资金账户更新
    m_mapStart[PartyDetailsListReportMessageID] = &OnCGMsgStart;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT METask::OnMEStartPlus(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnSPStartPlus");
    ResCodeT                rc = NO_ERR;
    IRS_STRING strMsgId;
    IMIX::BasicMessage& baseMsg = const_cast<IMIX::BasicMessage&>(inMessage);

    if (NULL == pReq)
    {
        RAISE_ERR(ERR_MSG_HANDLE_NULL_ERR, RTN);
    }
    

    
#ifdef PERF_TEST    
    if (baseMsg.GetHeader()->GetMsgType() != UserRequestMessageID)
    {
        LOG_DEBUG("ME Return for test :Msgid[%s],#msg_in#[%s]",
        baseMsg.GetHeader()->GetMsgType().c_str(),baseMsg.ToString().c_str());
        RETURN_RESCODE;
    }
#endif

    LOG_DEBUG("ME start:Msgid[%s],#msg_in#[%s]",
        baseMsg.GetHeader()->GetMsgType().c_str(),baseMsg.ToString().c_str());

    //根据消息号进行处理,增加对不同类型消息的判断
    strMsgId = baseMsg.GetHeader()->GetMsgType();

    if (this->m_mapStart[strMsgId] != NULL)
    {
        rc = (*(this->m_mapStart[strMsgId]))(inMessage, pReq);
        RAISE_ERR(rc, RTN);
    }
    else
    {
        RAISE_ERR(ERR_MSG_ID_ERR, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT METask::OnMEStopPlus(IntrnlMsgT* pInterMsg, SENDMSGLIST* pOutImixMsg)
{
    //返回值
    BEGIN_FUNCTION("OnMEStopPlus");
    ResCodeT                rc = NO_ERR;

    if (NULL == pInterMsg ||
        NULL == pOutImixMsg) {
        RAISE_ERR(ERR_MSG_HANDLE_NULL_ERR, RTN);
    }

    switch (pInterMsg->msgHdr.msgType) {
        case MSG_TYPE_USER_LOGIN:
            rc = OnLoginStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_USER_LOGOUT:
            rc = OnLogoutStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_REMOVE_ONLINE_USER:
            rc = OnRemoveOnlineUserStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_LOGIN:
            rc = OnApiLoginStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_LOGOUT:
            rc = OnApiLogoutStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_PARAM_UPDATE:
            rc = OnAPIParamUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_USER_FREEZE:
            rc = OnAPIUserFreezeStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_USER_REMOVE:
            rc = OnAPIUserRemoveStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_SUBSCRIBE:
            rc = OnApiSubscribeStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_UNSUBSCRIBE_ALL:
            rc = OnApiUnSubscribeAllStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_ORD_SUBMIT:
            rc = OnApiOrdSubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_ORD_CANCEL:
            rc = OnApiOrdCancelStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SIRS_API_ORD_SUBMIT:
            rc = OnApiOrdSubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SIRS_API_ORD_CANCEL:
            rc = OnApiOrdCancelStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_API_ORD_SUBMIT:
            rc = OnApiOrdSubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_API_ORD_CANCEL:
            rc = OnApiOrdCancelStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_TRADER_PRIVIL_CONFIG:
            rc = OnApiPrvlgUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;

        case MSG_TYPE_API_CREDIT_UPDATE:
            rc = OnApiCreditUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_API_RISK_UPDATE:
            rc = OnApiRiskUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;

        case MSG_TYPE_CREDIT_MODIFY:
            //风险系数修改
            rc = OnCreditAndRiskModifyStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_CREDIT_UPDATE:
            //授信更新
            rc = OnCreditUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_CREDIT_UNLOCK:
            //授信更新解锁
            rc = OnUnlockCreditStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_CREDIT_REFRESH_METHOD_UPDATE:
            //授信更新方式设置
            rc = OnCreditRefreshMethodUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_ORDER_SUBMIT_MESSAGE:
        case MSG_TYPE_ORDER_SAVE_MESSAGE:
        case MSG_TYPE_ORDER_WITHDRAW_MESSAGE:
            rc = OnOrderSubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_ORDER_MODIFY_SUBMIT_MESSAGE:
            rc = OnOrderModifySubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_ORDER_MODIFY_SAVE_MESSAGE:
            rc = OnOrderModifySaveStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_ORDER_CANCEL_MESSAGE:
            rc = OnOrderCnclReqStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_ORDER_FREEZE_MESSAGE:
        case MSG_TYPE_ORDER_ACTIVATE_MESSAGE:
            rc = OnOrderCnclRplcReqStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_PERIOD_VALIDATE:
            rc = OnPeriodValidateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_TIMER_CAL_REF_PRC:
            rc = OnTimerCalRefPrcStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_MKT_DAT_PUSH:
            rc = OnMktDatPushStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BILORDER_SUBMIT_MESSAGE:
        case MSG_TYPE_BILORDER_SAVE_MESSAGE:
        case MSG_TYPE_BILORDER_WITHDRAW_MESSAGE:
            rc = OnBilOrderSubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;

        case MSG_TYPE_BILORDER_MODIFY_SUBMIT_MESSAGE:
            rc = OnBilOrderModifySubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BILORDER_MODIFY_SAVE_MESSAGE:
            rc = OnBilOrderModifySaveStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BILORDER_CANCEL_MESSAGE:
            rc = OnBilOrderCnclReqStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BILORDER_FREEZE_MESSAGE:
        case MSG_TYPE_BILORDER_ACTIVATE_MESSAGE:
            rc = OnBilOrderCnclRplcReqStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_OCOORDER_SUBMIT_MESSAGE:
        case MSG_TYPE_OCOORDER_SAVE_MESSAGE:
        case MSG_TYPE_OCOORDER_WITHDRAW_MESSAGE:
            rc = OnOcoOrderSubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;

        case MSG_TYPE_OCOORDER_MODIFY_SUBMIT_MESSAGE:
            rc = OnOcoOrderModifySubmitStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_OCOORDER_MODIFY_SAVE_MESSAGE:
            rc = OnOrderModifySaveStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_OCOORDER_CANCEL_MESSAGE:
            rc = OnOcoOrderCnclReqStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_OCOORDER_FREEZE_MESSAGE:
        case MSG_TYPE_OCOORDER_ACTIVATE_MESSAGE:
            rc = OnOcoOrderCnclRplcReqStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_DEAL_CNCL_MESSAGE:
            rc = OnTrdCancelStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        //机构禁用/解禁
        case MSG_TYPE_ORG_BANK_FREEZE:
            rc = OnBankFreezeStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        //机构权限市场
        case MSG_TYPE_ORG_MARKET_ROLE_UPDATE:
            rc = OnOrgMktRoleUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        //用户市场权限设置
        case MSG_TYPE_USR_MARKET_ROLE_UPDATE:
            rc = OnUsrMktRoleUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_MSG_TO_TDPS:
            rc = SendMsgToTDPS(pInterMsg, pOutImixMsg);
            break;
        case MSG_TYPE_ORDTRD_TO_CLNT:
            rc = SendOrdTrdToClntStop(pInterMsg, pOutImixMsg);
            break;
        case MSG_TYPE_MSG_TO_GATEWAY:
            rc = SendMsgToGatewayStop(pInterMsg, pOutImixMsg);
            break;
        case MSG_TYPE_MARKET_INFO_UPDATE:
            rc = OnUpdMktInfoStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BRIDGE_DEALER_UPDATE:
            rc = OnBrdgDealerUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BRIDGE_CREDIT_MODIFY:
            rc = OnBrdgCrdtModifyStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BRIDGE_CREDIT_UPDATE:
            rc = OnBrdgCrdtUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_MARKET_CONFIG_MODIFY_CW:
            rc = OnMarketStateTimeSetStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BRIDGE_PERCENTAGE_UPDATE:
            rc = OnBrdgPercentageUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_ORDER_CANCEL_BY_ADMIN:
            rc = OnOrderCancelStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_BRDG_ORDR_TRGR:
            rc = OnBrdgOrdrStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_RISK_UPDATE:
            rc = OnRiskCoefUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SETL_PRC_MODIFY:
            rc = OnSetmentPriceModifyStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_CCP_CREDIT_UPDATE:
            rc = OnCCPCreditUpdateStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_ORDER_SUBMIT_QSS:
            rc = OnSBFCCPClosePositionStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_ORDER_CANCEL_QSS:
            rc = OnSBFCCPClosePositionCancelStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_CREDIT_LIMIT_CW:
            rc = OnSBFCCP_LimitPositionStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_ORDER_CANCEL_CW:
            rc = OnSBFCCP_UndoClosePositionStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;
        case MSG_TYPE_SBFCCP_ORDER_SUBMIT_CW:
            rc = OnSBFCCP_ClosePositionStop(pInterMsg, pOutImixMsg, pInterMsg->msgHdr.errCode);
            break;

        default:
            break;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT METask::DefineTimer(TimerList* lTimerList)
{
    //返回值
    BEGIN_FUNCTION("DefineTimer");
    ResCodeT                rc = NO_ERR;

    MatchingTimer* pRefPrcCalcTimer = NULL;
    MatchingTimer* pOrdPeriodTimer = NULL;
    MatchingTimer* pMktDatPushTimer = NULL;
    MatchingTimer* pBrdgOrdrTimer = NULL;
    MDReqGrp* pMDReqGrp;
    MDReqGrp::NoMDEntryTypes* pNoMDEntryTypes;

    struct cfgValueS cfgValue = {0};

    /* Get config value for the system  */
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);

    //订单过期检查消息
    m_pOrderCheckMsg = new ExecutionReport();
    if (NULL != m_pOrderCheckMsg)
    {
        m_pOrderCheckMsg->SetExecInst(EXECINST_ORD_CHECK);

        pOrdPeriodTimer = new MatchingTimer(m_pOrderCheckMsg, TIMER_ORD_PERIOD_INTERVAL);
        if (NULL != pOrdPeriodTimer)
        {
            lTimerList->push_back(pOrdPeriodTimer);
        }
        else
        {
            RAISE_ERR(ERR_MSG_ID_ERR, RTN);
        }
    }
    else
    {
        RAISE_ERR(ERR_MSG_ID_ERR, RTN);
    }


    /* Define market data push event */
    m_pMktDatPushMsg = new ExecutionReport();
    if (NULL != m_pMktDatPushMsg)
    {
        m_pMktDatPushMsg->SetExecInst(EXECINST_MKT_DAT_PUSH);

        pMktDatPushTimer = new MatchingTimer(m_pMktDatPushMsg, cfgValue.iMktDatPushIntrval*1000); // 2 seconds
        if (NULL != pMktDatPushTimer)
        {
            lTimerList->push_back(pMktDatPushTimer);
        }
        else
        {
            RAISE_ERR(ERR_MSG_ID_ERR, RTN);
        }
    }
    else
    {
        RAISE_ERR(ERR_MSG_ID_ERR, RTN);
    }


    /* Define market data push event */
    m_pBrdgOrdrMsg = new ExecutionReport();
    if (NULL != m_pBrdgOrdrMsg)
    {
        m_pBrdgOrdrMsg->SetExecInst(EXECINST_BRDG_ORDR_TRGR);
		int64       byPassFreqcy = 0;
		rc = GetBypassFrequency(&byPassFreqcy);
		RAISE_ERR(rc, RTN);

        pBrdgOrdrTimer = new MatchingTimer(m_pBrdgOrdrMsg, byPassFreqcy*1000);
        if (NULL != pBrdgOrdrTimer)
        {
            lTimerList->push_back(pBrdgOrdrTimer);
        }
        else
        {
            RAISE_ERR(ERR_MSG_ID_ERR, RTN);
        }
    }
    else
    {
        RAISE_ERR(ERR_MSG_ID_ERR, RTN);
    }

    m_pMarketDataReqMsg = new ExecutionReport();
    if (NULL != m_pMarketDataReqMsg)
    {
        m_pMarketDataReqMsg->SetExecInst(EXECINST_CAL_REF_PRC_TRGR);

        pRefPrcCalcTimer = new MatchingTimer(m_pMarketDataReqMsg, TIMER_REFPRC_CALC_INTERVAL*1000);
        if (NULL != pRefPrcCalcTimer)
        {
            lTimerList->push_back(pRefPrcCalcTimer);
        }
        else
        {
            RAISE_ERR(ERR_MSG_ID_ERR, RTN);
        }
    }
    else
    {
        RAISE_ERR(ERR_MSG_ID_ERR, RTN);
    }

    EXIT_BLOCK();

    if (rc != NO_ERR)
    {
        if (NULL != pRefPrcCalcTimer)
        {
            delete pRefPrcCalcTimer;
            pRefPrcCalcTimer =NULL;
        }

        if (NULL != pOrdPeriodTimer)
        {
            delete pOrdPeriodTimer;
            pOrdPeriodTimer =NULL;
        }

        if (NULL != m_pOrderCheckMsg)
        {
            delete m_pOrderCheckMsg;
            m_pOrderCheckMsg = NULL;
        }

        if (NULL != m_pMktDatPushMsg)
        {
            delete m_pMktDatPushMsg;
            m_pMktDatPushMsg = NULL;
        }
        if (NULL != pMktDatPushTimer)
        {
            delete pMktDatPushTimer;
            pMktDatPushTimer = NULL;
        }

        if (NULL != m_pMarketDataReqMsg)
        {
            delete m_pMarketDataReqMsg;
            m_pMarketDataReqMsg = NULL;
        }

        if (NULL != pBrdgOrdrTimer)
        {
            delete pBrdgOrdrTimer;
            pBrdgOrdrTimer = NULL;
        }

        if (NULL != m_pBrdgOrdrMsg)
        {
            delete m_pBrdgOrdrMsg;
            m_pBrdgOrdrMsg = NULL;
        }

        lTimerList->clear();
    }

    RETURN_RESCODE;
}
