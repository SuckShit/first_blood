/***
Created on Aug 02, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#ifndef _METASK_CLEAR_ACCOUNT_H_
#define _METASK_CLEAR_ACCOUNT_H_

#include "data_type.h"
#include "internal_function_def.h"
#include "intrnl_msg.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define LOGIN_STATUS_SUCCESS            1
#define LOGIN_STATUS_FAIL               2
#define LOGOUT_STATUS_SUCCESS           1
#define LOGOUT_STATUS_FAIL              2
#define CREDITUPDATE_SUCCESS            3
#define CREDITUPDATE_ERROR              10
#define SUBCRIBE_STATUS_SUCCESS         0
#define SUBCRIBE_STATUS_FAIL            1

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
// ������ʵʱ�ӿ�
ResCodeT OnClearingAccountStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq
);
ResCodeT OnUsrMktRoleUpdateStart(
    const IMIX::BasicMessage& inMessage, 
    IntrnlMsgT* pReq
);
ResCodeT OnUsrMktRoleUpdateStop(
    IntrnlMsgT* pRsp, 
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag
);

//ResCodeT OnClearingAccountStop(RESETLIST* pRSnMap,SENDMSGLIST* pSendMsgList,MsgList* pParamList,const IMIX::BasicMessage& inMessage,int nExceptionFlag);
ResCodeT OnCCPCreditUpdateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnCCPCreditUpdateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);
ResCodeT OnSBFCCPClosePositionStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnSBFCCPClosePositionStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);
ResCodeT OnSBFCCPClosePositionCancelStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnSBFCCPClosePositionCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag); 

#endif /* _METASK_CLEAR_ACCOUNT_H_ */
