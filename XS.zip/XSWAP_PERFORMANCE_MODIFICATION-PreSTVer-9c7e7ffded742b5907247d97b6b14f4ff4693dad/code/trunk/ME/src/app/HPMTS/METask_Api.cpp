/***
Created on JUN 06, 2017
@author: Dongwei.Li
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */

/* Project Header File */
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"

#include "msg_credit.h"

#include "METask_Api.h"
#include "METask_Comm.h"
#include "METask_API_Comm.h"
#include "login.h"
#include "api.h"
#include "usr.h"
#include "org_info.h"
#include "contract_info.h"
#include "uti_tool.h"
#include "irs_code_convert.h"
#include "order_book.h"
#include "pck_irs_dicdata.h"

using namespace IMIX;
using namespace IMIX20;
using namespace xapi;

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT OnAPIInterfaceStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq
)
{
    BEGIN_FUNCTION("OnAPIInterfaceStart");
    ResCodeT  rc = NO_ERR;

    QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    std::string strQueryType = message.GetQueryType();
    int nQuryType = atoi(strQueryType.c_str());         // ��Ϣ����
    switch (nQuryType)
    {
    case CRDT_UPD_REQ:  // �����޸�
        {
            vector<xapi::CreditLimitUpdateRequest> vectMsg;
            AnalyzeCreditUpdateMessage(message, vectMsg);
            // ����ֻ��һ�α���
            for (int nIndex = 0; nIndex < vectMsg.size(); ++nIndex) {
                OnApiCreditUpdateStart(vectMsg[nIndex], pReq);
//                OnApiCreditUnlockStart(vectMsg[nIndex], pReq);
            }
        }
        break;
    case RISK_UPD_REQ:      // ����ϵ���޸�
        {
            vector<xapi::RiskLimitUpdateRequest> vectMsg;
            AnalyzeRiskUpdateMessage(message, vectMsg);
            for (int nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
            {
                OnApiRiskUpdateStart(vectMsg[nIndex], pReq);
                //OnApiRiskUnlockStart(vectMsg[nIndex], pParamList);
            }

        }
        break;
    case TOKEN_REQ:     // ��¼
        {
            rc = OnApiLoginStart(inMessage, pReq);
        }
        break;

    case LOGOUT_REQ:        // �ǳ�
        {
            rc = OnApiLogoutStart(inMessage, pReq);
        }
        break;
    case ORG_SUB_REQ:
        {
            rc = OnApiSubscribeStart(inMessage, pReq);
        }
        break;
    case ORG_SUB_CLEAR_REQ:
        {
            rc = OnApiUnSubscribeAllStart(inMessage, pReq);
        }
        break;
    case ORDER_SUBMIT_REQ:
        {
            //�����ύ
            rc = OnApiOrdSubmitProcessStart(inMessage, pReq);
        }
        break;
    case ORDER_CANCEL_REQ:
        {
            //��������
            rc = OnApiOrdCancelProcessStart(inMessage, pReq);
        }
        break;
    default:
        break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// ����Mass��Ϣ
ResCodeT AnalyzeCreditUpdateMessage(
    IMIX20::QueryResult inMsg,
    vector<xapi::CreditLimitUpdateRequest>& vectSubMsg
)
{
    BEGIN_FUNCTION("AnalyzeCreditUpdateMessage");
    ResCodeT  rc = NO_ERR;
    int nMassSize;

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp = inMsg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp) {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        if (nMassSize < 1) {
            return APP_CODE_INCOM_PARAM_ERROR;
        }

        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nMassSize + IMIX_GRP_INDEX_BEGIN; ++nIndex) {
            MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(nIndex);
            if (NULL != pNoMassMessage) {
                xapi::CreditLimitUpdateRequest creditUpate;
                int len = pNoMassMessage->GetMessageLen();
                char *out = new char[len / 2 + 1];
                size_t nLen;
                char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
                p[nLen] = 0;
                creditUpate.ParseFromArray(p, nLen);
                delete[] out;
                out = NULL;

                vectSubMsg.push_back(creditUpate);
            }
            else {
                return APP_CODE_INCOM_PARAM_ERROR;
            }
        }
    }
    else {
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// ���Ÿ���
ResCodeT OnApiCreditUpdateStart(
    const xapi::CreditLimitUpdateRequest& inMessage,
    IntrnlMsgT* pReq
)
{
    BEGIN_FUNCTION("OnApiCreditUpdateStart");
    ResCodeT  rc = NO_ERR;
    int32 nIndex = 0;

    ApiCreditUpdateReqT *pApiCreditUpdateMsg = NULL;
    pApiCreditUpdateMsg = (ApiCreditUpdateReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(ApiCreditUpdateReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_CREDIT_UPDATE;

    User user = inMessage.user();
    //�����û�ID
    IRS_STRING strSenderUserId = user.user_id();
    //Token
    IRS_STRING strToken = user.token();
    //���𷽻�����ʶ
    IRS_STRING strSenderOrgId = user.org_id();

    //ִ�з�������ʶ���û���ʶ
    IRS_STRING strExecOrgId = inMessage.exec_org_id();
    IRS_STRING strExecUserId = inMessage.exec_user_id();
    IRS_STRING strMarketId = inMessage.market_id();

    //���ŷ�ʽ
    int nCrdtMethod = inMessage.risk_limit_update_method();

    IRS_STRING strCrdtMethod = "";
    if (1 == nCrdtMethod) {
        strCrdtMethod = "1";
    }
    else if (2 == nCrdtMethod) {
        strCrdtMethod = "0";
    }
    else {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%d: risk_limit_update_method is invalid.", FUNC_ID_CREDIT_UPDATE_API);
    }

    // ������Ϣ��ӡ��־��ӡ
    LOG_INFO("In condition: strSenderUserId = %s, strSenderOrgId = %s, strExecUserId = %s, strToken = %s, strExecOrgId = %s, strMarketId = %s, strCrdtMethod = %s",
        strSenderUserId.c_str(), strSenderOrgId.c_str(), strExecUserId.c_str(), strToken.c_str(), strExecOrgId.c_str(), strMarketId.c_str(), strCrdtMethod.c_str());

    // SP���
    pApiCreditUpdateMsg->iFuncId = FUNC_ID_CREDIT_UPDATE_API;                       // ���ܱ�ʶ
    strcpy(pApiCreditUpdateMsg->strUsrIdHeader, strSenderUserId.c_str());           // �����û�ID��ʶ
    strcpy(pApiCreditUpdateMsg->strOrgIdHeader, strSenderOrgId.c_str());            // ���𷽻���
    strcpy(pApiCreditUpdateMsg->strUserId,      strExecUserId.c_str());             // �û���ʶ
    strcpy(pApiCreditUpdateMsg->strOrgId,       strExecOrgId.c_str());              // ���Ż�����ʶ
    strcpy(pApiCreditUpdateMsg->strToken,       strToken.c_str());                  // Token
    strcpy(pApiCreditUpdateMsg->strMarketId,    strMarketId.c_str());               // X-Swap
    pApiCreditUpdateMsg->iCrdtMthd = atoi(strCrdtMethod.c_str());                   // ���ŷ�ʽ

    int crdtsSize = inMessage.credits_size();
    for (int i = 0; i < crdtsSize; i++, nIndex++) {
        CreditLimit credits = inMessage.credits(i);

        //�����Ż�����ʶ
        IRS_STRING strCrdtOrgId = credits.opponent_org_id();
        //��ʼ���Ŷ��
        IRS_STRING strAmt = credits.risk_limit_amount();
        //�����
        IRS_STRING strTmpTerm = credits.risk_term();
        IRS_STRING strCrdtTerm = "0";
        GetCrdtTerm(strTmpTerm, strCrdtTerm);
        //���Ź�ϵ��ʶ
        int nCrdtRelationId = credits.has_relation();

        IRS_STRING strCrdtRelationId = "";
        if (1 == nCrdtRelationId) {
            strCrdtRelationId = "1";
        }
        else if (2 == nCrdtRelationId) {
            strCrdtRelationId = "0";
        }
        else {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%d: has_relation is invalid.", FUNC_ID_CREDIT_UPDATE_API);
        }

        // ������Ϣ��ӡ��־��ӡ
        LOG_INFO("In condition: strCrdtOrgId = %s, strAmt = %s, strCrdtTerm = %s, strCrdtRelationId = %s",
            strCrdtOrgId.c_str(), strAmt.c_str(), strCrdtTerm.c_str(), strCrdtRelationId.c_str());

        pApiCreditUpdateMsg->iCrdtedOrgIdLst[nIndex] = atoi(strCrdtOrgId.c_str());    // �����Ż�����ʶ
        pApiCreditUpdateMsg->iIntlCrdtAmntLst[nIndex] = StringToInt64(strAmt.c_str()); // ��ʼ���Ŷ��
        pApiCreditUpdateMsg->iCrdtTermLst[nIndex] = atoi(strCrdtTerm.c_str());        // �����
        pApiCreditUpdateMsg->iCrdtRlfLst[nIndex] = atoi(strCrdtRelationId.c_str());   // ���Ź�ϵ��ʶ
        pApiCreditUpdateMsg->iCrdtCount++;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnApiCreditUpdateStop(
    IntrnlMsgT* pRsp,
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag
)
{
    BEGIN_FUNCTION("OnApiCreditUpdateStop");
    ResCodeT  rc = NO_ERR;

    /*---------------------------------------
    **********  ��ʱ���� ***************
    ----------------------------------------*/
    ApiCreditUpdateRespT* pApiCreditUpdateResp;
    int32 applRefSeqNum;
    IRS_STRING strQryType;

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg  = "";
    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/
    // ����Ӧ����Ϣ
    IMIX20::QueryResult* pRspMessage = new QueryResult;
    if (NULL == pRspMessage) {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pRspMessage is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    IntToString(CRDT_UPD_RSP,strQryType);
    pRspMessage->SetQueryType(strQryType);

    if (NO_ERR != nExceptionFlag) {
        rc = ResponeExceptionMsg(pSendMsgList, pRspMessage, nExceptionFlag);
        RAISE_ERR(rc, RTN);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    pApiCreditUpdateResp = (ApiCreditUpdateRespT*)pRsp->msgBody;
//    rc = API_SendLoginRspMsgToApi(pRspMessage, pLoginResp, pSendMsgList);
    RAISE_ERR(rc, RTN);

/*
    if (APP_CODE_SUCCESS != API_SendCrdtRspMsgToApi(pSendMsgList, inMessage, pRspMessage, oRetUnlockParam, nErrCodeTrue)) {
        delete pRspMessage;
        pRspMessage = NULL;
    }

    // ������������Ϣ
    if (SP_RET_SUCCESS == oRetUnlockParam.m_nErrorCode &&
        SP_RET_SUCCESS == oRetParam.m_nErrorCode) {
        int nOutBoundId = oRetUnlockParam.m_nOutBoundId;
        SendFreezeStatusNotifyMsgToTrader(RDP_COMPID, oRetParamRst.m_vecFreezeInfo, pSendMsgList);

        SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, pSendMsgList);
        SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SBF_vecOrders, pSendMsgList);

        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SBF_vecOrders, nOutBoundId, pSendMsgList, pParamList);

        //SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        //���Ÿ���֪ͨ��ǰ̨�û�
//        SendCreditUpdReportMsgToTrader(RDP_COMPID, oRetParamRst.m_vecFreezeInfo, pSendMsgList);
        //���Ÿ���֪ͨ��Ϣ��TDPS
        SendCreditUpdReportMsgToTDPS(oRetParamRst.m_vecCredit, oRetUnlockParam.m_sCreditMethd, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
    }
*/

    EXIT_BLOCK();
    RETURN_RESCODE;
}


// ����Mass��Ϣ
ResCodeT AnalyzeRiskUpdateMessage(
    IMIX20::QueryResult inMsg,
        vector<xapi::RiskLimitUpdateRequest>& vectSubMsg
)
{
    BEGIN_FUNCTION("AnalyzeRiskUpdateMessage");
    ResCodeT  rc = NO_ERR;
    int nMassSize;

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp = inMsg.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        if (nMassSize < 1)
        {
            return APP_CODE_INCOM_PARAM_ERROR;
        }

        for (int nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nMassSize + IMIX_GRP_INDEX_BEGIN; ++nIndex)
        {
            MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(nIndex);
            if (NULL != pNoMassMessage)
            {
                xapi::RiskLimitUpdateRequest creditUpate;
                    int len = pNoMassMessage->GetMessageLen();
                    char *out = new char[len / 2 + 1];
                    size_t nLen;
                    char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
                    p[nLen] = 0;
                    creditUpate.ParseFromArray(p, nLen);
                delete[] out;
                out = NULL;

                vectSubMsg.push_back(creditUpate);
            }
            else
            {
                return APP_CODE_INCOM_PARAM_ERROR;
            }
        }
    }
    else
    {
        return APP_CODE_INCOM_PARAM_ERROR;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// ���ո���
// ���ո���
ResCodeT OnApiRiskUpdateStart( const xapi::RiskLimitUpdateRequest& inMessage,IntrnlMsgT* pReq )
{
    BEGIN_FUNCTION("OnApiRiskUpdateStart");
    ResCodeT  rc = NO_ERR;
    int32 nIndex = 0;
    RiskInfoReqT *pRiskInfoMsg = NULL;
    pRiskInfoMsg = (RiskInfoReqT*)&pReq->msgBody[0];
    pReq->msgHdr.msgLen = sizeof(RiskInfoReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_RISK_UPDATE;

    User user = inMessage.user();
    //�����û�ID
    IRS_STRING strSenderUserId = user.user_id();
    //Token
    IRS_STRING strToken = user.token();
    //���𷽻�����ʶ
    IRS_STRING strSenderOrgId = user.org_id();

    //ִ�з�������ʶ���û���ʶ
    IRS_STRING strExecOrgId = inMessage.exec_org_id();
    IRS_STRING strExecUserId = inMessage.exec_user_id();
    IRS_STRING strSecuriType = inMessage.inst_scope_security_type();

    // ������Ϣ��ӡ��־��ӡ
    LOG_INFO("In condition: strSenderUserId = %s, strSenderOrgId = %s, strExecUserId = %s, strToken = %s, strExecOrgId = %s, inMessage.market_indicator() = %d ",
        strSenderUserId.c_str(), strSenderOrgId.c_str(), strExecUserId.c_str(), strToken.c_str(), strExecOrgId.c_str(), inMessage.market_indicator());

    // ���
    pRiskInfoMsg->iFuncId = FUNC_ID_RISK_UPDATE_API;                         // ���ܱ�ʶ
    strcpy(pRiskInfoMsg->strUsrIdHeader, strSenderUserId.c_str());           // �����û�ID��ʶ
    strcpy(pRiskInfoMsg->strOrgIdHeader, strSenderOrgId.c_str());            // ���𷽻���
    strcpy(pRiskInfoMsg->strUserId,      strExecUserId.c_str());             // �û���ʶ
    strcpy(pRiskInfoMsg->strToken,       strToken.c_str());                  // Token
    strcpy(pRiskInfoMsg->strOrgId,       strExecOrgId.c_str());              // ���Ż�����ʶ
    pRiskInfoMsg->iMarketId = inMessage.market_indicator();                  // X-Swap
    strcpy(pRiskInfoMsg->strSecuriType,  strSecuriType.c_str());             // IRS/SIRS/SBFWD
    pRiskInfoMsg->iCleaningMthd = inMessage.clearingmethod();                // 13
    int nRiskLimitsSize = inMessage.risk_limits_size();
    for (int i = 0; i < nRiskLimitsSize; i++, nIndex++) {
        RiskLimit riskLimits = inMessage.risk_limits(i);
            IRS_STRING strCntrctNm = riskLimits.security_id();
            //����ϵ��
            IRS_STRING strRiskCofCnt = riskLimits.risk_inst_multiplier();

        // ������Ϣ��ӡ��־��ӡ
        LOG_INFO("In condition: strContractNm = %s, strRiskCofCnt = %s",
            strCntrctNm.c_str(), strRiskCofCnt.c_str());
        strcpy(pRiskInfoMsg->riskCfcnt[nIndex].strCntrctNm,  strCntrctNm.c_str()); // ��Լ��
        pRiskInfoMsg->riskCfcnt[nIndex].intRiskCfcnt = atoi(strRiskCofCnt.c_str());   // ����ϵ��
    }
    pRiskInfoMsg->iRiskCount = nIndex;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnApiRiskUpdateStop(
    IntrnlMsgT* pRsp,
    SENDMSGLIST* pSendMsgList,
    int nExceptionFlag
)
{
    BEGIN_FUNCTION("OnApiRiskUpdateStop");
    ResCodeT  rc = NO_ERR;

    /*---------------------------------------
    **********  ��ʱ���� ***************
    ----------------------------------------*/
    RiskInfoRespT*  pRiskCoefStop;
    int32 applRefSeqNum;
    IRS_STRING strQryType;

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg  = "";
    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/
    // ����Ӧ����Ϣ
    IMIX20::QueryResult* pRspMessage = new QueryResult;
    if (NULL == pRspMessage) {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "pRspMessage is null.");
        return APP_CODE_INCOM_PARAM_ERROR;
    }
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    IntToString(CRDT_UPD_RSP,strQryType);
    pRspMessage->SetQueryType(strQryType);

    if (NO_ERR != nExceptionFlag) {
        rc = ResponeExceptionMsg(pSendMsgList, pRspMessage, nExceptionFlag);
        RAISE_ERR(rc, RTN);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    pRiskCoefStop = (RiskInfoRespT*)pRsp->msgBody;
    rc = SendMessage(pSendMsgList, pRspMessage);
    RAISE_ERR(rc, RTN);

    if (NO_ERR == nExceptionFlag)
    {
        pRiskCoefStop = (RiskInfoRespT*)pRsp->msgBody;
        rc = SendFreezeStatusNotifyMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(),
            pRiskCoefStop , pSendMsgList);
        RAISE_ERR(rc, RTN);
    }
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/*****************************************************************************
 **
 ** The following API interfaces are added by xiejiawang.
 **
 *****************************************************************************/


// Api�û���¼
ResCodeT OnApiLoginStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiLoginStart");
    ResCodeT        rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiLoginStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());


    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;
    // functionid
    std::string strFuncId = "";

    // �û�ID
    std::string strUserId = "";

    IRS_STRING strUserId_Check = "";

    // ��ԱΨһ���
    std::string strOrgCd = "";

    IRS_STRING strUserSt = "";
    int nUserSt = 0;
    std::string strRequestId = "";

    IntToString(FUNC_ID_API_LOGIN, strFuncId);


    QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            TokenRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            strRequestId = partyUpdate.request_id();

            nUserSt = partyUpdate.user_status();
            IntToString(nUserSt, strUserSt);
            strUserId = partyUpdate.user_name();

            User user = partyUpdate.user();
            strUserId_Check = user.user_id();
            strOrgCd = user.org_id();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }
    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%d] In condition: strFuncId = %s, strUserId_Check = %s, strUserId = %s, strOrgCd = %s, strUserSt = %s",
                FUNC_ID_API_LOGIN, strFuncId.c_str(), strUserId_Check.c_str(), strUserId.c_str(), strOrgCd.c_str(), strUserSt.c_str());


    ApiLoginReqT*   pApiReq;
    pApiReq = (ApiLoginReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(ApiLoginReqT));
    pReq->msgHdr.msgLen = sizeof(ApiLoginReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_LOGIN;

    pApiReq->iFuncId = FUNC_ID_API_LOGIN;
    strcpy(pApiReq->strInitUserId, strUserId_Check.c_str() );
    strcpy(pApiReq->strUserId, strUserId.c_str() );
    strcpy(pApiReq->strOrgCd, strOrgCd.c_str() );
    strcpy(pApiReq->strRequestId, strRequestId.c_str());
    pApiReq->iLoginType = nUserSt;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnApiLoginStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiLoginStop");
    ResCodeT            rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiLoginStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    ApiLoginRespT*      pLoginResp;
    pLoginResp = (ApiLoginRespT*)pRsp->msgBody;

    IRS_STRING          strErrCode = "";
    IRS_STRING          strErrMsg = "";

    IMIX20::QueryResult* pRspMessage = new IMIX20::QueryResult;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    //���ͷ�����Ϣ�������г�״̬��Ϣ
    rc = API_SendLoginRspMsgToApi(pRspMessage, pLoginResp, pSendMsgList, nExceptionFlag);
    RAISE_ERR(rc, RTN);

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        int nOutBoundId = pLoginResp->iMaxOutboundId;
        //API_SendKickUserMsgToTDPS(pSendMsgList, inMessage, oRetParam, nOutBoundId, pParamList);   //ǿ��ͬ��������API�û�
/*
        if (oRetParam.m_nUserRole == E_USER_ROLE_API_HQ)
        {
            //API�û�����Ȩ�޽�ɫ
            API_SendSubscribeClsMsgToTDPS(CLEAR_SUBSCRIBE_ONE ,nOutBoundId, pSendMsgList, pParamList,strUserId,strOrgCd);
        }

        SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, pSendMsgList);
        //SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        //SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID, oRetParamRst, nOutBoundId, pSendMsgList, pParamList,inMessage);

        CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        //CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        //SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
*/
    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}


// Api�û��ǳ�
ResCodeT OnApiLogoutStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiLogoutStart");
    ResCodeT        rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiLogoutStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());


    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;
    //
    std::string strFuncId = "";

    // �û�ID
    std::string strUserId = "";

    // ����CD 21λ����
    std::string strOrgCd = "";

    // token
    std::string strToken = "";

    std::string strRequestId = "";

    int nUserSt = 2;
    IRS_STRING strUserSt = "";
    IntToString(nUserSt, strUserSt);

    IntToString(FUNC_ID_API_LOGOUT, strFuncId);


    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            LogoutRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            strRequestId = partyUpdate.request_id();

            strUserId = partyUpdate.user_name();
            User user = partyUpdate.user();
            strToken = user.token();
//          strUserId = user.user_id();
            strOrgCd = user.org_id();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%d] In condition: strUserId = %s, strOrgCd = %s, strToken = %s",
                FUNC_ID_API_LOGOUT, strUserId.c_str(), strOrgCd.c_str(), strToken.c_str());


    ApiLogoutReqT*  pApiReq;
    pApiReq = (ApiLogoutReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(ApiLogoutReqT));
    pReq->msgHdr.msgLen = sizeof(ApiLogoutReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_LOGOUT;

    pApiReq->iFuncId = FUNC_ID_API_LOGOUT;
    strcpy(pApiReq->strUserId, strUserId.c_str());
    strcpy(pApiReq->strOrgCd, strOrgCd.c_str());
    strcpy(pApiReq->strToken, strToken.c_str());
    strcpy(pApiReq->strRequestId, strRequestId.c_str());
    pApiReq->iLoginType = nUserSt;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnApiLogoutStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiLogoutStop");
    ResCodeT            rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiLogoutStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IRS_STRING          strErrCode = "";
    IRS_STRING          strErrMsg = "";

    std::string strQryType;

    IMIX20::QueryResult* pRspMessage = new IMIX20::QueryResult;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);

    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    IntToString(LOGOUT_RSP,strQryType);
    pRspMessage->SetQueryType(strQryType);

    if (NO_ERR != nExceptionFlag)
    {
        LOG_ERROR(APP_CODE_UNKNOW_EXCEPTION, APP_MSG_UNKNOW_EXCEPTION);
    }

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    ApiLogoutRespT*     pLogoutResp;
    pLogoutResp = (ApiLogoutRespT*)pRsp->msgBody;

    //���ͷ�����Ϣ�������г�״̬��Ϣ
    rc = API_SendLogoutRspMsgToApi(pRspMessage, pLogoutResp, pSendMsgList);
    if (NO_ERR != rc)
    {
        delete pRspMessage;
        pRspMessage = NULL;
    }
    RAISE_ERR(rc, RTN);

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        int nOutBoundId = pLogoutResp->iMaxOutboundId;

/*
        if (pLogoutResp->iUserRole == E_USER_ROLE_API_HQ)
        {
            //API�û�����Ȩ�޽�ɫ
            API_SendSubscribeClsMsgToTDPS(CLEAR_SUBSCRIBE_ONE ,nOutBoundId, pSendMsgList, pParamList,strUserId,strOrgCd);
        }
        SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, pSendMsgList);
        //SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);    //�û��ǳ�����Ҳûɶ��

        SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        //SIRS_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
        //CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(TDPS_COMPID,oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);
        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
*/
    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}


//API����
ResCodeT OnApiSubscribeStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiSubscribeStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiSubscribeStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    //
    std::string strFuncId = "";

    // �û�ID
    std::string strUserId = "";

    // ����CD 21λ����
    std::string strOrgCd = "";

    // token
    std::string strToken = "";

    IRS_STRING strReqId = "";
    int nMktIndicator = 0;
    IRS_STRING strMktIndicator = "";
    IRS_STRING strInstSecurityTy = "";
    int nClearMethod ;
    IRS_STRING strClearingMethod = "";
    int nSubTy = 0; //���ı�ʶ
    IRS_STRING strSubTyp = "";
    IRS_STRING strExecUserId = "";
    IRS_STRING strExecOrgId = "";
    IRS_STRING strSecurityId = "-";//��ԼƷ��
    int nMdBookTy = -1;//��������
    IRS_STRING strMdBookTy = "";
    int nMktDepth = -1; //��λ���鵵��
    IRS_STRING strMktDepth = "";
    IRS_STRING strTm = "";

    IntToString(FUNC_ID_API_SUBSCRIBE, strFuncId);

    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            SubscribeRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            User user = partyUpdate.user();
            strToken = user.token();
            strUserId = user.user_id();
            strOrgCd = user.org_id();

            strReqId = partyUpdate.sub_req_id();
            nMktIndicator = partyUpdate.market_indicator();
            IntToString(nMktIndicator, strMktIndicator);
            if (partyUpdate.has_inst_scope_security_type())
            {
                strInstSecurityTy = partyUpdate.inst_scope_security_type();
            }
            if (partyUpdate.has_clearingmethod())
            {
                nClearMethod = partyUpdate.clearingmethod();
                IntToString(nClearMethod, strClearingMethod);
            }

            nSubTy = partyUpdate.subtype();
            IntToString(nSubTy, strSubTyp);
            strExecUserId = partyUpdate.exec_user_id();
            strExecOrgId = partyUpdate.exec_org_id();
            if (partyUpdate.has_securityid())
            {
                strSecurityId = partyUpdate.securityid();
            }

            nMdBookTy = partyUpdate.mdbooktype();
            IntToString(nMdBookTy, strMdBookTy);
            if (partyUpdate.has_marketdepth())
            {
                nMktDepth = partyUpdate.marketdepth();
                IntToString(nMktDepth, strMktDepth);
            }

            strTm = partyUpdate.tran_time();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%d] In condition: strFuncId = %s, strReqId = %s, strUserId = %s, strOrgCd = %s, strExecUserId = %s, \
                strToken = %s, strExecOrgId = %s, strSubTyp = %s, strMdBookTy = %s, strMktDepth = %s, strMktIndicator = %s \
                strInstSecurityTy = %s, strClearingMethod = %s,strSecurityId = %s, strTm = %s",
                FUNC_ID_API_SUBSCRIBE, strFuncId.c_str(), strReqId.c_str(), strUserId.c_str(), strOrgCd.c_str(), strExecUserId.c_str(),
                strToken.c_str(), strExecOrgId.c_str(), strSubTyp.c_str(), strMdBookTy.c_str(), strMktDepth.c_str(), strMktIndicator.c_str(),
                strInstSecurityTy.c_str(), strClearingMethod.c_str(),strSecurityId.c_str(), strTm.c_str());


    // SP���
    ApiSubscribeReqT* pApiReq;
    pApiReq = (ApiSubscribeReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(ApiSubscribeReqT));
    pReq->msgHdr.msgLen = sizeof(ApiSubscribeReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_SUBSCRIBE;

    pApiReq->iFuncId = FUNC_ID_API_SUBSCRIBE;
    pApiReq->iReqId = atoi(strReqId.c_str());
    strcpy(pApiReq->strUsrIdHeader, strUserId.c_str());
    strcpy(pApiReq->strOrgCdHeader, strOrgCd.c_str());
    strcpy(pApiReq->strUsrId, strExecUserId.c_str());
    strcpy(pApiReq->strToken, strToken.c_str());
    strcpy(pApiReq->strOrgCd, strExecOrgId.c_str());
    pApiReq->iRequestType = atoi(strSubTyp.c_str());
    pApiReq->iMdBookType = atoi(strMdBookTy.c_str());
    pApiReq->iMarketDepth = atoi(strMktDepth.c_str());
    pApiReq->iMarketIndic = atoi(strMktIndicator.c_str());
    strcpy(pApiReq->strSecurityTp, strInstSecurityTy.c_str());
    strcpy(pApiReq->strCleaningMthd, strClearingMethod.c_str());
    strcpy(pApiReq->strCntRctCd, strSecurityId.c_str());
    strcpy(pApiReq->strTimeStamp, strTm.c_str());

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;

}

ResCodeT OnApiSubscribeStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiSubscribeStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiSubscribeStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";
    int32 nApplSeqNum = 0;

    std::string strQryType;


    // ����Ӧ����Ϣ
    IMIX20::QueryResult* pRspMessage = new IMIX20::QueryResult;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &nApplSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(nApplSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    IntToString(ORG_SUB_RSP, strQryType);
    pRspMessage->SetQueryType(strQryType);


    ApiSubscribeRespT* pApiResp;
    pApiResp = (ApiSubscribeRespT*)pRsp->msgBody;

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);
    rc = API_SendSubcribeRspMsgToApi(pRspMessage, pApiResp, pSendMsgList);
    if (NO_ERR == rc)
    {
        delete pRspMessage;
        pRspMessage = NULL;
    }
    RAISE_ERR(rc, RTN);


    if (NO_ERR == nExceptionFlag)
    {
        int nOutBoundId = pApiResp->iMaxOutboundId;
#if 0
        //���Ͷ�����Ϣ��TDPS
        IMIX20::MarketDataRequest *pSubscribeMsg = new IMIX20::MarketDataRequest;
        if (NULL == pSubscribeMsg)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pSubscribeMsg is null.", sFunction.c_str());
            return APP_CODE_INCOM_PARAM_ERROR;
        }

        pSubscribeMsg->SetApplSeqNum(nOutBoundId++);
        pSubscribeMsg->GetHeader()->SetTargetCompID(TDPS_COMPID);

        pSubscribeMsg->SetMDReqID(strReqId);
        pSubscribeMsg->SetApplToken(strToken);
        char c;
        StringToChar(strSubTyp, c);
        pSubscribeMsg->SetSubscriptionRequestType(c);
        pSubscribeMsg->SetMDBookType(nMdBookTy);
        pSubscribeMsg->SetMarketDepth(nMktDepth);
        //pSubscribeMsg->SetTransactTime(strTm);
        //pSubscribeMsg->SetClearingMethod(nClearMethod);
        InstrmtMDReqGrp *pInstrmtMDReqGrp = pSubscribeMsg->GetInstrmtMDReqGrp();
        if (pInstrmtMDReqGrp)
        {
            InstrmtMDReqGrp::NoRelatedSym *pNoRelatedSym = pInstrmtMDReqGrp->AddNoRelatedSym();
            if (pNoRelatedSym)
            {
                Instrument *pInstrment = pNoRelatedSym->GetInstrument();
                if (pInstrment)
                {
                    pInstrment->SetSecurityID(strSecurityId);
                    //pInstrment->SetMarketIndicator(nMktIndicator);
                    pInstrment->SetSecurityType(strInstSecurityTy);
                }
            }
        }

        Parties *pParties = pSubscribeMsg->GetParties();
        if (pParties)
        {
            Parties::NoPartyIDs *pNoPartyIds = pParties->AddNoPartyIDs();
            if (pNoPartyIds)
            {
                pNoPartyIds->SetPartyRole(1);
                pNoPartyIds->SetPartyID(strOrgCd);
            }

            IMIX20::PtysSubGrp *pPtysSubGrp = pNoPartyIds->GetPtysSubGrp();
            if (pPtysSubGrp)
            {
                PtysSubGrp::NoPartySubIDs *pNoPartySubIds = pPtysSubGrp->AddNoPartySubIDs();
                if (pNoPartySubIds)
                {
                    pNoPartySubIds->SetPartySubIDType(2);
                    pNoPartySubIds->SetPartySubID(strUserId);
                }
            }
        }
#endif
        IMIX20::QueryResult* pSubscribeMsg = new IMIX20::QueryResult;
        if (pSubscribeMsg == NULL)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pSubscribeMsg is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        pSubscribeMsg->SetApplSeqNum(nOutBoundId++);
        pSubscribeMsg->GetHeader()->SetTargetCompID(TDPS_COMPID);
        std::string strQryType;
        IntToString(ORG_SUB_REQ,strQryType);
        pSubscribeMsg->SetQueryType(strQryType);

        MassMessageGrp::NoMassMessage *pNoMassMsg = pSubscribeMsg->GetMassMessageGrp()->AddNoMassMessage();
        if (pNoMassMsg == NULL)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s pNoMassMsg is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        IRS_STRING strOrgId = "";
        IntToString(pApiResp->iOrgId, strOrgId);
        SubscribeRequest partyUpdate;
        partyUpdate.set_exec_org_id(strOrgId);

        int len = partyUpdate.ByteSize();
        char *buf = new char[len];
        partyUpdate.SerializeToArray(buf, len);
        char *out = new char[len * 2 + 1];
        size_t olen;
        char *p = ArraytoHex(buf, len, out, &olen);
        p[olen] = 0;
        pNoMassMsg->SetMessageData(p, olen);
        pNoMassMsg->SetMessageLen(olen);
        delete[] buf;
        buf = NULL;
        delete[] out;
        out = NULL;

        string debugString = partyUpdate.DebugString();
        replace(debugString.begin(), debugString.end(), '\n', ' ');
        LOG_DEBUG("API partyUpdate Msg[%s]", debugString.c_str());

        if (NO_ERR == SendMessage(pSendMsgList, pSubscribeMsg))
        {
//            OutBoundMsg(pSubscribeMsg->GetApplSeqNum(), static_cast<IMIX::BasicMessage*>(pSubscribeMsg), pParamList);
        }
    }


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}


//APIȡ�����ж���
ResCodeT OnApiUnSubscribeAllStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiUnSubscribeAllStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiUnSubscribeAllStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IRS_STRING strSubTyp = "";

    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            SubscribeClearRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;


            int nSubType = partyUpdate.subtype();
            IntToString(nSubType, strSubTyp);
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    LOG_INFO("[%d] In condition: strSubTyp = %s",
                FUNC_ID_API_UNSUBSCRIBE_ALL, strSubTyp.c_str());

    //SP ���
    ApiUnSubscribeAllReqT* pApiReq;
    pApiReq = (ApiUnSubscribeAllReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(ApiUnSubscribeAllReqT));
    pReq->msgHdr.msgLen = sizeof(ApiUnSubscribeAllReqT);
    pReq->msgHdr.msgType = MSG_TYPE_API_UNSUBSCRIBE_ALL;

    pApiReq->iUnSubId = atoi(strSubTyp.c_str());

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnApiUnSubscribeAllStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiUnSubscribeAllStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiUnSubscribeAllStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    /*---------------------------------------
    ************ Ӧ����Ϣ��ʼ�� ************
    ---------------------------------------*/

    //���ִ��SP����ʧ��
    if (NO_ERR != nExceptionFlag)
    {
        LOG_ERROR(APP_CODE_UNKNOW_EXCEPTION, APP_MSG_UNKNOW_EXCEPTION);
    }


    NewOrderSingleRspT* pApiResp;
    pApiResp = (NewOrderSingleRspT*)pRsp->msgBody;


    if (NO_ERR == nExceptionFlag)
    {
//        int nOutBoundId = pApiResp->iMaxOutboundId;

        // �������������Ϣ��TDPS
//        API_SendSubscribeClsMsgToTDPS(CLEAR_SUBSCRIBE_ALL ,nOutBoundId, pSendMsgList, pParamList);

        //���API��Ϣ�����ý�������Ϣ����API�û�
        //SendOrderStatusUpdateMsgToTrader(RDP_COMPID, pApiResp->rspOrder, pApiResp->rspOrderCnt, pSendMsgList);
        SendOrdrDealStsUpdtMsgToTrdr(RDP_COMPID, pApiResp->rspSlot, pApiResp->slotCnt, pSendMsgList);
/*
        SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_SIRS_vecOrders, pSendMsgList);
        CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecSBFCCPOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);

        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_SIRS_vecOrders, nOutBoundId, pSendMsgList, pParamList);
        SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecSBFCCPOrders, nOutBoundId, pSendMsgList, pParamList);

        SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

        SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
*/
    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//API�����ɽ������
ResCodeT OnApiOrdSubmitProcessStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiOrdSubmitProcessStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiOrdSubmitProcessStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    int nMarketindicator;//���ڹ���

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            OrderSubmitRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            nMarketindicator = partyUpdate.marketindicator();

            switch(nMarketindicator)
            {
            case IMIX_MKT_TYPE_IRS:
                {
                    pReq->msgHdr.setId = SET_MKT_IRS;
                    rc = OnApiOrdSubmitStart(inMessage, pReq, FUNC_ID_API_ORD_SUBMIT);
                }
                break;
            case IMIX_MKT_TYPE_SIRS:
                {
                    pReq->msgHdr.setId = SET_MKT_SIRS;
                    rc = OnApiOrdSubmitStart(inMessage, pReq, FUNC_ID_SIRSAPI_ORD_SUBMIT);
//                    rc = OnSirsApiOrdSubmitStart(inMessage, pReq);
                }
                break;
            //case IMIX_MKT_TYPE_SBFCCP:
            default:
                {
                    pReq->msgHdr.setId = SET_MKT_SBFCCP;
                    rc = OnApiOrdSubmitStart(inMessage, pReq, FUNC_ID_SBFCCPAPI_ORD_SUBMIT);
//                    rc = OnSbfccpApiOrdSubmitStart(inMessage, pReq);
                }
                break;
            }
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//API�������������
ResCodeT OnApiOrdCancelProcessStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnApiOrdCancelProcessStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiOrdCancelProcessStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    int nMarketindicator = 0;//���ڹ���

    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            xapi::OrderCancelRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            nMarketindicator = partyUpdate.marketindicator();

            switch(nMarketindicator)
            {
            case IMIX_MKT_TYPE_IRS:
                {
                    pReq->msgHdr.setId = SET_MKT_IRS;
                    rc = OnApiOrdCancelStart(inMessage, pReq, MSG_TYPE_API_ORD_CANCEL);
                }
                break;
            case IMIX_MKT_TYPE_SIRS:
                {
                    pReq->msgHdr.setId = SET_MKT_SIRS;
                    rc = OnApiOrdCancelStart(inMessage, pReq, MSG_TYPE_SIRS_API_ORD_CANCEL);
//                    rc = OnSirsApiOrdCancelStart(inMessage, pReq);
                }
                break;
                //case IMIX_MKT_TYPE_SBFCCP:
            default:
                {
                    pReq->msgHdr.setId = SET_MKT_SBFCCP;
                    rc = OnApiOrdCancelStart(inMessage, pReq, MSG_TYPE_SBFCCP_API_ORD_CANCEL);
//                    rc = OnSbfccpApiOrdCancelStart(inMessage, pReq);
                }
                break;
            }

        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

//IRSAPI�����ɽ�
ResCodeT OnApiOrdSubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, int32 funcId)
{
    BEGIN_FUNCTION("OnApiOrdSubmitStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiOrdSubmitStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    //
    std::string strFuncId = "";

    // �û�ID
    std::string strUserId = "";

    // ����CD 21λ����
    std::string strOrgCd = "";
    IRS_STRING strorderreqid="";//���������ο����
    IRS_STRING strsecurity_type = "";
    IRS_STRING strmarketindicator = "";//���ڹ���
    IRS_STRING strClearingMethod = "";
    IRS_STRING strexec_org_id="";//ִ�з�����
    IRS_STRING strExec_User_Name = "";
    IRS_STRING strexec_user_id="";//ִ�з�����
    IRS_STRING strOrderType = "";//��������
    IRS_STRING strTime = "";//��Чʱ��
    IRS_STRING strDir="";//���׷���
    IRS_STRING strinstrument;//��ԼƷ��
    IRS_STRING strprice="";//�۸�
    IRS_STRING strOrderQty="";//������
    // token
    std::string strToken = "";
    IntToString(funcId, strFuncId);

    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            OrderSubmitRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;
            strorderreqid = partyUpdate.order_req_id();
            IntToString(partyUpdate.marketindicator(), strmarketindicator);
            if (partyUpdate.has_inst_scope_security_type())
            {
                strsecurity_type = partyUpdate.inst_scope_security_type();
            }

            if (partyUpdate.has_clearingmethod())
            {
                IntToString(partyUpdate.clearingmethod(), strClearingMethod);
            }

            strexec_user_id = partyUpdate.exec_user_id();
            if (partyUpdate.has_exec_user_name())
            {
                strExec_User_Name = partyUpdate.exec_user_name();
            }
            strexec_org_id = partyUpdate.exec_org_id();
            strinstrument = partyUpdate.securityid();
            strDir = partyUpdate.side();
            strOrderType = partyUpdate.ordertype();
            strTime = partyUpdate.expire_time();
            strprice = partyUpdate.price();
            //DoubleToString2(partyUpdate.price(),strprice);
            IntToString(partyUpdate.orderqty(),strOrderQty);
            User user = partyUpdate.user();
            strUserId = user.user_id();
            strToken = user.token();
            strOrgCd = user.org_id();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    // ������Ϣ��ӡ��־��ӡ
    LOG_INFO("[%d] In condition: strFuncId = %s, strToken = %s, strorderreqid = %s, strUserId = %s, strOrgCd = %s, strexec_user_id = %s, strExec_User_Name = %s, \
                strexec_org_id = %s,  strinstrument = %s, strDir = %s, strprice = %s, strOrderQty = %s, strTime = %s),strOrderType = %s,strmarketindicator = %s,\
                strsecurity_type = %s, strClearingMethod = %s",
                funcId, strFuncId.c_str(), strToken.c_str(), strorderreqid.c_str(), strUserId.c_str(), strOrgCd.c_str(), strexec_user_id.c_str(), strExec_User_Name.c_str(),
                strexec_org_id.c_str(), strinstrument.c_str(), strDir.c_str(), strprice.c_str(), strOrderQty.c_str(),strTime.c_str(),strOrderType.c_str(),strmarketindicator.c_str(),
                strsecurity_type.c_str(), strClearingMethod.c_str());

    // �ж�����Ƿ�Ϊ�գ�IN_DLDIR��IN_ORDRSBMTTP�Ƿ����ö��ֵ
    if (strorderreqid.length() == 0
            || strinstrument.length() == 0
            || strDir.length() == 0
            || strOrderType.length() == 0
            || strprice.length() == 0
            || strOrderQty.length() == 0)
    {
        RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
    }

    if (pReq->msgHdr.setId == SET_MKT_SBFCCP)
    {
        // �ж�����Ƿ�Ϊ��
        if (strUserId.length() == 0
                || strOrgCd.length() == 0
                || strexec_user_id.length() == 0
                || strexec_org_id.length() == 0
                || strToken.length() == 0
                || strmarketindicator.length() == 0
                || (strOrderType == C_API_LMT && strTime.length() == 0))
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }

        // ��֤����Ҫ��ö��ֵ
        // ���ڹ��ߡ��г���ʶ�����㷽ʽ
        if (strmarketindicator != C_API_MKTID_SBF
                || (strsecurity_type.length() > 0 && strsecurity_type != C_API_MKTDESC_SBF)
                || strClearingMethod != C_API_CLEARMTHD_CENTRAL)
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }

        // ���׷��򡢶����ύ����
        if ((strDir != C_API_BID && strDir != C_API_OFFER)
                || (strOrderType != C_API_LMT && strOrderType != C_API_FOK))
        {
            RAISE_ERR(APIERR_CODE_INVLD_PRC, RTN);
        }
    }

    //SP ���
    NewOrderSingleReqT* pApiReq;
    pApiReq = (NewOrderSingleReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(NewOrderSingleReqT));
    pReq->msgHdr.msgLen = sizeof(NewOrderSingleReqT);
    switch (pReq->msgHdr.setId)
    {
        case SET_MKT_IRS:
            pReq->msgHdr.msgType = MSG_TYPE_API_ORD_SUBMIT;
            break;
        case SET_MKT_SIRS:
            pReq->msgHdr.msgType = MSG_TYPE_SIRS_API_ORD_SUBMIT;
            break;
        case SET_MKT_SBFCCP:
        default :
            pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_API_ORD_SUBMIT;
            break;
    }
/*
    pApiReq->iFuncId = FUNC_ID_API_ORD_SUBMIT;
    strcpy(pApiReq->strToken, strToken.c_str());
    strcpy(pApiReq->strReqId, strorderreqid.c_str());
    strcpy(pApiReq->strUsrIdHeader, strUserId.c_str());
    strcpy(pApiReq->strOrgCdHeader, strOrgCd.c_str());
    strcpy(pApiReq->strUsrId, strexec_user_id.c_str());     //?
    strcpy(pApiReq->strUsrNm, strExec_User_Name.c_str());   //?
    strcpy(pApiReq->strOrgCd, strexec_org_id.c_str());      //?
    strcpy(pApiReq->strCntrctNm, strinstrument.c_str());
    strcpy(pApiReq->strDealDir, strDir.c_str());
    strcpy(pApiReq->strOrderPrice, strprice.c_str());
    strcpy(pApiReq->strNtnlAmnt, strOrderQty.c_str());
    strcpy(pApiReq->strOrdrExprdTm, strTime.c_str());
    strcpy(pApiReq->strOrdrSbmtTp, strOrderType.c_str());
    pApiReq->iMarketIndic = atoi(strmarketindicator.c_str());   //?
    strcpy(pApiReq->strSecurityTp, strsecurity_type.c_str());   //?
    strcpy(pApiReq->strCleaningMthd, strClearingMethod.c_str());    //?
*/
    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;
    pCntrctBaseInfoT pCntract;

    strcpy(pApiReq->token, strToken.c_str());
    pApiReq->newOrdrInfo.apiRqstId = atoi(strorderreqid.substr(strorderreqid.length()-8, strorderreqid.length()).c_str());

    //strUsrIdHeader
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pApiUsr);
    RAISE_ERR(rc, RTN);
    pApiReq->newOrdrInfo.apiLoginUsrIdx =  pApiUsr->pos;

    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(pApiUsr->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    pApiReq->newOrdrInfo.orgIdx = pOrgInfo->pos;

    //strUsr
    rc = IrsUsrInfoGetByNameExt((char *)strexec_user_id.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pApiReq->newOrdrInfo.userIdx =  pUsr->pos;

    rc = IrsCntrctInfoGetByNameExt((char *)strinstrument.c_str(), &pCntract);
    RAISE_ERR(rc, RTN);
    pApiReq->newOrdrInfo.contractPos = pCntract->pos;

    rc = SideConvert(strDir[0], &pApiReq->newOrdrInfo.side);
    RAISE_ERR(rc, RTN);

    CnvtPriceToIntnlVal(strprice.c_str(), &pApiReq->newOrdrInfo.prcQtyInfo.price);

    pApiReq->newOrdrInfo.prcQtyInfo.qty = StringToInt64( strOrderQty.c_str() );

    DateTimeToTimestamp((char*)strTime.c_str(), &pApiReq->newOrdrInfo.effectTime);

    pApiReq->newOrdrInfo.ordType = ImixToIrs_OrdType(strOrderType);
    pApiReq->newOrdrInfo.extOrdType = pApiReq->newOrdrInfo.ordType;


    pApiReq->newOrdrInfo.ordAction = ORDR_ACT_NEW;


    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnApiOrdSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiOrdSubmitStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiOrdSubmitStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    NewOrderSingleRspT* pApiResp;
    IRS_STRING          strErrCode = "";
    IRS_STRING          strErrMsg = "";
    std::string         strQryType;

    // ����Ӧ����Ϣ
    IMIX20::QueryResult* pRspMessage = new IMIX20::QueryResult;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_SPRET_ERR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_FAILD, RTN);
    }

    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    IntToString(ORDER_SUBMIT_RSP,strQryType);
    pRspMessage->SetQueryType(strQryType);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    pApiResp = (NewOrderSingleRspT*)pRsp->msgBody;

//    LOG_INFO("[%s] rsp msg: strUserId = %s, strOrgCd = %s, m_sOrdId = %s, strorderreqid = %s, strexec_user_id = %s, nErrorCode = %d",
//        sFunction.c_str(), strUserId.c_str(), strOrgCd.c_str(), oRetParam.m_sOrdId.c_str(), strorderreqid.c_str(), strexec_user_id.c_str(), nErrorCode);


    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        switch (pRsp->msgHdr.setId)
        {
            case SET_MKT_IRS:
                {
//                    int nOutBoundId = pApiResp->iMaxOutboundId;

                    SendOrdrDealStsUpdtMsgToTrdr(RDP_COMPID, pApiResp->rspSlot, pApiResp->slotCnt, pSendMsgList);
                    //SendOrderStatusUpdateMsgToTrader(RDP_COMPID, pApiResp->rspOrder, pApiResp->rspOrderCnt, pSendMsgList);
//                    SendOrderStatusUpdateMsgToApiTrader(message.GetHeader()->GetSenderCompID(), oRetParamRst, nOutBoundId, pSendMsgList, pParamList, inMessage);
                    //SendDealMsgToTrader(RDP_COMPID, pApiResp->rspDeal, pApiResp->rspDealCnt, pSendMsgList);
//                    SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//                    SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);

                    //SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
//                    SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

//                    SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
                }
                break;

            case SET_MKT_SIRS:
                {
//                    int nOutBoundId = oRetParam.m_nOutBoundId;

//                    SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, pSendMsgList);
//                    SIRS_SendOrderStatusUpdateMsgToApiTrader(message.GetHeader()->GetSenderCompID(),oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

//                    SIRS_SendDealMsgToTrader(RDP_COMPID, oRetParamRst.m_vecDeals, pSendMsgList);
//                    SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//                    SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);

//                    SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);
                }
                break;

            case SET_MKT_SBFCCP:
            default :
                {
//                    int nOutBoundId = oRetParam.m_nOutBoundId;

                    // �ͻ��˶���״̬
//                    CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
//                    CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(message.GetHeader()->GetSenderCompID(),oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

                    // �ͻ��˳ɽ���Ϣ
//                    CCP_SBF_SendDealMsgToTrader(RDP_COMPID, oRetParamRst.m_vecDeals, oRetParamRst.m_vecOnlineUser, pSendMsgList);

                    // TDPS�ɽ���Ϣ
//                    SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);

                    // ��Χ�ӿڳɽ���Ϣ
//                    CCP_SBF_SendDealMsgToTDPS(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//                    CCP_SBF_SendDealMsgToTDPSToSHCH(oRetParamRst.m_vecDeals, nOutBoundId, pSendMsgList, pParamList);
//                    CCP_SBF_SendLimitPositionStateMsgToTrader(RDP_COMPID,oRetParamRst.m_vecOnlineUser,oRetParamRst.m_vecCrdtLmts, pSendMsgList);

//                    SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
                }
                break;
        }
    }


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}


//IRSAPI��������
ResCodeT OnApiOrdCancelStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, int32 funcId)
{
    BEGIN_FUNCTION("OnApiOrdCancelStart");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiOrdCancelStart]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());

    APP_ERROR_CODE nRet = APP_CODE_SUCCESS;
    //
    std::string strFuncId = "";

    // �û�ID
    std::string strUserId = "";
    // token
    std::string strToken = "";
    // ����CD 21λ����
    std::string strOrgCd = "";
    IRS_STRING strorderreqid="";//���������ο����
    IRS_STRING strCancelType="";//����������ʾ
    IRS_STRING strOrderSeqNum="";//�����������������к�
    IRS_STRING strOrdId="";//�������
    IRS_STRING strexec_org_id="";//ִ�з�����
    IRS_STRING strexec_user_id="";//ִ�з�����
    IRS_STRING strsecurity_type = "";
    IRS_STRING strmarketindicator = "";//���ڹ���
    IRS_STRING strClearingMethod = "";

    IntToString(funcId, strFuncId);

    IMIX20::QueryResult message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        RAISE_ERR(APP_CODE_INCOM_MSG_INVALID, RTN);
    }

    //��ȡ����Ϣ
    MassMessageGrp* pMassMessageGrp;
    pMassMessageGrp = message.GetMassMessageGrp();
    if (NULL != pMassMessageGrp)
    {
        int nMassSize = pMassMessageGrp->GetNoMassMessage_Num();
        LOG_DEBUG("%s Mass size: %d.", sFunction.c_str(), nMassSize);
        if (nMassSize < 1)
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s NoMassMessage_Num is %d.", sFunction.c_str(), nMassSize);
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

        MassMessageGrp::NoMassMessage* pNoMassMessage = pMassMessageGrp->GetNoMassMessage(1);
        if (NULL != pNoMassMessage)
        {
            xapi::OrderCancelRequest partyUpdate;
            int len = pNoMassMessage->GetMessageLen();
            //16����ת��2���ƣ��ٽ���
            char *out = new char[len / 2 + 1];
            size_t nLen;
            char *p = hexStringToByteArray(pNoMassMessage->GetMessageData(), len, out, &nLen);
            p[nLen] = 0;
            partyUpdate.ParseFromArray(p, nLen);
            delete[] out;
            out = NULL;

            strorderreqid = partyUpdate.order_req_id();
            strOrdId = partyUpdate.orderid();
            strexec_user_id = partyUpdate.exec_user_id();
            strexec_org_id = partyUpdate.exec_org_id();

            IntToString(partyUpdate.ordercanceltype(),strCancelType);
            strOrderSeqNum=partyUpdate.orderseqnum();
            IntToString(partyUpdate.marketindicator(), strmarketindicator);
            if (partyUpdate.has_inst_scope_security_type())
            {
                strsecurity_type = partyUpdate.inst_scope_security_type();
            }

            if (partyUpdate.has_clearingmethod())
            {
                IntToString(partyUpdate.clearingmethod(), strClearingMethod);
            }

            User user = partyUpdate.user();
            strUserId = user.user_id();
            strToken = user.token();
            strOrgCd = user.org_id();
        }
        else
        {
            LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoMassMessage is null.", sFunction.c_str());
            RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
        }

    }
    else
    {
        LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetMassMessageGrp is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_INCOM_PARAM_ERROR, RTN);
    }

    // ������Ϣ��ӡ��־��ӡ
    LOG_INFO("[%d] In condition: strFuncId = %s, strToken = %s, strorderreqid = %s, strUserId = %s, strOrgCd = %s, strexec_user_id = %s, strexec_org_id = %s, \
                strOrdId = %s, strOrderSeqNum = %s, strCancelType = %s, strmarketindicator = %s, strsecurity_type = %s, strClearingMethod = %s",
                funcId, strFuncId.c_str(), strToken.c_str(), strorderreqid.c_str(), strUserId.c_str(), strOrgCd.c_str(), strexec_user_id.c_str(), strexec_org_id.c_str(),
                strOrdId.c_str(), strOrderSeqNum.c_str(), strCancelType.c_str(), strmarketindicator.c_str(), strsecurity_type.c_str(), strClearingMethod.c_str());

    int iCancelType;
    iCancelType = atoi(strCancelType.c_str());
    if (pReq->msgHdr.setId == SET_MKT_SBFCCP)
    {
        if ((iCancelType == C_API_CANCEL_ONE && strOrdId.length() == 0)
                || (iCancelType == C_API_CANCEL_ALL && strOrdId.length() != 0)
                || strToken.length() == 0
                || strCancelType.length() == 0
                || (iCancelType != C_API_CANCEL_ONE && iCancelType != C_API_CANCEL_ALL)
                )
        {
            RAISE_ERR(APIERR_CODE_INVLD_ORDRINCOME, RTN);
        }
    }
    else
    {
        if (strorderreqid.length() == 0
                || strCancelType.length() == 0
                || (iCancelType != C_API_CANCEL_ONE && iCancelType != C_API_CANCEL_ALL)
                || (iCancelType == C_API_CANCEL_ONE && strOrdId.length() == 0)
                )
        {
            RAISE_ERR(APIERR_CODE_INVLD_ORDRINCOME, RTN);
        }
    }

    //SP ���
    OrderCancelRequestReqT* pApiReq;
    pApiReq = (OrderCancelRequestReqT*)&pReq->msgBody[0];
    memset(pApiReq, 0, sizeof(OrderCancelRequestReqT));
    pReq->msgHdr.msgLen = sizeof(OrderCancelRequestReqT);
    switch (pReq->msgHdr.setId)
    {
        case SET_MKT_IRS:
            pReq->msgHdr.msgType = MSG_TYPE_API_ORD_CANCEL;
            break;
        case SET_MKT_SIRS:
            pReq->msgHdr.msgType = MSG_TYPE_SIRS_API_ORD_CANCEL;
            break;
        case SET_MKT_SBFCCP:
        default :
            pReq->msgHdr.msgType = MSG_TYPE_SBFCCP_API_ORD_CANCEL;
            break;
    }


    pUsrBaseInfoT pUsr, pApiUsr;
    pOrgInfoT pOrgInfo;

    strcpy(pApiReq->token, strToken.c_str());
    pApiReq->apiRqstId = atoi(strorderreqid.substr(strorderreqid.length()-8, strorderreqid.length()).c_str());

    //strUsrIdHeader
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pApiUsr);
    RAISE_ERR(rc, RTN);
    pApiReq->apiLoginUsrIdx =  pApiUsr->pos;

    /*get orgnizaion pos*/
    rc = OrgInfoGetByIdExt(pApiUsr->orgId, &pOrgInfo);
    RAISE_ERR(rc, RTN);

    pApiReq->orgIdx = pOrgInfo->pos;

    //strUsr
    rc = IrsUsrInfoGetByNameExt((char *)strexec_user_id.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pApiReq->userIdx =  pUsr->pos;

    pApiReq->ordId = atoi(strOrdId.c_str());

    pApiReq->apiCancelRqstId = atoi(strOrderSeqNum.c_str());

    pApiReq->apiCancelType = atoi(strCancelType.c_str());


    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}

ResCodeT OnApiOrdCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag)
{
    BEGIN_FUNCTION("OnApiOrdCancelStop");
    ResCodeT rc = NO_ERR;

    IRS_STRING sFunction = "[OnApiOrdCancelStop]: ";
    LOG_DEBUG("%s Start..", sFunction.c_str());


    NewOrderSingleRspT* pApiResp;
    IRS_STRING          strErrCode = "";
    IRS_STRING          strErrMsg = "";
    std::string         strQryType;

    // ����Ӧ����Ϣ
    IMIX20::QueryResult* pRspMessage = new IMIX20::QueryResult;
    if (NULL == pRspMessage)
    {
        LOG_ERROR(APP_CODE_SPRET_ERR, "%s pRspMessage is null.", sFunction.c_str());
        RAISE_ERR(APP_CODE_FAILD, RTN);
    }

    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    rc = SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);
    RAISE_ERR(rc, RTN);

    IntToString(ORDER_CANCEL_RSP,strQryType);
    pRspMessage->SetQueryType(strQryType);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    pApiResp = (NewOrderSingleRspT*)pRsp->msgBody;


    // ����������Ϣ
    if (NO_ERR == nExceptionFlag)
    {
        switch (pRsp->msgHdr.setId)
        {
            case SET_MKT_IRS:
                {
//                    int nOutBoundId = pApiResp->iMaxOutboundId;

                    SendOrdrDealStsUpdtMsgToTrdr(RDP_COMPID, pApiResp->rspSlot, pApiResp->slotCnt, pSendMsgList);
                    //SendOrderStatusUpdateMsgToTrader(RDP_COMPID, pApiResp->rspOrder, pApiResp->rspOrderCnt, pSendMsgList);
//                    SendOrderStatusUpdateMsgToApiTrader(message.GetHeader()->GetSenderCompID(),oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

//                    SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);

                    //SendImpOrderMsgToTDPS(oRetParamRst.m_vecImpOrders, nOutBoundId, pSendMsgList, pParamList);
//                    SendBrdgOrderMsgToTDPS(oRetParamRst.m_vecBrdgOrders, nOutBoundId, pSendMsgList, pParamList);

//                    SendOrderInfoMsgToTDPSToOutSide(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
                }
                break;

            case SET_MKT_SIRS:
                {
//                    int nOutBoundId = oRetParam.m_nOutBoundId;

//                    SIRS_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, pSendMsgList);
//                    SIRS_SendOrderStatusUpdateMsgToApiTrader(message.GetHeader()->GetSenderCompID(),oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);

//                    SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
                }
                break;

            case SET_MKT_SBFCCP:
            default :
                {
//                    int nOutBoundId = oRetParam.m_nOutBoundId;

//                    CCP_SBF_SendOrderStatusUpdateMsgToTrader(RDP_COMPID, oRetParamRst.m_vecOrders, oRetParamRst.m_vecOnlineUser, pSendMsgList);
//                    CCP_SBF_SendOrderStatusUpdateMsgToApiTrader(message.GetHeader()->GetSenderCompID(),oRetParamRst,nOutBoundId, pSendMsgList, pParamList,inMessage);
//                    SendOrderStatusUpdateMsgToTDPS(oRetParamRst.m_vecOrders, nOutBoundId, pSendMsgList, pParamList);
                }
                break;
        }
    }


    EXIT_BLOCK();
    LOG_DEBUG("%s End..", sFunction.c_str());
    RETURN_RESCODE;
}
