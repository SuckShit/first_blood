/***
Created on August 14, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "msg_type.h"
#include "common_macro.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "msg_credit.h"
#include "match_lib.h"

#include "credit_modify.h"
#include "internal_base_def.h"
#include "base_param.h"
#include "sys_st_rsrc.h"
#include "org_info.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 ** 
 ** FunctionName: CreditModify
 ** Description:  Prepare for Credit and Order freeze.
 *****************************************************************************/
ResCodeT CreditModify(
    int32 connId, 
    pIntrnlMsgT pReq, 
    pIntrnlMsgT pRsp, 
    int64 timestamp, 
    pCallBackCtxT pCtx
)
{
    BEGIN_FUNCTION( "CreditModify" );
    ResCodeT rc = NO_ERR;

    CreditRiskModifyReqT  *pCreditRiskModifyReq;
    CreditRiskModifyRespT *pCreditRiskModifyResp;
    CreditUpdateDataT data;
    int32 dataLen;

    uint64 maxBoundId;

    /*---------------------------���κ͹��̱����ĳ�ʼ��--------------------*/
    //RequestMessage 
    pCreditRiskModifyReq  = (CreditRiskModifyReqT*)&pReq->msgBody[0];
    //ResponseMessage 
    pCreditRiskModifyResp = (CreditRiskModifyRespT*)&pRsp->msgBody[0];
    memset(pCreditRiskModifyResp, 0x00, sizeof(CreditRiskModifyRespT));
    memset(&data, 0x00, sizeof(CreditUpdateDataT));
//    dataLen = sizeof(CreditUpdateDataT);

    // [IN]Set Parameters.
    data.eMessageType = MSG_TYPE_CREDIT_MODIFY;
    strcpy(data.strUserId, pCreditRiskModifyReq->strUserId);

    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);

    /*-----------------------------ͨ�ü��--------------------------------*/
    rc = CommonChk( pCreditRiskModifyReq->strUserId, 
                    atoi(pCreditRiskModifyReq->strOrgId), 
                    pCreditRiskModifyReq->iFuncId, 
                    pCreditRiskModifyReq->strToken, 
                    &data.intOrgId );
    RAISE_ERR(rc, RTN);

    // Calculate the size of common data
    dataLen  = sizeof(data.eMessageType);
    dataLen += MAX_USR_ID_LENTH;
    dataLen += sizeof(data.intOrgId); 
    dataLen += MAX_TIME_LENGTH;
    dataLen += sizeof(data.intCheckOrg);
    dataLen += sizeof(data.intUpdMthd);
    dataLen += sizeof(data.intCrdtMthd);
    dataLen += sizeof(data.intCrdtVldOrgFlag);
    dataLen += sizeof(data.intCount);

    // ����û������ж���
    /* init NewOrderSingleRspT */
    InitRspDat(&pCreditRiskModifyResp->orderRsp);
    /*All Market */
    rc = MtchrPrcsFreezeOrgOrdr(data.intOrgId, timestamp, &pCreditRiskModifyResp->orderRsp);
    if (NOTOK(rc) && APIERR_CODE_INVLD_ORDR != rc) {
        RAISE_ERR(rc, RTN);
    }

    //--����ǰ�Ƿ������Ų�����ΪY
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_CREDIT_DAT, &data, dataLen);
    RAISE_ERR(rc, RTN);

    /* �趨����ֵ */
    strcpy(pCreditRiskModifyResp->strUserId, data.strUserId);
    sprintf(pCreditRiskModifyResp->strOrgId, "%d", data.intOrgId);
    strcpy(pCreditRiskModifyResp->strUpdTime, data.strUpdTm);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/*****************************************************************************
 ** 
 ** FunctionName: CCPCreditUpdate
 ** Description:  Update CCP market credit parameter
 *****************************************************************************/
ResCodeT CCPCreditUpdate(
    int32           connId, 
    pIntrnlMsgT     pReq, 
    pIntrnlMsgT     pRsp, 
    int64           timestamp, 
    pCallBackCtxT   pCtx)
{
    BEGIN_FUNCTION( "CCPCreditUpdate" );
    ResCodeT            rc = NO_ERR;
    int32               dataLen = 0;
    int32               mrktState;
    
    pCCPCreditUptReqT   pCCPCrdtReq = NULL;
    pCCPCreditUptRspT   pCCPCrdtRsp = NULL;
    CCPCreditDataRefT   data;
    pBaseParamT         pParamData  = NULL;
    SysStRsrcT          sysStRsrc   = {0};
    OrgInfoT            orgInfo     = {0};
    OrgCdPosInfoT       orgCdPosInfo = {0}; 

    pCCPCrdtReq     = (pCCPCreditUptReqT)pReq->msgBody;
    pCCPCrdtRsp     = (pCCPCreditUptRspT)pRsp->msgBody;
    memset(pCCPCrdtRsp, 0x00, sizeof(CCPCreditUptRspT));
    memset(&data, 0x00, sizeof(CCPCreditDataRefT));
    
    pCCPCrdtRsp->msgSrno        = pCCPCrdtReq->msgSrno;
    pCCPCrdtRsp->crdtLmtSrno    = pCCPCrdtReq->crdtLmtSrno;
    pCCPCrdtRsp->setId          = pReq->msgHdr.setId;
    data.setId                  = pReq->msgHdr.setId;
    
    data.crdtAmnt       = pCCPCrdtReq->crdtAmnt;    
    data.timestamp              = timestamp;
    dataLen = sizeof(CCPCreditDataRefT);

    rc = BaseParamGetByNameExt((char*)C_MKT_ST, &pParamData);
    RAISE_ERR(rc, RTN);
    mrktState        = atoi(pParamData->paramValue);
    
    if (mrktState == C_MKT_ST_CLOSE)
    {
        RAISE_ERR(ERR_CODE_CNTRCT_DL_UNIT_EMPTY, RTN);
    }

    memset(&orgCdPosInfo, 0x00, sizeof(OrgCdPosInfoT));
    rc = OrgIdGetByCode((char *)pCCPCrdtReq->strOrgCd, &orgCdPosInfo);
    if (rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST)
    {
        RAISE_ERR(ERR_CODE_INVLD_ORG_NOPRV, RTN);
    }
    else
    {
        RAISE_ERR(rc, RTN);
    }

    rc = OrgInfoGetByPos(orgCdPosInfo.pos, &orgInfo);
    RAISE_ERR(rc, RTN);
    
    data.intOrgId   = orgInfo.orgId;
    
    if (orgInfo.orgSt == C_ORG_ST_DELETE || orgInfo.orgSt == C_ORG_ST_FORBID)
    {
        RAISE_ERR(ERR_CODE_INVLD_ORG_FRD, RTN);
    }

    rc = SysStRsrcGetByKey(C_PSTNLIMITMDFY_FUNCID, mrktState, &sysStRsrc);
    if ( rc == ERR_CMN_HASH_LIST_NODE_NOT_EXIST)
    {
        RAISE_ERR(ERR_CODE_INVLD_MKT_NOT_PMT, RTN);
    }
    else
    {
        RAISE_ERR(rc, RTN);
    }
     
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_CCPCRDT_DAT, &data, dataLen);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}