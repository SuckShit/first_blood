/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#ifndef METASK_OCOORDER_H
#define METASK_OCOORDER_H

#include "internal_function_def.h"
#include "intrnl_msg.h"

using namespace IMIX;
using namespace IMIX20;
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
// 用户登录
ResCodeT OnOcoOrderSubmitStart(int32 msgType,NewOrderList &message, IntrnlMsgT* pReq, OCO_CHECKBOX eCheckBox  = E_OCO_CHECKBOX_TRUE);
ResCodeT OnOcoOrderModifySubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnOcoOrderModifySaveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnOcoOrderSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOcoOrderModifySubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOcoOrderModifySaveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOcoOrderCnclRplcReqStart(int msgType, const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnOcoOrderCnclRplcReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOcoOrderCnclReqStart(int msgType, ListCancelRequest& message, IntrnlMsgT* pReq);
ResCodeT OnOcoOrderCnclReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
#endif