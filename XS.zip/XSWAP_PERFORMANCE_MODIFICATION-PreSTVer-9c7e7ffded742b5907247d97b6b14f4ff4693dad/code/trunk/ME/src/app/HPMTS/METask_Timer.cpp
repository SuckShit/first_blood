/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/

#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "irs_code_convert.h"
#include "msg_ref_prc_update.h"
#include "msg_timer.h"
#include "METask_Comm.h"

#include "METask_Comm.h"
#include "METask_Timer.h"

using namespace IMIX;
using namespace IMIX20;

/*=============================================================================
* Start��������ʵ��
===============================================================================*/

ResCodeT OnPeriodValidateStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnPeriodValidateStart");
    ResCodeT                rc = NO_ERR;

    // ��Ϣ����
    ExecutionReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    //pOrderMsg = (ExecutionReportReqT*)&pReq->msgBody[0];
    //pReq->msgHdr.msgLen = sizeof(ExecutionReportReqT);
    pReq->msgHdr.msgType = MSG_TYPE_PERIOD_VALIDATE;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



// for reference price re calculate
ResCodeT OnTimerCalRefPrcStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnTimerCalRefPrcStart");
    ResCodeT                rc = NO_ERR;

    // ��Ϣ����
    ExecutionReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    //pOrderMsg = (ExecutionReportReqT*)&pReq->msgBody[0];
    //pReq->msgHdr.msgLen = sizeof(ExecutionReportReqT);
    pReq->msgHdr.msgType = MSG_TYPE_TIMER_CAL_REF_PRC;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT OnTimerCalRefPrcStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnTimerCalRefPrcStop");
    ResCodeT                rc = NO_ERR;


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnMktDatPushStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnMktDatPushStart");
    ResCodeT                rc = NO_ERR;

    // ��Ϣ����
    ExecutionReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    //pOrderMsg = (ExecutionReportReqT*)&pReq->msgBody[0];
    //pReq->msgHdr.msgLen = sizeof(ExecutionReportReqT);
    pReq->msgHdr.msgType = MSG_TYPE_MKT_DAT_PUSH;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnMktDatPushStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnMktDatPushStop");
    ResCodeT                rc = NO_ERR;


    EXIT_BLOCK();
    RETURN_RESCODE;
}




ResCodeT OnBrdgOrdrStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnBrdgOrdrStart");
    ResCodeT                rc = NO_ERR;

    // ��Ϣ����
    ExecutionReport message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                ��ȡ��Ϣ�ֶ�
    *************************************/
    //pOrderMsg = (ExecutionReportReqT*)&pReq->msgBody[0];
    //pReq->msgHdr.msgLen = sizeof(ExecutionReportReqT);
    pReq->msgHdr.msgType = MSG_TYPE_BRDG_ORDR_TRGR;

    //reserve message header
    rc = ResrveReqMsg(&message, &pReq->msgHdr.imixHdr);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OnBrdgOrdrStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnBrdgOrdrStop");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleRspT*  pOrderSubmitStop;
    IRS_STRING strErrCode = "";
    IRS_STRING strErrMsg = "";

    ExecutionReport* pRspMessage = new ExecutionReport;
    int32 applRefSeqNum;
    rc = GetApplRefSeqNum(&pRsp->msgHdr.imixHdr, &applRefSeqNum);
    RAISE_ERR(rc, RTN);
    pRspMessage->SetApplRefSeqNum(applRefSeqNum);
    SetRespMsgHeader(&pRsp->msgHdr.imixHdr, pRspMessage);

    pRspMessage->GetHeader()->SetTargetCompID(RDP_COMPID);

    rc = GetErrCodeMsg(nExceptionFlag, strErrCode, strErrMsg);
    RAISE_ERR(rc, RTN);

    pRspMessage->SetApplErrorCode(strErrCode);
    pRspMessage->SetApplErrorDesc(strErrMsg);

    rc = SendMessage(pSendMsgList, pRspMessage);
    RAISE_ERR(rc, RTN);

    pOrderSubmitStop = (NewOrderSingleRspT*)pRsp->msgBody;

    // ����������Ϣ
    if (NO_ERR == nExceptionFlag && pOrderSubmitStop->slotCnt )
    {
//        rc = SendOrderStatusUpdateMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspOrder, pOrderSubmitStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
//        rc = SendDealMsgToTrader(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspDeal,pOrderSubmitStop->rspDealCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        rc = SendOrdrDealStsUpdtMsgToTrdr(pRspMessage->GetHeader()->GetTargetCompID(), pOrderSubmitStop->rspSlot,  pOrderSubmitStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT OnPeriodValidateStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag)
{
    BEGIN_FUNCTION("OnPeriodValidateStop");
    ResCodeT                rc = NO_ERR;

    NewOrderSingleRspT*  pPeriodValidateStop;

    pPeriodValidateStop = (pNewOrderSingleRspT)pRsp->msgBody;

    // ����������Ϣ
    if (pPeriodValidateStop->slotCnt)
    {
        //���Ͷ���������������������SIRS������ �����
//        rc = SendOrderStatusUpdateMsgToTrader(RDP_COMPID, pPeriodValidateStop->rspOrder, pPeriodValidateStop->rspOrderCnt, pSendMsgList);
//        RAISE_ERR(rc, RTN);
        
        
        rc = SendOrdrDealStsUpdtMsgToTrdr(RDP_COMPID, pPeriodValidateStop->rspSlot,  pPeriodValidateStop->slotCnt, pSendMsgList);
        RAISE_ERR(rc, RTN);

        //todo SendBilNoteUsrMsgToTrader(RDP_COMPID, pPeriodValidateStop->rspUsr, pPeriodValidateStop->rspUsrCnt, pSendMsgList);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

