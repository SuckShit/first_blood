/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard header files */
/* Project Header File*/
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"

#include "METask_Comm.h"
#include "METask_Login.h"
#include "METask_Order.h"
#include "METask_Officer.h"
#include "METask_Layer2.h"
#include "METask_BilOrder.h"
#include "METask_OcoOrder.h"
#include "METask_CombOrder.h"
#include "METask_BilCombOrder.h"
using namespace IMIX;
using namespace IMIX20;

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
// �û���¼&�ǳ�
ResCodeT OnLogonAndOutStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnLogonAndOutStart");
    ResCodeT                rc = NO_ERR;
    int nUserReqType;

    // ��Ϣ����,UserRequestType = 1ΪLogon, UserRequestType = 2ΪLogout
    UserRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    nUserReqType = message.GetUserRequestType();

    switch(nUserReqType)
    {
    case E_REQTYPE_LOGIN:
        rc = OnLoginStart(inMessage, pReq);
        break;
    case E_REQTYPE_LOGOUT:
        rc = OnLogoutStart(inMessage, pReq);
        break;
    case E_REQTYPE_REMOVE_USER:
        rc = OnRemoveOnlineUserStart(inMessage, pReq);
        break;
    default:
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
        break;
    }

    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//NewOrderSingleMessage�Ĵ�������
ResCodeT OnNewOrderSingleMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnNewOrderSingleMsgStart");
    ResCodeT                rc = NO_ERR;

    IRS_STRING strExecInst;
    char cOrdType;
    bool bBilOrd;

    // ��Ϣ����,ExecInst = 2Ϊ�ύ,ExecInst = SΪ����
    NewOrderSingle message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    strExecInst = message.GetExecInst();
    cOrdType = message.GetCommType();
    bBilOrd = (cOrdType==BIL_TYPE)?true:false;

    if (EXECINST_ORD_NEW == strExecInst || EXECINST_ORD_NEW_EXEC == strExecInst)
    {
        if (bBilOrd)
        {
            rc = OnBilOrderSubmitStart(MSG_TYPE_BILORDER_SUBMIT_MESSAGE,message, pReq);
        }
        else
        {
            rc = OnOrderSubmitStart(MSG_TYPE_ORDER_SUBMIT_MESSAGE, message, pReq);
        }

    }
    else if (EXECINST_ORD_SAVING == strExecInst)
    {
        if (bBilOrd)
        {
            rc = OnBilOrderSubmitStart(MSG_TYPE_BILORDER_SAVE_MESSAGE,message, pReq);
        }
        else
        {
            rc = OnOrderSubmitStart(MSG_TYPE_ORDER_SAVE_MESSAGE, message, pReq);
        }

    }
    else
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//OrdCancelReplaceReq��Ϣ�Ĵ�������
ResCodeT OnOrdCancelReplaceReqMsgStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrdCancelReplaceReqMsgStart");
    ResCodeT                rc = NO_ERR;
    MSG_G_FUNC eFunction;

    // ��Ϣ����
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //��ȡ������Ϣ�Ĺ�������
    eFunction = GetOrdCancelReplaceReqMsgFunction(message);
    switch(eFunction)
    {
    case E_ORD_ACTIVATE:
        rc = OnOrderCnclRplcReqStart(MSG_TYPE_ORDER_ACTIVATE_MESSAGE, message, pReq);
        break;
    case E_ORD_FREEZE:
        rc = OnOrderCnclRplcReqStart(MSG_TYPE_ORDER_FREEZE_MESSAGE, message, pReq);
        break;
    case E_ORD_MODIFY_SAVING:
        rc = OnOrderModifySaveStart(inMessage, pReq);
        break;
    case E_ORD_MODIFY_SUBMIT:
        rc = OnOrderModifySubmitStart(inMessage, pReq);
        break;
    case E_OCOORD_ACTIVATE:
        rc = OnOcoOrderCnclRplcReqStart(MSG_TYPE_OCOORDER_ACTIVATE_MESSAGE, inMessage, pReq);
        break;
    case E_OCOORD_FREEZE:
        rc = OnOcoOrderCnclRplcReqStart(MSG_TYPE_OCOORDER_FREEZE_MESSAGE, inMessage, pReq);
        break;
    default:
        break;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//��ϢTypeΪCS����Ϣ��������
ResCodeT OnCSMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    ResCodeT rc = NO_ERR;
    CSMsgFunction eFunction;

    BEGIN_FUNCTION("OnCSMsgStart");
    // ��Ϣ����
    PartyRiskLimitsDefinitionRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    //��ȡ������Ϣ�Ĺ�������
    eFunction = GetCSMsgFunction(message);
    switch (eFunction) {
        case E_CSMSG_CREDIT_RISK_MODIFY:        //����ϵ���޸�
            rc = OnCreditAndRiskModifyStart(inMessage, pReq);
            break;
        case E_CSMSG_CREDIT_REFRESH_METHOD_UPDATE: //���Ÿ��·�ʽ����
            rc = OnCreditRefreshMethodUpdateStart(inMessage, pReq);
            break;
        case E_CSMSG_CREDIT_RISK_SET_CANCEL://ȡ�����š�����ϵ������
            rc = OnUnlockCreditStart(inMessage, pReq);
            break;
        default:
            LOG_ERROR(APP_CODE_REQFUNC_ERR, APP_MSG_REQFUNC_ERR);
            rc = APP_CODE_REQFUNC_ERR;
            RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//BilOrdCancelReplaceReq��Ϣ�Ĵ�������
ResCodeT OnBilOrdCancelReplaceReqMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnOrdCancelReplaceReqMsgStart");
    ResCodeT                rc = NO_ERR;
    MSG_G_FUNC eFunction;

    // ��Ϣ����
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        return APP_CODE_INCOM_MSG_INVALID;
    }

    //��ȡ������Ϣ�Ĺ�������
    eFunction = GetOrdCancelReplaceReqMsgFunction(message);
    switch(eFunction)
    {
    case E_ORD_ACTIVATE:
        rc = OnBilOrderCnclRplcReqStart(MSG_TYPE_BILORDER_ACTIVATE_MESSAGE,message, pReq);
        break;
    case E_ORD_FREEZE:
        rc = OnBilOrderCnclRplcReqStart(MSG_TYPE_BILORDER_FREEZE_MESSAGE,message, pReq);
        break;
    case E_ORD_MODIFY_SAVING:
        rc = OnBilOrderModifySaveStart(inMessage, pReq);
        break;
    case E_ORD_MODIFY_SUBMIT:
        rc = OnBilOrderModifySubmitStart(inMessage, pReq);
        break;
    default:
        break;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//NewOrderListMessage�Ĵ�������
ResCodeT OnNewOrderListMsgStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION("OnNewOrderListMsgStart");
    ResCodeT                rc = NO_ERR;
    NewOrderListMsgFunction eFunction;

    // ��Ϣ����
    NewOrderList message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        return APP_CODE_INCOM_MSG_INVALID;
    }

    //��ȡ������Ϣ�Ĺ�������
    eFunction = GetNewOrderListMsgFunction(message);
    switch(eFunction)
    {
    case E_OCOORD_SAVE:
        rc = OnOcoOrderSubmitStart(MSG_TYPE_OCOORDER_SAVE_MESSAGE, message, pReq, E_OCO_CHECKBOX_TRUE);
        break;
    case E_OCOORD_SUBMIT:
        rc = OnOcoOrderSubmitStart(MSG_TYPE_OCOORDER_SUBMIT_MESSAGE,message, pReq, E_OCO_CHECKBOX_TRUE);
        break;
    default:
        break;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

//DataSet��Ϣ�Ĵ�������
ResCodeT OnDataSetMsgStart(
    const IMIX::BasicMessage& inMessage,
    IntrnlMsgT* pReq
)
{
    BEGIN_FUNCTION( "OnDataSetMsgStart" );
    ResCodeT rc = NO_ERR;

    // ��Ϣ����
    DataSet message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet) {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    DATASET_HEADER_DATA header;
    vector<IMIX::BasicMessage> vectMsg;
    AnalyzeMassMessage(message, header, vectMsg);

    LOG_INFO("header.m_nDataType:%d, vectMsg.size:%d", header.m_nDataType, vectMsg.size());

    switch (header.m_nDataType) {
    case E_MASS_TYPE_CREDIT_UPD_REQ:
        {
            OnCreditUpdateStart(vectMsg, pReq, message);

//            for (int nIndex = 0; nIndex < vectMsg.size(); ++nIndex) {
//                OnCreditUpdateStart(vectMsg[nIndex], pReq);
//            }

//            if (vectMsg.size() > 0) {
//                OnCreditUpdateUnlockStart(vectMsg[0], pReq);
//            }
        }
        break;
    case E_MASS_TYPE_RISK_UPD_REQ:
        {
            OnRiskCoefUpdateStart(inMessage, pReq);
        }
        break;
    case E_MASS_TYPE_CONTRACT_UPD_REQ:
        {
//          for (int nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
//          {
//              OnContractParamUpdateStart(vectMsg[nIndex], pParamList);
//          }
        }
        break;
    case E_MASS_TYPE_OCO_SUBMIT_REQ://OCO �����޸ĺ��ύ
        {
//          rc = OnOcoOrderModifySubmitStart(inMessage, pParamList);
        }
        break;
    case E_MASS_TYPE_OCO_SAVE_REQ://OCO�����޸ĺ󱣴�
        {
//          rc = OnOcoOrderModifySaveStart(inMessage, pParamList);
        }
        break;

        //1.5.1.0DataSet��Ϣȡ��XML�ַ���
    case E_MASS_TYPE_CW_PRICE_MODITY:
        {
            OnSetmentPriceModifyStart(inMessage, pReq);
        }
    default:
//      LOG_ERROR(APP_CODE_REQFUNC_ERR, APP_MSG_REQFUNC_ERR);
//      rc = APP_CODE_REQFUNC_ERR;
        break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


//NewOrderMultileg
ResCodeT OnNewOrderMultilegStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION( "OnNewOrderMultilegStart" );
    ResCodeT rc = NO_ERR;


    // ��Ϣ����,ExecInst = 2Ϊ�ύ,ExecInst = SΪ����
    NewOrderMultileg message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }
    
    char cOrdType = message.GetCommType();
    bool bBilOrd = (cOrdType==BIL_TYPE)?true:false;

    IRS_STRING strExecInst = message.GetExecInst();
    LOG_DEBUG("strExecInst: %s .bBilOrd=%d",strExecInst.c_str(),bBilOrd);

    if (EXECINST_ORD_NEW == strExecInst || EXECINST_ORD_NEW_EXEC == strExecInst )
    {
        if (bBilOrd)
        {
            rc = OnBilCombOrderSubmitStart(MSG_TYPE_BILORDER_SUBMIT_MESSAGE, const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
        else
        {
            rc = OnCombOrderSubmitStart(MSG_TYPE_ORDER_SUBMIT_MESSAGE, const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
    }
    else if (EXECINST_ORD_SAVING == strExecInst)
    {
        if (bBilOrd)
        {
            rc = OnBilCombOrderSubmitStart(MSG_TYPE_BILORDER_SAVE_MESSAGE, const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
        else
        {
            rc = OnCombOrderSubmitStart(MSG_TYPE_ORDER_SAVE_MESSAGE, const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
        
    }
    else
    {
        rc = APP_CODE_UNHANDLE_MSG;
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;    
}
//MultilegOrderCancelReplace
ResCodeT OnMultilegOrderCancelReplaceStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq)
{
    BEGIN_FUNCTION( "OnMultilegOrderCancelReplaceStart" );
    ResCodeT rc = NO_ERR;



    MultilegOrderCancelReplace message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        LOG_ERROR(APP_CODE_INCOM_MSG_INVALID, APP_MSG_INCOM_MSG_INVALID);
        return APP_CODE_INCOM_MSG_INVALID;
    }

    IRS_STRING strExecInst = message.GetExecInst();
    IRS_STRING strSecurityId = message.GetSecurityID();
    char cOrdType = message.GetCommType();
    bool bBilOrd = (cOrdType==BIL_TYPE)?true:false;

    LOG_DEBUG("OnMultilegOrderCancelReplaceStart strExecInst: %s, SecurityId: %s.bBilOrd=%d", 
            strExecInst.c_str(), strSecurityId.c_str(),bBilOrd);

    if ((EXECINST_ORD_NEW == strExecInst ||
        EXECINST_ORD_NEW_EXEC == strExecInst) &&
        strSecurityId != "")
    {
        //�ڲ���޸ĺ��ύ
//        if (bBilOrd)
//        {
//            rc = OnBilCombOrderModifySubmitStart(inMessage, pParamList);
//        }
//        else
//        {
//            rc = OnCombOrderCnclRplcStart(inMessage, pParamList);
//        }
    }
    else if (EXECINST_ORD_SAVING == strExecInst &&
        strSecurityId != "")
    {
        //�ڲ���޸ĺ󱣴�
//        if (bBilOrd)
//        {
//            rc = OnBilCombOrderModifySaveStart(inMessage, pParamList);
//        }
//        else
//        {
//            rc = OnCombOrderModifySaveStart(inMessage, pParamList);
//        }
        
    }
    else if (EXECINST_ORD_SAVING == strExecInst)
    {
        //�ڲ������
        if (bBilOrd)
        {
            rc = OnBilCombOrderCnclRplcStart(MSG_TYPE_BILORDER_FREEZE_MESSAGE,const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
        else
        {
            rc = OnCombOrderCnclRplcStart(MSG_TYPE_ORDER_FREEZE_MESSAGE, const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
        
    }
    else if (EXECINST_ORD_ACTIVATE == strExecInst ||
            EXECINST_ORD_ACTIVATE_EXEC == strExecInst)
    {
        //�ڲ������
        if (bBilOrd)
        {
            rc = OnBilCombOrderCnclRplcStart(MSG_TYPE_BILORDER_ACTIVATE_MESSAGE,const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
        else
        {
            rc = OnCombOrderCnclRplcStart(MSG_TYPE_ORDER_ACTIVATE_MESSAGE, const_cast<IMIX::BasicMessage&>(inMessage), pReq);
        }
    }
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;   
}
