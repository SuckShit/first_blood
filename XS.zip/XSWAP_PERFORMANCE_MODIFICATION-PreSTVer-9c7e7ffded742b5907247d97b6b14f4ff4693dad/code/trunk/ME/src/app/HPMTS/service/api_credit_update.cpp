/***
Created on August 14, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <math.h>

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "uti_tool.h"
#include "common_macro.h"

#include "pck_irs_util.h"
#include "pck_irs_dicdata.h"

#include "base_param.h"
#include "contract_info.h"
#include "credit_info.h"

#include "CrdtDb.h"
#include "match_lib.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "msg_credit.h"
#include "credit_common.h"
#include "api_common.h"
#include "api_credit_update.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 ** 
 ** FunctionName: ApiCreditUpdate
 ** Description:  Prepare for Credit Update.
 *****************************************************************************/
ResCodeT ApiCreditUpdate(
    int32 connId, 
    pIntrnlMsgT pReq, 
    pIntrnlMsgT pRsp, 
    int64 timestamp, 
    pCallBackCtxT pCtx
)
{
    BEGIN_FUNCTION( "ApiCreditUpdate" );
    ResCodeT rc = NO_ERR;
    ResCodeT ret = NO_ERR;

    ApiCreditUpdateReqT  *pApiCreditUpdateReq;
    ApiCreditUpdateRespT *pApiCreditUpdateResp;
    CreditUpdateDataT data;
    int32 dataLen;
    uint64 maxBoundId;
    int32 index;

    //lidongwei add
    Crdt crdtData;
    vectorT  keyVct[GET_BIT_VECT_LEN(18)] = {0};

    char  strCrtUseNm[50];
    pBaseParamT pParamData;
    pCntrctBaseInfoT pCntrctBaseInfo;
    pRiskCfcntT pRiskCfcnt;

    uint64 iRefCrtAmount;
    uint64 iCrtUseRskCof;
    int32 iCrtUseAmount;
    int32 iCrtLmtNum;

    OrgInfoT orgInfo;
    CreditT crdt;
    int32 cntOfCrdtdOrg = 0;
    int32 cntOfOrgModified = 0;
    //lidongwei end

    /*---------------------------���κ͹��̱����ĳ�ʼ��--------------------*/
    //RequestMessage 
    pApiCreditUpdateReq  = (ApiCreditUpdateReqT*)&pReq->msgBody[0];
    //ResponseMessage 
    pApiCreditUpdateResp = (ApiCreditUpdateRespT*)&pRsp->msgBody[0];
    memset(pApiCreditUpdateResp, 0x00, sizeof(ApiCreditUpdateRespT));

    memset(&data, 0x00, sizeof(CreditUpdateDataT));
//    dataLen = sizeof(CreditUpdateDataT);

    if (strcmp(pApiCreditUpdateReq->strOrgIdHeader, pApiCreditUpdateReq->strOrgId)) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_ORG_CD, RTN);
    }

    if (strcmp(pApiCreditUpdateReq->strUsrIdHeader, pApiCreditUpdateReq->strUserId)) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }

    // [IN]Set Parameters.
    data.eMessageType = MSG_TYPE_API_CREDIT_UPDATE;
    strcpy(data.strUserId, pApiCreditUpdateReq->strUserId);
    data.intCrdtMthd = pApiCreditUpdateReq->iCrdtMthd;
    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);
    /*-----------------------------ͨ�ü��--------------------------------*/
    rc = ApiCommonCheck(  
                            pApiCreditUpdateReq->strUserId, 
                            pApiCreditUpdateReq->strOrgId, 
                            pApiCreditUpdateReq->iFuncId, 
                            pApiCreditUpdateReq->strToken,
                            C_MKT_TP_IRS,
                            timestamp,
                            &data.intOrgId
                            );
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    if (strcmp(MARKET_X_SWAP, pApiCreditUpdateReq->strMarketId)) {
        RAISE_ERR(APIERR_CODE_INVLD_INCOME, RTN);
    }

    // ����ο����Ŷ��
    //ȡ�õ�ǰ�������ŷ�ʽ
    memset(&orgInfo, 0x00, sizeof(OrgInfoT));
    rc = OrgInfoGetById(data.intOrgId, &orgInfo);
    RAISE_ERR(rc, RTN);

    //���Ųο���Լ
    memset(strCrtUseNm, 0x00, sizeof(strCrtUseNm));
    rc = BaseParamGetByNameExt(C_CRT_RFCCNTCT, &pParamData);
    RAISE_ERR(rc, RTN);
    strcpy(strCrtUseNm, pParamData->paramValue);

    //���Ųο���Լ��Ӧ����
    rc = BaseParamGetByNameExt(C_CRT_LMT, &pParamData);
    RAISE_ERR(rc, RTN);
    iCrtLmtNum = atoi(pParamData->paramValue);

    //ȡ���Ųο�
    rc = IrsCntrctInfoGetByNameExt(strCrtUseNm, &pCntrctBaseInfo);
    RAISE_ERR(rc, RTN);
    iCrtUseAmount = pCntrctBaseInfo->dealUnit;

    //���Ųο���Լ��Ӧ�ķ���ϵ��(RSK_CFCNT)
    rc = IrsRiskCfcntGetByKeyExt(data.intOrgId, strCrtUseNm, &pRiskCfcnt);
    if (NOTOK(rc)) {
        LOG_INFO("this Org's Risk_CFCnt is not existed. Org[%lld],CntrctNm[%s]", data.intOrgId, strCrtUseNm);
        RAISE_ERR(rc, RTN);
    }
    iCrtUseRskCof = pRiskCfcnt->rskCfcntVal;

    //�ο�����
    iRefCrtAmount = iCrtLmtNum * iCrtUseAmount * iCrtUseRskCof / pow10(FIGURES_OF_RISK_COEFFICIENCY_IRS);

    //����ϵ����
    if (C_CREDIT_RL == orgInfo.crdtMthd) {
        memset(&crdtData, 0x00, sizeof(Crdt));
        memset( keyVct, 0x00, sizeof(vectorT) * GET_BIT_VECT_LEN(18) );
        crdtData.crdtOrgId = orgInfo.orgId;
        sprintf(crdtData.crdtRlF, "%d", C_CREDIT_RL);

        DbCmmnSetColBit( keyVct, 1 );
        DbCmmnSetColBit( keyVct, 5 );

        rc = GetResultCntOfCrdtByKeyRL(connId, &crdtData, keyVct, &cntOfCrdtdOrg);
        RAISE_ERR(rc, RTN);
    }
    else if (C_CREDIT_AMT == orgInfo.crdtMthd) {
        memset(&crdtData, 0x00, sizeof(Crdt));
        memset( keyVct, 0x00, sizeof(vectorT) * GET_BIT_VECT_LEN(18) );
        crdtData.crdtOrgId = orgInfo.orgId;
        crdtData.rmnCrdtAmnt = iRefCrtAmount;

        DbCmmnSetColBit( keyVct, 1 );
        DbCmmnSetColBit( keyVct, 7 );

        rc = GetResultCntOfCrdtByKeyAmnt(connId, &crdtData, keyVct, &cntOfCrdtdOrg);
        RAISE_ERR(rc, RTN);
    }
    else {
        LOG_INFO("this Org is not credited. Org[%lld]", orgInfo.orgId);
    }

    for (index = 0; index < pApiCreditUpdateReq->iCrdtCount; index++) {
        data.crdtInfo[index].intCrdtedOrgId  = pApiCreditUpdateReq->iCrdtedOrgIdLst[index];
        data.crdtInfo[index].intCrdtRlf      = pApiCreditUpdateReq->iCrdtRlfLst[index];
        data.crdtInfo[index].intIntlCrdtAmnt = pApiCreditUpdateReq->iIntlCrdtAmntLst[index];
        data.crdtInfo[index].intCrdtTerm     = pApiCreditUpdateReq->iCrdtTermLst[index];

        //ͳ����Ч���Ż�������
        if (orgInfo.crdtMthd == data.intCrdtMthd) {
            //���Ź�ϵ���:��
            if (C_CREDIT_RL == data.intCrdtMthd) {
                if (C_CRT_RL == data.crdtInfo[index].intCrdtRlf) cntOfOrgModified++;
                else if (C_CRT_RLESS == data.crdtInfo[index].intCrdtRlf) cntOfOrgModified--;
                else ;
            }
            else if (C_CREDIT_AMT == data.intCrdtMthd) {
                memset(&crdt, 0x00, sizeof(CreditT));
                rc = CreditInfoGetByKey(data.intOrgId, 
                                        data.crdtInfo[index].intCrdtedOrgId, 
                                        &crdt);
                RAISE_ERR(rc, RTN);

                if (crdt.rmnCrdtAmnt >= iRefCrtAmount && 
                    data.crdtInfo[index].intIntlCrdtAmnt < iRefCrtAmount) {
                    cntOfOrgModified--;
                }
                else if (crdt.rmnCrdtAmnt < iRefCrtAmount && 
                         data.crdtInfo[index].intIntlCrdtAmnt >= iRefCrtAmount) {
                    cntOfOrgModified++;
                }
            }
        }
        else {
            //���Ź�ϵ���:��
            if (C_CREDIT_RL == data.intCrdtMthd) {
                if (C_CRT_RL == data.crdtInfo[index].intCrdtRlf) cntOfOrgModified++;
            }
            else if (C_CREDIT_AMT == data.intCrdtMthd) {
                if (data.crdtInfo[index].intIntlCrdtAmnt >= iRefCrtAmount) cntOfOrgModified++;
            }
        }    
    }
    data.intCount = index;

    if (orgInfo.crdtMthd == data.intCrdtMthd) {
        cntOfCrdtdOrg += cntOfOrgModified;
    }
    else {
        cntOfCrdtdOrg = cntOfOrgModified;
    } 

    //��֤������Ч
    ret = CreditOrgCheck(cntOfCrdtdOrg);
    if (NOTOK(ret)) {
        data.intCrdtVldOrgFlag = C_ORG_CRT_USELESS;
    }
    else {
        data.intCrdtVldOrgFlag = C_ORG_CRT_USEFULL;
    }

    // Calculate the size of common data
    dataLen  = sizeof(data.eMessageType);
    dataLen += MAX_USR_ID_LENTH;
    dataLen += sizeof(data.intOrgId); 
    dataLen += MAX_TIME_LENGTH;
    dataLen += sizeof(data.intCheckOrg);
    dataLen += sizeof(data.intUpdMthd);
    dataLen += sizeof(data.intCrdtMthd);
    dataLen += sizeof(data.intCrdtVldOrgFlag);
    dataLen += sizeof(data.intCount);

    // Calculate the size of detail data and get the total size.
    dataLen += (data.intCount+1) * sizeof(CreditInfoT);

    // ����û������ж���
    /* init NewOrderSingleRspT */
    InitRspDat(&pApiCreditUpdateResp->orderRsp);
    /*All Market */
    rc = MtchrPrcsFreezeOrgOrdr(data.intOrgId, timestamp, &pApiCreditUpdateResp->orderRsp);
    if (NOTOK(rc) && APIERR_CODE_INVLD_ORDR != rc) {
        RAISE_ERR(rc, RTN);
    }

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_CREDIT_DAT, &data, dataLen);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    /* ����BoundId */
//    rc = GetBoundId(connId, &maxBoundId);
//    pCreditUpdateResp->iMaxOutBoundId = maxBoundId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
