/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
#ifndef METASK_ORDER_H
#define METASK_ORDER_H

#include "internal_function_def.h"
#include "intrnl_msg.h"

using namespace IMIX;
using namespace IMIX20;
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT OnOrderSubmitStart(int32 msgType, NewOrderSingle& message, IntrnlMsgT* pReq);
ResCodeT OnOrderModifySubmitStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox= E_OCO_CHECKBOX_TRUE);
ResCodeT OnOrderModifySaveStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq, OCO_CHECKBOX eOcoCheckBox= E_OCO_CHECKBOX_TRUE);
ResCodeT OnOrderCnclRplcReqStart(int msgType, OrderCancelReplaceRequest& message, IntrnlMsgT* pReq);
ResCodeT OnOrderCnclReqStart(int msgType,  OrderCancelRequest& message, IntrnlMsgT* pReq);
ResCodeT OnOrderSubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOrderModifySubmitStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOrderModifySaveStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOrderCnclRplcReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnOrderCnclReqStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnTrdCancelStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList,  int nExceptionFlag);
ResCodeT OnTrdCancelStart(const IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq);
ResCodeT SendOrdTrdToClntStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList);
ResCodeT OnSetmentPriceModifyStart(const IMIX::BasicMessage& inMessage, IntrnlMsgT* pReq);
ResCodeT OnSetmentPriceModifyStop(IntrnlMsgT* pRsp, SENDMSGLIST* pSendMsgList, int nExceptionFlag);
#endif