/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#ifndef SPTASK_BILCOMBORDER_H
#define SPTASK_BILCOMBORDER_H

#include "internal_function_def.h"

// 订单提交
ResCodeT OnBilCombOrderSubmitStart(int32 msgType, IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq); 
// 订单保存

// 订单撤销
// 订单冻结
ResCodeT OnBilCombOrderCnclRplcStart(int32 msgType, IMIX::BasicMessage& inMessage,IntrnlMsgT* pReq); 
// 订单激活

#endif