/***
Created on August 14, 2017
@author: Dongwei.Li
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>
#include <stdlib.h>

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "uti_tool.h"
#include "common_macro.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "credit_common.h"

#include "org_info.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "msg_credit.h"
#include "credit_unlock.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 ** 
 ** FunctionName: CreditUnlock
 ** Description:  Prepare for Credit Unlock.
 *****************************************************************************/
ResCodeT CreditUnlock(
    int32 connId, 
    pIntrnlMsgT pReq, 
    pIntrnlMsgT pRsp, 
    int64 timestamp, 
    pCallBackCtxT pCtx
)
{
    BEGIN_FUNCTION( "CreditUnlock" );
    ResCodeT rc  = NO_ERR;
    ResCodeT ret = NO_ERR;

    CreditUnlockReqT  *pCreditUnlockReq;
    CreditUnlockRespT *pCreditUnlockResp;
    CreditUpdateDataT data;
    int32 dataLen;
    uint64 maxBoundId;

    OrgInfoT orgInfo;

    /*---------------------------���κ͹��̱����ĳ�ʼ��--------------------*/
    //RequestMessage 
    pCreditUnlockReq  = (CreditUnlockReqT*)&pReq->msgBody[0];
    //ResponseMessage 
    pCreditUnlockResp = (CreditUnlockRespT*)&pRsp->msgBody[0];
    memset(pCreditUnlockResp, 0x00, sizeof(CreditUnlockRespT));

    memset(&data, 0x00, sizeof(CreditUpdateDataT));
//    dataLen = sizeof(CreditUpdateDataT);

    // [IN]Set Parameters.
    data.eMessageType = MSG_TYPE_CREDIT_UNLOCK;
    strcpy(data.strUserId, pCreditUnlockReq->strUserId);
    data.intCheckOrg = pCreditUnlockReq->iCheckOrg;
    rc = GetStrDateTimeByFormat(timestamp, data.strUpdTm);
    RAISE_ERR(rc, RTN);

    /*-----------------------------ͨ�ü��--------------------------------*/
    rc = CommonChk( pCreditUnlockReq->strUserId, 
                    atoi(pCreditUnlockReq->strOrgId), 
                    pCreditUnlockReq->iFuncId, 
                    pCreditUnlockReq->strToken, 
                    &data.intOrgId );
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    if (pCreditUnlockReq->iCheckOrg == 1) {
        memset(&orgInfo, 0x00, sizeof(OrgInfoT));
        rc = OrgInfoGetById(data.intOrgId, &orgInfo);
        if (NOTOK(rc)) {
            RAISE_ERR(rc, RTN);
        }
        data.intCrdtVldOrgFlag = orgInfo.crdtVldOrgFlag;

        //��֤������Ч
//        ret = CreditOrgCheck(connId, data.intOrgId);
//        if (NOTOK(ret)) {
//            data.intCrdtVldOrgFlag = C_ORG_CRT_USELESS;
//        }
//        else {
//            data.intCrdtVldOrgFlag = C_ORG_CRT_USEFULL;
//        }
    }

    // Calculate the size of common data
    dataLen  = sizeof(data.eMessageType);
    dataLen += MAX_USR_ID_LENTH;
    dataLen += sizeof(data.intOrgId); 
    dataLen += MAX_TIME_LENGTH;
    dataLen += sizeof(data.intCheckOrg);
    dataLen += sizeof(data.intUpdMthd);
    dataLen += sizeof(data.intCrdtMthd);
    dataLen += sizeof(data.intCrdtVldOrgFlag);
    dataLen += sizeof(data.intCount);

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_CREDIT_DAT, &data, dataLen);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }

    //--���ض����û���Ϣ

    /* ����BoundId */
//    rc = GetBoundId(connId, &maxBoundId);
//    pCreditUnlockResp->iMaxOutBoundId = maxBoundId;
    pCreditUnlockResp->iResult = data.intCrdtVldOrgFlag;
    strcpy(pCreditUnlockResp->strUserId, data.strUserId);
    sprintf(pCreditUnlockResp->strOrgId, "%d", data.intOrgId);
    strcpy(pCreditUnlockResp->strUpdTime, data.strUpdTm);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
