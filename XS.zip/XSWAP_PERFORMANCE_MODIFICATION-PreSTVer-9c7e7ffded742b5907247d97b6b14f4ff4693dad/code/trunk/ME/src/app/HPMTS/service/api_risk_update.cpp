/***
Created on Serp 19, 2017
@author: Zhanjun
@version $Id
***/
/***
Modify History:
    ID      Date        Person      Description
***/
 
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C hearder files */
#include <stdio.h>
#include <stdlib.h>

/* Project Header Files */
#include "err_cod.h"
#include "err_lib.h"
#include "msg_type.h"
#include "common_macro.h"

#include "pck_irs_util.h"
#include "pck_irs_dicdata.h"

#include "usr_def_ref.h"
#include "ref_dat_updt.h"
#include "msg_risk.h"
#include "credit_common.h"
#include "api_common.h"
#include "api_risk_update.h"
#include "CntrctBaseInfoDb.h"
#include "contract_info.h"
#include "user_order.h"
#include "match_lib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 ** 
 ** FunctionName: ApiRiskUpdate
 ** Description:  Prepare for Risk Update.
 *****************************************************************************/
ResCodeT ApiRiskUpdate(
    int32 connId, 
    pIntrnlMsgT pReq, 
    pIntrnlMsgT pRsp, 
    int64 timestamp, 
    pCallBackCtxT pCtx
)
{
    BEGIN_FUNCTION( "ApiRiskUpdate" );
    ResCodeT rc = NO_ERR;
    
    pOrgInfoT pOrgInfoData;    
    RiskInfoReqT    *pRiskInfoReq;
    RiskInfoRespT   *pRiskInfoResp;
    NewOrderSingleRspT orderRsp;
    RiskUpdateDataT data;
    int32 dataLen;
    uint64 maxBoundId;
    int32 index;
    int32 iCrtMthd;
    int32 iRskRlNum;
    pCntrctBaseInfoT dataStr;

    /*---------------------------���κ͹��̱����ĳ�ʼ��--------------------*/
    pRiskInfoReq  = (RiskInfoReqT*)&pReq->msgBody[0];
    pRiskInfoResp = (RiskInfoRespT*)&pRsp->msgBody[0];
    memset(pRiskInfoResp, 0x00, sizeof(RiskInfoRespT));

    memset(&data, 0x00, sizeof(RiskUpdateDataT));
    dataLen = sizeof(RiskUpdateDataT);

    if (strcmp(pRiskInfoReq->strOrgIdHeader, pRiskInfoReq->strOrgId)) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_ORG_CD, RTN);
    }

    if (strcmp(pRiskInfoReq->strUsrIdHeader, pRiskInfoReq->strUserId)) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }
    
    if (!((2 == pRiskInfoReq->iMarketId && (0 == strlen(pRiskInfoReq->strSecuriType) || 0 == strcmp(pRiskInfoReq->strSecuriType, "IRS")))
        ||(42 == pRiskInfoReq->iMarketId && (0 == strlen(pRiskInfoReq->strSecuriType) || 0 == strcmp(pRiskInfoReq->strSecuriType, "SIRS"))))) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);         
    } 
    
    //�ж����ŷ�ʽ
    rc = OrgInfoGetByIdExt(atoi(pRiskInfoReq->strOrgId), &pOrgInfoData);
    if (NOTOK(rc)) {
        RAISE_ERR(rc, RTN);
    }
    iCrtMthd = pOrgInfoData->crdtMthd;
    
    if (C_CREDIT_AMT != iCrtMthd) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    }

    if (13 != pRiskInfoReq->iCleaningMthd) {
        RAISE_ERR(APIERR_CODE_INVLD_OWNR_USRID, RTN);
    } 
    
    rc = RiskInfoUpdate(connId, pReq, pRsp, timestamp, pCtx);
    RAISE_ERR(rc, RTN);    
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}
