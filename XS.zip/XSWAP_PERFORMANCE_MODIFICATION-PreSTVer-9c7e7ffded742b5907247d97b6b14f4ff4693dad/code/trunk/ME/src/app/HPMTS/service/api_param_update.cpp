/***
Created on Sep 5, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/******************************************************************************
 **
 ** UpdateBaseParamApi
 **
 ******************************************************************************/
ResCodeT UpdateBaseParamApi(
            int32               connId,
            ApiParamUpdateReqT* pApiReq,
            char*               strKey,
            char*               strCtrl,
            char*               strUpdateTime
            )
{
    BEGIN_FUNCTION( "UpdateBaseParamApi" );
    ResCodeT rc = NO_ERR;

    BaseParamApi data;
    vectorT  keyVct[GET_BIT_VECT_LEN(10)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(10)] = {0};

    memset(&data, 0, sizeof(BaseParamApi));
    strcpy(data.paramNm, strKey);
    strcpy(data.paramNextVl, strCtrl);
    itoa(C_PARAM_NEXT_ST_MODIFY, data.mdfySt, 10);
    strcpy(data.crtUsrNm, pApiReq->strUserId);
    strcpy(data.updTm, strUpdateTime);

    DbCmmnSetColBit( keyVct, 1 );
    DbCmmnSetColBit( datVct, 3 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 9 );
    DbCmmnSetColBit( datVct, 8 );

    rc = UpdateBaseParamApiByKey( connId, &data, keyVct, datVct );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 **
 ** Detail Service Callback : ApiParamUpdate
 **
 ******************************************************************************/
ResCodeT ApiParamUpdate(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp
            )
{
    BEGIN_FUNCTION( "ApiParamUpdate" );
    ResCodeT rc = NO_ERR;

    ApiParamUpdateReqT*   pApiReq;

    pApiReq = (ApiParamUpdateReqT*)&pReq->msgBody[0];



    // common check
    int32 iOrgId;
    rc = CommonChk(pApiReq->strUserId, C_ORG_NULL, pApiReq->iFuncId, pApiReq->strToken, &iOrgId);
    RAISE_ERR(rc, RTN);


    // ����ĸ����ز����Ƿ�С��1
    if (pApiReq->iCrdtFlowCtrl < 1
            || pApiReq->iTradeFlowCtrl < 1
            || pApiReq->iLoginFlowCtrl < 1
            || pApiReq->iMktFlowCtrl < 1)
    {
        RAISE_ERR(ERR_CODE_INVLD_FLWVAL, RTN);
    }


    // check beging time & end time
    int64   iBegin, iEnd;
    rc = DateTimeToTimestamp(pApiReq->strMdfyCrdtBegin, &iBegin);
    RAISE_ERR(rc, RTN);
    rc = DateTimeToTimestamp(pApiReq->strMdfyCrdtEnd, &iEnd);
    RAISE_ERR(rc, RTN);
    if (iBegin > iEnd)
    {
        RAISE_ERR(ERR_CODE_INVLD_CRDT_TM, RTN);
    }


    // get current time
    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);


    // update 6 base_param_api table
    char temp[10];

    rc = UpdateBaseParamApi(connId, pApiReq, (char*)C_API_CRDT_FLW_CNTRL, itoa(pApiReq->iCrdtFlowCtrl, temp, 10), strTimestamp);
    RAISE_ERR(rc, RTN);

    rc = UpdateBaseParamApi(connId, pApiReq, (char*)C_API_TRADE_FLW_CNTRL, itoa(pApiReq->iTradeFlowCtrl, temp, 10), strTimestamp);
    RAISE_ERR(rc, RTN);

    rc = UpdateBaseParamApi(connId, pApiReq, (char*)C_API_LOGIN_FLW_CNTRL,  itoa(pApiReq->iLoginFlowCtrl, temp, 10), strTimestamp);
    RAISE_ERR(rc, RTN);

    rc = UpdateBaseParamApi(connId, pApiReq, (char*)C_API_MKT_FLW_CNTRL, itoa(pApiReq->iMktFlowCtrl, temp, 10), strTimestamp);
    RAISE_ERR(rc, RTN);

    rc = UpdateBaseParamApi(connId, pApiReq, (char*)C_API_CRDT_TIME_START, pApiReq->strMdfyCrdtBegin, strTimestamp);
    RAISE_ERR(rc, RTN);

    rc = UpdateBaseParamApi(connId, pApiReq, (char*)C_API_CRDT_TIME_END, pApiReq->strMdfyCrdtEnd, strTimestamp);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
