/***
Created on Sep.23 2017
@author: No One
@version $ID
***/
/***
Modify History:
    ID      Date        Person      Description
***/
#include "METask_CallSub.h"
#include "METask_Comm.h"
#include "UTILITY/base64.h"
#include "usr.h"
#include "order_book.h"
#include "contract_info.h"
#include "org_info.h"
#include "uti_tool.h"
#include "irs_code_convert.h"
using namespace IMIX20;

#define   OCO_ORDER_ASC   0
#define   OCO_ORDER_DEC   1

static int32 gDecCnt = 0;
static int32 gAscCnt = 0;

ResCodeT InitOcoOrderCnt()
{
    BEGIN_FUNCTION("InitOCOOrderCnt");
    ResCodeT                rc = NO_ERR;

    gDecCnt = 0;
    gAscCnt = 0;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetOcoOrderCnt(int32* pSecCnt, int32* pSecAskCnt)
{
    BEGIN_FUNCTION("InitOCOOrderCnt");
    ResCodeT                rc = NO_ERR;

    *pSecCnt = gAscCnt;
    *pSecAskCnt = gDecCnt;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT InsertIntoOrderArray(NewOrderInfoT* pParamsOffer, NewOrderInfoT* pOrder, int16 flg)
{
    BEGIN_FUNCTION("InsertIntoOrderArray");
    ResCodeT                rc = NO_ERR;

    int32 idx= 0;
    int32 tmpCnt = 0;

    NewOrderInfoT* pTmp;

    if (flg == OCO_ORDER_DEC)
    {
        tmpCnt = gDecCnt;
    }else
    {
        tmpCnt = gAscCnt;
    }
    
    pTmp = pParamsOffer;
    while (1)
    {
        if (pTmp->prcQtyInfo.price == 0)
        {
            break;
        }
    
        if (OCO_ORDER_DEC == flg)
        {
            if (pOrder->prcQtyInfo.price > pTmp->prcQtyInfo.price)
            {
                break;
            }
        }
        if (OCO_ORDER_ASC == flg)
        {
            if (pOrder->prcQtyInfo.price < pTmp->prcQtyInfo.price)
            {
                break;
            }
        }
    
        pTmp = pTmp + 1;
        idx = idx + 1;
    }

    if (idx < tmpCnt)
    {
        memcpy(pTmp + 1, pTmp, sizeof(NewOrderInfoT)* (tmpCnt - idx)  );
    }
    memcpy(pTmp,  pOrder, sizeof(NewOrderInfoT) ); 
    
    if (OCO_ORDER_DEC == flg)
    {
        gDecCnt++;
    }else
    {
        gAscCnt++;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;     
}

ResCodeT OnOcoSubmitFirstSpStartExe(IMIX20::DataSet& message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOcoSubmitFirstSpStartExe");
    ResCodeT                rc = NO_ERR;
    
    int nMsgNum;
    bool bGetParam;
    int nIndex;
    IMIX::BasicMessage baseMsg;
    IRS_STRING strMsgId ;
    bool bRet;
    ListOrdGrp* pListOrdGrp;
    ListOrdGrp::NoOrders* pNoOrders;
    IRS_STRING strUserId;
    pUsrBaseInfoT pUsr = NULL;
    NewOrderList msgOrdList;
    OrderCancelReplaceRequest msgOrdCancelRelaceReq;
    
    vector<IMIX::BasicMessage> vectMsg;
    DATASET_HEADER_DATA header;
    rc = AnalyzeMassMessage(message, header, vectMsg);
    RAISE_ERR(rc, RTN);    

    pOcoFirst->eCheckBox = eCheckBox;
    
    nMsgNum = vectMsg.size();
    if (E_OCO_CHECKBOX_FALSE == eCheckBox)
    {
        //有取消消息则减去一条
        nMsgNum --;
    }   

    // 处理新增的订单逻辑    
    bGetParam = false;
    for(nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
    {
        baseMsg = vectMsg[nIndex];
        //根据消息号进行处理,增加对不同类型消息的判断
        strMsgId = baseMsg.GetHeader()->GetMsgType();
        if (NewOrderListMessageID == strMsgId)
        {
            // 消息解析
            bRet = msgOrdList.crack(const_cast<IMIX::BasicMessage&>(baseMsg));
            if (!bRet)
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            nMsgNum -= 1;//减去NewOrderList这条消息
            if (msgOrdList.GetNoOrders() <= 0)
            {
                continue;
            }

            if (false == bGetParam)
            {
                strcpy(pOcoFirst->token, msgOrdList.GetApplToken().c_str()  );
                pOcoFirst->ocoId = StringToInt64(msgOrdList.GetListID()  );
                rc = ExecInstConvert(msgOrdList.GetListExecInst(), &pOcoFirst->execInst);   
                RAISE_ERR(rc, RTN);

                //获取交易员,从重复组里面的第一个订单中获取
                pListOrdGrp = msgOrdList.GetListOrdGrp();       
                if (pListOrdGrp)
                {
                    pNoOrders = pListOrdGrp->GetNoOrders();
                    if (pNoOrders)
                    {
                        rc = GetTraderFromParties(pNoOrders->GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
                        RAISE_ERR(rc, RTN);
    
                        rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
                        RAISE_ERR(rc, RTN);
                        pOcoFirst->userIdx =  pUsr->pos;
                    }
                    else
                    {
                        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoOrders error!", sFunction.c_str());
                    }
                }
                else
                {
                    //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetListOrdGrp error!", sFunction.c_str());
                }
                bGetParam = true;
            }                       
            nMsgNum += msgOrdList.GetNoOrders();            

            break;
        }
        else if (OrderCancelReplaceRequestMessageID == strMsgId && false == bGetParam)
        {
            bRet = msgOrdCancelRelaceReq.crack(const_cast<IMIX::BasicMessage&>(baseMsg));
            if (!bRet)
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            strcpy(pOcoFirst->token, msgOrdCancelRelaceReq.GetApplToken().c_str()  );
            pOcoFirst->ocoId = StringToInt64(msgOrdCancelRelaceReq.GetListID()  );
            rc = ExecInstConvert(msgOrdCancelRelaceReq.GetExecInst(), &pOcoFirst->execInst);    
            RAISE_ERR(rc, RTN);
            rc = GetTraderFromParties(msgOrdCancelRelaceReq.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
            RAISE_ERR(rc, RTN);
    
            rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
            RAISE_ERR(rc, RTN);
            pOcoFirst->userIdx =  pUsr->pos;

            bGetParam = true;
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;     
}

ResCodeT OnOcoSubmitFirstSpStart(IMIX20::NewOrderList& message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOcoSubmitFirstSpStart");
    ResCodeT                rc = NO_ERR;
    ListOrdGrp::NoOrders* pNoOrders;
    IRS_STRING strUserId;
    pUsrBaseInfoT pUsr = NULL;
    ListOrdGrp* pListOrdGrp;
    
    strcpy(pOcoFirst->token, message.GetApplToken().c_str()  );
    pOcoFirst->ocoId = StringToInt( message.GetListID() );
    pOcoFirst->ordNum = message.GetTotNoOrders() ;
    rc = ExecInstConvert(message.GetListExecInst(), &pOcoFirst->execInst);
    RAISE_ERR(rc, RTN);
    pOcoFirst->eCheckBox = eCheckBox;
    pOcoFirst->ordAction = ORDR_ACT_NEW;
    
    //获取交易员,从重复组里面的第一个订单中获取
    pListOrdGrp = message.GetListOrdGrp();      
    if (pListOrdGrp)
    {
        pNoOrders = pListOrdGrp->GetNoOrders();
        if (pNoOrders)
        {
            rc = GetTraderFromParties(pNoOrders->GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
            RAISE_ERR(rc, RTN);
    
            rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
            RAISE_ERR(rc, RTN);
            pOcoFirst->userIdx =  pUsr->pos;            
        }
        else
        {
            //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoOrders error!", sFunction.c_str());
        }
    }
    else
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetListOrdGrp error!", sFunction.c_str());
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;     
}

ResCodeT OnOcoSubmitSecondSpStart(IMIX20::NewOrderList& message, NewOrderInfoT* pOcoSecBid, NewOrderInfoT* pOcoSecAsk, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOcoSubmitSecondSpStart");
    ResCodeT                rc = NO_ERR;

    // 按照买卖方向分别获取订单信息
    rc = GetOrdNewSubmitParams(message, pOcoSecBid, pOcoSecAsk, eCheckBox);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;     
}


ResCodeT OnOcoSaveFirstSpStart(IMIX20::NewOrderList&  message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOcoSaveFirstSpStart");
    ResCodeT                rc = NO_ERR;
    
    ListOrdGrp::NoOrders*  pNoOrders;
    IRS_STRING strUserId;
    ListOrdGrp* pListOrdGrp;
    pUsrBaseInfoT pUsr = NULL;
    
    strcpy(pOcoFirst->token, message.GetApplToken().c_str()  );
    pOcoFirst->ocoId = StringToInt64(message.GetListID()  );
    pOcoFirst->ordNum = message.GetTotNoOrders();
    rc = ExecInstConvert(message.GetListExecInst(), &pOcoFirst->execInst);  
    RAISE_ERR(rc, RTN);
    pOcoFirst->eCheckBox = eCheckBox;
    
    pListOrdGrp = message.GetListOrdGrp();
    if (pListOrdGrp)
    {
        pNoOrders = pListOrdGrp->GetNoOrders();
        if (pNoOrders)
        {
            rc = GetTraderFromParties(pNoOrders->GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
            RAISE_ERR(rc, RTN);         
        
            rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
            RAISE_ERR(rc, RTN);
            pOcoFirst->userIdx =  pUsr->pos;
        }
        else
        {
            //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoOrders error!", sFunction.c_str());
        }
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;  
}

// OCO保存流程中，调用第一个检查SP用
ResCodeT OnOcoSaveFirstSpStartExe(IMIX20::DataSet& message, OCOFirstT* pOcoFirst, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOcoSaveFirstSpStart");
    ResCodeT                rc = NO_ERR;
    int nMsgNum;
    bool bGetParam;
    int nIndex;
    bool bRet;
    IMIX::BasicMessage baseMsg;
    IRS_STRING strMsgId;
    vector<IMIX::BasicMessage> vectMsg;
    DATASET_HEADER_DATA header;
    NewOrderList msgOrdList;
    ListOrdGrp* pListOrdGrp;
    ListOrdGrp::NoOrders* pNoOrders;
    IRS_STRING strUserId;
    pUsrBaseInfoT pUsr = NULL;
    OrderCancelReplaceRequest msgOrdCancelRelaceReq;
    
    rc = AnalyzeMassMessage(message, header, vectMsg);
    RAISE_ERR(rc, RTN);

    //CheckBox标识
    pOcoFirst->eCheckBox = eCheckBox;

    pOcoFirst->ordAction = ORDR_ACT_MOD;

    nMsgNum = vectMsg.size();
    if (E_OCO_CHECKBOX_FALSE == eCheckBox)
    {
        //有取消消息则减去一条
        nMsgNum --;
    }
    
    bGetParam = false;
    // 处理新增的订单逻辑    
    for(nIndex = 0; nIndex < vectMsg.size(); ++nIndex)
    {
        baseMsg = vectMsg[nIndex];
        //根据消息号进行处理,增加对不同类型消息的判断
        strMsgId = baseMsg.GetHeader()->GetMsgType();
        if (NewOrderListMessageID == strMsgId)
        {
            // 消息解析
            bRet = msgOrdList.crack(const_cast<IMIX::BasicMessage&>(baseMsg));
            if (!bRet)
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            nMsgNum -= 1;//减去NewOrderList这条消息
            if (msgOrdList.GetNoOrders() <= 0)
            {
                continue;
            }
            nMsgNum += msgOrdList.GetNoOrders();            

            if (false == bGetParam)
            {
                strcpy(pOcoFirst->token, msgOrdList.GetApplToken().c_str()  );
                pOcoFirst->ocoId = StringToInt( msgOrdList.GetListID());
                //pOcoFirst->ordAction = ORDR_ACT_NEW;
                rc = ExecInstConvert(msgOrdList.GetListExecInst(), &pOcoFirst->execInst);
                RAISE_ERR(rc, RTN);     
                
                //获取交易员,从重复组里面的第一个订单中获取
                pListOrdGrp = msgOrdList.GetListOrdGrp();       
                if (pListOrdGrp)
                {
                    pNoOrders = pListOrdGrp->GetNoOrders();
                    if (pNoOrders)
                    {
                        rc = GetTraderFromParties(pNoOrders->GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
                        RAISE_ERR(rc, RTN);
    
                        rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
                        RAISE_ERR(rc, RTN);
                        pOcoFirst->userIdx =  pUsr->pos;
                    }
                    else
                    {
                        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetNoOrders error!", sFunction.c_str());
                    }
                }
                else
                {
                    //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s GetListOrdGrp error!", sFunction.c_str());
                }
                bGetParam = true;
            }                       
            break;
        }
        else if (OrderCancelReplaceRequestMessageID == strMsgId && false == bGetParam)
        {
            
            bRet = msgOrdCancelRelaceReq.crack(const_cast<IMIX::BasicMessage&>(baseMsg));
            if (!bRet)
            {
                RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
            }

            strcpy(pOcoFirst->token, msgOrdCancelRelaceReq.GetApplToken().c_str()  );
            pOcoFirst->ocoId = StringToInt( msgOrdCancelRelaceReq.GetListID());
            rc = ExecInstConvert(msgOrdCancelRelaceReq.GetExecInst(), &pOcoFirst->execInst);
            RAISE_ERR(rc, RTN);     

            rc = GetTraderFromParties(msgOrdCancelRelaceReq.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
            RAISE_ERR(rc, RTN);
    
            rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
            RAISE_ERR(rc, RTN);
            pOcoFirst->userIdx =  pUsr->pos;
            bGetParam = true;
        }
    }
    
    pOcoFirst->ordNum = nMsgNum;
    
    EXIT_BLOCK();
    RETURN_RESCODE;  
}



// OCO保存流程中，调用第二个订单新建
ResCodeT OnOcoSaveSecondSpStart(IMIX20::NewOrderList& message, NewOrderInfoT* pSec, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("OnOcoSaveSecondSpStart");
    ResCodeT                rc = NO_ERR;

    /****************************/
    IRS_STRING strOcoId ="";
    ListOrdGrp* pListOrdGrp;
    int nGrpSize;
    int nIndex;
    NewOrderInfoT* pTmp; 
    ListOrdGrp::NoOrders* pNoOrders;
    char  securityId[30];   
    CntrctBaseInfoT cntract;
    pUsrBaseInfoT pUsr = NULL;
    IRS_STRING strUserId;
    
    //订单处理类型
    IRS_STRING strIsExec = "";

    // 如果OCO CheckBox未选中，则提交单个订单时不提供OCOID(SP的处理要求)
    if (E_OCO_CHECKBOX_TRUE == eCheckBox)
    {
        strOcoId = message.GetListID();
    }

    pTmp = pSec;
    pListOrdGrp = message.GetListOrdGrp();      
    if (pListOrdGrp)
    {
        nGrpSize = pListOrdGrp->GetNoOrders_Num();
        for (nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nGrpSize + IMIX_GRP_INDEX_BEGIN; ++nIndex)
        {
            pTmp->ocoId = StringToInt(strOcoId);
            pTmp->ordAction = ORDR_ACT_NEW;
            rc = ExecInstConvert(message.GetListExecInst(), &pTmp->execInst);
    
            pNoOrders = pListOrdGrp->GetNoOrders(nIndex);
            if (pNoOrders)
            {
                //spParam.m_sOrdId  = pNoOrders->GetRefOrderID();
                pTmp->ordId = StringToInt64(pNoOrders->GetRefOrderID());
                if (pNoOrders->GetInstrument())
                {
                    //spParam.m_sSecurityId = pNoOrders->GetInstrument()->GetSecurityID();
                    strcpy(securityId, pNoOrders->GetInstrument()->GetSecurityID().c_str() );
                    rc = IrsCntrctInfoGetByName(&securityId[0], &cntract);
                    RAISE_ERR(rc, RTN);
                    pTmp->contractPos = cntract.pos;
                }

                rc = SideConvert(pNoOrders->GetSide(), &pTmp->side);
                RAISE_ERR(rc, RTN); 

                CnvtPriceToIntnlVal(pNoOrders->GetPrice(), &pTmp->prcQtyInfo.price);
                
                //spParam.m_sOrdType = CharToString(pNoOrders->GetOrdType());
                if (pNoOrders->GetOrderQtyData() != NULL)
                {
                    //spParam.m_sOrderQty = pNoOrders->GetOrderQtyData()->GetOrderQty();
                    pTmp->prcQtyInfo.qty = StringToInt64( pNoOrders->GetOrderQtyData()->GetOrderQty() );
                }
                else
                {
                    //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "GetOrderQtyData error.");
                }
                
                TimeToSecs((char *)pNoOrders->GetEffectiveTime().c_str(), &pTmp->effectTime);
                rc = GetTraderFromParties(pNoOrders->GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
                RAISE_ERR(rc, RTN);
                rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
                RAISE_ERR(rc, RTN);
                pTmp->userIdx =  pUsr->pos;
            }
            pTmp = pTmp + 1;
        }                                   
    }

    EXIT_BLOCK();
    RETURN_RESCODE; 
}


ResCodeT GetOrdNewSubmitParams(IMIX20::NewOrderList& message, NewOrderInfoT* pParamsBid, NewOrderInfoT* pParamsOffer, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("GetOrdNewSubmitParams");
    ResCodeT                rc = NO_ERR;

    ListOrdGrp::NoOrders* pNoOrders;
    pUsrBaseInfoT pUsr = NULL;
    int nGrpSize;
    int nIndex;
    IRS_STRING strSide;
    IRS_STRING strUserId;
    IRS_STRING strToken = "";
    IRS_STRING strOcoId ="";
    strToken = message.GetApplToken();
    pCntrctBaseInfoT pCntract;
    pOrgInfoT pOrgInfo = NULL;
    
    // 如果OCO CheckBox未选中，则提交单个订单时不提供OCOID(SP的处理要求)
    if (E_OCO_CHECKBOX_TRUE == eCheckBox)
    {
        strOcoId = message.GetListID();
    }

    ListOrdGrp* pListOrdGrp = message.GetListOrdGrp();      
    if (pListOrdGrp)
    {
        nGrpSize = pListOrdGrp->GetNoOrders_Num();
        for (nIndex = IMIX_GRP_INDEX_BEGIN; nIndex < nGrpSize + IMIX_GRP_INDEX_BEGIN; ++nIndex)
        {
            NewOrderInfoT  order;
            order.ocoId = StringToInt(strOcoId);
            order.ordAction = ORDR_ACT_NEW;
            
            rc = ExecInstConvert(message.GetListExecInst(), &order.execInst);
            RAISE_ERR(rc, RTN);
        
            pNoOrders = pListOrdGrp->GetNoOrders(nIndex);
            if (NULL != pNoOrders)
            {
                order.ordId = StringToInt64(pNoOrders->GetRefOrderID());
                if (pNoOrders->GetInstrument())
                {
                    rc = IrsCntrctInfoGetByNameExt((char *) pNoOrders->GetInstrument()->GetSecurityID().c_str(), &pCntract);
                    RAISE_ERR(rc, RTN);
                    order.contractPos = pCntract->pos;
                }
                rc = SideConvert(pNoOrders->GetSide(), &order.side);
                RAISE_ERR(rc, RTN); 

                CnvtPriceToIntnlVal(pNoOrders->GetPrice(), &order.prcQtyInfo.price);
                
                order.ordType = ImixToIrs_OrdType(CharToString(pNoOrders->GetOrdType()));
                order.extOrdType = order.ordType;
    
                if (pNoOrders->GetOrderQtyData() != NULL)
                {
                    order.prcQtyInfo.qty = StringToInt64( pNoOrders->GetOrderQtyData()->GetOrderQty() );
                }
                else
                {
                    //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "GetOrderQtyData error.");
                }
                DateTimeToTimestamp((char *)pNoOrders->GetEffectiveTime().c_str(), &order.effectTime);

                rc = GetTraderFromParties(pNoOrders->GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
                RAISE_ERR(rc, RTN);
                rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
                RAISE_ERR(rc, RTN);
                order.userIdx =  pUsr->pos;
                
                    /*get orgnizaion pos*/
                rc = OrgInfoGetByIdExt(pUsr->orgId, &pOrgInfo);
                RAISE_ERR(rc, RTN);
                
                order.orgIdx = pOrgInfo->pos;

                order.apiLoginUsrIdx = -1;
                order.apiRqstId = 0;
            }

            strSide = pNoOrders->GetSide();
            if (E_IMIX_SIDE_BID == strSide)
            {
                //paramsBid.push_back(spParam);
                InsertIntoOrderArray(pParamsBid, &order, OCO_ORDER_ASC);
            }
            else if (E_IMIX_SIDE_ASK == strSide)
            {
                //paramsOffer.push_back(spParam);
                InsertIntoOrderArray(pParamsOffer, &order, OCO_ORDER_DEC);
            }
            else
            {
                //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s Error side: %s!", sFunction.c_str(), strSide.c_str());
            }           
        }                                   
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetOrdModifySubmitParams(IMIX20::OrderCancelReplaceRequest& message, NewOrderInfoT* pParamsBid, NewOrderInfoT* pParamsOffer, OCO_CHECKBOX eCheckBox)
{
    BEGIN_FUNCTION("GetOrdModifySubmitParams");
    ResCodeT                rc = NO_ERR;

    IRS_STRING strSide;
    IRS_STRING strUserId;
    IRS_STRING strToken = "";
    IRS_STRING strOcoId ="";
    pUsrBaseInfoT pUsr = NULL;
    CntrctBaseInfoT cntract;     
    NewOrderInfoT  order;
    char  securityId[30];
    
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
        
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    order.userIdx =  pUsr->pos;     
    
    order.ordId = StringToInt64(message.GetOrderID());
    strcpy(securityId, message.GetSecurityID().c_str() );
    rc = IrsCntrctInfoGetByName(&securityId[0], &cntract);
    RAISE_ERR(rc, RTN);
    order.contractPos = cntract.pos;

    //买卖方向  
    rc = SideConvert(message.GetSide(), &order.side);
    RAISE_ERR(rc, RTN);     
    CnvtPriceToIntnlVal(message.GetPrice(), &order.prcQtyInfo.price);
    order.prcQtyInfo.qty = StringToInt64( message.GetOrderQty() );
    if (E_OCO_CHECKBOX_TRUE == eCheckBox)
    {
        order.ocoId = StringToInt(message.GetListID());
    }
    else
    {
        order.ocoId =  0;
    }   
    TimeToSecs((char *)message.GetEffectiveTime().c_str(), &order.effectTime);
    //ordType to be done
    //spParam.m_sOrdType = CharToString(message.GetOrdType());
    rc = ExecInstConvert(message.GetExecInst(), &order.execInst);
    RAISE_ERR(rc, RTN);
    
    order.ordAction = ORDR_ACT_MOD;     

    strSide = message.GetSide();
    if (E_IMIX_SIDE_BID == strSide)
    {
        InsertIntoOrderArray(pParamsBid, &order, OCO_ORDER_ASC);
    }
    else if (E_IMIX_SIDE_ASK == strSide)
    {
        InsertIntoOrderArray(pParamsOffer, &order, OCO_ORDER_DEC);
    }
    else
    {
        //LOG_ERROR(APP_CODE_INCOM_PARAM_ERROR, "%s Error side: %s!", sFunction.c_str(), strSide.c_str());
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// 订单修改后保存
ResCodeT OnOrderModifySaveStartByOco(const IMIX::BasicMessage& inMessage, NewOrderInfoT* pOrderMsg, OCO_CHECKBOX eOcoCheckBox)
{
    BEGIN_FUNCTION("OnOrderModifySubmitStart");
    ResCodeT                rc = NO_ERR;

    //OrderCancelReplaceRequestReqT* pOrderMsg; 
    IRS_STRING strUserId;
    IRS_STRING strordAction = E_ORD_EXEC_TYPE_MODIFY;
    CntrctBaseInfoT cntract;
    pUsrBaseInfoT pUsr = NULL;
    
    // 消息解析
    OrderCancelReplaceRequest message;
    bool bRet = message.crack(const_cast<IMIX::BasicMessage&>(inMessage));
    if (!bRet)
    {
        RAISE_ERR(APP_CODE_UNHANDLE_MSG, RTN);
    }

    /************************************
                获取消息字段
    *************************************/

    //获取交易员
    rc = GetTraderFromParties(message.GetParties(), strUserId,  E_PARTY_ROLE_ORD_USER);
    RAISE_ERR(rc, RTN);
    
    rc = IrsUsrInfoGetByNameExt((char *)strUserId.c_str(), &pUsr);
    RAISE_ERR(rc, RTN);
    pOrderMsg->userIdx =  pUsr->pos;
    
    pOrderMsg->ordId = StringToInt(message.GetOrderID()  );

    rc = IrsCntrctInfoGetByName((char *)message.GetSecurityID().c_str(), &cntract);
    RAISE_ERR(rc, RTN);
    pOrderMsg->contractPos = cntract.pos;
    
    //买卖方向    
    rc = SideConvert(message.GetSide(), &pOrderMsg->side);
    RAISE_ERR(rc, RTN); 
    
    CnvtPriceToIntnlVal(message.GetPrice(), &pOrderMsg->prcQtyInfo.price);
    pOrderMsg->prcQtyInfo.qty = StringToInt64( message.GetOrderQty() );
    if (E_OCO_CHECKBOX_TRUE == eOcoCheckBox)
    {
        pOrderMsg->ocoId = StringToInt( message.GetListID()  );
    }   
    
    TimeToSecs((char *)message.GetEffectiveTime().c_str(), &pOrderMsg->effectTime);
    pOrderMsg->ordAction =   ORDR_ACT_MOD;

    EXIT_BLOCK();
    RETURN_RESCODE; 
}


