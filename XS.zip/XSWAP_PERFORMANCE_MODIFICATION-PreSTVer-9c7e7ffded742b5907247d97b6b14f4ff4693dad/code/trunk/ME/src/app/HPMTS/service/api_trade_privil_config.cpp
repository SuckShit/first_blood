/***
Created on Sep 20, 2017
@author: Jiawang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <regex.h>
#include <math.h>

#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "common_macro.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "ref_dat_updt.h"
#include "intrnl_msg.h"
#include "internal_base_def.h"

#include "pck_irs_dicdata.h"
#include "pck_irs_util.h"
#include "BaseParamApiDb.h"
#include "api.h"
#include "usr.h"
#include "api_common.h"
#include "UsrOnlnDb.h"
#include "UsrLgnHstryDb.h"
#include "QtSbscrptnApiDb.h"
#include "org_info.h"
#include "usr_def_ref.h"
#include "contract_info.h"
#include "order_submit.h"
#include "order_check.h"
#include "order_book.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/******************************************************************************
 **
 ** SerializeTrdConfRefData
 **
 ******************************************************************************/
ResCodeT SerializeTrdConfRefData(
                int32                       connId,
                ApiTradePrivilConfigReqT*   pApiReq,
                char*                       strTimestamp
                )
{
    BEGIN_FUNCTION( "SerializeTrdConfRefData" );
    ResCodeT rc = NO_ERR;

    int32 iRefSize;
    iRefSize = sizeof(TrdPrvlConfDataRefT);

    TrdPrvlConfDataRefT  s;
    memset(&s, 0, sizeof(TrdPrvlConfDataRefT));

    strcpy(s.oprtTm, strTimestamp);
    if (pApiReq != NULL)
    {
        strcpy(s.strUsrId, pApiReq->strUsrId);
        strcpy(s.strTrdId, pApiReq->strTrdId);
        if (pApiReq->iAppId % 2)
        {
            BitSet(s.allPrvls, 0);
        }
        if (pApiReq->iOrdrPrvlgFlag % 2)
        {
            BitSet(s.allPrvls, 1);
        }
        if (pApiReq->iOrdrPrvlgMdfyFlag)
        {
            BitSet(s.allPrvls, 2);
        }
        if (pApiReq->iOrdrPrvlgFlagSirs % 2)
        {
            BitSet(s.allPrvls, 3);
        }
        if (pApiReq->iOrdrPrvlgMdfyFlagSirs)
        {
            BitSet(s.allPrvls, 4);
        }
        if (pApiReq->iOrdrPrvlgFlagSbfccp % 2)
        {
            BitSet(s.allPrvls, 5);
        }
        if (pApiReq->iOrdrPrvlgMdfyFlagSbfccp)
        {
            BitSet(s.allPrvls, 6);
        }
    }

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_TRADE_PRIVIL_CONFIG_DAT, &s, iRefSize);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 **
 ** Detail Service Callback : ApiTradePrivilConfig
 **
 ******************************************************************************/
ResCodeT ApiTradePrivilConfig(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp,
            pCallBackCtxT   pCtx
            )
{
    BEGIN_FUNCTION( "ApiTradePrivilConfig" );
    ResCodeT rc = NO_ERR;

    ApiTradePrivilConfigReqT*   pApiReq;

    pApiReq = (ApiTradePrivilConfigReqT*)&pReq->msgBody[0];


    // common check
    int32 iOrgId;
    rc = CommonChk(pApiReq->strUsrId, C_ORG_NULL, pApiReq->iFuncId, pApiReq->strToken, &iOrgId);
    RAISE_ERR(rc, RTN);


    char strTimestamp[MAX_TIME_LEN];
    memset(strTimestamp, 0, sizeof(strTimestamp));
    rc = GetStrDateTimeByFormat(timestamp, strTimestamp);

    pUsrBaseInfoT pUserInfo;
    rc = IrsUsrInfoGetByNameExt(pApiReq->strTrdId, &pUserInfo);
    RAISE_ERR(rc, RTN);

    if (pApiReq->iAppId == C_DWS)
    {
        // �����ǰ̨����Ĳ���
        if ((atoi(pUserInfo->ordrPrvlgF) != pApiReq->iOrdrPrvlgFlag && atoi(pUserInfo->ordrPrvlgMdfyF) == C_TRD_PVL_NO)
            || (atoi(pUserInfo->ordrPrvlgFSirs) != pApiReq->iOrdrPrvlgFlagSirs && atoi(pUserInfo->ordrPrvlgMdfyFSirs) == C_TRD_PVL_NO)
            || (atoi(pUserInfo->ordrPrvlgFSbfccp) != pApiReq->iOrdrPrvlgFlagSbfccp && atoi(pUserInfo->ordrPrvlgMdfyFSbfccp) == C_TRD_PVL_NO))
        {
            RAISE_ERR(APIERR_CODE_TRD_NO_PVL, RTN);
        }
/*
        // update usr
        itoa(pApiReq->iOrdrPrvlgFlag, pUserInfo->ordrPrvlgF, 10);
        itoa(pApiReq->iOrdrPrvlgFlagSirs, pUserInfo->ordrPrvlgFSirs, 10);
        itoa(pApiReq->iOrdrPrvlgFlagSbfccp, pUserInfo->ordrPrvlgFSbfccp, 10);

        rc = UpdateUsrFlag(connId, pApiReq, strTimestamp);
        RAISE_ERR(rc, RTN);
    }
    else if (pApiReq->iAppId == C_MBO)
    {
        // ������к�̨����Ĳ���

        // update usr
        itoa(pApiReq->iOrdrPrvlgFlag, pUserInfo->ordrPrvlgF, 10);
        itoa(pApiReq->iOrdrPrvlgMdfyFlag, pUserInfo->ordrPrvlgMdfyF, 10);
        itoa(pApiReq->iOrdrPrvlgFlagSirs, pUserInfo->ordrPrvlgFSirs, 10);
        itoa(pApiReq->iOrdrPrvlgMdfyFlagSirs, pUserInfo->ordrPrvlgMdfyFSirs, 10);
        itoa(pApiReq->iOrdrPrvlgFlagSbfccp, pUserInfo->ordrPrvlgFSbfccp, 10);
        itoa(pApiReq->iOrdrPrvlgMdfyFlagSbfccp, pUserInfo->ordrPrvlgMdfyFSbfccp, 10);

        rc = UpdateUsrFlagAndMdfy(connId, pApiReq, strTimestamp);
        RAISE_ERR(rc, RTN);
*/
    }

    rc = SerializeTrdConfRefData(connId, pApiReq, strTimestamp);
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}
