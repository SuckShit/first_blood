/***
Created on Aug 24, 2017
@author: Xiaoping Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "err_lib.h"
#include "err_cod.h"
#include "msg_type.h"
#include "cfg_lib.h"
#include "db_comm.h"
#include "uti_tool.h"
#include "org_info.h"
#include "usr.h"
#include "base_param.h"
#include "OrgInfoBrdgDb.h"
#include "CrdtBrdgDb.h"
#include "BaseParamDb.h"

#include "bridge_update.h"
#include "msg_bridge_update.h"
#include "pck_irs_util.h"
#include "pck_irs_dicdata.h"
#include "usr_def_ref.h"
#include "ref_dat_updt.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define USER_NAME_EMERGENCY           "emergency"
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/******************************************************************************
 **
 ** Detail Service Callback
 **
 ******************************************************************************/
/* 桥交易员设置 */
ResCodeT BridgeDealerUpdate(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp)
{
    BEGIN_FUNCTION( "BridgeDealerUpdate" );
    ResCodeT rc = NO_ERR;

    // vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    // vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};

    BrdgDealerUpdateReqT *pDealerUptReq;
    BrdgDealerUpdateRespT *pDealerUptResp;
    int32 v_OutOrgId;
    pBrdgOrgInfoT pBrdgOrgData;
    short v_PreSt;
    short v_PostSt;
    BOOL hasOrgMktPrvlg;
    BOOL hasUsrMktPrvlg;
    // OrgInfoBrdg orgInfoBrdgData;
    char sysUptDateStr[MAX_TIME_LEN];
    uint64 maxBoundId;
    BridgeUpdateDataRefT brdgUpdateRefData;


    pDealerUptReq = (BrdgDealerUpdateReqT*)&pReq->msgBody[0];
    pDealerUptResp = (BrdgDealerUpdateRespT*)&pRsp->msgBody[0];

    memset(pDealerUptResp, 0x00, sizeof(BrdgDealerUpdateRespT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
    memset(&brdgUpdateRefData, 0x00, sizeof(BridgeUpdateDataRefT));

    /* 通用检查 */
    rc = CommonChk(pDealerUptReq->strUserId, C_ORG_NULL, pDealerUptReq->intFuncId,
                pDealerUptReq->strToken, &v_OutOrgId);
    RAISE_ERR(rc, RTN);

    /* 获取前值 */
    rc = BrdgOrgInfoGetByIdExt(v_OutOrgId, &pBrdgOrgData);
    RAISE_ERR(rc, RTN);

    v_PreSt = pBrdgOrgData->brdgOrgSt;


    /* 判断新值 */
    v_PostSt = 1;
    hasOrgMktPrvlg = FALSE;
    hasUsrMktPrvlg = FALSE;

    if (!(pDealerUptReq->intBrdgPrvlgSt == 1 &&
        pBrdgOrgData->brdgPrvlgFlag == 1 &&
        pBrdgOrgData->crdtOprtngSt == 0 &&
        strlen(pDealerUptReq->strBrdgDealer) != 0)){

        v_PostSt = 0;
    }

    /* Check the organization privilege */
    rc = IsAuthorizedInMarket(v_OutOrgId, 1, &hasOrgMktPrvlg);
    RAISE_ERR(rc, RTN);

    if (hasOrgMktPrvlg == FALSE){
        v_PostSt = 0;
    }

    /* Check the user privilege */
    rc = IrsUsrMktStatusGet(pDealerUptReq->strBrdgDealer, 1, &hasUsrMktPrvlg);
    RAISE_ERR(rc, RTN);

    if (hasUsrMktPrvlg == FALSE){
        v_PostSt = 0;
    }


    /* 更新交易员 & st */
    // First, update the DB
    // memset(&orgInfoBrdgData, 0x00, sizeof(OrgInfoBrdg));

    /* Get current timestamp */
    // rc = GetCurrentTime(sysDateStr);
    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);

    brdgUpdateRefData.eMessageType = MSG_TYPE_BRIDGE_DEALER_UPDATE;
    strcpy(brdgUpdateRefData.strUserId, pDealerUptReq->strUserId);
    brdgUpdateRefData.intOrgId = v_OutOrgId;
    strcpy(brdgUpdateRefData.strDealerId, pDealerUptReq->strBrdgDealer);
    brdgUpdateRefData.intBrdgOrgSt = v_PostSt;
    brdgUpdateRefData.intBrdgPrvlgSt = pDealerUptReq->intBrdgPrvlgSt;
    strcpy(brdgUpdateRefData.strSysTime, sysUptDateStr);

    rc = RefDatUpdtCmmn(REF_TYP_UPDT_BRIDGE_DAT, &brdgUpdateRefData, sizeof(BridgeUpdateDataRefT));
    RAISE_ERR(rc, RTN);

    // orgInfoBrdgData.orgId = v_OutOrgId;

    // DbCmmnSetColBit( keyVct, 1 );

    // sprintf(orgInfoBrdgData.brdgIntntnF, "%d", pDealerUptReq->intBrdgPrvlgSt);
    // strcpy(orgInfoBrdgData.usrLgnNm, pDealerUptReq->strBrdgDealer);
    // strcpy(orgInfoBrdgData.dlrUpdTm, sysDateStr);
    // strcpy(orgInfoBrdgData.dlrUpdUsrNm, pDealerUptReq->strUserId);
    // strcpy(orgInfoBrdgData.updTm, sysDateStr);
    // strcpy(orgInfoBrdgData.updUsrNm, pDealerUptReq->strUserId);
    // sprintf(orgInfoBrdgData.brdgOrgSt, "%d", v_PostSt);

    // DbCmmnSetColBit( datVct, 4 );
    // DbCmmnSetColBit( datVct, 10 );
    // DbCmmnSetColBit( datVct, 11 );
    // DbCmmnSetColBit( datVct, 12 );
    // DbCmmnSetColBit( datVct, 17 );
    // DbCmmnSetColBit( datVct, 18 );
    // DbCmmnSetColBit( datVct, 2 );

    // rc = UpdateOrgInfoBrdgByKey(connId, &orgInfoBrdgData,keyVct, datVct);
    // RAISE_ERR(rc, RTN);

    // rc = DbCmmnCommit(connId);
    // RAISE_ERR(rc, RTN);

    // Then, update the shared memory
    // pBrdgOrgData->brdgIntntnFlag = pDealerUptReq->intBrdgPrvlgSt;
    // strcpy(pBrdgOrgData->usrLgnNm, pDealerUptReq->strBrdgDealer);
    // pBrdgOrgData->brdgOrgSt = v_PostSt;

    /* 刷桥单 */
    if (v_PostSt == 0 && v_PreSt == 1){
        //TODO: PCK_IRS_BRDG.SP_CLEARBRDGORDBYBRDGORG
    }else if (v_PostSt == 1 && v_PreSt == 0){
        //TODO: PCK_IRS_BRDG.SP_CLEARBRDGORDALL
    }

    /* 返回桥单 */
    //TODO: OPEN OUT_BRDGORDRC FOR


    rc = GetBoundId(connId, &maxBoundId);
    RAISE_ERR(rc, RTN);
    pDealerUptResp->intMaxOutBoundId = maxBoundId;


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/* 桥授信修改 */
ResCodeT BridgeCreditModify(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp)
{
    BEGIN_FUNCTION( "BridgeCreditModify" );
    ResCodeT rc = NO_ERR;
    
    // vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    // vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};
    
    BrdgCreditModifyReqT* pCrdtModifyReq;
    BrdgCreditModifyRespT* pCrdtModifyResp;
    int32 v_OutOrgId;
    pBrdgOrgInfoT pBrdgOrgData;
    // OrgInfoBrdg orgInfoBrdgData;
    char sysUptDateStr[MAX_TIME_LEN];
    uint64 maxBoundId;
    BridgeUpdateDataRefT brdgUpdateRefData;
    
    
    pCrdtModifyReq = (BrdgCreditModifyReqT*)&pReq->msgBody[0];
    pCrdtModifyResp = (BrdgCreditModifyRespT*)&pRsp->msgBody[0];
    
    memset(pCrdtModifyResp, 0x00, sizeof(BrdgCreditModifyRespT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
    memset(&brdgUpdateRefData, 0x00, sizeof(BridgeUpdateDataRefT));
    
    /* 通用检查 */
    rc = CommonChk(pCrdtModifyReq->strUserId, C_ORG_NULL, pCrdtModifyReq->intFuncId,
                    pCrdtModifyReq->strToken, &v_OutOrgId);
    RAISE_ERR(rc, RTN);
    
    /* 更新桥机构信息 */
    // First, update the DB
    // memset(&orgInfoBrdgData, 0x00, sizeof(OrgInfoBrdg));
    
    /* Get current timestamp */
    // rc = GetCurrentTime(sysDateStr);
    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);
    
    brdgUpdateRefData.eMessageType = MSG_TYPE_BRIDGE_CREDIT_MODIFY;
    brdgUpdateRefData.intOrgId = v_OutOrgId;
    strcpy(brdgUpdateRefData.strUserId, pCrdtModifyReq->strUserId);
    strcpy(brdgUpdateRefData.strSysTime, sysUptDateStr);
    
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_BRIDGE_DAT, &brdgUpdateRefData, sizeof(BridgeUpdateDataRefT));
    RAISE_ERR(rc, RTN);
    
    // orgInfoBrdgData.orgId = v_OutOrgId;
    
    // DbCmmnSetColBit( keyVct, 1 );
    
    // sprintf(orgInfoBrdgData.crdtOprtngSt, "%d", C_CRT_OPERATING);
    // strcpy(orgInfoBrdgData.crdtOprtr, pCrdtModifyReq->strUserId);
    // sprintf(orgInfoBrdgData.brdgOrgSt, "%d", 0);
    // strcpy(orgInfoBrdgData.updTm, sysDateStr);
    // strcpy(orgInfoBrdgData.updUsrNm, pCrdtModifyReq->strUserId);
    
    // DbCmmnSetColBit( datVct, 13 );
    // DbCmmnSetColBit( datVct, 14 );
    // DbCmmnSetColBit( datVct, 2 );
    // DbCmmnSetColBit( datVct, 17 );
    // DbCmmnSetColBit( datVct, 18 );
    
    // rc = UpdateOrgInfoBrdgByKey(connId, &orgInfoBrdgData, keyVct, datVct);
    // RAISE_ERR(rc, RTN);
    
    // rc = DbCmmnCommit(connId);
    // RAISE_ERR(rc, RTN);
    
    // // Then, update the shared memory
    // rc = BrdgOrgInfoGetByIdExt(v_OutOrgId, &pBrdgOrgData);
    // RAISE_ERR(rc, RTN);
    
    // pBrdgOrgData->crdtOprtngSt = C_CRT_OPERATING;
    // strcpy(pBrdgOrgData->crdtOprtr, pCrdtModifyReq->strUserId);
    // pBrdgOrgData->brdgOrgSt = 0;

    
    // TODO: 
    // PCK_IRS_BRDG.SP_CLEARBRDGORDBYBRDGORG
    
    /* 返回桥单 */
    // TODO:
    // OPEN OUT_BRDGORDRC FOR
    
    
    rc = GetBoundId(connId, &maxBoundId);
    RAISE_ERR(rc, RTN);
    pCrdtModifyResp->intMaxOutBoundId = maxBoundId;


    EXIT_BLOCK();
    RETURN_RESCODE;
}


/* 桥授信解锁 */
static ResCodeT BridgeCreditUnlock(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int32           orgId,
            BridgeCreditDataRefT* pBrdgCrdtRefData)
{
    BEGIN_FUNCTION( "BridgeCreditUnlock" );
    ResCodeT rc = NO_ERR;
    BrdgCreditUpdateReqT* pCrdtUpdateReq;
    BrdgCreditUpdateRespT* pCrdtUpdateResp;
    short v_BrdgSt;
    BOOL hasOrgMktPrvlg;
    BOOL hasUsrMktPrvlg;
    pBrdgOrgInfoT pBrdgOrgData;
    uint64 maxBoundId;
    
    // vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    // vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};
    OrgInfoBrdg orgInfoBrdgData;
    // char sysDateStr[MAX_TIME_LEN];
    
    pCrdtUpdateReq = (BrdgCreditUpdateReqT*)&pReq->msgBody[0];
    pCrdtUpdateResp = (BrdgCreditUpdateRespT*)&pRsp->msgBody[0];
    
    memset(pCrdtUpdateResp, 0x00, sizeof(BrdgCreditUpdateRespT));
    
    rc = BrdgOrgInfoGetByIdExt(orgId, &pBrdgOrgData);
    RAISE_ERR(rc, RTN);
     
    /* 判断新值 */
    v_BrdgSt = 1;
    hasOrgMktPrvlg = FALSE;
    hasUsrMktPrvlg = FALSE;
    
    if (!(pBrdgOrgData->brdgPrvlgFlag == 1 && 
        pBrdgOrgData->brdgIntntnFlag == 1 &&
        strlen(pBrdgOrgData->usrLgnNm) != 0)){
        
        v_BrdgSt = 0;
    }
    
    /* Check the organization privilege */
    rc = IsAuthorizedInMarket(orgId, 1, &hasOrgMktPrvlg);
    RAISE_ERR(rc, RTN);
    
    if (hasOrgMktPrvlg == FALSE){
        v_BrdgSt = 0;
    }
    
    /* Check the user privilege */
    rc = IrsUsrMktStatusGet(pBrdgOrgData->usrLgnNm, 1, &hasUsrMktPrvlg);
    RAISE_ERR(rc, RTN);
    
    if (hasUsrMktPrvlg == FALSE){
        v_BrdgSt = 0;
    }
    
    pBrdgCrdtRefData->intBrdgSt = v_BrdgSt;
    
    /* 更新st */
    // First, update the DB
    // memset(&orgInfoBrdgData, 0x00, sizeof(OrgInfoBrdg));
    
    /* Get current timestamp */
    // rc = GetCurrentTime(sysDateStr);
    // RAISE_ERR(rc, RTN);
    
    // orgInfoBrdgData.orgId = orgId;
    
    // DbCmmnSetColBit( keyVct, 1 );
    
    // sprintf(orgInfoBrdgData.crdtOprtngSt, "%d", C_CRT_NONE);
    // if (pCrdtUpdateReq->intMdfyF == 0){
        // memset(orgInfoBrdgData.crdtOprtr, 0x00, 100);
    // }else{
        // strcpy(orgInfoBrdgData.crdtOprtr, pCrdtUpdateReq->strUserId);
    // }
    // sprintf(orgInfoBrdgData.brdgOrgSt, "%d", v_BrdgSt);
    // strcpy(orgInfoBrdgData.updUsrNm, pCrdtUpdateReq->strUserId);
    // strcpy(orgInfoBrdgData.updTm, sysDateStr);
    
    // DbCmmnSetColBit( datVct, 13 );
    // DbCmmnSetColBit( datVct, 14 );
    // DbCmmnSetColBit( datVct, 2 );
    // DbCmmnSetColBit( datVct, 17 );
    // DbCmmnSetColBit( datVct, 18 );

    // rc = UpdateOrgInfoBrdgByKey(connId, &orgInfoBrdgData,keyVct, datVct);
    // RAISE_ERR(rc, RTN);
    
    // rc = DbCmmnCommit(connId);
    // RAISE_ERR(rc, RTN);
    
    
    // Then, update the shared memory
    // pBrdgOrgData->crdtOprtngSt = C_CRT_NONE;
    // if (pCrdtUpdateReq->intMdfyF == 0){
        // memset(pBrdgOrgData->crdtOprtr, 0x00, CREDIT_OPERATOR_LENGTH);
    // }else{
        // strcpy(pBrdgOrgData->crdtOprtr, pCrdtUpdateReq->strUserId);
    // }
    // pBrdgOrgData->brdgOrgSt = v_BrdgSt;
    
    if (v_BrdgSt == 1){
        // TODO: PCK_IRS_BRDG.SP_CLEARBRDGORDALL
    }
    
    /* 返回桥单 */
    // TODO:  OPEN OUT_BRDGORDRC FOR
    
    
    rc = GetBoundId(connId, &maxBoundId);
    RAISE_ERR(rc, RTN);
    pCrdtUpdateResp->intMaxOutBoundId = maxBoundId;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


/* 桥授信更新 */
ResCodeT BridgeCreditUpdate(
            int32           connId,
            pIntrnlMsgT     pReq,
            pIntrnlMsgT     pRsp,
            int64           timestamp)
{
    BEGIN_FUNCTION( "BridgeCreditUpdate" );
    ResCodeT rc = NO_ERR;
    BrdgCreditUpdateReqT* pCrdtUpdateReq;

    // vectorT  keyVct[GET_BIT_VECT_LEN(11)] = {0};
    // vectorT  datVct[GET_BIT_VECT_LEN(11)] = {0};
    char sysDateStr[MAX_TIME_LEN];
    // CrdtBrdg crdtBrdgData;
    int32 infoSize;
    int32 v_OutOrgId;
    int32 index;
    BridgeCreditDataRefT brdgCrdtRefData;
    int32 refDataSize;
    
    pCrdtUpdateReq = (BrdgCreditUpdateReqT*)&pReq->msgBody[0];
    
    memset(sysDateStr, 0x00, sizeof(sysDateStr));
    memset(&brdgCrdtRefData, 0x00, sizeof(BridgeCreditDataRefT));
    
    /* 通用检查 */
    rc = CommonChk(pCrdtUpdateReq->strUserId, C_ORG_NULL, pCrdtUpdateReq->intFuncId,
                        pCrdtUpdateReq->strToken, &v_OutOrgId);
    RAISE_ERR(rc, RTN);
    
    /* Get current timestamp */
    // rc = GetCurrentTime(sysDateStr);
    rc = GetStrDateTimeByFormat(timestamp, sysDateStr);
    RAISE_ERR(rc, RTN);
    
    
    strcpy(brdgCrdtRefData.strUserId, pCrdtUpdateReq->strUserId);
    brdgCrdtRefData.intOrgId = v_OutOrgId;
    brdgCrdtRefData.intInfoCount = pCrdtUpdateReq->intInfoCount;
    brdgCrdtRefData.intModifyFlag = pCrdtUpdateReq->intMdfyF;
    strcpy(brdgCrdtRefData.strSysTime, sysDateStr);

    // DbCmmnSetColBit( keyVct, 1 );
    // DbCmmnSetColBit( keyVct, 2 );

    // DbCmmnSetColBit( datVct, 4 );
    // DbCmmnSetColBit( datVct, 5 );
    // DbCmmnSetColBit( datVct, 6 );
    // DbCmmnSetColBit( datVct, 9 );
    // DbCmmnSetColBit( datVct, 10 );
    
    infoSize = pCrdtUpdateReq->intInfoCount;
    for (index = 0; index < infoSize; index++){
        /* Fill the detail datas in BridgeCreditDataRefT with the datas in pCrdtUpdateReq */
        if (strlen(pCrdtUpdateReq->brdgCrdtInfo[index].strBrdgFee) == 0){
            RAISE_ERR(ERR_CODE_INVLD_BRDG_FEE, RTN);
        }
            
        brdgCrdtRefData.brdgCrdtDetail[index].intOpOrgId = pCrdtUpdateReq->brdgCrdtInfo[index].intOpOrgId;
        brdgCrdtRefData.brdgCrdtDetail[index].intCrdtRlf = pCrdtUpdateReq->brdgCrdtInfo[index].intCrdtRlf;
        strcpy(brdgCrdtRefData.brdgCrdtDetail[index].strBrdgFee, pCrdtUpdateReq->brdgCrdtInfo[index].strBrdgFee);
        brdgCrdtRefData.brdgCrdtDetail[index].intTerm = pCrdtUpdateReq->brdgCrdtInfo[index].intTerm;
        
    }
    
    // rc = DbCmmnCommit(connId);
    // RAISE_ERR(rc, RTN);
    rc = BridgeCreditUnlock(connId, pReq, pRsp, v_OutOrgId, &brdgCrdtRefData);
    RAISE_ERR(rc, RTN);
    
    // Calculate the size of common data
    refDataSize = sizeof(brdgCrdtRefData.strUserId);
    refDataSize += sizeof(brdgCrdtRefData.intOrgId) + sizeof(brdgCrdtRefData.intInfoCount); 
    refDataSize += sizeof(brdgCrdtRefData.intModifyFlag) + sizeof(brdgCrdtRefData.intBrdgSt);
    refDataSize += sizeof(brdgCrdtRefData.strSysTime);
    // Calculate the size of detail data and get the total size.
    refDataSize += infoSize*sizeof(BridgeCreditDetailT);
    
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_BRIDGE_CREDIT_DAT, &brdgCrdtRefData, refDataSize);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}



/* 桥百分比设置 */
ResCodeT BridgePercentageUpdate(int32 connId, pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp)
{
    BEGIN_FUNCTION( "BridgePercentageUpdate" );
    ResCodeT rc = NO_ERR;
    
    // vectorT  keyVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    // vectorT  datVctBaseParam[GET_BIT_VECT_LEN(8)] = {0};
    // BaseParam updData = {0};
    
    BrdgPercentageUpdateReqT *pBrdgPrcntgUpdReq;
    BrdgPercentageUpdateRespT *pBrdgPrcntgUpdResp;
    
    BridgeCwDataRefT brdgCwRefData;
    // pBaseParamT pBaseParamData;
    char sysUptDateStr[MAX_TIME_LEN];
    uint64 maxBoundId;
    
    pBrdgPrcntgUpdReq = (BrdgPercentageUpdateReqT*)&pReq->msgBody[0];
    pBrdgPrcntgUpdResp = (BrdgPercentageUpdateRespT*)&pRsp->msgBody[0];
    
    memset(pBrdgPrcntgUpdResp, 0x00, sizeof(BrdgPercentageUpdateRespT));
    memset(sysUptDateStr, 0x00, sizeof(sysUptDateStr));
    memset(&brdgCwRefData, 0x00, sizeof(BridgeCwDataRefT));

    /* Get current timestamp */
    // rc = GetCurrentTime(sysUptDateStr);
    rc = GetStrDateTimeByFormat(timestamp, sysUptDateStr);
    RAISE_ERR(rc, RTN);
    
    strcpy(brdgCwRefData.strBrdgFlag, pBrdgPrcntgUpdReq->strBrdgFlag);
    strcpy(brdgCwRefData.strBrdgPercentage, pBrdgPrcntgUpdReq->strBrdgPercentage);
    strcpy(brdgCwRefData.strBrdgTime, pBrdgPrcntgUpdReq->strBrdgReturn);
    strcpy(brdgCwRefData.strSysTime, sysUptDateStr);
    
    rc = RefDatUpdtCmmn(REF_TYP_UPDT_BRIDGE_PARAM_DAT, &brdgCwRefData, sizeof(BridgeCwDataRefT));
    RAISE_ERR(rc, RTN);
    /* First, update the values in the DB */
    // DbCmmnSetColBit( keyVctBaseParam, 1 );
                
    // DbCmmnSetColBit( datVctBaseParam, 2 );
    // DbCmmnSetColBit( datVctBaseParam, 5 );
    // DbCmmnSetColBit( datVctBaseParam, 6 );
    
    // /* 搭桥开关 */
    // memset(&updData, 0x00, sizeof(BaseParam));

    // strcpy(updData.paramNm, C_BRDG_BRIDGEFLAG);
    // strcpy(updData.paramVl, pBrdgPrcntgUpdReq->strBrdgFlag);
    // strcpy(updData.updUsrNm, USER_NAME_EMERGENCY);
    // strcpy(updData.updTm, sysUptDateStr);
    
    // rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
    // RAISE_ERR(rc, RTN);

    // /* 搭桥百分比 */
    // memset(&updData, 0x00, sizeof(BaseParam));

    // strcpy(updData.paramNm, C_BRDG_BRIDGEPERCENT);
    // strcpy(updData.paramVl, pBrdgPrcntgUpdReq->strBrdgPercentage);
    // strcpy(updData.updUsrNm, USER_NAME_EMERGENCY);
    // strcpy(updData.updTm, sysUptDateStr);
    
    // rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
    // RAISE_ERR(rc, RTN);
    
    // /* 搭桥持续时间 */
    // memset(&updData, 0x00, sizeof(BaseParam));

    // strcpy(updData.paramNm, C_BRDG_BRIDGETIME);
    // strcpy(updData.paramVl, pBrdgPrcntgUpdReq->strBrdgReturn);
    // strcpy(updData.updUsrNm, USER_NAME_EMERGENCY);
    // strcpy(updData.updTm, sysUptDateStr);
    
    // rc = UpdateBaseParamByKey(connId, &updData, keyVctBaseParam, datVctBaseParam);
    // RAISE_ERR(rc, RTN);
    
    // rc = DbCmmnCommit(connId);
    // RAISE_ERR(rc, RTN);
    
    
    /* Second, update the values in the shared memory */
    // rc = BaseParamGetByNameExt((char*)C_BRDG_BRIDGEFLAG, &pBaseParamData);
    // RAISE_ERR(rc, RTN);
    // strcpy(pBaseParamData->paramValue, pBrdgPrcntgUpdReq->strBrdgFlag);
    
    // rc = BaseParamGetByNameExt((char*)C_BRDG_BRIDGEPERCENT, &pBaseParamData);
    // RAISE_ERR(rc, RTN);
    // strcpy(pBaseParamData->paramValue, pBrdgPrcntgUpdReq->strBrdgPercentage);
    
    // rc = BaseParamGetByNameExt((char*)C_BRDG_BRIDGETIME, &pBaseParamData);
    // RAISE_ERR(rc, RTN);
    // strcpy(pBaseParamData->paramValue, pBrdgPrcntgUpdReq->strBrdgReturn);
    
    if (strcmp(pBrdgPrcntgUpdReq->strBrdgFlag, "N") == 0){
        // TODO: 
        // Pck_Irs_Brdg.sp_ClearBrdgOrdAll
    }

    
    /* 返回BoundId */
    rc = GetBoundId(connId, &maxBoundId);
    RAISE_ERR(rc, RTN);
    pBrdgPrcntgUpdResp->intMaxOutBoundId = maxBoundId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}
