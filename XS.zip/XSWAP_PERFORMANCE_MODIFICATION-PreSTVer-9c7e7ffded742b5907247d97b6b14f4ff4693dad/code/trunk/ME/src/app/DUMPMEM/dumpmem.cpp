﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/
#ifndef _DUMPMEM_
#define _DUMPMEM_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "common_hash.h"
#include "optlib.h"
#include "err_lib.h"
#include "err_cod.h"
#include "uti_tool.h"
#include "match_lib.h"
#include "ref_dat_updt.h"
#include "dump_ord.h"
#include "mem_txn.h"
#include "cfg_lib.h"
#include "monitor_thread.h"
#include "usr.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/



int32 main(int argc, char* argv[])
{
    BEGIN_FUNCTION("main");
    ResCodeT rc = NO_ERR;
    
    int32           op;
    int32           txnId = 0;
    int32           runMark = MEM_TXN_DUMP_TO_DB_RUN;
    
    cfgValueS       cfgValue = {0};
    char            cgv[10] = {0};
    char            prcsName[] = "";
    
    PrcsInit(prcsName);
    
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc,RTN);
    
    rc = DumpOrdInit(cfgValue.setId);
    RAISE_ERR(rc,RTN);
    
    rc = MonThreadShmAttach();
    RAISE_ERR(rc,RTN);
    
    rc = PrdctInfoAttachToShm();
    RAISE_ERR(rc,RTN);

    
    MatchingDumptxnThread((void*)&runMark);
    
    
    runMark = MEM_TXN_DUMP_TO_DB_END;

    EXIT_BLOCK();
    RETURN_RESCODE;

}


#endif /* _DUMPMEM_ */ 