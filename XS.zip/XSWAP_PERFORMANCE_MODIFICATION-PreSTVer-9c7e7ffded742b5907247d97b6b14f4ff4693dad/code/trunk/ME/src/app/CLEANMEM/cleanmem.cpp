﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Project Header files*/
#include "data_type.h"
#include "err_lib.h"

#include "shm.h"


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
int32 main(int argc, char* argv[])
{
    ResCodeT rc = NO_ERR;
    char prcsId[10] = {0};
    char tmpPath[1024] =  {0};
    
    if (argc < 2)
    {
        printf(" Usage ./CLEANMEM [shmPath] [prcsId] \n");
        printf(" Eg ./CLEANMEM ../tmp/ 01\n");
        return NO_ERR;
    }

    strcpy(tmpPath, argv[1]);
    

    if (argc > 2)
    {
        sprintf(prcsId,"P%s",argv[2] );
    }
        
    
    
    rc = ShmDeleteByPid(tmpPath, "", prcsId);
    if (rc != NO_ERR)
    {
        printf(" Failed to delete memory \n");
        return NO_ERR;
    }

    return NO_ERR;
}
