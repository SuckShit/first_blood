﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/
#ifndef _SHOWMEM_
#define _SHOWMEM_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "common_hash.h"
#include "optlib.h"
#include "err_lib.h"
#include "showmem.h"
#include "uti_tool.h"
#include "match_lib.h"
#include "ref_dat_updt.h"
#include "org_info.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MEM_TXN_SET_ID    1
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct MemTxnCtxS {
    int32   setID;
    int32   txnID;
    int32   startId;
    int32   endTxnId;
    int32   prdctId;
    int32   slotId;
    int32   orgIdA;
    int32   orgIdB;
    int32   orgBrdgId;
    int32   orgBrdgOpId;
    vectorT serverFlag;                       // indicate which server SHOWMEM is running on (ME or TDPS)
    char    prdctName[PRDCT_NAME_LENGTH];
    char    paramName[PARAM_NAME_LENGTH];
}MemTxnCtxT, *pMemTxnCtxT;


static OpEntryT g_showallOps[MAX_OPS][MAX_ENTRY] = {
 
    { {(char*)"help", 0}},
    { {(char*)"crdt", 0},{(char*)"orga", MSK_VAL|MSK_DEF},{(char*)"orgb", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"memtxn", 0},{(char*)"txn", MSK_VAL|MSK_DEF},{(char*)"start", MSK_VAL|MSK_DEF},{(char*)"end", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"msgcnt", 0},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"prd", 0},{(char*)"name", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"bg", 0},{(char*)"set", MSK_VAL|MSK_DEF},{(char*)"prdct", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"ordbk", 0},{(char*)"set", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"ordmgmt", 0},{(char*)"set", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"ordno", 0},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"brdgord", 0},{(char*)"set", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"param", 0},{(char*)"pmname", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"orgbrdg", 0},{(char*)"obid", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"crdtbrdg", 0},{(char*)"obid", MSK_VAL|MSK_DEF},{(char*)"obopid", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}},
    { {(char*)"monitor", 0}},
    { {(char*)"showall", 0},{(char*)"set", MSK_VAL|MSK_DEF},{(char*)"s", MSK_VAL|MSK_DEF}}
};

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static MemTxnCtxT gMemTxnCtx ={0};
FILE* gOutFile ;
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT PrintOrdrF(pOrderFT  pOrderF);
ResCodeT PrintOrdrT(pOrderTT  pOrderTIn);
ResCodeT PrintOrderF4PrcLeadS(pOrderF4PrcLeadT pOrderF4PrcLead);
ResCodeT PrintOrderT4PrcLeadS(pOrderT4PrcLeadT pOrderT4PrcLead);
 
static ResCodeT ParseOption(int argc, char** argv,
                    OpEntryT options[MAX_OPS][MAX_ENTRY])
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("ParseOption");
    char* key = NULL;
    char* value = NULL;
 
    // set the default value of serverFlag
    gMemTxnCtx.serverFlag = SHOWMEM_OPT_ME;
    
    while (GetNextOption(argc, argv, options, &key, &value))
    {
        
        if ( !strcmp(key, "set"))
        {
            gMemTxnCtx.setID = atoi(value);
        }
        else if (!strcmp(key, "txn"))
        {
            gMemTxnCtx.txnID = atoi(value);
        }
        else if (!strcmp(key, "start"))
        {
            gMemTxnCtx.startId = atoi(value);
        }
        else if (!strcmp(key, "end"))
        {
            gMemTxnCtx.endTxnId = atoi(value);
        }
        else if (!strcmp(key, "prdct"))
        {
            gMemTxnCtx.prdctId = atoi(value);
        }
        else if (!strcmp(key, "slot"))
        {
            gMemTxnCtx.slotId = atoi(value);
        }
        else if (!strcmp(key, "orga"))
        {
            gMemTxnCtx.orgIdA = atoi(value);
        }
        else if (!strcmp(key, "orgb"))
        {
            gMemTxnCtx.orgIdB = atoi(value);
        }
        else if ( !strcmp(key, "name") )
        {
            strcpy(gMemTxnCtx.prdctName, value);
        }
        else if ( !strcmp(key, "pmname") )
        {
            strcpy(gMemTxnCtx.paramName, value);
        }
        else if ( !strcmp(key, "obid") )
        {
            gMemTxnCtx.orgBrdgId = atoi(value);
        }
        else if ( !strcmp(key, "obopid") )
        {
            gMemTxnCtx.orgBrdgOpId = atoi(value);
        }
        else if ( !strcmp(key, "s") )
        {
            if ( !strcmp("TDPS", value)){
                gMemTxnCtx.serverFlag = SHOWMEM_OPT_TDPS;
            }else{
                gMemTxnCtx.serverFlag = SHOWMEM_OPT_ME;
            }
        }
    }
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}




static ResCodeT PrintDataOrdr()
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("PrintDataOrdr");
    pOrderT     pCurOrdr = NULL;
    BOOL        bReset = TRUE;
    
    while (1)
    {
        rc = OrdBkGetUsedOrdr(bReset,  MEM_TXN_SET_ID, &pCurOrdr);
        if ( ERR_OBK_SET_ODRBK_FULL == rc )
        {
        break;
        }
        else
        {
        RAISE_ERR(rc,RTN);
        }
        bReset = FALSE;
        
        if (!pCurOrdr->orderF.ordrNo)
        {
            continue;
        }
        
        if (pCurOrdr->orderT.priceLdr == NULL_SLOT)
        {
            PrintOrderF4PrcLeadS((pOrderF4PrcLeadT)&pCurOrdr->orderF);
            PrintOrderT4PrcLeadS((pOrderT4PrcLeadT)&pCurOrdr->orderT);
            printf("\n");
        }
        else
        {
            PrintOrdrF(&pCurOrdr->orderF);
            PrintOrdrT(&pCurOrdr->orderT);
            printf("\n");
        }
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

void Usage()
{
    fprintf(gOutFile, "Usage: ShowMEM\n");
    fprintf(gOutFile, "\t-help to get help\n");
    fprintf(gOutFile, "\tcfgpath -crdt -orga [orgId] -orgb [orgId] to get credit info of a->b and b->a\n");
    fprintf(gOutFile, "\tcfgpath -memtxn -txn [txnId] -start [sttId] -end [endId]  to show memtxn info \n");
    fprintf(gOutFile, "\tcfgpath -msgcnt for message count information\n");
    fprintf(gOutFile, "\tcfgpath -prd -set [setId] -name [prdctName] for product information\n");
    fprintf(gOutFile, "\tcfgpath -bg -set [setId] -name [prdctId] for getting bstGroup in orderbook\n");
    fprintf(gOutFile, "\tcfgpath -ordbk -set [setId] for showing all orders in orderbook of set 'setId'\n");
    fprintf(gOutFile, "\tcfgpath -ordmgmt -set [setId] for showing order mgmt information\n");
    fprintf(gOutFile, "\tcfgpath -ordno [instId] for instrument information\n");
    fprintf(gOutFile, "\tcfgpath -brdgord [instId] for showing bridge ordr mgmt informationn\n");
    fprintf(gOutFile, "\tcfgpath -param -pmname [paramName] for showing the value of the parameter\n");
    fprintf(gOutFile, "\tcfgpath -orgbrdg -obid [orgBridgeId] for showing the bridge organization information\n");
    fprintf(gOutFile, "\tcfgpath -crdtbrdg -obid [orgBridgeId] -obopid [orgBrdgOpponentId] for showing the bridge credit info of obid->obopid\n");
    fprintf(gOutFile, "\tcfgpath -showall -set [setId] for getting all memtxn, all orders and all order mgmt info\n");
    fprintf(gOutFile, "\tcfgpath -monitor for service thread status\n");
    fprintf(gOutFile, "\n");
    fprintf(gOutFile, "\t*** Option -s can be added to above commands to indicate which server ShowMEM is running on.\n");
    fprintf(gOutFile, "\t       eg. SHOWMEM -msgcnt -s TDPS. Default is ME. \n");
    exit (0);
}


static ResCodeT PrintMsgCount()
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("MsgCount");
    
    int32 msgMaxCnt;
    int32 msgUsedCnt;
    int32 msgLeftCnt;
    rc = GetMsgCount(&msgMaxCnt, &msgUsedCnt);
    RAISE_ERR(rc,RTN);
    printf("Max: %d, used: %d, left: %d\n",msgMaxCnt,msgUsedCnt,msgMaxCnt-msgUsedCnt);
 
    EXIT_BLOCK();
    RETURN_RESCODE;
}

/******************************************************************************
 * Description:   print all txn information
 * Parameters:
 *      set         IN  set value
 *      txnId       IN  txn ID
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintMemTxnGetTxnBaseInfo(int32 set, int32 txnId)
{
    BEGIN_FUNCTION("PrintMemTxnGetTxnBaseInfo");
   
    ResCodeT rc = NO_ERR;
    MemTxnCtrlT TxnCtrl_out;
    MemTxnEntryT TxnEntry_out;
    char date[150] = {0};
    char time[150]= {0};
    
    MemTxnGetTxnInfo(set, txnId, &TxnCtrl_out, &TxnEntry_out);
    
    GetStrDateTime(TxnEntry_out.timestamp, date, time);//Turn timestamp into date and time.
    
    printf("TXN %d|DatCnt %d|FrstDat %d|LstDat %d|Time %s %s\n",
    TxnEntry_out.txnId, TxnEntry_out.dataCnt, TxnEntry_out.frstDataSqno, 
    TxnEntry_out.lstDataSqno, date, time);

    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   print all txn information
 * Parameters:
 *      set         IN  set value
 *      txnId       IN  txn ID
 *      N/A         OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintMemTxnGetTxnInfo(int32 set, int32 txnId)
{
    BEGIN_FUNCTION("PrintMemTxnGetTxnInfo");
   
    ResCodeT rc = NO_ERR;
    MemTxnCtrlT TxnCtrl_out;
    MemTxnEntryT TxnEntry_out;
    char date[150];
    char time[150];
    
    MemTxnGetTxnInfo(set, txnId, &TxnCtrl_out, &TxnEntry_out);
    
    GetStrDateTime(TxnEntry_out.timestamp, date, time);//Turn timestamp into date and time.
    
    printf("set %d,txn %d,currTxn %d,cmitTxn %d,maxTxn %d,currDat %d, maxDat %d, elemCnt %d\n", set, 
    txnId, TxnCtrl_out.currTxnId, TxnCtrl_out.commitTxnId, TxnCtrl_out.maxTxnId, TxnCtrl_out.currDataCnt, 
    TxnCtrl_out.maxDataCnt, TxnCtrl_out.elemCnt);
    
    printf("txnSts %d,datCnt %d,frstDat %d,lstDat %d,datTim %s %s.\n", 
    TxnEntry_out.txnSts, TxnEntry_out.dataCnt, TxnEntry_out.frstDataSqno, 
    TxnEntry_out.lstDataSqno, date, time);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



/******************************************************************************
 * Description:   print order information based on order mask
 * Parameters:
 *      oMask       IN  order mash value
 *      *side       OUT 
 *      *trdrestr   OUT  
 *      *type       OUT 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintOrderInformation(int32 oMask, char *side, char *trdrestr, char *type)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("PrintOrderInformation");
    
    GetOrderSide(oMask, side);
    GetTradingRestriction(oMask, trdrestr);
    GetOrderType(oMask, type);
    
    EXIT_BLOCK();
    RETURN_RESCODE; 
}


ResCodeT PrintOrdrF(pOrderFT  pOrderF)
{
    pMDelOrdrT      pDelOrdAddr  = NULL;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
    
    printf("OrdrF, ");
    printf("oNo %lld, ",pOrderF->ordrNo);
    printf("prdct %ld, ",pOrderF->prdctId);
    printf("oExePrc %lld, ",pOrderF->ordrExePrc);
    printf("oQty %ld, ",pOrderF->ordrQty);
    printf("remQty %lld, ",pOrderF->remPkQty);
    printf("oExeQty %lld, ",pOrderF->ordrExeQty);
    printf("oAppPrc %lld, ",pOrderF->ordrApplyPrc);
    printf("oMtchPrc %lld,",pOrderF->ordrMtchPrc);
    printf("spNo %lld, ",pOrderF->specOrdrNo);
    printf("extTyp %lld, ",pOrderF->extOrdrType);
    PrintOrderInformation(pOrderF->ordrMask,side,trdrestr,type);
    printf("oMask %s,",side);
    printf("%s,",trdrestr);
    printf("%s \n",type);
    
    timestampIn = pOrderF->ordrEntTim;
    GetStrDateTime(timestampIn,date,time);
    printf("        oEntT %s %s, ",date,time);
    timestampIn = pOrderF->ordrExpTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oExpT %s %s, ",date,time);
    timestampIn = pOrderF->tranTime;
    GetStrDateTime(timestampIn,date,time);
    printf("tranT %s %s, ",date,time);
    timestampIn = pOrderF->ordrActiveTim;
    GetStrDateTime(timestampIn,date,time);
    printf("actvT %s %s, ",date,time);
    printf("entyIdxNo %ld, ",pOrderF->entyIdxNo);
    printf("userIdx %ld, ",pOrderF->userIdx);
    printf("extOType %ld, ",pOrderF->extOrdrType);
    printf("oSts %d, ",pOrderF->ordrSts);
    printf("brdgFee %ld, ",pOrderF->brdgFee);
    printf("execInst %d, ",pOrderF->execInst);
    printf("oAct %ld\n",pOrderF->ordAct);
   
}



ResCodeT PrintOrdrT(pOrderTT  pOrderTIn)
{
    printf("OrdrT, ");
    printf("unrONxt %d, ",(int32)pOrderTIn->unrO.next);
    printf("unrOPre %d, ",(int32)pOrderTIn->unrO.prev);
    printf("unrAuONxt %d, ",(int32)pOrderTIn->unrAuO.next);
    printf("unrAuOPre %d, ",pOrderTIn->unrAuO.prev);
    printf("unrAuOaONxt %d, ",pOrderTIn->unrAuOaO.next);
    printf("unrAuOaOPre %d, ",pOrderTIn->unrAuOaO.prev);
    printf("oExePrcNxt %d, ",pOrderTIn->ordNo.next);
    printf("oExePrcPre %d, ",pOrderTIn->ordNo.prev);
    printf("entyNoNxt %d, ",pOrderTIn->entyNo.next);
    printf("entyNoPre %d, ",pOrderTIn->entyNo.prev);
    printf("priceLdr %ld,",pOrderTIn->priceLdr);
    printf("slotNo %ld,",pOrderTIn->slotNo);
    printf("free %ld,",pOrderTIn->free);
    printf("sltOpen %ld \n",pOrderTIn->sltOpen);
    
}



ResCodeT PrintOrderF4PrcLeadS(pOrderF4PrcLeadT pOrderF4PrcLead)
{
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
    
    printf("OrdrF4PrcLd,");
    printf("ordrExePrc %lld,",pOrderF4PrcLead->ordrExePrc);
    printf("prdctId %ld,",pOrderF4PrcLead->prdctId);
    printf("ordrNo %lld,",pOrderF4PrcLead->ordrNo);
    printf("ordrPri %lld,",pOrderF4PrcLead->ordrPri);
    printf("SrtngType %ld,",pOrderF4PrcLead->odrBkSortingType);
    printf("cntUnrO %ld,",pOrderF4PrcLead->cntUnrO);
    printf("totUnrO %ld,",pOrderF4PrcLead->totUnrO);
    printf("cntUnrAuO %ld,",pOrderF4PrcLead->cntUnrAuO);
    printf("totUnrAuO %ld,",pOrderF4PrcLead->totUnrAuO);
    printf("cntUnrAuOaO %ld,",pOrderF4PrcLead->cntUnrAuOaO);
    printf("totUnrAuOaO %ld,",pOrderF4PrcLead->totUnrAuOaO);
    PrintOrderInformation(pOrderF4PrcLead->ordrMask,side,trdrestr,type);
    printf("oMask %s,",side);
    printf("trdrestr %s,",trdrestr);
    printf("%s\n",type);
    
}



ResCodeT PrintOrderT4PrcLeadS(pOrderT4PrcLeadT pOrderT4PrcLead)
{
    printf("OrdrT4PrcLd,");
    printf("unrONex %d,",pOrderT4PrcLead->unrO.next);
    printf("unrOPre %d,",pOrderT4PrcLead->unrO.prev);
    printf("unrAuONex %d,",pOrderT4PrcLead->unrAuO.next);
    printf("unrAuOPre %d,",pOrderT4PrcLead->unrAuO.prev);
    printf("unrAuOaONex %d,",pOrderT4PrcLead->unrAuOaO.next);
    printf("unrAuOaOPre %d,",pOrderT4PrcLead->unrAuOaO.prev);
    printf("oExePrcNex %d,",pOrderT4PrcLead->ordNo.next);
    printf("oExePrcPre %d,",pOrderT4PrcLead->ordNo.prev);
    printf("entyNoNex %d,",pOrderT4PrcLead->entyNo.next);
    printf("entyNoPre %d,",pOrderT4PrcLead->entyNo.prev);
    printf("priceLdr %ld,",pOrderT4PrcLead->priceLdr);
    printf("slotNo %ld,",pOrderT4PrcLead->slotNo);
    printf("prcLderNxt %d,",pOrderT4PrcLead->prcLder.next);
    printf("prcLderPre %d\n",pOrderT4PrcLead->prcLder.prev);
    //printf("free %ld\n",pOrderT4PrcLead->free);
    
}




/******************************************************************************
 * Description:   print all order logs
 * Parameters:
 *      dataLenIn   IN 
 *      elemTypeIn  IN  
 *      *pDataIn    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintOrdrLog(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintOrdrLog");
    ResCodeT rc = NO_ERR;
  
    pMLogOrdrT      pLogOrdrAddr;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
    pLogOrdrAddr = (pMLogOrdrT)pDataIn;
    
    printf("ODR_LOG|");   
    printf("Len %ld, ",dataLenIn);

    PrintOrdrF(&pLogOrdrAddr->ordr);
    printf("        oNoOld %lld,",pLogOrdrAddr->mtchInfo.ordrNoOld);
    printf("trdPrc %lld,",pLogOrdrAddr->mtchInfo.tradePrc);
    printf("actnNo %lld,",pLogOrdrAddr->mtchInfo.actnSeqNum);
    printf("oPrtFil %d,",pLogOrdrAddr->mtchInfo.ordrPrtFilCod);
    printf("slot %ld,",pLogOrdrAddr->slot);
    printf("actnMsk %d\n",pLogOrdrAddr->actnMask);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   print all order add
 * Parameters:
 *      dataLenIn   IN 
 *      elemTypeIn  IN  
 *      *pDataIn    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintOdrAdd(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintOdrAdd");
    ResCodeT rc = NO_ERR;
  
    pMAddOrdrT      pAddOrdrAddr = NULL;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
    
    pAddOrdrAddr = (pMAddOrdrT)pDataIn;
    
    printf("ODR_ADD|");
    printf("Len %ld, ",dataLenIn);
    
    PrintOrdrF(&pAddOrdrAddr->ordr);
                
    printf("        oNoOld %lld, ",pAddOrdrAddr->mtchInfo.ordrNoOld);
    printf("trdPrc %lld, ",pAddOrdrAddr->mtchInfo.tradePrc);
    printf("actnNo %lld, ",pAddOrdrAddr->mtchInfo.actnSeqNum);
    printf("oPrtFil %d, ",pAddOrdrAddr->mtchInfo.ordrPrtFilCod);        
    printf("slot %ld, ",pAddOrdrAddr->slot);
                
    printf("oldHldMsk %d, ",pAddOrdrAddr->oldHldMask);        
    printf("actnMsk %d, ",pAddOrdrAddr->actnMask);         
    printf("fNewPrcLder %d\n",pAddOrdrAddr->fNewPrcLder);
      
   
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   print all order del
 * Parameters:
 *      dataLenIn   IN 
 *      elemTypeIn  IN  
 *      *pDataIn    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintOrdDel(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintOrdDel");
    ResCodeT rc = NO_ERR;
  
    pMDelOrdrT      pDelOrdAddr  = NULL;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
    pDelOrdAddr = (pMDelOrdrT)pDataIn;
    
    printf("ORD_DEL|");
    
    printf("Len %ld, ",dataLenIn);
    
    PrintOrdrF(&pDelOrdAddr->orderF);
                
    printf("        oNoOld %lld, ",pDelOrdAddr->mtchInfo.ordrNoOld); 
    printf("tradPrc %lld, ",pDelOrdAddr->mtchInfo.tradePrc);
    printf("actnNo %lld,",pDelOrdAddr->mtchInfo.actnSeqNum);
    printf("oPrtFil %d, ",pDelOrdAddr->mtchInfo.ordrPrtFilCod);
                
    timestampIn = pDelOrdAddr->tranTime;
    GetStrDateTime(timestampIn,date,time);
    printf("tranT %s %s,",date,time);          
    printf("slot %ld, ",pDelOrdAddr->slot);             
    printf("actnMsk %d\n",pDelOrdAddr->actnMask);
  
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}

  
/******************************************************************************
 * Description:   print all trade logs
 * Parameters:
 *      dataLenIn   IN 
 *      elemTypeIn  IN  
 *      *pDataIn    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintTrdLog(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintTrdLog");
    ResCodeT rc = NO_ERR;
  
    pMLogTrdT       pLogTrdAddr  = NULL;
    pMDelOrdrT      pDelOrdAddr  = NULL;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    
    printf("TRD_LOG|");    
    printf("Len %ld,",dataLenIn);
    
    pLogTrdAddr = (pMLogTrdT)pDataIn;
    printf("prdId %lld, ",pLogTrdAddr->trade.prdctId);
    printf("traIdNo %lld, ",pLogTrdAddr->trade.tranIdNo);
    printf("oNo %lld, ",pLogTrdAddr->trade.ordrNo);
    printf("tradMtchPrc %lld,",pLogTrdAddr->trade.tradMtchPrc);
    printf("trdQty %lld,",pLogTrdAddr->trade.trdQty);
    printf("oExeQty %lld,",pLogTrdAddr->trade.ordrExeQty);
    printf("oExePrc %lld, ",pLogTrdAddr->trade.ordrExePrc);
    printf("oPrtFilCod %d",pLogTrdAddr->trade.ordrPrtFilCod);
    timestampIn = pLogTrdAddr->trade.tranDatTim;
    GetStrDateTime(timestampIn,date,time);
    printf("trnDatT %s %s \n",date,time);
    printf("        oldOrdNo %d,",pLogTrdAddr->oldOrdrNo);
    printf("actnMsk %d\n",pLogTrdAddr->actnMask);
  
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   print all order mods
 * Parameters:
 *      dataLenIn   IN 
 *      elemTypeIn  IN  
 *      *pDataIn    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintOrdMod(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintOrdMod");
    ResCodeT rc = NO_ERR;
  
    pMModOrdrT      pModOrdrAddr = NULL;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
    
    printf("ODR_MOD|");
    printf("Len %ld,",dataLenIn);
    
    pModOrdrAddr = (pMModOrdrT)pDataIn;
    printf("slot %ld,",pModOrdrAddr->slot);
    printf("oldPrcLder %ld,",pModOrdrAddr->oldPrcLder);
    printf("newPrcLder %ld,",pModOrdrAddr->newPrcLder);
    printf("actnMask %d,",pModOrdrAddr->actnMask);
    printf("fNewPrcLder %d,",pModOrdrAddr->fNewPrcLder);
                
    printf("oExePrc %lld,",pModOrdrAddr->oldOrdr.ordrExePrc);
    printf("oNo %lld,",pModOrdrAddr->oldOrdr.ordrNo);
    timestampIn = pModOrdrAddr->oldOrdr.ordrEntTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oEntTim %s %s,",date,time);
    timestampIn = pModOrdrAddr->oldOrdr.ordrExpTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oExpT %s %s,",date,time);
    timestampIn = pModOrdrAddr->oldOrdr.tranTime;
    GetStrDateTime(timestampIn,date,time);
    printf("tranT %s %s|\n",date,time);
    printf("       oQty %ld,",pModOrdrAddr->oldOrdr.ordrQty);
    printf("remPkQty %lld,",pModOrdrAddr->oldOrdr.remPkQty);
    printf("Id %ld,",pModOrdrAddr->oldOrdr.prdctId);
    printf("entyIdxNo %ld,",pModOrdrAddr->oldOrdr.entyIdxNo);
    printf("oExeQty %lld",pModOrdrAddr->oldOrdr.ordrExeQty);
    printf("oAppPrc %lld,",pModOrdrAddr->oldOrdr.ordrApplyPrc);
    printf("oMtchPrc %lld,",pModOrdrAddr->oldOrdr.ordrMtchPrc);
    printf("extOrdTyp %ld,",pModOrdrAddr->oldOrdr.extOrdrType);
    printf("oSts %d,",pModOrdrAddr->oldOrdr.ordrSts);
    printf("brdgFe %ld,",pModOrdrAddr->oldOrdr.brdgFee);
    PrintOrderInformation(pModOrdrAddr->oldOrdr.ordrMask,side,trdrestr,type);
    printf("oMask %s,",side);
    printf("%s,",trdrestr);
    printf("%s,",type);
    printf("execInst %d|\n",pModOrdrAddr->oldOrdr.execInst);
    printf("       useIdx %ld,",pModOrdrAddr->oldOrdr.userIdx);
    printf("oAct %ld,",pModOrdrAddr->oldOrdr.ordAct);
                
    printf("oExePrc %lld,",pModOrdrAddr->newOrdr.ordrExePrc);
    printf("oNo %lld,",pModOrdrAddr->newOrdr.ordrNo);
    timestampIn = pModOrdrAddr->newOrdr.ordrEntTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oEntT %s %s,",date,time);
    timestampIn = pModOrdrAddr->newOrdr.ordrExpTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oExpT %s %s,",date,time);
    timestampIn = pModOrdrAddr->newOrdr.tranTime;
    GetStrDateTime(timestampIn,date,time);
    printf("traT %s %s,",date,time);
    printf("oQty %ld,",pModOrdrAddr->newOrdr.ordrQty);
    printf("remPkQty %lld,",pModOrdrAddr->newOrdr.remPkQty);
    printf("prdId %ld,",pModOrdrAddr->newOrdr.prdctId);
    printf("entyIdxNo %ld,",pModOrdrAddr->newOrdr.entyIdxNo);
    printf("oExeQty %lld|\n",pModOrdrAddr->newOrdr.ordrExeQty);
    printf("       oAppPrc %lld,",pModOrdrAddr->newOrdr.ordrApplyPrc);
    printf("oMtchPrc %lld,",pModOrdrAddr->newOrdr.ordrMtchPrc);
    printf("extOTyp %ld,",pModOrdrAddr->newOrdr.extOrdrType);
    printf("oSts %d,",pModOrdrAddr->newOrdr.ordrSts);
    printf("brdgFe %ld,",pModOrdrAddr->newOrdr.brdgFee);
    PrintOrderInformation(pModOrdrAddr->newOrdr.ordrMask,side,trdrestr,type);
    printf("oMask %s,",side);
    printf("%s,",trdrestr);
    printf("%s,",type);
    printf("execInst %d,",pModOrdrAddr->newOrdr.execInst);
    printf("userIdx %ld,",pModOrdrAddr->newOrdr.userIdx);
    printf("oAct %ld,",pModOrdrAddr->newOrdr.ordAct);
                
    printf("oNoOld %lld,",pModOrdrAddr->mtchInfo.ordrNoOld); 
    printf("tradPrc %lld,",pModOrdrAddr->mtchInfo.tradePrc);
    printf("actnSeqNum %lld,",pModOrdrAddr->mtchInfo.actnSeqNum);
    printf("oPrtFilCod %d\n",pModOrdrAddr->mtchInfo.ordrPrtFilCod);
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/******************************************************************************
 * Description:   print all mod quantity
 * Parameters:
 *      dataLenIn   IN 
 *      elemTypeIn  IN  
 *      *pDataIn    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintOrdModQty(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintOrdModQty");
    ResCodeT rc = NO_ERR;
  
    pMModOrdQtyT    pModOrdQtyAddr = NULL;
    pMModOrdrT      pModOrdrAddr = NULL;
    int64           timestampIn;
    char            date[150];
    char            time[150];
    char            side[10];
    char            trdrestr[10]; 
    char            type[10];
  
    printf("MOD_QTY|");
    printf("Len %ld,",dataLenIn);
    
    pModOrdQtyAddr = (pMModOrdQtyT)pDataIn;
    printf("oExePrc lld,",pModOrdQtyAddr->oldOrdr.ordrExePrc);
    printf("oNo lld,",pModOrdQtyAddr->oldOrdr.ordrNo);
    timestampIn = pModOrdQtyAddr->oldOrdr.ordrEntTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oEntT %s %s,",date,time);
    timestampIn = pModOrdQtyAddr->oldOrdr.ordrExpTim;
    GetStrDateTime(timestampIn,date,time);
    printf("oExpT %s %s,",date,time);
    timestampIn = pModOrdQtyAddr->oldOrdr.tranTime;
    GetStrDateTime(timestampIn,date,time);
    printf("tranT %s %s|\n",date,time);
    printf("       oQty %ld,",pModOrdQtyAddr->oldOrdr.ordrQty);
    printf("remPkQty %lld,",pModOrdQtyAddr->oldOrdr.remPkQty);
    printf("prdId %ld,",pModOrdQtyAddr->oldOrdr.prdctId);
    printf("entyIdxNo %ld,",pModOrdQtyAddr->oldOrdr.entyIdxNo);
    printf("oExeQty %lld",pModOrdQtyAddr->oldOrdr.ordrExeQty);
    printf("oAppPrc %lld,",pModOrdQtyAddr->oldOrdr.ordrApplyPrc);
    printf("oMtchPrc %lld,",pModOrdQtyAddr->oldOrdr.ordrMtchPrc);
    printf("extOTyp %ld,",pModOrdQtyAddr->oldOrdr.extOrdrType);
    printf("oSts %d,",pModOrdQtyAddr->oldOrdr.ordrSts);
    printf("       brdgFe %ld|\n",pModOrdQtyAddr->oldOrdr.brdgFee);
    PrintOrderInformation(pModOrdQtyAddr->oldOrdr.ordrMask,side,trdrestr,type);
    printf("oMask %s,",side);
    printf("%s,",trdrestr);
    printf("%s,",type);
    printf("execInst %d,",pModOrdQtyAddr->oldOrdr.execInst);
    printf("useIdx %ld,",pModOrdQtyAddr->oldOrdr.userIdx);
    printf("oAct %ld,",pModOrdQtyAddr->oldOrdr.ordAct);
                
    printf("exeQty %lld,",pModOrdQtyAddr->exeQty);
               
    printf("remPkQty %lld,",pModOrdQtyAddr->remPkQty);
               
    timestampIn = pModOrdQtyAddr->tranTime;
    GetStrDateTime(timestampIn,date,time);
    printf("tranT %s%s,",date,time);
                
    printf("exePrc %lld,",pModOrdQtyAddr->exePrc);
                
    printf("slot %ld,",pModOrdQtyAddr->slot);
                
    printf("actnMask %d\n",pModOrdQtyAddr->actnMask);
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrintOrdSave(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintOrdSave");
    ResCodeT rc = NO_ERR;
  
    pMSaveOrdrT pSaveOrdrAddr;
    
    pSaveOrdrAddr = (pMSaveOrdrT)pDataIn;
    
    printf("ODR_SAV|");
    printf("Len %ld, ",dataLenIn);
    
    PrintOrdrF(&pSaveOrdrAddr->ordrF);
                        
    printf("        slot %ld, ",pSaveOrdrAddr->slot);   
    printf("actnMsk %d \n",pSaveOrdrAddr->actnMask);         
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintBilOrdSave(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintBilOrdSave");
    ResCodeT rc = NO_ERR;
  
    pMSaveBilOrdrT pSaveBilOrdrAddr;
    
    pSaveBilOrdrAddr = (pMSaveBilOrdrT)pDataIn;
    
    printf("BIL_ODR_SAV|");
    printf("Len %ld, ",dataLenIn);
    
    PrintOrdrF(&pSaveBilOrdrAddr->bidOrdrF);
    printf("        ",pSaveBilOrdrAddr->bidSlot);
    PrintOrdrF(&pSaveBilOrdrAddr->askOrdrF);
                        
    printf("        Bslot %ld, ",pSaveBilOrdrAddr->bidSlot);
    printf("Aslot %ld, ",pSaveBilOrdrAddr->askSlot);
    printf("oSts %d, ",pSaveBilOrdrAddr->ordrSts);
    printf("oAct %d, ",pSaveBilOrdrAddr->ordrAct);   
    printf("setId %d \n",pSaveBilOrdrAddr->setId);        
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintMktDataPush(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintMktDataPush");
    ResCodeT rc = NO_ERR;
  
    
    printf("MKT_DAT|");
    printf("Len %ld \n",dataLenIn);     
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintLogOco(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintLogOco");
    ResCodeT rc = NO_ERR;
  
    pMLogOcoOrdrT pMLogOcoOrdr;
    
    pMLogOcoOrdr = (pMLogOcoOrdrT)pDataIn;
    
    printf("LOG_OCO|");
    printf("Len %ld, ",dataLenIn);
                        
    printf("BslotCnt %ld, ",pMLogOcoOrdr->bidSlotCnt);
    printf("AslotCnt %ld, ",pMLogOcoOrdr->askSlotCnt);
    printf("oSts %d, ",pMLogOcoOrdr->ordrSts);
    printf("oAct %d, ",pMLogOcoOrdr->ordrAct);   
    printf("setId %d \n",pMLogOcoOrdr->setId);        
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintRefDat(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintFlushMkt");
    ResCodeT rc = NO_ERR;
    

    pMRefDatUpdtT    pMRefDatUpdtAddr;
    void          * pDataOff;
    
    pMRefDatUpdtAddr = (pMRefDatUpdtT)pDataIn;
    
    printf("REF_DAT|");
    printf("Len %ld, ",dataLenIn);
    pDataOff = (void*)ADDRESS_ADD_OFFSET(pDataIn, sizeof(MRefDatUpdtT));
    
    rc = RefDatPrntCmmn(pMRefDatUpdtAddr->updtType, pDataOff, pMRefDatUpdtAddr->dataLen);
    RAISE_ERR(rc,RTN);
       
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintFlushMkt(int32 dataLenIn, void * pDataIn)
{
    BEGIN_FUNCTION("PrintFlushMkt");
    ResCodeT rc = NO_ERR;
  
    pMFlushMktDatT pMFlushMktDat;
    
    pMFlushMktDat = (pMFlushMktDatT)pDataIn;
    
    printf("FLU_MKT|");
    printf("Len %ld, ",dataLenIn);
                         
    printf("setId %ld \n",pMFlushMktDat->setId);        
  
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintCrdtUpdtByTrd(int32 dataLenIn,void * pDataIn)
{
    BEGIN_FUNCTION("PrintCrdtUpdtByTrd");
    ResCodeT rc = NO_ERR;
    
    pMUpdtCrdtByTrdT    pUpdtCrdtByTrdAdrr;
    
    pUpdtCrdtByTrdAdrr = (pMUpdtCrdtByTrdT)pDataIn;
    
    printf("CRD_UPD|");
    printf("Len %ld, ",dataLenIn);
    
    printf("prdPos %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.prdctPos);
    printf("Len %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.chkMode);
    printf("IncEIdPos %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incEntyIdPos);
    printf("BstEIdPos %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstEntyIdPos);
    printf("IncCrdPos %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incCrdtPos);
    printf("BstCrdPos %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstCrdtPos);
    printf("IncUseQty %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incUsedQty);
    printf("IncRmtQty %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.incRmntQty);
    printf("BstUseQty %ld, ",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstUsedQty);
    printf("BstRmtQty %ld \n",pUpdtCrdtByTrdAdrr->crdtMgmtUpdt.bstRmntQty);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrintElemsDone(int32 setId,
                    int64 txnId,
                    void * pCtx)
{
    BEGIN_FUNCTION("PrintElemsDone");
    ResCodeT rc = NO_ERR;
    rc = PrintMemTxnGetTxnBaseInfo(MEM_TXN_SET_ID, txnId);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
/******************************************************************************
 * Description:   print all elements
 * Parameters:
 *      elemType    IN 
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: 
 ******************************************************************************/
ResCodeT PrintElems(void * pDataIn, int32 dataLenIn, MTElemTypeT elemType, void *pCtx)
{
    BEGIN_FUNCTION("PrintElems");
    switch(elemType)
    {
        case MT_TYP_ODR_LOG:
            PrintOrdrLog(dataLenIn, pDataIn);
            break;
        case MT_TYP_ODR_ADD:
            PrintOdrAdd(dataLenIn, pDataIn);
            break;   
        case MT_TYP_ORD_DEL:
            PrintOrdDel(dataLenIn, pDataIn);
            break;   
        case MT_TYP_TRD_LOG:
            PrintTrdLog(dataLenIn, pDataIn);  
            pDataIn = (pMLogTrdT)ADDRESS_ADD_OFFSET(pDataIn, sizeof(MLogTrdT));
            PrintTrdLog(dataLenIn, pDataIn);
            break;
        case MT_TYP_ODR_MOD:
            PrintOrdMod(dataLenIn, pDataIn);
            break;
        case MT_TYP_ORD_MOD_QTY:
            PrintOrdModQty(dataLenIn, pDataIn);  
            break;    
        case MT_TYP_ORD_SAVE:
            PrintOrdSave(dataLenIn, pDataIn);
            break;  
        case MT_TYP_BIL_ORD_SAVE:
            PrintBilOrdSave(dataLenIn, pDataIn);
            break;
        case MT_TYP_MKT_DAT_PUSH:
            PrintMktDataPush(dataLenIn, pDataIn);
            break;
        case MT_TYP_LOG_OCO:
            PrintLogOco(dataLenIn, pDataIn);
            break;
        case MT_TYP_REF_DAT_UPT:
            PrintRefDat(dataLenIn, pDataIn);
            break;
        case MT_TYP_FLUSH_MKT:
            PrintFlushMkt(dataLenIn, pDataIn);
            break; 
        case MT_TYP_CRDT_UPDT_BY_TRD:
            PrintCrdtUpdtByTrd(dataLenIn, pDataIn);
            break; 
        default:
            printf("UNKNOW | %d\n", elemType);
            break;
    }
    
    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}




static ResCodeT PrintBstGrp()
{
    BEGIN_FUNCTION("PrintBstGrp");
    ResCodeT rc = NO_ERR;
    
    CntrctBaseInfoT IrsCntrctInfo;
    BstGrpT BstGrp;
    int32 oMask;
    

    rc = IrsCntrctInfoGetByPos(gMemTxnCtx.prdctId, &IrsCntrctInfo);
    RAISE_ERR(rc,RTN);
    printf("PrdctName %s\n",IrsCntrctInfo.cntrctName);
    
    oMask = ORDR_SIDE_BUY;
    oMask |= ORDR_TRDRESTR_AU;


    rc = GetBstGrp(MEM_TXN_SET_ID, gMemTxnCtx.prdctId, oMask, &BstGrp);
    RAISE_ERR(rc,RTN);
    printf("bstBuyLmtPrc %lld\n",BstGrp.bstBuyLmtPrc);
    printf("bstBuyMktQty %lld\n",BstGrp.bstBuyMktQty);
    printf("bstBuyLmtQty %lld\n",BstGrp.bstBuyLmtQty);
    
    oMask = ORDR_SIDE_SELL;
    oMask |= ORDR_TRDRESTR_AU;
    rc = GetBstGrp(MEM_TXN_SET_ID, gMemTxnCtx.prdctId, oMask, &BstGrp);
    RAISE_ERR(rc,RTN);
    printf("bstSellLmtPrc %lld\n",BstGrp.bstSellLmtPrc);
    printf("bstSellMktQty %lld\n",BstGrp.bstSellMktQty);
    printf("bstSellLmtQty %lld\n",BstGrp.bstSellLmtQty);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



static ResCodeT PrintOrdrMgmt()
{
    BEGIN_FUNCTION("PrintOrdrMgmt");
    ResCodeT rc = NO_ERR;
    OrdrMgmtRcrdT OrdrMgmtInfo;
    pOrderT pOrder = NULL;
    pOrderFT pOrderF = NULL;
    pOrderFT pTmpOrdrF = NULL;
    uint32 nodePos = CMN_HASH_ITER_START;
    char ordrSts[MAX_BUFF_LEN] = { 0 };
    int i = 0;
    while (1)
    {
        rc = OrdrMgmtIter(MEM_TXN_SET_ID, &nodePos, &OrdrMgmtInfo);
        if (nodePos == CMN_LIST_NULL_NODE)
        {
            break;
        }
        else
        {  
            RAISE_ERR(rc,RTN);
            switch (OrdrMgmtInfo.ordrSts)
            {
                case ORDR_STS_ACTIVE:
                    strcpy(ordrSts,"Active");
                    break;
                case ORDR_STS_DEAL:
                    strcpy(ordrSts, "Deal");
                    break;
                case ORDR_STS_CANCEL:
                    strcpy(ordrSts, "Cancel");
                    break;
                case ORDR_STS_FREEZE:
                    strcpy(ordrSts, "Freeze");
                    break;
                case ORDR_STS_INACTIVE:
                    strcpy(ordrSts, "Inactive");
                    break;
            }
            
            printf("OrdrNo %lld, Type %d, Sts %s, \n",OrdrMgmtInfo.ordrKey.ordrNo, OrdrMgmtInfo.ordrKey.ordrType, ordrSts);
            for (i=0; i<OrdrMgmtInfo.ordrCnt; i++)
            {
                rc = OrdrBkGetOrdr( MEM_TXN_SET_ID, OrdrMgmtInfo.ordrSlot[i],  &pOrder);
                RAISE_ERR( rc, RTN );
                
                PrintOrdrF(&pOrder->orderF);
                PrintOrdrT(&pOrder->orderT);
            }

        }
    }
    EXIT_BLOCK();
    RETURN_RESCODE;
}



static ResCodeT PrintNmbrSrvcNo()
{

    BEGIN_FUNCTION( "PrintNmbrSrvcNo" );
    ResCodeT    rc = NO_ERR;
    int64       ordNmbr = 0;
    int64       trdNmbr = 0;
    
    NmbrSrvcGetNo(1,NMBR_TYPE_ORD, &ordNmbr);
    NmbrSrvcGetNo(1,NMBR_TYPE_TRD, &trdNmbr);
    printf("ordNmb %lld\n", ordNmbr);
    printf("trdNmb %lld\n", trdNmbr);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


/*print brdg ordr elements*/
static ResCodeT PrintBrdgOrdMgmt()
{
    BEGIN_FUNCTION( "PrintBrdgOrdMgmt" );
    ResCodeT    rc = NO_ERR;
    
    pOrgInfoT      pOrgInfo = NULL;
    BrdgOrdrRcrdT  brdgOrdrRcrd = {0};
    uint32 nodePos = CMN_HASH_ITER_START;
    
    rc = OrgInfoAttachToShm();
    RAISE_ERR( rc, RTN );
    
    while (1)
    {
        rc = BrdgOrdrMgmtIter(MEM_TXN_SET_ID, &nodePos, &brdgOrdrRcrd);
        if (nodePos == CMN_LIST_NULL_NODE)
        {
            break;
        }
        else
        {
            RAISE_ERR( rc, RTN );

            rc = OrgInfoGetByPosExt( (uint64)brdgOrdrRcrd.ordrKey.entyIdxNo, &pOrgInfo );
            RAISE_ERR( rc, RTN );

            printf("orgBrdg %u, ", brdgOrdrRcrd.ordrKey.entyIdxNo);
            printf("orgID %lld, ", pOrgInfo->orgId);
            printf("prdctId %lld, ", brdgOrdrRcrd.ordrKey.prdctId);
            printf("ordrSide %d," , brdgOrdrRcrd.ordrKey.ordrSide);
            
            printf("brgOrgId %lld, ", brdgOrdrRcrd.brdgOrgId);
            printf("brgFee %lld, ", brdgOrdrRcrd.brdgFee);
            printf("oBkSlt %lld\n", brdgOrdrRcrd.ordrBkSlot);
        }
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT PrintCreditInfo()
{
    BEGIN_FUNCTION( "PrintCreditInfo" );
    ResCodeT    rc = NO_ERR;

    CreditT     creditInfoAB = {0};
    CreditT     creditInfoBA = {0};

    rc = CreditInfoGetByKey( (uint32)gMemTxnCtx.orgIdA,
                                (uint32)gMemTxnCtx.orgIdB, &creditInfoAB );
    RAISE_ERR(rc,RTN);

    rc = CreditInfoGetByKey( (uint32)gMemTxnCtx.orgIdB,
                                (uint32)gMemTxnCtx.orgIdA, &creditInfoBA );
    RAISE_ERR(rc,RTN);

    printf("crdt direction|intlCrdtAmnt|RlFlag|usedCrdtAmnt| rmnCrdtAmnt|crdtTerm|st\n");
    printf("%6u->%6u|%12lu|%6c|%12lu|%12lu|%8u|%2d\n", 
                                    creditInfoAB.crdtOrgId,
                                    creditInfoAB.crdtdOrgId,
                                    creditInfoAB.intlCrdtAmnt,
                                    creditInfoAB.crdtRlFlag[0],
                                    creditInfoAB.usedCrdtAmnt,
                                    creditInfoAB.rmnCrdtAmnt,
                                    creditInfoAB.crdtTerm,
                                    creditInfoAB.st );

    printf("%6u->%6u|%12lu|%6c|%12lu|%12lu|%8u|%2d\n", 
                                    creditInfoBA.crdtOrgId,
                                    creditInfoBA.crdtdOrgId,
                                    creditInfoBA.intlCrdtAmnt,
                                    creditInfoBA.crdtRlFlag[0],
                                    creditInfoBA.usedCrdtAmnt,
                                    creditInfoBA.rmnCrdtAmnt,
                                    creditInfoBA.crdtTerm,
                                    creditInfoBA.st );

    rc = CreditInfoDetachFromShm();
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT PrintProductInfo(pPrdctInfoT pPrdctInfo)
{
    BEGIN_FUNCTION( "PrintProductInfo" );
    ResCodeT    rc = NO_ERR;

    printf("  ************* %s *************\n", pPrdctInfo->prdctName);

    for ( int i = 0; i < BST_MKTINFO_GRP_MAX; i++ )
    {
        printf("   BidPrc[%d]:%lld", i, pPrdctInfo->bstMktInfoGrp[i].bstBidPrc);
    }
    printf("\n");
    
    for ( int i = 0; i < BST_MKTINFO_GRP_MAX; i++ )
    {
        printf("   AskPrc[%d]:%lld", i, pPrdctInfo->bstMktInfoGrp[i].bstAskPrc);
    }
    printf("\n");
    
    for ( int i = 0; i < BST_MKTINFO_GRP_MAX; i++ )
    {
        printf("   BidQty[%d]:%lld", i, pPrdctInfo->bstMktInfoGrp[i].bstBidQty);
    }
    printf("\n");
    
    for ( int i = 0; i < BST_MKTINFO_GRP_MAX; i++ )
    {
        printf("   AskQty[%d]:%lld", i, pPrdctInfo->bstMktInfoGrp[i].bstAskQty);
    }
    printf("\n");
    
    for ( int i = 0; i < BST_MKTINFO_GRP_MAX; i++ )
    {
        printf("   OrdBid[%d]:%lld", i, pPrdctInfo->bstMktInfoGrp[i].numOrdrBid);
    }
    printf("\n");
    for ( int i = 0; i < BST_MKTINFO_GRP_MAX; i++ )
    {
        printf("   OrdAsk[%d]:%lld", i, pPrdctInfo->bstMktInfoGrp[i].numOrdrAsk);
    }
    printf("\n");

    printf("  mktBidQty:%lld, ", pPrdctInfo->baseInfo.mktBidQty);
    printf("  mktAskQty:%lld, ", pPrdctInfo->baseInfo.mktAskQty);
    printf("  mktBidOrdrNum:%lld, ", pPrdctInfo->baseInfo.mktBidOrdrNum);
    printf("  mktAskOrdrNum:%lld, ", pPrdctInfo->baseInfo.mktAskOrdrNum);
    printf("  auctOpenPrc:%lld, ", pPrdctInfo->baseInfo.auctOpenPrc);
    printf("  lstTrdPrc:%lld, ", pPrdctInfo->baseInfo.lstTrdPrc);
    printf("  lstTrdQty:%lld\n", pPrdctInfo->baseInfo.lstTrdQty);
    printf("  dlyHghPrc:%lld, ", pPrdctInfo->baseInfo.dlyHghPrc);
    printf("  dlyLowPrc:%lld,", pPrdctInfo->baseInfo.dlyLowPrc);
    printf("  opnPrc:%lld, ", pPrdctInfo->baseInfo.opnPrc);
    printf("  intraRefPrc:%lld, ", pPrdctInfo->baseInfo.intraRefPrc);
    printf("  wghtTotPrc:%lld, ", pPrdctInfo->baseInfo.wghtTotPrc);
    printf("  wghtTotQty:%lld, ", pPrdctInfo->baseInfo.wghtTotQty);
    printf("  totTrdQty:%lld\n", pPrdctInfo->baseInfo.totTrdQty);
    printf("  lstTrdDatTim:%lld, ", pPrdctInfo->baseInfo.lstTrdDatTim);
    printf("  lstUpdateTim:%lld, ", pPrdctInfo->baseInfo.lstUpdateTim);
    printf("  lstRefPrcUpdTim:%lld, ", pPrdctInfo->baseInfo.lstRefPrcUpdTim);
    printf("  prcsSts:%lld, ", pPrdctInfo->baseInfo.prcsSts);
    printf("  pos:%llu\n", pPrdctInfo->pos);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


static ResCodeT PrintBaseParam()
{

    BEGIN_FUNCTION( "PrintBaseParam" );
    ResCodeT    rc = NO_ERR;
    
    BaseParamT baseParam = {0};
    char paramValue[PARAM_VALUE_LENGTH];

    rc = BaseParamGetByName(gMemTxnCtx.paramName, &baseParam);    
    RAISE_ERR(rc, RTN);
    
    printf("%s = %s\n", baseParam.paramName, baseParam.paramValue);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


static ResCodeT PrintBridgeOrg()
{

    BEGIN_FUNCTION( "PrintBridgeOrg" );
    ResCodeT    rc = NO_ERR;
    
    BrdgOrgInfoT brdgOrg = {0};

    rc = BrdgOrgInfoGetById(gMemTxnCtx.orgBrdgId, &brdgOrg);    
    RAISE_ERR(rc, RTN);

    printf("orgId = %d\n", brdgOrg.orgId);  
    printf("brdgOrgSt = %d\n", brdgOrg.brdgOrgSt);
    printf("brdgOrgOrdr = %lld\n", brdgOrg.brdgOrgOrdr);
    printf("brdgIntntnFlag = %d\n", brdgOrg.brdgIntntnFlag);
    printf("brdgPrvlgFlag = %d\n", brdgOrg.brdgPrvlgFlag);
    printf("brdgPrvlgFlagNext = %d\n", brdgOrg.brdgPrvlgFlagNext);
    printf("mdfySt = %d\n", brdgOrg.mdfySt);
    printf("usrLgnNm = %s\n", brdgOrg.usrLgnNm);
    printf("crdtOprtngSt = %d\n", brdgOrg.crdtOprtngSt);
    printf("crdtOprtr = %s\n", brdgOrg.crdtOprtr);

    
    EXIT_BLOCK();
    RETURN_RESCODE;

}


static ResCodeT PrintBridgeCredit()
{

    BEGIN_FUNCTION( "PrintBridgeCredit" );
    ResCodeT    rc = NO_ERR;
    
    CreditBrdgT crdtBrdg = {0};

    rc = BridgeCreditInfoGetByKey(gMemTxnCtx.orgBrdgId, gMemTxnCtx.orgBrdgOpId, &crdtBrdg);    
    RAISE_ERR(rc, RTN);

    printf("brdgOrgId = %d\n", crdtBrdg.brdgOrgId); 
    printf("orgId = %d\n", crdtBrdg.orgId);
    printf("st = %lld\n", crdtBrdg.st);
    printf("brdgRlFlag = %d\n", crdtBrdg.brdgRlFlag);
    printf("brdgFee = %lld\n", crdtBrdg.brdgFee);
    printf("crdtTerm = %d\n", crdtBrdg.crdtTerm);

    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT PrintPrd()
{
    BEGIN_FUNCTION( "PrintPrd" );
    ResCodeT    rc = NO_ERR;
    pPrdctInfoT pPrdctInfo = NULL;
    
    rc = PrdctInfoGetByNameExt( gMemTxnCtx.prdctName, &pPrdctInfo );
    RAISE_ERR(rc,RTN);

    rc = PrintProductInfo(pPrdctInfo);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT PrintMemTxn()
{
    BEGIN_FUNCTION( "PrintMemTxn" );
    ResCodeT    rc = NO_ERR;
    
    MTElemTypeT myType[] = {(MTElemTypeT)MT_TYPE_ALL,(MTElemTypeT)MT_TYPE_END};
    int64 MaxTxnId;
    MemTxnUserModeT userMode;

    if (gMemTxnCtx.txnID != 0)
    {
        rc = PrintMemTxnGetTxnInfo(MEM_TXN_SET_ID, gMemTxnCtx.txnID);
        RAISE_ERR(rc,RTN);
    }
    else if (gMemTxnCtx.startId != 0)
    {
        userMode.callBack.PrcsData = PrintElems;
        userMode.callBack.PrcsDataDone = PrintElemsDone;
        userMode.callBack.pCtx4PrcsData = NULL;
        userMode.callBack.pCtx4PrcsDataDone = NULL;
        userMode.readOnly = FALSE;
        userMode.pElemTypeArry = myType;
        
        rc = MemTxnRegisterUserMode(&userMode);
        RAISE_ERR(rc,RTN);
      
        rc = MemTxnRetrieveData(MEM_TXN_SET_ID, gMemTxnCtx.startId, gMemTxnCtx.endTxnId, &MaxTxnId);
        RAISE_ERR(rc,RTN);
    }
    else
    {
        RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
    }
              
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT PrintAllMemTxn()
{
    BEGIN_FUNCTION( "PrintAllMemTxn" );
    ResCodeT    rc = NO_ERR;

    MemTxnUserModeT userMode = {0};
    MTElemTypeT myType[] = {(MTElemTypeT)MT_TYPE_ALL,(MTElemTypeT)MT_TYPE_END};
    int64 MaxTxnId;
    

    userMode.callBack.PrcsData = PrintElems;
    userMode.callBack.PrcsDataDone = PrintElemsDone;
    userMode.callBack.pCtx4PrcsData = NULL;
    userMode.callBack.pCtx4PrcsDataDone = NULL;
    userMode.readOnly = FALSE;
    userMode.pElemTypeArry = myType;
          
    rc = MemTxnRegisterUserMode(&userMode);
    RAISE_ERR(rc,RTN);
    rc = MemTxnRetrieveData(MEM_TXN_SET_ID, 1, 999999999, &MaxTxnId);
    RAISE_ERR(rc,RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT PrintAllPrd()
{
    BEGIN_FUNCTION( "PrintAllPrd" );
    ResCodeT    rc = NO_ERR;

    pPrdctInfoT pPrdctInfo = NULL;
    uint32 prdctPos = CMN_LIST_NULL_NODE;

    
    while (TRUE)
    {   
        rc = PrdctInfoIterExt(&prdctPos, &pPrdctInfo);
        RAISE_ERR(rc,RTN);
        
        if ( CMN_LIST_NULL_NODE == prdctPos )
        {
            break;
        }
        
        rc = PrintProductInfo(pPrdctInfo);
        RAISE_ERR(rc,RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT PrintAll()
{
    BEGIN_FUNCTION( "PrintAll" );
    ResCodeT    rc = NO_ERR;
    
    int32 shmType;
    char serverName[8] = {0};
    
    if (gMemTxnCtx.serverFlag == SHOWMEM_OPT_ME){
        strcpy(serverName, "ME");
    }else{
        strcpy(serverName, "TDPS");
    }
                    
    for (shmType = OPT_CRDT; shmType < OPT_ALL; shmType++){
        if (gShmPrintMatrix[shmType].printOption & SHOWMEM_OPT_PRINT_ALL){
            if (!gShmPrintMatrix[shmType].fPrintShmAllDataCallback){
                RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
            }else{
                /* Check if the shared memory is available on the server that SHOWMEM is running on  */
                if (gMemTxnCtx.serverFlag & gShmPrintMatrix[shmType].printOption){
                    printf("========= %s =========\n", shmName[shmType]);
                    rc = gShmPrintMatrix[shmType].fPrintShmAllDataCallback();
                    RAISE_ERR(rc, RTN);
                }else{
                    /* If the shared memory is not available, print the message and continue to print the next shared memory */
                    printf("The shared memory [%s] you want to show is not available on Server %s\n", shmName[shmType], serverName);
                }
            }
        }
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT AttachShmBstGrp()
{
    BEGIN_FUNCTION( "AttachShmBstGrp" );
    ResCodeT    rc = NO_ERR;
    
    rc = OrdrBkShmAttach(MEM_TXN_SET_ID);
    RAISE_ERR(rc,RTN);

    rc = IrsCntrctInfoAttachToShm();
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

static ResCodeT AttachShmOrder()
{
    BEGIN_FUNCTION( "AttachShmOrder" );
    ResCodeT    rc = NO_ERR;
    
    rc = OrdrBkShmAttach(MEM_TXN_SET_ID);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT AttachShmBridgeOrder()
{
    BEGIN_FUNCTION( "AttachShmBridgeOrder" );
    ResCodeT    rc = NO_ERR;
    
    rc = BrdgOrdrShmAttach(MEM_TXN_SET_ID);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT AttachShmOrderMgmt()
{
    BEGIN_FUNCTION( "AttachShmOrderMgmt" );
    ResCodeT    rc = NO_ERR;
    
    rc = OrdrMgmtShmAttach(MEM_TXN_SET_ID);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT AttachShmNmbrSrvcNo()
{
    BEGIN_FUNCTION( "AttachShmNmbrSrvcNo" );
    ResCodeT    rc = NO_ERR;
    
    rc = NmbrSrvcShmAttach(1);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT AttachShmMemTxn()
{
    BEGIN_FUNCTION( "AttachShmMemTxn" );
    ResCodeT    rc = NO_ERR;
    
    rc = MemTxnShmInit(MEM_TXN_SET_ID);
    RAISE_ERR(rc,RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT AttachShmAll()
{
    BEGIN_FUNCTION( "AttachShmAll" );
    ResCodeT    rc = NO_ERR;
    
    int32 shmType;
    
    for (shmType = OPT_CRDT; shmType < OPT_ALL; shmType++){
        if (gShmPrintMatrix[shmType].printOption & SHOWMEM_OPT_PRINT_ALL){
            if (!gShmPrintMatrix[shmType].fAttachShmCallback){
                RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
            }else{
                /* Check if the shared memory is available on the server that SHOWMEM is running on  */
                if (gMemTxnCtx.serverFlag & gShmPrintMatrix[shmType].printOption){
                    /* If the shared memory is available, attach to the shared memory */
                    rc = gShmPrintMatrix[shmType].fAttachShmCallback();
                    RAISE_ERR(rc, RTN);
                }
            }
        }
    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}



int32 main(int argc, char* argv[])
{
    BEGIN_FUNCTION("main");
    ResCodeT rc = NO_ERR;

    int32 op;
    char serverName[8] = {0};
    
    gOutFile = stdout;
    
    PrcsInit(argv[1]);
    
    rc = ParseOption(argc, argv, g_showallOps);
    RAISE_ERR(rc,RTN);
    
    op=GetTheOpt();
    
    if (op == OPT_HELP)
    {
        /* Print the usage information of this utility */
        Usage();
    } 
    else 
    {
        if (op != gShmPrintMatrix[op].shmType || 
            !gShmPrintMatrix[op].fAttachShmCallback ||
            !gShmPrintMatrix[op].fPrintShmCallback)
        {
            /* Invalid parameters */
            RAISE_ERR(ERCD_ARCH_INPUT_ARGS,RTN);
        }
        
        /* Check if the shared memory to be printed is available on the server that SHOWMEM is running on  */
        if (!(gMemTxnCtx.serverFlag & gShmPrintMatrix[op].printOption))
        {
            /* If shared memory is not available on the server, print the message and exit */
            if (gMemTxnCtx.serverFlag == SHOWMEM_OPT_ME)
            {
                strcpy(serverName, "ME");
            }
            else
            {
                strcpy(serverName, "TDPS");
            }
            printf("The shared memory [%s] you want to show is not available on Server %s\n", shmName[op], serverName);
            exit(0);
        }

        /* Attach to shared memory */
        rc = gShmPrintMatrix[op].fAttachShmCallback();
        RAISE_ERR(rc, RTN);

        /* Print the data kept in shared memory */
        rc = gShmPrintMatrix[op].fPrintShmCallback();
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;

}


#endif /* _SHOWMEM_ */ 