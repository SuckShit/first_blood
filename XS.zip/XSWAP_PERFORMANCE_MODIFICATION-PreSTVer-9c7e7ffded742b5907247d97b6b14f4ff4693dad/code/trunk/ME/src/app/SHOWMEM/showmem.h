﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/
#ifndef _SHOWMEM_H_
#define _SHOWMEM_H_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "optlib.h"
#include "err_lib.h"
#include "msg_cache.h"
#include "base_param.h"
#include "org_info.h"
#include "credit_info.h"
#include "prdct_info.h"
#include "mem_txn.h"
#include "contract_info.h"
#include "nmbr_srvc.h"
#include "dump_ord.h"
#include "brdg_ordr_mgmt.h"
#include "order_book.h"
#include "ordr_mgmt.h"
#include "mem_txn.h"
#include "mem_txn_elem.h"
#include "monitor_thread.h"

#define SHOWMEM_OPT_ME            ((vectorT)1) << 1          // shared memory is available on ME server
#define SHOWMEM_OPT_TDPS          ((vectorT)1) << 2          // shared memory is available on TDPS server  
#define SHOWMEM_OPT_PRINT_ALL     ((vectorT)1) << 3          // printing of the shm data should be included in PrintAll       

#define SHOWMEM_SHMNAME_LENGTH    50

typedef enum { 
OPT_HELP = 0,       // showmem -help 显示帮助信息
OPT_CRDT,           // showmem -crdt 显示授信信息
OPT_TXN,            // showmem -advance 显示 高级操作信息
OPT_MSGCNT,         // showmem -ins 查询产品信息， 修改产品状态
OPT_PRD,
OPT_BG,
OPT_ORD,
OPT_ORDMGMT,
OPT_ORDNO,
OPT_BRDGORD,
OPT_PARAM,          // showmem -param 显示基本参数信息
OPT_ORGBRDG,        // showmem -orgbrdg 显示桥机构信息
OPT_CRDTBRDG,       // showmem -crdtbrdg 显示桥授信信息
OPT_MONITOR,        // showmem -monitor show thread status
OPT_ALL
}ShowALLOptT;

static char shmName[][SHOWMEM_SHMNAME_LENGTH] = {
"HELP",
"CREDIT",
"MEM TXN",
"MSG COUNT",
"PRODUCT INFO",
"BEST GROUP",
"ORDER BOOK",
"ORDER MANAGEMENT INFO",
"INSTRUMENT INFO",
"BRIDGE ORDER MANAGEMENT INFO",
"BASE PARAMETER",
"BRIDGE ORGANIZATION INFO",
"BRIDGE CREDIT INFO",
"ALL SHARED MEMORY"
};


typedef ResCodeT (*AttachShmCallbackT)(void);
typedef ResCodeT (*PrintShmInfoCallbackT)(void);
typedef ResCodeT (*PrintAllShmInfoCallbackT)(void);

typedef struct ShmInfoPrintS
{
    ShowALLOptT                shmType;
    vectorT                    printOption;
    AttachShmCallbackT         fAttachShmCallback;
    PrintShmInfoCallbackT      fPrintShmCallback;
    PrintAllShmInfoCallbackT   fPrintShmAllDataCallback;
} ShmInfoPrintT, *pShmInfoPrintT;

static ResCodeT ParseOption(int argc, char** argv,
                    OpEntryT options[MAX_OPS][MAX_ENTRY]);

                    
/* Define the methods that attatch to the shared memory */
static ResCodeT AttachShmBstGrp();
static ResCodeT AttachShmOrder();
static ResCodeT AttachShmBridgeOrder();
static ResCodeT AttachShmOrderMgmt();
static ResCodeT AttachShmNmbrSrvcNo();
static ResCodeT AttachShmMemTxn();
static ResCodeT AttachShmAll();
                    
/* Define the methods that print the data in the shared memory */                   
static ResCodeT PrintMsgCount();
static ResCodeT PrintBaseParam();
static ResCodeT PrintBridgeOrg();
static ResCodeT PrintBridgeCredit();
static ResCodeT PrintPrd();
static ResCodeT PrintCreditInfo();
static ResCodeT PrintBstGrp();
static ResCodeT PrintDataOrdr();
static ResCodeT PrintBrdgOrdMgmt();
static ResCodeT PrintOrdrMgmt();
static ResCodeT PrintNmbrSrvcNo();
static ResCodeT PrintMemTxn();
static ResCodeT PrintAll();

/* Define the methods that print all the data in the specified shared memory */  
static ResCodeT PrintAllMemTxn();
static ResCodeT PrintAllPrd();


static ShmInfoPrintS gShmPrintMatrix[] = {
    {OPT_HELP, 0, NULL, NULL},
    {OPT_CRDT, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, CreditInfoAttachToShm, PrintCreditInfo, NULL},
    {OPT_TXN, SHOWMEM_OPT_ME|SHOWMEM_OPT_PRINT_ALL, AttachShmMemTxn, PrintMemTxn, PrintAllMemTxn},
    {OPT_MSGCNT, SHOWMEM_OPT_ME, MsgInit, PrintMsgCount, NULL},
    {OPT_PRD, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS|SHOWMEM_OPT_PRINT_ALL, PrdctInfoAttachToShm, PrintPrd, PrintAllPrd},
    {OPT_BG, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, AttachShmBstGrp, PrintBstGrp, NULL},
    {OPT_ORD, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS|SHOWMEM_OPT_PRINT_ALL, AttachShmOrder, PrintDataOrdr, PrintDataOrdr},
    {OPT_ORDMGMT, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS|SHOWMEM_OPT_PRINT_ALL, AttachShmOrderMgmt, PrintOrdrMgmt, PrintOrdrMgmt},
    {OPT_ORDNO, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, AttachShmNmbrSrvcNo, PrintNmbrSrvcNo, NULL},
    {OPT_BRDGORD, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS|SHOWMEM_OPT_PRINT_ALL, AttachShmBridgeOrder, PrintBrdgOrdMgmt, PrintBrdgOrdMgmt},
    {OPT_PARAM, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, BaseParamAttachToShm, PrintBaseParam, NULL},
    {OPT_ORGBRDG, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, BrdgOrgInfoAttachToShm, PrintBridgeOrg, NULL},
    {OPT_CRDTBRDG, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, BridgeCreditInfoAttachToShm, PrintBridgeCredit, NULL},
    {OPT_MONITOR, SHOWMEM_OPT_ME, MonThreadShmAttach, PrintMonThread, NULL},
    {OPT_ALL, SHOWMEM_OPT_ME|SHOWMEM_OPT_TDPS, AttachShmAll, PrintAll, NULL}
};
                    
#endif /* _SHOWMEM_H_ */