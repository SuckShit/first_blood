/***
Created on June 13, 2017
@author: XiaoPing Zhou
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/select.h>


/* Project Header File*/
#include "data_type.h"
#include "err_lib.h"
#include "shm.h"
#include "perf_stat.h"
#include "cfg_lib.h"
#include "uti_tool.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define CFG_INTVL_DEFAULT     10                /* default value: every 10 seconds */
#define STOP_LOGICAL          "PERF_STOP"       /* logical to stop execution */
#define MAX_UINT64            0xffffffffffffff
               /* time precision is second. time format is YYYY/MM/DD HH:MI:SS */
#define TIME_STRING_FROMAT    "%4d/%02d/%02d %02d:%02d:%02d"


#define RAISE_STDIO_ERR  \
{ \
    RAISE_ERR_PARM (ERR_ARCH_EL_ISSUESYSERROR,RTN,strerror(errno));  \
}


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
// typedef struct {
  // UWORD   buflen;
  // UWORD   item_code;
  // LONG    *buf_adr;
  // WORD    *ret_len_adr;
  // LONG    terminator;
// } itemList3T, *pItemList3T;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
uint64     timStart = 0;                    /* start / next wake-up time */
char       szCsvName[255] = "";             /* CSV file name */
float      iInterval = CFG_INTVL_DEFAULT;   /* wake-up interval */
FILE       *fLog = NULL;                    /* handle to CSV file */ 
pPerfStatT pStats = NULL;                 /* 64bit ptr to statistics memory */
PerfStatT  prevStats[EndOfTypes];           /* last seen statistics */
struct timeval    timerVal;                 /* the interval setting of the timer */
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
//OK
ResCodeT TimeConvBinToAsc(uint64 iTime, char* timeStr)
{
    
    BEGIN_FUNCTION("TimeConvBinToAsc");
    ResCodeT rc;
    char timeBuf[MAX_TIME_LEN+1];
    time_t timep;
    struct tm *p;
    
    ASSERT(timeStr);
    
    memset(timeBuf, 0, sizeof(timeBuf));
    
    /* convert the iTime into time formatted string. the precision of iTime is second. */
    timep = (time_t)iTime;
    p = localtime(&timep);
    sprintf(timeBuf, TIME_STRING_FROMAT, 1900+p->tm_year,1+p->tm_mon,p->tm_mday,
        p->tm_hour,p->tm_min,p->tm_sec);
    strcpy(timeStr, timeBuf);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

//OK
ResCodeT TimeCurrAscTime(char* timeStr){

    BEGIN_FUNCTION("TimeCurrAscTime");
    ResCodeT rc;
    
    time_t currTim = 0;
    
    ASSERT(timeStr);
    
    /* Get the current time */
    time(&currTim);
    /* Convert the current time into formatted string */
    rc = TimeConvBinToAsc((uint64)currTim, timeStr);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}



ResCodeT OpenFlgFile(){

    BEGIN_FUNCTION("OpenFlgFile");
    ResCodeT rc = NO_ERR;
    FILE       *fFlgFile = NULL; 
    /* Create the file */
    fFlgFile = fopen("../tmp/Perf_End.flg", "r");
    if (!fFlgFile){
        return NO_ERR;
    }
    else
    {
        if (fclose(fFlgFile)){
            LOG_DEBUG("close file %s error\n", "Perf_End.flg");
            SET_RESCODE(ERR_ARCH_IO_CLOSE_ERR);
        }
        fFlgFile = NULL;
        
        return ERR_ARCH_IO_CLOSE_ERR;
    }
    /* Error Handling */
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}


ResCodeT CsvFileCreate(){

    BEGIN_FUNCTION("CsvFileCreate");
    ResCodeT rc;
    
    char timeBuf[MAX_TIME_LEN + 1];
    int32 type;
    
    /* Create the file */
    fLog = fopen(szCsvName, "w+b");
    if (!fLog){
        RAISE_STDIO_ERR;
    }
    
    
    /* Write header information */
    /* 1.Line: Host and comment information */
    if (fprintf(fLog,"XSWAP, PERF Enviroment\n") < 0){
        RAISE_STDIO_ERR;
    }
    
    /* 2.Line: Start Date */
    rc = TimeConvBinToAsc(timStart, timeBuf);
    RAISE_ERR(rc, RTN);
    
    if (fprintf(fLog, "%10.10s, %10.10s\n", timeBuf, timeBuf) < 0 ){
        RAISE_STDIO_ERR;
    }
    
    /* 3.Line: Start Time */
    if (fprintf(fLog, "%5.5s,%5.5s\n", timeBuf+11, timeBuf+11) < 0){
        RAISE_STDIO_ERR;
    }
    
    /* 4.Line: Column headers */
    if (fprintf(fLog, "[PERF]Sample Time,") < 0){
        RAISE_STDIO_ERR;
    }
    for (type = 0; type < EndOfTypes-1; type++){
        if (fprintf(fLog, "%s,", PERF_STAT[type].descr) < 0){
            RAISE_STDIO_ERR;
        }
    }
    if (fprintf(fLog, "%s\n", PERF_STAT[type].descr) < 0){
        RAISE_STDIO_ERR;
    }
    
    /* Error Handling */
    EXIT_BLOCK();
    if (fLog && NOTOK(GET_RESCODE())){
        if (fclose(fLog)){
            TRACE_PARM("close file %s error\n", szCsvName);
            SET_RESCODE(ERR_ARCH_IO_CLOSE_ERR);
        }
        fLog = NULL;
    }
    
    RETURN_RESCODE;
    
}


ResCodeT CsvFileClose(){

    BEGIN_FUNCTION("CsvFileClose");
    
    if (fLog){
        if (fclose(fLog)){
            TRACE("close file error\n");
            RAISE_ERR(ERR_ARCH_IO_CLOSE_ERR, RTN);
        }
      
        fLog = NULL;
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


//OK
ResCodeT CopyStatsArr(pPerfStatT to){

    BEGIN_FUNCTION("CopyStatsArr");
    
    int32 type;
    int i = 0;
    
    ASSERT(to);
    
    /* Copy values one-by-one, which each is an atomic operation, so that no application can disrupt the value at the same time;
       a memcpy would be faster, but is not atomic */
    for (type = 0; type < EndOfTypes; type++){
        switch (PERF_STAT[type].method){
            case AvgPerSecond:
            case Constant:
                /* just copy locally, is considered atomic operation */
                to[type].cnt = pStats[type].cnt;
                break;
            case AvgOfSamples:
                /* consistency protocol: perf_stat.c increments samplesBegin at beginning, samplesEnd at end.
                    Here, we read the other way round. cnt is only valid if samplesBegin == samplesEnd,
                    then we can be sure nobody touched the value inbetween.
                    In order not to end up in an end-less loop, we set a maximum loop-count of 10. */
                i = 0;
                do {
                    to[type].samplesEnd = pStats[type].samplesEnd;
                    to[type].cnt = pStats[type].cnt;
                    to[type].samplesBegin = pStats[type].samplesBegin;
                } while ( (to[type].samplesEnd != to[type].samplesBegin) && (++i < 10) );
                break;
        }
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

//OK
ResCodeT CalcStatsValue(PerfStatTypesT type, PerfStatT *currArr, float *pVal){

    BEGIN_FUNCTION("CalcStatsValue");
    
    uint64 val = 0, cnt = 0;
    
    ASSERT(pVal);
    
    /* Calculate the value to be reported as difference between previous and current statistics */
    if (currArr[type].cnt >= prevStats[type].cnt ){
        val = currArr[type].cnt - prevStats[type].cnt;
    } else {
        /* Current value less than previous->counter, so do wrap-around */
        val = MAX_UINT64 - prevStats[type].cnt;
        val++;
        val += currArr[type].cnt;
    }
    
    /* Calculate the number of samples to be reported as difference between previous and current statistics */
    if (currArr[type].samplesBegin >= prevStats[type].samplesBegin){
        cnt = currArr[type].samplesBegin - prevStats[type].samplesBegin;
    } else {
        /* Current value less than previous->Counter, so do wrap-around */
        cnt = MAX_UINT64 - prevStats[type].samplesBegin;
        cnt++;
        cnt += currArr[type].samplesBegin;
    }
    
    /* Based on method the calculation returned differs */
    switch (PERF_STAT[type].method){
        case AvgPerSecond:
            (*pVal) = (float)val/iInterval;
            break;
        
        case Constant:
            /* Just report the current values as-is */
            (*pVal) = currArr[type].cnt;
            break;
        
        case AvgOfSamples:
            /* Report the average of samples */
            (*pVal) = cnt > 0 ? (float)val/cnt: 0;
            break;
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

//OK
ResCodeT CsvAddLn(){

    BEGIN_FUNCTION("CsvAddLn");
    ResCodeT rc;
    
    /* local copy of statistics */
    PerfStatT stats[EndOfTypes];
    float val = 0;
    char currAscTim[MAX_TIME_LEN + 1];
    int32 type;
    
    /* Init, get current timestamp */
    memset(&stats, 0, sizeof(stats));
    rc = TimeCurrAscTime(currAscTim);
    RAISE_ERR(rc, RTN);
    
    /* Copy current value locally */
    rc = CopyStatsArr(stats);
    RAISE_ERR(rc, RTN);
    
    /* Now we have all time of the world to format and write the CSV records */
    if (fprintf(fLog, "%s, ", currAscTim) < 0){
        RAISE_STDIO_ERR;
    }
    for (type = 0; type < EndOfTypes-1; type++){
        rc = CalcStatsValue((PerfStatTypesT)type, stats, &val);
        RAISE_ERR(rc, RTN);
      
        if (fprintf(fLog, "%1.2f, ", val) < 0){
            RAISE_STDIO_ERR;
        }
    }
    
    /* The last value on the line */
    rc = CalcStatsValue((PerfStatTypesT)type, stats, &val);
    RAISE_ERR(rc, RTN);
      
    if (fprintf(fLog, "%1.2f\n", val) < 0){
        RAISE_STDIO_ERR;
    }
    
    /* flush the file after each record as we wake up only periodically */
    if (fflush(fLog) == EOF){
        RAISE_STDIO_ERR;
    }
    
    /* Copy the reported statistics into the previous array, as basis for the next wake-up period */
    memcpy(prevStats, stats, sizeof(prevStats));

    EXIT_BLOCK();
    RETURN_RESCODE;    
    
}

// void CsvTimerAST(){

    // BEGIN_FUNCTION("CsvTimerAST");
    
    // /* Just wake up mainline */
    // // TODO: How to wake up in Linux??
    // // sys$wake(0,0);
    
    // EXIT_BLOCK();
// }

//OK
ResCodeT CsvSetTimer(int64 intervalTime){

    BEGIN_FUNCTION("CsvSetTimer");
    
    /* Set the interval time of the Timer. Precision is second */
    timerVal.tv_sec = intervalTime;
    timerVal.tv_usec = 0;
    
    select(0, NULL, NULL, NULL, &timerVal);
    
    RETURN_RESCODE;    
    
}

//OK
ResCodeT InitStatsArray(){

    BEGIN_FUNCTION("InitStatsArray");
    PerfStatTypesT type;
    ResCodeT rc;
    
    /* Initialize previous counters' array */
    memset(prevStats, 0, sizeof(prevStats));
    
    /* Try to attach silently first, mybe the area is still there */
    rc = PerfStatShmAttach(&pStats);
    if (NOTOK(rc)){
        /* Did not work out, then try to create the area */
        rc = PerfStatShmCreate(&pStats);
        RAISE_ERR(rc, RTN);
      
        memset(pStats, 0, sizeof(PerfStatT)*EndOfTypes);
    } else {
        /* There are (potentially high) counters in there, copy them to last known array */
        rc = CopyStatsArr(prevStats);
        RAISE_ERR(rc, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}



// /*
 // * TransLogSilend
 // * Translates a logical very similar to translate_logical,
 // * but without issuing warnings if it is not defined. 
 // */
// ResCodeT TransLogSilent(const char* proc_name, const char* logical_name, 
                        // char* logical_value, unsigned short value_max_len){

    // BEGIN_FUNCTION("TransLogSilent");
    
    // char err_msg[128], table[] = "LNM$DCL_LOGICAL";
    // long rtn_code;
    // itemList3T itemlist;
    // short ret_len;
    
    // ASSERT(proc_name);
    // ASSERT(logical_name);
    // ASSERT(logical_value);
    
    // itemlist.buflen = value_max_len -1;
    // itemlist.item_code = LNM$_STRING;
    // itemlist.buf_adr = (long*)logical_value;
    // itemlist.ret_len_adr = &ret_len;
    // itemlist.terminator = 0;
    
    // /* Call system to translate the logical */
    // // TODO: sys$trnlnm is not defined
    // trn_code = sys$trnlnm(0, DESCR_S1(table), DESCR_S2((char*)logical_name)), 0, &itemlist);
    
    // if (!ODD(rtn_code)){
      // /* Was no success, which is OK in our case, don't log error */
      // THROW_RESCODE(ERR_SHL_NO_LOGICAL_NAME);
    // }
    
    // logical_value[ret_len] = '\0';
    
    // EXIT_BLOCK();
    // RETURN_RESCODE;
    
// }


/*
 * MonContinue
 * Continue processing?
 * Checks if enviroment variable PERF_STOP has been set to Y or 1
 */
ResCodeT MonContinue(){

    BEGIN_FUNCTION("MonContinue");
    ResCodeT rc = NO_ERR;
//    char * flg = NULL;
//    char logicalVal[8] = {0};
//    static int count = 1;  // for test
    // /* translate logical TOFF$T4_STOP */
    // memset(logicalVal, sizeof(logicalVal));
//    flg = getenv(STOP_LOGICAL);
//    //rc = TransLogSilent("MonContinue", STOP_LOGICAL, logicalVal, sizeof(logicalVal)-1);
//    
//    if (!flg)
//    {
//        strcpy(logicalVal, "N");
//    }
//    
//    /* translated. Is it any "TRUE" value? */
//    if (strcmp(logicalVal, "Y") == 0 ||
//        strcmp(logicalVal, "T") == 0 ||
//        strcmp(logicalVal, "YES") == 0 ||
//        strcmp(logicalVal, "TRUE") == 0 ||
//        strcmp(logicalVal, "1") == 0 || count >= 10)
//    {
//        /* then do not continue */
//        THROW_RESCODE(ERCD_UNSPECIFIED_ERROR);
//    }

    rc = OpenFlgFile();
    RAISE_ERR(rc, RTN);
    
    /* in all other cases: just continue processing */
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/*
 * MonInit
 * General one-time image initializations
 */
ResCodeT MonInit(){

    BEGIN_FUNCTION("MonInit");
    
    // TODO: config file read related.
    // CfgItemT defaultItem;
    // CfgItemT *pCfgItem = NULL;
    char szStartTim[MAX_TIME_LEN + 1];
    ResCodeT rc;
    time_t currTime;
    struct cfgValueS cfgValue;
    
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
    
    // for temporary use, just set the interval to the default value
    iInterval = cfgValue.iPerfMonIntrval;
    // -------------------TODO End ----------------------------------------

    
    /* Start time is now, but normalized to full multiples of the interval, so that we always
       start at an interval boundary */
    time(&currTime);
    timStart = (uint64)currTime;
    // Need to start at interval boundary.
    timStart -= timStart % (int64)iInterval;
    timStart += (int64)iInterval;
    
    rc = TimeConvBinToAsc(timStart, szStartTim);
    RAISE_ERR(rc, RTN);

    /* Set the CSV file name */
    sprintf(szCsvName, "../tmp/PERFORMANCE_DATA_%4.4s%2.2s%2.2s_%2.2s%2.2s_SWAP.CSV",
                        &szStartTim[0], &szStartTim[5],
                        &szStartTim[8], &szStartTim[11], &szStartTim[14]);
    
    /* Initialize statistics array */
    rc = InitStatsArray();
    RAISE_ERR(rc, RTN);
    
    /* Log the sampling interval into the PERF data */
    pStats[Intvl].cnt = iInterval;
    
    /* Create the main log file */
    rc = CsvFileCreate();
    RAISE_ERR_PARM(rc, RTN, "File creation failed, is DATA defined?");
    
    EXIT_BLOCK();
    // TODO: Close config file.
    // rc = CfgShutdown();
    RAISE_ERR(rc, NORTN);
    RETURN_RESCODE;    
}

/*
 * WriteDataAtIntervals
 * Create the snap-shot of the performance data.
 * Since the operation of writing CSV file is a little bit time-consuming,
 * so it is necessary to calculate the interval at real time and
 * set the interval of the Timer each time.
 */
ResCodeT WriteDataAtIntervals(){

    BEGIN_FUNCTION("WriteDataAtIntervals");

    ResCodeT rc;
    time_t currTime;
    uint64 startInterval;
    
    /* Recalculate the gap between current time and startTime. Use this 
       recalculated value to set the timer and call the CsvAddLn for the first time. */ 
    time(&currTime);
    startInterval = timStart - (uint64)currTime;
    // printf("current time in main: %d\n",currTime);
    // printf("startInterval is  : %d\n",startInterval);
    if (startInterval > 0){
        // since the start time has not yet come, wait for a period of time(startInterval).
        rc = CsvSetTimer(startInterval);
        RAISE_ERR(rc, RTN);
        
        // print the first line of performance data into CSV file.
        rc = CsvAddLn();
        RAISE_ERR(rc, RTN);
    } else if (startInterval == 0){
        // Just reach the start time. So print the first line of data at once. 
        rc = CsvAddLn();
        RAISE_ERR(rc, RTN);
    } else {
        // the current time has passed the start time, so reset the start time and wait.
        while (startInterval < 0){
            startInterval = (int64)iInterval + startInterval;
        }
        
        rc = CsvSetTimer(startInterval);
        RAISE_ERR(rc, RTN);
        
        // print the first line of performance data into CSV file.
        rc = CsvAddLn();
        RAISE_ERR(rc, RTN);
        
    }
    
    /* Calculate next timeout value as difference from previous one => no time shift! */
    timStart +=((int64)iInterval);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
}

int main(int argc, char* argv[] ){

    BEGIN_FUNCTION("main");
    
    ResCodeT rc = NO_ERR;
    struct cfgValueS cfgValue;
    
    if (argc < 3)
    {
        RAISE_ERR(ERR_CAR_MAIN_PARAMETER_NUMBERS_ERR, RTN);
    }
    
    PrcsInit(argv[2]);
    
    rc = GetCfgValue(&cfgValue);
    RAISE_ERR(rc, RTN);
    
    /* Initialize */
    rc = MonInit();
    RAISE_ERR(rc, RTN);
    
    /* Main Loop */
    do {
        // /* Set the timer */
        sleep(cfgValue.iPerfMonIntrval);
        
        // /* Woken up, write statistics */
        rc = CsvAddLn();
        RAISE_ERR(rc, RTN);
      
        rc = WriteDataAtIntervals();
        RAISE_ERR(rc, RTN);
      
    } while (OK(MonContinue()));
    
    /* Close the main log file */
    rc = CsvFileClose();
    RAISE_ERR(rc, NORTN);
    
    LOG_DEBUG("Perf Mon Exit");
   
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
