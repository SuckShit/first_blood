/***
Created on July 18, 2017
@author: Dongwei Li
@version $Id
***/

// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)


// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include <limits.h>
#include <pthread.h>          
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include "gtest/gtest.h"

#include "common_macro.h"
#include "shm.h"
#include "db_comm.h"
#include "OrgInfoBrdgDb.h"

// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.
using ::testing::InitGoogleTest; 

int32 connId;

class orgInfoBrdgTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // TRACE("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // TRACE("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
        ResCodeT rc = NO_ERR;
        rc = DbCmmnInit();
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }
        rc = DbCmmnConnect((char*)DB_INST, (char*)DB_NAME, (char*)DB_PWD, &connId);
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }        
    }
        
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        rc = DbCmmnDisconnect(connId);
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }
        rc = DbCmmnCleanup();
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }
    }
};




#if 0 

TEST_F(orgInfoBrdgTest, BatchUpdateOrgInfoBrdgByKey) {
    ResCodeT rc = NO_ERR;
    OrgInfoBrdgKeyLst key;
    OrgInfoBrdgMulti data;
    OrgInfoBrdgUpdFlag flag;

    // key multi data.
    int32 orgSrnoArray[5] = {9501, 9502, 9503, 9504, 9505};
    // value multi data.
    int32 orgIdArray[5] = {100101, 100102, 100103, 100104, 100105};
    char brdgPrvlgFArray[5][1+1] = {"0", "0", "0", "0", "0"};
    char brdgPrvlgUpdTmArray[5][19+1] = {"2017-07-17 17:58:59", "2017-07-17 17:59:59", "2017-07-17 18:00:00", "2017-07-17 18:10:00", "2017-07-17 18:20:00"};
    memset(&key,  0x00, sizeof(OrgInfoBrdgKeyLst));
    memset(&data, 0x00, sizeof(OrgInfoBrdgMulti));
    memset(&flag,  0x00, sizeof(OrgInfoBrdgUpdFlag));

    // keydata.
    key.keyRow = 5;
    key.orgSrnoLst = orgSrnoArray;

    // updatedata.
    data.dataRow = 5;
    data.orgIdLst = orgIdArray;
    flag.bOrgId = TRUE;

    data.brdgPrvlgFLst = (char**)brdgPrvlgFArray;
    data.brdgPrvlgFMaxSize = 1;
    flag.bBrdgPrvlgF = TRUE;

    data.brdgPrvlgUpdTmLst = brdgPrvlgUpdTmArray[0];
    data.brdgPrvlgUpdTmMaxSize = 19;
    flag.bBrdgPrvlgUpdTm = TRUE;

    TRACE("Ready to test batch update function.\n");

//ResCodeT BatchUpdateOrgInfoBrdgByKey(int32 connId, OrgInfoBrdgKeyLst* pKeyList, OrgInfoBrdgMulti* pData, OrgInfoBrdgUpdFlag* pUpdFlag, int32 dataCol);

    rc = BatchUpdateOrgInfoBrdgByKey(connId, &key, &data, &flag, 3);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);
}


TEST_F(orgInfoBrdgTest, UpdateOrgInfoBrdgByCrdtOprtr) {
    ResCodeT rc = NO_ERR;
    char CrdtOprtr[100];

    OrgInfoBrdg uptData;
    OrgInfoBrdgUpdFlag upFlg;

    // key.
    memset(CrdtOprtr, 0x00, sizeof(CrdtOprtr));
    strcpy(CrdtOprtr, "lidw2");
    // data.
    memset(&uptData, 0x00, sizeof(OrgInfoBrdg));
    memset(&upFlg, 0x00, sizeof(OrgInfoBrdgUpdFlag));
    uptData.orgId = 90011;
    upFlg.bOrgId = TRUE;
    strcpy(uptData.brdgOrgSt, "5");
    upFlg.bBrdgOrgSt = TRUE;
    strcpy(uptData.brdgIntntnF, "9");
    upFlg.bBrdgIntntnF = TRUE;
    strcpy(uptData.updTm, "2017-08-02 19:04:59");
    upFlg.bUpdTm = TRUE;
    strcpy(uptData.updUsrNm, "zhaoys");
    upFlg.bUpdUsrNm = TRUE;

    rc = UpdateOrgInfoBrdgByCrdtOprtr(connId, CrdtOprtr, &uptData, &upFlg, 5);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    

}

TEST_F(orgInfoBrdgTest, UpdateOrgInfoBrdgByKey) {
    ResCodeT rc = NO_ERR;

    OrgInfoBrdgKey keyData;
    OrgInfoBrdg uptData;

    vectorT  keyVct[GET_BIT_VECT_LEN(23)] = {0};
    vectorT  datVct[GET_BIT_VECT_LEN(23)] = {0};

    memset(&keyData, 0x00, sizeof(OrgInfoBrdgKey));
    memset(&uptData, 0x00, sizeof(OrgInfoBrdg));

    keyData.orgSrno = 9501;

    uptData.orgId = 90011;
    strcpy(uptData.brdgOrgSt, "5");
    strcpy(uptData.brdgIntntnF, "9");
    strcpy(uptData.updTm, "2017-07-28 19:04:59");
    strcpy(uptData.updUsrNm, "zhaoys");

    DbCmmnSetColBit( keyVct, 0 );
    DbCmmnSetColBit( datVct, 1 );
    DbCmmnSetColBit( datVct, 2 );
    DbCmmnSetColBit( datVct, 4 );
    DbCmmnSetColBit( datVct, 17 );
    DbCmmnSetColBit( datVct, 18 );

    rc = UpdateOrgInfoBrdgByKey(connId, &keyData, keyVct, datVct);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);

}

TEST_F(orgInfoBrdgTest, BatchInsert) {
    ResCodeT rc = NO_ERR;
    OrgInfoBrdgMulti mulData;

    int32 orgSrnoArray[5] = {9501, 9502, 9503, 9504, 9505};
    int32 orgIdArray[5] = {90001, 90002, 90003, 90004, 90005};
    char brdgOrgStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    int32 brdgOrgOrdrArray[5] = {9501, 9502, 9503, 9504, 9505};
    char brdgIntntnFArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgFArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgFNextArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char mdfyStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgUpdTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char brdgPrvlgUpdUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char usrLgnNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char dlrUpdTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char dlrUpdUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char crdtOprtngStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char crdtOprtrArray[5][5+1] = {"lidw1", "lidw2", "lidw3", "lidw4", "lidw5"};
    char crtTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char crtUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char updTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char updUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};

    // Prepare data.
    memset(&mulData, 0x00, sizeof(OrgInfoBrdgMulti));
    mulData.dataRow = 5;
    mulData.orgSrnoLst = orgSrnoArray;
    mulData.orgIdLst = orgIdArray;
    mulData.brdgOrgStLst = (char**)brdgOrgStArray;
    mulData.brdgOrgStMaxSize = 1;
    mulData.brdgOrgOrdrLst = brdgOrgOrdrArray;
    mulData.brdgIntntnFLst = (char**)brdgIntntnFArray;
    mulData.brdgIntntnFMaxSize = 1;
    mulData.brdgPrvlgFLst = (char**)brdgPrvlgFArray;
    mulData.brdgPrvlgFMaxSize = 1;
    mulData.brdgPrvlgFNextLst = (char**)brdgPrvlgFNextArray;
    mulData.brdgPrvlgFNextMaxSize = 1;
    mulData.mdfyStLst = (char**)mdfyStArray;
    mulData.mdfyStMaxSize = 1;
    mulData.brdgPrvlgUpdTmLst = brdgPrvlgUpdTmArray[0];
    mulData.brdgPrvlgUpdTmMaxSize = 19;
    mulData.brdgPrvlgUpdUsrNmLst = (char**)brdgPrvlgUpdUsrNmArray;
    mulData.brdgPrvlgUpdUsrNmMaxSize = 10;
    mulData.usrLgnNmLst = (char**)usrLgnNmArray;
    mulData.usrLgnNmMaxSize = 10;
    mulData.dlrUpdTmLst = dlrUpdTmArray[0];
    mulData.dlrUpdTmMaxSize = 19;
    mulData.dlrUpdUsrNmLst = (char**)dlrUpdUsrNmArray;
    mulData.dlrUpdUsrNmMaxSize = 10;
    mulData.crdtOprtngStLst = (char**)crdtOprtngStArray;
    mulData.crdtOprtngStMaxSize = 1;
    mulData.crdtOprtrLst = (char**)crdtOprtrArray;
    mulData.crdtOprtrMaxSize = 5;
    mulData.crtTmLst = crtTmArray[0];
    mulData.crtTmMaxSize = 19;
    mulData.crtUsrNmLst = (char**)crtUsrNmArray;
    mulData.crtUsrNmMaxSize = 10;
    mulData.updTmLst = updTmArray[0];
    mulData.updTmMaxSize = 19;
    mulData.updUsrNmLst = (char**)updUsrNmArray;
    mulData.updUsrNmMaxSize = 10;

    TRACE("Ready to test batch insert function.\n");
    rc = BatchInsertOrgInfoBrdg(connId, &mulData);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    
}

TEST_F(orgInfoBrdgTest, SingleInsert) {
    ResCodeT rc = NO_ERR;
    OrgInfoBrdg data;
    
    memset(&data, 0x00, sizeof(OrgInfoBrdg));

    // Prepare data.
    data.orgSrno = 9500;
    data.orgId = 100001;
    strcpy(data.brdgOrgSt, "1"); 
    data.brdgOrgOrdr = 100;
    strcpy(data.brdgIntntnF,"0");
    strcpy(data.brdgPrvlgF, "0");
    strcpy(data.brdgPrvlgFNext, "0");
    strcpy(data.mdfySt, "1");
    strcpy(data.brdgPrvlgUpdTm, "2017/07/25 16:30:34");
    strcpy(data.brdgPrvlgUpdUsrNm, "lidw_test");
    strcpy(data.usrLgnNm, "lidw_test");
    strcpy(data.dlrUpdTm, "2017/07/25 16:30:34");
    strcpy(data.dlrUpdUsrNm, "lidw_test");
    strcpy(data.crdtOprtngSt, "0");
    strcpy(data.crdtOprtr, "lidw");
    strcpy(data.crtTm, "2017/07/25 16:30:34");
    strcpy(data.crtUsrNm, "lidw_test");
    strcpy(data.updTm, "2017/07/25 16:30:34");
    strcpy(data.updUsrNm, "lidw_test");

    TRACE("Ready to test batch insert function.\n");
    rc = InsertOrgInfoBrdg(connId, &data);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    
}

TEST_F(orgInfoBrdgTest, InsertSqlTest) {
    ResCodeT rc = NO_ERR;
    OrgInfoBrdgMulti mulData;

    int32 orgSrnoArray[5] = {9501, 9502, 9503, 9504, 9505};
    int32 orgIdArray[5] = {90001, 90002, 90003, 90004, 90005};
    char brdgOrgStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    int32 brdgOrgOrdrArray[5] = {9501, 9502, 9503, 9504, 9505};
    char brdgIntntnFArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgFArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgFNextArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char mdfyStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgUpdTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char brdgPrvlgUpdUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char usrLgnNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char dlrUpdTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char dlrUpdUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char crdtOprtngStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char crdtOprtrArray[5][5+1] = {"lidw1", "lidw2", "lidw3", "lidw4", "lidw5"};
    char crtTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char crtUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char updTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char updUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};

    TRACE("Ready to test batch insert function.\n");
    memset(&mulData, 0x00, sizeof(OrgInfoBrdgMulti));


    mulData.dataRow = 5;
    mulData.orgSrnoLst = orgSrnoArray;
    mulData.orgIdLst = orgIdArray;
    mulData.brdgOrgStLst = (char**)brdgOrgStArray;
    mulData.brdgOrgStMaxSize = 1;
    mulData.brdgOrgOrdrLst = brdgOrgOrdrArray;
    mulData.brdgIntntnFLst = (char**)brdgIntntnFArray;
    mulData.brdgIntntnFMaxSize = 1;
    mulData.brdgPrvlgFLst = (char**)brdgPrvlgFArray;
    mulData.brdgPrvlgFMaxSize = 1;
    mulData.brdgPrvlgFNextLst = (char**)brdgPrvlgFNextArray;
    mulData.brdgPrvlgFNextMaxSize = 1;
    mulData.mdfyStLst = (char**)mdfyStArray;
    mulData.mdfyStMaxSize = 1;
    mulData.brdgPrvlgUpdTmLst = brdgPrvlgUpdTmArray[0];
    mulData.brdgPrvlgUpdTmMaxSize = 19;
    mulData.brdgPrvlgUpdUsrNmLst = (char**)brdgPrvlgUpdUsrNmArray;
    mulData.brdgPrvlgUpdUsrNmMaxSize = 10;
    mulData.usrLgnNmLst = (char**)usrLgnNmArray;
    mulData.usrLgnNmMaxSize = 10;
    mulData.dlrUpdTmLst = dlrUpdTmArray[0];
    mulData.dlrUpdTmMaxSize = 19;
    mulData.dlrUpdUsrNmLst = (char**)dlrUpdUsrNmArray;
    mulData.dlrUpdUsrNmMaxSize = 10;
    mulData.crdtOprtngStLst = (char**)crdtOprtngStArray;
    mulData.crdtOprtngStMaxSize = 1;
    mulData.crdtOprtrLst = (char**)crdtOprtrArray;
    mulData.crdtOprtrMaxSize = 5;
    mulData.crtTmLst = crtTmArray[0];
    mulData.crtTmMaxSize = 19;
    mulData.crtUsrNmLst = (char**)crtUsrNmArray;
    mulData.crtUsrNmMaxSize = 10;
    mulData.updTmLst = updTmArray[0];
    mulData.updTmMaxSize = 19;
    mulData.updUsrNmLst = (char**)updUsrNmArray;
    mulData.updUsrNmMaxSize = 10;

    rc = BatchInsertOrgInfoBrdg(connId, &mulData);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    
}



TEST_F(orgInfoBrdgTest, DeleteSqlTest) {
    ResCodeT rc = NO_ERR;
    TableColumn keyData;

    // key data.
    int32 srnoData = 9501;

//ResCodeT DeleteOrgInfoBrdg(int32 connId, TableColumn* pKeyData);
    TRACE("Ready to test delete function.\n");
    memset(&keyData, 0x00, sizeof(TableColumn));

    // keydata.
    strcpy(keyData.colName, "ORG_SRNO");
    keyData.type = eColumnINTEGER;
    strcpy(keyData.bndName, ":org_srno");
    memcpy(keyData.value, &srnoData, sizeof(int32));

    rc = DeleteOrgInfoBrdg(connId, &keyData);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    

}

// Test the method [UpdateSqlTest]
TEST_F(orgInfoBrdgTest, UpdateSqlTest) {
    ResCodeT rc = NO_ERR;
    TableColumn keyData;
    TableColumn recData[3];

    // key data.
    int32 srnoData = 9500;
    // value data.
    int32 idData = 99999;

    // key multi data.
    int32 orgSrnoArray[5] = {9501, 9502, 9503, 9504, 9505};
    // value multi data.
    int32 orgIdArray[5] = {100101, 100102, 100103, 100104, 100105};
    char brdgPrvlgFArray[5][1+1] = {"0", "0", "0", "0", "0"};
    char brdgPrvlgUpdTmArray[5][19+1] = {"2017-07-17 17:58:59", "2017-07-17 17:59:59", "2017-07-17 18:00:00", "2017-07-17 18:10:00", "2017-07-17 18:20:00"};

//ResCodeT UpdateOrgInfoBrdg(int32 connId, TableColumn* pKeyData, TableColumn* pData, int32 dataCol);
    TRACE("Ready to test update function.\n");
    memset(&keyData, 0x00, sizeof(TableColumn));
    memset(recData, 0x00, sizeof(TableColumn)*3);

    // keydata.
    strcpy(keyData.colName, "ORG_SRNO");
    keyData.type = eColumnINTEGER;
    strcpy(keyData.bndName, ":org_srno");
    memcpy(keyData.value, &srnoData, sizeof(int32));

    // updatedata.
    strcpy(recData[0].colName, "ORG_ID");
    recData[0].type = eColumnINTEGER;
    strcpy(recData[0].bndName, ":org_id"); 
    memcpy(recData[0].value, &idData, sizeof(int32));

    strcpy(recData[1].colName, "BRDG_INTNTN_F");
    recData[1].type = eColumnVARCHAR2;
    strcpy(recData[1].bndName, ":brdg_intntn_f"); 
    memcpy(recData[1].value, "1", sizeof(char));

    strcpy(recData[2].colName, "BRDG_PRVLG_UPD_TM");
    recData[2].type = eColumnTIMESTAMP;
    strcpy(recData[2].bndName, ":brdg_prvlg_upd_tm"); 
    memcpy(recData[2].value, "2017-07-20 15:52:53", sizeof(char)*20);


    rc = UpdateOrgInfoBrdg(connId, &keyData, recData, 3);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    

//ResCodeT BatchUpdateOrgInfoBrdg(int32 connId, TableColumn* pKeyData, TableColumn* pData, int32 dataCol, int32 dataRow);
    TRACE("Ready to test batch update function.\n");

    memset(&keyData, 0x00, sizeof(TableColumn));
    memset(recData, 0x00, sizeof(TableColumn)*3);

    // key data set.
    strcpy(keyData.colName, "ORG_SRNO");
    keyData.type = eColumnINTEGER;
    strcpy(keyData.bndName, ":org_srno");
    keyData.maxSize = sizeof(int32);
    memcpy(keyData.value, orgSrnoArray, sizeof(int32)*5);

    // update data set.
    strcpy(recData[0].colName, "ORG_ID");
    recData[0].type = eColumnINTEGER;
    strcpy(recData[0].bndName, ":org_id");
    recData[0].maxSize = sizeof(int32);
    memcpy(recData[0].value, orgIdArray, sizeof(int32)*5);

    strcpy(recData[1].colName, "BRDG_PRVLG_F");
    recData[1].type = eColumnVARCHAR2;
    strcpy(recData[1].bndName, ":brdg_prvlg_f");
    recData[1].maxSize = sizeof(char);
    memcpy(recData[1].value, brdgPrvlgFArray, (1+1)*5);

    strcpy(recData[2].colName, "BRDG_PRVLG_UPD_TM");
    recData[2].type = eColumnTIMESTAMP;
    strcpy(recData[2].bndName, ":brdg_prvlg_upd_tm");
    recData[2].maxSize = 19;
    memcpy(recData[2].value, brdgPrvlgUpdTmArray, 20*(5 + 1));

    rc = BatchUpdateOrgInfoBrdg(connId, &keyData, recData, 3, 5);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    

}

TEST_F(orgInfoBrdgTest, InsertSqlTest) {
    ResCodeT rc = NO_ERR;
    OrgInfoBrdg data;
    OrgInfoBrdgMulti mulData;
    
    int32 orgSrnoArray[5] = {9501, 9502, 9503, 9504, 9505};
    int32 orgIdArray[5] = {100001, 100002, 100003, 100004, 100005};
    char brdgOrgStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    int32 brdgOrgOrdrArray[5] = {9501, 9502, 9503, 9504, 9505};
    char brdgIntntnFArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgFArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgFNextArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char mdfyStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char brdgPrvlgUpdTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char brdgPrvlgUpdUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char usrLgnNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char dlrUpdTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char dlrUpdUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char crdtOprtngStArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char crdtOprtrArray[5][5+1] = {"lidw1", "lidw2", "lidw3", "lidw4", "lidw5"};
    char crtTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char crtUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};
    char updTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char updUsrNmArray[5][10+1] = {"lidw_test1", "lidw_test2", "lidw_test3", "lidw_test4", "lidw_test5"};

    TRACE("Ready to test batch insert function.\n");
    memset(&data, 0x00, sizeof(OrgInfoBrdg));
    memset(&mulData, 0x00, sizeof(OrgInfoBrdgMulti));


    mulData.dataRow = 5;
    mulData.orgSrnoLst = orgSrnoArray;
    mulData.orgIdLst = orgIdArray;
    mulData.brdgOrgStLst = (char**)brdgOrgStArray;
    mulData.brdgOrgStMaxSize = 1;
    mulData.brdgOrgOrdrLst = brdgOrgOrdrArray;
    mulData.brdgIntntnFLst = (char**)brdgIntntnFArray;
    mulData.brdgIntntnFMaxSize = 1;
    mulData.brdgPrvlgFLst = (char**)brdgPrvlgFArray;
    mulData.brdgPrvlgFMaxSize = 1;
    mulData.brdgPrvlgFNextLst = (char**)brdgPrvlgFNextArray;
    mulData.brdgPrvlgFNextMaxSize = 1;
    mulData.mdfyStLst = (char**)mdfyStArray;
    mulData.mdfyStMaxSize = 1;
    mulData.brdgPrvlgUpdTmLst = brdgPrvlgUpdTmArray[0];
    mulData.brdgPrvlgUpdTmMaxSize = 19;
    mulData.brdgPrvlgUpdUsrNmLst = (char**)brdgPrvlgUpdUsrNmArray;
    mulData.brdgPrvlgUpdUsrNmMaxSize = 10;
    mulData.usrLgnNmLst = (char**)usrLgnNmArray;
    mulData.usrLgnNmMaxSize = 10;
    mulData.dlrUpdTmLst = dlrUpdTmArray[0];
    mulData.dlrUpdTmMaxSize = 19;
    mulData.dlrUpdUsrNmLst = (char**)dlrUpdUsrNmArray;
    mulData.dlrUpdUsrNmMaxSize = 10;
    mulData.crdtOprtngStLst = (char**)crdtOprtngStArray;
    mulData.crdtOprtngStMaxSize = 1;
    mulData.crdtOprtrLst = (char**)crdtOprtrArray;
    mulData.crdtOprtrMaxSize = 5;
    mulData.crtTmLst = crtTmArray[0];
    mulData.crtTmMaxSize = 19;
    mulData.crtUsrNmLst = (char**)crtUsrNmArray;
    mulData.crtUsrNmMaxSize = 10;
    mulData.updTmLst = updTmArray[0];
    mulData.updTmMaxSize = 19;
    mulData.updUsrNmLst = (char**)updUsrNmArray;
    mulData.updUsrNmMaxSize = 10;

    rc = BatchInsertOrgInfoBrdg(connId, &mulData);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);

/*
    data.orgSrno = 9500;
    data.orgId = 100001;
    strcpy(data.brdgOrgSt, "1"); 
    data.brdgOrgOrdr = 100;
    strcpy(data.brdgIntntnF,"0");
    strcpy(data.brdgPrvlgF, "0");
    strcpy(data.brdgPrvlgFNext, "0");
    strcpy(data.mdfySt, "1");
    strcpy(data.brdgPrvlgUpdTm, "2017/07/25 16:30:34");
    strcpy(data.brdgPrvlgUpdUsrNm, "lidw_test");
    strcpy(data.usrLgnNm, "lidw_test");
    strcpy(data.dlrUpdTm, "2017/07/25 16:30:34");
    strcpy(data.dlrUpdUsrNm, "lidw_test");
    strcpy(data.crdtOprtngSt, "0");
    strcpy(data.crdtOprtr, "lidw");
    strcpy(data.crtTm, "2017/07/25 16:30:34");
    strcpy(data.crtUsrNm, "lidw_test");
    strcpy(data.updTm, "2017/07/25 16:30:34");
    strcpy(data.updUsrNm, "lidw_test");

    rc = InsertOrgInfoBrdg(connId, &data);
    if (rc != NO_ERR) {
        EXPECT_EQ(rc, NO_ERR);
        return ;
    }
    EXPECT_EQ(rc, NO_ERR);
*/


    rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc, NO_ERR);    
}

#endif

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);

    // Adds the leak checker to the end of the test event listener list,
    // after the default text output printer and the default XML report
    // generator.
    //
    // The order is important - it ensures that failures generated in the
    // leak checker's OnTestEnd() method are processed by the text and XML
    // printers *before* their OnTestEnd() methods are called, such that
    // they are attributed to the right test. Remember that a listener
    // receives an OnXyzStart event *after* listeners preceding it in the
    // list received that event, and receives an OnXyzEnd event *before*
    // listeners preceding it.
    //
    // We don't need to worry about deleting the new listener later, as

    return RUN_ALL_TESTS();
}

// Step 3. Call RUN_ALL_TESTS() in main().
//
// We do this by linking in src/gtest_main.cc file, which consists of
// a main() function which calls RUN_ALL_TESTS() for us.
//
// This runs all the tests you've defined, prints the result, and
// returns 0 if successful, or 1 otherwise.
//
// Did you notice that we didn't register the tests?  The
// macro magically knows about all the tests we
// defined.  Isn't this convenient?
