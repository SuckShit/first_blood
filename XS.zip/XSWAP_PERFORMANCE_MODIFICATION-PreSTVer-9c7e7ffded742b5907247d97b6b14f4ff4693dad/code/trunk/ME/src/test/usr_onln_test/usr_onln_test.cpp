/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "usr_onln.h"
#include "shm.h"
#include "gtest/gtest.h"

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/


/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char dbAddress[] = "200.31.155.145:1521/xswapdb";
static char username[] = "xswap";
static char password[] = "xswap";

int32 connId = 0;


/***********************************************************************************************
**
**   Functiona Declaration                                                                           
**
************************************************************************************************/


/***********************************************************************************************
**
**   Functiona Implementation                                                                           
**
************************************************************************************************/
using ::testing::InitGoogleTest; 


class RoleTest : public testing::Test {
//protected:
    // You should make the members protected s.t. they can be
    // accessed from sub-classes.

    // virtual void SetUp() will be called before each test is run.  You
    // should define it if you need to initialize the varaibles.
    // Otherwise, this can be skipped.
    virtual void SetUp() {}

    // virtual void TearDown() will be called after each test is run.
    // You should define it if there is cleanup work to do.  Otherwise,
    // you don't have to provide it.
    //
    virtual void TearDown() {}
};


TEST(RoleTest, RoleInfoLoad)
{
    ResCodeT rc = 0;

	DbCmmnInit();
	
    rc = DbCmmnConnect(dbAddress, username, password, &connId);
    EXPECT_EQ(rc,NO_ERR);

    rc = IrsUsrOnlnInfoLoadFromDb(connId);
	EXPECT_EQ(rc,NO_ERR);
}

TEST(RoleTest, RoleInfoDelete)
{
    ResCodeT rc = 0;

	rc = IrsUsrOnlnInfoDetachFromShm();
	EXPECT_EQ(rc, NO_ERR);
	ShmDelete((char*)SHM_IRS_USR_ONLN_NAME);

	#if 0
	memset(&Dlkey, 0, sizeof(UsrRoleKey));
	strcpy(Dlkey.usrNm, "jh003");
	rc = DeleteUsrRole(connId, &Dlkey);
	EXPECT_EQ(rc, NO_ERR);
	rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc,NO_ERR);


    #endif
}


TEST(RoleTest, RoleInfoUpdate)
{
    UsrOnlnBaseInfoT recDate;
	ResCodeT rc = 0;
	#if 1
	rc = IrsUsrOnlnUpdateByName(connId, (char*)"anny", 6);
    EXPECT_EQ(rc, NO_ERR);

	rc = IrsUsrOnlnInfoGetByName((char*)"anny", &recDate);
    EXPECT_EQ(rc, NO_ERR);

	#endif
}


int main(int argc, char **argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

