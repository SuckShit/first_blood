/***
Created on Sep 13, 2017
@author: XiaoPing Zhou
@version $Id
***/
// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)


// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include <limits.h>
#include <pthread.h>          
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include "mkt_st_cfg.h"
#include "shm.h"
#include "db_comm.h"
#include "common_macro.h"
#include "MktStCfgDb.h"
#include "gtest/gtest.h"
#include "cfg_lib.h"



// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.
using ::testing::InitGoogleTest; 

int32 connId;

class mktStCfgTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // printf("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // printf("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
        ResCodeT rc = NO_ERR;
        cfgValueS cfgValue = {0};
        
        DbCmmnInit();
		
		char prcsName[] = "";
        PrcsInit(prcsName); 
      
        rc = GetCfgValue(&cfgValue);
        EXPECT_EQ(rc,NO_ERR);
      
        rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        RAISE_ERR(rc, RTN);
        
        rc = MktStCfgLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);
        
    }
    
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        
        rc = MktStCfgDetachFromShm();
        EXPECT_EQ(rc, NO_ERR);
        
        DbCmmnDisconnect(connId);
        DbCmmnCleanup();
        ShmDelete((char*)SHM_MKT_ST_CFG_NAME);
    }   

};



/****************************** The test methods of Credit  ************************************************/
// Test the method [MktStCfgGetByKey]
TEST_F(mktStCfgTest, mktStCfgGetByKey) {
    
    ResCodeT rc = NO_ERR;
    MktStCfgT testData; 
    uint64 key1;
    
    // Specify the key of the test data
    key1 = 1;
    rc = MktStCfgGetByKey(key1, &testData);
    EXPECT_EQ(rc, NO_ERR);

    // Also verify that the fields in testData are equal to the test data.
    EXPECT_EQ(testData.mktStCfgId, 1);
    EXPECT_EQ(testData.mktSt, 1);
    EXPECT_EQ(strcmp(testData.strtTm, "09:00"), 0);
    EXPECT_EQ(strcmp(testData.nextStrtTm, "09:00"), 0);
    EXPECT_EQ(testData.sendFlag, 0);
    
    // Specify the contract name that doesn't exist in the test data
    rc = MktStCfgGetByKey(999999, &testData);
    EXPECT_EQ(rc, ERR_CMN_HASH_LIST_NODE_NOT_EXIST);

}


// Test the method [MktStCfgGetByKeyExt]
TEST_F(mktStCfgTest, mktStCfgGetByKeyExt) {
    
    ResCodeT rc = NO_ERR;
    MktStCfgT verifyData;
    pMktStCfgT pData;
    
    // Specify the contract name that exists in the test data
    rc = MktStCfgGetByKeyExt(1, &pData);
    EXPECT_EQ(rc, NO_ERR);

    // also verify that the fields in pData are equal to the test data.
    EXPECT_EQ(pData->mktStCfgId, 1);
    EXPECT_EQ(pData->mktSt, 1);
    EXPECT_EQ(strcmp(pData->strtTm, "09:00"), 0);
    EXPECT_EQ(strcmp(pData->nextStrtTm, "09:00"), 0);
    EXPECT_EQ(pData->sendFlag, 0);
    
    // Specify the contract name that doesn't exist in the test data
    rc = MktStCfgGetByKeyExt(999999, &pData);
    EXPECT_EQ(rc, ERR_CMN_HASH_LIST_NODE_NOT_EXIST);


    // Specify the contract name that exists in the test data
    rc = MktStCfgGetByKeyExt(2, &pData);
    EXPECT_EQ(rc, NO_ERR);

    // use the pData to change some value. Then call CreditInfoGetByKey to 
    // verify that the values in the shared memory also have been changed.
    pData->sendFlag = 1;
    strcpy(pData->nextStrtTm, "10:30");
    
    rc = MktStCfgGetByKey(2, &verifyData);
    EXPECT_EQ(rc, NO_ERR);
    EXPECT_EQ(strcmp(verifyData.nextStrtTm, "10:30"), 0);
    EXPECT_EQ(verifyData.sendFlag, 1);
    
}



// Test the method [MktStCfgGetByPos]
TEST_F(mktStCfgTest, mktStCfgGetByPos) {
    
    ResCodeT rc = NO_ERR;
    MktStCfgT testData,posData;
    int32 dataPos;    
    
    rc = MktStCfgGetByKey(1, &posData);
    EXPECT_EQ(rc, NO_ERR);
    dataPos = posData.pos;
    
    // Specify the contract position of the test data
    rc = MktStCfgGetByPos(dataPos, &testData);
    EXPECT_EQ(rc, NO_ERR);

    // also verify that the fields in pData are equal to the test data.
	EXPECT_EQ(testData.mktStCfgId, 1);
    EXPECT_EQ(testData.mktSt, 1);
    EXPECT_EQ(strcmp(testData.strtTm, "09:00"), 0);
    EXPECT_EQ(strcmp(testData.nextStrtTm, "09:00"), 0);
    EXPECT_EQ(testData.sendFlag, 0);
	
   
    // Specify the position value that is too big
    rc = MktStCfgGetByPos(100000, &testData);
    EXPECT_EQ(rc, ERCD_ARCH_BUFF_TOO_SHORT);
    
}


// Test the method [MktStCfgGetByPosExt]
TEST_F(mktStCfgTest, mktStCfgGetByPosExt) {
    
    ResCodeT rc = NO_ERR;
    MktStCfgT posData,verifyData;
    pMktStCfgT pData; 
    int32 dataPos;    
    
    rc = MktStCfgGetByKey(3, &posData);
    EXPECT_EQ(rc, NO_ERR);
    dataPos = posData.pos;
    
    // Specify the contract position of the test data
    rc = MktStCfgGetByPosExt(dataPos, &pData);
    EXPECT_EQ(rc, NO_ERR);

    // also verify that the fields in pData are equal to the test data.
	EXPECT_EQ(pData->mktStCfgId, 3);
    EXPECT_EQ(pData->mktSt, 3);
    EXPECT_EQ(strcmp(pData->strtTm, "12:00"), 0);
    EXPECT_EQ(strcmp(pData->nextStrtTm, "12:00"), 0);
    EXPECT_EQ(pData->sendFlag, 0);
	
   
    // Specify the position value that is too big
    rc = MktStCfgGetByPosExt(100000, &pData);
    EXPECT_EQ(rc, ERCD_ARCH_BUFF_TOO_SHORT);


    // Specify the position of the test data
    rc = MktStCfgGetByPosExt(dataPos, &pData);
    EXPECT_EQ(rc, NO_ERR);

    // use the pData to change some value. Then call IrsCntrctInfoGetByPos to 
    // verify that the values in the shared memory also have been changed.
    pData->sendFlag = 2;
    strcpy(pData->nextStrtTm, "13:45");
    
    rc = MktStCfgGetByKey(3, &verifyData);
    EXPECT_EQ(rc, NO_ERR);
    EXPECT_EQ(verifyData.sendFlag, 2);
    EXPECT_EQ(strcmp(verifyData.nextStrtTm, "13:45"), 0);
    
}



int main(int argc, char **argv) {

    // monEnv = new MonTestEnv;
    // testing::AddGlobalTestEnvironment(monEnv);
    testing::InitGoogleTest(&argc, argv);

    // Adds the leak checker to the end of the test event listener list,
    // after the default text output printer and the default XML report
    // generator.
    //
    // The order is important - it ensures that failures generated in the
    // leak checker's OnTestEnd() method are processed by the text and XML
    // printers *before* their OnTestEnd() methods are called, such that
    // they are attributed to the right test. Remember that a listener
    // receives an OnXyzStart event *after* listeners preceding it in the
    // list received that event, and receives an OnXyzEnd event *before*
    // listeners preceding it.
    //
    // We don't need to worry about deleting the new listener later, as

    return RUN_ALL_TESTS();
}

// Step 3. Call RUN_ALL_TESTS() in main().
//
// We do this by linking in src/gtest_main.cc file, which consists of
// a main() function which calls RUN_ALL_TESTS() for us.
//
// This runs all the tests you've defined, prints the result, and
// returns 0 if successful, or 1 otherwise.
//
// Did you notice that we didn't register the tests?  The
// macro magically knows about all the tests we
// defined.  Isn't this convenient?
