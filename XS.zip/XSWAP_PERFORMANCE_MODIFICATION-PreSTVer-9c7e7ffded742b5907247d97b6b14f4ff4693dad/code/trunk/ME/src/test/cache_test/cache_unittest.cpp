/***
Created on May 08, 2017
@author: Ming.Kong
@version $Id
***/


#include <limits.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include "msg_cache.h"
#include "err_cod.h"
#include "gtest/gtest.h"

int32 gMsgCacheIdx; 
int32 predictedSlot;

#if 0
void* thread3_1(void *)
{
    SlotT slot = 9999;
    int32* pData; 
    int i= 0;
    ResCodeT rc;
	
    rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
    if (rc != 1)
    {
    }

    for(int i=1; i < 10; i++)
    {
        slot = 9999;
        rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
        if (rc != 1)
        {
        }
    }

    sleep(2);
    //can not read 
    slot = 9999;
    rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
    EXPECT_EQ(ERCD_ARCH_READ_TRY_AGAIN, rc);
    EXPECT_EQ(9999, slot);

    sleep(3);
    //can read
    slot = 9999;
    rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
    EXPECT_EQ(1, rc);
    EXPECT_EQ(predictedSlot, slot);

    return NULL;
}

void* thread3_2(void *)
{
    SlotT slot = 9999;
    int32* pData; 
    int i= 0;
    ResCodeT rc;

    rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
    if (rc != 1)
    {
    }

    return NULL;
}

void* thread3_3(void *)
{
    SlotT slot = 9999;
    int32* pData; 
    int i= 0;
    ResCodeT rc;

    rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
    
    *pData = 8888;
    
    if (rc != 1)
    {
    }

    sleep(3);

    //write 
    rc = MsgCacheReleaseSlot(gMsgCacheIdx, slot);
    
    pData = NULL;
    MsgCacheGetSlotAddr(gMsgCacheIdx, slot, (void**)&pData);
    EXPECT_EQ(8888, *pData);
    
    if (rc != 1)
    {
    }
    predictedSlot = slot + 1;

    //write 32 -> 21-29 ,30 write in to shm 
    rc = MsgCacheReleaseSlot(gMsgCacheIdx, 32);
    if (rc != 1)
    {
    }
    
    return NULL;
}

void* thread3_4(void *)
{
    SlotT slot = 9999;
    int32* pData; 
    ResCodeT rc;

    sleep(1);
    
    rc = MsgCacheResrveSlot(gMsgCacheIdx, &slot, (void**)&pData);
    if (rc != 1)
    {

    }

    EXPECT_EQ(1, rc);
    EXPECT_EQ(31, slot);

    return NULL;
}

TEST(cacheTest, threadTothread3) {

    pthread_t id_1;
    pthread_t id_2;
    pthread_t id_3;
    pthread_t id_4;

    ResCodeT rc;
    MsgCacheConfigT cfg;
    cfg.frstLevelElemCnt = 32;
    cfg.secLevelElemCnt = 10;
    cfg.elemSize  = sizeof(uint32);
    cfg.threadCnt = 5;

    rc = MsgCacheCreate((char*)"./testCache", &cfg, &gMsgCacheIdx);
    if (rc != 1)
    {
    }
    pthread_create(&id_1, NULL, thread3_1, (void*)NULL);
    pthread_create(&id_2, NULL, thread3_2, (void*)NULL);
    pthread_create(&id_3, NULL, thread3_3, (void*)NULL);
    pthread_create(&id_4, NULL, thread3_4, (void*)NULL);

    pthread_join(id_1,NULL);
    pthread_join(id_2,NULL);
    pthread_join(id_3,NULL);
    pthread_join(id_4,NULL);

    rc = MsgCacheDestroy(gMsgCacheIdx);
    if (rc != 1)
    {
    }
}

//int main(int argc, char **argv) {
//    testing::InitGoogleTest(&argc, argv);
//    return RUN_ALL_TESTS();
//}

#endif
