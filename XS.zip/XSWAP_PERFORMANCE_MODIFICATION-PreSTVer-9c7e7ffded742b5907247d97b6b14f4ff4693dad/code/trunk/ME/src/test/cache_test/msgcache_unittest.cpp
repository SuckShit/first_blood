/***
Created on June 29, 2017
@author: Jiawwang.Xie
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
#include "gtest/gtest.h"
#include "msg_cache.h"
#include "shm_name.h"
#include "uti_tool.h"
#include "common_macro.h"
#include <sys/epoll.h>              /* define wait handling functions     */
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define TEST_SET_ID_1   1
#define TEST_CASE_2_CNT 102
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
int32   gInputQHndl = -1;
int32   gOutputQHndl = -1;
int32       WaitFd;
BOOL    gbRunFlg = TRUE;
using ::testing::InitGoogleTest;
    
int32   gTestCase = 0;

static struct epoll_event gWaitEvent;
/******************************************************************************
 **
 ** MsgCacheCommonTest Class
 **
 ******************************************************************************/

ResCodeT ReadMsgFromQ()
{
    pMsgCacheSlotT pReqMsgSlot = NULL;
    pMsgCacheSlotT pRspMsgSlot = NULL;
    ResCodeT rc = NO_ERR;
    SlotT       slot = -1;
    
    rc = MsgQueueReadSlot(gInputQHndl, &slot);
    if(rc == ERCD_ARCH_READ_TRY_AGAIN)
    {
        return 1;
    }
    EXPECT_EQ(rc, NO_ERR);
                
    
    rc = MsgGetSlot(slot, &pReqMsgSlot);
    EXPECT_EQ(rc, NO_ERR);
                

    rc = MsgGetSlotRsp(slot, &pRspMsgSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    rc = MsgQueueWriteSlot(gOutputQHndl,slot);
    EXPECT_EQ(rc, NO_ERR);
                

    return 1;
}

ResCodeT InitQueue(int32 queueSize, int32 itemSize, int32 * pHndl)
{
    MsgQueueCfgT        msgQCfg;
    ResCodeT            rc = NO_ERR;
    int32               ttlSize = 0;
    void *              pQueueAddr = NULL;

    msgQCfg.type = Q_TYPE_MW1R;
    msgQCfg.itemCnt = queueSize * 2;  /* enlarge the buffer queue */
    msgQCfg.itemSize = itemSize;
    msgQCfg.threadCnt = 10;

    rc = MsgQueueCalcSize(&msgQCfg, (uint32*)&ttlSize);
    EXPECT_EQ(rc, NO_ERR);
                

    MALLOC(pQueueAddr, ttlSize)

    rc = MsgQueueCreate(&msgQCfg,pHndl,pQueueAddr);
    EXPECT_EQ(rc, NO_ERR);
                
    return 1;
}/* End of InitOutBuffQueue */

ResCodeT InitWaitQueue(int32 * pInQHndl)
{
    BEGIN_FUNCTION( "InitWaitQueue" );
    ResCodeT            rc = NO_ERR;
    int32               queueFd = 0;
    int32               i = 0;

    WaitFd = epoll_create(10);
    if (WaitFd < 0)
    {

    }


    rc = MsgQueueGetFd(pInQHndl[i], &queueFd);
    EXPECT_EQ(rc, NO_ERR);
                



    gWaitEvent.events = EPOLLIN| EPOLLRDHUP|EPOLLERR|EPOLLHUP;
    gWaitEvent.data.fd = queueFd;
    gWaitEvent.data.ptr = (void *)pInQHndl;


    if (epoll_ctl(WaitFd,EPOLL_CTL_ADD, queueFd, &gWaitEvent))
    {
        
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of InitWaitQueue */


/******************************************************************************
 * Description:   main call back to run the process logic
 * Parameters:
 *      rtnCode     OUT     function return value
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to create the share memory.
 ******************************************************************************/
void * RunFunc(void * rtnCode)
{
    BEGIN_FUNCTION( "RunFunc" );
    struct epoll_event waitEvent[10];
    int32 queueCnt = 0;
    ResCodeT rc = NO_ERR;


    do
    {
        queueCnt = epoll_wait(WaitFd, waitEvent,10, 10);

        if (queueCnt<0 && errno != EINTR)
        {

            RAISE_ERR( ERR_APP_EPOLL_WAIT_ERR, RTN );
        }
        else if  (queueCnt<0 && errno == EINTR)
        {
            //RAISE_ERR( ERR_APP_EPOLL_WAIT_ERR, NORTN );
            //usleep(1000000);
            continue;
        }
        else if (queueCnt == 0)
        {
            ReadMsgFromQ();
        }
        else
        {
            ReadMsgFromQ();
        }
    } while (gbRunFlg);

    EXIT_BLOCK();
    
    

    //*((int32 *) rtnCode) = GET_RESCODE();
}/* End of ShlRunFunc */

class MsgCacheCommonTest : public testing::Test
{
protected:  // You should make the members protected s.t. they can be
    virtual void SetUp()
    {
        LogInit((char*)"");
    }

    virtual void TearDown()
    {
    }

    static void SetUpTestCase()
    {
       
        char appName[] = "";
        PrcsInit(appName);

        ResCodeT rc = NO_ERR;

        rc =  MsgCreate(4096, 100, 10);
        ASSERT_EQ(rc, NO_ERR);
        
        
        rc = InitQueue(1024, sizeof(SlotT), &gInputQHndl);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = InitQueue(1024, sizeof(SlotT), &gOutputQHndl);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = InitWaitQueue(&gInputQHndl);
        ASSERT_EQ(rc, NO_ERR);
    }

    static void TearDownTestCase()
    {
        ResCodeT rc = NO_ERR;

        rc = MsgDetach();
        ASSERT_EQ(rc, NO_ERR);
        
        rc = MsgDestory();
        ASSERT_EQ(rc, NO_ERR);
        TRACE("========================================= MsgCache Test End =========================================\n");
    }
};

/******************************************************************************
 **
 ** Thread_1
 **     + 110
 **     sleep 1
 **     - 19 (from 91 to 109)
 **     sleep 1
 **     + 10
 **
 ******************************************************************************/
void* thread_sender_1(void *)
{
    ResCodeT rc = NO_ERR;

    SlotT slot = -1;
    char* pMsg = (char*)"";
    int i = 0;
    SlotT slotId;
    pMsgCacheSlotT pReqSlot;
    pMsgCacheSlotT pRespSlot;
    
    switch (gTestCase)
    {
        case 1:
            // step 1: reserve slot, and set the memory
            for (i = 0; i < 20; i++)
            {
                rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot,&pRespSlot);
                EXPECT_EQ(rc, NO_ERR);
                
                rc = MsgQueueWriteSlot(gInputQHndl,slotId);
                EXPECT_EQ(rc, NO_ERR);
            }
            break;
       case 2:
            // step 1: reserve slot, and set the memory
            for (i = 0; i < TEST_CASE_2_CNT; i++)
            {
                rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot,&pRespSlot);
                EXPECT_EQ(rc, NO_ERR);
                
                rc = MsgQueueWriteSlot(gInputQHndl,slotId);
                EXPECT_EQ(rc, NO_ERR);
            }
            break;     
    }

   
    rc = MsgCacheCleanThread();
    EXPECT_EQ(rc, NO_ERR);
    LOG_DEBUG("Thread 1 Exit");
    return NULL;
}

/******************************************************************************
 **
 ** Thread_2
 **     + 110
 **     sleep 1
 **     - 20 (from 91 to 110)
 **     sleep 1
 **     + 10
 **
 ******************************************************************************/
void* thread_sender_2(void *)
{
    ResCodeT rc = NO_ERR;

    SlotT slot = -1;
    char* pMsg = (char*)"";
    int i = 0;
    SlotT slotId;
    pMsgCacheSlotT pReqSlot;
    pMsgCacheSlotT pRespSlot;
    
    switch (gTestCase)
    {
        case 1:
            // step 1: reserve slot, and set the memory
            for (i = 0; i < 20; i++)
            {
                rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot,&pRespSlot);
                EXPECT_EQ(rc, NO_ERR);
                
                rc = MsgQueueWriteSlot(gInputQHndl,slotId);
                EXPECT_EQ(rc, NO_ERR);
            }
            break;
        case 2:
            // step 1: reserve slot, and set the memory
            for (i = 0; i < TEST_CASE_2_CNT; i++)
            {
                rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot,&pRespSlot);
                EXPECT_EQ(rc, NO_ERR);
                
                rc = MsgQueueWriteSlot(gInputQHndl,slotId);
                EXPECT_EQ(rc, NO_ERR);
            }
            break;         
    }
    rc = MsgCacheCleanThread();
    EXPECT_EQ(rc, NO_ERR);
    LOG_DEBUG("Thread 2 Exit");
    return NULL;
}

/******************************************************************************
 **
 ** Thread_3
 **     + 110
 **     sleep 1
 **     - 20 (from 110 to 91)
 **     sleep 1
 **     + 10
 **
 ******************************************************************************/
void* thread_sender_3(void *)
{
    ResCodeT rc = NO_ERR;

    SlotT slot = -1;
    char* pMsg = (char*)"";
    int i = 0;
    SlotT slotId;
    pMsgCacheSlotT pReqSlot;
    pMsgCacheSlotT pRespSlot;
    
    switch (gTestCase)
    {
        case 1:
            // step 1: reserve slot, and set the memory
            for (i = 0; i < 20; i++)
            {
                rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot,&pRespSlot);
                EXPECT_EQ(rc, NO_ERR);
                
                rc = MsgQueueWriteSlot(gInputQHndl,slotId);
                EXPECT_EQ(rc, NO_ERR);
            }
            break;
        case 2:
            // step 1: reserve slot, and set the memory
            for (i = 0; i < TEST_CASE_2_CNT; i++)
            {
                rc = MsgRsrvSlotsPaired(&slotId, &pReqSlot,&pRespSlot);
                EXPECT_EQ(rc, NO_ERR);
                
                rc = MsgQueueWriteSlot(gInputQHndl,slotId);
                EXPECT_EQ(rc, NO_ERR);
            }
            break;         
    }
    
    rc = MsgCacheCleanThread();
    EXPECT_EQ(rc, NO_ERR);
    LOG_DEBUG("Thread 3 Exit");
    return NULL;
}

/******************************************************************************
 **
 ** Thread_4
 **     + 110
 **     sleep 1
 **     - 19 (from 110 to 92)
 **     sleep 1
 **     + 10
 **
 ******************************************************************************/
void* thread_responser_1(void *)
{
    ResCodeT rc = NO_ERR;
    int i = 0;
    SlotT slotId;
    pMsgCacheSlotT pReqSlot;
    pMsgCacheSlotT pRespSlot;
    
    int32       msgCnt = 0;
    

    // step 1: reserve slot, and set the memory
    do
    {
        
        rc = MsgQueueReadSlot(gOutputQHndl, &slotId);
        if (rc == ERCD_ARCH_READ_TRY_AGAIN)
        {
            continue;
        }
        EXPECT_EQ(rc, NO_ERR);
        
        msgCnt++;
        
        rc = MsgGetSlot(slotId, &pReqSlot);
        EXPECT_EQ(rc, NO_ERR);
        
        rc = MsgGetSlotRsp(slotId, &pRespSlot);
        EXPECT_EQ(rc, NO_ERR);
        
        rc = MsgDelete(slotId);
        EXPECT_EQ(rc, NO_ERR);
        
        if (1== gTestCase)
        {
            if (msgCnt >= 20*3)
            {
                break;
            }
        } 
        else if (2== gTestCase)
        {
            if (msgCnt >= TEST_CASE_2_CNT*3)
            {
                break;
            }
        }
        
        
        
    } while (TRUE);
    
    rc = MsgQueueReadSlot(gOutputQHndl, &slotId);
    EXPECT_EQ(ERCD_ARCH_READ_TRY_AGAIN, rc);

    rc = MsgCacheCleanThread();
    EXPECT_EQ(rc, NO_ERR);
    LOG_DEBUG("Resp Thread 1 Exit");
    return NULL;
}

/******************************************************************************
 **
 ** Multi-Thread Test
 **     Thread_1, Thread_2, Thread_3, Thread_4, Thread_5
 **
 ******************************************************************************/
TEST_F(MsgCacheCommonTest, MultiThreadTest)
{
    ResCodeT rc = NO_ERR;
    pthread_t sender_1;
    pthread_t sender_2;
    pthread_t sender_3;
    pthread_t prcser_1;
    pthread_t responser_1;
    
    int32    maxCnt, usedCnt;
    // case 1
    gTestCase = 1;
    pthread_create(&sender_1, NULL, thread_sender_1, (void*)NULL);
    pthread_create(&sender_2, NULL, thread_sender_2, (void*)NULL);
    pthread_create(&sender_3, NULL, thread_sender_3, (void*)NULL);
    pthread_create(&prcser_1, NULL, RunFunc, (void*)NULL);
    pthread_create(&responser_1, NULL, thread_responser_1, (void*)NULL);
    
    pthread_join(sender_1, NULL);
    pthread_join(sender_2, NULL);
    pthread_join(sender_3, NULL);
    pthread_join(responser_1, NULL);
    
    gbRunFlg = FALSE;
    pthread_join(prcser_1, NULL);
    
    rc = GetMsgCount(&maxCnt, &usedCnt);
    EXPECT_EQ(rc, NO_ERR);
    
    EXPECT_EQ(maxCnt, 4096);
    EXPECT_EQ(usedCnt, 1);
    
    LOG_DEBUG("========== Case 1 done ==================================================");
    // case 2
    gTestCase = 2;
    gbRunFlg = TRUE;
    pthread_create(&sender_1, NULL, thread_sender_1, (void*)NULL);
    pthread_create(&sender_2, NULL, thread_sender_2, (void*)NULL);
    pthread_create(&sender_3, NULL, thread_sender_3, (void*)NULL);
    pthread_create(&prcser_1, NULL, RunFunc, (void*)NULL);
    pthread_create(&responser_1, NULL, thread_responser_1, (void*)NULL);
    
    pthread_join(sender_1, NULL);
    pthread_join(sender_2, NULL);
    pthread_join(sender_3, NULL);
    pthread_join(responser_1, NULL);
    
    gbRunFlg = FALSE;
    pthread_join(prcser_1, NULL);
    
    rc = GetMsgCount(&maxCnt, &usedCnt);
    EXPECT_EQ(rc, NO_ERR);
    
    EXPECT_EQ(maxCnt, 4096);
    EXPECT_EQ(usedCnt, 1);
    LOG_DEBUG("========== Case 2 done ==================================================");

}


/******************************************************************************
 **
 ** main
 **
 ******************************************************************************/
int main(int argc, char **argv)
{
    InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}
