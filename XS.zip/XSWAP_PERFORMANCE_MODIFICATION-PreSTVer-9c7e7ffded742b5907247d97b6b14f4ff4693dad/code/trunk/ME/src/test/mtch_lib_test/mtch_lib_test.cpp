﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/

#include <limits.h>
#include "err_lib.h"    
#include "app_shl.h"            
#include "gtest/gtest.h"
#include "msg_cache.h"
#include "UTILITY/logfile.h"
#include "Utils.h"
#include "order_book.h"
#include "match_lib.h"
#include "mem_txn.h"
#include "uti_tool.h"
#include "user_order.h"
#include "nmbr_srvc.h"
#include "ordr_mgmt.h"
#define TEST_SET_ID_1   1

using ::testing::InitGoogleTest; 


class MatchLibCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {
        

       
    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char appName[] = "";
        PrcsInit(appName);

        ResCodeT rc = NO_ERR;
        MemTxnCfgT memTxnCfg[2];
        
        memTxnCfg[0].setId = TEST_SET_ID_1;
        memTxnCfg[0].nmbrOfTxn = 1000;
        memTxnCfg[0].dataSize = 512;
       
        
        rc = MemTxnShmCreateForAllSet(memTxnCfg, 1);
        ASSERT_EQ(rc, NO_ERR);
        
        OrdrBkCfgT  ordrBkCfg = {0};
        ordrBkCfg.nmbrOfOrdr = 10000;
        ordrBkCfg.nmbrOfPrdct = 1000;
        ordrBkCfg.setId = TEST_SET_ID_1;
        ordrBkCfg.nmbrOfEnty = 100;
        
        rc = NmbrSrvcShmCreate(1);
        ASSERT_EQ(rc, NO_ERR);
         
        rc = OrdrBkShmCreate(&ordrBkCfg);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = OrdrMgmtShmCreate(10000,TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = MtchrInit(TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
    }
    
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        rc = MtchrDetach(TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = OrdrBkShmDelete(TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc =  MemTxnShmDetach();
        ASSERT_EQ(rc, NO_ERR);
        
        rc =  MemTxnShmDelete();
        ASSERT_EQ(rc, NO_ERR);
        
      
    }   
};
  


TEST_F(MatchLibCommonTest, AddOrdr) {
    ResCodeT rc = NO_ERR;
    
    PrdctInfoT      prdctInfo;
    MtchInfoT       mtchInfo;
    
    pOrderT          pBuyOrdr;
    pOrderT          pSellOrdr;

    
    NewOrderSingleReqT  buyOrder;
    NewOrderSingleReqT  sellOrder;
    NewOrderSingleRspT  orderRsp;
    
    memset(&buyOrder, 0x00, sizeof(OrderT));
    
    int64 txnId, timestamp;
    
    rc = MemTxnStart(TEST_SET_ID_1, &txnId, &timestamp);
    EXPECT_EQ(rc,NO_ERR);
    
    
    buyOrder.newOrdrInfo.userIdx = 1;
    buyOrder.newOrdrInfo.contractPos = 1;
    buyOrder.newOrdrInfo.side = ORDR_SIDE_BUY;
    buyOrder.newOrdrInfo.prcQtyInfo.price = 10;
    buyOrder.newOrdrInfo.prcQtyInfo.qty = 100;
    buyOrder.newOrdrInfo.effectTime = 1;
    buyOrder.newOrdrInfo.ordType;
    buyOrder.newOrdrInfo.execInst = EXEC_INST_ORD_NEW;
    buyOrder.newOrdrInfo.ordAction = ORDR_ACT_NEW;    
   
    rc = MtchrCreateOrdrFromOrdrInfo(TEST_SET_ID_1, &buyOrder.newOrdrInfo, &pBuyOrdr,FALSE, NULL);
    EXPECT_EQ(rc,NO_ERR);
    
    
    rc = MtchrPrcsOrdrAdd(FALSE, TRUE, TEST_SET_ID_1, &prdctInfo, pBuyOrdr, pBuyOrdr->orderF.tranTime, &orderRsp, &mtchInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(orderRsp.rspOrder[0].price,buyOrder.newOrdrInfo.prcQtyInfo.price);
    EXPECT_EQ(orderRsp.rspOrder[0].qty,buyOrder.newOrdrInfo.prcQtyInfo.qty);
    
    sellOrder.newOrdrInfo.userIdx = 1;
    sellOrder.newOrdrInfo.contractPos = 1;
    sellOrder.newOrdrInfo.side = ORDR_SIDE_SELL;
    sellOrder.newOrdrInfo.prcQtyInfo.price = 10;
    sellOrder.newOrdrInfo.prcQtyInfo.qty = 100;
    sellOrder.newOrdrInfo.effectTime = 2;
    sellOrder.newOrdrInfo.ordType;
    sellOrder.newOrdrInfo.execInst = EXEC_INST_ORD_NEW;
    sellOrder.newOrdrInfo.ordAction = ORDR_ACT_NEW;    
   

    rc = MtchrCreateOrdrFromOrdrInfo(TEST_SET_ID_1, &sellOrder.newOrdrInfo, &pSellOrdr,FALSE, NULL);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MtchrPrcsOrdrAdd(FALSE, TRUE, TEST_SET_ID_1, &prdctInfo, pSellOrdr, pSellOrdr->orderF.tranTime, &orderRsp, &mtchInfo);
    EXPECT_EQ(rc,NO_ERR);
     
    EXPECT_EQ(orderRsp.rspOrder[0].price,sellOrder.newOrdrInfo.prcQtyInfo.price);
    EXPECT_EQ(orderRsp.rspOrder[0].qty,sellOrder.newOrdrInfo.prcQtyInfo.qty);
    
//    pOrderT pOrderCreate;
//    pOrderT pOrderSell;
//    
//    OrderFT  buyOrder; 
//    OrderFT  sellOrder; 
//    pOrderT pBestO;
//    int32  ordrMask  = 0;
//    memset(&buyOrder,0x00,sizeof(OrderFT));
//    memset(&sellOrder,0x00,sizeof(OrderFT));
//    
//    OrdrRbInfoT ordrRbInfo;
//    
//    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    memcpy(&pOrderCreate->orderF, &buyOrder, sizeof(OrderFT));
//    
//    rc = OrdrBkAddOrdr(TEST_SET_ID_1, &pOrderCreate, &ordrRbInfo);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    ordrMask |= ORDR_SIDE_BUY;
//    ordrMask |= ORDR_TRDRESTR_AU;
//    rc =  GetBest(TEST_SET_ID_1,1, ordrMask,&pBestO );
//    EXPECT_EQ(rc,NO_ERR);
//    
//    EXPECT_EQ(buyOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
//    EXPECT_EQ(buyOrder.ordrQty,pBestO->orderF.ordrQty);
//    EXPECT_EQ(buyOrder.ordrNo,pBestO->orderF.ordrNo);
//    EXPECT_EQ(buyOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
//    EXPECT_EQ(buyOrder.ordrMask,pBestO->orderF.ordrMask);
//    
//    
//    sellOrder.ordrExePrc = 20;
//    sellOrder.ordrQty = 200;
//    sellOrder.prdctId = 1;
//    sellOrder.ordrNo = 2;
//    sellOrder.ordrEntTim = 2;
//    sellOrder.tranTime = sellOrder.ordrEntTim;
//    sellOrder.ordrMask |= ORDR_TRDRESTR_AU;
//    sellOrder.ordrMask |= ORDR_SIDE_SELL;
//    
//    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderSell);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    memcpy(&pOrderSell->orderF, &sellOrder, sizeof(OrderFT));
//    
//    rc = OrdrBkAddOrdr(TEST_SET_ID_1, &pOrderSell, &ordrRbInfo);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    ordrMask = 0;
//    ordrMask |= ORDR_SIDE_SELL;
//    ordrMask |= ORDR_TRDRESTR_AU;
//    rc =  GetBest(TEST_SET_ID_1,1, ordrMask,&pBestO );
//    EXPECT_EQ(rc,NO_ERR);
//    
//    EXPECT_EQ(sellOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
//    EXPECT_EQ(sellOrder.ordrQty,pBestO->orderF.ordrQty);
//    EXPECT_EQ(sellOrder.ordrNo,pBestO->orderF.ordrNo);
//    EXPECT_EQ(sellOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
//    EXPECT_EQ(sellOrder.ordrMask,pBestO->orderF.ordrMask);
}


//
//TEST_F(OrdrBkCommonTest, ModOrdr) {
//    ResCodeT rc = NO_ERR;
//    
//    pOrderT pOrderCreate;
//    pOrderT pOrderNew;
//    
//    OrderFT  oldOrder; 
//    OrderFT  newOrder; 
//    pOrderT pBestO;
//    int32  ordrMask  = 0;
//    memset(&oldOrder,0x00,sizeof(OrderFT));
//    memset(&newOrder,0x00,sizeof(OrderFT));
//    
//    oldOrder.ordrExePrc = 10;
//    oldOrder.ordrQty = 100;
//    oldOrder.prdctId = 2;
//    oldOrder.ordrNo = 3;
//    oldOrder.ordrEntTim = 1;
//    oldOrder.tranTime = oldOrder.ordrEntTim;
//    oldOrder.ordrMask |= ORDR_TRDRESTR_AU;
//    oldOrder.ordrMask |= ORDR_SIDE_BUY;
//    OrdrRbInfoT ordrRbInfo;
//    
//    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    memcpy(&pOrderCreate->orderF, &oldOrder, sizeof(OrderFT));
//    
//    rc = OrdrBkAddOrdr(TEST_SET_ID_1, &pOrderCreate, &ordrRbInfo);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    memcpy(&newOrder,&pOrderCreate->orderF, sizeof(OrderFT));
//    
//    // only qty change
//    //newOrder.ordrExePrc = 11;
//    newOrder.ordrQty = 111;
//    
//    rc = OrdrBkModOrdr (TEST_SET_ID_1, &pOrderCreate,&newOrder,&ordrRbInfo);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    
//    ordrMask |= ORDR_SIDE_BUY;
//    ordrMask |= ORDR_TRDRESTR_AU;
//    rc =  GetBest(TEST_SET_ID_1,2, ordrMask,&pBestO );
//    EXPECT_EQ(rc,NO_ERR);
//    
//    EXPECT_EQ(oldOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
//    EXPECT_EQ(newOrder.ordrQty,pBestO->orderF.ordrQty);
//    EXPECT_EQ(oldOrder.ordrNo,pBestO->orderF.ordrNo);
//    EXPECT_EQ(oldOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
//    EXPECT_EQ(oldOrder.ordrMask,pBestO->orderF.ordrMask);
//    
//    
//    // only qty  and price change
//    memset(&ordrRbInfo,0x00,sizeof(OrdrRbInfoT));
//    newOrder.ordrExePrc = 22;
//    newOrder.ordrQty = 222;
//    
//    rc = OrdrBkModOrdr (TEST_SET_ID_1, &pOrderCreate,&newOrder,&ordrRbInfo);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    
//    ordrMask |= ORDR_SIDE_BUY;
//    ordrMask |= ORDR_TRDRESTR_AU;
//    rc =  GetBest(TEST_SET_ID_1,2, ordrMask,&pBestO );
//    EXPECT_EQ(rc,NO_ERR);
//    
//    EXPECT_EQ(newOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
//    EXPECT_EQ(newOrder.ordrQty,pBestO->orderF.ordrQty);
//    EXPECT_EQ(oldOrder.ordrNo,pBestO->orderF.ordrNo);
//    EXPECT_EQ(oldOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
//    EXPECT_EQ(oldOrder.ordrMask,pBestO->orderF.ordrMask);
//    
//    // only qty  and price change
//    memset(&ordrRbInfo,0x00,sizeof(OrdrRbInfoT));
//    
//    newOrder.ordrExePrc = 33;
//    newOrder.ordrQty = 333;
//    newOrder.prdctId = 2;
//    newOrder.ordrNo = 333;
//    newOrder.ordrEntTim = 333; 
//    
//    rc = OrdrBkModOrdr (TEST_SET_ID_1, &pOrderCreate,&newOrder,&ordrRbInfo);
//    EXPECT_EQ(rc,NO_ERR);
//    
//    
//    ordrMask |= ORDR_SIDE_BUY;
//    ordrMask |= ORDR_TRDRESTR_AU;
//    rc =  GetBest(TEST_SET_ID_1,2, ordrMask,&pBestO );
//    EXPECT_EQ(rc,NO_ERR);
//    
//    EXPECT_EQ(newOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
//    EXPECT_EQ(newOrder.ordrQty,pBestO->orderF.ordrQty);
//    EXPECT_EQ(newOrder.ordrNo,pBestO->orderF.ordrNo);
//    EXPECT_EQ(newOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
//    EXPECT_EQ(newOrder.ordrMask,pBestO->orderF.ordrMask);
//
//}

int main(int argc, char **argv) {
    InitGoogleTest(&argc, argv);


    return RUN_ALL_TESTS();
}

