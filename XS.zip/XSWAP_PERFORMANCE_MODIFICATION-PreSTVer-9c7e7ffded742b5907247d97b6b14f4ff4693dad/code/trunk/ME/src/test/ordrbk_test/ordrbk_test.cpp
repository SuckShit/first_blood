﻿/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/

#include <limits.h>
#include "err_lib.h"    
#include "app_shl.h"            
#include "gtest/gtest.h"
#include "msg_cache.h"
#include "UTILITY/logfile.h"
#include "Utils.h"
#include "order_book.h"
#include "uti_tool.h"
#include "match_lib.h"
#include "nmbr_srvc.h"

#define TEST_SET_ID_1   1

using ::testing::InitGoogleTest; 


class OrdrBkCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {
        

       
    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char appName[] = "";
        PrcsInit(appName);
        
        ResCodeT rc = NO_ERR;
        
        OrdrBkCfgT  ordrBkCfg = {0};
        ordrBkCfg.nmbrOfOrdr = 10000;
        ordrBkCfg.nmbrOfPrdct = 1000;
        ordrBkCfg.setId = TEST_SET_ID_1;
        ordrBkCfg.nmbrOfEnty = 100;
        
        rc = OrdrBkShmCreate(&ordrBkCfg);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = OrdrBkShmAttach(TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
    }
    
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        rc = OrdrBkShmDetach(TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = OrdrBkShmDelete(TEST_SET_ID_1);
        ASSERT_EQ(rc, NO_ERR);
        
      
    }   
};
  


TEST_F(OrdrBkCommonTest, CreateOrdrAndFree) {
    
    EXPECT_EQ(sizeof(OrderFT),sizeof(OrderF4PrcLeadT));
    
    EXPECT_EQ(sizeof(OrderTT),sizeof(OrderT4PrcLeadT));
    
    ResCodeT rc = NO_ERR;
    
    pOrderT pOrderCreate[10001];
    
    OrderFT  order; 
    
    
    int32 i = 0;
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);

        
        EXPECT_NE((SlotT)-1,pOrderCreate[i]->orderT.slotNo);

    }
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[10000]);
    EXPECT_EQ(rc,ERR_OBK_SET_ODRBK_FULL);
    
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkFreeOrder(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);

    }
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[0]);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = OrdrBkFreeOrder(TEST_SET_ID_1, &pOrderCreate[0]);
    EXPECT_EQ(rc,NO_ERR);
    
    
    /* again insert */
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);

        
        EXPECT_NE((SlotT)-1,pOrderCreate[i]->orderT.slotNo);

    }
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[10000]);
    EXPECT_EQ(rc,ERR_OBK_SET_ODRBK_FULL);
    
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkFreeOrder(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);

    }
}

TEST_F(OrdrBkCommonTest, AddOrdrAndDelete) {
    
    EXPECT_EQ(sizeof(OrderFT),sizeof(OrderF4PrcLeadT));
    
    EXPECT_EQ(sizeof(OrderTT),sizeof(OrderT4PrcLeadT));
    
    ResCodeT rc = NO_ERR;
    
    pOrderT pOrderCreate[10001];
    
    OrderFT  order; 
    memset(&order, 0x00, sizeof(OrderFT));
    
    order.ordrExePrc = 10;
    order.ordrQty = 100;
    order.prdctId = 1000;
    
    order.ordrEntTim = 1;
    order.tranTime = order.ordrEntTim;
    order.ordrMask |= ORDR_TRDRESTR_AU;
    order.ordrMask |= ORDR_SIDE_BUY;
    MAddOrdrT addOrdrInfo;
    
    
    int32 i = 0;
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);
     
        
        EXPECT_NE((SlotT)-1,pOrderCreate[i]->orderT.slotNo);
        
        order.ordrNo = i+1;
        order.ordrExePrc = i+1;
        
        memcpy(&pOrderCreate[i]->orderF, &order, sizeof(OrderFT));
    
        rc = OrdrBkAddOrdr(FALSE, TEST_SET_ID_1, &pOrderCreate[i], &addOrdrInfo);
        EXPECT_EQ(rc,NO_ERR);
    }
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[10000]);
    EXPECT_EQ(rc,ERR_OBK_SET_ODRBK_FULL);
    

    
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkDeleteOrdr(TEST_SET_ID_1, &pOrderCreate[i], 0);
        EXPECT_EQ(rc,NO_ERR);
        
        rc = OrdrBkFreeOrder(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);

    }
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[0]);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = OrdrBkFreeOrder(TEST_SET_ID_1, &pOrderCreate[0]);
    EXPECT_EQ(rc,NO_ERR);
    
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);
     
        
        EXPECT_NE((SlotT)-1,pOrderCreate[i]->orderT.slotNo);
        
        order.ordrNo = i+1;
        order.ordrExePrc = i+1;
        
        memcpy(&pOrderCreate[i]->orderF, &order, sizeof(OrderFT));
    
        rc = OrdrBkAddOrdr(FALSE, TEST_SET_ID_1, &pOrderCreate[i], &addOrdrInfo);
        EXPECT_EQ(rc,NO_ERR);
    }
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate[10000]);
    EXPECT_EQ(rc,ERR_OBK_SET_ODRBK_FULL);
    
    
    for (i=0; i<10000; i++)
    {

        rc = OrdrBkDeleteOrdr(TEST_SET_ID_1, &pOrderCreate[i], 0);
        EXPECT_EQ(rc,NO_ERR);
        
        rc = OrdrBkFreeOrder(TEST_SET_ID_1, &pOrderCreate[i]);
        EXPECT_EQ(rc,NO_ERR);

    }
}



TEST_F(OrdrBkCommonTest, AddOrdr) {
    ResCodeT rc = NO_ERR;
    
    pOrderT pOrderCreate;
    pOrderT pOrderSell;
    
    OrderFT  buyOrder; 
    OrderFT  sellOrder; 
    pOrderT pBestO;
    int32  ordrMask  = 0;
    memset(&buyOrder,0x00,sizeof(OrderFT));
    memset(&sellOrder,0x00,sizeof(OrderFT));
    
    buyOrder.ordrExePrc = 10;
    buyOrder.ordrQty = 100;
    buyOrder.prdctId = 1;
    buyOrder.ordrNo = 1;
    buyOrder.ordrEntTim = 1;
    buyOrder.tranTime = buyOrder.ordrEntTim;
    buyOrder.ordrMask |= ORDR_TRDRESTR_AU;
    buyOrder.ordrMask |= ORDR_SIDE_BUY;
    MAddOrdrT addOrdrInfo;
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate);
    EXPECT_EQ(rc,NO_ERR);
    
    memcpy(&pOrderCreate->orderF, &buyOrder, sizeof(OrderFT));
    
    rc = OrdrBkAddOrdr(FALSE, TEST_SET_ID_1, &pOrderCreate, &addOrdrInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    ordrMask |= ORDR_SIDE_BUY;
    ordrMask |= ORDR_TRDRESTR_AU;
    rc =  GetBest(TEST_SET_ID_1,1, ordrMask,&pBestO );
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(buyOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
    EXPECT_EQ(buyOrder.ordrQty,pBestO->orderF.ordrQty);
    EXPECT_EQ(buyOrder.ordrNo,pBestO->orderF.ordrNo);
    EXPECT_EQ(buyOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
    EXPECT_EQ(buyOrder.ordrMask,pBestO->orderF.ordrMask);
    
    
    sellOrder.ordrExePrc = 20;
    sellOrder.ordrQty = 200;
    sellOrder.prdctId = 1;
    sellOrder.ordrNo = 2;
    sellOrder.ordrEntTim = 2;
    sellOrder.tranTime = sellOrder.ordrEntTim;
    sellOrder.ordrMask |= ORDR_TRDRESTR_AU;
    sellOrder.ordrMask |= ORDR_SIDE_SELL;
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderSell);
    EXPECT_EQ(rc,NO_ERR);
    
    memcpy(&pOrderSell->orderF, &sellOrder, sizeof(OrderFT));
    
    rc = OrdrBkAddOrdr(FALSE, TEST_SET_ID_1, &pOrderSell, &addOrdrInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    ordrMask = 0;
    ordrMask |= ORDR_SIDE_SELL;
    ordrMask |= ORDR_TRDRESTR_AU;
    rc =  GetBest(TEST_SET_ID_1,1, ordrMask,&pBestO );
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(sellOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
    EXPECT_EQ(sellOrder.ordrQty,pBestO->orderF.ordrQty);
    EXPECT_EQ(sellOrder.ordrNo,pBestO->orderF.ordrNo);
    EXPECT_EQ(sellOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
    EXPECT_EQ(sellOrder.ordrMask,pBestO->orderF.ordrMask);
}



TEST_F(OrdrBkCommonTest, ModOrdr) {
    ResCodeT rc = NO_ERR;
    
    pOrderT pOrderCreate;
    pOrderT pOrderNew;
    
    OrderFT  oldOrder; 
    OrderFT  newOrder; 
    pOrderT pBestO;
    int32  ordrMask  = 0;
    memset(&oldOrder,0x00,sizeof(OrderFT));
    memset(&newOrder,0x00,sizeof(OrderFT));
    
    oldOrder.ordrExePrc = 10;
    oldOrder.ordrQty = 100;
    oldOrder.prdctId = 2;
    oldOrder.ordrNo = 3;
    oldOrder.ordrEntTim = 1;
    oldOrder.tranTime = oldOrder.ordrEntTim;
    oldOrder.ordrMask |= ORDR_TRDRESTR_AU;
    oldOrder.ordrMask |= ORDR_SIDE_BUY;
    MAddOrdrT addOrdrInfo;
    MModOrdrT modOrdrInfo;
    
    rc = OrdrBkCreateOrdr(TEST_SET_ID_1, &pOrderCreate);
    EXPECT_EQ(rc,NO_ERR);
    
    memcpy(&pOrderCreate->orderF, &oldOrder, sizeof(OrderFT));
    
    rc = OrdrBkAddOrdr(FALSE, TEST_SET_ID_1, &pOrderCreate, &addOrdrInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    memcpy(&newOrder,&pOrderCreate->orderF, sizeof(OrderFT));
    
    // only qty change
    //newOrder.ordrExePrc = 11;
    newOrder.ordrQty = 111;
    
    rc = OrdrBkModOrdr (FALSE,TEST_SET_ID_1, &pOrderCreate,&newOrder,&modOrdrInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    
    ordrMask |= ORDR_SIDE_BUY;
    ordrMask |= ORDR_TRDRESTR_AU;
    rc =  GetBest(TEST_SET_ID_1,2, ordrMask,&pBestO );
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(oldOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
    EXPECT_EQ(newOrder.ordrQty,pBestO->orderF.ordrQty);
    EXPECT_EQ(oldOrder.ordrNo,pBestO->orderF.ordrNo);
    EXPECT_EQ(oldOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
    EXPECT_EQ(oldOrder.ordrMask,pBestO->orderF.ordrMask);
    
    
    // only qty  and price change
    memset(&modOrdrInfo,0x00,sizeof(MModOrdrT));
    newOrder.ordrExePrc = 22;
    newOrder.ordrQty = 222;
    
    rc = OrdrBkModOrdr (FALSE,TEST_SET_ID_1, &pOrderCreate,&newOrder,&modOrdrInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    
    ordrMask |= ORDR_SIDE_BUY;
    ordrMask |= ORDR_TRDRESTR_AU;
    rc =  GetBest(TEST_SET_ID_1,2, ordrMask,&pBestO );
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(newOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
    EXPECT_EQ(newOrder.ordrQty,pBestO->orderF.ordrQty);
    EXPECT_EQ(oldOrder.ordrNo,pBestO->orderF.ordrNo);
    EXPECT_EQ(oldOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
    EXPECT_EQ(oldOrder.ordrMask,pBestO->orderF.ordrMask);
    
    // only qty  and price change
    memset(&modOrdrInfo,0x00,sizeof(MModOrdrT));
    
    newOrder.ordrExePrc = 33;
    newOrder.ordrQty = 333;
    newOrder.prdctId = 2;
    newOrder.ordrNo = 333;
    newOrder.ordrEntTim = 333; 
    
    rc = OrdrBkModOrdr (FALSE, TEST_SET_ID_1, &pOrderCreate,&newOrder,&modOrdrInfo);
    EXPECT_EQ(rc,NO_ERR);
    
    
    ordrMask |= ORDR_SIDE_BUY;
    ordrMask |= ORDR_TRDRESTR_AU;
    rc =  GetBest(TEST_SET_ID_1,2, ordrMask,&pBestO );
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(newOrder.ordrExePrc,pBestO->orderF.ordrExePrc);
    EXPECT_EQ(newOrder.ordrQty,pBestO->orderF.ordrQty);
    EXPECT_EQ(newOrder.ordrNo,pBestO->orderF.ordrNo);
    EXPECT_EQ(newOrder.ordrEntTim,pBestO->orderF.ordrEntTim);
    EXPECT_EQ(newOrder.ordrMask,pBestO->orderF.ordrMask);

}


class NmbrSrvcCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {

    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char prcsName[] = "";
        PrcsInit(prcsName);
        ResCodeT rc = NO_ERR;
            
            
        rc = NmbrSrvcShmCreate(1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = NmbrSrvcInit(1);
        ASSERT_EQ(rc, NO_ERR);
    }
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        
        rc =  NmbrSrvcShmDetach(1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc =  NmbrSrvcShmDelete(1);
        ASSERT_EQ(rc, NO_ERR);
    
    }   
};

TEST_F(NmbrSrvcCommonTest, NmbrSrvcCommon) {

    int          rc = NO_ERR;
    int64        frstOrdNmbr = 0, scndOrdNmbr = 0;
    int64        frstTrdNmbr = 0, scndTrdNmbr = 0;
    int64        tmpOrdNmbr = 0, tmpTrdNmbr = 0;
    
    rc = NmbrSrvcGenNo(1, (NmbrTypeT)10, &frstOrdNmbr);
    EXPECT_EQ(ERR_NMBR_SRVC_INVLD_TYPE, rc);
    
    rc = NmbrSrvcGetNo(1,(NmbrTypeT)10, &frstOrdNmbr);
    EXPECT_EQ(ERR_NMBR_SRVC_INVLD_TYPE, rc);
    
    rc = NmbrSrvcSetNo(1,(NmbrTypeT)10, frstOrdNmbr);
    EXPECT_EQ(ERR_NMBR_SRVC_INVLD_TYPE, rc);
    
    
    rc = NmbrSrvcGenNo(1,NMBR_TYPE_ORD, &frstOrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = NmbrSrvcGenNo(1,NMBR_TYPE_ORD, &scndOrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    EXPECT_EQ(frstOrdNmbr+1, scndOrdNmbr);
    
    
    rc = NmbrSrvcGenNo(1,NMBR_TYPE_TRD, &frstTrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = NmbrSrvcGenNo(1,NMBR_TYPE_TRD, &scndTrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    EXPECT_EQ(frstTrdNmbr+1, scndTrdNmbr);
    
    rc  = NmbrSrvcGetNo(1,NMBR_TYPE_ORD, &tmpOrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    EXPECT_EQ(tmpOrdNmbr, scndOrdNmbr);
    
    rc  = NmbrSrvcGetNo(1,NMBR_TYPE_TRD, &tmpTrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    EXPECT_EQ(tmpTrdNmbr, scndTrdNmbr);
    
    
    rc  = NmbrSrvcSetNo(1,NMBR_TYPE_ORD, scndOrdNmbr + 2);
    EXPECT_EQ(NO_ERR, rc);
    
    rc  = NmbrSrvcGetNo(1,NMBR_TYPE_ORD, &tmpOrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    EXPECT_EQ(tmpOrdNmbr, scndOrdNmbr+2);
    
    
    rc  = NmbrSrvcSetNo(1,NMBR_TYPE_TRD, scndTrdNmbr + 2);
    EXPECT_EQ(NO_ERR, rc);
    
    rc  = NmbrSrvcGetNo(1,NMBR_TYPE_TRD, &tmpTrdNmbr);
    EXPECT_EQ(NO_ERR, rc);
    
    EXPECT_EQ(tmpTrdNmbr, scndTrdNmbr+2);

	
}



int main(int argc, char **argv) {
    InitGoogleTest(&argc, argv);


    return RUN_ALL_TESTS();
}

