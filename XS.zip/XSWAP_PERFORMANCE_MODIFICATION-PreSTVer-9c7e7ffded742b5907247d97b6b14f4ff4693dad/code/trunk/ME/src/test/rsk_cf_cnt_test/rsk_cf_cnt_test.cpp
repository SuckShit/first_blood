/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "../../common/ref_data/include/usr.h"
#include "rsk_cf_cnt.h"
#include "shm.h"
#include "gtest/gtest.h"

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/


/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char dbAddress[] = "200.31.155.145:1521/xswapdb";
static char username[] = "xswap";
static char password[] = "xswap";
static char dbAddress1[] = "200.31.157.151:1521/xswapdb";
static char username1[] = "xswap2";
static char password1[] = "xswap2";

int32 connId = 0;


/***********************************************************************************************
**
**   Functiona Declaration                                                                           
**
************************************************************************************************/


/***********************************************************************************************
**
**   Functiona Implementation                                                                           
**
************************************************************************************************/
using ::testing::InitGoogleTest; 


class RskCfCntTest : public testing::Test {
//protected:
    // You should make the members protected s.t. they can be
    // accessed from sub-classes.

    // virtual void SetUp() will be called before each test is run.  You
    // should define it if you need to initialize the varaibles.
    // Otherwise, this can be skipped.
    virtual void SetUp() {}

    // virtual void TearDown() will be called after each test is run.
    // You should define it if there is cleanup work to do.  Otherwise,
    // you don't have to provide it.
    //
    virtual void TearDown() {}
};


TEST(RskCfCntTest, RskCfCntLoad)
{
    ResCodeT rc = 0;
    int32 temp = 0;
    

    DbCmmnInit();
    
    rc = DbCmmnConnect(dbAddress, username, password, &connId);
    EXPECT_EQ(rc,NO_ERR);

    rc = IrsRskCfCntLoadFromDb(connId);
    EXPECT_EQ(rc,NO_ERR);
}

TEST(RskCfCntTest, RskCfCntDelete)
{
    UsrKey DeleteSrno;
    ResCodeT rc = 0;

    rc = IrsRskCfCntDetachFromShm();
    EXPECT_EQ(rc, NO_ERR);

    ShmDelete((char*)SHM_IRS_RISK_CF_CNT_NAME);
}


TEST(RskCfCntTest, getByKey)
{
    RskCfCntInfoT FetchData;
    char cntrctNm[50];
    int32 orgId;
    ResCodeT rc = 0;

    memset(cntrctNm, 0, 50);
    strcpy(cntrctNm, "FR007_6M");
    orgId = 102316;
    memset(&FetchData, 0, sizeof(RskCfCntInfoT));

    rc = IrsRskCfCntGetByTwoKey(cntrctNm, orgId, &FetchData);
    EXPECT_EQ(rc,NO_ERR);

}


int main(int argc, char **argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
