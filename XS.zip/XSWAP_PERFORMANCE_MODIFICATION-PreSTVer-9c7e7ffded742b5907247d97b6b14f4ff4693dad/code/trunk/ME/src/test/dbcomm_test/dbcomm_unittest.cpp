/***
Created on June 28, 2017
@author: No One
@version $Id
***/

// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)
    

// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include <limits.h>
#include <pthread.h>          
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include "gtest/gtest.h"

#include "err_lib.h"
#include "err_cod.h"
#include "data_type.h"
#include "common_macro.h"
#include "shm.h"

#include "db_comm.h"


// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.
using ::testing::InitGoogleTest; 

static char dbAddress[] = "200.31.155.145:1521/xswapdb";
static char username[] = "xswap";
static char password[] = "xswap";

int32 connId;

class dbcommTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // printf("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // printf("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
//        ResCodeT rc = NO_ERR;
//        rc = DbCmmnInit();
//        if (rc != NO_ERR){
//            EXPECT_EQ(rc, NO_ERR);
//            return ;
//        }
//        rc = DbCmmnConnect((char*)dbAddress, (char*)username, (char*)password, &connId);
//        if (rc != NO_ERR){
//            EXPECT_EQ(rc, NO_ERR);
//            return ;
//        }        
    }
        
    static void TearDownTestCase() {
//        ResCodeT rc = NO_ERR;
//        rc = DbCmmnDisConnect(connId);
//        if (rc != NO_ERR){
//            EXPECT_EQ(rc, NO_ERR);
//            return ;
//        }
//        rc = DbCmmnCleanup();
//        if (rc != NO_ERR){
//            EXPECT_EQ(rc, NO_ERR);
//            return ;
//        }
    }
};

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////Function Test Starting//////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

TEST_F(dbcommTest, SelectTest) {
    ResCodeT rc = NO_ERR;

//    char sql[1000] = "SELECT ORG_ID, ORG_CD, ORG_NM_CN FROM ORG_INFO WHERE ORG_IRS_ST = \'1\' ORDER BY ORG_ID ";
//	char sqlSub[1000] = "SELECT ORG_ID, ORG_MKT_PRVLG_SRNO FROM ORG_MKT_PRVLG WHERE ST = \'0\' AND MKT_TP = \'1\' ORDER BY ORG_MKT_PRVLG_SRNO ";
//    int32 selId = 0;
//	int32 count = 0;
//	RsltCol col[3];
//	int32 colNum = 3;
//
//	int32 orgId = 0;
//	char orgCd[50];
//	char orgNm[300];
//
//    int32 subselId = 0;
//    int32 subcount = 0;
//	RsltCol colSub[2];
//	int32 colSubNum = 2;
//	int32 suborgId = 0;
//	int32 mkt_srno = 0;
//
//	// col
//	memset(col,   0x00, sizeof(RsltCol)*colNum);
//	memset(colSub, 0x00, sizeof(RsltCol)*colSubNum);
//	memset(orgCd, 0x00, sizeof(orgCd));
//	memset(orgNm, 0x00, sizeof(orgNm));
//
//	//subcol[0]
//    colSub[0].colId = 1;
//    strcpy(colSub[0].colName, "ORG_ID");
//    strcpy(colSub[0].bndName, ":org_id");
//    colSub[0].colType = eINTEGER;
//    colSub[0].maxSize = sizeof(int32); 
//    colSub[0].dataRow = 1;
//    colSub[0].pDataValue = &suborgId;
//
//	//subcol[1]
//    colSub[1].colId = 2;
//    strcpy(colSub[1].colName, "ORG_MKT_PRVLG_SRNO");
//    strcpy(colSub[1].bndName, ":org_mkt_prvlg_srno");
//    colSub[1].colType = eINTEGER;
//    colSub[1].maxSize = sizeof(int32); 
//    colSub[1].dataRow = 1;
//    colSub[1].pDataValue = &mkt_srno;
//
//	//col[0]
//    col[0].colId = 1;
//    strcpy(col[0].colName, "ORG_ID");
//    strcpy(col[0].bndName, ":org_id");
//    col[0].colType = eINTEGER;
//    col[0].maxSize = sizeof(int32); 
//    col[0].dataRow = 1;
//    col[0].pDataValue = &orgId;
//
//	//col[1]
//    col[1].colId = 2;
//    strcpy(col[1].colName, "ORG_CD");
//    strcpy(col[1].bndName, ":org_cd");
//    col[1].colType = eVARCHAR2;
//    col[1].maxSize = 50; 
//    col[1].dataRow = 1;
//    col[1].pDataValue = orgCd;
//
//	//col[2]
//    col[2].colId = 3;
//    strcpy(col[2].colName, "ORG_NM_CN");
//    strcpy(col[2].bndName, ":org_nm_cn");
//    col[2].colType = eVARCHAR2;
//    col[2].maxSize = 300; 
//    col[2].dataRow = 1;
//    col[2].pDataValue = orgNm;
//
//    rc = DbCmmnSqlSelect(connId, sqlSub, &subselId);
//    if (rc != NO_ERR) {
//        EXPECT_EQ(rc, NO_ERR);
//        return ;
//    }
//    EXPECT_EQ(rc, NO_ERR);
//
//	printf("SubSelectId = %d.\n", subselId);
//	while (OK(DbCmmnSqlFetchNext(connId, subselId, colSub, &colSubNum))) {
//		printf("SubOrgId[%d]=%d.\n", subcount, suborgId);
//		printf("mkt_srno[%d]=%d.\n", subcount, mkt_srno);
//
//		printf("*******************NEXT(%d)*******************\n", subcount+1);
//		rc = DbCmmnSqlSelect(connId, sql, &selId);
//		if (rc != NO_ERR) {
//			EXPECT_EQ(rc, NO_ERR);
//			return ;
//		}
//		EXPECT_EQ(rc, NO_ERR);
//
//		printf("SelectId = %d.\n", selId);
//		count = 0; 
//		while (OK(DbCmmnSqlFetchNext(connId, selId, col, &colNum))) {
//			printf("orgId[%d]=%d.\n", count, orgId);
//			printf("orgCd[%d]=%s.\n", count, orgCd);
//			printf("orgNm[%d]=%s.\n", count, orgNm);
//			count++;
//		}
//		subcount++;
//	}
//
//	printf("count=%d.\n", count);
//	printf("subcount=%d.\n", subcount);

}

#if 0
TEST_F(dbcommTest, InsertTest) {
//    ResCodeT rc = NO_ERR;
//    char sql[1000] = "INSERT INTO MEM_TXN_DAT_1_TBL (TXN_DAT_SQNO, TXN_ELEM_SIZE, TXN_ELEM_CNT, PRE_DAT_SQNO, NXT_DAT_SQNO, TXN_ELEM_DAT) "
//                    "VALUES (:txn_dat_sqno, :txn_elem_size, :txn_elem_cnt, :pre_dat_sqno, :nxt_dat_sqno, :txn_elem_dat) ";
//    RsltCol col[6];
//    int32 colNum = 6;
//    int32 srno = 2;
//    char elem_dat[1000];
//    int64 data[5] = {
//        2222222222,
//        3333333333,
//        4444444444,
//        5555555555,
//        6666666666
//    };
//
//    // memset
//    memset(col, 0x00, sizeof(RsltCol)*6);
//    memset(elem_dat, 0x00, sizeof(elem_dat));
//
//    // memcpy
//    memcpy(elem_dat, data, sizeof(int64)*5);
//    
//    // col[0]:TXN_DAT_SQNO
//    col[0].colId = 1;
//    strcpy(col[0].colName, "TXN_DAT_SQNO");
//    strcpy(col[0].bndName, ":txn_dat_sqno");
//    col[0].colType = eINTEGER;
//    col[0].maxSize = sizeof(int32); 
//    col[0].dataRow = 1;
//    col[0].pDataValue = &srno;
//    // col[1]:TXN_ELEM_SIZE
//    col[1].colId = 2;
//    strcpy(col[1].colName, "TXN_ELEM_SIZE");
//    strcpy(col[1].bndName, ":txn_elem_size");
//    col[1].colType = eINTEGER;
//    col[1].maxSize = sizeof(int32); 
//    col[1].dataRow = 1;
//    col[1].pDataValue = &srno;
//    // col[2]:TXN_ELEM_CNT
//    col[2].colId = 3;
//    strcpy(col[2].colName, "TXN_ELEM_CNT");
//    strcpy(col[2].bndName, ":txn_elem_cnt");
//    col[2].colType = eINTEGER;
//    col[2].maxSize = sizeof(int32); 
//    col[2].dataRow = 1;
//    col[2].pDataValue = &srno;
//    // col[3]:PRE_DAT_SQNO
//    col[3].colId = 4;
//    strcpy(col[3].colName, "PRE_DAT_SQNO");
//    strcpy(col[3].bndName, ":pre_dat_sqno");
//    col[3].colType = eINTEGER;
//    col[3].maxSize = sizeof(int32); 
//    col[3].dataRow = 1;
//    col[3].pDataValue = &srno;
//    // col[4]:NXT_DAT_SQNO
//    col[4].colId = 5;
//    strcpy(col[4].colName, "NXT_DAT_SQNO");
//    strcpy(col[4].bndName, ":nxt_dat_sqno");
//    col[4].colType = eINTEGER;
//    col[4].maxSize = sizeof(int32); 
//    col[4].dataRow = 1;
//    col[4].pDataValue = &srno;
//    // col[5]:TXN_ELEM_DAT
//    col[5].colId = 6;
//    strcpy(col[5].colName, "TXN_ELEM_DAT");
//    strcpy(col[5].bndName, ":txn_elem_dat");
//    col[5].colType = eBLOB;
//    col[5].maxSize = sizeof(int64)*5; 
//    col[5].dataRow = 1;
//    col[5].pDataValue = elem_dat;
//
//    rc = DbCmmnSqlSingleExecute(connId, sql, col, &colNum);
//    if (rc != NO_ERR) {
//        EXPECT_EQ(rc, NO_ERR);
//        return ;
//    }
//    EXPECT_EQ(rc, NO_ERR);
//
//    rc = DbCmmnCommit(connId);
//    EXPECT_EQ(rc, NO_ERR);
}
#endif

#if 0
TEST_F(dbcommTest, SelectTest) {
    ResCodeT rc = NO_ERR;
//    char sql[1000] = "SELECT TXN_DAT_SQNO, TXN_ELEM_SIZE, TXN_ELEM_CNT, PRE_DAT_SQNO, NXT_DAT_SQNO, TXN_ELEM_DAT FROM MEM_TXN_DAT_1_TBL ";
//    int32 selId = 0;
//    RsltCol col[6];
//    int32 colNum = 6;
//
//    int32 ret[5];
//    char buff[1000];
//
//    int64 outdata = 0;
//    int64 cpdata = 2222222222;
//
//    memset(col, 0x00, sizeof(RsltCol)*6);
//    memset(buff, 0x00, sizeof(buff));
//
//    col[0].colId = 1;
//    col[0].colType = eINTEGER;
//    col[0].pDataValue = &ret[0];
//
//    col[1].colId = 2;
//    col[1].colType = eINTEGER;
//    col[1].pDataValue = &ret[1];
//
//    col[2].colId = 3;
//    col[2].colType = eINTEGER;
//    col[2].pDataValue = &ret[2];
//
//    col[3].colId = 4;
//    col[3].colType = eINTEGER;
//    col[3].pDataValue = &ret[3];
//
//    col[4].colId = 5;
//    col[4].colType = eINTEGER;
//    col[4].pDataValue = &ret[4];
//
//    col[5].colId = 6;
//    col[5].colType = eBLOB;
//    col[5].pDataValue = buff;
//
////ResCodeT DbCmmnSqlSelect(int32 connId, char* sql, int32* pSelectId);
//    rc = DbCmmnSqlSelect(connId, sql, &selId);
//    if (rc != NO_ERR) {
//        EXPECT_EQ(rc, NO_ERR);
//        return ;
//    }
//    EXPECT_EQ(rc, NO_ERR);
//
////ResCodeT DbCmmnSqlFetchNext(int32 connId, int32 selectId, RsltCol* pInCol, int32* pInColNum);
//    rc = DbCmmnSqlFetchNext(connId, selId, col, &colNum);
//    if (rc != NO_ERR) {
//        EXPECT_EQ(rc, NO_ERR);
//        return ;
//    }
//    EXPECT_EQ(rc, NO_ERR);
//
//    memcpy(&outdata, buff, sizeof(int64));
//
//    EXPECT_EQ(ret[0], 1);
//    EXPECT_EQ(ret[1], 1);
//    EXPECT_EQ(ret[2], 1);
//    EXPECT_EQ(ret[3], 1);
//    EXPECT_EQ(ret[4], 1);
//    EXPECT_EQ(outdata, cpdata);

}
#endif

#if 0 // Function OCI test is passed.
TEST(dbcommTest, DbOciInsertTest) {
    // Result Definition:
//    char funcName[] = "DbOciInsertTest";
//    ResCodeT bRet;
//    int32 errCd;
//    int32 cnnId;
//    int32 stmtId;
//    char sql[100];
//    char colName[20];
//
//    int32 id = 50;
//    char pLastName[10+1] = "zhang1";
//    char pFirstName[5+1] = "yi";
//    char pAddress[10+1] = "address50";
//    double codeLine = 26.01;
//    float coverage = 0.01;
//    int32 seqno = 50;
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//    // Initialize.
//    bRet = NO_ERR;
//    errCd = 0;
//    cnnId = 0;
//    bRet = DbOciInitialize(&errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//    bRet = DbOciCreate(dbAddress, username, password, &cnnId, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//    stmtId = 0;
//    memset(sql, 0, sizeof(sql));
//    strcpy(sql, "insert into test_oci ");
//    strcat(sql, "(ID, CODELINE, COVERAGE, SEQNO, LASTNAME) ");
//    strcat(sql, "values ");
//    strcat(sql, "(:id, :codeline, :coverage, :seqno, :lastname) ");
//    TRACE("sql: %s.\n", sql);
//
//    bRet = DbOciExePrepare(cnnId, &stmtId, sql, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//    memset(colName, 0, sizeof(colName));
//    strcpy(colName, ":id");
//    bRet = DbOciBindInt(cnnId, stmtId, colName, &id, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//    memset(colName, 0, sizeof(colName));
//    strcpy(colName, ":codeline");
//    bRet = DbOciBindDouble(cnnId, stmtId, colName, &codeLine, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//    memset(colName, 0, sizeof(colName));
//    strcpy(colName, ":coverage");
//    bRet = DbOciBindFloat(cnnId, stmtId, colName, &coverage, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//    memset(colName, 0, sizeof(colName));
//    strcpy(colName, ":seqno");
//    bRet = DbOciBindInt(cnnId, stmtId, colName, &seqno, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//    memset(colName, 0, sizeof(colName));
//    strcpy(colName, ":lastname");
//    bRet = DbOciBindString(cnnId, stmtId, colName, pLastName, &errCd);
//    if (bRet!=NO_ERR){
//        return;
//    }
//
//
//
//    bRet = DbOciExecutCmdNoRst(cnnId, stmtId, &errCd);
//    EXPECT_EQ(0, errCd);
//    EXPECT_EQ(NO_ERR, bRet);
//
//    bRet = DbOciCommit(cnnId, &errCd);
//    EXPECT_EQ(0, errCd);
//    EXPECT_EQ(NO_ERR, bRet);
//
//    // Result Compare.
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);


}
#endif // Function OCI test is passed.

//
//#if 0 // Function Common test is passed.
//TEST(dbCommTest, DbCmmnInit) {
//    // Result Definition:
//    char funcName[] = "DbCmmnInit";
//    ResCodeT rslt;
//
////[NORMAL]Start:TestCase01
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    rslt = DbCmmnInit();
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
////[NORMAL]End:TestCase01
//
////[ERROR]Start:TestCase02
//    TRACE("[ERROR](%s)Start:TestCase02.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    rslt = DbCmmnInit();
//    EXPECT_EQ(ERR_DB_OCI_INITIATED, rslt);
//    TRACE("[ERROR](%s)End:TestCase02.\n", funcName);
////[ERROR]End:TestCase02
//
//    rslt = DbCmmnCleanup();
//
//}
//#endif // Function OCI test is passed.
//
//#if 0
//TEST(dbCommTest, DbCmmnCleanup) {
//    // Result Definition:
//    char funcName[] = "DbCmmnCleanup";
//    ResCodeT rslt;
//
////[NORMAL]Start:TestCase01
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    rslt = DbCmmnInit();
//    if (rslt != NO_ERR){
//        TRACE("[NORMAL](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
////[NORMAL]End:TestCase01
//
//
////[NORMAL]Start:TestCase02
//    TRACE("[NORMAL](%s)Start:TestCase02.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[NORMAL](%s)End:TestCase02.\n", funcName);
////[NORMAL]End:TestCase02
//
//}
//#endif // Function OCI test is passed.
//
//#if 0
//TEST(dbCommTest, DbCmmnConnect) {
//    // Result Definition:
//    char funcName[] = "DbCmmnConnect";
//    ResCodeT rslt;
//    int32 connId;
//    char pwsd[20];
//    char* pData = "aaaaa";
//
//    // db init.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[NORMAL](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//
////[NORMAL]Start:TestCase01
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
////[NORMAL]End:TestCase01
//
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
////[ERROR]Start:TestCase02
//    TRACE("[ERROR](%s)Start:TestCase02.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    EXPECT_EQ(ERR_DB_OCI_NOT_INIT, rslt);
//    TRACE("[ERROR](%s)End:TestCase02.\n", funcName);
////[ERROR]End:TestCase02
//
////[ERROR]Start:TestCase03
//    TRACE("[ERROR](%s)Start:TestCase03.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(NULL, username, password, &connId);
//    EXPECT_EQ(ERR_INVLD_POINTER, rslt);
//    TRACE("[ERROR](%s)End:TestCase03.\n", funcName);
////[ERROR]End:TestCase03
//
////[ERROR]Start:TestCase04
//    TRACE("[ERROR](%s)Start:TestCase04.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, NULL, password, &connId);
//    EXPECT_EQ(ERR_INVLD_POINTER, rslt);
//    TRACE("[ERROR](%s)End:TestCase04.\n", funcName);
////[ERROR]End:TestCase04
//
////[ERROR]Start:TestCase05
//    TRACE("[ERROR](%s)Start:TestCase05.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, NULL, &connId);
//    EXPECT_EQ(ERR_INVLD_POINTER, rslt);
//    TRACE("[ERROR](%s)End:TestCase05.\n", funcName);
////[ERROR]End:TestCase05
//
////[ERROR]Start:TestCase06
//    TRACE("[ERROR](%s)Start:TestCase06.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, NULL);
//    EXPECT_EQ(ERR_INVLD_POINTER, rslt);
//    TRACE("[ERROR](%s)End:TestCase06.\n", funcName);
////[ERROR]End:TestCase06
//
////[ERROR]Start:TestCase07
//    TRACE("[ERROR](%s)Start:TestCase07.\n", funcName);
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[NORMAL](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//    memset(pwsd, 0, sizeof(pwsd));
//    strcpy(pwsd,pData);
//    
//    rslt = DbCmmnConnect(dbAddress, username, pwsd, &connId);
//    EXPECT_EQ(ERR_DB_OCI_CONN_ERR, rslt);
//
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[ERROR](%s)End:TestCase07.\n", funcName);
////[ERROR]End:TestCase07
//
//}
//#endif // Function OCI test is passed.
//
//#if 0
//TEST(dbCommTest, DbCmmnDisConnect){
//    // Result Definition:
//    char funcName[] = "DbCmmnDisConnect";
//    ResCodeT rslt;
//    int32 connId;
//
//    // db init.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[NORMAL](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//
////[NORMAL]Start:TestCase01
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
////[NORMAL]End:TestCase01
//
////[ERROR]Start:TestCase02
//    TRACE("[ERROR](%s)Start:TestCase02.\n", funcName);
//    // Initialize.
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    TRACE("[ERROR](%s)End:TestCase02.\n", funcName);
////[ERROR]End:TestCase02
//
//
//}
//#endif // Function Common test is passed.
//
//#if 0 // Function Sample Test is passed.
//TEST(dbCommTest, DbCmmnSqlSingleExecute){
//    // Result Definition:
//    char funcName[] = "DbCmmnSqlSingleExecute";
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol[7];
//    int32 iValue;
//    double dValue;
//    float fValue;
//
//    // db environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
////[NORMAL]Start:TestCase01
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//    // insert table.
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 7;
//
//    strcpy(sql, "insert into test_oci ");
//    strcat(sql, "(ID, CODELINE, COVERAGE, SEQNO, LASTNAME, FIRSTNAME, ADDRESS) ");
//    strcat(sql, "values ");
//    strcat(sql, "(:id, :codeline, :coverage, :seqno, :lastname, :firstname, :address) ");
//
//    iValue = 22;
//    dValue = 23.4;
//    fValue = 0.34;
//    // No1 Column
//    resCol[0].colId = 1;
//    strcpy(resCol[0].bndName, ":id");
//    resCol[0].colType = eINTEGER;
//    resCol[0].maxSize = 0;
//    resCol[0].dataRow = 1;
//    memcpy(resCol[0].dataBuf[0], &iValue, sizeof(iValue));
//
//    // No5 Column
//    resCol[1].colId = 2;
//    strcpy(resCol[1].bndName, ":codeline");
//    resCol[1].colType = eDOUBLE;
//    resCol[1].maxSize = 0;
//    resCol[1].dataRow = 1;
//    memcpy(resCol[1].dataBuf[0], &dValue, sizeof(dValue));
//
//    // No6 Column
//    resCol[2].colId = 3;
//    strcpy(resCol[2].bndName, ":coverage");
//    resCol[2].colType = eFLOAT;
//    resCol[2].maxSize = 0;
//    resCol[2].dataRow = 1;
//    memcpy(resCol[2].dataBuf[0], &fValue, sizeof(fValue));
//
//
//    // No6 Column
//    resCol[3].colId = 4;
//    strcpy(resCol[3].bndName, ":seqno");
//    resCol[3].colType = eINTEGER;
//    resCol[3].maxSize = 0;
//    resCol[3].dataRow = 1;
//    memcpy(resCol[3].dataBuf[0], &iValue, sizeof(iValue));
//
//
//    // No2 Column
//    resCol[4].colId = 5;
//    strcpy(resCol[4].bndName, ":lastname");
//    resCol[4].colType = eVARCHAR2;
//    resCol[4].maxSize = 0;
//    resCol[4].dataRow = 1;
//    strcpy(resCol[4].dataBuf[0], "fang");
//
//    // No3 Column
//    resCol[5].colId = 6;
//    strcpy(resCol[5].bndName, ":firstname");
//    resCol[5].colType = eVARCHAR2;
//    resCol[5].maxSize = 0;
//    resCol[5].dataRow = 1;
//    strcpy(resCol[5].dataBuf[0], "shuo");
//
//    // No4 Column
//    resCol[6].colId = 7;
//    strcpy(resCol[6].bndName, ":address");
//    resCol[6].colType = eVARCHAR2;
//    resCol[6].maxSize = 0;
//    resCol[6].dataRow = 1;
//    strcpy(resCol[6].dataBuf[0], "address22");
//
//    rslt = DbCmmnSqlSingleExecute(connId, sql, resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
////[NORMAL]End:TestCase01
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//}
//#endif // Function OCI test is passed.
//
//
//// TestSample Start. 
//// Insert single data to database.
//#if 0
//TEST(dbCommTest, DbCmmnSqlSingleExecute){
//    char funcName[] = "DbCmmnSqlSingleExecute";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol[7];
//    int32 iValue;
//    double dValue;
//    float fValue;
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 7;
//
//    strcpy(sql, "insert into test_oci ");
//    strcat(sql, "(ID, CODELINE, COVERAGE, SEQNO, LASTNAME, FIRSTNAME, ADDRESS) ");
//    strcat(sql, "values ");
//    strcat(sql, "(:id, :codeline, :coverage, :seqno, :lastname, :firstname, :address) ");
//
//    iValue = 30;
//    dValue = 23.42;
//    fValue = 1.34;
//
//    // No1 Column
//    resCol[0].colId = 1;
//    strcpy(resCol[0].bndName, ":id");
//    resCol[0].colType = eINTEGER;
//    resCol[0].maxSize = 0;
//    resCol[0].dataRow = 1;
//    memcpy(resCol[0].dataBuf[0], &iValue, sizeof(iValue));
//
//    // No5 Column
//    resCol[1].colId = 2;
//    strcpy(resCol[1].bndName, ":codeline");
//    resCol[1].colType = eDOUBLE;
//    resCol[1].maxSize = 0;
//    resCol[1].dataRow = 1;
//    memcpy(resCol[1].dataBuf[0], &dValue, sizeof(dValue));
//
//    // No6 Column
//    resCol[2].colId = 3;
//    strcpy(resCol[2].bndName, ":coverage");
//    resCol[2].colType = eFLOAT;
//    resCol[2].maxSize = 0;
//    resCol[2].dataRow = 1;
//    memcpy(resCol[2].dataBuf[0], &fValue, sizeof(fValue));
//
//    // No7 Column
//    resCol[3].colId = 4;
//    strcpy(resCol[3].bndName, ":seqno");
//    resCol[3].colType = eINTEGER;
//    resCol[3].maxSize = 0;
//    resCol[3].dataRow = 1;
//    memcpy(resCol[3].dataBuf[0], &iValue, sizeof(iValue));
//
//    // No2 Column
//    resCol[4].colId = 5;
//    strcpy(resCol[4].bndName, ":lastname");
//    resCol[4].colType = eVARCHAR2;
//    resCol[4].maxSize = 0;
//    resCol[4].dataRow = 1;
//    strcpy(resCol[4].dataBuf[0], "zhang");
//
//    // No3 Column
//    resCol[5].colId = 6;
//    strcpy(resCol[5].bndName, ":firstname");
//    resCol[5].colType = eVARCHAR2;
//    resCol[5].maxSize = 0;
//    resCol[5].dataRow = 1;
//    strcpy(resCol[5].dataBuf[0], "zhengshuang");
//
//    // No4 Column
//    resCol[6].colId = 7;
//    strcpy(resCol[6].bndName, ":address");
//    resCol[6].colType = eVARCHAR2;
//    resCol[6].maxSize = 0;
//    resCol[6].dataRow = 1;
//    strcpy(resCol[6].dataBuf[0], "address_No.30");
//
//    rslt = DbCmmnSqlSingleExecute(connId, sql, resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
//
//}
//#endif // Function OCI test is passed.
//
//// Update single data to database.
//#if 0
//TEST(dbCommTest, DbCmmnSqlSingleExecute){
//    char funcName[] = "DbCmmnSqlSingleExecute";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol[7];
//    int32 iValue;
//    double dValue;
//    float fValue;
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 7;
//
//    strcpy(sql, "update test_oci set ");
//    strcat(sql, "ID = :id, CODELINE = :codeline, COVERAGE = :coverage, SEQNO = :seqno, LASTNAME = :lastname, FIRSTNAME = :firstname, ADDRESS = :address ");
//    strcat(sql, "where ");
//    strcat(sql, "ID = 30 ");
//
//    iValue = 31;
//    dValue = 53.42;
//    fValue = 2.34;
//
//    // No1 Column
//    resCol[0].colId = 1;
//    strcpy(resCol[0].bndName, ":id");
//    resCol[0].colType = eINTEGER;
//    resCol[0].maxSize = 0;
//    resCol[0].dataRow = 1;
//    memcpy(resCol[0].dataBuf[0], &iValue, sizeof(iValue));
//
//    // No5 Column
//    resCol[1].colId = 2;
//    strcpy(resCol[1].bndName, ":codeline");
//    resCol[1].colType = eDOUBLE;
//    resCol[1].maxSize = 0;
//    resCol[1].dataRow = 1;
//    memcpy(resCol[1].dataBuf[0], &dValue, sizeof(dValue));
//
//    // No6 Column
//    resCol[2].colId = 3;
//    strcpy(resCol[2].bndName, ":coverage");
//    resCol[2].colType = eFLOAT;
//    resCol[2].maxSize = 0;
//    resCol[2].dataRow = 1;
//    memcpy(resCol[2].dataBuf[0], &fValue, sizeof(fValue));
//
//    // No7 Column
//    resCol[3].colId = 4;
//    strcpy(resCol[3].bndName, ":seqno");
//    resCol[3].colType = eINTEGER;
//    resCol[3].maxSize = 0;
//    resCol[3].dataRow = 1;
//    memcpy(resCol[3].dataBuf[0], &iValue, sizeof(iValue));
//
//    // No2 Column
//    resCol[4].colId = 5;
//    strcpy(resCol[4].bndName, ":lastname");
//    resCol[4].colType = eVARCHAR2;
//    resCol[4].maxSize = 0;
//    resCol[4].dataRow = 1;
//    strcpy(resCol[4].dataBuf[0], "cui");
//
//    // No3 Column
//    resCol[5].colId = 6;
//    strcpy(resCol[5].bndName, ":firstname");
//    resCol[5].colType = eVARCHAR2;
//    resCol[5].maxSize = 0;
//    resCol[5].dataRow = 1;
//    strcpy(resCol[5].dataBuf[0], "xiaolin");
//
//    // No4 Column
//    resCol[6].colId = 7;
//    strcpy(resCol[6].bndName, ":address");
//    resCol[6].colType = eVARCHAR2;
//    resCol[6].maxSize = 0;
//    resCol[6].dataRow = 1;
//    strcpy(resCol[6].dataBuf[0], "address_No.31");
//
//    rslt = DbCmmnSqlSingleExecute(connId, sql, resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
//
//}
//#endif // Function OCI test is passed.
//
//// delete single data to database.
//#if 0
//TEST(dbCommTest, DbCmmnSqlSingleExecute){
//    char funcName[] = "DbCmmnSqlSingleExecute";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol;
//    int32 iValue;
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 1;
//
//    strcpy(sql, "delete from test_oci ");
//    strcat(sql, "where ");
//    strcat(sql, "ID = :id ");
//
//    iValue = 31;
//
//    // No1 Column
//    resCol.colId = 1;
//    strcpy(resCol.bndName, ":id");
//    resCol.colType = eINTEGER;
//    resCol.maxSize = 0;
//    resCol.dataRow = 1;
//    memcpy(resCol.dataBuf[0], &iValue, sizeof(iValue));
//
//    rslt = DbCmmnSqlSingleExecute(connId, sql, &resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
//
//}
//#endif // Function OCI test is passed.
//
//// Insert batch data to db
//#if 0
//TEST(dbCommTest, DbCmmnSqlBatchExecute){
//    char funcName[] = "DbCmmnSqlBatchExecute";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol[7];
//    int32 idValue[10] = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110};
//    char lastname[10][20+1] = {
//        "lastname101",
//        "lastname102",
//        "lastname103",
//        "lastname104",
//        "lastname105",
//        "lastname106",
//        "lastname107",
//        "lastname108",
//        "lastname109",
//        "lastname110"
//    };
//    char firstname[10][20+1] = {
//        "firstname101",
//        "firstname102",
//        "firstname103",
//        "firstname104",
//        "firstname105",
//        "firstname106",
//        "firstname107",
//        "firstname108",
//        "firstname109",
//        "firstname110"
//    };
//    char address[10][20+1] = {
//        "address_No.101",
//        "address_No.102",
//        "address_No.103",
//        "address_No.104",
//        "address_No.105",
//        "address_No.106",
//        "address_No.107",
//        "address_No.108",
//        "address_No.109",
//        "address_No.110"
//    };
//
//    double codelineValue[10] = {101.11, 102.11, 103.11, 104.11, 105.11, 106.11, 107.11, 108.11, 109.11, 110.11};
//    float coverageValue[10] = {101.22, 102.22, 103.22, 104.22, 105.22, 106.22, 107.22, 108.22, 109.22, 110.22};
//    int32 seqnoValue[10] = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110};
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 7;
//
//    strcpy(sql, "insert into test_oci ");
//    strcat(sql, "(ID, CODELINE, COVERAGE, SEQNO, LASTNAME, FIRSTNAME, ADDRESS) ");
//    strcat(sql, "values ");
//    strcat(sql, "(:id, :codeline, :coverage, :seqno, :lastname, :firstname, :address) ");
//
//    // No1 Column
//    resCol[0].colId = 1;
//    strcpy(resCol[0].bndName, ":id");
//    resCol[0].colType = eINTEGER;
//    resCol[0].maxSize = 20;
//    resCol[0].dataRow = 10;
//    memcpy(resCol[0].dataBuf, idValue, sizeof(idValue));
//
//    // No5 Column
//    resCol[1].colId = 2;
//    strcpy(resCol[1].bndName, ":codeline");
//    resCol[1].colType = eDOUBLE;
//    resCol[1].maxSize = 20;
//    resCol[1].dataRow = 10;
//    memcpy(resCol[1].dataBuf, codelineValue, sizeof(codelineValue));
//
//    // No6 Column
//    resCol[2].colId = 3;
//    strcpy(resCol[2].bndName, ":coverage");
//    resCol[2].colType = eFLOAT;
//    resCol[2].maxSize = 20;
//    resCol[2].dataRow = 10;
//    memcpy(resCol[2].dataBuf, coverageValue, sizeof(coverageValue));
//
//    // No7 Column
//    resCol[3].colId = 4;
//    strcpy(resCol[3].bndName, ":seqno");
//    resCol[3].colType = eINTEGER;
//    resCol[3].maxSize = 20;
//    resCol[3].dataRow = 10;
//    memcpy(resCol[3].dataBuf, seqnoValue, sizeof(seqnoValue));
//
//    // No2 Column
//    resCol[4].colId = 5;
//    strcpy(resCol[4].bndName, ":lastname");
//    resCol[4].colType = eVARCHAR2;
//    resCol[4].maxSize = 20;
//    resCol[4].dataRow = 10;
//    memcpy(resCol[4].dataBuf, lastname, sizeof(lastname));
//
//    // No3 Column
//    resCol[5].colId = 6;
//    strcpy(resCol[5].bndName, ":firstname");
//    resCol[5].colType = eVARCHAR2;
//    resCol[5].maxSize = 20;
//    resCol[5].dataRow = 10;
//    memcpy(resCol[5].dataBuf, firstname, sizeof(firstname));
//
//    // No4 Column
//    resCol[6].colId = 7;
//    strcpy(resCol[6].bndName, ":address");
//    resCol[6].colType = eVARCHAR2;
//    resCol[6].maxSize = 20;
//    resCol[6].dataRow = 10;
//    memcpy(resCol[6].dataBuf, address, sizeof(address));
//
//    rslt = DbCmmnSqlBatchExecute(connId, sql, resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
//
//}
//#endif // Function OCI test is passed.
//
//
//// update batch data to database.
//#if 0
//TEST(dbCommTest, DbCmmnSqlBatchExecute){
//    char funcName[] = "DbCmmnSqlBatchExecute";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol[7];
//    int32 idValue[10] = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110};
//    char lastname[10][20+1] = {
//        "lastname201",
//        "lastname202",
//        "lastname203",
//        "lastname204",
//        "lastname205",
//        "lastname206",
//        "lastname207",
//        "lastname208",
//        "lastname209",
//        "lastname210"
//    };
//    char firstname[10][20+1] = {
//        "firstname201",
//        "firstname202",
//        "firstname203",
//        "firstname204",
//        "firstname205",
//        "firstname206",
//        "firstname207",
//        "firstname208",
//        "firstname209",
//        "firstname210"
//    };
//    char address[10][20+1] = {
//        "address_No.201",
//        "address_No.202",
//        "address_No.203",
//        "address_No.204",
//        "address_No.205",
//        "address_No.206",
//        "address_No.207",
//        "address_No.208",
//        "address_No.209",
//        "address_No.210"
//    };
//
//    double codelineValue[10] = {201.11, 202.11, 203.11, 204.11, 205.11, 206.11, 207.11, 208.11, 209.11, 210.11};
//    float coverageValue[10] = {201.22, 202.22, 203.22, 204.22, 205.22, 206.22, 207.22, 208.22, 209.22, 210.22};
//    int32 seqnoValue[10] = {201, 202, 203, 204, 205, 206, 207, 208, 209, 210};
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 7;
//
//    strcpy(sql, "update test_oci set ");
//    strcat(sql, "CODELINE = :codeline, COVERAGE = :coverage, SEQNO = :seqno, LASTNAME = :lastname, FIRSTNAME = :firstname, ADDRESS = :address ");
//    strcat(sql, "where ");
//    strcat(sql, "ID = :id ");
//
//    // No1 Column
//    resCol[0].colId = 1;
//    strcpy(resCol[0].bndName, ":id");
//    resCol[0].colType = eINTEGER;
//    resCol[0].maxSize = 20;
//    resCol[0].dataRow = 10;
//    memcpy(resCol[0].dataBuf, idValue, sizeof(idValue));
//
//    // No5 Column
//    resCol[1].colId = 2;
//    strcpy(resCol[1].bndName, ":codeline");
//    resCol[1].colType = eDOUBLE;
//    resCol[1].maxSize = 20;
//    resCol[1].dataRow = 10;
//    memcpy(resCol[1].dataBuf, codelineValue, sizeof(codelineValue));
//
//    // No6 Column
//    resCol[2].colId = 3;
//    strcpy(resCol[2].bndName, ":coverage");
//    resCol[2].colType = eFLOAT;
//    resCol[2].maxSize = 20;
//    resCol[2].dataRow = 10;
//    memcpy(resCol[2].dataBuf, coverageValue, sizeof(coverageValue));
//
//    // No7 Column
//    resCol[3].colId = 4;
//    strcpy(resCol[3].bndName, ":seqno");
//    resCol[3].colType = eINTEGER;
//    resCol[3].maxSize = 20;
//    resCol[3].dataRow = 10;
//    memcpy(resCol[3].dataBuf, seqnoValue, sizeof(seqnoValue));
//
//    // No2 Column
//    resCol[4].colId = 5;
//    strcpy(resCol[4].bndName, ":lastname");
//    resCol[4].colType = eVARCHAR2;
//    resCol[4].maxSize = 20;
//    resCol[4].dataRow = 10;
//    memcpy(resCol[4].dataBuf, lastname, sizeof(lastname));
//
//    // No3 Column
//    resCol[5].colId = 6;
//    strcpy(resCol[5].bndName, ":firstname");
//    resCol[5].colType = eVARCHAR2;
//    resCol[5].maxSize = 20;
//    resCol[5].dataRow = 10;
//    memcpy(resCol[5].dataBuf, firstname, sizeof(firstname));
//
//    // No4 Column
//    resCol[6].colId = 7;
//    strcpy(resCol[6].bndName, ":address");
//    resCol[6].colType = eVARCHAR2;
//    resCol[6].maxSize = 20;
//    resCol[6].dataRow = 10;
//    memcpy(resCol[6].dataBuf, address, sizeof(address));
//
//    rslt = DbCmmnSqlBatchExecute(connId, sql, resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
//
//}
//#endif // Function OCI test is passed.
//
//// delete batch data to database.
//#if 0
//TEST(dbCommTest, DbCmmnSqlBatchExecute){
//    char funcName[] = "DbCmmnSqlBatchExecute";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol;
//    int32 idValue[10] = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110};
//    char lastname[10][20+1] = {
//        "lastname201",
//        "lastname202",
//        "lastname203",
//        "lastname204",
//        "lastname205",
//        "lastname206",
//        "lastname207",
//        "lastname208",
//        "lastname209",
//        "lastname210"
//    };
//    char firstname[10][20+1] = {
//        "firstname201",
//        "firstname202",
//        "firstname203",
//        "firstname204",
//        "firstname205",
//        "firstname206",
//        "firstname207",
//        "firstname208",
//        "firstname209",
//        "firstname210"
//    };
//    char address[10][20+1] = {
//        "address_No.201",
//        "address_No.202",
//        "address_No.203",
//        "address_No.204",
//        "address_No.205",
//        "address_No.206",
//        "address_No.207",
//        "address_No.208",
//        "address_No.209",
//        "address_No.210"
//    };
//
//    double codelineValue[10] = {201.11, 202.11, 203.11, 204.11, 205.11, 206.11, 207.11, 208.11, 209.11, 210.11};
//    float coverageValue[10] = {201.22, 202.22, 203.22, 204.22, 205.22, 206.22, 207.22, 208.22, 209.22, 210.22};
//    int32 seqnoValue[10] = {201, 202, 203, 204, 205, 206, 207, 208, 209, 210};
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n", funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 1;
//
//    strcpy(sql, "delete from test_oci ");
//    strcat(sql, "where ");
//    strcat(sql, "ID = :id ");
//
//    // No1 Column
//    resCol.colId = 1;
//    strcpy(resCol.bndName, ":id");
//    resCol.colType = eINTEGER;
//    resCol.maxSize = 20;
//    resCol.dataRow = 10;
//    memcpy(resCol.dataBuf, idValue, sizeof(idValue));
//
//
//    rslt = DbCmmnSqlBatchExecute(connId, sql, &resCol, &resNum);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCommit(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n", funcName);
//
//}
//
//
//#endif // Function Sample test is passed.
//
//#if 0
//TEST(dbCommTest, DbCmmnSqlSelect){
//    char funcName[] = "DbCmmnSqlSelect";
//
//    // variable define
//    ResCodeT rslt;
//    int32 connId;
//    char sql[1000];
//    int32 resNum;
//    RsltCol resCol[7];
//    int32 selId;
//    int32 count = 0;
//
//    int32 idVal;
//    double codelineVal;
//    float coverageVal;
//    int32 seqnoVal;
//
//    TRACE("[NORMAL](%s)Start:TestCase01.\n" $$ funcName);
//
//    // environment initialize.
//    if (DbCmmnInit() != NO_ERR){
//        TRACE("[ERROR](%s):Common Init failed.\n" $$ funcName);
//        return ;
//    }
//    rslt = NO_ERR;
//    connId = 0;
//    selId = 0;
//
//    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
//    if (rslt != NO_ERR){
//        TRACE("[ERROR](%s):Connect to database is failed.\n" $$ funcName);
//        return ;
//    }
//
//    memset(sql, 0, sizeof(sql));
//    memset(&resCol, 0, sizeof(resCol));
//    resNum = 7;
//
//    strcpy(sql, "select ");
//    strcat(sql, "ID, LASTNAME, FIRSTNAME, ADDRESS, CODELINE, COVERAGE, SEQNO ");
//    strcat(sql, "from test_oci ");
//    strcat(sql, "order by id ");
//
//    rslt = DbCmmnSqlSelect(connId, sql, &selId);
//    EXPECT_EQ(NO_ERR, rslt);
//
//
//    // No1 Column
//    resCol[0].colId = 1;
//    strcpy(resCol[0].bndName, ":id");
//    resCol[0].colType = eINTEGER;
//
//    // No2 Column
//    resCol[1].colId = 2;
//    strcpy(resCol[1].bndName, ":lastname");
//    resCol[1].colType = eVARCHAR2;
//
//    // No3 Column
//    resCol[2].colId = 3;
//    strcpy(resCol[2].bndName, ":firstname");
//    resCol[2].colType = eVARCHAR2;
//
//    // No4 Column
//    resCol[3].colId = 4;
//    strcpy(resCol[3].bndName, ":address");
//    resCol[3].colType = eVARCHAR2;
//
//    // No5 Column
//    resCol[4].colId = 5;
//    strcpy(resCol[4].bndName, ":codeline");
//    resCol[4].colType = eDOUBLE;
//
//    // No6 Column
//    resCol[5].colId = 6;
//    strcpy(resCol[5].bndName, ":coverage");
//    resCol[5].colType = eFLOAT;
//
//    // No7 Column
//    resCol[6].colId = 7;
//    strcpy(resCol[6].bndName, ":seqno");
//    resCol[6].colType = eINTEGER;
//
//    while (DbCmmnSqlFetchNext(connId, selId, resCol, &resNum) == NO_ERR){
//        memcpy(&idVal, resCol[0].dataBuf[0], sizeof(idVal));
//        memcpy(&codelineVal, resCol[4].dataBuf[0], sizeof(codelineVal));
//        memcpy(&coverageVal, resCol[5].dataBuf[0], sizeof(coverageVal));
//        memcpy(&seqnoVal, resCol[6].dataBuf[0], sizeof(seqnoVal));
//
//        TRACE("record[%d]:ID=%d, LASTNAME=%s, FIRSTNAME=%s, ADDRESS=%s, CODELINE=%.2lf, COVERAGE=%.2f, SEQNO=%d.\n" $$ 
//            count $$
//            idVal $$
//            resCol[1].dataBuf[0] $$
//            resCol[2].dataBuf[0] $$
//            resCol[3].dataBuf[0] $$
//            codelineVal $$
//            coverageVal $$
//            seqnoVal);
//        count++;
//    }
//
//    rslt = DbCmmnDisConnect(connId);
//    EXPECT_EQ(NO_ERR, rslt);
//    rslt = DbCmmnCleanup();
//    EXPECT_EQ(NO_ERR, rslt);
//
//    TRACE("[NORMAL](%s)End:TestCase01.\n" $$ funcName);
//
//}
//#endif // Function OCI test is passed.
//
//
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////Function Test Ending////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//
//// Function Test End.
//
//// Step 3. Call RUN_ALL_TESTS() in main().
////
//// We do this by linking in src/gtest_main.cc file, which consists of
//// a main() function which calls RUN_ALL_TESTS() for us.
////
//// This runs all the tests you've defined, prints the result, and
//// returns 0 if successful, or 1 otherwise.
////
//// Did you notice that we didn't register the tests?  The
//// macro magically knows about all the tests we
//// defined.  Isn't this convenient?

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

