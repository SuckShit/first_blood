/***
Created on July 07, 2017
@author: XiaoPing Zhou
@version $Id
***/
// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)


// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include <limits.h>
#include <pthread.h>          
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <math.h>
#include "contract_info.h"    
#include "err_lib.h"      
#include "shm.h"
#include "uti_tool.h"
#include "db_comm.h"
#include "common_macro.h"
#include "cfg_lib.h"
#include "gtest/gtest.h"


// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.
using ::testing::InitGoogleTest; 

int32 connId;

class contractInfoTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // printf("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // printf("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
        ResCodeT rc = NO_ERR;
        int32 dataNum = 1;
        cfgValueS cfgValue = {0};
        
        DbCmmnInit();
        // insert the test data into table CONTRCT_BASE_INFO
        char prcsName[] = "";
        PrcsInit(prcsName); 
      
        rc = GetCfgValue(&cfgValue);
        EXPECT_EQ(rc,NO_ERR);
      
        rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        EXPECT_EQ(rc,NO_ERR);
        
        rc = IrsCntrctInfoLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);
    }
    
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        
        rc = IrsCntrctInfoDetachFromShm();
        EXPECT_EQ(rc, NO_ERR);
        
        DbCmmnDisconnect(connId);
        DbCmmnCleanup();
        ShmDelete((char*)SHM_IRS_CONTRACT_INFO_NAME);
    }   

};


// Test the method [IrsCntrctInfoGetByName]
TEST_F(contractInfoTest, getByName) {
    
    ResCodeT rc = NO_ERR;
    CntrctBaseInfoT testData; 

	/* -------------- IRS ----------------------------------------- */
    // Specify the contract name of the test data
    rc = IrsCntrctInfoGetByName((char*)"FR007_1Y*2Y", &testData);
    EXPECT_EQ(rc, NO_ERR);

    // Also verify that the fields in testData are equal to the test data.
    EXPECT_EQ(strcmp(testData.cntrctName,"FR007_1Y*2Y"), 0);
    EXPECT_EQ(testData.cntrctType, 1);
    EXPECT_EQ(testData.mktId, 1);
    EXPECT_EQ(strcmp(testData.shrtCntrctName,"FR007_1Y"), 0);
    EXPECT_EQ(strcmp(testData.lngCntrctName,"FR007_2Y"), 0);
    EXPECT_EQ(testData.shrtAmntRatio, 2*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(testData.lngAmntRatio, 1*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(testData.maxAmntPerDeal, 1000);
    EXPECT_EQ(testData.minAmntPerDeal, 1);
    EXPECT_EQ(testData.dealUnit, 50000000);
    EXPECT_EQ(testData.dealPrcUnit, 0);
    EXPECT_EQ(testData.term, 24);
    EXPECT_EQ(testData.st, 1);
    EXPECT_EQ(strcmp(testData.termStrng,"2Y"), 0);
    EXPECT_EQ(testData.brdgSort, 17);
    
    
    // Specify the contract name that doesn't exist in the test data
    rc = IrsCntrctInfoGetByName((char*)"aaaaa", &testData);
    EXPECT_EQ(rc, ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
    
    
	/* -------------- SIRS ----------------------------------------- */
	rc = IrsCntrctInfoGetByName((char*)"SS011M_1410", &testData);
    EXPECT_EQ(rc, NO_ERR);

    // Also verify that the fields in testData are equal to the test data.
    EXPECT_EQ(strcmp(testData.cntrctName,"SS011M_1410"), 0);
    EXPECT_EQ(testData.mktId, 2);
    EXPECT_EQ(testData.st, 2);
    EXPECT_EQ(testData.term, 1);
    EXPECT_EQ(testData.maxAmntPerDeal, 99);
    EXPECT_EQ(testData.minAmntPerDeal, 1);
	
    EXPECT_EQ(testData.dealPrcUnit, 1);
	
    EXPECT_EQ(strcmp(testData.cntrctNameEn,"ShiborO/N_1M"), 0);
    EXPECT_EQ(strcmp(testData.cntrctMth,"1410"), 0);
    EXPECT_EQ(testData.cntrctFaceVal, 50000000*pow10(FIGURES_OF_CONTRCT_FACE_VAL));
    EXPECT_EQ(strcmp(testData.dlvryDate,"2014-10-15 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.actvDate,"2013-10-16 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.exprdDate,"2014-10-14 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.trdngEndTm,"09:30:00"), 0);
    EXPECT_EQ(testData.emgcyFlag, 1);
    EXPECT_EQ(testData.settleType, 1);
    EXPECT_EQ(testData.amntPerUnit, 100000000*pow10(FIGURES_OF_AMNT_PER_UNIT));
    EXPECT_EQ(testData.bnchmkRate, 1.9867 * pow10(FIGURES_OF_BENCHMARK_RATE));
	
	EXPECT_EQ(strcmp(testData.intrstStartDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.intrstEndDate,"2014-10-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.intrstDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.frstIntrstDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(testData.intrstDaysAdj, 2);
	EXPECT_EQ(testData.pymntDateAdj, 3);
	EXPECT_EQ(strcmp(testData.fxdIntrstBidDlvryDate,"2014-10-15 00:00:00"), 0);
	EXPECT_EQ(testData.fxdIntrstBidPymntPeriod, 1);
	EXPECT_EQ(testData.fxdIntrstBidIntrstBnchmk, 1);
	EXPECT_EQ(testData.fxdIntrstBidIntrstType, 2);
	EXPECT_EQ(strcmp(testData.refCntrct,"Shibor_O/N"), 0);
	EXPECT_EQ(strcmp(testData.fxdIntrstOfrDlvryDay,"2014-10-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.frstIntrstCnfrmDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(testData.intrstType, 1);
	EXPECT_EQ(testData.intrstSpread, 0*pow10(FIGURES_OF_INTREST_SPREAD));
	EXPECT_EQ(testData.fxdIntrstOfrPymntPeriod, 1);
	EXPECT_EQ(testData.resetRate, 1);
	EXPECT_EQ(testData.fxdIntrstOfrIntrstBnchmk, 2);
	
	
	/* -------------- SBFCCP ----------------------------------------- */
	rc = IrsCntrctInfoGetByName((char*)"CDB3_1503", &testData);
    EXPECT_EQ(rc, NO_ERR);

    // Also verify that the fields in testData are equal to the test data.
    EXPECT_EQ(strcmp(testData.cntrctName,"CDB3_1503"), 0);
    EXPECT_EQ(testData.mktId, 5);
    EXPECT_EQ(testData.st, 2);
    EXPECT_EQ(testData.term, 12);
    EXPECT_EQ(testData.maxAmntPerDeal, 99);
    EXPECT_EQ(testData.minAmntPerDeal, 1);
	
    EXPECT_EQ(strcmp(testData.cntrctNameEn,"CDB3"), 0);
    EXPECT_EQ(strcmp(testData.cntrctMth,"1503"), 0);
    EXPECT_EQ(testData.cntrctFaceVal, 10000000*pow10(FIGURES_OF_CONTRCT_FACE_VAL));
    EXPECT_EQ(strcmp(testData.dlvryDate,"2015-03-18 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.actvDate,"2014-03-19 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.exprdDate,"2015-03-17 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.trdngEndTm,"12:00:00"), 0);
    EXPECT_EQ(testData.emgcyFlag, 1);
    EXPECT_EQ(testData.settleType, 2);
    EXPECT_EQ(testData.amntPerUnit, 10000000*pow10(FIGURES_OF_AMNT_PER_UNIT));
    EXPECT_EQ(testData.bnchmkRate, 0);
	
	EXPECT_EQ(testData.cnvrtRate, 1*pow10(FIGURES_OF_CONVERT_RATE));
	EXPECT_EQ(testData.prcLimit, 10*pow10(FIGURES_OF_PRICE_LIMIT));
	EXPECT_EQ(testData.chkSt, 3);
	EXPECT_EQ(testData.cpnRate, 0.03*pow10(FIGURES_OF_COUPON_RATE));
	EXPECT_EQ(testData.cntrctUndrlyng, 3);
    
    
  // <TechnicalDetails>
  //
  // EXPECT_EQ(expected, actual) is the same as
  //
  //   EXPECT_TRUE((expected) == (actual))
  //
  // except that it will print both the expected value and the actual
  // value when the assertion fails.  This is very helpful for
  // debugging.  Therefore in this case EXPECT_EQ is preferred.
  //
  // On the other hand, EXPECT_TRUE accepts any Boolean expression,
  // and is thus more general.
  //
  // </TechnicalDetails>
}


// // Test the method [IrsCntrctInfoGetByNameExt]
TEST_F(contractInfoTest, getByNameExt) {
    
    ResCodeT rc = NO_ERR;
    CntrctBaseInfoT verifyData;
    pCntrctBaseInfoT pData;
    
    // Specify the contract name that exists in the test data
    rc = IrsCntrctInfoGetByNameExt((char*)"FR007_1Y*2Y", &pData);
    EXPECT_EQ(rc, NO_ERR);

    // also verify that the fields in pData are equal to the test data.
    EXPECT_EQ(strcmp(pData->cntrctName,"FR007_1Y*2Y"), 0);
    EXPECT_EQ(pData->cntrctType, 1);
    EXPECT_EQ(pData->mktId, 1);
    EXPECT_EQ(strcmp(pData->shrtCntrctName,"FR007_1Y"), 0);
    EXPECT_EQ(strcmp(pData->lngCntrctName,"FR007_2Y"), 0);
    EXPECT_EQ(pData->shrtAmntRatio, 2*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(pData->lngAmntRatio, 1*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(pData->maxAmntPerDeal, 1000);
    EXPECT_EQ(pData->minAmntPerDeal, 1);
    EXPECT_EQ(pData->dealUnit, 50000000);
    EXPECT_EQ(pData->dealPrcUnit, 0);
    EXPECT_EQ(pData->term, 24);
    EXPECT_EQ(pData->st, 1);
    EXPECT_EQ(strcmp(pData->termStrng,"2Y"), 0);
    EXPECT_EQ(pData->brdgSort, 17);
    
    // Specify the contract name that doesn't exist in the test data
    rc = IrsCntrctInfoGetByNameExt((char*)"aaaaa", &pData);
    EXPECT_EQ(rc, ERR_CMN_HASH_LIST_NODE_NOT_EXIST);


    // Specify the contract name that exists in the test data
    rc = IrsCntrctInfoGetByNameExt((char*)"FR007_1Y*2Y", &pData);
    EXPECT_EQ(rc, NO_ERR);

    // use the pData to change some value. Then call IrsCntrctInfoGetByName to 
    // verify that the values in the shared memory also have been changed.
    pData->term = 12;
    strcpy(pData->termStrng, "1Y");
    
    rc = IrsCntrctInfoGetByName((char*)"FR007_1Y*2Y", &verifyData);
    EXPECT_EQ(rc, NO_ERR);
    EXPECT_EQ(verifyData.term, 12);
    EXPECT_EQ(strcmp(verifyData.termStrng,"1Y"), 0);
    
}



// Test the method [IrsCntrctInfoGetByPos]
TEST_F(contractInfoTest, getByPos) {
    
    ResCodeT rc = NO_ERR;
    CntrctBaseInfoT testData,posData;
    int32 dataPos;    
    
    rc = IrsCntrctInfoGetByName((char*)"FR007_1Y*2Y", &posData);
    EXPECT_EQ(rc, NO_ERR);
    dataPos = posData.pos;
    
    // Specify the contract position of the test data
    rc = IrsCntrctInfoGetByPos(dataPos, &testData);
    EXPECT_EQ(rc, NO_ERR);

    // TODO: also verify that the fields in pData are equal to the test data.
    EXPECT_EQ(strcmp(testData.cntrctName,"FR007_1Y*2Y"), 0);
    EXPECT_EQ(testData.cntrctType, 1);
    EXPECT_EQ(testData.mktId, 1);
    EXPECT_EQ(strcmp(testData.shrtCntrctName,"FR007_1Y"), 0);
    EXPECT_EQ(strcmp(testData.lngCntrctName,"FR007_2Y"), 0);
    EXPECT_EQ(testData.shrtAmntRatio, 2*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(testData.lngAmntRatio, 1*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(testData.maxAmntPerDeal, 1000);
    EXPECT_EQ(testData.minAmntPerDeal, 1);
    EXPECT_EQ(testData.dealUnit, 50000000);
    EXPECT_EQ(testData.dealPrcUnit, 0);
    // EXPECT_EQ(testData.term, 12);
    EXPECT_EQ(testData.st, 1);
    // EXPECT_EQ(strcmp(testData.termStrng,"1Y"), 0);
    EXPECT_EQ(testData.brdgSort, 17);
    
    // Specify the position value that is too big
    rc = IrsCntrctInfoGetByPos(100000, &testData);
    EXPECT_EQ(rc, ERCD_ARCH_BUFF_TOO_SHORT);
	
	
	/* -------------- SIRS ----------------------------------------- */
	rc = IrsCntrctInfoGetByName((char*)"SS011M_1410", &posData);
    EXPECT_EQ(rc, NO_ERR);
    dataPos = posData.pos;
    
    // Specify the contract position of the test data
    rc = IrsCntrctInfoGetByPos(dataPos, &testData);
    EXPECT_EQ(rc, NO_ERR);
	
	EXPECT_EQ(strcmp(testData.cntrctName,"SS011M_1410"), 0);
    EXPECT_EQ(testData.mktId, 2);
    EXPECT_EQ(testData.st, 2);
    EXPECT_EQ(testData.term, 1);
    EXPECT_EQ(testData.maxAmntPerDeal, 99);
    EXPECT_EQ(testData.minAmntPerDeal, 1);
	
    EXPECT_EQ(testData.dealPrcUnit, 1);
	
    EXPECT_EQ(strcmp(testData.cntrctNameEn,"ShiborO/N_1M"), 0);
    EXPECT_EQ(strcmp(testData.cntrctMth,"1410"), 0);
    EXPECT_EQ(testData.cntrctFaceVal, 50000000*pow10(FIGURES_OF_CONTRCT_FACE_VAL));
    EXPECT_EQ(strcmp(testData.dlvryDate,"2014-10-15 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.actvDate,"2013-10-16 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.exprdDate,"2014-10-14 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.trdngEndTm,"09:30:00"), 0);
    EXPECT_EQ(testData.emgcyFlag, 1);
    EXPECT_EQ(testData.settleType, 1);
    EXPECT_EQ(testData.amntPerUnit, 100000000*pow10(FIGURES_OF_AMNT_PER_UNIT));
    EXPECT_EQ(testData.bnchmkRate, 1.9867 * pow10(FIGURES_OF_BENCHMARK_RATE));
	
	EXPECT_EQ(strcmp(testData.intrstStartDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.intrstEndDate,"2014-10-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.intrstDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.frstIntrstDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(testData.intrstDaysAdj, 2);
	EXPECT_EQ(testData.pymntDateAdj, 3);
	EXPECT_EQ(strcmp(testData.fxdIntrstBidDlvryDate,"2014-10-15 00:00:00"), 0);
	EXPECT_EQ(testData.fxdIntrstBidPymntPeriod, 1);
	EXPECT_EQ(testData.fxdIntrstBidIntrstBnchmk, 1);
	EXPECT_EQ(testData.fxdIntrstBidIntrstType, 2);
	EXPECT_EQ(strcmp(testData.refCntrct,"Shibor_O/N"), 0);
	EXPECT_EQ(strcmp(testData.fxdIntrstOfrDlvryDay,"2014-10-15 00:00:00"), 0);
	EXPECT_EQ(strcmp(testData.frstIntrstCnfrmDate,"2014-09-15 00:00:00"), 0);
	EXPECT_EQ(testData.intrstType, 1);
	EXPECT_EQ(testData.intrstSpread, 0*pow10(FIGURES_OF_INTREST_SPREAD));
	EXPECT_EQ(testData.fxdIntrstOfrPymntPeriod, 1);
	EXPECT_EQ(testData.resetRate, 1);
	EXPECT_EQ(testData.fxdIntrstOfrIntrstBnchmk, 2);
	
	
	/* -------------- SBFCCP ----------------------------------------- */
	rc = IrsCntrctInfoGetByName((char*)"CDB3_1503", &posData);
    EXPECT_EQ(rc, NO_ERR);
    dataPos = posData.pos;
    
    // Specify the contract position of the test data
    rc = IrsCntrctInfoGetByPos(dataPos, &testData);
    EXPECT_EQ(rc, NO_ERR);
	
	EXPECT_EQ(strcmp(testData.cntrctName,"CDB3_1503"), 0);
    EXPECT_EQ(testData.mktId, 5);
    EXPECT_EQ(testData.st, 2);
    EXPECT_EQ(testData.term, 12);
    EXPECT_EQ(testData.maxAmntPerDeal, 99);
    EXPECT_EQ(testData.minAmntPerDeal, 1);
	
    EXPECT_EQ(strcmp(testData.cntrctNameEn,"CDB3"), 0);
    EXPECT_EQ(strcmp(testData.cntrctMth,"1503"), 0);
    EXPECT_EQ(testData.cntrctFaceVal, 10000000*pow10(FIGURES_OF_CONTRCT_FACE_VAL));
    EXPECT_EQ(strcmp(testData.dlvryDate,"2015-03-18 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.actvDate,"2014-03-19 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.exprdDate,"2015-03-17 00:00:00"), 0);
    EXPECT_EQ(strcmp(testData.trdngEndTm,"12:00:00"), 0);
    EXPECT_EQ(testData.emgcyFlag, 1);
    EXPECT_EQ(testData.settleType, 2);
    EXPECT_EQ(testData.amntPerUnit, 10000000*pow10(FIGURES_OF_AMNT_PER_UNIT));
    EXPECT_EQ(testData.bnchmkRate, 0);
	
	EXPECT_EQ(testData.cnvrtRate, 1*pow10(FIGURES_OF_CONVERT_RATE));
	EXPECT_EQ(testData.prcLimit, 10*pow10(FIGURES_OF_PRICE_LIMIT));
	EXPECT_EQ(testData.chkSt, 3);
	EXPECT_EQ(testData.cpnRate, 0.03*pow10(FIGURES_OF_COUPON_RATE));
	EXPECT_EQ(testData.cntrctUndrlyng, 3);
    
}


// Test the method [IrsCntrctInfoGetByPosExt]
TEST_F(contractInfoTest, getByPosExt) {
    
    ResCodeT rc = NO_ERR;
    CntrctBaseInfoT posData,verifyData;
    pCntrctBaseInfoT pData; 
    int32 dataPos;    
    
    rc = IrsCntrctInfoGetByName((char*)"FR007_1Y*2Y", &posData);
    EXPECT_EQ(rc, NO_ERR);
    dataPos = posData.pos;
    
    // Specify the contract position of the test data
    rc = IrsCntrctInfoGetByPosExt(dataPos, &pData);
    EXPECT_EQ(rc, NO_ERR);

    // also verify that the fields in pData are equal to the test data.
    EXPECT_EQ(strcmp(pData->cntrctName,"FR007_1Y*2Y"), 0);
    EXPECT_EQ(pData->cntrctType, 1);
    EXPECT_EQ(pData->mktId, 1);
    EXPECT_EQ(strcmp(pData->shrtCntrctName,"FR007_1Y"), 0);
    EXPECT_EQ(strcmp(pData->lngCntrctName,"FR007_2Y"), 0);
    EXPECT_EQ(pData->shrtAmntRatio, 2*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(pData->lngAmntRatio, 1*pow10(FIGURES_OF_AMOUNT_RATIO));
    EXPECT_EQ(pData->maxAmntPerDeal, 1000);
    EXPECT_EQ(pData->minAmntPerDeal, 1);
    EXPECT_EQ(pData->dealUnit, 50000000);
    EXPECT_EQ(pData->dealPrcUnit, 0);
    // EXPECT_EQ(pData->term, 12);
    EXPECT_EQ(pData->st, 1);
    // EXPECT_EQ(strcmp(pData->termStrng,"1Y"), 0);
    EXPECT_EQ(pData->brdgSort, 17);
    
    // Specify the position value that is too big
    rc = IrsCntrctInfoGetByPosExt(100000, &pData);
    EXPECT_EQ(rc, ERCD_ARCH_BUFF_TOO_SHORT);


    // Specify the position of the test data
    rc = IrsCntrctInfoGetByPosExt(dataPos, &pData);
    EXPECT_EQ(rc, NO_ERR);

    // use the pData to change some value. Then call IrsCntrctInfoGetByPos to 
    // verify that the values in the shared memory also have been changed.
    pData->term = 36;
    strcpy(pData->termStrng, "3Y");
    
    rc = IrsCntrctInfoGetByName((char*)"FR007_1Y*2Y", &verifyData);
    EXPECT_EQ(rc, NO_ERR);
    EXPECT_EQ(verifyData.term, 36);
    EXPECT_EQ(strcmp(verifyData.termStrng,"3Y"), 0);
    
}



int main(int argc, char **argv) {

    // monEnv = new MonTestEnv;
    // testing::AddGlobalTestEnvironment(monEnv);
    testing::InitGoogleTest(&argc, argv);

    // Adds the leak checker to the end of the test event listener list,
    // after the default text output printer and the default XML report
    // generator.
    //
    // The order is important - it ensures that failures generated in the
    // leak checker's OnTestEnd() method are processed by the text and XML
    // printers *before* their OnTestEnd() methods are called, such that
    // they are attributed to the right test. Remember that a listener
    // receives an OnXyzStart event *after* listeners preceding it in the
    // list received that event, and receives an OnXyzEnd event *before*
    // listeners preceding it.
    //
    // We don't need to worry about deleting the new listener later, as

    return RUN_ALL_TESTS();
}

// Step 3. Call RUN_ALL_TESTS() in main().
//
// We do this by linking in src/gtest_main.cc file, which consists of
// a main() function which calls RUN_ALL_TESTS() for us.
//
// This runs all the tests you've defined, prints the result, and
// returns 0 if successful, or 1 otherwise.
//
// Did you notice that we didn't register the tests?  The
// macro magically knows about all the tests we
// defined.  Isn't this convenient?
