/***
Created on June 28, 2017
@author: No One
@version $Id
***/

// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)
    

// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include "gtest/gtest.h"
#include "err_lib.h"
#include "err_cod.h"
#include "data_type.h"
#include "dbcomm.h"

#include "SqlCommon.h"
#include "CntrctBaseInfoDb.h"

// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.

static char dbAddress[] = "200.31.155.145:1521/xswapdb";
static char username[] = "xswap";
static char password[] = "xswap";

class CntrctBaseInfoDbTest : public testing::Test {
//protected:
    // You should make the members protected s.t. they can be
    // accessed from sub-classes.

    // virtual void SetUp() will be called before each test is run.  You
    // should define it if you need to initialize the varaibles.
    // Otherwise, this can be skipped.
    virtual void SetUp() {}

    // virtual void TearDown() will be called after each test is run.
    // You should define it if there is cleanup work to do.  Otherwise,
    // you don't have to provide it.
    //
    virtual void TearDown() {}
};


////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////Function Test Starting//////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////





TEST(CntrctBaseInfoDbTest, BatchInsertCntrctBaseInfo) {
    char funcName[] = "BatchInsertCntrctBaseInfo";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;

    CntrctBaseInfoMulti data;
    int32 cntrctSrnoArray[5] = {201, 202, 203, 204, 205};
    char cntrctNmArray[5][7+1] = {"test201", "test202", "test203", "test204", "test205"};
    char cntrctTpArray[5][6+1] = {"test_A", "test_B", "test_C", "test_D", "test_E"};
    char mktIdArray[5][7+1] = {"mktid_A", "mktid_B", "mktid_C", "mktid_D", "mktid_E"};
    char shrtCntrctNmArray[5][8+1] = {"shrtNm_A", "shrtNm_B", "shrtNm_C", "shrtNm_D", "shrtNm_E"};
    char lngCntrctNmArray[5][7+1] = {"lngNm_A", "lngNm_B", "lngNm_C", "lngNm_D", "lngNm_E"};
    double shrtAmntRatioArray[5] = {200.01, 201.01, 202.01, 203.01, 204.01};
    double lngAmntRatioArray[5] = {200.02, 201.02, 202.02, 203.02, 204.02};
    int32 maxAmntPerDlArray[5] = {200, 201, 202, 203, 204};
    int32 minAmntPerDlArray[5] = {200, 201, 202, 203, 204};
    int32 dlUnitArray[5] = {200, 201, 202, 203, 204};
    char dlPrcUnitArray[5][1+1] = {"1", "2", "3", "4", "5"};
    int32 termArray[5] = {200, 201, 202, 203, 204};
    char stArray[5][1+1] = {"1", "2", "3", "4", "5"};
    char crtTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char crtUsrNmArray[5][6+1] = {"zhaoys", "zhaoys", "zhaoys", "zhaoys", "zhaoys"};
    char updTmArray[5][19+1] = {"2017-07-13 09:58:59", "2017-07-14 09:58:59", "2017-07-15 09:58:59", "2017-07-16 09:58:59", "2017-07-17 09:58:59"};
    char updUsrNmArray[5][6+1] = {"zhaoys", "zhaoys", "zhaoys", "zhaoys", "zhaoys"};
    char termStrngArray[5][2+1] = {"1Y", "2Y", "3Y", "4Y", "5Y"};
    int32 brdgSortArray[5] = {201, 202, 203, 204, 205};

    memset(&data, 0, sizeof(CntrctBaseInfoMulti));

/////////////////////////db connection create./////////////////////////////////////
    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }
    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }
/////////////////////////db connection create./////////////////////////////////////

    // data set.
    data.dataRow = 5;
    data.cntrctSrnoLst = cntrctSrnoArray;
    data.cntrctNmLst = (char**)cntrctNmArray;
    data.cntrctNmMaxSize = 7;
    data.cntrctTpLst = (char**)cntrctTpArray;
    data.cntrctTpMaxSize = 6;
    data.mktIdLst = (char**)mktIdArray;
    data.mktIdMaxSize = 7;

    data.shrtCntrctNmLst = (char**)shrtCntrctNmArray;
    data.shrtCntrctNmMaxSize = 8;
    data.lngCntrctNmLst = (char**)lngCntrctNmArray;
    data.lngCntrctNmMaxSize = 7;
    data.shrtAmntRatioLst = shrtAmntRatioArray;
    data.lngAmntRatioLst = lngAmntRatioArray;
    data.maxAmntPerDlLst = maxAmntPerDlArray;
    data.minAmntPerDlLst = minAmntPerDlArray;
    data.dlUnitLst = dlUnitArray;
    data.dlPrcUnitLst = (char**)dlPrcUnitArray;
    data.dlPrcUnitMaxSize = 1;
    data.termLst = termArray; 
    data.stLst = (char**)stArray;
    data.stMaxSize = 1;
    data.crtTmLst = crtTmArray[0];
    data.crtTmMaxSize = 19;
    data.crtUsrNmLst = (char**)crtUsrNmArray;
    data.crtUsrNmMaxSize = 6;
    data.updTmLst = updTmArray[0];
    data.updTmMaxSize = 19;
    data.updUsrNmLst = (char**)updUsrNmArray;
    data.updUsrNmMaxSize = 6;
    data.termStrngLst = (char**)termStrngArray;
    data.termStrngMaxSize = 2;
    data.brdgSortLst = brdgSortArray;


    // insert data to table.
    rslt = BatchInsertCntrctBaseInfo(connId, &data);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}







#if 0 // passed.

TEST(CntrctBaseInfoDbTest, BatchUpdateCntrctBaseInfo) {
    char funcName[] = "BatchUpdateCntrctBaseInfo";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;

    TableColumn keyData;
    TableColumn data[6];
    int32 dCol = 6;
    int32 dRow = 5;

    // key data.
    int32 cntrctSrnoArray[5] = {180, 181, 182, 183, 184};

    // update data.
    char cntrctNmArray[5][7+1] = {"test200", "test201", "test202", "test203", "test204"};
    double shrtAmntRatioArray[5] = {200.01, 201.01, 202.01, 203.01, 204.01};
    int32 minAmntPerDlArray[5] = {200, 201, 202, 203, 204};
    char updTmArray[5][19+1] = {"2017-07-17 17:58:59", "2017-07-17 17:59:59", "2017-07-17 18:00:00", "2017-07-17 18:10:00", "2017-07-17 18:20:00"};
    char updUsrNmArray[5][5+1] = {"lidw1", "lidw2", "lidw3", "lidw4", "lidw5"};
    int32 brdgSortArray[5] = {180, 181, 182, 183, 184};

    memset(&keyData, 0, sizeof(TableColumn));
    memset(data, 0, sizeof(TableColumn)*6);

/////////////////////////db connection create./////////////////////////////////////
    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }
    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }
/////////////////////////db connection create./////////////////////////////////////

/*
typedef struct recTableColumn{
    char colName[20];
    EColumnType type;
    char bndName[20];
    char value[100];
    int32 maxSize;
}TableColumn;
*/

    // key data set.
    strcpy(keyData.colName, "CNTRCT_SRNO");
    keyData.type = eColumnINTEGER;
    strcpy(keyData.bndName, ":cntrct_srno");
    keyData.maxSize = sizeof(int32);
    memcpy(keyData.value, cntrctSrnoArray, sizeof(int32)*dRow);

    // update data set.
    strcpy(data[0].colName, "CNTRCT_NM");
    data[0].type = eColumnVARCHAR2;
    strcpy(data[0].bndName, ":cntrct_nm");
    data[0].maxSize = 7;
    memcpy(data[0].value, cntrctNmArray, (7+1)*(dRow+1));

    strcpy(data[1].colName, "SHRT_AMNT_RATIO");
    data[1].type = eColumnDOUBLE;
    strcpy(data[1].bndName, ":shrt_amnt_ratio");
    data[1].maxSize = sizeof(double);
    memcpy(data[1].value, shrtAmntRatioArray, sizeof(double)*dRow);

    strcpy(data[2].colName, "MIN_AMNT_PER_DL");
    data[2].type = eColumnINTEGER;
    strcpy(data[2].bndName, ":min_amnt_per_dl");
    data[2].maxSize = sizeof(int32);
    memcpy(data[2].value, minAmntPerDlArray, sizeof(int32)*dRow);

    strcpy(data[3].colName, "UPD_TM");
    data[3].type = eColumnTIMESTAMP;
    strcpy(data[3].bndName, ":upd_tm");
    data[3].maxSize = 19;
    memcpy(data[3].value, updTmArray, 20*(dRow + 1));

    strcpy(data[4].colName, "UPD_USR_NM");
    data[4].type = eColumnVARCHAR2;
    strcpy(data[4].bndName, ":upd_usr_nm");
    data[4].maxSize = 5;
    memcpy(data[4].value, updUsrNmArray, (5+1)*(dRow+1));

    strcpy(data[5].colName, "BRDG_SORT");
    data[5].type = eColumnINTEGER;
    strcpy(data[5].bndName, ":brdg_sort");
    data[5].maxSize = sizeof(int32);
    memcpy(data[5].value, brdgSortArray, sizeof(int32)*dRow);

    // update data to table.
    rslt = BatchUpdateCntrctBaseInfo(connId, &keyData, data, dCol, dRow);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}





TEST(CntrctBaseInfoDbTest, InsertCntrctBaseInfo) {
    char funcName[] = "InsertCntrctBaseInfo";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;

    CntrctBaseInfo data;
    memset(&data, 0, sizeof(CntrctBaseInfo));

/////////////////////////db connection create./////////////////////////////////////
    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }
    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }
/////////////////////////db connection create./////////////////////////////////////
//ResCodeT InsertCntrctBaseInfo(int32 connId, CntrctBaseInfo* pData, int32 pDataNum);

    // data set.
    data.cntrctSrno = 99999;
    strcpy(data.cntrctNm, "test999 ");
    strcpy(data.cntrctTp, "A_type");
    strcpy(data.mktId, "A_mkid");
    strcpy(data.shrtCntrctNm, "shibor_test");
    strcpy(data.lngCntrctNm, "shibor_test");
    data.shrtAmntRatio = 199.01;
    data.lngAmntRatio = 199.11;
    data.maxAmntPerDl = 199;
    data.minAmntPerDl = 1;
    data.dlUnit = 1;
    strcpy(data.dlPrcUnit, "10");
    data.term = 4;
    strcpy(data.st, "1");
    strcpy(data.crtTm, "2017-07-13 09:58:59");
    strcpy(data.crtUsrNm, "zhaoys");
    strcpy(data.updTm, "2017-07-13 09:58:59");
    strcpy(data.updUsrNm, "zhaoys");
    strcpy(data.termStrng, "4Y");
    data.brdgSort = 99999;

    // insert data to table.
    rslt = InsertCntrctBaseInfo(connId, &data);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}



TEST(CntrctBaseInfoDbTest, DeleteCntrctBaseInfo) {
    char funcName[] = "DeleteCntrctBaseInfo";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;
    int32 srno = 199;

    CntrctBaseInfoColumn keyData;
    memset(&keyData, 0, sizeof(CntrctBaseInfoColumn));

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

//ResCodeT DeleteCntrctBaseInfo(int32 connId,CntrctBaseInfoColumn* pKeyData);

    // keydata.
    strcpy(keyData.colName, "CNTRCT_SRNO");
    keyData.type = eColumnINTEGER;
    strcpy(keyData.bndName, ":cntrct_srno");
    memcpy(keyData.value, &srno, sizeof(int32));


    rslt = DeleteCntrctBaseInfo(connId, &keyData);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}


TEST(CntrctBaseInfoDbTest, UpdateCntrctBaseInfo) {
    char funcName[] = "UpdateCntrctBaseInfo";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;
    CntrctBaseInfoColumn keyData;
    CntrctBaseInfoColumn recData[3];
    int32 idValue = 199;
    double ratioValue = 199.24;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    memset(&keyData, 0, sizeof(CntrctBaseInfoColumn));
    memset(recData, 0, sizeof(recData));

    // keydata.
    strcpy(keyData.colName, "CNTRCT_SRNO");
    keyData.type = eColumnINTEGER;
    strcpy(keyData.bndName, ":cntrct_srno");
    memcpy(keyData.value, &idValue, sizeof(int32));

    // updatedata.
    strcpy(recData[0].colName, "SHRT_CNTRCT_NM");
    recData[0].type = eColumnVARCHAR2;
    strcpy(recData[0].bndName, ":shrt_cntrct_nm"); 
    memcpy(recData[0].value, "test_nm_01", sizeof(char)*11);

    strcpy(recData[1].colName, "SHRT_AMNT_RATIO");
    recData[1].type = eColumnDOUBLE;
    strcpy(recData[1].bndName, ":shrt_amnt_ratio"); 
    memcpy(recData[1].value, &ratioValue, sizeof(double));

    strcpy(recData[2].colName, "CRT_TM");
    recData[2].type = eColumnTIMESTAMP;
    strcpy(recData[2].bndName, ":crt_tm"); 
    memcpy(recData[2].value, "2017-07-20 15:52:53", sizeof(char)*20);

    rslt = UpdateCntrctBaseInfo(connId, &keyData, recData, 3);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}


TEST(CntrctBaseInfoDbTest, FetchNextCntrctBaseInfo) {
    char funcName[] = "FetchNextCntrctBaseInfo";
    ResCodeT rslt = NO_ERR;
    CntrctBaseInfo recData;
    int32 connId = 0;
    int32 cntRec = 0;
    int32 count = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    rslt = GetResultCntOfCntrctBaseInfo(connId, &cntRec);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):get record count failed.\n", funcName);
        return ;
    }

    memset(&recData, 0, sizeof(CntrctBaseInfo));
    while (FetchNextCntrctBaseInfo(connId, &recData) == NO_ERR){
        TRACE("record[%d]:cntrct_srno=%d, cntrct_nm=%s, cntrct_tp=%s, mkt_id=%s, shrt_cntrct_nm=%s, lng_cntrct_nm=%s, shrt_amnt_ratio=%.2f, lng_amnt_ratio=%.2f, max_amnt_per_dl=%d,  min_amnt_per_dl=%d, dl_unit=%d, dl_prc_unit=%s, term=%d, st=%s, crt_tm =%s, crt_usr_nm=%s, upd_tm=%s, upd_usr_nm=%s.\n",
            count,
            recData.cntrctSrno,
            recData.cntrctNm,
            recData.cntrctTp,
            recData.mktId,
            recData.shrtCntrctNm,
            recData.lngCntrctNm,
            recData.shrtAmntRatio,
            recData.lngAmntRatio,
            recData.maxAmntPerDl,
            recData.minAmntPerDl,
            recData.dlUnit,
            recData.dlPrcUnit,
            recData.term,
            recData.st,
            recData.crtTm,
            recData.crtUsrNm,
            recData.updTm,
            recData.updUsrNm);
        count++;
        memset(&recData, 0, sizeof(CntrctBaseInfo));
    }

    EXPECT_EQ(count, cntRec);

    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}



TEST(sqlOciTest, DeleteAll_Testoci) {
    char funcName[] = "DeleteAll_Testoci";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    rslt = DeleteAllTEST_OCI(connId);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}



TEST(sqlOciTest, Delete_Testoci) {
    char funcName[] = "Delete_Testoci";
    ResCodeT rslt = NO_ERR;
    int32 connId = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    rslt = DeleteTEST_OCI(connId, 10);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}



TEST(sqlOciTest, Insert_Testoci) {
    char funcName[] = "Insert_Testoci";
    ResCodeT rslt = NO_ERR;
    Testoci recData;
    int32 connId = 0;
    int32 count = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    memset(&recData, 0, sizeof(Testoci));
    recData.id = 50;
    strcpy(recData.lastname, "lastname50");
    strcpy(recData.firstname, "firstname50");
    strcpy(recData.address, "address50");
    recData.codeline = 50.01;
    recData.coverage = 50.02;
    recData.seqno = 50;
    strcpy(recData.update_date, "2017-07-20");
    strcpy(recData.update_time, "2017-07-20 15:52:53");

    rslt = InsertTEST_OCI(connId, &recData, 1);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCommit(connId);
    EXPECT_EQ(NO_ERR, rslt);
    
    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);


}


TEST(sqlOciTest, FetchNextCNTRCT_BASE_INFO) {
    char funcName[] = "FetchNextCNTRCT_BASE_INFO";
    ResCodeT rslt = NO_ERR;
    CNTRCT_BASE_INFO recData;
    int32 connId = 0;
    int32 count = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    memset(&recData, 0, sizeof(CNTRCT_BASE_INFO));
    while (FetchNextCNTRCT_BASE_INFO(connId, &recData) == NO_ERR){
        TRACE("record[%d]:cntrct_srno=%d, cntrct_nm=%s, cntrct_tp=%s, mkt_id=%s, shrt_cntrct_nm=%s, lng_cntrct_nm=%s, shrt_amnt_ratio=%.2f, lng_amnt_ratio=%.2f, max_amnt_per_dl=%d,  min_amnt_per_dl=%d, dl_unit=%d, dl_prc_unit=%s, term=%d, st=%s, crt_tm =%s, crt_usr_nm=%s, upd_tm=%s, upd_usr_nm=%s.\n",
            count,
            recData.cntrct_srno,
            recData.cntrct_nm,
            recData.cntrct_tp,
            recData.mkt_id,
            recData.shrt_cntrct_nm,
            recData.lng_cntrct_nm,
            recData.shrt_amnt_ratio,
            recData.lng_amnt_ratio,
            recData.max_amnt_per_dl,
            recData.min_amnt_per_dl,
            recData.dl_unit,
            recData.dl_prc_unit,
            recData.term,
            recData.st,
            recData.crt_tm,
            recData.crt_usr_nm,
            recData.upd_tm,
            recData.upd_usr_nm);
        count++;
        memset(&recData, 0, sizeof(CNTRCT_BASE_INFO));
    }

    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}


TEST(sqlOciTest, FetchNextTEST_OCI) {
    char funcName[] = "FetchNextTEST_OCI";
    ResCodeT rslt = NO_ERR;
    TEST_OCI recData;
    int32 connId = 0;
    int32 count = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    memset(&recData, 0, sizeof(TEST_OCI));
    while (FetchNextTEST_OCI(connId, &recData) == NO_ERR){
        TRACE("record[%d]:ID=%d, LASTNAME=%s, FIRSTNAME=%s, ADDRESS=%s, CODELINE=%.2lf, COVERAGE=%.2f, SEQNO=%d, UPDATE_DATE=%s, UPDATE_TIME=%s.\n", 
            count,
            recData.id,
            recData.lastname,
            recData.firstname,
            recData.address,
            recData.codeline,
            recData.coverage,
            recData.seqno,
            recData.update_date,
            recData.update_time);
        count++;
        memset(&recData, 0, sizeof(TEST_OCI));
    }

    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}



TEST(sqlOciTest, GetResultCntOfTEST_OCI) {
    char funcName[] = "GetResultCntOfTEST_OCI";

    ResCodeT rslt = NO_ERR;
    int32 connId = 0;
    int32 resCnt = 0;

    // environment initialize.
    if (DbCmmnInit() != NO_ERR){
        TRACE("[ERROR](%s):Common Init failed.\n", funcName);
        return ;
    }

    rslt = DbCmmnConnect(dbAddress, username, password, &connId);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Connect to database is failed.\n", funcName);
        return ;
    }

    rslt = GetResultCntOfTEST_OCI(connId, &resCnt);
    if (rslt != NO_ERR){
        TRACE("[ERROR](%s):Select TEST_OCI to get record is failed.\n", funcName);
        return ;
    }
    
    EXPECT_EQ(resCnt, 10);
    EXPECT_EQ(NO_ERR, rslt);

    rslt = DbCmmnDisConnect(connId);
    EXPECT_EQ(NO_ERR, rslt);
    rslt = DbCmmnCleanup();
    EXPECT_EQ(NO_ERR, rslt);

}
#endif // passed.

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////Function Test Ending////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

// Function Test End.

// Step 3. Call RUN_ALL_TESTS() in main().
//
// We do this by linking in src/gtest_main.cc file, which consists of
// a main() function which calls RUN_ALL_TESTS() for us.
//
// This runs all the tests you've defined, prints the result, and
// returns 0 if successful, or 1 otherwise.
//
// Did you notice that we didn't register the tests?  The
// macro magically knows about all the tests we
// defined.  Isn't this convenient?

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

