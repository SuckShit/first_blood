﻿/***
Created on Aug 3, 2017
@author: Jiawang.Xie
@version $Id
***/

#include "gtest/gtest.h"
#include "cfg_lib.h"
#include "uti_tool.h"
#include "db_comm.h"

#include "intrnl_msg.h"
#include "login.h"
#include "../../app/HPMTS/service/user_login.h"

#include "ref_data.h"
#include "active_info.h"
#include "active_keeper.h"

#include "base_param_api.h"
#include "pck_irs_dicdata.h"

using ::testing::InitGoogleTest;


static int32        gConnId             = DB_INVALID_CONN_ID;
static const int32  gTimeLen            = 30;
//static const char   C_FORMAT_TIME[]     = "%Y%m%d-%H:%M:%S"; //年月日时分秒 "YYYYMMDD-HH24:MI:SS"


class RemoveUserCommonTest : public testing::Test
{
protected:  // You should make the members protected s.t. they can be

    virtual void SetUp()
    {
        LogInit((char*)"");
    }

    virtual void TearDown()
    {
    }

    static void SetUpTestCase()
    {
        ResCodeT rc = NO_ERR;

        char appName[] = "";
        PrcsInit(appName);

        struct cfgValueS cfgValue = {0};

        /* Get config value for the system  */
        rc = GetCfgValue(&cfgValue);
        ASSERT_EQ(rc, NO_ERR);

        rc = DbCmmnInit();
        ASSERT_EQ(rc, NO_ERR);

        rc = DbCmmnConnect((char*)cfgValue.dbInst, (char*)cfgValue.dbName, (char*)cfgValue.dbPwd, &gConnId);
        ASSERT_EQ(rc, NO_ERR);
    }


    static void TearDownTestCase()
    {
        ResCodeT rc = NO_ERR;

        rc = DbCmmnCleanup();
        ASSERT_EQ(rc, NO_ERR);
    }

};

//static RsltCol gResColSelect[] =
//{
////    colId   colName         bndName         colType     maxSize dataRow pDataValue
//    {1,     "ORG_ID",       ":org_id",      eINTEGER,       0,      0,      0 },
//    {2,     "USR_LGN_NM",   ":usr_lgn_nm",  eVARCHAR2,      0,      0,      0 },
//};
//static int32 gColCntSel = sizeof(gResColSelect)/sizeof(gResColSelect[0]);
//
//ResCodeT SelectFreezeInfo(int32 connId, char* strRemoveId, char* sUpdateTime, int32* count, FreezeInfoT* freezeInfo)
//{
//    ResCodeT    rc = NO_ERR;
//
//    int32       iSelId = 0;
//    char        sql[1024];
//    RsltCol     resCol;
//    int32       resNum;
//
//
//    // 1. do select count
//    memset(sql, 0, sizeof(sql));
//    sprintf(sql, "SELECT count(*) FROM USR A RIGHT JOIN USR_ONLN B ON A.USR_LGN_NM = B.USR_NM WHERE B.LGN_TP IN (3, 4) AND ORG_ID IN (SELECT ORG_ID FROM ORG_INFO WHERE CRDT_OPRTR = '%s' AND CRDT_OPRTNG_ST = '0') ", strRemoveId);
//
//    rc = DbCmmnSqlSelect(connId, sql, &iSelId);
//    if (rc != NO_ERR) {
//        TRACE("Failed to execute sql select.");
//        return rc;
//    }
//
//    // 2. get the count
//    resNum = 1;
//    memset(&resCol, 0, sizeof(RsltCol));
//    resCol.colId = 1;
//    resCol.colType = eINTEGER;
//    resCol.pDataValue = count;
//
//    rc = DbCmmnSqlFetchNext(connId, iSelId, &resCol, &resNum);
//    if (rc != NO_ERR) {
//        TRACE("failed to fetch first result");
//        return rc;
//    }
//
//
//    // 3. do select
//    if (*count > 0)
//    {
//        memset(sql, 0, sizeof(sql));
//        sprintf(sql, "SELECT A.ORG_ID, A.USR_LGN_NM FROM USR A RIGHT JOIN USR_ONLN B ON A.USR_LGN_NM = B.USR_NM WHERE B.LGN_TP IN (3, 4) AND ORG_ID IN (SELECT ORG_ID FROM ORG_INFO WHERE CRDT_OPRTR = '%s' AND CRDT_OPRTNG_ST = '0') ORDER BY ORG_ID ", strRemoveId);
//
//        rc = DbCmmnSqlSelect(connId, sql, &iSelId);
//        if (rc != NO_ERR) {
//            TRACE("Failed to execute sql select.");
//            return rc;
//        }
//
//        // 4. get the result
//        for (int i = 0; i < *count; i++)
//        {
//            gResColSelect[0].pDataValue = &freezeInfo[i].orgId;
//            gResColSelect[1].pDataValue = freezeInfo[i].usrLgnNm;
//
//            rc = DbCmmnSqlFetchNext(connId, iSelId, gResColSelect, &gColCntSel);
//            if (rc != NO_ERR)
//            {
//                TRACE("Failed to execute sql select.");
//                return rc;
//            }
//
//            strcpy(freezeInfo[i].crdtMdffnsh, "授信/风险系数修改完毕！");
//            strcpy(freezeInfo[i].currentTime, sUpdateTime);
//
//            LOG_INFO("------------- freeze info [%d] -------------", i);
//            LOG_INFO("    orgId = %d                         ", freezeInfo[i].orgId);
//            LOG_INFO("    usrLgnNm = %s                     ", freezeInfo[i].usrLgnNm);
//            LOG_INFO("    crdtMdffnsh = %s  ", freezeInfo[i].crdtMdffnsh);
//            LOG_INFO("    currentTime = %s        ", freezeInfo[i].currentTime);
//        }
//        LOG_INFO("-------------------------------------------");
//    }
//
//    return rc;
//}
//
//
///******************************************************************************
// **
// ** Test case : remove online user
// **
// ******************************************************************************/
//TEST_F(RemoveUserCommonTest, RemoveUser)
//{
//    ResCodeT rc = NO_ERR;
//
//    RemoveUserRespT  removeResp;
//    char strUserId[] = "hanxzb3";
//    int32   count;
//
//    memset(&removeResp.sFreezeInfo, 0, sizeof(FreezeInfoT)*(MAX_FREEZE_INFO_NUM));
//
//    char sUpdateTime[gTimeLen];
//    rc = GetCurrentTime(sUpdateTime);
//    ASSERT_EQ(rc, NO_ERR);
//
//    // 2. 获取冻结用户信息  SP_OT_CURSOR
//    rc = SelectFreezeInfo(gConnId, strUserId, sUpdateTime, &count, removeResp.sFreezeInfo);
//    ASSERT_EQ(rc, NO_ERR);
//}
//
//
//#if 1
//
///******************************************************************************
// **
// ** Test case : active keeper
// **
// ******************************************************************************/
//TEST_F(RemoveUserCommonTest, ActiveKeeper)
//{
//    ResCodeT rc = NO_ERR;
//
//    char    host[MAX_HOST_LEN];
//    int64   setId = 1;
//
//    //============================== init test ==============================
//
//    // 1. load data from database
//    /* Load the active info */
//    rc = ActiveInfoLoadFromDB(gConnId);
//    ASSERT_EQ(rc, NO_ERR);
//
//    // 2. active keeper initialize
//    rc = ActiveKeeperInitWithoutConn();
//    ASSERT_EQ(rc, NO_ERR);
//
//    rc = InitPrimary(setId, "host11");
//    ASSERT_EQ(rc, NO_ERR);
//
//    //============================== get test ==============================
//    memset(host, 0, sizeof(host));
//    rc = GetPrimary(1, host);
//    ASSERT_EQ(rc, NO_ERR);
//    printf("    primary 1 = %s\n", host);
//
//    memset(host, 0, sizeof(host));
//    rc = GetBackup(2, host);
//    ASSERT_EQ(rc, NO_ERR);
//    printf("    backup 2 = %s\n", host);
//
//    //============================== get all active info test ==============================
//
//    vectorT     setIds[GET_BIT_VECT_LEN(MAX_SET_CNT)];
//    memset(setIds, 0, sizeof(setIds));
//    rc = GetAllSetIds(setIds);
//    ASSERT_EQ(rc, NO_ERR);
//    printf("    setIds = %d\n", setIds[0]);
//
//    vectorT*    pSetIds;
//    rc = GetAllSetIdsPtr(&pSetIds);
//    ASSERT_EQ(rc, NO_ERR);
//    printf("    pSetIds = %d\n", *pSetIds);
//
//    pActiveInfoT    pInfos;
//    rc = GetAllActiveInfoPtr(&pInfos);
//    ASSERT_EQ(rc, NO_ERR);
//
//
//    for (int i = 1; i <= 3; i++)
//    {
//        printf("    set_id=[ %d ] primary= %s , backup = %s , begin_time = %s .\n", pInfos[i].setId, pInfos[i].primaryHost, pInfos[i].backupHost, pInfos[i].haTime);
//    }
//
//    //============================== stop test ==============================
//
//    rc = ActiveKeeperStop();
//    ASSERT_EQ(rc, NO_ERR);
//
//}
//
//#else
//
///******************************************************************************
// **
// ** Test case : active keeper
// **
// ******************************************************************************/
//TEST_F(RemoveUserCommonTest, ActiveKeeperTackover)
//{
//    ResCodeT rc = NO_ERR;
//
//    char    host[MAX_HOST_LEN];
//    int64   setId = 1;
//
//    //============================== init test ==============================
//
//    // 1. load data from database
//    /* Load the active info */
//    rc = ActiveInfoLoadFromDB(gConnId);
//    ASSERT_EQ(rc, NO_ERR);
//
//    // 2. active keeper initialize
////    rc = ActiveKeeperInit(gConnId);
//    rc = ActiveKeeperInitWithoutConn();
//    ASSERT_EQ(rc, NO_ERR);
//
//    rc = InitBackup(setId, "host12");
//    ASSERT_EQ(rc, NO_ERR);
//
//    //============================== tackover test ==============================
//
//    BOOL blTackover = FALSE;
//    rc = BackupTakeover(1, "host12", &blTackover);
//    ASSERT_EQ(rc, NO_ERR);
//    printf("    blTackover 1 = %d\n", blTackover);
//
//    //============================== stop test ==============================
//
//    rc = ActiveKeeperStop();
//    ASSERT_EQ(rc, NO_ERR);
//
//}
//
//#endif


/******************************************************************************
 **
 ** Test case : base param api time
 **
 ******************************************************************************/
TEST_F(RemoveUserCommonTest, CheckBaseParamApiTime)
{
    ResCodeT rc = NO_ERR;
    int64   timestamp = 0;
    int64 iStartTime, iEndTime;



    rc = BaseParamApiLoadFromDB(gConnId);
    ASSERT_EQ(rc, NO_ERR);



    pBaseParamApiT pParamApiData;
    char strStartTime[MAX_TIME_LEN];
    char strEndTime[MAX_TIME_LEN];
    char strCurrTime[MAX_TIME_LEN];

    rc = GetCurrentTime(strCurrTime);
    ASSERT_EQ(rc, NO_ERR);
    strncpy(strStartTime, strCurrTime, 9);
    strncpy(strEndTime, strCurrTime, 9);


    // temporary to set the current timestamp
    rc = DateTimeToTimestamp(strCurrTime, &timestamp);
    ASSERT_EQ(rc, NO_ERR);


    rc = BaseParamApiGetByNameExt((char*)C_API_CRDT_TIME_START, &pParamApiData);
    ASSERT_EQ(rc, NO_ERR);
    strcat(strStartTime, pParamApiData->paramValue);
    strcat(strStartTime, ":00");

    rc = BaseParamApiGetByNameExt((char*)C_API_CRDT_TIME_END, &pParamApiData);
    ASSERT_EQ(rc, NO_ERR);
    strcat(strEndTime, pParamApiData->paramValue);
    strcat(strEndTime, ":00");

    rc = DateTimeToTimestamp(strStartTime, &iStartTime);
    ASSERT_EQ(rc, NO_ERR);
    rc = DateTimeToTimestamp(strEndTime, &iEndTime);
    ASSERT_EQ(rc, NO_ERR);

    ASSERT_FALSE(iStartTime > timestamp || iEndTime < timestamp);
//    if (iStartTime > timestamp || iEndTime < timestamp)
//    {
//        printf("APIERR_CODE_INVLD_CRDT_MDFY_TM \n");
//        RAISE_ERR(APIERR_CODE_INVLD_CRDT_MDFY_TM, RTN);
//    }


    rc = BaseParamApiDetachFromShm();
    ASSERT_EQ(rc, NO_ERR);

}


int main(int argc, char **argv)
{
    InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}
