/***
Created on sometimes
@author: No One
@version $ID
***/


/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "../../common/ref_data/include/usr.h"
#include "UsrDb.h"
#include "CntrctBaseInfoDb.h"
#include "shm.h"
#include "gtest/gtest.h"
#include "cfg_lib.h"
#include "uti_tool.h"
#include "org_info.h"
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/


/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
int32 connId = 0;
cfgValueS cfgValue = {0};

/***********************************************************************************************
**
**   Functiona Declaration                                                                           
**
************************************************************************************************/


/***********************************************************************************************
**
**   Functiona Implementation                                                                           
**
************************************************************************************************/
using ::testing::InitGoogleTest; 


//class UsrTest : public testing::Test {
////protected:
//    // You should make the members protected s.t. they can be
//    // accessed from sub-classes.
//
//    // virtual void SetUp() will be called before each test is run.  You
//    // should define it if you need to initialize the varaibles.
//    // Otherwise, this can be skipped.
//    virtual void SetUp() {}
//
//    // virtual void TearDown() will be called after each test is run.
//    // You should define it if there is cleanup work to do.  Otherwise,
//    // you don't have to provide it.
//    //
//    virtual void TearDown() {}
//    
//    static void SetUpTestCase() 
//    {
//        ResCodeT rc = NO_ERR;
//
//    }
//
//    static void TearDownTestCase() {
//
//    }   
//};

class UsrTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // TRACE("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // TRACE("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
        ResCodeT rc = NO_ERR;

        char prcsName[] = "";
        PrcsInit(prcsName); 
        
        rc = GetCfgValue(&cfgValue);
        EXPECT_EQ(rc,NO_ERR);
        
        rc = DbCmmnInit();
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }

        rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }
        
        rc = OrgInfoLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);
        
        rc = BrdgOrgInfoLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);
        
    }
        
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        rc = DbCmmnDisconnect(connId);
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }
        rc = DbCmmnCleanup();
        if (rc != NO_ERR){
            EXPECT_EQ(rc, NO_ERR);
            return ;
        }
        rc = OrgInfoDetachFromShm();
        EXPECT_EQ(rc, NO_ERR);
    }
};

TEST_F(UsrTest, UsrInfoLoad)
{
    ResCodeT rc = NO_ERR;
    
    char prcsName[] = "";
    PrcsInit(prcsName); 
    
    rc = GetCfgValue(&cfgValue);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = OrgInfoAttachToShm();
    EXPECT_EQ(rc,NO_ERR);

    
	int32 temp = 0;
	Usr usrInfo1, usrInfo2, usrInfo3;
	
	
    
    //rc = CfgInit(cgv);
    //EXPECT_EQ(rc,NO_ERR);
    
	
	memset(&usrInfo1, 0, sizeof(Usr));
	memset(&usrInfo2, 0, sizeof(Usr));
	memset(&usrInfo3, 0, sizeof(Usr));
	
	usrInfo1.usrSrno = 41040;
	strcpy(usrInfo1.usrLgnNm, "nanjin123456");
	usrInfo1.orgId = 889;
	strcpy(usrInfo1.nmDesc, "nanjin123456");
	strcpy(usrInfo1.usrSt, "1");	
	strcpy(usrInfo1.pswd, "123");
	strcpy(usrInfo1.pswdTm, "2017-07-12");
	usrInfo1.pswdErCnt = 1;
	strcpy(usrInfo1.crtTm, "2017-07-12");
	strcpy(usrInfo1.crtUsrNm, "nanjin123456");
	strcpy(usrInfo1.updTm, "2017-07-12");
	strcpy(usrInfo1.updUsrNm, "nanjin123456");
	strcpy(usrInfo1.sysSrc, "123");
	strcpy(usrInfo1.tel, "123");
	strcpy(usrInfo1.faxNo, "123");
	strcpy(usrInfo1.apiF, "1");
	strcpy(usrInfo1.ordrPrvlgF, "1");
	strcpy(usrInfo1.ordrPrvlgMdfyF, "1");
	strcpy(usrInfo1.ordrPrvlgFSirs, "1");
	strcpy(usrInfo1.ordrPrvlgMdfyFSirs, "1");
	strcpy(usrInfo1.ordrPrvlgFSbfccp, "1");
	strcpy(usrInfo1.ordrPrvlgMdfyFSbfccp, "1");

//	usrInfo2.usrSrno = 30001;
//	strcpy(usrInfo2.usrLgnNm, "usr6");
//	usrInfo2.orgId = 2;
//	strcpy(usrInfo2.nmDesc, "usr6");
//	strcpy(usrInfo2.usrSt, "1");	
//	strcpy(usrInfo2.pswd, "123");
//	strcpy(usrInfo2.pswdTm, "2017-07-12");
//	usrInfo2.pswdErCnt = 1;
//	strcpy(usrInfo2.crtTm, "2017-07-12");
//	strcpy(usrInfo2.crtUsrNm, "usr6");
//	strcpy(usrInfo2.updTm, "2017-07-12");
//	strcpy(usrInfo2.updUsrNm, "usr6");
//	strcpy(usrInfo2.sysSrc, "usr6");
//	strcpy(usrInfo2.tel, "123");
//	strcpy(usrInfo2.faxNo, "123");
//	strcpy(usrInfo2.apiF, "1");
//	strcpy(usrInfo2.ordrPrvlgF, "1");
//	strcpy(usrInfo2.ordrPrvlgMdfyF, "1");
//	strcpy(usrInfo2.ordrPrvlgFSirs, "1");
//	strcpy(usrInfo2.ordrPrvlgMdfyFSirs, "1");
//	strcpy(usrInfo2.ordrPrvlgFSbfccp, "1");
//	strcpy(usrInfo2.ordrPrvlgMdfyFSbfccp, "1");
//
//	usrInfo3.usrSrno = 30002;
//	strcpy(usrInfo3.usrLgnNm, "usr7");
//	usrInfo3.orgId = 3;
//	strcpy(usrInfo3.nmDesc, "usr7");
//	strcpy(usrInfo3.usrSt, "1");	
//	strcpy(usrInfo3.pswd, "123");
//	strcpy(usrInfo3.pswdTm, "2017-07-12");
//	usrInfo3.pswdErCnt = 1;
//	strcpy(usrInfo3.crtTm, "2017-07-12");
//	strcpy(usrInfo3.crtUsrNm, "usr7");
//	strcpy(usrInfo3.updTm, "2017-07-12");
//	strcpy(usrInfo3.updUsrNm, "usr7");
//	strcpy(usrInfo3.sysSrc, "usr7");
//	strcpy(usrInfo3.tel, "123");
//	strcpy(usrInfo3.faxNo, "123");
//	strcpy(usrInfo3.apiF, "1");
//	strcpy(usrInfo3.ordrPrvlgF, "1");
//	strcpy(usrInfo3.ordrPrvlgMdfyF, "1");
//	strcpy(usrInfo3.ordrPrvlgFSirs, "1");
//	strcpy(usrInfo3.ordrPrvlgMdfyFSirs, "1");
//	strcpy(usrInfo3.ordrPrvlgFSbfccp, "1");
//	strcpy(usrInfo3.ordrPrvlgMdfyFSbfccp, "1");
//
//	rc = InsertUsr(connId, &usrInfo2);
//    EXPECT_EQ(rc,NO_ERR);
//	rc = InsertUsr(connId, &usrInfo3);
//    EXPECT_EQ(rc,NO_ERR);

    rc = InsertUsr(connId, &usrInfo1);
    EXPECT_EQ(rc,NO_ERR);
    
	rc = DbCmmnCommit(connId);
	EXPECT_EQ(rc, NO_ERR);

	rc = IrsUsrInfoLoadFromDb(connId);
    EXPECT_EQ(rc,NO_ERR);

}

TEST_F(UsrTest, UsrInfoDelete)
{
	UsrKey DeleteSrno;
    ResCodeT rc = NO_ERR;

	rc = IrsUsrInfoDetachFromShm();
	EXPECT_EQ(rc, NO_ERR);

	DeleteSrno.usrSrno = 41040;
	rc = DeleteUsr(connId, &DeleteSrno);
    EXPECT_EQ(rc,NO_ERR);
	rc = DbCmmnCommit(connId);
    EXPECT_EQ(rc,NO_ERR);
	ShmDelete((char*)SHM_IRS_USR_NAME);
}

TEST_F(UsrTest, getByName)
{
#if 1
	UsrBaseInfoT FetchData;
	UsrBaseInfoT FetchPosData;
	int32 roleId = 0;
	ResCodeT rc = NO_ERR;
	BOOL isExist = FALSE, status = FALSE;
#if 0
	DbCmmnInit();
	
    
	rc = IrsUsrInfoLoadFromDb(connId);
    EXPECT_EQ(rc,NO_ERR);

#endif

	memset(&FetchData, 0, sizeof(UsrBaseInfoT));

	rc = IrsUsrInfoGetByName((char*)"yexin", &FetchData);
    EXPECT_EQ(rc,NO_ERR);
	EXPECT_EQ(FetchData.usrOnlnStatus,FALSE);
    //rc = IrsUsrMktStatusGet("0003", 1, &status);
	//EXPECT_EQ(rc,NO_ERR);
	//EXPECT_EQ(status, FALSE);
	rc = IrsUsrInfoGetByName((char*)"acc5", &FetchData);
    EXPECT_EQ(rc,NO_ERR);
	EXPECT_EQ(FetchData.usrOnlnStatus,TRUE);
	//rc = IrsUsrMktStatusGet("0008", 1, &status);
	//EXPECT_EQ(rc,NO_ERR);
	//EXPECT_EQ(status, TRUE);
	//EXPECT_EQ(FetchData.roleId, 2);

	//memset(&FetchPosData, 0, sizeof(UsrBaseInfoT));
	//rc = IrsUsrInfoGetByPos(FetchData.pos, &FetchPosData);
	//EXPECT_EQ(strcmp(FetchPosData.usrLgnNm, "wangzhou1"), 0);
	
	//rc = IrsUsrInfoGetByName((char*)"nanjing3", &FetchData);
    //EXPECT_EQ(rc,NO_ERR);
    //EXPECT_EQ(FetchData.roleId,2);
	
#endif

}


int main(int argc, char **argv)
{
    InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

