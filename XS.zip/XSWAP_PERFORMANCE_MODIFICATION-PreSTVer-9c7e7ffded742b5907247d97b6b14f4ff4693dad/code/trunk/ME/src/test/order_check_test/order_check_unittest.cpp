﻿/***
Created on Aug 15, 2017
@author: longyun.hao
@version $Id
***/
// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)


// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include <limits.h>
#include <pthread.h>          
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>

#include "shm.h"
#include "dbcomm.h"
#include "common_macro.h"
#include "gtest/gtest.h"
#include "contract_info.h"
#include "user_order.h"
#include "contract_info.h"
#include "CntrctBaseInfoDb.h"
#include "uti_tool.h"
#include "usr.h"
#include "UsrDb.h"
#include "order_book.h"

#include "org_info.h"
#include "base_param.h"
#include "order_check.h"
#include "pck_irs_dicdata.h"
#include "cfg_lib.h"


// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.
using ::testing::InitGoogleTest; 

int32 connId;

class ordCheckTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // printf("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // printf("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
        ResCodeT rc = NO_ERR;
        int32 dataNum = 1;
    	Usr usrInfo;
        CntrctBaseInfo testDataCntrct;
        cfgValueS cfgValue = {0};

        DbCmmnInit();
        
        char prcsName[] = "";
        PrcsInit(prcsName); 
      
        rc = GetCfgValue(&cfgValue);
        EXPECT_EQ(rc,NO_ERR);
      
        rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        RAISE_ERR(rc, RTN);

        /****************************************************/
        // insert the test data into table CNTRCT
        memset(&testDataCntrct, 0x00, sizeof(CntrctBaseInfo));
        testDataCntrct.cntrctSrno = 99999;
        strcpy(testDataCntrct.cntrctNm, "IRS_CONTRACT_UNIT_TEST");
        strcpy(testDataCntrct.cntrctTp, "0");
        strcpy(testDataCntrct.mktId, "2");
        strcpy(testDataCntrct.shrtCntrctNm, "SHORT_NAME");
        strcpy(testDataCntrct.lngCntrctNm, "LONG_NAME");
        testDataCntrct.shrtAmntRatio = 1.2345;
        testDataCntrct.lngAmntRatio = 2.3456;
        testDataCntrct.maxAmntPerDl = 999;
        testDataCntrct.minAmntPerDl = 9;
        testDataCntrct.dlUnit = 666;
        strcpy(testDataCntrct.dlPrcUnit, "1");
        testDataCntrct.term = 12;
        strcpy(testDataCntrct.st, "2");
        strcpy(testDataCntrct.crtTm, "2017-07-12");
        strcpy(testDataCntrct.crtUsrNm, "TEST");
        strcpy(testDataCntrct.updTm, "2017-07-12");
        strcpy(testDataCntrct.updUsrNm, "UT");
        strcpy(testDataCntrct.termStrng, "1Y");
        testDataCntrct.brdgSort = 112;
        
        rc = InsertCntrctBaseInfo(connId, &testDataCntrct);
        EXPECT_EQ(rc, NO_ERR);


    	memset(&usrInfo, 0, sizeof(Usr));

    	usrInfo.usrSrno = 99999;
    	strcpy(usrInfo.usrLgnNm, "nanjin123456");
    	usrInfo.orgId = 1;
    	strcpy(usrInfo.nmDesc, "nanjin123456");
    	strcpy(usrInfo.usrSt, "1");	
    	strcpy(usrInfo.pswd, "123");
    	strcpy(usrInfo.pswdTm, "2017-07-12");
    	usrInfo.pswdErCnt = 1;
    	strcpy(usrInfo.crtTm, "2017-07-12");
    	strcpy(usrInfo.crtUsrNm, "nanjin123456");
    	strcpy(usrInfo.updTm, "2017-07-12");
    	strcpy(usrInfo.updUsrNm, "nanjin123456");
    	strcpy(usrInfo.sysSrc, "123");
    	strcpy(usrInfo.tel, "123");
    	strcpy(usrInfo.faxNo, "123");
    	strcpy(usrInfo.apiF, "1");
    	strcpy(usrInfo.ordrPrvlgF, "1");
    	strcpy(usrInfo.ordrPrvlgMdfyF, "1");
    	strcpy(usrInfo.ordrPrvlgFSirs, "1");
    	strcpy(usrInfo.ordrPrvlgMdfyFSirs, "1");
    	strcpy(usrInfo.ordrPrvlgFSbfccp, "1");
    	strcpy(usrInfo.ordrPrvlgMdfyFSbfccp, "1");

	    rc = InsertUsr(connId, &usrInfo);
        EXPECT_EQ(rc,NO_ERR);



        DbCmmnCommit(connId);

        rc = IrsCntrctInfoLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);

    	rc = IrsUsrInfoLoadFromDb(connId);
        EXPECT_EQ(rc,NO_ERR);
        
        rc = OrgInfoLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);

        rc = BaseParamLoadFromDB(connId);
        EXPECT_EQ(rc, NO_ERR);
    }
    
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        CntrctBaseInfoKey keyInfo;
	    UsrKey DeleteSrno = {0};

        rc = IrsCntrctInfoDetachFromShm();
        EXPECT_EQ(rc, NO_ERR);
        
        // delete the test data added in the setup method.
        memset(&keyInfo, 0x00, sizeof(CntrctBaseInfoKey));
        keyInfo.cntrctSrno = 99999;
        
        DeleteCntrctBaseInfo(connId, &keyInfo);

	    DeleteSrno.usrSrno = 99999;
	    DeleteUsr(connId, &DeleteSrno);

        DbCmmnCommit(connId);
        
        DbCmmnDisConnect(connId);
        DbCmmnCleanup();
        ShmDelete((char*)SHM_IRS_CONTRACT_INFO_NAME);  
        ShmDelete((char*)SHM_BASE_PARAM_NAME);
    }   

};

// Test the method [OrderCheck]
TEST_F(ordCheckTest, OrderChk) {
    
    ResCodeT rc = NO_ERR;
    CntrctBaseInfoT testData; 
    int64 sysTimestamp = 0;

    NewOrderSingleReqT incOrdr;
    pNewOrderSingleReqT pIncOrdr = &incOrdr;

    /* get contract pos in share mem */
    rc = IrsCntrctInfoGetByName((char*)"IRS_CONTRACT_UNIT_TEST", &testData);
    EXPECT_EQ(rc, NO_ERR);

    /* get current system time */
    rc = GetSysTimestamp( &sysTimestamp );
    EXPECT_EQ(rc, RTN);

    memset( pIncOrdr, 0x00, sizeof(NewOrderSingleReqT) );

    pIncOrdr->price = 250;
    pIncOrdr->orderQty = 5000;
    pIncOrdr->contractPos = testData.pos;
    pIncOrdr->effectTime = sysTimestamp - 100;

    //set order effective time earlier than current system time.
    rc = OrderCheck( pIncOrdr );
    EXPECT_EQ(rc, ERR_CODE_INVLD_EXPIRE_TIME);

    //set order effective time later than current system time.
    pIncOrdr->effectTime = sysTimestamp + 1000000;
    rc = OrderCheck( pIncOrdr );
    EXPECT_EQ(rc, NO_ERR);

    //set order price cheaper than its min price limit.
    pIncOrdr->price = 9;
    rc = OrderCheck( pIncOrdr );
    EXPECT_EQ(rc, ERR_CODE_INVLD_ORDR_PRC);


    
  // <TechnicalDetails>
  //
  // EXPECT_EQ(expected, actual) is the same as
  //
  //   EXPECT_TRUE((expected) == (actual))
  //
  // except that it will print both the expected value and the actual
  // value when the assertion fails.  This is very helpful for
  // debugging.  Therefore in this case EXPECT_EQ is preferred.
  //
  // On the other hand, EXPECT_TRUE accepts any Boolean expression,
  // and is thus more general.
  //
  // </TechnicalDetails>
}

// Test the method [CheckUsrStatus]
TEST_F(ordCheckTest, ChkUsrStatus) {
    
    ResCodeT rc = NO_ERR;
    CntrctBaseInfoT testData; 
    int64 sysTimestamp = 0;

    pUsrBaseInfoT pUsrInfo = NULL;

    rc = CheckUsrStatus( (int32) 989898 );
    EXPECT_EQ(rc, ERR_CODE_INVLD_INVALID_USER);


    rc = IrsUsrInfoGetByNameExt( (char*)"nanjin123456", &pUsrInfo );
    EXPECT_EQ(rc, NO_ERR);

    //pUsrInfo->mktSt = TRUE;
    pUsrInfo->usrOnlnStatus = TRUE;


    //not log on
    pUsrInfo->usrOnlnStatus = FALSE;
    rc = CheckUsrStatus( pUsrInfo->pos );
    EXPECT_EQ(rc, ERR_CODE_INVLD_NOT_LOGON);

    //USR_STATUS_USING
    pUsrInfo->usrOnlnStatus = TRUE;
    strcpy( pUsrInfo->usrSt, USR_STATUS_USING );
    rc = CheckUsrStatus( pUsrInfo->pos );
    EXPECT_EQ(rc, NO_ERR);

    //USR_STATUS_LCKED
    strcpy( pUsrInfo->usrSt, USR_STATUS_LCKED );
    rc = CheckUsrStatus( pUsrInfo->pos );
    EXPECT_EQ(rc, ERR_CODE_INVLD_INVALID_USER);

    //USR_STATUS_INVLD
    strcpy( pUsrInfo->usrSt, USR_STATUS_INVLD );
    rc = CheckUsrStatus( pUsrInfo->pos );
    EXPECT_EQ(rc, ERR_CODE_INVLD_INVALID_USER);

    //MKT status
    //pUsrInfo->usrOnlnStatus = TRUE;
    //pUsrInfo->mktSt = FALSE;
    //rc = CheckUsrStatus( pUsrInfo->pos );
    //EXPECT_EQ(rc, ERR_CODE_INVLD_INVALID_USER);

}


// Test the method [CheckOrgStatus]
TEST_F(ordCheckTest, ChkOrgStatus) {
    
    ResCodeT rc = NO_ERR;
    pOrgInfoT    pOrgInfo = NULL;

    rc = OrgInfoGetByIdExt( (uint64)123456, &pOrgInfo );
    EXPECT_EQ(rc, NO_ERR);

    //NOT FOUND
    rc = CheckOrgStatus( (int32) 989898 );
    EXPECT_EQ(rc, ERR_CODE_INVLD_INVALID_ORG);

    //ORG_STATUS_FORBID
    pOrgInfo->orgSt = ORG_STATUS_FORBID;
    rc = CheckOrgStatus( pOrgInfo->pos );
    EXPECT_EQ(rc, ERR_CODE_INVLD_ORG_FRD);

    //ORG_STATUS_FORBID
    pOrgInfo->orgSt = ORG_STATUS_ACTIVE;
    pOrgInfo->orgIrsSt = ORG_IRS_ST_FORBID;
    rc = CheckOrgStatus( pOrgInfo->pos );
    EXPECT_EQ(rc, ERR_CODE_INVLD_ORG_FRD);

    //ERR_CODE_INVLD_ORG_DEL
    pOrgInfo->orgIrsSt = ORG_IRS_ST_DELETE;
    rc = CheckOrgStatus( pOrgInfo->pos );
    EXPECT_EQ(rc, ERR_CODE_INVLD_ORG_DEL);

}

// Test the method [OrderCancelCheck]
TEST_F(ordCheckTest, OrderCancelChk) {
    
    ResCodeT rc = NO_ERR;
    int64 sysTimestamp = 0;
    pBaseParamT pParamData = NULL;

    OrderT delOrdr;
    pOrderT pDelOrdr = &delOrdr;

    memset( pDelOrdr, 0x00, sizeof(OrderT) );

    //ERR_CODE_ORD_CLOSED_NO_C
    pDelOrdr->orderF.ordrSts = ORDR_STS_DEAL;
    rc = OrderCancelCheck( pDelOrdr );
    EXPECT_EQ(rc, ERR_CODE_ORD_CLOSED_NO_C);

    //ERR_CODE_INVLD_CANCELED
    pDelOrdr->orderF.ordrSts = ORDR_STS_CANCEL;
    rc = OrderCancelCheck( pDelOrdr );
    EXPECT_EQ(rc, ERR_CODE_INVLD_CANCELED);


    //ERR_CODE_INVLD_CNCL_MKCLS
    pDelOrdr->orderF.ordrSts = ORDR_STS_ACTIVE;
    rc = BaseParamGetByNameExt((char *)C_MKT_ST_IRS, &pParamData);
    EXPECT_EQ(rc, NO_ERR);

    strcpy( pParamData->paramValue, "5" );
    rc = OrderCancelCheck( pDelOrdr );
    EXPECT_EQ(rc, ERR_CODE_INVLD_CNCL_MKCLS);
}



int main(int argc, char **argv) {

    // monEnv = new MonTestEnv;
    // testing::AddGlobalTestEnvironment(monEnv);
    testing::InitGoogleTest(&argc, argv);

    // Adds the leak checker to the end of the test event listener list,
    // after the default text output printer and the default XML report
    // generator.
    //
    // The order is important - it ensures that failures generated in the
    // leak checker's OnTestEnd() method are processed by the text and XML
    // printers *before* their OnTestEnd() methods are called, such that
    // they are attributed to the right test. Remember that a listener
    // receives an OnXyzStart event *after* listeners preceding it in the
    // list received that event, and receives an OnXyzEnd event *before*
    // listeners preceding it.
    //
    // We don't need to worry about deleting the new listener later, as

    return RUN_ALL_TESTS();
}

// Step 3. Call RUN_ALL_TESTS() in main().
//
// We do this by linking in src/gtest_main.cc file, which consists of
// a main() function which calls RUN_ALL_TESTS() for us.
//
// This runs all the tests you've defined, prints the result, and
// returns 0 if successful, or 1 otherwise.
//
// Did you notice that we didn't register the tests?  The
// macro magically knows about all the tests we
// defined.  Isn't this convenient?
