/***
Created on May 08, 2017
@author: Ming.Kong
@version $Id
***/

#include <limits.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include "msg_queue.h"
#include "shm.h"
#include "gtest/gtest.h"


int32 msgHndl;
int32 fd;

class mqTest : public testing::Test {
    virtual void SetUp() {
    }

    virtual void TearDown() {
    }
};

void* writeThread(void * arg)
{
    uint32 i  = 0;
    int32 ret;
    for(i= 1;i<=100;i++)
    {
        ret = MsgQueueWriteSlot(msgHndl, i);
        if (ret != 1)
        {

        }
    }
    return NULL;
}

void *writeThread2(void * arg)
{
    uint32 i  = 0;
    
    for(i= 101;i<=200;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread3(void * arg)
{
    uint32 i  = 0;
    for(i= 201;i<=300;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread4(void * arg)
{
    uint32 i  = 0;
    
    for(i= 301;i<=400;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread5(void * arg)
{
    uint32 i  = 0;
    
    for(i= 401;i<=500;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread6(void * arg)
{
    uint32 i  = 0;
    for(i= 501;i<=600;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread7(void * arg)
{
    uint32 i  = 0;
    
    for(i= 601;i<=700;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread8(void * arg)
{
    uint32 i  = 0;
    
    for(i= 701;i<=800;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread9(void * arg)
{
    uint32 i  = 0;
    
    for(i= 801;i<=900;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void *writeThread10(void * arg)
{
    uint32 i  = 0;
    
    for(i= 901;i<=1000;i++)
    {
        MsgQueueWriteSlot(msgHndl, i);
    }
    return NULL;
}

void* readThread(void* pRdCnt)
{
    uint32 i =0;
    int ret;
    int targetCnt =0;
    
    
    uint32 cnt = 0;
    uint32* pCnt  = (uint32*)pRdCnt;
    
    targetCnt = *pCnt;
    
    fd_set fSet;
    struct timeval timeOut;
    timeOut.tv_sec = 4;
    timeOut.tv_usec = 0;
    
    FD_ZERO(&fSet);
    FD_SET(fd, &fSet);

    while (1)
    {
        ret = select(fd+1, &fSet,NULL, NULL, &timeOut);
        if (ret == 1)
        {
            if (FD_ISSET(fd, &fSet))
            {
                if (MsgQueueReadSlot(msgHndl, &i) == 1)
                {
                    cnt++;
                }else
                {

                }
            }
        }
        if (cnt==targetCnt)
        {
            break;
        }
        if (ret == 0)
        {
            break;
        }
    }

    *pCnt = cnt;
    return NULL;
}

TEST(mqTest, oneToOneWithShm) {
    pthread_t id_1;
    pthread_t id_3;
    uint32 readCnt = 100;

    MsgQueueCfgT  cfg;

    cfg.type = Q_TYPE_1W1R;
    cfg.itemCnt = 1024*2;
    cfg.itemSize = sizeof(int);

    int64* pRoot;
    
    ShmCreate("./test_shm", 1024*2*40, &pRoot);
    
    MsgQueueCreate(&cfg, 2, &msgHndl, (void*)pRoot);
    MsgQueueGetFd(msgHndl, &fd);
    
    pthread_create(&id_1, NULL, writeThread, (void*)NULL);
    pthread_create(&id_3, NULL, readThread, (void*)&readCnt);

    pthread_join(id_1,NULL);
    pthread_join(id_3,NULL);

    EXPECT_EQ(100, readCnt);
    
    MsgQueueDispose(msgHndl);
    ShmDelete("./test_shm");
}

TEST(mqTest, oneToOne) {
    pthread_t id_1;
    pthread_t id_3;
    uint32 readCnt = 100;

    MsgQueueCfgT  cfg;

    cfg.type = Q_TYPE_1W1R;
    cfg.itemCnt = 1024*2;
    cfg.itemSize = sizeof(int);

    MsgQueueCreate(&cfg, 2, &msgHndl, NULL);
    MsgQueueGetFd(msgHndl, &fd);
    pthread_create(&id_1, NULL, writeThread, (void*)NULL);
    pthread_create(&id_3, NULL, readThread, (void*)&readCnt);
    pthread_join(id_1,NULL);
    pthread_join(id_3,NULL);
    EXPECT_EQ(100, readCnt);

    MsgQueueDispose(msgHndl);
}



TEST(mqTest, twoToOne) {
  // This test is named "Negative", and belongs to the "FactorialTest"
  // test case.

    pthread_t id_1;
    pthread_t id_2;
    pthread_t id_3;
    uint32 readCnt = 200;

    MsgQueueCfgT  cfg;

    cfg.type = Q_TYPE_MW1R;
    cfg.itemCnt = 1024*2;
    cfg.itemSize = sizeof(int);

    MsgQueueCreate(&cfg, 3, &msgHndl, NULL);
    MsgQueueGetFd(msgHndl, &fd);
		
    pthread_create(&id_1, NULL, writeThread, (void*)NULL);
    pthread_create(&id_2, NULL, writeThread2, (void*)NULL);
    pthread_create(&id_3, NULL, readThread, (void*)&readCnt);
  
    pthread_join(id_1,NULL);
    pthread_join(id_2,NULL);
    pthread_join(id_3,NULL);
	
    EXPECT_EQ(200, readCnt);
    MsgQueueDispose(msgHndl);
}

TEST(mqTest, tenToOne) {
  // This test is named "Negative", and belongs to the "FactorialTest"
  // test case.

    pthread_t id_1;
    pthread_t id_2;
    pthread_t id_3;
    pthread_t id_4;
    pthread_t id_5;
    pthread_t id_6;
    pthread_t id_7;
    pthread_t id_8;
    pthread_t id_9;
    pthread_t id_10;
    pthread_t id_rd;
    uint32 readCnt = 1000;

    MsgQueueCfgT  cfg;

    cfg.type = Q_TYPE_MW1R;
    cfg.itemCnt = 1024*2;
    cfg.itemSize = sizeof(int);

    MsgQueueCreate(&cfg, 11, &msgHndl, NULL);
    MsgQueueGetFd(msgHndl, &fd);

    pthread_create(&id_1, NULL, writeThread, (void*)NULL);
    pthread_create(&id_2, NULL, writeThread2, (void*)NULL);
    pthread_create(&id_3, NULL, writeThread3, (void*)NULL);
    pthread_create(&id_4, NULL, writeThread4, (void*)NULL);
    pthread_create(&id_5, NULL, writeThread5, (void*)NULL);
    pthread_create(&id_6, NULL, writeThread6, (void*)NULL);
    pthread_create(&id_7, NULL, writeThread7, (void*)NULL);
    pthread_create(&id_8, NULL, writeThread8, (void*)NULL);
    pthread_create(&id_9, NULL, writeThread9, (void*)NULL);
    pthread_create(&id_10, NULL, writeThread10, (void*)NULL);
    pthread_create(&id_rd, NULL, readThread, (void*)&readCnt);
  
    pthread_join(id_1,NULL);
    pthread_join(id_2,NULL);
    pthread_join(id_3,NULL);
    pthread_join(id_4,NULL);
    pthread_join(id_5,NULL);
    pthread_join(id_6,NULL);
    pthread_join(id_7,NULL);
    pthread_join(id_8,NULL);
    pthread_join(id_9,NULL);
    pthread_join(id_10,NULL);
    pthread_join(id_rd,NULL);
    EXPECT_EQ(1000, readCnt);

    MsgQueueDispose(msgHndl);
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
