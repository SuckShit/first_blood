/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/

#include <limits.h>
#include "err_lib.h"    
#include "app_shl.h"            
#include "gtest/gtest.h"
#include "msg_cache.h"
#include "UTILITY/logfile.h"
#include "Utils.h"
#include "mem_txn.h"
#include "uti_tool.h"
#include "msg_type.h"
#include "db_comm.h"
static ShlCfgInfoT gShlCfgInfo;

static int32        gMsgCnt = 0;
static int32        gCommitCnt =0;
static int32        gNeedTxn = 0;
using ::testing::InitGoogleTest; 


class AppShlCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {

       
    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char appName[] = "";
        PrcsInit(appName);
        
        
        ResCodeT rc = NO_ERR;
        rc = MsgCreate(8192,10,10);
        ASSERT_EQ(rc, NO_ERR);
       
        
        MsgQueueCfgT        msgQCfg;
        int32               ttlSize;
        void *              pQueueAddr = NULL;
        
        msgQCfg.type = Q_TYPE_MW1R;
        msgQCfg.itemCnt = 4096;
        msgQCfg.itemSize = sizeof(SlotT);
        msgQCfg.threadCnt = 100;
        
        rc = MsgQueueCalcSize(&msgQCfg, (uint32*)&ttlSize);
        ASSERT_EQ(rc, NO_ERR);
        
        MALLOC(pQueueAddr, ttlSize)
    
        rc = MsgQueueCreate(&msgQCfg,&gShlCfgInfo.inQHndl[SHL_Q_TYPE_DFLT],pQueueAddr);      
        ASSERT_EQ(rc, NO_ERR);
        
        MALLOC(pQueueAddr, ttlSize)
    
        rc = MsgQueueCreate(&msgQCfg,&gShlCfgInfo.inQHndl[SHL_Q_TYPE_EVENT],pQueueAddr);      
        ASSERT_EQ(rc, NO_ERR);
        
        MALLOC(pQueueAddr, ttlSize)
    
        rc = MsgQueueCreate(&msgQCfg,&gShlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT],pQueueAddr);      
        ASSERT_EQ(rc, NO_ERR);
        
        MemTxnCfgT memTxnCfg[2];
        
        memTxnCfg[0].setId = 1;
        memTxnCfg[0].nmbrOfTxn = 1000;
        memTxnCfg[0].dataSize = 512;
        
        memTxnCfg[1].setId = 2;
        memTxnCfg[1].nmbrOfTxn = 2000;
        memTxnCfg[1].dataSize = 600;
        
        rc = MemTxnShmCreateForAllSet(memTxnCfg, 2);
        ASSERT_EQ(rc, NO_ERR);
        
            
        rc = DbCmmnInit();
        ASSERT_EQ(rc, NO_ERR);
        
    }
    
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        rc = AppShlShutDown();
        ASSERT_EQ(rc, NO_ERR);

        
        rc = MsgQueueDispose(gShlCfgInfo.inQHndl[SHL_Q_TYPE_DFLT]);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = MsgQueueDispose(gShlCfgInfo.inQHndl[SHL_Q_TYPE_EVENT]);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = MsgQueueDispose(gShlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT]);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = MsgDestory();
        ASSERT_EQ(rc, NO_ERR);
        
        rc = MemTxnShmDelete();
        ASSERT_EQ(rc, NO_ERR);
    }   
};
  
#define     TEST_OK_MSG_CNT     1026
ResCodeT TestCallback(pIntrnlMsgT pReq, pIntrnlMsgT pRsp, int64 timestamp, pCallBackCtxT pCtx)
{
    gMsgCnt++;
    
    
    if (gMsgCnt>= TEST_OK_MSG_CNT)
    {
        AppShlStop();
    }
    
    pCtx->sendFlg = 1;
    
    //printf("getMsg %lld got\n", gMsgCnt);
    
    return NO_ERR; 
}
ResCodeT TestDoneCallback()
{
    gCommitCnt++;
    usleep(10000);
    //printf("commit %lld, Msg %lld got\n", gCommitCnt, gMsgCnt);
    
    return NO_ERR; 
}

TEST_F(AppShlCommonTest, InitError) {
    ResCodeT rc = NO_ERR;
    
    rc = AppShlInit(1111, (char *)"TEST_APP", &gShlCfgInfo,TestCallback, TestDoneCallback);
    EXPECT_EQ(rc,ERR_INVLD_SET_ID);
    
    rc = AppShlInit(1, (char *)"TEST_APP", NULL,TestCallback, TestDoneCallback);
    EXPECT_EQ(rc,ERCD_ARCH_INPUT_ARGS);
    
    rc = AppShlInit(1, (char *)"TEST_APP", &gShlCfgInfo,NULL, TestDoneCallback);
    EXPECT_EQ(rc,ERCD_ARCH_INPUT_ARGS);
    
    gShlCfgInfo.txnSize =0;
    rc = AppShlInit(1, (char *)"TEST_APP", &gShlCfgInfo,TestCallback, TestDoneCallback);
    EXPECT_EQ(rc,ERCD_ARCH_INPUT_ARGS);
    
}

void* SendMsgThread(void * arg)
{
    uint32 i  = 0;
    ResCodeT rc = NO_ERR;
    SlotT                    slotId;
    pMsgCacheSlotT          pReqSlot;
    pMsgCacheSlotT          pRespSlot;
    pIntrnlMsgT             pReq;
    
    for (i=0; i<TEST_OK_MSG_CNT;i++)
    {
        rc = MsgRsrvSlotsPaired(&slotId,&pReqSlot,&pRespSlot);
        EXPECT_EQ(rc,NO_ERR);
        
        pReq = (pIntrnlMsgT)&pReqSlot->msgBody;
        
        if (gNeedTxn)
        {
            pReq->msgHdr.msgType = MSG_TYPE_ORDER_SUBMIT_MESSAGE;
        }
        else
        {
            pReq->msgHdr.msgType = MSG_TYPE_ORDR_QUERY;
        }
        
        //printf("send msg %lld\n", slotId);
        
        rc = MsgQueueWriteSlot(gShlCfgInfo.inQHndl[SHL_Q_TYPE_DFLT], slotId);
        EXPECT_EQ(rc,NO_ERR);
        if ((i>(TEST_OK_MSG_CNT/2)) && (i%100 == 0))
        {
            usleep(1000);
        }
    }
    
    //printf("Msg %lld sent\n", i);
   
    return NULL;
}



TEST_F(AppShlCommonTest, InitNoTxnOk) {
    ResCodeT rc = NO_ERR;
    
    gMsgCnt = 0;
    gCommitCnt = 0;
    gNeedTxn = 0;
    
    gShlCfgInfo.txnSize =512;
    
    gShlCfgInfo.bDbSupport =1;
    
    rc = MsgInit();
    EXPECT_EQ(rc,NO_ERR);
    
    rc = AppShlInit(1, (char *)"TEST_APP", &gShlCfgInfo,TestCallback, TestDoneCallback);
    EXPECT_EQ(rc,NO_ERR);
    
    pthread_t test_1;
    pthread_create(&test_1, NULL, SendMsgThread, (void*)NULL);
    
    rc = AppShlRun();
    EXPECT_EQ(rc,NO_ERR);
    
 
    
    pthread_join(test_1,NULL);
    
    EXPECT_EQ(gMsgCnt,TEST_OK_MSG_CNT);
    EXPECT_EQ(gCommitCnt,0);
    
    SlotT       slotId = 0;
    int32 i = 0;
    int32 msgCnt  = 0;
    
    for (i=0;i<TEST_OK_MSG_CNT ;i++)
    {
        rc = MsgQueueReadSlot(gShlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT], &slotId);
        EXPECT_EQ(rc,NO_ERR);
        if (OK(rc))
        {
            msgCnt++;
        }
        
        //rc = MsgDelete(slotId);
        //EXPECT_EQ(rc,NO_ERR);
    }
    

    EXPECT_EQ(msgCnt,TEST_OK_MSG_CNT);
}




TEST_F(AppShlCommonTest, InitTxnOk) {
    ResCodeT rc = NO_ERR;
    
    gMsgCnt = 0;
    gCommitCnt = 0;
    gNeedTxn = TRUE;
    gShlCfgInfo.txnSize =512;
    
    rc = AppShlInit(1, (char *)"TEST_APP", &gShlCfgInfo,TestCallback, TestDoneCallback);
    EXPECT_EQ(rc,NO_ERR);
    
    pthread_t test_1;
    pthread_create(&test_1, NULL, SendMsgThread, (void*)NULL);
    
    rc = AppShlRun();
    EXPECT_EQ(rc,NO_ERR);
    
 
    
    pthread_join(test_1,NULL);
    
    EXPECT_EQ(gMsgCnt,TEST_OK_MSG_CNT);
    EXPECT_EQ(gCommitCnt,3);
    
    SlotT       slotId = 0;
    int32 i = 0;
    int32 msgCnt  = 0;
    
    for (i=0;i<TEST_OK_MSG_CNT ;i++)
    {
        rc = MsgQueueReadSlot(gShlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT], &slotId);
        EXPECT_EQ(rc,NO_ERR);
        if (OK(rc))
        {
            msgCnt++;
        }
        
        //rc = MsgDelete(slotId);
        //EXPECT_EQ(rc,NO_ERR);
    }
    

    EXPECT_EQ(msgCnt,TEST_OK_MSG_CNT);
}




void* SendMsgThreadMix(void * arg)
{
    uint32 i  = 0;
    ResCodeT rc = NO_ERR;
    SlotT                    slotId;
    pMsgCacheSlotT          pReqSlot;
    pMsgCacheSlotT          pRespSlot;
    pIntrnlMsgT             pReq;
    
    for (i=0; i<TEST_OK_MSG_CNT;i++)
    {
        rc = MsgRsrvSlotsPaired(&slotId,&pReqSlot,&pRespSlot);
        EXPECT_EQ(rc,NO_ERR);
        
        pReq = (pIntrnlMsgT)&pReqSlot->msgBody;
        
        if (i%2 == 0)
        {
            pReq->msgHdr.msgType = MSG_TYPE_ORDER_SUBMIT_MESSAGE;
        }
        else
        {
            pReq->msgHdr.msgType = MSG_TYPE_ORDR_QUERY;
        }
        
        //printf("send msg %lld\n", slotId);
        
        rc = MsgQueueWriteSlot(gShlCfgInfo.inQHndl[SHL_Q_TYPE_DFLT], slotId);
        EXPECT_EQ(rc,NO_ERR);
    }
    
    //printf("Msg %lld sent\n", i);
   
    return NULL;
}


TEST_F(AppShlCommonTest, PrcsMsgMixedTxn) {
    ResCodeT rc = NO_ERR;
    
    gMsgCnt = 0;
    gCommitCnt = 0;
    gNeedTxn = TRUE;
    gShlCfgInfo.txnSize =512;
    
    rc = AppShlInit(1, (char *)"TEST_APP", &gShlCfgInfo,TestCallback, TestDoneCallback);
    EXPECT_EQ(rc,NO_ERR);
    
    pthread_t test_1;
    pthread_create(&test_1, NULL, SendMsgThreadMix, (void*)NULL);
    
    rc = AppShlRun();
    EXPECT_EQ(rc,NO_ERR);
    
 
    
    pthread_join(test_1,NULL);
    
    EXPECT_EQ(gMsgCnt,TEST_OK_MSG_CNT);
    EXPECT_EQ(gCommitCnt,2);
    
    SlotT       slotId = 0;
    int32 i = 0;
    int32 msgCnt  = 0;
    
    for (i=0;i<TEST_OK_MSG_CNT ;i++)
    {
        rc = MsgQueueReadSlot(gShlCfgInfo.outQHndl[SHL_Q_TYPE_DFLT], &slotId);
        EXPECT_EQ(rc,NO_ERR);
        if (OK(rc))
        {
            msgCnt++;
        }
        
        //rc = MsgDelete(slotId);
        //EXPECT_EQ(rc,NO_ERR);
    }
    

    EXPECT_EQ(msgCnt,TEST_OK_MSG_CNT);
}


int main(int argc, char **argv) {
    InitGoogleTest(&argc, argv);


    return RUN_ALL_TESTS();
}

