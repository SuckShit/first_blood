/***
Created on Aug 30, 2017
@author: XiaoPing Zhou
@version $Id
***/

// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)


// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.

#include <limits.h>
#include <pthread.h>          
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include "gtest/gtest.h"

#include "common_macro.h"
#include "shm.h"
#include "db_comm.h"

#include "org_onln.h"
#include "org_info.h"
#include "cfg_lib.h"

// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.
using ::testing::InitGoogleTest; 

int32 connId;

class orgOnlnTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {
      // TRACE("IN SETUP!!!!!!!\n");
    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
      // TRACE("IN TEARDOWN!!!!!!!\n");
    }
    
    static void SetUpTestCase() {
        ResCodeT rc = NO_ERR;
        cfgValueS cfgValue = {0};
        
        DbCmmnInit();

        char prcsName[] = "";
        PrcsInit(prcsName); 
      
        rc = GetCfgValue(&cfgValue);
        EXPECT_EQ(rc,NO_ERR);
      
        rc = DbCmmnConnect(cfgValue.dbInst, cfgValue.dbName, cfgValue.dbPwd, &connId);
        RAISE_ERR(rc, RTN);

        rc = OrgInfoLoadFromDB( connId );
        EXPECT_EQ(rc, NO_ERR);

		rc = OrgOnlnCreate(20);
		EXPECT_EQ(rc, NO_ERR);

		rc = OrgOnlnAddById(100001);
		EXPECT_EQ(rc, NO_ERR);
		rc = OrgOnlnAddById(100002);
		EXPECT_EQ(rc, NO_ERR);
				
    }
        
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        
		OrgOnlnDetachFromShm();
		ShmDelete((char*)SHM_ORG_ONLN_NAME);

        DbCmmnDisconnect(connId);
        DbCmmnCleanup();
    }
};

// Test the method [OrgOnlnGetById]
TEST_F(orgOnlnTest, orgOnlnGetById) {
    ResCodeT rc = NO_ERR;
    OrgOnlineT orgOnlnData;
	
    rc = OrgOnlnGetById(100001, &orgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	
	EXPECT_EQ(orgOnlnData.orgId, 100001);
      
}

// Test the method [OrgOnlnGetByPos]
TEST_F(orgOnlnTest, orgOnlnGetByPos) {
    ResCodeT rc = NO_ERR;
    OrgOnlineT orgOnlnData = {0};
	OrgOnlineT posData = {0};
	uint64 pos;
	
    rc = OrgOnlnGetById(100002, &orgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	
	pos = orgOnlnData.pos;
	
	rc = OrgOnlnGetByPos(pos, &posData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(posData.orgId, 100002);
      
}


// Test the method [OrgOnlnAddById]
TEST_F(orgOnlnTest, orgOnlnAddById) {
    ResCodeT rc = NO_ERR;
    pOrgOnlineT pOrgOnlnData;
	OrgOnlineT posData = {0};
	uint64 pos;
	
    rc = OrgOnlnAddById(100003);
	EXPECT_EQ(rc, NO_ERR);
	
	
	rc = OrgOnlnGetByIdExt(100003, &pOrgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(pOrgOnlnData->orgId, 100003);
	
	rc = OrgOnlnAddById(100002);
	EXPECT_EQ(rc, NO_ERR);

	rc = OrgOnlnGetByIdExt(100002, &pOrgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(pOrgOnlnData->usrCnt, 2);

    rc = OrgOnlnDeleteById(100002);
    EXPECT_EQ(rc, NO_ERR);

	rc = OrgOnlnGetByIdExt(100002, &pOrgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(pOrgOnlnData->usrCnt, 1);
}

// Test the method [OrgOnlnDeleteById]
TEST_F(orgOnlnTest, orgOnlnDeleteById) {
    ResCodeT rc = NO_ERR;
    pOrgOnlineT pOrgOnlnData;
	OrgOnlineT posData = {0};
	uint64 pos;
	
    rc = OrgOnlnAddById(100004);
	EXPECT_EQ(rc, NO_ERR);
	
	
	rc = OrgOnlnGetByIdExt(100004, &pOrgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(pOrgOnlnData->orgId, 100004);
	
	rc = OrgOnlnDeleteById(100004);
	EXPECT_EQ(rc, NO_ERR);
	
	rc = OrgOnlnGetById(100004, &posData);
	EXPECT_EQ(rc, ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
	
	rc = OrgOnlnDeleteById(999999);
	EXPECT_EQ(rc, ERR_CMN_HASH_LIST_NODE_NOT_EXIST);
      
}


// Test the method [OrgOnlnIterExt]
TEST_F(orgOnlnTest, orgOnlnIterExt) {
    ResCodeT rc = NO_ERR;
    pOrgOnlineT pOrgOnlnData;
	uint64 iterPos;
	
	iterPos = 0;
	
    rc = OrgOnlnIterExt(&iterPos, &pOrgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(pOrgOnlnData->orgId, 100001);

    rc = OrgOnlnIterExt(&iterPos, &pOrgOnlnData);
	EXPECT_EQ(rc, NO_ERR);
	EXPECT_EQ(pOrgOnlnData->orgId, 100002);
}

// Test the method [OrgOnlnIterExt]
TEST_F(orgOnlnTest, IterOnlOrg) {
    ResCodeT rc = NO_ERR;
    pOrgOnlineT pOrgOnlnData;
    uint64 nxtOnlOrg;
    uint64 lstOnlOrg;

    rc = OrgOnlnAddById(100009);
    EXPECT_EQ(rc, NO_ERR);

    rc = GetLstBrdgOrg( &lstOnlOrg );
    EXPECT_EQ(rc, NO_ERR);
    EXPECT_EQ(lstOnlOrg, CMN_LIST_NULL_NODE);

    rc = IterOnlOrg( lstOnlOrg, &nxtOnlOrg );
    EXPECT_EQ(rc, NO_ERR);
    //EXPECT_EQ(pOrgOnlnData->orgId, 100001);

    rc = UpdtLstBrdgOrg( nxtOnlOrg );
    EXPECT_EQ(rc, NO_ERR);
    //EXPECT_EQ(pOrgOnlnData->orgId, 100002);

    rc = GetLstBrdgOrg( &lstOnlOrg );
    EXPECT_EQ(rc, NO_ERR);
    EXPECT_EQ(lstOnlOrg, nxtOnlOrg);
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);

    // Adds the leak checker to the end of the test event listener list,
    // after the default text output printer and the default XML report
    // generator.
    //
    // The order is important - it ensures that failures generated in the
    // leak checker's OnTestEnd() method are processed by the text and XML
    // printers *before* their OnTestEnd() methods are called, such that
    // they are attributed to the right test. Remember that a listener
    // receives an OnXyzStart event *after* listeners preceding it in the
    // list received that event, and receives an OnXyzEnd event *before*
    // listeners preceding it.
    //
    // We don't need to worry about deleting the new listener later, as

    return RUN_ALL_TESTS();
}

// Step 3. Call RUN_ALL_TESTS() in main().
//
// We do this by linking in src/gtest_main.cc file, which consists of
// a main() function which calls RUN_ALL_TESTS() for us.
//
// This runs all the tests you've defined, prints the result, and
// returns 0 if successful, or 1 otherwise.
//
// Did you notice that we didn't register the tests?  The
// macro magically knows about all the tests we
// defined.  Isn't this convenient?
