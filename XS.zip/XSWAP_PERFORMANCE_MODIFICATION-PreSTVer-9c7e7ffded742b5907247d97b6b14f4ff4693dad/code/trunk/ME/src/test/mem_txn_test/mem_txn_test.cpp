/***
Created on June 20, 2017
@author: Brian.Ping
@version $Id
***/

#include <limits.h>
#include "err_lib.h"    
#include "mem_txn.h"            
#include "gtest/gtest.h"
#include "uti_tool.h"

#define SET_ID_ONE          1
#define SET_ID_TWO          2
#define SET_ID_THREE        3
#define SET_ID_INVLD        100
#define SET_ID_ONE_DAT_SIZE        500

using ::testing::InitGoogleTest; 

class MemTxnCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {

    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char prcsName[] = "";
        PrcsInit(prcsName);
        ResCodeT rc = NO_ERR;
        MemTxnCfgT memTxnCfg[2];
        
        memTxnCfg[0].setId = SET_ID_ONE;
        memTxnCfg[0].nmbrOfTxn = 1000;
        memTxnCfg[0].dataSize = SET_ID_ONE_DAT_SIZE;
        
        memTxnCfg[1].setId = SET_ID_TWO;
        memTxnCfg[1].nmbrOfTxn = 2000;
        memTxnCfg[1].dataSize = 600;
        
        
        memTxnCfg[2].setId = SET_ID_THREE;
        memTxnCfg[2].nmbrOfTxn = 2000;
        memTxnCfg[2].dataSize = 600;
        
        rc = MemTxnShmCreateForAllSet(memTxnCfg, 3);
        ASSERT_EQ(rc, NO_ERR);
    }
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        rc =  MemTxnShmDetach();
        ASSERT_EQ(rc, NO_ERR);
        
        rc =  MemTxnShmDelete();
        ASSERT_EQ(rc, NO_ERR);
    
    }   
};


TEST_F(MemTxnCommonTest, Init) {
    ResCodeT rc = NO_ERR;
    
    rc = MemTxnShmInit(SET_ID_ONE);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnShmInit(SET_ID_TWO);
    EXPECT_EQ(rc,NO_ERR);
    
//    rc = MemTxnShmInit(SET_ID_INVLD);
//    EXPECT_EQ(rc,ERR_INVLD_SET_ID);
}


TEST_F(MemTxnCommonTest, AddElem) {
    ResCodeT rc = NO_ERR;
    char   testStr[] = "Peter Parker";
    DatCtrlT datCtrl;
    
    rc =  MemTxnAddElem(SET_ID_ONE, MT_TYP_ODR_LOG, NULL, strlen(testStr));
    EXPECT_EQ(rc,ERCD_ARCH_INPUT_ARGS);
    
    rc =  MemTxnAddElem(SET_ID_ONE, MT_TYPE_MAX, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,ERCD_ARCH_INPUT_ARGS);
 
}

TEST_F(MemTxnCommonTest, StartAndCommit) {
    ResCodeT rc = NO_ERR;
    int64  txnId = 0;
    int64  timestamp = 0;
    MemTxnCtrlT txnCtrl;
    MemTxnEntryT txnEntry;
    char   testStr[] = "Peter Parker";
    DatCtrlT datCtrl;
    
    rc = MemTxnShmInit(SET_ID_ONE);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnStart(SET_ID_ONE, &txnId, &timestamp);
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(txnId,1);
    
    MemTxnGetTxnInfo(SET_ID_ONE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currTxnId,1);
    EXPECT_EQ(txnCtrl.commitTxnId,0);
    EXPECT_EQ(txnCtrl.maxTxnId,1000);
    
    
    EXPECT_EQ(txnCtrl.currDataCnt,0);
    EXPECT_EQ(txnCtrl.maxDataCnt,1000);
    EXPECT_EQ(txnCtrl.elemCnt,0);

    EXPECT_EQ(txnEntry.txnId,txnId);
    EXPECT_EQ(txnEntry.txnSts,TXN_STS_OPEN);
    EXPECT_EQ(txnEntry.dataCnt,0);
    
    EXPECT_EQ(txnEntry.frstDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);

    /* write first data*/
    rc =  MemTxnAddElem(SET_ID_ONE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    
    MemTxnGetTxnInfo(SET_ID_ONE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,1);
    EXPECT_EQ(txnCtrl.elemCnt,1);
    EXPECT_EQ(txnEntry.dataCnt,1);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_ONE,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,1);
    EXPECT_EQ(datCtrl.elemTtlSize,strlen(testStr) + sizeof(DatElemHdrT) * 2);
    EXPECT_EQ(datCtrl.elemCnt,1);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    /* write next data*/
    rc =  MemTxnAddElem(SET_ID_ONE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    
    MemTxnGetTxnInfo(1, txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,1);
    EXPECT_EQ(txnCtrl.elemCnt,2);
    EXPECT_EQ(txnEntry.dataCnt,1);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_ONE,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,1);
    EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2)*2);
    EXPECT_EQ(datCtrl.elemCnt,2);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    /* try to write data to full*/
    int32 i = 0;
    int32 maxCnt = SET_ID_ONE_DAT_SIZE/(strlen(testStr)+ sizeof(DatElemHdrT) * 2);
    for (i = 0; i<maxCnt-2; i++)
    {
        rc =  MemTxnAddElem(SET_ID_ONE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
        EXPECT_EQ(rc,NO_ERR);
    }
    
    MemTxnGetTxnInfo(SET_ID_ONE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,1);
    EXPECT_EQ(txnCtrl.elemCnt,maxCnt);
    EXPECT_EQ(txnEntry.dataCnt,1);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_ONE,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,1);
    EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2)*maxCnt);
    EXPECT_EQ(datCtrl.elemCnt,maxCnt);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    /*Suppose the data is full, will get a new data sqno after write data */
    rc =  MemTxnAddElem(SET_ID_ONE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);

    
    MemTxnGetTxnInfo(SET_ID_ONE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,2);
    EXPECT_EQ(txnCtrl.elemCnt,maxCnt +1);
    EXPECT_EQ(txnEntry.dataCnt,2);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_ONE,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,2);
    EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2));
    EXPECT_EQ(datCtrl.elemCnt,1);
    
    EXPECT_EQ(datCtrl.prevDataSqno,1);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    /* Commit */
    rc = MemTxnCommit(SET_ID_ONE);
    EXPECT_EQ(rc,NO_ERR);
    
    MemTxnGetTxnInfo(SET_ID_ONE,  txnId, &txnCtrl,&txnEntry );
    EXPECT_EQ(txnCtrl.currDataCnt,2);
    EXPECT_EQ(txnCtrl.elemCnt,maxCnt +1);
    
    EXPECT_EQ(txnCtrl.currTxnId,1);
    EXPECT_EQ(txnCtrl.commitTxnId,1);
    EXPECT_EQ(txnCtrl.maxTxnId,1000);

    EXPECT_EQ(txnCtrl.maxDataCnt,1000);

    EXPECT_EQ(txnEntry.txnId,txnId);
    EXPECT_EQ(txnEntry.txnSts,TXN_STS_COMMIT);
    EXPECT_EQ(txnEntry.dataCnt,2);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,2);
    
    MemTxnGetDataInfo(SET_ID_ONE,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,2);
    EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2));
    EXPECT_EQ(datCtrl.elemCnt,1);
    
    EXPECT_EQ(datCtrl.prevDataSqno,1);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_ONE,  txnCtrl.currDataCnt -1, &datCtrl);
    EXPECT_EQ(datCtrl.nextDataSqno,2);
    
    
    //ResCodeT MemTxnIterElem(int32 set, int32 startTxnId,int32 endTxnId, MTElemTypeT * pElemType, void ** ppData, int32 * pDataLen);
    MTElemTypeT  ElemType;
    void *pData;
    int32 dataLen;
    int32 curTxnId;
    
    rc = MemTxnIterElem(SET_ID_ONE,2,1,&ElemType,(void**)&pData,&dataLen);
    EXPECT_EQ(rc,ERR_MEM_TXN_ITER_DATA_END);
    
    rc = MemTxnIterElem(SET_ID_ONE,1,2,&ElemType,(void**)&pData,&dataLen);
    EXPECT_EQ(rc,NO_ERR);
    EXPECT_EQ(ElemType,MT_TYP_ODR_LOG);
    EXPECT_EQ(memcmp(pData,testStr,strlen(testStr)),0);
    EXPECT_EQ(dataLen,strlen(testStr));
    

    
    for (int32 i = 0; i < 17; i++)
    {
        rc = MemTxnIterElemNext(SET_ID_ONE,&curTxnId,&ElemType,(void**)&pData,&dataLen);
        EXPECT_EQ(rc,NO_ERR);
        EXPECT_EQ(ElemType,MT_TYP_ODR_LOG);
        EXPECT_EQ(memcmp(pData,testStr,strlen(testStr)),0);
        EXPECT_EQ(dataLen,strlen(testStr));
    }
     
     rc = MemTxnIterElemNext(SET_ID_ONE,&curTxnId,&ElemType,(void**)&pData,&dataLen);
     EXPECT_EQ(rc,ERR_MEM_TXN_ITER_DATA_END);
}



TEST_F(MemTxnCommonTest, StartAndRollback) {
    ResCodeT rc = NO_ERR;
    int64  txnId = 0;
    int64  timestamp = 0;
    MemTxnCtrlT txnCtrl;
    MemTxnEntryT txnEntry;
    char   testStr[] = "Peter Parker";
    DatCtrlT datCtrl;
    
    rc = MemTxnShmInit(SET_ID_TWO);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnStart(SET_ID_TWO, &txnId, &timestamp);
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(txnId,1);
    
    MemTxnGetTxnInfo(SET_ID_TWO,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currTxnId,1);
    EXPECT_EQ(txnCtrl.commitTxnId,0);
    EXPECT_EQ(txnCtrl.maxTxnId,2000);
    
    
    EXPECT_EQ(txnCtrl.currDataCnt,0);
    EXPECT_EQ(txnCtrl.maxDataCnt,2000);
    EXPECT_EQ(txnCtrl.elemCnt,0);

    EXPECT_EQ(txnEntry.txnId,txnId);
    EXPECT_EQ(txnEntry.txnSts,TXN_STS_OPEN);
    EXPECT_EQ(txnEntry.dataCnt,0);
    
    EXPECT_EQ(txnEntry.frstDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);

    /* write first data*/
    rc =  MemTxnAddElem(SET_ID_TWO, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    
    MemTxnGetTxnInfo(SET_ID_TWO,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,1);
    EXPECT_EQ(txnCtrl.elemCnt,1);
    EXPECT_EQ(txnEntry.dataCnt,1);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_TWO,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,1);
    EXPECT_EQ(datCtrl.elemTtlSize,strlen(testStr) + sizeof(DatElemHdrT) * 2);
    EXPECT_EQ(datCtrl.elemCnt,1);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    /* write next data*/
    rc =  MemTxnAddElem(SET_ID_TWO, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    
    MemTxnGetTxnInfo(SET_ID_TWO, txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,1);
    EXPECT_EQ(txnCtrl.elemCnt,2);
    EXPECT_EQ(txnEntry.dataCnt,1);
    
    EXPECT_EQ(txnEntry.frstDataSqno,1);
    EXPECT_EQ(txnEntry.lstDataSqno,NO_DATA_SQNO);
    
    MemTxnGetDataInfo(SET_ID_TWO,  txnCtrl.currDataCnt, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,1);
    EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2)*2);
    EXPECT_EQ(datCtrl.elemCnt,2);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    rc = MemTxnRollback(SET_ID_TWO);
    EXPECT_EQ(datCtrl.elemCnt,2);
    
    MemTxnGetTxnInfo(SET_ID_TWO,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,0);
    EXPECT_EQ(txnCtrl.elemCnt,0);
    
    EXPECT_EQ(txnCtrl.currTxnId,0);
    EXPECT_EQ(txnCtrl.commitTxnId,0);
    EXPECT_EQ(txnCtrl.maxTxnId,2000);

    EXPECT_EQ(txnCtrl.maxDataCnt,2000);

    EXPECT_EQ(txnEntry.txnId,0);
    EXPECT_EQ(txnEntry.txnSts,0);
    EXPECT_EQ(txnEntry.dataCnt,0);
    
    EXPECT_EQ(txnEntry.frstDataSqno,0);
    EXPECT_EQ(txnEntry.lstDataSqno,0);
    
    MemTxnGetDataInfo(SET_ID_TWO,  1, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,0);
    EXPECT_EQ(datCtrl.elemTtlSize,0);
    EXPECT_EQ(datCtrl.elemCnt,0);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
}

TEST_F(MemTxnCommonTest, Start3AndRb1) {
    ResCodeT rc = NO_ERR;
    int64  txnId = 0;
    int64  timestamp = 0;
    MemTxnCtrlT txnCtrl;
    MemTxnEntryT txnEntry;
    char   testStr[] = "Peter Parker";
    DatCtrlT datCtrl;
    
    int32 i = 0;
    
    for (i=0; i<10; i++)
    {
        rc = MemTxnShmInit(SET_ID_THREE);
        EXPECT_EQ(rc,NO_ERR);
        
        rc = MemTxnStart(SET_ID_THREE, &txnId, &timestamp);
        EXPECT_EQ(rc,NO_ERR);
        
        /* write first data*/
        rc =  MemTxnAddElem(SET_ID_THREE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
        EXPECT_EQ(rc,NO_ERR);
        /* write first data*/
        rc =  MemTxnAddElem(SET_ID_THREE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
        EXPECT_EQ(rc,NO_ERR);
        
        /* Commit */
        rc = MemTxnCommit(SET_ID_THREE);
        EXPECT_EQ(rc,NO_ERR);
    }
    
    EXPECT_EQ(txnId,10);
    
    MemTxnGetTxnInfo(SET_ID_THREE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currTxnId,10);
    EXPECT_EQ(txnCtrl.commitTxnId,10);
    
    EXPECT_EQ(txnCtrl.currDataCnt,10);
    EXPECT_EQ(txnCtrl.elemCnt,20);
    
    for (i=0; i<10; i++)
    {
        MemTxnGetTxnInfo(SET_ID_THREE,  i+1, &txnCtrl,&txnEntry );
         
        EXPECT_EQ(txnEntry.txnId,i+1);
        EXPECT_EQ(txnEntry.txnSts,TXN_STS_COMMIT);
        EXPECT_EQ(txnEntry.dataCnt,1);
        
        EXPECT_EQ(txnEntry.frstDataSqno,i+1);
        EXPECT_EQ(txnEntry.lstDataSqno,i+1);
        
        MemTxnGetDataInfo(SET_ID_THREE,  i+1, &datCtrl);
    
        EXPECT_EQ(datCtrl.dataSqno,i+1);
        EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2) *2);
        EXPECT_EQ(datCtrl.elemCnt,2);
        
        EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
        EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    }

    rc = MemTxnShmInit(SET_ID_THREE);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnStart(SET_ID_THREE, &txnId, &timestamp);
    EXPECT_EQ(rc,NO_ERR);
    
    /* write first data*/
    rc =  MemTxnAddElem(SET_ID_THREE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    /* write first data*/
    rc =  MemTxnAddElem(SET_ID_THREE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnRollback(SET_ID_THREE);
    EXPECT_EQ(datCtrl.elemCnt,2);
    
    MemTxnGetTxnInfo(SET_ID_THREE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currDataCnt,10);
    EXPECT_EQ(txnCtrl.elemCnt,20);
    EXPECT_EQ(txnCtrl.currTxnId,10);
    EXPECT_EQ(txnCtrl.commitTxnId,10);

    EXPECT_EQ(txnEntry.txnId,0);
    EXPECT_EQ(txnEntry.txnSts,0);
    EXPECT_EQ(txnEntry.dataCnt,0);
    
    EXPECT_EQ(txnEntry.frstDataSqno,0);
    EXPECT_EQ(txnEntry.lstDataSqno,0);
    
    MemTxnGetDataInfo(SET_ID_THREE,  11, &datCtrl);
    
    EXPECT_EQ(datCtrl.dataSqno,0);
    EXPECT_EQ(datCtrl.elemTtlSize,0);
    EXPECT_EQ(datCtrl.elemCnt,0);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    rc = MemTxnShmInit(SET_ID_THREE);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnStart(SET_ID_THREE, &txnId, &timestamp);
    EXPECT_EQ(rc,NO_ERR);
    
    /* write first data*/
    rc =  MemTxnAddElem(SET_ID_THREE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    /* write first data*/
    rc =  MemTxnAddElem(SET_ID_THREE, MT_TYP_ODR_LOG, (void *) testStr, strlen(testStr));
    EXPECT_EQ(rc,NO_ERR);
    
    rc = MemTxnCommit(SET_ID_THREE);
    EXPECT_EQ(rc,NO_ERR);
    
    EXPECT_EQ(txnId,11);
    
    MemTxnGetTxnInfo(SET_ID_THREE,  txnId, &txnCtrl,&txnEntry );
    
    EXPECT_EQ(txnCtrl.currTxnId,11);
    EXPECT_EQ(txnCtrl.commitTxnId,11);
    
    EXPECT_EQ(txnCtrl.currDataCnt,11);
    EXPECT_EQ(txnCtrl.elemCnt,22);


    EXPECT_EQ(txnEntry.txnId,txnId);
    EXPECT_EQ(txnEntry.txnSts,TXN_STS_COMMIT);
    EXPECT_EQ(txnEntry.dataCnt,1);
    
    EXPECT_EQ(txnEntry.frstDataSqno,11);
    EXPECT_EQ(txnEntry.lstDataSqno,11);
    
    MemTxnGetDataInfo(SET_ID_THREE,  txnId, &datCtrl);

    EXPECT_EQ(datCtrl.dataSqno,11);
    EXPECT_EQ(datCtrl.elemTtlSize,(strlen(testStr) + sizeof(DatElemHdrT) * 2) *2);
    EXPECT_EQ(datCtrl.elemCnt,2);
    
    EXPECT_EQ(datCtrl.prevDataSqno,NO_DATA_SQNO);
    EXPECT_EQ(datCtrl.nextDataSqno,NO_DATA_SQNO);
    
    
    MTElemTypeT  ElemType;
    void *pData;
    int32 dataLen;
    int32 curTxnId;
    
    rc = MemTxnIterElem(SET_ID_THREE,12,1,&ElemType,(void**)&pData,&dataLen);
    EXPECT_EQ(rc,ERR_MEM_TXN_ITER_DATA_END);
    
    rc = MemTxnIterElem(SET_ID_THREE,1,11,&ElemType,(void**)&pData,&dataLen);
    EXPECT_EQ(rc,NO_ERR);
    EXPECT_EQ(ElemType,MT_TYP_ODR_LOG);
    EXPECT_EQ(memcmp(pData,testStr,strlen(testStr)),0);
    EXPECT_EQ(dataLen,strlen(testStr));

    for (int32 i = 0; i < 21; i++)
    {
        rc = MemTxnIterElemNext(SET_ID_THREE,&curTxnId,&ElemType,(void**)&pData,&dataLen);
        EXPECT_EQ(rc,NO_ERR);
        EXPECT_EQ(ElemType,MT_TYP_ODR_LOG);
        EXPECT_EQ(memcmp(pData,testStr,strlen(testStr)),0);
        EXPECT_EQ(dataLen,strlen(testStr));
    }
     
     rc = MemTxnIterElemNext(SET_ID_THREE,&curTxnId,&ElemType,(void**)&pData,&dataLen);
     EXPECT_EQ(rc,ERR_MEM_TXN_ITER_DATA_END);

}

int main(int argc, char **argv) {
    InitGoogleTest(&argc, argv);


    return RUN_ALL_TESTS();
}

