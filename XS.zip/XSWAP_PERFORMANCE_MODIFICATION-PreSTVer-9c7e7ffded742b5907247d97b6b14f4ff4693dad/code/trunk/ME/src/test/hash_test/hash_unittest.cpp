/***
Created on June 20, 2017
@author: Yinsong.Zhao
@version $Id
***/
// Copyright 2005, Google Inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// A sample program demonstrating using Google C++ testing framework.
//
// Author: wan@google.com (Zhanyong Wan)


// This sample shows how to write a simple unit test for a function,
// using Google C++ testing framework.
//
// Writing a unit test using Google C++ testing framework is easy as 1-2-3:


// Step 1. Include necessary header files such that the stuff your
// test logic needs is declared.
//
// Don't forget gtest.h, which declares the testing framework.
#include "uti_tool.h"
#include "common_hash.h"          
#include "err_cod.h"
#include "err_lib.h"
#include "gtest/gtest.h"
#include "brdg_ordr_mgmt.h"
#include "order_book.h"
#include "trade.h"
#include "trade_mgmt.h"
#include "org_info.h"

// Step 2. Use the TEST macro to define your tests.
//
// TEST has two parameters: the test case name and the test name.
// After using the macro, you should define your test logic between a
// pair of braces.  You can use a bunch of macros to indicate the
// success or failure of a test.  EXPECT_TRUE and EXPECT_EQ are
// examples of such macros.  For a complete list, see gtest.h.
//
// <TechnicalDetails>
//
// In Google Test, tests are grouped into test cases.  This is how we
// keep test code organized.  You should put logically related tests
// into the same test case.
//
// The test case name and the test name should both be valid C++
// identifiers.  And you should not use underscore (_) in the names.
//
// Google Test guarantees that each test you define is run exactly
// once, but it makes no guarantee on the order the tests are
// executed.  Therefore, you should write your tests in such a way
// that their results don't depend on their order.
//
// </TechnicalDetails>
// To use a test fixture, derive a class from testing::Test.


using ::testing::InitGoogleTest; 



class hashTest : public testing::Test {
 //protected:  // You should make the members protected s.t. they can be
             // accessed from sub-classes.

  // virtual void SetUp() will be called before each test is run.  You
  // should define it if you need to initialize the varaibles.
  // Otherwise, this can be skipped.
    virtual void SetUp() {

    }

  // virtual void TearDown() will be called after each test is run.
  // You should define it if there is cleanup work to do.  Otherwise,
  // you don't have to provide it.
  //
    virtual void TearDown() {
    }

};

CmnHashHndlT hashHndl;

TEST(hashTest, createHash) {
    ResCodeT rc = NO_ERR;
    HashTableRecInfoT htInfo;
    BOOL exist = 0;
    uint64 pos = 0;
    char ret[100];
    char cp[100];
    
    memset(ret, 0, sizeof(ret));
    memset(cp, 0, sizeof(ret));
    
    
    htInfo.recSize = 100;
    htInfo.keyOffset = 0;
    htInfo.keySize = 4;
    htInfo.recCnt = 5000;
    void* pRt;
    
    rc = CmnHashTblCreate((char*)"./myHash", htInfo,1, &pRt, &hashHndl);
    
    EXPECT_EQ(rc,NO_ERR);
    EXPECT_FALSE(pRt==NULL);
    EXPECT_NE(hashHndl,0);
    
}


TEST(hashTest, logData) {
    
    
    ResCodeT rc = NO_ERR;
    char  data[100];
    uint64 pDataPos;
    BOOL exist = 0;
    uint32 pos = 0;
    char ret[100];
    char cp[100];
    
    int tempKey = 1;
      // check invalid hashHndl
    rc = CmnHashLogData(0,"1001_test",0,0,0);
    EXPECT_EQ(rc,ERCD_ARCH_INVLD_HNDL);
    
    
    
    for(int32 i=0;i<5000;i++){
        char str[10000];
        sprintf(str,"%04d",i+1);
        tempKey = tempKey+1; 
        char a[] = "_abcd";
        rc = CmnHashCheckData(hashHndl, str, &exist, &pos, ret);
        EXPECT_EQ(rc,NO_ERR);
        strcat(str,a);
        if (exist == 0)
        {
            rc = CmnHashLogData(hashHndl, str, pos, 1, 1);
            EXPECT_EQ(rc,NO_ERR);
        }
        //printf("data is %s\n", &str);
    }
    

    
    // if it's vaild

    rc = CmnHashCheckData(hashHndl,"1001",&exist, &pos, (void*)&data);

    EXPECT_EQ(rc,NO_ERR);
    EXPECT_EQ(exist,1);
    EXPECT_EQ(strcmp((char*)data,"1001_abcd"),0);
    
    rc = CmnHashCheckData(hashHndl,"5001",&exist, &pos, (void*)&data);

    EXPECT_EQ(rc,ERR_CMN_HASH_LIST_FULL);

}




TEST(hashTest, readData) {
    ResCodeT rc = NO_ERR;
    char  data[100];
    uint64 pDataPos;
    BOOL exist = 0;
    uint32 pos = 0;
    char ret[100];
    char cp[100];

// check invalid hashHndl
    rc = CmnHashCheckData(hashHndl, "1001", &exist, &pos, ret);
    rc = CmnHashReadDataByPos(hashHndl,pos,(void*)&data);
    EXPECT_EQ(strcmp((char*)data,"1001_abcd"),0);

    rc = CmnHashReadDataByPos(0,pos,(void*)&data);
    EXPECT_EQ(rc,ERCD_ARCH_INVLD_HNDL);

    rc = CmnHashReadDataByPos(hashHndl,100010,(void*)&data);
    EXPECT_EQ(rc,ERCD_ARCH_BUFF_TOO_SHORT);
  

}


TEST(hashTest, deleteData) {
    ResCodeT rc = NO_ERR;
    char  data[100];
    uint64 pDataPos;
    BOOL exist = 0;
    uint32 pos = 0;
    char ret[100];
    char cp[100];
    rc = CmnHashCheckData(hashHndl, "1001", &exist, &pos, ret);
// check invalid hashHndl
    rc = CmnHashDeleteData(0,pos);
    EXPECT_EQ(rc,ERCD_ARCH_INVLD_HNDL);

// check invalid pos
    rc = CmnHashDeleteData(hashHndl,100010);
    EXPECT_EQ(rc,ERCD_ARCH_BUFF_TOO_SHORT);

    // delete
    rc = CmnHashDeleteData(hashHndl,pos);
    EXPECT_EQ(rc,NO_ERR);
    
    rc = CmnHashCheckData(hashHndl, "1001",&exist, &pos, ret);
    EXPECT_EQ(exist,0);

}

TEST(hashTest, updateData) {

    ResCodeT rc = NO_ERR;
    char  data[100];
    uint64 pDataPos;
    BOOL exist = 0;
    uint32 pos = 0;
    char ret[100];
    char cp[100];
    rc = CmnHashCheckData(hashHndl, "1002", &exist, &pos, ret);
//check invalid hashHndl;
    rc = CmnHashUpdateData(0,"1002_abd4",pos);
    EXPECT_EQ(rc,ERCD_ARCH_INVLD_HNDL);
  
   //valid hashHndl and pos    
    rc = CmnHashCheckData(hashHndl, "1002", &exist, &pos, ret);
    EXPECT_EQ(rc,NO_ERR);
    if (exist == 1)
    {
    rc = CmnHashUpdateData(hashHndl,"1002_test",pos);
    EXPECT_EQ(rc,NO_ERR);
    }
    
    rc = CmnHashCheckData(hashHndl, "1002", &exist, &pos, (void*)&data);
    EXPECT_EQ(exist,1);
    EXPECT_EQ(strcmp((char*)data,"1002_test"),0);

}

//TEST(hashTest,pathTest) {
//    char path[1000];
//    ResCodeT rc = NO_ERR;
//    rc = GetStrEnvVar("PATH",(char*)&path);
//    EXPECT_EQ(rc,NO_ERR);
//    printf("---------------------data is %s", path);
//
//}



class BrdgOrdrCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {

    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char prcsName[] = "";
        PrcsInit(prcsName);
        ResCodeT rc = NO_ERR;
        
            
        rc = BrdgOrdrShmCreate(20,1);
        ASSERT_EQ(rc, NO_ERR);
        
        BrdgOrdrShmAttach(1);
        ASSERT_EQ(rc, NO_ERR);
        
    }
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        
        rc =  BrdgOrdrShmDetach(1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc =  BrdgOrdrShmDelete(1);
        ASSERT_EQ(rc, NO_ERR);
    
    }   
};

TEST_F(BrdgOrdrCommonTest, BrdgOrdrCommon) {

    int          rc = NO_ERR;
    int          set = 1;
    uint32        brdgOrdrPos;
    BrdgOrdrRcrdT *pBrdgOrdrRcrd, *pBrdgOrdrRcrd2;
    BrdgOrdrKeyT  *pBrdgOrdrKey, *pBrdgOrdrKey2;
    pOrgInfoT     pOrgInfo;
    
    BrdgOrdrRcrdT brdgOrdrRcrd1 = {0};
    pBrdgOrdrRcrdT pBrdgOrdrRcrd1 = &brdgOrdrRcrd1;

    rc = OrgInfoGetByIdExt( 100034, &pOrgInfo );
    EXPECT_EQ(NO_ERR, rc);

    BrdgOrdrRcrdT brdgOrdrRcrd = {0};
    pBrdgOrdrRcrd = &brdgOrdrRcrd;
    pBrdgOrdrRcrd->brdgOrgId = 100013;
    pBrdgOrdrRcrd->brdgFee = 10;
    pBrdgOrdrRcrd->ordrBkSlot = 5;

    pBrdgOrdrKey = &brdgOrdrRcrd.ordrKey;
    pBrdgOrdrKey->entyIdxNo = pOrgInfo->pos;
    pBrdgOrdrKey->prdctId = 37;
    pBrdgOrdrKey->ordrSide = ORDR_SIDE_BUY;

    rc = OrgInfoGetByIdExt( 100036, &pOrgInfo );
    EXPECT_EQ(NO_ERR, rc);
    
    BrdgOrdrRcrdT brdgOrdrRcrd2 = {0};
    pBrdgOrdrRcrd2 = &brdgOrdrRcrd2;
    pBrdgOrdrRcrd2->brdgOrgId = 100009;
    pBrdgOrdrRcrd2->brdgFee = 10;
    pBrdgOrdrRcrd2->ordrBkSlot = 5;
        
    pBrdgOrdrKey2 = &brdgOrdrRcrd2.ordrKey;
    pBrdgOrdrKey->entyIdxNo = pOrgInfo->pos;
    pBrdgOrdrKey2->prdctId = 37;
    pBrdgOrdrKey2->ordrSide = ORDR_SIDE_SELL;
    
    
    
    
    rc = BrdgOrdrAdd(set, pBrdgOrdrRcrd, &brdgOrdrPos);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = BrdgOrdrChk(set, pBrdgOrdrKey, &pBrdgOrdrRcrd, &brdgOrdrPos);
    EXPECT_EQ(ERR_CMN_HASH_LIST_NODE_EXISTED, rc);
    
    rc = BrdgOrdrGetByPos(set, pBrdgOrdrKey, brdgOrdrPos, &pBrdgOrdrRcrd1);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = BrdgOrdrDelByPos(set, brdgOrdrPos);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = BrdgOrdrChk(set, pBrdgOrdrKey, &pBrdgOrdrRcrd, &brdgOrdrPos);
    EXPECT_EQ(NO_ERR, rc);
    
    
    
    rc = BrdgOrdrAdd(set, pBrdgOrdrRcrd2, &brdgOrdrPos);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = BrdgOrdrChk(set, pBrdgOrdrKey2, &pBrdgOrdrRcrd2, &brdgOrdrPos);
    EXPECT_EQ(ERR_CMN_HASH_LIST_NODE_EXISTED, rc);
    
    rc = BrdgOrdrDel(set, pBrdgOrdrKey2);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = BrdgOrdrChk(set, pBrdgOrdrKey2, &pBrdgOrdrRcrd2, &brdgOrdrPos);
    EXPECT_EQ(NO_ERR, rc);
    
}



/* Trade mgmt test*/
class TradeCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() {

    }

    virtual void TearDown() {
    
    } 
    
    static void SetUpTestCase() {
        char prcsName[] = "";
        PrcsInit(prcsName);
        ResCodeT rc = NO_ERR;
        
            
        rc = TradeShmCreate(20,1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc = TradeShmAttach(1);
        ASSERT_EQ(rc, NO_ERR);
        
    }
    
    static void TearDownTestCase() {
        ResCodeT rc = NO_ERR;
        
        rc =  TradeShmDetach(1);
        ASSERT_EQ(rc, NO_ERR);
        
        rc =  TradeShmDelete(1);
        ASSERT_EQ(rc, NO_ERR);
    
    }   
};



TEST_F(TradeCommonTest, TradeCommon) {

    int          rc = NO_ERR;
    int          set = 1;
    uint32       tradePos;
    uint32       newTradePos;
    
    TradeKeyT    TradeKey = {2017091800001};
    TradeDatT    TradeDat = {{2017091800001}, {20170918000001, 37, 1, 'N', "", 1505703315255462, 2017091800000002, 250, 250000000, 250, 250000000},
    	{20170918000001, 37, 1, 'N', "", 1505703315255462, 2017091800000001, 250, 250000000, 250, 250000000}};
    TradeDatT    UptTradeDat = {{2017091800001}, {20170918000001, 6, 1, 'N', "", 1505703315255462, 2017091800000002, 250, 250000000, 250, 250000000},
    	{20170918000001, 6, 1, 'N', "", 1505703315255462, 2017091800000001, 250, 250000000, 250, 250000000}}; 
    TradeDatT    NewTradeDat = {{2017091800002}, {20170918000002, 37, 1, 'N', "", 1505703315255462, 2017091800000004, 250, 250000000, 250, 250000000},
    	{20170918000002, 37, 1, 'N', "", 1505703315255462, 2017091800000003, 250, 250000000, 250, 250000000}};    
    pTradeKeyT   pTradeKey = &TradeKey;
    pTradeDatT   pTradeDat = &TradeDat;
    pTradeDatT   pUptTradeDat = &UptTradeDat;
    pTradeDatT   pGetTradeDat;
    pTradeDatT   pTradeDatChk;
    pTradeDatT   pUptTradeDatChk;
    TradeDatT    tradeDatTInt1;
    TradeDatT    tradeDatTInt2;
    
    rc = TradeChk(1, pTradeKey, &pTradeDat, &tradePos);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = TradeAdd(1, pTradeDat, &tradePos);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = TradeChk(1, pTradeKey, &pTradeDatChk, &tradePos);
    EXPECT_EQ(ERR_CMN_HASH_LIST_NODE_EXISTED, rc);
    
    rc = TradeGetByPos(1, pTradeKey , tradePos, &pGetTradeDat );
    EXPECT_EQ(NO_ERR, rc);
    
    rc = TradeUpdtByPos(1, tradePos, pUptTradeDat);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = TradeGetByPos(1, pTradeKey , tradePos, &pUptTradeDatChk );
    EXPECT_EQ(NO_ERR, rc);
    EXPECT_EQ(pUptTradeDatChk->bidTrd.prdctId, 6);
    EXPECT_EQ(pUptTradeDatChk->askTrd.prdctId, 6);
    
    rc = TradeMgmtIter(1, &tradePos, &tradeDatTInt1);
    EXPECT_EQ(NO_ERR, rc);
    EXPECT_EQ(tradeDatTInt1.trdKey.trdNo, 0);
    
    rc = TradeAdd(1, &NewTradeDat, &newTradePos);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = TradeMgmtIter(1, &newTradePos, &tradeDatTInt2);
    EXPECT_EQ(NO_ERR, rc);
    EXPECT_EQ(tradeDatTInt2.trdKey.trdNo, 2017091800001);
    
}


TEST(hashTest,LogInit) {
    ResCodeT rc = NO_ERR;
    rc = LogInit((char*)"");

}

int main(int argc, char **argv)
{
    InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}