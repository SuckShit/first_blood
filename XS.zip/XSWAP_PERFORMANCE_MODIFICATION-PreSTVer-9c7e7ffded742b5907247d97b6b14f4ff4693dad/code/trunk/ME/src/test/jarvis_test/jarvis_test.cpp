﻿/***
Created on Sep 20, 2017
@author: Brian.Ping
@version $Id
***/

#include <limits.h>
#include "err_lib.h"    
#include "app_shl.h"            
#include "gtest/gtest.h"
#include "msg_cache.h"
#include "UTILITY/logfile.h"
#include "Utils.h"
#include "order_book.h"
#include "match_lib.h"
#include "mem_txn.h"
#include "uti_tool.h"
#include "user_order.h"
#include "nmbr_srvc.h"
#include "ordr_mgmt.h"
#include "brdg_ordr_mgmt.h"
#include "order_submit.h"
#include "cfg_lib.h"
#include "active_keeper.h"
#include "active_info.h"
#include "ref_data.h"
#include "msg_type.h"
#include "usr.h"
#include "org_info.h"
#include "trade_mgmt.h"
#include "pck_irs_dicdata.h"
#include "order_check.h"
#include "role_prvlg.h"
#include "perf_stat.h"
#include "usr_flg.h"
using ::testing::InitGoogleTest; 

#define SET_MKT_IRS 1
int64 orgIdMa;
int64 usrIdMa;
int64 orgIdZhang;
int64 usrIdZhang;
int32 contractPos;
int64 gCurrentDateBase;
int64 gSpecOrdrIdBase;
int64 gTradeIdBase;

class JarvisCommonTest : public testing::Test {
    protected:  // You should make the members protected s.t. they can be
    virtual void SetUp() 
    {
        

    }

    virtual void TearDown() 
    {
    
    } 
    
    static void SetUpTestCase() {
        
        char appName[] = "";
        PrcsInit(appName);
        
        ResCodeT rc = NO_ERR;
        vectorT *       pSetVct;
        int32           set = 0;
        pUsrBaseInfoT   pUsrMa;
        pUsrBaseInfoT   pUsrZhang;
        pOrgInfoT       pOrgInfo;
        char majingjing[] = "majingjing";
        char zhangkun[] = "zhangkun";
        pRolePrvlgT pRolePrvlg;
        pPerfStatT pShmRoot = NULL;
        int64  txnId = 0;
        int64  timestamp = 0;
        pCntrctBaseInfoT pIrsCntrctInfo;
        int64       timestampDateTime = 0;
        char        date[MAX_DATETIME_LEN] = {0};
        char        time[MAX_DATETIME_LEN] = {0};
        
    
    
        LOG_INFO("########## ServiceManagerInit Begin ##########");
    
        OrdrBkCfgT  ordrBkCfg = {0};
        struct cfgValueS cfgValue = {0};
    
        MemTxnCfgT memTxnCfg[1];
        ShlCfgInfoT     shlCfgInfo = {0};
    
        /* Get config value for the system  */
        rc = GetCfgValue(&cfgValue);
        EXPECT_EQ(NO_ERR, rc);
   
        rc = RefDataLoadFromDB();
        EXPECT_EQ(NO_ERR, rc);
        
        rc = GetAllSetIdsPtr(&pSetVct);
        EXPECT_EQ(NO_ERR, rc);
        
        rc = PerfStatShmCreate(&pShmRoot);
        EXPECT_EQ(NO_ERR, rc);
        
        rc = MsgCreate(4096, 100, 10);
        EXPECT_EQ(NO_ERR, rc);
        
        rc = UsrFlgShmCreate();
        EXPECT_EQ(NO_ERR, rc);
        
        rc = UsrFlgShmLoad();
        EXPECT_EQ(NO_ERR, rc);
    
        while (1)
        {
            /*找到当前主机所负责set*/
            BitFindFS(pSetVct, set + 1, MAX_SET_CNT, &set);
            if (set == -1)
            {
                break;
            }
    
            LOG_DEBUG("create set %d shm", set);
            /* Initialize Order Book Section  */
            ordrBkCfg.nmbrOfOrdr = cfgValue.ttlOrdrNmbr;
            ordrBkCfg.nmbrOfPrdct =  cfgValue.ttlPrdctNmbr;
            ordrBkCfg.setId = set;
            ordrBkCfg.nmbrOfEnty =  cfgValue.ttlEntyNmbr;
    
            rc = OrdrBkShmCreate(&ordrBkCfg);
            EXPECT_EQ(NO_ERR, rc);
    
            rc = OrdrMgmtShmCreate(cfgValue.ttlOrdrNmbr, set);
            EXPECT_EQ(NO_ERR, rc);
    
            rc = NmbrSrvcShmCreate(set);
            EXPECT_EQ(NO_ERR, rc);
    
            rc = BrdgOrdrShmCreate(cfgValue.ttlOrdrNmbr, set);
            EXPECT_EQ(NO_ERR, rc);
    
            rc = MtchrInit(set);
            EXPECT_EQ(NO_ERR, rc);
            
            rc = TradeShmCreate(cfgValue.ttlOrdrNmbr, set);
            EXPECT_EQ(NO_ERR, rc);
            
            TradeShmAttach(set);
            EXPECT_EQ(NO_ERR, rc);
        }
    
        memTxnCfg[0].setId = cfgValue.setId;
        memTxnCfg[0].nmbrOfTxn = cfgValue.nmbrOfTxn;
        memTxnCfg[0].dataSize = cfgValue.dataSize;
    
        rc = MemTxnShmCreateForAllSet(memTxnCfg, 1);
        EXPECT_EQ(NO_ERR, rc); 
        
        rc = IrsUsrInfoGetByNameExt(majingjing, &pUsrMa);
    	EXPECT_EQ( rc, NO_ERR );
    	char token[]= "505284576648012";
    	memcpy(pUsrMa->sesnId, token, sizeof(token));
    	pUsrMa->usrOnlnStatus = TRUE;
    	pUsrMa->roleId[pUsrMa->lgnTp-1] = 1;
    	
    	orgIdMa = pUsrMa->orgId;
    	usrIdMa = pUsrMa->pos;
    	
    	rc = OrgInfoGetByIdExt(orgIdMa, &pOrgInfo);
    	EXPECT_EQ( rc, NO_ERR );
    	
    	orgIdMa = pOrgInfo->pos;
    	pOrgInfo->orgIrsSt = C_ORG_ST_ACTIVE;
    	pOrgInfo->orgSt = ORG_STATUS_ACTIVE;
    	
    	//rc = RolePrvlgAdd(C_ORDSUBMIT_FUNCID, pUsrMa->lgnTp, &pRolePrvlg);
    	//EXPECT_EQ( rc, NO_ERR );
    	
    	rc = IrsUsrInfoGetByNameExt(zhangkun, &pUsrZhang);
    	EXPECT_EQ( rc, NO_ERR );
    	memcpy(pUsrZhang->sesnId, token,sizeof(token));
    	pUsrZhang->usrOnlnStatus = TRUE;
    	pUsrZhang->roleId[pUsrZhang->lgnTp-1] = 1;
    	
    	orgIdZhang = pUsrZhang->orgId;
    	usrIdZhang = pUsrZhang->pos;
    	
    	rc = OrgInfoGetByIdExt(orgIdZhang, &pOrgInfo);
    	EXPECT_EQ( rc, NO_ERR );
    	
    	orgIdZhang = pOrgInfo->pos;
    	pOrgInfo->orgIrsSt = C_ORG_ST_ACTIVE;
    	pOrgInfo->orgSt = ORG_STATUS_ACTIVE;
    	pOrgInfo->crdtVldOrgFlag = 1;
    	
        rc = MemTxnStart(1, &txnId, &timestamp);
        EXPECT_EQ( rc, NO_ERR );
        
        rc = IrsCntrctInfoGetByNameExt("FR007_3M", &pIrsCntrctInfo);
        EXPECT_EQ( rc, NO_ERR );
        
        contractPos = pIrsCntrctInfo->pos;
        
        rc = GetSysTimestamp(&timestampDateTime);
        EXPECT_EQ( rc, NO_ERR );
    
        GetStrDateTime(timestampDateTime,date,time);
        
        gCurrentDateBase = atoll(date)*100000000;
        gSpecOrdrIdBase = atoll(date)*100000;
        gTradeIdBase = atoll(date)*1000000;
    }
    
    
    static void TearDownTestCase() {

    }   
};
 
ResCodeT ChkOrdrInfo(pOrderInfoT pInOrdrInfo, pOrderInfoT pExptOrdrInfo)
{
	
	EXPECT_EQ(pInOrdrInfo->orgId, pExptOrdrInfo->orgId);
	EXPECT_EQ(pInOrdrInfo->traderId, pExptOrdrInfo->traderId);
	EXPECT_EQ(pInOrdrInfo->orderNo, pExptOrdrInfo->orderNo);
	EXPECT_EQ(pInOrdrInfo->extOrdrType, pExptOrdrInfo->extOrdrType);
	EXPECT_EQ(pInOrdrInfo->status, pExptOrdrInfo->status);
	EXPECT_EQ(pInOrdrInfo->ordrMask, pExptOrdrInfo->ordrMask);
	
	EXPECT_EQ(strcmp(pInOrdrInfo->rqstId, pExptOrdrInfo->rqstId), 0);
	
	EXPECT_EQ(pInOrdrInfo->contractPos, pExptOrdrInfo->contractPos);
	EXPECT_EQ(pInOrdrInfo->qty, pExptOrdrInfo->qty);
	EXPECT_EQ(pInOrdrInfo->remain, pExptOrdrInfo->remain);
	EXPECT_EQ(pInOrdrInfo->price, pExptOrdrInfo->price);
	EXPECT_EQ(pInOrdrInfo->specOrdrId, pExptOrdrInfo->specOrdrId);
	EXPECT_EQ(pInOrdrInfo->createTime, pExptOrdrInfo->createTime);
	EXPECT_EQ(pInOrdrInfo->activateTime, pExptOrdrInfo->activateTime);
	EXPECT_EQ(pInOrdrInfo->updateTime, pExptOrdrInfo->updateTime);
	EXPECT_EQ(pInOrdrInfo->expireTime, pExptOrdrInfo->expireTime);
	EXPECT_EQ(pInOrdrInfo->closePositionCD, pExptOrdrInfo->closePositionCD);
	
	EXPECT_EQ(pInOrdrInfo->apiId == pExptOrdrInfo->apiId, TRUE);
	EXPECT_EQ(pInOrdrInfo->orgCd == pExptOrdrInfo->orgCd, TRUE);

}


ResCodeT ChkDealInfo(pDealInfoT pDealInfo, pDealInfoT pExptDealInfo)
{
	
	
	EXPECT_EQ(pDealInfo->bidOrdNo, pExptDealInfo->bidOrdNo);
	EXPECT_EQ(pDealInfo->bidOrgIdx, pExptDealInfo->bidOrgIdx);
	EXPECT_EQ(pDealInfo->bidUsrIdx, pExptDealInfo->bidUsrIdx);
	
	EXPECT_EQ(pDealInfo->askOrdNo, pExptDealInfo->askOrdNo);
	EXPECT_EQ(pDealInfo->askOrgIdx, pExptDealInfo->askOrgIdx);
	EXPECT_EQ(pDealInfo->askUsrIdx, pExptDealInfo->askUsrIdx);
	
	EXPECT_EQ(pDealInfo->tradeNo, pExptDealInfo->tradeNo);
	EXPECT_EQ(pDealInfo->contractPos, pExptDealInfo->contractPos);
	EXPECT_EQ(pDealInfo->trdAmount, pExptDealInfo->trdAmount);
	EXPECT_EQ(pDealInfo->trdPrice, pExptDealInfo->trdPrice);
	EXPECT_EQ(pDealInfo->trdDateTime, pExptDealInfo->trdDateTime);
	EXPECT_EQ(pDealInfo->trdSts, pExptDealInfo->trdSts);
	
}



ResCodeT FormatNewOrderSingleReqT(char*               token,
                                  int64               ordId,
                                  int32               userIdx,
                                  int32               contractPos,
                                  int16               side,
                                  int64               price,
                                  int64               qty,
                                  int64               effectTime,
                                  int32               ordType,
                                  int32               extOrdType,
                                  int32               execInst,
                                  int32               orgIdx,
                                  int16               ordAction,
                                  int64               ocoId,
                                  int64               priceAsk,
                                  int64               qtyAsk,
                                  int32               apiLoginUsrIdx,//new added
                                  int64               apiRqstId,
                                  int64               forceId, 
                                  pNewOrderSingleReqT pOrderAdd)
{
    memset(pOrderAdd, 0, sizeof(NewOrderSingleReqT));
    
    memcpy(pOrderAdd->token, token, MAX_TOKEN_LENTH);
    
    pOrderAdd->newOrdrInfo.ordId = ordId;
    pOrderAdd->newOrdrInfo.userIdx = userIdx;
    pOrderAdd->newOrdrInfo.contractPos = contractPos;
    
    pOrderAdd->newOrdrInfo.prcQtyInfo.price = price;
    pOrderAdd->newOrdrInfo.prcQtyInfo.qty = qty;
    
    pOrderAdd->newOrdrInfo.effectTime = effectTime;
    pOrderAdd->newOrdrInfo.ordType = ordType;
    pOrderAdd->newOrdrInfo.extOrdType = extOrdType;
    pOrderAdd->newOrdrInfo.execInst = execInst;
    pOrderAdd->newOrdrInfo.orgIdx = orgIdx;
    pOrderAdd->newOrdrInfo.side = side;
    pOrderAdd->newOrdrInfo.ordAction = ordAction;
    pOrderAdd->newOrdrInfo.apiLoginUsrIdx = apiLoginUsrIdx;
    pOrderAdd->newOrdrInfo.ocoId = ocoId;
    pOrderAdd->newOrdrInfo.apiRqstId = apiRqstId;
    pOrderAdd->newOrdrInfo.forceId = forceId;
    
    pOrderAdd->askPrcQtyInfo.price = priceAsk;
    pOrderAdd->askPrcQtyInfo.qty = qtyAsk;
}


ResCodeT FormatOrderInfoT(int32             orgId,
                          int32             traderId,
                          int64             orderNo,
                          int16             extOrdrType,
                          int16             status,
                          int16             ordrMask,
                          char*             rqstId,
                          int64             contractPos,
                          int64             qty,
                          int64             remain,
                          int64             price,
                          int64             specOrdrId,
                          int64             createTime,
                          int64             activateTime,
                          int64             updateTime,
                          int64             expireTime,
                          int64             closePositionCD,
                          char              apiId,
                          char              orgCd,
                          pOrderInfoT       pOrderInfoAddRsp)
{
    memset(pOrderInfoAddRsp, 0, sizeof(OrderInfoT));
    
    pOrderInfoAddRsp->orgId = orgId;
    pOrderInfoAddRsp->traderId = traderId;
    pOrderInfoAddRsp->orderNo = orderNo;
    pOrderInfoAddRsp->extOrdrType = extOrdrType;
    pOrderInfoAddRsp->status = status;
    pOrderInfoAddRsp->ordrMask = ordrMask;
    memcpy(pOrderInfoAddRsp->rqstId, rqstId, 2);
    pOrderInfoAddRsp->contractPos = contractPos;
    pOrderInfoAddRsp->qty = qty;
    pOrderInfoAddRsp->remain = remain;
    pOrderInfoAddRsp->price = price;
    pOrderInfoAddRsp->specOrdrId = specOrdrId;
    pOrderInfoAddRsp->createTime = createTime;
    pOrderInfoAddRsp->activateTime = activateTime;
    pOrderInfoAddRsp->updateTime = updateTime;
    pOrderInfoAddRsp->expireTime = expireTime;
    pOrderInfoAddRsp->closePositionCD = closePositionCD;
    pOrderInfoAddRsp->apiId = apiId;
    pOrderInfoAddRsp->orgCd = orgCd;
}



ResCodeT FormatOrderCancelRequestReqT(int32                     userIdx,
                                      char*                     token,
                                      int64                     ordId,
                                      int64                     ocoId,
                                      int64                     apiRqstId,
                                      int64                     apiLoginUsrIdx,
                                      int64                     orgIdx,
                                      int64                     apiCancelRqstId,
                                      int64                     apiCancelType,
                                      pOrderCancelRequestReqT   pOrderCncl
                                      )
{
    memset(pOrderCncl, 0, sizeof(OrderCancelRequestReqT));
    
    pOrderCncl->userIdx = userIdx;
    memcpy(pOrderCncl->token, token, MAX_TOKEN_LENTH);
    pOrderCncl->ordId = ordId;
    pOrderCncl->ocoId = ocoId;
    pOrderCncl->apiRqstId = apiRqstId;
    pOrderCncl->apiLoginUsrIdx = apiLoginUsrIdx;
    pOrderCncl->orgIdx = orgIdx;
    pOrderCncl->apiCancelRqstId = apiCancelRqstId;
    pOrderCncl->apiCancelType = apiCancelType;
}



ResCodeT FormatDealInfoT(int64       tradeNo,
                         int32       contractPos,
                         int64       trdAmount,
                         int64       trdPrice,
                         int64       trdDateTime,
                         int16       trdSts,
                         int64       bidOrdNo, 
                         int64       askOrdNo,
                         int32       bidOrgIdx,     
                         int32       askOrgIdx,     
                         int32       bidUsrIdx,
                         int32       askUsrIdx,
                         int64       trdDate,
                         int16       trdMthd,
                         int64       bidToAskLastCredit,
                         int64       askToBidLastCredit,
                         int16       bidTradeType,
                         int16       askTradeType,
                         int16       tradeSubType,
                         int64       updateTime,
                         int16       calcOrg,
                         int32       rowNum,
                         int64       bidAccntNo,
                         int64       bidStlmntAccntNo,
                         int32       termLimit,
                         int32       interestDaysChange,
                         int64       interestFirstDay,
                         int64       dlvryDtDay,
                         int64       interestPayforDaysChange,
                         int16       stleTp,
                         int32       interestBidPayPrd,
                         int64       interestBidDlvryDt,
                         int64       interestBidInterestBnchmk,
                         int64       refCntrct,
                         int64       interestSprd,
                         int64       interestOfferDlvryDt,
                         int32       interestOfferPayPrd,
                         int64       interestConfirmFirstDay,
                         int32       interestOfferResetRate,
                         int32       interestOfferTp,
                         int32       interestOfferInterestBnchmk,
                         pDealInfoT  pDealInfo)
{
    memset(pDealInfo, 0, sizeof(DealInfoT));
    
    pDealInfo->tradeNo = tradeNo;
    pDealInfo->contractPos = contractPos;
    pDealInfo->trdAmount = trdAmount;
    pDealInfo->trdPrice = trdPrice;
    pDealInfo->trdDateTime = trdDateTime;
    pDealInfo->trdSts = trdSts;
    pDealInfo->bidOrdNo = bidOrdNo;
    pDealInfo->askOrdNo = askOrdNo;
    pDealInfo->bidOrgIdx = bidOrgIdx;
    pDealInfo->askOrgIdx = askOrgIdx;
    pDealInfo->bidUsrIdx = bidUsrIdx;
    pDealInfo->askUsrIdx = askUsrIdx;
    pDealInfo->trdDate = trdDate;
    pDealInfo->trdMthd = trdMthd;
    pDealInfo->bidToAskLastCredit = bidToAskLastCredit;
    pDealInfo->askToBidLastCredit = askToBidLastCredit;
    pDealInfo->bidTradeType = bidTradeType;
    pDealInfo->askTradeType = askTradeType;
    pDealInfo->tradeSubType = tradeSubType;
    pDealInfo->updateTime = updateTime;
    pDealInfo->calcOrg = calcOrg;
    pDealInfo->rowNum = rowNum;
    pDealInfo->bidAccntNo = bidAccntNo;
    pDealInfo->bidStlmntAccntNo = bidStlmntAccntNo;
    pDealInfo->termLimit = termLimit;
    pDealInfo->interestDaysChange = interestDaysChange;
    pDealInfo->interestFirstDay = interestFirstDay;
    pDealInfo->dlvryDtDay = dlvryDtDay;
    pDealInfo->interestPayforDaysChange = interestPayforDaysChange;
    pDealInfo->stleTp = stleTp;
    pDealInfo->interestBidPayPrd = interestBidPayPrd;
    pDealInfo->interestBidDlvryDt = interestBidDlvryDt;
    pDealInfo->interestBidInterestBnchmk = interestBidInterestBnchmk;
    pDealInfo->refCntrct = refCntrct;
    pDealInfo->interestSprd = interestSprd;
    pDealInfo->interestOfferDlvryDt = interestOfferDlvryDt;
    pDealInfo->interestOfferPayPrd = interestOfferPayPrd;
    pDealInfo->interestConfirmFirstDay = interestConfirmFirstDay;
    pDealInfo->interestOfferResetRate = interestOfferResetRate;
    pDealInfo->interestOfferTp = interestOfferTp;
    pDealInfo->interestOfferInterestBnchmk = interestOfferInterestBnchmk;
}


ResCodeT FormatDealCancelRequestReqT(int32                  userIdx,
                                     int32                  officerIdx,
                                     char*                  token,
                                     int64                  dealId,
                                     pDealCancelRequestReqT pCnclDealReq)
{
    memset(pCnclDealReq, 0, sizeof(DealCancelRequestReqT));
    
    pCnclDealReq->userIdx = userIdx;
    pCnclDealReq->officerIdx = officerIdx;
    strcpy(pCnclDealReq->token, token);
    pCnclDealReq->dealId = dealId;
}




TEST_F(JarvisCommonTest, NormalOrdrAdd) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq, sRsp;
    int64          timestamp;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT orderAdd = {0};
    OrderInfoT  orderInfoAddRsp = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    
    /* Do Order Add*/
    
                             /* token,           ordId, userIdx, contractPos, side, price, qty,        effectTime,       ordType */
    FormatNewOrderSingleReqT("505284576648012",   0,     usrIdMa, contractPos,   0,   250,   250000000, 1505300400000000, 1, 
                             /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId, output*/
                                1,          4,        orgIdMa,    1,          0,       0,     -1,             0,         0,         0,  &orderAdd);
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,   usrIdMa, gCurrentDateBase+1, 1,           1,      16,       "",  contractPos, 250000000, 250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd,       output */
                       1505284587941003, 1505284587941003, 1505284587941003, 1505300400000000, 0,              0,     0,     &orderInfoAddRsp);

    
    memcpy(&sReq.msgBody, &orderAdd, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = OrderSubmitMessage(&sReq,&sRsp,orderInfoAddRsp.createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1); 

    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoAddRsp);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}




TEST_F(JarvisCommonTest, NormalOrdrSave) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    //pNewDealCnfrmT  pDealCnfrm = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT orderSave = {0};
    OrderInfoT orderInfoSaveRsp = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    /* Do Order Save*/
    
                                   /* token,           ordId, userIdx, contractPos, side,  price, qty,        effectTime,       ordType */
    FormatNewOrderSingleReqT("505284576648012",       0,     usrIdMa,   contractPos,  0,   250,   250000000, 1505300400000000,     0, 
                                   /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId, output*/
                                      0,           6,        orgIdMa,      1,          0,    0,      -1,            0,         0,         0,  &orderSave);
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos,     qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,   usrIdMa, gCurrentDateBase+2, 0,           4,      16,       "",     contractPos, 250000000, 250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd, output */
                       1505284818877676,           0, 1505284818877676, 1505300400000000, 0,              0,     0,  &orderInfoSaveRsp);

    
    memcpy(&sReq.msgBody, &orderSave, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSAVING_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 

    rc = OrderSaveMessage(&sReq,&sRsp,orderInfoSaveRsp.createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1);
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
     
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoSaveRsp);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}




TEST_F(JarvisCommonTest, NormalOrdrCncl) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    int32          msgType;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT orderAdd = {0};
    OrderInfoT  orderInfoAddRsp = {0};
    OrderCancelRequestReqT orderCncl = {0};
    OrderInfoT orderInfoCnclRsp = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
     /* Do Order Add*/
    
                             /* token,           ordId, userIdx, contractPos, side, price, qty,        effectTime,    ordType */
    FormatNewOrderSingleReqT("505284576648012",  0,     usrIdMa,   contractPos,  0,    250,   250000000, 1505300400000000,  1, 
                               /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId, output */
                                  1,          4,        orgIdMa,  1,         0 ,       0,     0,           -1,         0,         0,  &orderAdd);
                                            
                   /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos,   qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa, usrIdMa, gCurrentDateBase+3, 1,           1,      16,       "",     contractPos, 250000000, 250000000, 250,   0, 
                   /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd， output */
                      1505284587941003, 1505284587941003, 1505284587941003, 1505300400000000, 0,              0,       0, &orderInfoAddRsp);

    
    memcpy(&sReq.msgBody, &orderAdd, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = OrderSubmitMessage(&sReq,&sRsp,orderInfoAddRsp.createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1);
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
     
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoAddRsp);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
    
    

    /* Do Order Cncl*/
    
                                   /* userInx,           token,                ordrId,     ocoid,    apiRqstId, apiLoginUsrIdx, orgIdx, apiCancelRqstId, apiCancelType, output*/
    FormatOrderCancelRequestReqT(  usrIdMa,      "505284576648012",  gCurrentDateBase+03,       0,      0,            -1,          0,             0,             0,    &orderCncl);
                                            
                   /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,   usrIdMa,gCurrentDateBase+3, 1,         3,      16,       "",  contractPos,          250000000, 250000000, 250,   0, 
                   /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd,    output */
                      1505284587941003,          0, 1505285596519558, 1505300400000000, 0,              0,     0 ,  &orderInfoCnclRsp);

    
    memcpy(&sReq.msgBody, &orderCncl, sizeof(OrderCancelRequestReqT));
    msgType = MSG_TYPE_ORDER_CANCEL_MESSAGE;
    
    rc = RolePrvlgAdd(C_ORDCANCEL_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsOrderCnclMsg(msgType, &sReq,&sRsp,orderInfoCnclRsp.updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRspCnal =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRspCnal->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRspCnal->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
    
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoCnclRsp);
    
    rc = MsgDelete(pOrdrActlRspCnal->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}




TEST_F(JarvisCommonTest, NormalOrdrActv) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    int32          msgType;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT orderSave = {0};
    OrderInfoT orderInfoSaveRsp = {0};
    OrderCancelRequestReqT orderActv = {0};
    OrderInfoT orderInfoActvRsp = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    
    /* Do Order Save*/
    
                             /* token,           ordId, userIdx, contractPos, side, price, qty,        effectTime,       ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,     usrIdMa,   contractPos,0,    250,   250000000, 1505311200000000, 0, 
                             /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId, output*/
                                0,          6,        orgIdMa,    1,          0,     0,       0,             -1,          0,        0,  &orderSave);
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,   usrIdMa,gCurrentDateBase+4, 0,           4,      16,       "", contractPos,  250000000, 250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd,  output */
                       1505305119907331,           0, 1505305119907331, 1505311200000000,       0,              0,     0,    &orderInfoSaveRsp);
    
    memcpy(&sReq.msgBody, &orderSave, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSAVING_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = OrderSaveMessage(&sReq,&sRsp,orderInfoSaveRsp.createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoSaveRsp);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
    
    
    
    /* Do Order Actv*/
    
                                   /* userInx,           token,                ordrId,     ocoid,  apiRqstId, apiLoginUsrIdx, orgIdx, apiCancelRqstId, apiCancelType, output  */
    FormatOrderCancelRequestReqT( usrIdMa,    "505284576648012",  gCurrentDateBase+4,       0 ,      0,             0,          0,             0,             0,    &orderActv);
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa, usrIdMa,gCurrentDateBase+4, 0,           1,      16,       "",     contractPos, 250000000, 250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd, output */
                       1505305119907331, 1505305454751522, 1505305454751522, 1505311200000000, 0,              0,     0,  &orderInfoActvRsp);

    
    memcpy(&sReq.msgBody, &orderActv, sizeof(OrderCancelRequestReqT));
    msgType = MSG_TYPE_ORDER_ACTIVATE_MESSAGE;
    
    rc = RolePrvlgAdd(C_ORDACTIVATE_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsOrderActvtMsg(msgType,&sReq,&sRsp,orderInfoActvRsp.updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRspActv =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRspActv->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRspActv->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoActvRsp);
    
    rc = MsgDelete(pOrdrActlRspActv->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}




TEST_F(JarvisCommonTest, NormalOrdrFrz) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    int32          msgType;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT orderAdd = {0};
    OrderInfoT  orderInfoAddRsp = {0};
    OrderCancelRequestReqT orderFrz = {0};
    OrderInfoT orderInfoFrzRsp = {0};
    OrderCancelRequestReqT orderActv = {0};
    OrderInfoT orderInfoActvRsp = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
     /* Do Order Add*/
    
                               /* token,           ordId, userIdx, contractPos, side, price, qty,        effectTime,       ordType */
    FormatNewOrderSingleReqT("505284576648012",   0,     usrIdMa,   contractPos,  0,   250,   250000000, 1505386800000000,    1, 
                                     /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId, output*/
                                        1,          4,      orgIdMa,    1,         0,        0,     0,           -1,           0,        0,  &orderAdd );
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa, usrIdMa, gCurrentDateBase+5, 1,           1,      16,       "",     contractPos,   250000000, 250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd, output */
                       1505358954471511, 1505358954471511, 1505358954471511, 1505386800000000, 0,              0,      0,  &orderInfoAddRsp);
    
    memcpy(&sReq.msgBody, &orderAdd, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = OrderSubmitMessage(&sReq,&sRsp,orderInfoAddRsp.updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoAddRsp);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
    
    
    
    /* Do Order Frz*/
    
                                   /* userInx,           token,                ordrId,     ocoid, apiRqstId, apiLoginUsrIdx, orgIdx, apiCancelRqstId, apiCancelType, output  */
    FormatOrderCancelRequestReqT(  usrIdMa,    "505284576648012",  gCurrentDateBase+05,       0,    0,            -1,          0,             0,             0,    &orderFrz );
                                            
                   /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,usrIdMa,    gCurrentDateBase+5, 1,           4,      16,       "",  contractPos,  250000000, 250000000, 250,   0, 
                   /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd,     output */
                      1505358954471511,           0, 1505359082309422, 1505386800000000,     0,              0,     0, &orderInfoFrzRsp );

    
    memcpy(&sReq.msgBody, &orderFrz, sizeof(OrderCancelRequestReqT));
    msgType = MSG_TYPE_ORDER_FREEZE_MESSAGE;
    
    rc = RolePrvlgAdd(C_ORDFREEZE_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsOrderFrzMsg(msgType,&sReq,&sRsp,orderInfoFrzRsp.updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRspFrz =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRspFrz->slotCnt, 1);
    
    rc = MsgGetSlot(pOrdrActlRspFrz->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
     
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoFrzRsp);
    
    rc = MsgDelete(pOrdrActlRspFrz->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);



/* Do Order Actv*/
    
                                 /* userInx,           token,                ordrId,     ocoid  apiRqstId, apiLoginUsrIdx, orgIdx, apiCancelRqstId, apiCancelType, output  */
    FormatOrderCancelRequestReqT( usrIdMa,      "505284576648012",  gCurrentDateBase+5,       0,         0,             -1,          0,             0,             0,    &orderActv );
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos,     qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,   usrIdMa,gCurrentDateBase+5, 1,           1,      16,       "",     contractPos, 250000000, 250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd, output*/
                       1505358954471511, 1505359180112998, 1505359180112998, 1505386800000000, 0,              0,      0, &orderInfoActvRsp);

    
    memcpy(&sReq.msgBody, &orderActv, sizeof(OrderCancelRequestReqT));
    msgType = MSG_TYPE_ORDER_ACTIVATE_MESSAGE;
    
    rc = RolePrvlgAdd(C_ORDACTIVATE_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsOrderActvtMsg(msgType,&sReq,&sRsp,orderInfoActvRsp.updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRspActv =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRspActv->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRspActv->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
    
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoActvRsp);
    
    rc = MsgDelete(pOrdrActlRspActv->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);

}




TEST_F(JarvisCommonTest, BilOrdrAdd) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT bilOrderAdd = {0};
    OrderInfoT bilOrderInfoAddRsp[2] = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    /* Do Order Add*/
    
                             /* token,           ordId, userIdx, contractPos, side,  price,  qty,        effectTime,    ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,     usrIdMa,   contractPos,  0,   250,   250000000, 1505300400000000, 0, 
                             /* extOrdType, execInst, orgIdx, ordAction, ocoId, price,    qty,  apiLoginUsrIdx,  apiRqstId,  forceId,   output*/
                                5,          9,        orgIdMa,  1,          0,     250,  250000000,        -1,           0,        0, &bilOrderAdd);
                                            
                     /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa, usrIdMa, gCurrentDateBase+6, 5,           1,      16,       "",     contractPos, 250000000, 250000000, 250,   gSpecOrdrIdBase+1, 
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD,     apiId, orgCd,   output */
                        1505285009248890, 1505285009248890, 	1505285009248890, 1505300400000000,          0,              0,     0, &bilOrderInfoAddRsp[0]),
                     /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT(orgIdMa, usrIdMa, gCurrentDateBase+7, 5,           1,         17,     "",    contractPos, 250000000, 250000000, 250,   gSpecOrdrIdBase+1,
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD,  apiId,  orgCd,     output */
                        1505285009248891, 1505285009248891,  1505285009248891, 1505300400000000,          0,              0,     0,  &bilOrderInfoAddRsp[1]);

    
    memcpy(&sReq.msgBody, &bilOrderAdd, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_BILORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = BilOrderSubmitMessage(&sReq,&sRsp,bilOrderInfoAddRsp[0].createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1);
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
         
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &bilOrderInfoAddRsp[0]);
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &bilOrderInfoAddRsp[1]);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}



TEST_F(JarvisCommonTest, BilOrdrSave) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT bilOrderSave = {0};
    OrderInfoT bilOrderInfoSaveRsp[2] = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    pCntrctBaseInfoT pCntrctInfo;
    int32       conPos;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    rc = IrsCntrctInfoGetByNameExt("FR007_6M", &pCntrctInfo);
    EXPECT_EQ( rc, NO_ERR );
    
    conPos = pCntrctInfo->pos;
    
    /* Do BilOrder Save*/
    
                            /* token,           ordId, userIdx, contractPos, side, price,  qty,        effectTime,    ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,    usrIdMa,  conPos,        0,  250,   250000000, 1505300400000000, 0, 
                            /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price,   qty,  apiLoginUsrIdx,  apiRqstId,  forceId,   output*/
                               5,          6,       orgIdMa,    1,          0,       250,  250000000,        0,           0,        0, &bilOrderSave);
                                            
                     /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT(orgIdMa, usrIdMa, gCurrentDateBase+8, 5,           4,      16,       "",     conPos,      250000000, 250000000, 250,  gSpecOrdrIdBase+2, 
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,  output */
                        1505285009248890,                0, 	              0, 1505300400000000,          0,              0,  0, &bilOrderInfoSaveRsp[0]),
                     /* orgId, traderId, orderNo,      extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT(orgIdMa,  usrIdMa,gCurrentDateBase+9, 5,           4,         17,     "",   conPos,   250000000, 250000000, 250,   gSpecOrdrIdBase+2,
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,   output */
                        1505285009248890,                 0,               0, 1505300400000000,          0,              0,     0, &bilOrderInfoSaveRsp[1]);
    
    memcpy(&sReq.msgBody, &bilOrderSave, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_BILORDSAVING_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = BilOrderSaveMessage(&sReq,&sRsp,bilOrderInfoSaveRsp[0].createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &bilOrderInfoSaveRsp[0]);
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &bilOrderInfoSaveRsp[1]);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);

}



TEST_F(JarvisCommonTest, BilOrdrCncl) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    int32          msgType;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT bilOrderAdd = {0};
    OrderInfoT bilOrderInfoAddRsp[2] = {0};
    OrderCancelRequestReqT BilOrderCncl = {0};
    OrderInfoT BilOrderInfoCnclRsp[2] = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    pCntrctBaseInfoT pCntrctInfo;
    int32       conPos;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    rc = IrsCntrctInfoGetByNameExt("FR007_9M", &pCntrctInfo);
    EXPECT_EQ( rc, NO_ERR );
    
    conPos = pCntrctInfo->pos;
    
    /* Do Order Add*/
    
                             /* token,           ordId, userIdx, contractPos, side, price, qty,        effectTime,    ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,     usrIdMa,  conPos,         0,  250,   250000000, 1505300400000000, 0, 
                             /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price,    qty, apiLoginUsrIdx,  apiRqstId,  forceId,   output*/
                                 5,          9,        orgIdMa, 1,         0,     250,     250000000,        0,           0,        0, &bilOrderAdd);
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa, usrIdMa,  gCurrentDateBase+10, 5,           1,      16,       "",     conPos,   250000000, 250000000, 250,   gSpecOrdrIdBase+3, 
                    /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,       output */
                       1505285009248890, 1505285009248890, 	1505285009248890, 1505300400000000,          0,              0,     0, &bilOrderInfoAddRsp[0] ),
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT(orgIdMa, usrIdMa, gCurrentDateBase+11, 5,           1,         17,     "",    conPos,     250000000, 250000000, 250,   gSpecOrdrIdBase+3,
                    /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd, o     utput */
                       1505285009248891, 1505285009248891,  1505285009248891, 1505300400000000,          0,              0,     0, &bilOrderInfoAddRsp[1] );

    
    memcpy(&sReq.msgBody, &bilOrderAdd, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_BILORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = BilOrderSubmitMessage(&sReq,&sRsp,bilOrderInfoAddRsp[0].createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
    
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &bilOrderInfoAddRsp[0]);
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &bilOrderInfoAddRsp[1]);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);



    /* Do BilOrder Cncl*/
    
                                    /* userInx,           token,            ordrId,     ocoid    apiRqstId, apiLoginUsrIdx, orgIdx, apiCancelRqstId, apiCancelType, output*/
    FormatOrderCancelRequestReqT(  usrIdMa,    "505284576648012",  gSpecOrdrIdBase+3,       0,         0,             0,          0,             0,             0,    &BilOrderCncl);
                                            
                       /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT(orgIdMa, usrIdMa,    gCurrentDateBase+10, 5,           3,      16,       "",     conPos,    250000000, 250000000, 250,   gSpecOrdrIdBase+3, 
                       /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd, output */
                          1505285009248890,               0,   1505285009248891, 1505300400000000,          0,              0,     0, &BilOrderInfoCnclRsp[0] ),
                     /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT( orgIdMa, usrIdMa,  gCurrentDateBase+11, 5,           3,         17,     "",    conPos,   250000000, 250000000, 250,   gSpecOrdrIdBase+3,
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd, output*/
                        1505285009248891,                  0,  1505285009248891, 1505300400000000,          0,              0,     0, &BilOrderInfoCnclRsp[1]);

    memcpy(&sReq.msgBody, &BilOrderCncl, sizeof(OrderCancelRequestReqT));
    msgType = MSG_TYPE_BILORDER_CANCEL_MESSAGE;
    
    rc = RolePrvlgAdd(C_BILORDCANCEL_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsOrderCnclMsg(msgType,&sReq,&sRsp,BilOrderInfoCnclRsp[0].updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRspCnal =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRspCnal->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRspCnal->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
    
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &BilOrderInfoCnclRsp[0]);
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &BilOrderInfoCnclRsp[1]);
    
    rc = MsgDelete(pOrdrActlRspCnal->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}



TEST_F(JarvisCommonTest, BilOrdrFrz) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    int32          msgType;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT bilOrderAdd = {0};
    OrderInfoT bilOrderInfoAddRsp[2] = {0};
    OrderCancelRequestReqT BilOrderFrz = {0};
    OrderInfoT BilOrderInfoFrzRsp[2] = {0};
    UsrBaseInfoT usr;
    pRolePrvlgT pRolePrvlg;
    pCntrctBaseInfoT pCntrctInfo;
    int32       conPos;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    rc = IrsCntrctInfoGetByNameExt("FR007_1Y", &pCntrctInfo);
    EXPECT_EQ( rc, NO_ERR );
    
    conPos = pCntrctInfo->pos;
    
    /* Do Order Add*/
    
                             /* token,           ordId, userIdx, contractPos, side, price, qty,        effectTime,       ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,     usrIdMa,   conPos,       0,   250,   250000000, 1505300400000000,  0, 
                                     /* extOrdType, execInst, orgIdx, ordAction, ocoId,  price,        qty,  apiLoginUsrIdx,  apiRqstId,  forceId,   output*/
                                        5,          9,     orgIdMa,    1,          0,     250,     250000000,        0,           0,           0,   &bilOrderAdd);
                                            
                     /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId, createTime, activateTime, updateTime, expireTime, closePositionCD, apiId, orgCd */          
    FormatOrderInfoT(orgIdMa,  usrIdMa,   gCurrentDateBase+12, 5,           1,      16,       "",     conPos,    250000000, 250000000, 250,   gSpecOrdrIdBase+4, 
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,       output */
                        1505285009248890, 1505285009248890, 	1505285009248890, 1505300400000000,          0,              0,     0, &bilOrderInfoAddRsp[0]),
                     /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT( orgIdMa, usrIdMa,    gCurrentDateBase+13, 5,           1,         17,     "",  conPos,   250000000, 250000000, 250,   gSpecOrdrIdBase+4,
                     /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,        output*/
                        1505285009248891, 1505285009248891,  1505285009248891, 1505300400000000,          0,              0,     0, &bilOrderInfoAddRsp[1]);

    
    memcpy(&sReq.msgBody, &bilOrderAdd, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_BILORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = BilOrderSubmitMessage(&sReq,&sRsp,bilOrderInfoAddRsp[0].createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRsp->slotCnt, 1);
    
    rc = MsgGetSlot(pOrdrActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
         
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &bilOrderInfoAddRsp[0]);
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &bilOrderInfoAddRsp[1]);
    
    rc = MsgDelete(pOrdrActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);



    /* Do BilOrder Frz*/
    
                                   /* userInx,           token,             ordrId,     ocoid  apiRqstId, apiLoginUsrIdx, orgIdx, apiCancelRqstId, apiCancelType,     output  */
    FormatOrderCancelRequestReqT(  usrIdMa,    "505284576648012",  gSpecOrdrIdBase+4,       0,      0,             0,          0,             0,             0,  &BilOrderFrz);
                                            
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
	FormatOrderInfoT(orgIdMa, usrIdMa,  gCurrentDateBase+12, 5,           4,      16,       "",    conPos,    250000000, 250000000, 250,   gSpecOrdrIdBase+4, 
                    /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,  output*/
                       1505285009248890,              0, 	1505285009248891, 1505300400000000,          0,              0,     0, &BilOrderInfoFrzRsp[0] ),
                    /* orgId, traderId, orderNo,          extOrdrType, status, ordrMask, rqstId, contractPos, qty,       remain,    price, specOrdrId,*/
    FormatOrderInfoT(orgIdMa, usrIdMa,  gCurrentDateBase+13, 5,           4,         17,     "",    conPos,   250000000, 250000000, 250,   gSpecOrdrIdBase+4,
                    /* createTime,           activateTime,       updateTime,       expireTime,      closePositionCD, apiId, orgCd,       output*/
                       1505285009248891,               0,  1505285009248891, 1505300400000000,          0,              0,     0, &BilOrderInfoFrzRsp[1]);

    memcpy(&sReq.msgBody, &BilOrderFrz, sizeof(OrderCancelRequestReqT));
    msgType = MSG_TYPE_BILORDER_FREEZE_MESSAGE;
    
    rc = RolePrvlgAdd(C_BILORDFREEZE_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsOrderFrzMsg(msgType,&sReq,&sRsp,BilOrderInfoFrzRsp[0].updateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrActlRspFrz =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrActlRspFrz->slotCnt, 1); 
    
    rc = MsgGetSlot(pOrdrActlRspFrz->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &BilOrderInfoFrzRsp[0]);
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &BilOrderInfoFrzRsp[1]);
    
    rc = MsgDelete(pOrdrActlRspFrz->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
}





TEST_F(JarvisCommonTest, DealCncl) {
    ResCodeT rc = NO_ERR;
    IntrnlMsgT     sReq = {0}, sRsp = {0};
    int64          timestamp;
    CallBackCtxT   ctx;
    pMsgCacheSlotT  pReqSlot = NULL;
    pNewDealCnfrmT  pDealCnfrm = NULL;
    pNewOrderCnfrmT pOrderCnfrm = NULL;
    NewOrderSingleReqT orderAddBid = {0};
    OrderInfoT  orderInfoAddRspBid = {0};
    NewOrderSingleReqT orderAddAsk = {0};
    OrderInfoT  orderInfoAddRspAsk = {0};
    DealInfoT  DealInfo = {0};
    DealCancelRequestReqT CnclDealReq = {0};
    DealInfoT  DealInfoCncl = {0};
    UsrBaseInfoT usr,usrZh;
    pRolePrvlgT pRolePrvlg;
    pUsrBaseInfoT pUsrAdmin = NULL;
    
    sReq.msgHdr.setId = SET_MKT_IRS;
    
    
    
    /* Do Order Add*/
    
                              /* token,           ordId, userIdx, contractPos,  side, price,     qty,        effectTime,   ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,     usrIdMa,  contractPos,     0,   250,   250000000, 1505300400000000,   1, 
                              /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId,   output*/
                                 1,          4,        orgIdMa,    1,         0,    0,     0,        0,           0,           0,   &orderAddBid);
                                            
                    /* orgId,       traderId,      orderNo,    extOrdrType, status, ordrMask, rqstId, contractPos,       qty,       remain,  price, specOrdrId,  */          
    FormatOrderInfoT(orgIdMa,   usrIdMa,    gCurrentDateBase+14, 1,           1,      16,       "",   contractPos,  250000000,     250000000, 250,   0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd, output */
                       1505284587941003, 1505284587941003, 1505284587941003, 1505300400000000, 0,              0,     0, &orderInfoAddRspBid);

    
    memcpy(&sReq.msgBody, &orderAddBid, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdMa, &usr);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSUBMIT_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = OrderSubmitMessage(&sReq,&sRsp,orderInfoAddRspBid.createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrBidActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrBidActlRsp->slotCnt, 1); 
        
    rc = MsgGetSlot(pOrdrBidActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
        
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[0], &orderInfoAddRspBid);
    
    rc = MsgDelete(pOrdrBidActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
    
    
    memset(&sReq, 0 ,sizeof(IntrnlMsgT));
    memset(&sRsp, 0 ,sizeof(IntrnlMsgT));
    memset(pReqSlot, 0 ,sizeof(MsgCacheSlotT));
    memset(pOrderCnfrm, 0 ,sizeof(NewOrderCnfrmT));
    sReq.msgHdr.setId = SET_MKT_IRS;
    /* Do Order Add*/
    
                            /* token,           ordId, userIdx, contractPos,      side, price,      qty,      effectTime,  ordType */
    FormatNewOrderSingleReqT("505284576648012", 0,     usrIdZhang, contractPos,      1,   250,   250000000, 1505300400000000, 1, 
                            /* extOrdType, execInst, orgIdx, ordAction, ocoId,   price, qty, apiLoginUsrIdx,  apiRqstId,  forceId,   output*/
                               1,          4,        orgIdZhang,    1,     0,     0,     0,          0,           0,           0,   &orderAddAsk);
                                            
                    /* orgId,            traderId,           orderNo,     extOrdrType, status, ordrMask, rqstId, contractPos,      qty,       remain,  price, specOrdrId, */          
    FormatOrderInfoT(orgIdZhang,   usrIdZhang,    gCurrentDateBase+15,     1,           2,      17,       "",   contractPos,     250000000,        0,  250,     0, 
                    /* createTime,       activateTime,     updateTime,       expireTime,      closePositionCD, apiId, orgCd, output */
                       1505284587941003, 1505284587941003, 1505284587941003, 1505300400000000, 0,              0,     0,  &orderInfoAddRspAsk);
                                   
                    /*       tradeNo,    contractPos, trdAmount, trdPrice,      trdDateTime,  trdSts,        bidOrdNo,         askOrdNo,    bidOrgIdx,  askOrgIdx, bidUsrIdx, askUsrIdx,  */        
    FormatDealInfoT(gTradeIdBase+800001, contractPos, 250000000,     250,  1505284587941003,       1, gCurrentDateBase+1,gCurrentDateBase+15,   orgIdMa, orgIdZhang,   usrIdMa, usrIdZhang, 
                    /* trdDate, trdMthd, bidToAskLastCredit, askToBidLastCredit, bidTradeType, askTradeType, tradeSubType, updateTime, calcOrg, rowNum, */
                            0,        0,                  0,                0,             0,            0,             0,         0,        0,      0,              
                    /* bidAccntNo, bidStlmntAccntNo, termLimit, interestDaysChange, interestFirstDay, dlvryDtDay, interestPayforDaysChange, stleTp, */
                               0,                0,          0,                  0,                0,         0,                         0,      0,
                    /*  interestBidPayPrd, interestBidDlvryDt, interestBidInterestBnchmk, refCntrct, interestSprd, interestOfferDlvryDt, */
                                       0,                   0,                         0,         0,             0,                    0,
                    /*  interestOfferPayPrd, interestConfirmFirstDay, interestOfferResetRate, interestOfferTp, interestOfferInterestBnchmk, output*/
                                            0,                        0,                       0,              0,                           0, &DealInfo);

    
    memcpy(&sReq.msgBody, &orderAddAsk, sizeof(NewOrderSingleReqT));
    
    rc = IrsUsrInfoGetByPos(usrIdZhang, &usrZh);
    EXPECT_EQ(NO_ERR, rc);
    
    rc = RolePrvlgAdd(C_ORDSUBMIT_FUNCID, usrZh.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = OrderSubmitMessage(&sReq,&sRsp,orderInfoAddRspAsk.createTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pOrdrAskActlRsp =  (pNewOrderSingleRspT)sRsp.msgBody;     
    
    EXPECT_EQ(pOrdrAskActlRsp->slotCnt, 2); 
    
    rc = MsgGetSlot(pOrdrAskActlRsp->rspSlot[1], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pOrderCnfrm = (pNewOrderCnfrmT)&pReqSlot->msgBody;
    
    ChkOrdrInfo(&pOrderCnfrm->rspOrder[1], &orderInfoAddRspAsk);
    
    rc = MsgDelete(pOrdrAskActlRsp->rspSlot[1]);
    EXPECT_EQ(rc, NO_ERR);
    
    rc = MsgGetSlot(pOrdrAskActlRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pDealCnfrm = (pNewDealCnfrmT)&pReqSlot->msgBody;
        
    ChkDealInfo(&pDealCnfrm->rspDeal[0], &DealInfo);
    
    rc = MsgDelete(pOrdrAskActlRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);

    
    /* Do Deal Cncl*/
    
                                  /* userInx,           officerIdx,                token,             dealId,           output*/
    FormatDealCancelRequestReqT(  0,                               0,     "505284576648012",    gTradeIdBase+800001, &CnclDealReq    ); 
                                     

                /*       tradeNo,        contractPos, trdAmount, trdPrice,      trdDateTime,  trdSts,        bidOrdNo,         askOrdNo,        bidOrgIdx,  askOrgIdx, bidUsrIdx,  askUsrIdx,  */        
    FormatDealInfoT(gTradeIdBase+800001, contractPos, 250000000,   250,  1505284587941003,       2, gCurrentDateBase+1,gCurrentDateBase+15,   orgIdMa, orgIdZhang,   usrIdMa,      usrIdZhang, 
                /* trdDate, trdMthd, bidToAskLastCredit, askToBidLastCredit, bidTradeType, askTradeType, tradeSubType, updateTime, calcOrg, rowNum, */
                        0,        0,                  0,                0,             0,            0,             0,         0,        0,      0,              
                /* bidAccntNo, bidStlmntAccntNo, termLimit, interestDaysChange, interestFirstDay, dlvryDtDay, interestPayforDaysChange, stleTp, */
                           0,                0,          0,                  0,                0,         0,                         0,      0,
                /*  interestBidPayPrd, interestBidDlvryDt, interestBidInterestBnchmk, refCntrct, interestSprd, interestOfferDlvryDt, */
                                  0,                   0,                         0,         0,             0,                    0,
                /*  interestOfferPayPrd, interestConfirmFirstDay, interestOfferResetRate, interestOfferTp, interestOfferInterestBnchmk,   output*/
                                            0,                        0,                       0,              0,                           0,  &DealInfoCncl);

    rc = IrsUsrInfoGetByNameExt((char *)"cwadmin", &pUsrAdmin);
    EXPECT_EQ(rc, RTN);
    
    CnclDealReq.officerIdx = pUsrAdmin->pos;
    strcpy(CnclDealReq.token, pUsrAdmin->sesnId);
    pUsrAdmin->usrOnlnStatus = TRUE;
    pUsrAdmin->roleId[pUsrAdmin->lgnTp-1] = 1;
    
    memcpy(&sReq.msgBody, &CnclDealReq, sizeof(DealCancelRequestReqT));
    
    rc = RolePrvlgAdd(C_TRADECANCEL_FUNCID, usr.lgnTp, &pRolePrvlg);
    if( rc == ERR_CMN_HASH_LIST_NODE_EXISTED)
    {
        rc = NO_ERR;
    }
    EXPECT_EQ( rc, NO_ERR ); 
    
    rc = PrcsDealCnclReq(&sReq,&sRsp,DealInfoCncl.trdDateTime,&ctx);
    EXPECT_EQ(NO_ERR, rc);    
    
    pNewOrderSingleRspT   pDealCnclRsp =  (pNewOrderSingleRspT)sRsp.msgBody;
    
    EXPECT_EQ(pDealCnclRsp->slotCnt, 1); 
    
    rc = MsgGetSlot(pDealCnclRsp->rspSlot[0], &pReqSlot);
    EXPECT_EQ(rc, NO_ERR);
    
    pDealCnfrm = (pNewDealCnfrmT)&pReqSlot->msgBody;
    
    ChkDealInfo(&pDealCnfrm->rspDeal[0], &DealInfoCncl);
    
    rc = MsgDelete(pDealCnclRsp->rspSlot[0]);
    EXPECT_EQ(rc, NO_ERR);
    
}



int main(int argc, char **argv) {
    InitGoogleTest(&argc, argv);


    return RUN_ALL_TESTS();
}

