/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctBaseInfoDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CNTRCTBASEINFO_CNT_NUM         1

#define DB_CNTRCTBASEINFO_TOT_COLMN       (sizeof(gCntrctBaseInfoDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CNTRCT_BASE_INFO "
"(CNTRCT_SRNO,CNTRCT_NM,CNTRCT_TP,MKT_ID,SHRT_CNTRCT_NM,LNG_CNTRCT_NM,SHRT_AMNT_RATIO,LNG_AMNT_RATIO,MAX_AMNT_PER_DL,MIN_AMNT_PER_DL,DL_UNIT,DL_PRC_UNIT,TERM,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,TERM_STRNG,BRDG_SORT) VALUES "
"(:cntrct_srno,:cntrct_nm,:cntrct_tp,:mkt_id,:shrt_cntrct_nm,:lng_cntrct_nm,:shrt_amnt_ratio,:lng_amnt_ratio,:max_amnt_per_dl,:min_amnt_per_dl,:dl_unit,:dl_prc_unit,:term,:st,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:term_strng,:brdg_sort) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CNTRCT_BASE_INFO ";
static char gSqlSelect[] = "SELECT CNTRCT_SRNO,CNTRCT_NM,CNTRCT_TP,MKT_ID,NVL(SHRT_CNTRCT_NM, ' '),NVL(LNG_CNTRCT_NM, ' '),SHRT_AMNT_RATIO,LNG_AMNT_RATIO,MAX_AMNT_PER_DL,MIN_AMNT_PER_DL,DL_UNIT,DL_PRC_UNIT,TERM,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,NVL(TERM_STRNG, ' '),BRDG_SORT FROM CNTRCT_BASE_INFO ";
static DbColInfoT gCntrctBaseInfoDbInfo[] = 
{
    {"CNTRCT_SRNO",    ":cntrct_srno",    offsetof(CntrctBaseInfo, cntrctSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_NM",    ":cntrct_nm",    offsetof(CntrctBaseInfo, cntrctNm),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_TP",    ":cntrct_tp",    offsetof(CntrctBaseInfo, cntrctTp),    0,    DB_COL_STRING,    8,  0 },
    {"MKT_ID",    ":mkt_id",    offsetof(CntrctBaseInfo, mktId),    0,    DB_COL_STRING,    8,  0 },
    {"SHRT_CNTRCT_NM",    ":shrt_cntrct_nm",    offsetof(CntrctBaseInfo, shrtCntrctNm),    0,    DB_COL_STRING,    50,  0 },
    {"LNG_CNTRCT_NM",    ":lng_cntrct_nm",    offsetof(CntrctBaseInfo, lngCntrctNm),    0,    DB_COL_STRING,    50,  0 },
    {"SHRT_AMNT_RATIO",    ":shrt_amnt_ratio",    offsetof(CntrctBaseInfo, shrtAmntRatio),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"LNG_AMNT_RATIO",    ":lng_amnt_ratio",    offsetof(CntrctBaseInfo, lngAmntRatio),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"MAX_AMNT_PER_DL",    ":max_amnt_per_dl",    offsetof(CntrctBaseInfo, maxAmntPerDl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MIN_AMNT_PER_DL",    ":min_amnt_per_dl",    offsetof(CntrctBaseInfo, minAmntPerDl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DL_UNIT",    ":dl_unit",    offsetof(CntrctBaseInfo, dlUnit),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DL_PRC_UNIT",    ":dl_prc_unit",    offsetof(CntrctBaseInfo, dlPrcUnit),    0,    DB_COL_STRING,    8,  0 },
    {"TERM",    ":term",    offsetof(CntrctBaseInfo, term),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ST",    ":st",    offsetof(CntrctBaseInfo, st),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctBaseInfo, crtTm),    offsetof(CntrctBaseInfo, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctBaseInfo, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctBaseInfo, updTm),    offsetof(CntrctBaseInfo, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctBaseInfo, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"TERM_STRNG",    ":term_strng",    offsetof(CntrctBaseInfo, termStrng),    0,    DB_COL_STRING,    50,  0 },
    {"BRDG_SORT",    ":brdg_sort",    offsetof(CntrctBaseInfo, brdgSort),    0,    DB_COL_INT32,    sizeof(int32),  0 },
};

static DbColInfoT gCntrctBaseInfoDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctBaseInfoCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctBaseInfo* pData );
ResCodeT FreeDateTimeType( CntrctBaseInfo* pData );
ResCodeT SelectCntrctBaseInfo(int32 connId, int32 *pStmntId);
ResCodeT SelectCntrctBaseInfoBySt(int32 connId, int32 *pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctBaseInfo(int32 connId, CntrctBaseInfo* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctBaseInfo" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctBaseInfoDbInfo,
                            DB_CNTRCTBASEINFO_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctBaseInfoByKey(int32 connId, CntrctBaseInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctBaseInfoByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTBASEINFO_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctBaseInfoDbInfo[keyIdx].colFlag,
                                    gCntrctBaseInfoDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CNTRCT_BASE_INFO SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTBASEINFO_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctBaseInfoDbInfo[colIdx].colFlag,
                                    gCntrctBaseInfoDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctBaseInfoDbInfo, 
                    DB_CNTRCTBASEINFO_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctBaseInfo(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctBaseInfo" );

    int32       stmtId;
    CntrctBaseInfoCntT    CntrctBaseInfoCnt = {0};
    CntrctBaseInfoCntT *  pCntrctBaseInfoCnt = &CntrctBaseInfoCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTBASEINFO_CNT_NUM,
                        gCntrctBaseInfoDbCntInfo, (void *) pCntrctBaseInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctBaseInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfCntrctBaseInfoByKeyRL(int32 connId, CntrctBaseInfo* pData, vectorT *pKeyFlg, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctBaseInfoByKeyRL" );

    int32       stmtId;
    CntrctBaseInfoCntT    CntrctBaseInfoCnt = {0};
    CntrctBaseInfoCntT *  pCntrctBaseInfoCnt = &CntrctBaseInfoCnt;
    int32     keyIdx = -1;
    char      keySql[DB_COMM_SQL_KEY_LEN];
    char      selectSql[DB_COMM_SQL_TOT_LEN];
    
    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE CNTRCT_NM = :cntrct_nm AND ST = :st " );

    memset(selectSql, 0x00, sizeof(selectSql));
    sprintf(selectSql, "%s%s", gSqlSelectCount, keySql );

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);
    
    /* Bind all values */
    rc = DbCmmnExcBindVal(connId, stmtId, gCntrctBaseInfoDbInfo, 
        DB_CNTRCTBASEINFO_TOT_COLMN, pKeyFlg, (void *)pData);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTBASEINFO_CNT_NUM,
                        gCntrctBaseInfoDbCntInfo, (void *) pCntrctBaseInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctBaseInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextCntrctBaseInfo( BOOL * pFrstFlag, int32 connId, CntrctBaseInfo* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctBaseInfo" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctBaseInfo(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTBASEINFO_TOT_COLMN, 
                            gCntrctBaseInfoDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextCntrctBaseInfoBySt(BOOL* pFrstFlag, int32 connId, CntrctBaseInfo* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctBaseInfoBySt" );

    static int32 stmntId;

    if ( *pFrstFlag ) {
        rc = SelectCntrctBaseInfoBySt(connId, &stmntId);
        RAISE_ERR(rc, RTN);
        *pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTBASEINFO_TOT_COLMN, 
                            gCntrctBaseInfoDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctBaseInfo(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctBaseInfo" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctBaseInfoBySt(int32 connId, int32 *pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctBaseInfoBySt" );

    int32 stmtId;
    char strSql[DB_COMM_SQL_TOT_LEN];
    const char strWhere[] = "WHERE ST = 1 ";

    memset(strSql, 0x00, sizeof(strSql));
    sprintf(strSql, "%s%s", gSqlSelect, strWhere);

    rc = DbCmmnPrprSql( connId, strSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FmtDateTimeType( CntrctBaseInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctBaseInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
