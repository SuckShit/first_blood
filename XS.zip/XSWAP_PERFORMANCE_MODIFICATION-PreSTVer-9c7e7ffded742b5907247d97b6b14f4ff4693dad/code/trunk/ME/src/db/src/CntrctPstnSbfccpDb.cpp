/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctPstnSbfccpDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CNTRCTPSTNSBFCCP_CNT_NUM         1

#define DB_CNTRCTPSTNSBFCCP_TOT_COLMN       (sizeof(gCntrctPstnSbfccpDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CNTRCT_PSTN_SBFCCP "
"(CNTRCT_PSTN_SRNO,ORG_ID,CNTRCT_CD,NET_PSTN,BID_HOLD_AMNT,OFR_HOLD_AMNT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:cntrct_pstn_srno,:org_id,:cntrct_cd,:net_pstn,:bid_hold_amnt,:ofr_hold_amnt,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CNTRCT_PSTN_SBFCCP ";
static char gSqlSelect[] = "SELECT CNTRCT_PSTN_SRNO,ORG_ID,CNTRCT_CD,NET_PSTN,BID_HOLD_AMNT,OFR_HOLD_AMNT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM CNTRCT_PSTN_SBFCCP ";
static DbColInfoT gCntrctPstnSbfccpDbInfo[] = 
{
    {"CNTRCT_PSTN_SRNO",    ":cntrct_pstn_srno",    offsetof(CntrctPstnSbfccp, cntrctPstnSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(CntrctPstnSbfccp, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(CntrctPstnSbfccp, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"NET_PSTN",    ":net_pstn",    offsetof(CntrctPstnSbfccp, netPstn),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"BID_HOLD_AMNT",    ":bid_hold_amnt",    offsetof(CntrctPstnSbfccp, bidHoldAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"OFR_HOLD_AMNT",    ":ofr_hold_amnt",    offsetof(CntrctPstnSbfccp, ofrHoldAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctPstnSbfccp, crtTm),    offsetof(CntrctPstnSbfccp, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctPstnSbfccp, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctPstnSbfccp, updTm),    offsetof(CntrctPstnSbfccp, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctPstnSbfccp, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gCntrctPstnSbfccpDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctPstnSbfccpCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctPstnSbfccp* pData );
ResCodeT FreeDateTimeType( CntrctPstnSbfccp* pData );
ResCodeT SelectCntrctPstnSbfccp(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctPstnSbfccp(int32 connId, CntrctPstnSbfccp* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctPstnSbfccp" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctPstnSbfccpDbInfo,
                            DB_CNTRCTPSTNSBFCCP_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctPstnSbfccpByKey(int32 connId, CntrctPstnSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctPstnSbfccpByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTPSTNSBFCCP_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctPstnSbfccpDbInfo[keyIdx].colFlag,
                                    gCntrctPstnSbfccpDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CNTRCT_PSTN_SBFCCP SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTPSTNSBFCCP_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctPstnSbfccpDbInfo[colIdx].colFlag,
                                    gCntrctPstnSbfccpDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctPstnSbfccpDbInfo, 
                    DB_CNTRCTPSTNSBFCCP_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctPstnSbfccp(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctPstnSbfccp" );

    int32       stmtId;
    CntrctPstnSbfccpCntT    CntrctPstnSbfccpCnt = {0};
    CntrctPstnSbfccpCntT *  pCntrctPstnSbfccpCnt = &CntrctPstnSbfccpCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTPSTNSBFCCP_CNT_NUM,
                        gCntrctPstnSbfccpDbCntInfo, (void *) pCntrctPstnSbfccpCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctPstnSbfccpCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCntrctPstnSbfccp( BOOL * pFrstFlag, int32 connId, CntrctPstnSbfccp* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctPstnSbfccp" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctPstnSbfccp(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTPSTNSBFCCP_TOT_COLMN, 
                            gCntrctPstnSbfccpDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctPstnSbfccp(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctPstnSbfccp" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CntrctPstnSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctPstnSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
