/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "UsrMktPrvlgDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_USRMKTPRVLG_CNT_NUM         1

#define DB_USRMKTPRVLG_TOT_COLMN       (sizeof(gUsrMktPrvlgDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO USR_MKT_PRVLG "
"(USR_MKT_PRVLG_SRNO,USR_LGN_NM,MKT_TP,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:usr_mkt_prvlg_srno,:usr_lgn_nm,:mkt_tp,:st,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM USR_MKT_PRVLG ";
static char gSqlSelect[] = "SELECT USR_MKT_PRVLG_SRNO,USR_LGN_NM,MKT_TP,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM USR_MKT_PRVLG ";
static DbColInfoT gUsrMktPrvlgDbInfo[] = 
{
    {"USR_MKT_PRVLG_SRNO",    ":usr_mkt_prvlg_srno",    offsetof(UsrMktPrvlg, usrMktPrvlgSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"USR_LGN_NM",    ":usr_lgn_nm",    offsetof(UsrMktPrvlg, usrLgnNm),    0,    DB_COL_STRING,    100,  0 },
    {"MKT_TP",    ":mkt_tp",    offsetof(UsrMktPrvlg, mktTp),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(UsrMktPrvlg, st),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(UsrMktPrvlg, crtTm),    offsetof(UsrMktPrvlg, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(UsrMktPrvlg, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(UsrMktPrvlg, updTm),    offsetof(UsrMktPrvlg, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(UsrMktPrvlg, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gUsrMktPrvlgDbCntInfo[] =
{
    {"",                 ":count",           offsetof(UsrMktPrvlgCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( UsrMktPrvlg* pData );
ResCodeT FreeDateTimeType( UsrMktPrvlg* pData );
ResCodeT SelectUsrMktPrvlg(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertUsrMktPrvlg(int32 connId, UsrMktPrvlg* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertUsrMktPrvlg" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gUsrMktPrvlgDbInfo,
                            DB_USRMKTPRVLG_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateUsrMktPrvlgByKey(int32 connId, UsrMktPrvlg* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateUsrMktPrvlgByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_USRMKTPRVLG_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gUsrMktPrvlgDbInfo[keyIdx].colFlag,
                                    gUsrMktPrvlgDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE USR_MKT_PRVLG SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_USRMKTPRVLG_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gUsrMktPrvlgDbInfo[colIdx].colFlag,
                                    gUsrMktPrvlgDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gUsrMktPrvlgDbInfo, 
                    DB_USRMKTPRVLG_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfUsrMktPrvlg(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfUsrMktPrvlg" );

    int32       stmtId;
    UsrMktPrvlgCntT    UsrMktPrvlgCnt = {0};
    UsrMktPrvlgCntT *  pUsrMktPrvlgCnt = &UsrMktPrvlgCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USRMKTPRVLG_CNT_NUM,
                        gUsrMktPrvlgDbCntInfo, (void *) pUsrMktPrvlgCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrMktPrvlgCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextUsrMktPrvlg( BOOL * pFrstFlag, int32 connId, UsrMktPrvlg* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextUsrMktPrvlg" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectUsrMktPrvlg(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USRMKTPRVLG_TOT_COLMN, 
                            gUsrMktPrvlgDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectUsrMktPrvlg(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectUsrMktPrvlg" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( UsrMktPrvlg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( UsrMktPrvlg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
