/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "PrcsTxnIdtblDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_PRCSTXNIDTBL_CNT_NUM         1

#define DB_RPLY_TOT_COLMN       (sizeof(gPrcsTxnIdtblDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO PRCS_TXN_ID_TBL "
"(SET_ID,KEY_VALUE) VALUES "
"(:set_id,:key_value) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM PRCS_TXN_ID_TBL ";
static char gSqlSelect[] = "SELECT SET_ID,KEY_VALUE FROM PRCS_TXN_ID_TBL ";
static char gSqlSlctSpe[] = "SELECT SET_ID,KEY_VALUE FROM PRCS_TXN_ID_TBL WHERE SET_ID='%ld' ";
static DbColInfoT gPrcsTxnIdtblDbInfo[] = 
{
    {"SET_ID",    ":set_id",    offsetof(PrcsTxnIdtbl, setId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"KEY_VALUE",    ":key_value",    offsetof(PrcsTxnIdtbl, keyValue),    0,    DB_COL_INT32,    sizeof(int32),  0 },
};

static DbColInfoT gPrcsTxnIdtblDbCntInfo[] =
{
    {"",                 ":count",           offsetof(PrcsTxnIdtblCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( PrcsTxnIdtbl* pData );
ResCodeT FreeDateTimeType( PrcsTxnIdtbl* pData );
ResCodeT SelectPrcsTxnIdtbl(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertPrcsTxnIdtbl(int32 connId, PrcsTxnIdtbl* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertPrcsTxnIdtbl" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gPrcsTxnIdtblDbInfo,
                            DB_RPLY_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdatePrcsTxnIdtblByKey(int32 connId, PrcsTxnIdtbl* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdatePrcsTxnIdtblByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_RPLY_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gPrcsTxnIdtblDbInfo[keyIdx].colFlag,
                                    gPrcsTxnIdtblDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE PRCS_TXN_ID_TBL SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_RPLY_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gPrcsTxnIdtblDbInfo[colIdx].colFlag,
                                    gPrcsTxnIdtblDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gPrcsTxnIdtblDbInfo, 
                    DB_RPLY_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfPrcsTxnIdtbl(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfPrcsTxnIdtbl" );

    int32       stmtId;
    PrcsTxnIdtblCntT    PrcsTxnIdtblCnt = {0};
    PrcsTxnIdtblCntT *  pPrcsTxnIdtblCnt = &PrcsTxnIdtblCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_PRCSTXNIDTBL_CNT_NUM,
                        gPrcsTxnIdtblDbCntInfo, (void *) pPrcsTxnIdtblCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = PrcsTxnIdtblCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextPrcsTxnIdtbl( BOOL * pFrstFlag, int32 connId, PrcsTxnIdtbl* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextPrcsTxnIdtbl" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectPrcsTxnIdtbl(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_RPLY_TOT_COLMN, 
                            gPrcsTxnIdtblDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectPrcsTxnIdtbl(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectPrcsTxnIdtbl" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SelectPrcsTxnIdtblByKey(int32 connId, PrcsTxnIdtblKey* pKey, int32* pCntOut)
{
    ResCodeT    rc = NO_ERR;
    static      int32 stmntId;
    BEGIN_FUNCTION( "SelectPrcsTxnIdtblByKey" );
    

    char sqlSelect[100];
    PrcsTxnIdtbl prcsTxnIdtblData = {0};
    
    memset(sqlSelect, 0x00, sizeof(sqlSelect));

    sprintf(sqlSelect, gSqlSlctSpe, pKey->setId );


    rc = DbCmmnPrprSql( connId, sqlSelect, &stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_RPLY_TOT_COLMN, 
                            gPrcsTxnIdtblDbInfo, (void *) &prcsTxnIdtblData );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    *pCntOut = prcsTxnIdtblData.keyValue;

EXIT_BLOCK();
RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( PrcsTxnIdtbl* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( PrcsTxnIdtbl* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    EXIT_BLOCK();
    RETURN_RESCODE;
}
