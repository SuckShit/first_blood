/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "HldyInfoDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_HLDYINFO_CNT_NUM         1

#define DB_HLDYINFO_TOT_COLMN       (sizeof(gHldyInfoDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO HLDY_INFO "
"(HLDY_SRNO,MKT_TP,CLNDR_TP,YR_VL,HLDY_DT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:hldy_srno,:mkt_tp,:clndr_tp,:yr_vl,:hldy_dt,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM HLDY_INFO ";
static char gSqlSelect[] = "SELECT HLDY_SRNO,MKT_TP,CLNDR_TP,YR_VL,HLDY_DT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM HLDY_INFO ";
static char gSqlSelectByDate[] = "SELECT COUNT(*) FROM HLDY_INFO WHERE MKT_TP = %d AND CLNDR_TP = %d AND TO_CHAR(HLDY_DT, 'YYYYMMDD') = '%s' ";
static DbColInfoT gHldyInfoDbInfo[] = 
{
    {"HLDY_SRNO",    ":hldy_srno",    offsetof(HldyInfo, hldySrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MKT_TP",    ":mkt_tp",    offsetof(HldyInfo, mktTp),    0,    DB_COL_STRING,    8,  0 },
    {"CLNDR_TP",    ":clndr_tp",    offsetof(HldyInfo, clndrTp),    0,    DB_COL_STRING,    8,  0 },
    {"YR_VL",    ":yr_vl",    offsetof(HldyInfo, yrVl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"HLDY_DT",    ":hldy_dt",    offsetof(HldyInfo, hldyDt),    offsetof(HldyInfo, pHldyDt),    DB_COL_DATE,    50,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(HldyInfo, crtTm),    offsetof(HldyInfo, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(HldyInfo, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(HldyInfo, updTm),    offsetof(HldyInfo, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(HldyInfo, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gHldyInfoDbCntInfo[] =
{
    {"",                 ":count",           offsetof(HldyInfoCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( HldyInfo* pData );
ResCodeT FreeDateTimeType( HldyInfo* pData );
ResCodeT SelectHldyInfo(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertHldyInfo(int32 connId, HldyInfo* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertHldyInfo" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gHldyInfoDbInfo,
                            DB_HLDYINFO_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateHldyInfoByKey(int32 connId, HldyInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateHldyInfoByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_HLDYINFO_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gHldyInfoDbInfo[keyIdx].colFlag,
                                    gHldyInfoDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE HLDY_INFO SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_HLDYINFO_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gHldyInfoDbInfo[colIdx].colFlag,
                                    gHldyInfoDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gHldyInfoDbInfo, 
                    DB_HLDYINFO_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfHldyInfoByKey(int32 connId, int32 mktType, int32 clndrType, char* dateStr, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfHldyInfoByKey" );

    int32       stmtId;
    HldyInfoCntT    HldyInfoCnt = {0};
    HldyInfoCntT *  pHldyInfoCnt = &HldyInfoCnt;
    char keySql[DB_COMM_SQL_KEY_LEN];
    memset( keySql, 0x00, sizeof(keySql) );
    sprintf(keySql, gSqlSelectByDate, mktType, clndrType, dateStr);
    
    rc = DbCmmnPrprSql( connId, keySql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_HLDYINFO_CNT_NUM,
                        gHldyInfoDbCntInfo, (void *) pHldyInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = HldyInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetResultCntOfHldyInfo(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfHldyInfo" );

    int32       stmtId;
    HldyInfoCntT    HldyInfoCnt = {0};
    HldyInfoCntT *  pHldyInfoCnt = &HldyInfoCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_HLDYINFO_CNT_NUM,
                        gHldyInfoDbCntInfo, (void *) pHldyInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = HldyInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextHldyInfo( BOOL * pFrstFlag, int32 connId, HldyInfo* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextHldyInfo" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectHldyInfo(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_HLDYINFO_TOT_COLMN, 
                            gHldyInfoDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectHldyInfo(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
BEGIN_FUNCTION( "SelectHldyInfo" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( HldyInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->hldyDt, &pData->pHldyDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( HldyInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pHldyDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
