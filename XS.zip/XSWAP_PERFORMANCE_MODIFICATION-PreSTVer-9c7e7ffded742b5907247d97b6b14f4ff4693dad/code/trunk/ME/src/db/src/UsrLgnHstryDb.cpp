/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "UsrLgnHstryDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_USRLGNHSTRY_CNT_NUM         1

#define DB_USRLGNHSTRY_TOT_COLMN       (sizeof(gUsrLgnHstryDbInfo) / sizeof(DbColInfoT))
#define DB_USRLGNHSTRY_TOT_INSERT_COLMN       (sizeof(gUsrLgnHstryDbInfoInsrt) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO USR_LGN_HSTRY "
"(LGN_SRNO, USR_NM,OPRT_TP,LGN_IP,OPRT_TM) VALUES "
"(SEQ_LOG_HSTR_ID.NEXTVAL,:usr_nm,:oprt_tp,:lgn_ip,:oprt_tm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM USR_LGN_HSTRY ";
static char gSqlSelect[] = "SELECT LGN_SRNO,USR_NM,OPRT_TP,NVL(LGN_IP, ' '),OPRT_TM FROM USR_LGN_HSTRY ";

static DbColInfoT gUsrLgnHstryDbInfoInsrt[] = 
{
    {"USR_NM",    ":usr_nm",    offsetof(UsrLgnHstry, usrNm),    0,    DB_COL_STRING,    100,  0 },
    {"OPRT_TP",    ":oprt_tp",    offsetof(UsrLgnHstry, oprtTp),    0,    DB_COL_STRING,    8,  0 },
    {"LGN_IP",    ":lgn_ip",    offsetof(UsrLgnHstry, lgnIp),    0,    DB_COL_STRING,    50,  0 },
    {"OPRT_TM",    ":oprt_tm",    offsetof(UsrLgnHstry, oprtTm),    offsetof(UsrLgnHstry, pOprtTm),    DB_COL_TIMESTAMP,    50,  0 },
};

static DbColInfoT gUsrLgnHstryDbInfo[] = 
{
    {"LGN_SRNO",    ":lgn_srno",    offsetof(UsrLgnHstry, lgnSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"USR_NM",    ":usr_nm",    offsetof(UsrLgnHstry, usrNm),    0,    DB_COL_STRING,    100,  0 },
    {"OPRT_TP",    ":oprt_tp",    offsetof(UsrLgnHstry, oprtTp),    0,    DB_COL_STRING,    8,  0 },
    {"LGN_IP",    ":lgn_ip",    offsetof(UsrLgnHstry, lgnIp),    0,    DB_COL_STRING,    50,  0 },
    {"OPRT_TM",    ":oprt_tm",    offsetof(UsrLgnHstry, oprtTm),    offsetof(UsrLgnHstry, pOprtTm),    DB_COL_TIMESTAMP,    50,  0 },
};

static DbColInfoT gUsrLgnHstryDbCntInfo[] =
{
    {"",                 ":count",           offsetof(UsrLgnHstryCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( UsrLgnHstry* pData );
ResCodeT FreeDateTimeType( UsrLgnHstry* pData );
ResCodeT SelectUsrLgnHstry(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertUsrLgnHstry(int32 connId, UsrLgnHstry* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertUsrLgnHstry" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    
    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gUsrLgnHstryDbInfoInsrt,
                            DB_USRLGNHSTRY_TOT_INSERT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateUsrLgnHstryByKey(int32 connId, UsrLgnHstry* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateUsrLgnHstryByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_USRLGNHSTRY_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gUsrLgnHstryDbInfo[keyIdx].colFlag,
                                    gUsrLgnHstryDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE USR_LGN_HSTRY SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_USRLGNHSTRY_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gUsrLgnHstryDbInfo[colIdx].colFlag,
                                    gUsrLgnHstryDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gUsrLgnHstryDbInfo, 
                    DB_USRLGNHSTRY_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfUsrLgnHstry(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfUsrLgnHstry" );

    int32       stmtId;
    UsrLgnHstryCntT    UsrLgnHstryCnt = {0};
    UsrLgnHstryCntT *  pUsrLgnHstryCnt = &UsrLgnHstryCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USRLGNHSTRY_CNT_NUM,
                        gUsrLgnHstryDbCntInfo, (void *) pUsrLgnHstryCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrLgnHstryCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextUsrLgnHstry( BOOL * pFrstFlag, int32 connId, UsrLgnHstry* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextUsrLgnHstry" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectUsrLgnHstry(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USRLGNHSTRY_TOT_COLMN, 
                            gUsrLgnHstryDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectUsrLgnHstry(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
BEGIN_FUNCTION( "SelectUsrLgnHstry" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( UsrLgnHstry* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->oprtTm, &pData->pOprtTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( UsrLgnHstry* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pOprtTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
