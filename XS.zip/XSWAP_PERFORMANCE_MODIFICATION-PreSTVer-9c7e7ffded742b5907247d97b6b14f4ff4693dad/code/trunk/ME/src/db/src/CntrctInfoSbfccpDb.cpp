/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctInfoSbfccpDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CNTRCTINFOSBFCCP_CNT_NUM         1

#define DB_CNTRCTINFOSBFCCP_TOT_COLMN       (sizeof(gCntrctInfoSbfccpDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO cntrct_info_sbfccp "
"(CNTRCT_INFO_SRNO,CNTRCT_CD,CNTRCT_NM_EN,CNTRCT_NM_CN,CNTRCT_MTH,TERM,CNTRCT_FACE_VL,CNTRCT_UNDRLYNG,BNCHMK_RATE,DLVRY_DT,ACTV_DT,EXPRD_DT,TRDNG_END_TM,EMGCY_F,ST,STLE_TP,AMNT_PER_UNIT,MIN_AMNT_PER_DL,MAX_AMNT_PER_DL,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,CNVRT_RATE,PRC_LMT,CHK_ST,CPN_RATE) VALUES "
"(:cntrct_info_srno,:cntrct_cd,:cntrct_nm_en,:cntrct_nm_cn,:cntrct_mth,:term,:cntrct_face_vl,:cntrct_undrlyng,:bnchmk_rate,:dlvry_dt,:actv_dt,:exprd_dt,:trdng_end_tm,:emgcy_f,:st,:stle_tp,:amnt_per_unit,:min_amnt_per_dl,:max_amnt_per_dl,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:cnvrt_rate,:prc_lmt,:chk_st,:cpn_rate) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM cntrct_info_sbfccp ";
static char gSqlSelect[] = "SELECT CNTRCT_INFO_SRNO,CNTRCT_CD,CNTRCT_NM_EN,CNTRCT_NM_CN,CNTRCT_MTH,TERM,CNTRCT_FACE_VL,CNTRCT_UNDRLYNG,BNCHMK_RATE,DLVRY_DT,ACTV_DT,EXPRD_DT,TRDNG_END_TM,EMGCY_F,ST,STLE_TP,AMNT_PER_UNIT,MIN_AMNT_PER_DL,MAX_AMNT_PER_DL,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,CNVRT_RATE,PRC_LMT,CHK_ST,CPN_RATE FROM cntrct_info_sbfccp ";
static DbColInfoT gCntrctInfoSbfccpDbInfo[] = 
{
    {"CNTRCT_INFO_SRNO",    ":cntrct_info_srno",    offsetof(CntrctInfoSbfccp, cntrctInfoSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(CntrctInfoSbfccp, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_NM_EN",    ":cntrct_nm_en",    offsetof(CntrctInfoSbfccp, cntrctNmEn),    0,    DB_COL_STRING,    100,  0 },
    {"CNTRCT_NM_CN",    ":cntrct_nm_cn",    offsetof(CntrctInfoSbfccp, cntrctNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"CNTRCT_MTH",    ":cntrct_mth",    offsetof(CntrctInfoSbfccp, cntrctMth),    0,    DB_COL_STRING,    50,  0 },
    {"TERM",    ":term",    offsetof(CntrctInfoSbfccp, term),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_FACE_VL",    ":cntrct_face_vl",    offsetof(CntrctInfoSbfccp, cntrctFaceVl),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CNTRCT_UNDRLYNG",    ":cntrct_undrlyng",    offsetof(CntrctInfoSbfccp, cntrctUndrlyng),    0,    DB_COL_STRING,    8,  0 },
    {"BNCHMK_RATE",    ":bnchmk_rate",    offsetof(CntrctInfoSbfccp, bnchmkRate),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"DLVRY_DT",    ":dlvry_dt",    offsetof(CntrctInfoSbfccp, dlvryDt),    offsetof(CntrctInfoSbfccp, pDlvryDt),    DB_COL_DATE,    50,  0 },
    {"ACTV_DT",    ":actv_dt",    offsetof(CntrctInfoSbfccp, actvDt),    offsetof(CntrctInfoSbfccp, pActvDt),    DB_COL_DATE,    50,  0 },
    {"EXPRD_DT",    ":exprd_dt",    offsetof(CntrctInfoSbfccp, exprdDt),    offsetof(CntrctInfoSbfccp, pExprdDt),    DB_COL_DATE,    50,  0 },
    {"TRDNG_END_TM",    ":trdng_end_tm",    offsetof(CntrctInfoSbfccp, trdngEndTm),    0,    DB_COL_STRING,    50,  0 },
    {"EMGCY_F",    ":emgcy_f",    offsetof(CntrctInfoSbfccp, emgcyF),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(CntrctInfoSbfccp, st),    0,    DB_COL_STRING,    8,  0 },
    {"STLE_TP",    ":stle_tp",    offsetof(CntrctInfoSbfccp, stleTp),    0,    DB_COL_STRING,    8,  0 },
    {"AMNT_PER_UNIT",    ":amnt_per_unit",    offsetof(CntrctInfoSbfccp, amntPerUnit),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"MIN_AMNT_PER_DL",    ":min_amnt_per_dl",    offsetof(CntrctInfoSbfccp, minAmntPerDl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MAX_AMNT_PER_DL",    ":max_amnt_per_dl",    offsetof(CntrctInfoSbfccp, maxAmntPerDl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctInfoSbfccp, crtTm),    offsetof(CntrctInfoSbfccp, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctInfoSbfccp, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctInfoSbfccp, updTm),    offsetof(CntrctInfoSbfccp, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctInfoSbfccp, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CNVRT_RATE",    ":cnvrt_rate",    offsetof(CntrctInfoSbfccp, cnvrtRate),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"PRC_LMT",    ":prc_lmt",    offsetof(CntrctInfoSbfccp, prcLmt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CHK_ST",    ":chk_st",    offsetof(CntrctInfoSbfccp, chkSt),    0,    DB_COL_STRING,    8,  0 },
    {"CPN_RATE",    ":cpn_rate",    offsetof(CntrctInfoSbfccp, cpnRate),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
};

static DbColInfoT gCntrctInfoSbfccpDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctInfoSbfccpCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctInfoSbfccp* pData );
ResCodeT FreeDateTimeType( CntrctInfoSbfccp* pData );
ResCodeT SelectCntrctInfoSbfccp(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctInfoSbfccp(int32 connId, CntrctInfoSbfccp* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctInfoSbfccp" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctInfoSbfccpDbInfo,
                            DB_CNTRCTINFOSBFCCP_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctInfoSbfccpByKey(int32 connId, CntrctInfoSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctInfoSbfccpByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTINFOSBFCCP_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctInfoSbfccpDbInfo[keyIdx].colFlag,
                                    gCntrctInfoSbfccpDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE cntrct_info_sbfccp SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTINFOSBFCCP_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctInfoSbfccpDbInfo[colIdx].colFlag,
                                    gCntrctInfoSbfccpDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctInfoSbfccpDbInfo, 
                    DB_CNTRCTINFOSBFCCP_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctInfoSbfccp(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctInfoSbfccp" );

    int32       stmtId;
    CntrctInfoSbfccpCntT    CntrctInfoSbfccpCnt = {0};
    CntrctInfoSbfccpCntT *  pCntrctInfoSbfccpCnt = &CntrctInfoSbfccpCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTINFOSBFCCP_CNT_NUM,
                        gCntrctInfoSbfccpDbCntInfo, (void *) pCntrctInfoSbfccpCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctInfoSbfccpCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCntrctInfoSbfccp( BOOL * pFrstFlag, int32 connId, CntrctInfoSbfccp* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctInfoSbfccp" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctInfoSbfccp(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTINFOSBFCCP_TOT_COLMN, 
                            gCntrctInfoSbfccpDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctInfoSbfccp(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctInfoSbfccp" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CntrctInfoSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->dlvryDt, &pData->pDlvryDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->actvDt, &pData->pActvDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->exprdDt, &pData->pExprdDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctInfoSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pDlvryDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pActvDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pExprdDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
