/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OrdrSbfccpDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ORDRSBFCCP_CNT_NUM         1

#define DB_ORDRSBFCCP_TOT_COLMN       (sizeof(gOrdrSbfccpDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ORDR_SBFCCP "
"(ORDR_ID,ORG_ID,ORDR_SBMT_TP,ORDR_TP,OCO_ID,CNTRCT_CD,NTNL_AMNT,RMNG_NTNL_AMNT,ORDR_PRC,ORDR_AMNT,DL_DIR,ST,TRDR_NM,ORDR_CRT_TM,ORDR_EXPRD_TM,ORDR_ACTV_TM,UPD_TM,UPD_USR_NM,ORG_FULL_NM_CN,ORG_CD,CLS_PSTN_CD,RQST_ID,USR_LGN_NM_API) VALUES "
"(:ordr_id,:org_id,:ordr_sbmt_tp,:ordr_tp,:oco_id,:cntrct_cd,:ntnl_amnt,:rmng_ntnl_amnt,:ordr_prc,:ordr_amnt,:dl_dir,:st,:trdr_nm,:ordr_crt_tm,:ordr_exprd_tm,:ordr_actv_tm,:upd_tm,:upd_usr_nm,:org_full_nm_cn,:org_cd,:cls_pstn_cd,:rqst_id,:usr_lgn_nm_api) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ORDR_SBFCCP ";
static char gSqlKeySelect[] = "SELECT COUNT(*) FROM ORDR_SBFCCP WHERE ORDR_ID = '%s' ";
static char gSqlSelect[] = "SELECT ORDR_ID,ORG_ID,ORDR_SBMT_TP,NVL(ORDR_TP, ' '),NVL(OCO_ID, ' '),CNTRCT_CD,NTNL_AMNT,RMNG_NTNL_AMNT,ORDR_PRC,ORDR_AMNT,DL_DIR,ST,TRDR_NM,ORDR_CRT_TM,ORDR_EXPRD_TM,ORDR_ACTV_TM,UPD_TM,UPD_USR_NM,ORG_FULL_NM_CN,ORG_CD,NVL(CLS_PSTN_CD, ' '),NVL(RQST_ID, ' '),NVL(USR_LGN_NM_API, ' ') FROM ORDR_SBFCCP ";
static DbColInfoT gOrdrSbfccpDbInfo[] = 
{
    {"ORDR_ID",    ":ordr_id",    offsetof(OrdrSbfccp, ordrId),    0,    DB_COL_STRING,    50,  0 },
    {"ORG_ID",    ":org_id",    offsetof(OrdrSbfccp, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORDR_SBMT_TP",    ":ordr_sbmt_tp",    offsetof(OrdrSbfccp, ordrSbmtTp),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_TP",    ":ordr_tp",    offsetof(OrdrSbfccp, ordrTp),    0,    DB_COL_STRING,    8,  0 },
    {"OCO_ID",    ":oco_id",    offsetof(OrdrSbfccp, ocoId),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(OrdrSbfccp, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"NTNL_AMNT",    ":ntnl_amnt",    offsetof(OrdrSbfccp, ntnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"RMNG_NTNL_AMNT",    ":rmng_ntnl_amnt",    offsetof(OrdrSbfccp, rmngNtnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"ORDR_PRC",    ":ordr_prc",    offsetof(OrdrSbfccp, ordrPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"ORDR_AMNT",    ":ordr_amnt",    offsetof(OrdrSbfccp, ordrAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"DL_DIR",    ":dl_dir",    offsetof(OrdrSbfccp, dlDir),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(OrdrSbfccp, st),    0,    DB_COL_STRING,    8,  0 },
    {"TRDR_NM",    ":trdr_nm",    offsetof(OrdrSbfccp, trdrNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORDR_CRT_TM",    ":ordr_crt_tm",    offsetof(OrdrSbfccp, ordrCrtTm),    offsetof(OrdrSbfccp, pOrdrCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"ORDR_EXPRD_TM",    ":ordr_exprd_tm",    offsetof(OrdrSbfccp, ordrExprdTm),    offsetof(OrdrSbfccp, pOrdrExprdTm),    DB_COL_DATE,    50,  0 },
    {"ORDR_ACTV_TM",    ":ordr_actv_tm",    offsetof(OrdrSbfccp, ordrActvTm),    offsetof(OrdrSbfccp, pOrdrActvTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OrdrSbfccp, updTm),    offsetof(OrdrSbfccp, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OrdrSbfccp, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_FULL_NM_CN",    ":org_full_nm_cn",    offsetof(OrdrSbfccp, orgFullNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_CD",    ":org_cd",    offsetof(OrdrSbfccp, orgCd),    0,    DB_COL_STRING,    50,  0 },
    {"CLS_PSTN_CD",    ":cls_pstn_cd",    offsetof(OrdrSbfccp, clsPstnCd),    0,    DB_COL_STRING,    50,  0 },
    {"RQST_ID",    ":rqst_id",    offsetof(OrdrSbfccp, rqstId),    0,    DB_COL_STRING,    50,  0 },
    {"USR_LGN_NM_API",    ":usr_lgn_nm_api",    offsetof(OrdrSbfccp, usrLgnNmApi),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gOrdrSbfccpDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OrdrSbfccpCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( OrdrSbfccp* pData );
ResCodeT FreeDateTimeType( OrdrSbfccp* pData );
ResCodeT SelectOrdrSbfccp(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOrdrSbfccp(int32 connId, OrdrSbfccp* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOrdrSbfccp" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOrdrSbfccpDbInfo,
                            DB_ORDRSBFCCP_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOrdrSbfccpByKey(int32 connId, OrdrSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrdrSbfccpByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORDRSBFCCP_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOrdrSbfccpDbInfo[keyIdx].colFlag,
                                    gOrdrSbfccpDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORDR_SBFCCP SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORDRSBFCCP_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrdrSbfccpDbInfo[colIdx].colFlag,
                                    gOrdrSbfccpDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrdrSbfccpDbInfo, 
                    DB_ORDRSBFCCP_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfOrdrSbfccp(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrdrSbfccp" );

    int32       stmtId;
    OrdrSbfccpCntT    OrdrSbfccpCnt = {0};
    OrdrSbfccpCntT *  pOrdrSbfccpCnt = &OrdrSbfccpCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORDRSBFCCP_CNT_NUM,
                        gOrdrSbfccpDbCntInfo, (void *) pOrdrSbfccpCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrdrSbfccpCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextOrdrSbfccp( BOOL * pFrstFlag, int32 connId, OrdrSbfccp* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrdrSbfccp" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOrdrSbfccp(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORDRSBFCCP_TOT_COLMN, 
                            gOrdrSbfccpDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOrdrSbfccp(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrdrSbfccp" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( OrdrSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->ordrCrtTm, &pData->pOrdrCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->ordrExprdTm, &pData->pOrdrExprdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->ordrActvTm, &pData->pOrdrActvTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( OrdrSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pOrdrCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pOrdrExprdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pOrdrActvTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchOrdrSbfccpByKey( int32 connId, char * pKey, BOOL * pFetchFlag )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchOrdrSbfccpByKey" );

    int32 stmntId;
    OrdrSbfccpCntT    OrdrCnt = {0};
    OrdrSbfccpCntT *  pOrdrCnt = &OrdrCnt;
    char updateSql[DB_COMM_SQL_TOT_LEN];
    
    * pFetchFlag = FALSE;

    sprintf( updateSql, gSqlKeySelect, pKey );

    rc = DbCmmnPrprSql( connId, updateSql, &stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORDRSBFCCP_CNT_NUM,
                        gOrdrSbfccpDbCntInfo, (void *) pOrdrCnt );
    RAISE_ERR(rc, RTN);

    if ( OrdrCnt.count )
    {
        * pFetchFlag = TRUE;
    }

    EXIT_BLOCK( );
    RETURN_RESCODE;
}



ResCodeT UpdateCancleOrdrSbfccp( int32 connId, OrdrSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCancleOrdrSbfccp");

    int32   stmtId;

    char updateSql[DB_COMM_SQL_TOT_LEN]={0};

    sprintf( updateSql, "UPDATE ORDR_SBFCCP SET ST='%s', ORDR_ACTV_TM=NULL ,RMNG_NTNL_AMNT=%lf WHERE ORDR_ID='%s' ", pData->st, pData->rmngNtnlAmnt, pData->ordrId );

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}