/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "QtSbscrptnApiDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_QTSBSCRPTNAPI_CNT_NUM         1

#define DB_QTSBSCRPTNAPI_TOT_COLMN       (sizeof(gQtSbscrptnApiDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO QT_SBSCRPTN_API "
"(QT_SBSCRPTN_API_SRNO,USR_LGN_NM,ORG_ID,ORG_CD,MKT_TP,STL_TP,CNTRCT_CD,QT_TP,LVL,INSTRCTN_SEND_TM,CRT_TM,RQST_ID) VALUES "
"(:qt_sbscrptn_api_srno,:usr_lgn_nm,:org_id,:org_cd,:mkt_tp,:stl_tp,:cntrct_cd,:qt_tp,:lvl,:instrctn_send_tm,:crt_tm,:rqst_id) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM QT_SBSCRPTN_API ";
static char gSqlSelect[] = "SELECT QT_SBSCRPTN_API_SRNO,USR_LGN_NM,ORG_ID,ORG_CD,MKT_TP,STL_TP,NVL(CNTRCT_CD, ' '),QT_TP,NVL(LVL, ' '),INSTRCTN_SEND_TM,CRT_TM,NVL(RQST_ID, ' ') FROM QT_SBSCRPTN_API ";
static DbColInfoT gQtSbscrptnApiDbInfo[] = 
{
    {"QT_SBSCRPTN_API_SRNO",    ":qt_sbscrptn_api_srno",    offsetof(QtSbscrptnApi, qtSbscrptnApiSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"USR_LGN_NM",    ":usr_lgn_nm",    offsetof(QtSbscrptnApi, usrLgnNm),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_ID",    ":org_id",    offsetof(QtSbscrptnApi, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_CD",    ":org_cd",    offsetof(QtSbscrptnApi, orgCd),    0,    DB_COL_STRING,    50,  0 },
    {"MKT_TP",    ":mkt_tp",    offsetof(QtSbscrptnApi, mktTp),    0,    DB_COL_STRING,    8,  0 },
    {"STL_TP",    ":stl_tp",    offsetof(QtSbscrptnApi, stlTp),    0,    DB_COL_STRING,    8,  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(QtSbscrptnApi, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"QT_TP",    ":qt_tp",    offsetof(QtSbscrptnApi, qtTp),    0,    DB_COL_STRING,    8,  0 },
    {"LVL",    ":lvl",    offsetof(QtSbscrptnApi, lvl),    0,    DB_COL_STRING,    50,  0 },
    {"INSTRCTN_SEND_TM",    ":instrctn_send_tm",    offsetof(QtSbscrptnApi, instrctnSendTm),    offsetof(QtSbscrptnApi, pInstrctnSendTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(QtSbscrptnApi, crtTm),    offsetof(QtSbscrptnApi, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"RQST_ID",    ":rqst_id",    offsetof(QtSbscrptnApi, rqstId),    0,    DB_COL_STRING,    50,  0 },
};

static DbColInfoT gQtSbscrptnApiDbCntInfo[] =
{
    {"",                 ":count",           offsetof(QtSbscrptnApiCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( QtSbscrptnApi* pData );
ResCodeT FreeDateTimeType( QtSbscrptnApi* pData );
ResCodeT SelectQtSbscrptnApi(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertQtSbscrptnApi(int32 connId, QtSbscrptnApi* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertQtSbscrptnApi" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gQtSbscrptnApiDbInfo,
                            DB_QTSBSCRPTNAPI_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateQtSbscrptnApiByKey(int32 connId, QtSbscrptnApi* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateQtSbscrptnApiByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_QTSBSCRPTNAPI_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gQtSbscrptnApiDbInfo[keyIdx].colFlag,
                                    gQtSbscrptnApiDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE QT_SBSCRPTN_API SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_QTSBSCRPTNAPI_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gQtSbscrptnApiDbInfo[colIdx].colFlag,
                                    gQtSbscrptnApiDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gQtSbscrptnApiDbInfo, 
                    DB_QTSBSCRPTNAPI_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfQtSbscrptnApi(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfQtSbscrptnApi" );

    int32       stmtId;
    QtSbscrptnApiCntT    QtSbscrptnApiCnt = {0};
    QtSbscrptnApiCntT *  pQtSbscrptnApiCnt = &QtSbscrptnApiCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_QTSBSCRPTNAPI_CNT_NUM,
                        gQtSbscrptnApiDbCntInfo, (void *) pQtSbscrptnApiCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = QtSbscrptnApiCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetResultCntByUsrAndQttp(int32 connId, char* name, char* mktTp, char* qtTp, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfQtSbscrptnApi" );

    char sql[1000];
    int32       stmtId;
    QtSbscrptnApiCntT    QtSbscrptnApiCnt = {0};
    QtSbscrptnApiCntT *  pQtSbscrptnApiCnt = &QtSbscrptnApiCnt;

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "SELECT COUNT(*) FROM QT_SBSCRPTN_API ");
    sprintf(sql, "%s USR_LGN_NM = '%s' AND MKT_TP = '%s' AND QT_TP = '%s' ", sql, name, mktTp, qtTp);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_QTSBSCRPTNAPI_CNT_NUM,
                        gQtSbscrptnApiDbCntInfo, (void *) pQtSbscrptnApiCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = QtSbscrptnApiCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT FetchNextQtSbscrptnApi( BOOL * pFrstFlag, int32 connId, QtSbscrptnApi* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextQtSbscrptnApi" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectQtSbscrptnApi(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_QTSBSCRPTNAPI_TOT_COLMN, 
                            gQtSbscrptnApiDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DeleteQtSbscrptnByUsrAndQttp(int32 connId, char* name, char* mktTp, char* qtTp)
{
    ResCodeT rc = NO_ERR;
    char sql[1000];
    int32  stmtId = 0;

    BEGIN_FUNCTION("DeleteQtSbscrptnApi");

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "DELETE FROM QT_SBSCRPTN_API WHERE");
    sprintf(sql, "%s USR_LGN_NM = '%s' AND MKT_TP = '%s' AND QT_TP = '%s' ", sql, name, mktTp, qtTp);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DeleteQtSbscrptnApi(int32 connId, QtSbscrptnApi* pKey)
{
    ResCodeT rc = NO_ERR;
    char sql[1000];
    int32  stmtId = 0;

    BEGIN_FUNCTION("DeleteQtSbscrptnApi");

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "DELETE FROM QT_SBSCRPTN_API WHERE");
    sprintf(sql, "%s USR_LGN_NM = '%s' ", sql, pKey->usrLgnNm);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DeleteAllQtSbscrptnApi(int32 connId)
{
    ResCodeT rc = NO_ERR;
    char sql[1000];
    int32  stmtId = 0;

    BEGIN_FUNCTION("DeleteAllQtSbscrptnApi");

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "DELETE QT_SBSCRPTN_API ");

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectQtSbscrptnApi(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectQtSbscrptnApi" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( QtSbscrptnApi* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->instrctnSendTm, &pData->pInstrctnSendTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( QtSbscrptnApi* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pInstrctnSendTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
