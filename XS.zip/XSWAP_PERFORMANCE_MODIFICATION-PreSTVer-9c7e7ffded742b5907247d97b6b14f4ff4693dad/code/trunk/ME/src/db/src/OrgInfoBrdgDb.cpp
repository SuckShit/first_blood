/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OrgInfoBrdgDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ORGINFOBRDG_CNT_NUM         1

#define DB_ORGINFOBRDG_TOT_COLMN       (sizeof(gOrgInfoBrdgDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ORG_INFO_BRDG "
"(ORG_SRNO,ORG_ID,BRDG_ORG_ST,BRDG_ORG_ORDR,BRDG_INTNTN_F,BRDG_PRVLG_F,BRDG_PRVLG_F_NEXT,MDFY_ST,BRDG_PRVLG_UPD_TM,BRDG_PRVLG_UPD_USR_NM,USR_LGN_NM,DLR_UPD_TM,DLR_UPD_USR_NM,CRDT_OPRTNG_ST,CRDT_OPRTR,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:org_srno,:org_id,:brdg_org_st,:brdg_org_ordr,:brdg_intntn_f,:brdg_prvlg_f,:brdg_prvlg_f_next,:mdfy_st,:brdg_prvlg_upd_tm,:brdg_prvlg_upd_usr_nm,:usr_lgn_nm,:dlr_upd_tm,:dlr_upd_usr_nm,:crdt_oprtng_st,:crdt_oprtr,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ORG_INFO_BRDG ";
static char gSqlSelect[] = "SELECT ORG_SRNO,ORG_ID,BRDG_ORG_ST,BRDG_ORG_ORDR,BRDG_INTNTN_F,BRDG_PRVLG_F,BRDG_PRVLG_F_NEXT,MDFY_ST,BRDG_PRVLG_UPD_TM,NVL(BRDG_PRVLG_UPD_USR_NM, ' '),NVL(USR_LGN_NM, ' '),DLR_UPD_TM,NVL(DLR_UPD_USR_NM, ' '),NVL(CRDT_OPRTNG_ST, ' '),NVL(CRDT_OPRTR, ' '),CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM ORG_INFO_BRDG ";
static DbColInfoT gOrgInfoBrdgDbInfo[] = 
{
    {"ORG_SRNO",    ":org_srno",    offsetof(OrgInfoBrdg, orgSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(OrgInfoBrdg, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"BRDG_ORG_ST",    ":brdg_org_st",    offsetof(OrgInfoBrdg, brdgOrgSt),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_ORG_ORDR",    ":brdg_org_ordr",    offsetof(OrgInfoBrdg, brdgOrgOrdr),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"BRDG_INTNTN_F",    ":brdg_intntn_f",    offsetof(OrgInfoBrdg, brdgIntntnF),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_PRVLG_F",    ":brdg_prvlg_f",    offsetof(OrgInfoBrdg, brdgPrvlgF),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_PRVLG_F_NEXT",    ":brdg_prvlg_f_next",    offsetof(OrgInfoBrdg, brdgPrvlgFNext),    0,    DB_COL_STRING,    8,  0 },
    {"MDFY_ST",    ":mdfy_st",    offsetof(OrgInfoBrdg, mdfySt),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_PRVLG_UPD_TM",    ":brdg_prvlg_upd_tm",    offsetof(OrgInfoBrdg, brdgPrvlgUpdTm),    offsetof(OrgInfoBrdg, pBrdgPrvlgUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"BRDG_PRVLG_UPD_USR_NM",    ":brdg_prvlg_upd_usr_nm",    offsetof(OrgInfoBrdg, brdgPrvlgUpdUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"USR_LGN_NM",    ":usr_lgn_nm",    offsetof(OrgInfoBrdg, usrLgnNm),    0,    DB_COL_STRING,    100,  0 },
    {"DLR_UPD_TM",    ":dlr_upd_tm",    offsetof(OrgInfoBrdg, dlrUpdTm),    offsetof(OrgInfoBrdg, pDlrUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"DLR_UPD_USR_NM",    ":dlr_upd_usr_nm",    offsetof(OrgInfoBrdg, dlrUpdUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CRDT_OPRTNG_ST",    ":crdt_oprtng_st",    offsetof(OrgInfoBrdg, crdtOprtngSt),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_OPRTR",    ":crdt_oprtr",    offsetof(OrgInfoBrdg, crdtOprtr),    0,    DB_COL_STRING,    100,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(OrgInfoBrdg, crtTm),    offsetof(OrgInfoBrdg, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(OrgInfoBrdg, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OrgInfoBrdg, updTm),    offsetof(OrgInfoBrdg, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OrgInfoBrdg, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gOrgInfoBrdgDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OrgInfoBrdgCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( OrgInfoBrdg* pData );
ResCodeT FreeDateTimeType( OrgInfoBrdg* pData );
ResCodeT SelectOrgInfoBrdg(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOrgInfoBrdg(int32 connId, OrgInfoBrdg* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOrgInfoBrdg" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOrgInfoBrdgDbInfo,
                            DB_ORGINFOBRDG_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOrgInfoBrdgByKey(int32 connId, OrgInfoBrdg* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrgInfoBrdgByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORGINFOBRDG_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOrgInfoBrdgDbInfo[keyIdx].colFlag,
                                    gOrgInfoBrdgDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORG_INFO_BRDG SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORGINFOBRDG_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrgInfoBrdgDbInfo[colIdx].colFlag,
                                    gOrgInfoBrdgDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrgInfoBrdgDbInfo, 
                    DB_ORGINFOBRDG_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateOrgInfoBrdgByKeyRpt(int32 connId, OrgInfoBrdg* pKeyData, OrgInfoBrdg* pNewData, 
                                vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrgInfoBrdgByKeyRpt");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char *pTmpVal = NULL;
    char tmpVal[300] = {0};
    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORGINFOBRDG_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        pTmpVal = (char *)ADDRESS_ADD_OFFSET(pKeyData, gOrgInfoBrdgDbInfo[keyIdx].valOffset);
        memcpy( tmpVal, pTmpVal, gOrgInfoBrdgDbInfo[keyIdx].valSize );
        
        sprintf( keySql, "%s %s = '%s' AND", 
                                    keySql,
                                    gOrgInfoBrdgDbInfo[keyIdx].colFlag,
                                    tmpVal );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORG_INFO_BRDG SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORGINFOBRDG_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrgInfoBrdgDbInfo[colIdx].colFlag,
                                    gOrgInfoBrdgDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pNewData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrgInfoBrdgDbInfo, 
                    DB_ORGINFOBRDG_TOT_COLMN, pColFlg, (void *) pNewData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pNewData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfOrgInfoBrdg(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrgInfoBrdg" );

    int32       stmtId;
    OrgInfoBrdgCntT    OrgInfoBrdgCnt = {0};
    OrgInfoBrdgCntT *  pOrgInfoBrdgCnt = &OrgInfoBrdgCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORGINFOBRDG_CNT_NUM,
                        gOrgInfoBrdgDbCntInfo, (void *) pOrgInfoBrdgCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrgInfoBrdgCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextOrgInfoBrdg( BOOL * pFrstFlag, int32 connId, OrgInfoBrdg* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrgInfoBrdg" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOrgInfoBrdg(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORGINFOBRDG_TOT_COLMN, 
                            gOrgInfoBrdgDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOrgInfoBrdg(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrgInfoBrdg" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( OrgInfoBrdg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->brdgPrvlgUpdTm, &pData->pBrdgPrvlgUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->dlrUpdTm, &pData->pDlrUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( OrgInfoBrdg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pBrdgPrvlgUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pDlrUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
