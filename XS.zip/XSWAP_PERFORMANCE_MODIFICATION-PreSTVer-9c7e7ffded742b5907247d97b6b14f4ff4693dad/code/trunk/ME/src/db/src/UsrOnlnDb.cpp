/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "UsrOnlnDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_USRONLN_CNT_NUM         1

#define DB_USRONLN_TOT_COLMN       (sizeof(gUsrOnlnDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO USR_ONLN "
"(USR_NM,SESN_ID,LGN_TP,LGN_TM,LGN_IP,API_F) VALUES "
"(:usr_nm,:sesn_id,:lgn_tp,:lgn_tm,:lgn_ip,:api_f) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM USR_ONLN ";
static char gSqlSelect[] = "SELECT USR_NM,SESN_ID,LGN_TP,LGN_TM,NVL(LGN_IP, ' '),NVL(API_F, ' ') FROM USR_ONLN ";
static DbColInfoT gUsrOnlnDbInfo[] = 
{
    {"USR_NM",    ":usr_nm",    offsetof(UsrOnln, usrNm),    0,    DB_COL_STRING,    100,  0 },
    {"SESN_ID",    ":sesn_id",    offsetof(UsrOnln, sesnId),    0,    DB_COL_STRING,    100,  0 },
    {"LGN_TP",    ":lgn_tp",    offsetof(UsrOnln, lgnTp),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"LGN_TM",    ":lgn_tm",    offsetof(UsrOnln, lgnTm),    offsetof(UsrOnln, pLgnTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"LGN_IP",    ":lgn_ip",    offsetof(UsrOnln, lgnIp),    0,    DB_COL_STRING,    50,  0 },
    {"API_F",    ":api_f",    offsetof(UsrOnln, apiF),    0,    DB_COL_STRING,    8,  0 },
};

static DbColInfoT gUsrOnlnDbCntInfo[] =
{
    {"",                 ":count",           offsetof(UsrOnlnCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( UsrOnln* pData );
ResCodeT FreeDateTimeType( UsrOnln* pData );
ResCodeT SelectUsrOnln(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertUsrOnln(int32 connId, UsrOnln* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertUsrOnln" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gUsrOnlnDbInfo,
                            DB_USRONLN_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateUsrOnlnByKey(int32 connId, UsrOnln* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateUsrOnlnByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_USRONLN_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gUsrOnlnDbInfo[keyIdx].colFlag,
                                    gUsrOnlnDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE USR_ONLN SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_USRONLN_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gUsrOnlnDbInfo[colIdx].colFlag,
                                    gUsrOnlnDbInfo[colIdx].colName );
    }
    LOG_DEBUG("SQL %s", updateSql);
    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gUsrOnlnDbInfo, 
                    DB_USRONLN_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateUsrOnlnByKeyEqlValue(int32 connId, UsrOnln* pData, vectorT * pKeyFlg, vectorT * pColFlg, char*  addKey)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateUsrOnlnByKeyEqlValue");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_USRONLN_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gUsrOnlnDbInfo[keyIdx].colFlag,
                                    gUsrOnlnDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE USR_ONLN SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_USRONLN_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gUsrOnlnDbInfo[colIdx].colFlag,
                                    gUsrOnlnDbInfo[colIdx].colName );
    }
    strcat(updateSql, addKey);
    LOG_DEBUG("SQL %s", updateSql);
    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gUsrOnlnDbInfo, 
                    DB_USRONLN_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfUsrOnln(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfUsrOnln" );

    int32       stmtId;
    UsrOnlnCntT    UsrOnlnCnt = {0};
    UsrOnlnCntT *  pUsrOnlnCnt = &UsrOnlnCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USRONLN_CNT_NUM,
                        gUsrOnlnDbCntInfo, (void *) pUsrOnlnCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrOnlnCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetCntByUsrNm(int32 connId, char* strUsrNm, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetCntByUsrNm" );

    char sql[1000];
    int32  stmtId = 0;

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "SELECT COUNT(*) FROM USR_ONLN WHERE");
    sprintf(sql, "%s USR_NM = '%s' ", sql, strUsrNm);

    UsrOnlnCntT    UsrOnlnCnt = {0};
    UsrOnlnCntT *  pUsrOnlnCnt = &UsrOnlnCnt;

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USRONLN_CNT_NUM,
                        gUsrOnlnDbCntInfo, (void *) pUsrOnlnCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrOnlnCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetCntByApiF(int32 connId, char* apiF, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetCntByApiF" );

    char sql[1000];
    int32  stmtId = 0;

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "SELECT COUNT(*) FROM USR_ONLN WHERE");
    sprintf(sql, "%s API_F = '%s' ", sql, apiF);

    UsrOnlnCntT    UsrOnlnCnt = {0};
    UsrOnlnCntT *  pUsrOnlnCnt = &UsrOnlnCnt;

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USRONLN_CNT_NUM,
                        gUsrOnlnDbCntInfo, (void *) pUsrOnlnCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrOnlnCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextUsrOnln( BOOL * pFrstFlag, int32 connId, UsrOnln* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextUsrOnln" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectUsrOnln(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USRONLN_TOT_COLMN, 
                            gUsrOnlnDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DeleteUsrOnln(int32 connId, UsrOnlnKey* pKey)
{
    ResCodeT rc = NO_ERR;
    char sql[1000];
    int32  stmtId = 0;

    BEGIN_FUNCTION("DeleteUsrOnln");

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "DELETE FROM USR_ONLN WHERE");
    sprintf(sql, "%s USR_NM = '%s' ", sql, pKey->usrNm);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DeleteApiUsrByFlag(int32 connId, int32 iFlag)
{
    ResCodeT rc = NO_ERR;
    char sql[1000];
    int32  stmtId = 0;

    BEGIN_FUNCTION("DeleteUsrOnln");

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "DELETE FROM USR_ONLN WHERE");
    sprintf(sql, "%s API_F = %d ", sql, iFlag);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT DeleteApiUsrByNameAndFlag(int32 connId, char* name, int32 iFlag)
{
    ResCodeT rc = NO_ERR;
    char sql[1000];
    int32  stmtId = 0;

    BEGIN_FUNCTION("DeleteUsrOnln");

    memset(sql, 0, sizeof(sql));
    //make where condition
    strcpy(sql, "DELETE FROM USR_ONLN WHERE");
    sprintf(sql, "%s USR_NM = '%s' AND API_F = %d ", sql, name, iFlag);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectUsrOnln(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectUsrOnln" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( UsrOnln* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->lgnTm, &pData->pLgnTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( UsrOnln* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pLgnTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateUsrOnlnLgnTpl(int32 connId, int32 orgId, int32 oldLgnTp, int32 newLgnTp)
{
    BEGIN_FUNCTION("UpdateUsrOnlnLgnTpl");
    ResCodeT                rc = NO_ERR;
    int32                   stmtId = 0;
    char                    updateSql[DB_COMM_SQL_TOT_LEN] = {0};

    snprintf(updateSql, sizeof(updateSql), 
        "UPDATE USR_ONLN uo SET uo.LGN_TP = %d WHERE EXISTS \
(SELECT 1 FROM USR u WHERE uo.USR_NM = u.USR_LGN_NM AND uo.LGN_TP = %d AND u.org_id = %d) ",
        newLgnTp, orgId, oldLgnTp );

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

