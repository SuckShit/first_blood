/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OrgInfoDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ORGINFO_CNT_NUM         1

#define DB_ORGINFO_TOT_COLMN       (sizeof(gOrgInfoDbInfo) / sizeof(DbColInfoT))
#define DB_ORGINFO_JOIN_TOT_COLMN  (sizeof(gOrgInfoDbJoinInfo) / sizeof(gOrgInfoDbJoinInfo[0]))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ORG_INFO "
"(ORG_SRNO,ORG_ID,ORG_CD,ORG_FULL_NM_CN,ORG_NM_CN,ORG_FULL_NM_EN,ORG_NM_EN,ORG_ST,ORG_TP,ORG_IRS_ST,CRDT_MTHD,CRDT_UPD_MTHD,CRDT_VLD_ORG_F,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,CRDT_OPRTNG_ST,CRDT_OPRTR,TEL,FAX_NO,LGL_RPRSNTV,ADRS_FRST_DESC,ADRS_SCND_DESC,BRDG_ORDR_RFRSH_F,LAST_BIL_NOTE_TM) VALUES "
"(:org_srno,:org_id,:org_cd,:org_full_nm_cn,:org_nm_cn,:org_full_nm_en,:org_nm_en,:org_st,:org_tp,:org_irs_st,:crdt_mthd,:crdt_upd_mthd,:crdt_vld_org_f,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:crdt_oprtng_st,:crdt_oprtr,:tel,:fax_no,:lgl_rprsntv,:adrs_frst_desc,:adrs_scnd_desc,:brdg_ordr_rfrsh_f,:last_bil_note_tm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ORG_INFO ";
static char gSqlSelect[] = "SELECT ORG_SRNO,ORG_ID,ORG_CD,ORG_FULL_NM_CN,ORG_NM_CN,ORG_FULL_NM_EN,ORG_NM_EN,ORG_ST,ORG_TP,ORG_IRS_ST,NVL(CRDT_MTHD, ' '),NVL(CRDT_UPD_MTHD, ' '),NVL(CRDT_VLD_ORG_F, ' '),CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,NVL(CRDT_OPRTNG_ST, ' '),NVL(CRDT_OPRTR, ' '),NVL(TEL, ' '),NVL(FAX_NO, ' '),NVL(LGL_RPRSNTV, ' '),NVL(ADRS_FRST_DESC, ' '),NVL(ADRS_SCND_DESC, ' '),BRDG_ORDR_RFRSH_F,LAST_BIL_NOTE_TM FROM ORG_INFO ";

// Count(1)
static char gSqlSelectJoinCount[] = "SELECT COUNT(1) FROM ORG_INFO AA, (SELECT ORG_ID,"
"LISTAGG(MKT_TP, ',') WITHIN GROUP(ORDER BY ORG_ID) AS MKT_TP,LISTAGG(ST, ',') WITHIN GROUP(ORDER BY MKT_TP) AS ST "
"FROM (SELECT A.ORG_SRNO,A.ORG_ID,A.ORG_CD,A.ORG_FULL_NM_CN,A.ORG_NM_CN,A.ORG_FULL_NM_EN,A.ORG_NM_EN,A.ORG_ST,A.ORG_TP,A.ORG_IRS_ST,"
"A.CRDT_MTHD,A.CRDT_UPD_MTHD,A.CRDT_VLD_ORG_F,A.CRT_TM,A.CRT_USR_NM,A.UPD_TM,A.UPD_USR_NM,A.CRDT_OPRTNG_ST,A.CRDT_OPRTR,A.TEL,A.FAX_NO,"
"A.LGL_RPRSNTV,A.ADRS_FRST_DESC,A.ADRS_SCND_DESC,A.BRDG_ORDR_RFRSH_F,A.LAST_BIL_NOTE_TM,B.MKT_TP,B.ST FROM ORG_INFO A LEFT JOIN ORG_MKT_PRVLG B "
"ON A.ORG_ID = B.ORG_ID ORDER BY B.MKT_TP) GROUP BY ORG_ID) BB WHERE AA.ORG_ID = BB.ORG_ID ORDER BY AA.ORG_ID ";

// Select
static char gSqlSelectJoin[] = "SELECT AA.ORG_SRNO,AA.ORG_ID,AA.ORG_CD,AA.ORG_FULL_NM_CN,AA.ORG_NM_CN,AA.ORG_FULL_NM_EN,AA.ORG_NM_EN,AA.ORG_ST,"
"AA.ORG_TP,AA.ORG_IRS_ST,NVL(AA.CRDT_MTHD, ' '),NVL(AA.CRDT_UPD_MTHD, ' '),NVL(AA.CRDT_VLD_ORG_F, ' '),AA.CRT_TM,AA.CRT_USR_NM,AA.UPD_TM,"
"AA.UPD_USR_NM,NVL(AA.CRDT_OPRTNG_ST, ' '),NVL(AA.CRDT_OPRTR, ' '),NVL(AA.TEL, ' '),NVL(AA.FAX_NO, ' '),NVL(AA.LGL_RPRSNTV, ' '),"
"NVL(AA.ADRS_FRST_DESC, ' '),NVL(AA.ADRS_SCND_DESC, ' '),AA.BRDG_ORDR_RFRSH_F,AA.LAST_BIL_NOTE_TM,BB.MKT_TP,BB.ST FROM ORG_INFO AA, "
"(SELECT ORG_ID,LISTAGG(MKT_TP, ',') WITHIN GROUP(ORDER BY ORG_ID) AS MKT_TP,LISTAGG(ST, ',') WITHIN GROUP(ORDER BY MKT_TP) AS ST "
"FROM (SELECT A.ORG_SRNO,A.ORG_ID,A.ORG_CD,A.ORG_FULL_NM_CN,A.ORG_NM_CN,A.ORG_FULL_NM_EN,A.ORG_NM_EN,A.ORG_ST,A.ORG_TP,A.ORG_IRS_ST,"
"A.CRDT_MTHD,A.CRDT_UPD_MTHD,A.CRDT_VLD_ORG_F,A.CRT_TM,A.CRT_USR_NM,A.UPD_TM,A.UPD_USR_NM,A.CRDT_OPRTNG_ST,A.CRDT_OPRTR,A.TEL,A.FAX_NO,"
"A.LGL_RPRSNTV,A.ADRS_FRST_DESC,A.ADRS_SCND_DESC,A.BRDG_ORDR_RFRSH_F,A.LAST_BIL_NOTE_TM,B.MKT_TP,B.ST FROM ORG_INFO A LEFT JOIN ORG_MKT_PRVLG B "
"ON A.ORG_ID = B.ORG_ID ORDER BY B.MKT_TP) GROUP BY ORG_ID) BB WHERE AA.ORG_ID = BB.ORG_ID ORDER BY AA.ORG_ID ";

static DbColInfoT gOrgInfoDbInfo[] = 
{
    {"ORG_SRNO",    ":org_srno",    offsetof(OrgInfo, orgSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(OrgInfo, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_CD",    ":org_cd",    offsetof(OrgInfo, orgCd),    0,    DB_COL_STRING,    50,  0 },
    {"ORG_FULL_NM_CN",    ":org_full_nm_cn",    offsetof(OrgInfo, orgFullNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_NM_CN",    ":org_nm_cn",    offsetof(OrgInfo, orgNmCn),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_FULL_NM_EN",    ":org_full_nm_en",    offsetof(OrgInfo, orgFullNmEn),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_NM_EN",    ":org_nm_en",    offsetof(OrgInfo, orgNmEn),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_ST",    ":org_st",    offsetof(OrgInfo, orgSt),    0,    DB_COL_STRING,    8,  0 },
    {"ORG_TP",    ":org_tp",    offsetof(OrgInfo, orgTp),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_IRS_ST",    ":org_irs_st",    offsetof(OrgInfo, orgIrsSt),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_MTHD",    ":crdt_mthd",    offsetof(OrgInfo, crdtMthd),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_UPD_MTHD",    ":crdt_upd_mthd",    offsetof(OrgInfo, crdtUpdMthd),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_VLD_ORG_F",    ":crdt_vld_org_f",    offsetof(OrgInfo, crdtVldOrgF),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(OrgInfo, crtTm),    offsetof(OrgInfo, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(OrgInfo, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OrgInfo, updTm),    offsetof(OrgInfo, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OrgInfo, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CRDT_OPRTNG_ST",    ":crdt_oprtng_st",    offsetof(OrgInfo, crdtOprtngSt),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_OPRTR",    ":crdt_oprtr",    offsetof(OrgInfo, crdtOprtr),    0,    DB_COL_STRING,    100,  0 },
    {"TEL",    ":tel",    offsetof(OrgInfo, tel),    0,    DB_COL_STRING,    100,  0 },
    {"FAX_NO",    ":fax_no",    offsetof(OrgInfo, faxNo),    0,    DB_COL_STRING,    100,  0 },
    {"LGL_RPRSNTV",    ":lgl_rprsntv",    offsetof(OrgInfo, lglRprsntv),    0,    DB_COL_STRING,    300,  0 },
    {"ADRS_FRST_DESC",    ":adrs_frst_desc",    offsetof(OrgInfo, adrsFrstDesc),    0,    DB_COL_STRING,    300,  0 },
    {"ADRS_SCND_DESC",    ":adrs_scnd_desc",    offsetof(OrgInfo, adrsScndDesc),    0,    DB_COL_STRING,    300,  0 },
    {"BRDG_ORDR_RFRSH_F",    ":brdg_ordr_rfrsh_f",    offsetof(OrgInfo, brdgOrdrRfrshF),    0,    DB_COL_STRING,    8,  0 },
    {"LAST_BIL_NOTE_TM",    ":last_bil_note_tm",    offsetof(OrgInfo, lastBilNoteTm),    offsetof(OrgInfo, pLastBilNoteTm),    DB_COL_TIMESTAMP,    50,  0 },
};

static DbColInfoT gOrgInfoDbJoinInfo[] = 
{
    {"ORG_SRNO",    ":org_srno",    offsetof(OrgInfoJoinT, orgSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(OrgInfoJoinT, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_CD",    ":org_cd",    offsetof(OrgInfoJoinT, orgCd),    0,    DB_COL_STRING,    50,  0 },
    {"ORG_FULL_NM_CN",    ":org_full_nm_cn",    offsetof(OrgInfoJoinT, orgFullNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_NM_CN",    ":org_nm_cn",    offsetof(OrgInfoJoinT, orgNmCn),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_FULL_NM_EN",    ":org_full_nm_en",    offsetof(OrgInfoJoinT, orgFullNmEn),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_NM_EN",    ":org_nm_en",    offsetof(OrgInfoJoinT, orgNmEn),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_ST",    ":org_st",    offsetof(OrgInfoJoinT, orgSt),    0,    DB_COL_STRING,    8,  0 },
    {"ORG_TP",    ":org_tp",    offsetof(OrgInfoJoinT, orgTp),    0,    DB_COL_STRING,    300,  0 },
    {"ORG_IRS_ST",    ":org_irs_st",    offsetof(OrgInfoJoinT, orgIrsSt),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_MTHD",    ":crdt_mthd",    offsetof(OrgInfoJoinT, crdtMthd),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_UPD_MTHD",    ":crdt_upd_mthd",    offsetof(OrgInfoJoinT, crdtUpdMthd),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_VLD_ORG_F",    ":crdt_vld_org_f",    offsetof(OrgInfoJoinT, crdtVldOrgF),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(OrgInfoJoinT, crtTm),    offsetof(OrgInfoJoinT, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(OrgInfoJoinT, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OrgInfoJoinT, updTm),    offsetof(OrgInfoJoinT, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OrgInfoJoinT, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CRDT_OPRTNG_ST",    ":crdt_oprtng_st",    offsetof(OrgInfoJoinT, crdtOprtngSt),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_OPRTR",    ":crdt_oprtr",    offsetof(OrgInfoJoinT, crdtOprtr),    0,    DB_COL_STRING,    100,  0 },
    {"TEL",    ":tel",    offsetof(OrgInfoJoinT, tel),    0,    DB_COL_STRING,    100,  0 },
    {"FAX_NO",    ":fax_no",    offsetof(OrgInfoJoinT, faxNo),    0,    DB_COL_STRING,    100,  0 },
    {"LGL_RPRSNTV",    ":lgl_rprsntv",    offsetof(OrgInfoJoinT, lglRprsntv),    0,    DB_COL_STRING,    300,  0 },
    {"ADRS_FRST_DESC",    ":adrs_frst_desc",    offsetof(OrgInfoJoinT, adrsFrstDesc),    0,    DB_COL_STRING,    300,  0 },
    {"ADRS_SCND_DESC",    ":adrs_scnd_desc",    offsetof(OrgInfoJoinT, adrsScndDesc),    0,    DB_COL_STRING,    300,  0 },
    {"BRDG_ORDR_RFRSH_F",    ":brdg_ordr_rfrsh_f",    offsetof(OrgInfoJoinT, brdgOrdrRfrshF),    0,    DB_COL_STRING,    8,  0 },
    {"LAST_BIL_NOTE_TM",    ":last_bil_note_tm",    offsetof(OrgInfoJoinT, lastBilNoteTm),    offsetof(OrgInfoJoinT, pLastBilNoteTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"MKT_TP",              ":mkt_tp",    offsetof(OrgInfoJoinT, mktTp),    0,    DB_COL_STRING,    8,  0 },
    {"ST",                  ":st",        offsetof(OrgInfoJoinT, st),       0,    DB_COL_STRING,    8,  0 },
};

static DbColInfoT gOrgInfoDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OrgInfoCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( OrgInfo* pData );
ResCodeT FreeDateTimeType( OrgInfo* pData );
ResCodeT SelectOrgInfo(int32 connId, int32 * pStmntId);
ResCodeT SelectOrgInfoJoinOrgMktPrvlg(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOrgInfo(int32 connId, OrgInfo* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOrgInfo" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOrgInfoDbInfo,
                            DB_ORGINFO_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOrgInfoByKey(int32 connId, OrgInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrgInfoByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORGINFO_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOrgInfoDbInfo[keyIdx].colFlag,
                                    gOrgInfoDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORG_INFO SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORGINFO_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrgInfoDbInfo[colIdx].colFlag,
                                    gOrgInfoDbInfo[colIdx].colName );
    }
    LOG_DEBUG("SQL %s", updateSql);
    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrgInfoDbInfo, 
                    DB_ORGINFO_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfOrgInfo(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrgInfo" );

    int32          stmtId;
    OrgInfoCntT    OrgInfoCnt  = {0};
    OrgInfoCntT*   pOrgInfoCnt = &OrgInfoCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORGINFO_CNT_NUM,
                        gOrgInfoDbCntInfo, (void *) pOrgInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrgInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfOrgInfoJoinOrgMktPrvlg(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrgInfoJoinOrgMktPrvlg" );

    int32          stmtId;
    OrgInfoCntT    OrgInfoCnt  = {0};
    OrgInfoCntT*   pOrgInfoCnt = &OrgInfoCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectJoinCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORGINFO_CNT_NUM,
                        gOrgInfoDbCntInfo, (void *) pOrgInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrgInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextOrgInfo( BOOL * pFrstFlag, int32 connId, OrgInfo* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrgInfo" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOrgInfo(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORGINFO_TOT_COLMN, 
                            gOrgInfoDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextOrgInfoJoinOrgMktPrvlg(BOOL* pFrstFlag, int32 connId, OrgInfoJoinT* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrgInfoJoinOrgMktPrvlg" );

    static int32 stmntJoinId;

    if ( *pFrstFlag ) {
        rc = SelectOrgInfoJoinOrgMktPrvlg(connId, &stmntJoinId);
        RAISE_ERR(rc, RTN);

        *pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntJoinId, DB_ORGINFO_JOIN_TOT_COLMN, 
                            gOrgInfoDbJoinInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntJoinId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntJoinId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOrgInfo(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrgInfo" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOrgInfoJoinOrgMktPrvlg(int32 connId, int32* pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrgInfoJoinOrgMktPrvlg" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelectJoin, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT FmtDateTimeType( OrgInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->lastBilNoteTm, &pData->pLastBilNoteTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( OrgInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pLastBilNoteTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
