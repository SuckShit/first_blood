/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OcoOrdrDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_OCOORDR_CNT_NUM         1

#define DB_OCOORDR_TOT_COLMN       (sizeof(gOcoOrdrDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO OCO_ORDR "
"(OCO_ID,CLNT_SRNO,ST,TRDR_NM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:oco_id,:clnt_srno,:st,:trdr_nm,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM OCO_ORDR ";
static char gSqlKeySelect[] = "SELECT COUNT(*) FROM OCO_ORDR WHERE OCO_ID = '%s' ";
static char gSqlSelect[] = "SELECT OCO_ID,NVL(CLNT_SRNO, ' '),ST,TRDR_NM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM OCO_ORDR ";
static DbColInfoT gOcoOrdrDbInfo[] = 
{
    {"OCO_ID",    ":oco_id",    offsetof(OcoOrdr, ocoId),    0,    DB_COL_STRING,    50,  0 },
    {"CLNT_SRNO",    ":clnt_srno",    offsetof(OcoOrdr, clntSrno),    0,    DB_COL_STRING,    50,  0 },
    {"ST",    ":st",    offsetof(OcoOrdr, st),    0,    DB_COL_STRING,    8,  0 },
    {"TRDR_NM",    ":trdr_nm",    offsetof(OcoOrdr, trdrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(OcoOrdr, crtTm),    offsetof(OcoOrdr, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(OcoOrdr, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OcoOrdr, updTm),    offsetof(OcoOrdr, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OcoOrdr, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gOcoOrdrDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OcoOrdrCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( OcoOrdr* pData );
ResCodeT FreeDateTimeType( OcoOrdr* pData );
ResCodeT SelectOcoOrdr(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOcoOrdr(int32 connId, OcoOrdr* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOcoOrdr" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOcoOrdrDbInfo,
                            DB_OCOORDR_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOcoOrdrByKey(int32 connId, OcoOrdr* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOcoOrdrByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_OCOORDR_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOcoOrdrDbInfo[keyIdx].colFlag,
                                    gOcoOrdrDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE OCO_ORDR SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_OCOORDR_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOcoOrdrDbInfo[colIdx].colFlag,
                                    gOcoOrdrDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOcoOrdrDbInfo, 
                    DB_OCOORDR_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfOcoOrdr(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOcoOrdr" );

    int32       stmtId;
    OcoOrdrCntT    OcoOrdrCnt = {0};
    OcoOrdrCntT *  pOcoOrdrCnt = &OcoOrdrCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_OCOORDR_CNT_NUM,
                        gOcoOrdrDbCntInfo, (void *) pOcoOrdrCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = OcoOrdrCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextOcoOrdr( BOOL * pFrstFlag, int32 connId, OcoOrdr* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOcoOrdr" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOcoOrdr(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_OCOORDR_TOT_COLMN, 
                            gOcoOrdrDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOcoOrdr(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOcoOrdr" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( OcoOrdr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( OcoOrdr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchOcoOrdrByKey( int32 connId, char * pKey, BOOL * pFetchFlag )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchOrdrByKey" );

    int32 stmntId;
    OcoOrdrCntT    OcoOrdrCnt = {0};
    OcoOrdrCntT *  pOcoOrdrCnt = &OcoOrdrCnt;
    char updateSql[DB_COMM_SQL_TOT_LEN];
    
    * pFetchFlag = FALSE;

    sprintf( updateSql, gSqlKeySelect, pKey );

    rc = DbCmmnPrprSql( connId, updateSql, &stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_OCOORDR_CNT_NUM,
                        gOcoOrdrDbCntInfo, (void *) pOcoOrdrCnt );
    RAISE_ERR(rc, RTN);

    if ( OcoOrdrCnt.count )
    {
        * pFetchFlag = TRUE;
    }

    EXIT_BLOCK( );
    RETURN_RESCODE;
}