/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "ImixMsgOutDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_IMIXMSGOUT_CNT_NUM         1

#define DB_IMIXMSGOUT_TOT_COLMN       (sizeof(gImixMsgOutDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO IMIX_MSG_OUT "
"(SRC_IMIX_CD,MSG_F,MSG,MSG_TM) VALUES "
"(:src_imix_cd,:msg_f,:msg,:msg_tm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM IMIX_MSG_OUT ";
static char gSqlSelect[] = "SELECT SRC_IMIX_CD,MSG_F,NVL(MSG, ' '),MSG_TM FROM IMIX_MSG_OUT ";
static DbColInfoT gImixMsgOutDbInfo[] = 
{
    {"SRC_IMIX_CD",    ":src_imix_cd",    offsetof(ImixMsgOut, srcImixCd),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MSG_F",    ":msg_f",    offsetof(ImixMsgOut, msgF),    0,    DB_COL_STRING,    8,  0 },
    {"MSG",    ":msg",    offsetof(ImixMsgOut, msg),    0,    DB_COL_STRING,    4000,  0 },
    {"MSG_TM",    ":msg_tm",    offsetof(ImixMsgOut, msgTm),    offsetof(ImixMsgOut, pMsgTm),    DB_COL_TIMESTAMP,    50,  0 },
};

static DbColInfoT gImixMsgOutDbCntInfo[] =
{
    {"",                 ":count",           offsetof(ImixMsgOutCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( ImixMsgOut* pData );
ResCodeT FreeDateTimeType( ImixMsgOut* pData );
ResCodeT SelectImixMsgOut(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertImixMsgOut(int32 connId, ImixMsgOut* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertImixMsgOut" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gImixMsgOutDbInfo,
                            DB_IMIXMSGOUT_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateImixMsgOutByKey(int32 connId, ImixMsgOut* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateImixMsgOutByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_IMIXMSGOUT_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gImixMsgOutDbInfo[keyIdx].colFlag,
                                    gImixMsgOutDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE IMIX_MSG_OUT SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_IMIXMSGOUT_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gImixMsgOutDbInfo[colIdx].colFlag,
                                    gImixMsgOutDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gImixMsgOutDbInfo, 
                    DB_IMIXMSGOUT_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfImixMsgOut(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfImixMsgOut" );

    int32       stmtId;
    ImixMsgOutCntT    ImixMsgOutCnt = {0};
    ImixMsgOutCntT *  pImixMsgOutCnt = &ImixMsgOutCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_IMIXMSGOUT_CNT_NUM,
                        gImixMsgOutDbCntInfo, (void *) pImixMsgOutCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = ImixMsgOutCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextImixMsgOut( BOOL * pFrstFlag, int32 connId, ImixMsgOut* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextImixMsgOut" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectImixMsgOut(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_IMIXMSGOUT_TOT_COLMN, 
                            gImixMsgOutDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectImixMsgOut(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
BEGIN_FUNCTION( "SelectImixMsgOut" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( ImixMsgOut* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->msgTm, &pData->pMsgTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( ImixMsgOut* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pMsgTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
