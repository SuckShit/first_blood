/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "ocilib.h"
#include "common_macro.h"
#include "MemTxnDatTblDb.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/
#define INSERT_SQL "INSERT INTO MEM_TXN_DAT_%ld_TBL (TXN_DAT_SQNO,TXN_ELEM_SIZE,TXN_ELEM_CNT,PRE_DAT_SQNO,NXT_DAT_SQNO,MSG_SQNO,TXN_ELEM_DAT) VALUES (:txn_dat_sqno,:txn_elem_size,:txn_elem_cnt,:pre_dat_sqno,:nxt_dat_sqno,:msg_sqno, :txn_elem_dat)"
#define SELECT_SQL "SELECT TXN_DAT_SQNO,TXN_ELEM_SIZE,TXN_ELEM_CNT,PRE_DAT_SQNO,NXT_DAT_SQNO,MSG_SQNO,TXN_ELEM_DAT FROM MEM_TXN_DAT_%ld_TBL  "

#define MAX_DATA_CNT 5000
#define DB_MEMTXNDATTBL_TOT_COLMN       (sizeof(gMemTxnDatTblDbInfo) / sizeof(DbColInfoT))
/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[MAX_BUFF_LEN] = { 0 };
static char gSqlSelect[MAX_BUFF_LEN] = { 0 };
static DbStmt gInstSttmnt = { 0 };

static char gSqlSelectCount[] = "SELECT COUNT(*) FROM MEM_TXN_DAT_TBL ";
static DbColInfoT gMemTxnDatTblDbInfo[] = 
{
    {"TXN_DAT_SQNO",    ":txn_dat_sqno",    offsetof(DatCtrlT, dataSqno),        0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"TXN_ELEM_SIZE",   ":txn_elem_size",   offsetof(DatCtrlT, elemTtlSize),     0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"TXN_ELEM_CNT",    ":txn_elem_cnt",    offsetof(DatCtrlT, elemCnt),         0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"PRE_DAT_SQNO",    ":pre_dat_sqno",    offsetof(DatCtrlT, prevDataSqno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"NXT_DAT_SQNO",    ":nxt_dat_sqno",    offsetof(DatCtrlT, nextDataSqno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MSG_SQNO",        ":msg_sqno",        offsetof(DatCtrlT, currMsgSqno),     0,    DB_COL_INT32,    sizeof(int32),  0 },
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InitMemTxnDatTblSqlQuery(int32 connId, int32 setId)
{
    BEGIN_FUNCTION( "InitMemTxnDatTblSqlQuery" );
    ResCodeT rc = NO_ERR;
    
    DbConn dbConn;
    
    sprintf(gSqlInsert, INSERT_SQL, setId);
    sprintf(gSqlSelect, SELECT_SQL, setId);
    
    rc = ExtGetConnAddr(connId,&dbConn);
    RAISE_ERR(rc, RTN);
    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT BatchInsertMemTxnDatTbl(int32 connId, pRtDatCtrlT pDataCtrl, int32 dataCnt, int32 dataSize)
{
    BEGIN_FUNCTION( "BatchInsertMemTxnDatTbl" );
    ResCodeT rc = NO_ERR;
    DbConn      dbConn;
    
    int32       i = 0;
    void * pBuff = NULL;

   
    DbLobTypeT **   ppDbBuff = NULL;


    ASSERT( pDataCtrl) ;
    
    rc = ExtGetConnAddr(connId,&dbConn);
    RAISE_ERR(rc, RTN);
    
    
    rc = ExtCreateSttmnt(&dbConn, &gInstSttmnt);
    RAISE_ERR(rc, RTN);
    
    rc = ExtPrprSttmnt(&gInstSttmnt, gSqlInsert);
    RAISE_ERR(rc, RTN);
    
    rc = ExtSetArraySize(&gInstSttmnt, dataCnt);
    RAISE_ERR(rc, RTN);
    
    rc = ExtCreateArrayLob(&dbConn, dataCnt, &ppDbBuff);
    RAISE_ERR(rc, RTN);
    
    
    rc = ExtBindArrayInt(&gInstSttmnt, (char *)":txn_dat_sqno", pDataCtrl->pDataSqno);
    RAISE_ERR(rc, RTN);
    
    rc = ExtBindArrayInt(&gInstSttmnt, (char *)":txn_elem_size", pDataCtrl->pElemTtlSize);
    RAISE_ERR(rc, RTN);
    
    rc = ExtBindArrayInt(&gInstSttmnt, (char *)":txn_elem_cnt", pDataCtrl->pElemCnt);
    RAISE_ERR(rc, RTN);
    
    rc = ExtBindArrayInt(&gInstSttmnt, (char *)":pre_dat_sqno", pDataCtrl->prevDataSqno);
    RAISE_ERR(rc, RTN);
    
    rc = ExtBindArrayInt(&gInstSttmnt, (char *)":nxt_dat_sqno", pDataCtrl->nextDataSqno);
    RAISE_ERR(rc, RTN);
    
    rc = ExtBindArrayInt(&gInstSttmnt, (char *)":msg_sqno", pDataCtrl->currMsgSqno);
    RAISE_ERR(rc, RTN);
    
    rc = ExtBindArrayLob(&gInstSttmnt, (char *)":txn_elem_dat", ppDbBuff);
    RAISE_ERR(rc, RTN);


    for(i = 0; i < dataCnt; i++)
    {
        pBuff = (void *)ADDRESS_ADD_OFFSET(pDataCtrl->pRtElemAddr, i*(dataSize));
        rc = ExtWriteLob(ppDbBuff[i], pBuff, pDataCtrl->pElemTtlSize[i]);
        RAISE_ERR(rc, RTN);
    }
    
    rc = ExtExeSql(&gInstSttmnt);
    RAISE_ERR(rc, RTN);
    
    
    rc = ExtFreeArrayLob(ppDbBuff);
    RAISE_ERR(rc, RTN);
    
    rc = ExtFreeStmnt(&gInstSttmnt);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SelectMemTxnDatTbl(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMemTxnDatTbl" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectMemTxnDatTblByKey(int32 connId, int32 keyValue, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMemTxnDatTbl" );

    int32 stmtId;
    char selectSql[MAX_BUFF_LEN] = {0};

    sprintf(selectSql, "%s WHERE TXN_DAT_SQNO = %ld", gSqlSelect, keyValue);

    rc = DbCmmnPrprSql( connId, selectSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextMemTxnDatTbl( BOOL * pFrstFlag, int32 connId,
                                    DatCtrlT* pDataOut, char* rtEleAddr)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextMemTxnDatTbl" );

    static int32 stmntId;

    DbColInfoT dataColInfo = {0};

    if ( * pFrstFlag )
    {
        rc = SelectMemTxnDatTbl(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_MEMTXNDATTBL_TOT_COLMN - 1, 
                            gMemTxnDatTblDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    /* get memtxn elem data */
    dataColInfo.colType = DB_COL_BLOB;
    dataColInfo.valSize = 4096;

    rc = DbCmmnGetRow( stmntId, DB_MEMTXNDATTBL_TOT_COLMN, 
                            &dataColInfo, (void *)rtEleAddr );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextMemTxnDatTblByKey( BOOL *pFrstFlag, int32 connId, int32 keyValue,
                            DatCtrlT* pDataOut, char* rtEleAddr, int32 outBuffLen )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextMemTxnDatTbl" );

    static int32 stmntId;

    DbColInfoT dataColInfo = {0};

    if ( *pFrstFlag )
    {
        rc = SelectMemTxnDatTblByKey(connId, keyValue, &stmntId);
        RAISE_ERR(rc, RTN);
        
        //*pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_MEMTXNDATTBL_TOT_COLMN, 
                            gMemTxnDatTblDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    /* get memtxn elem data */
    dataColInfo.colType = DB_COL_BLOB;
    dataColInfo.valSize = outBuffLen;

    rc = DbCmmnGetRow( stmntId, DB_MEMTXNDATTBL_TOT_COLMN + 1, 
                            &dataColInfo, (void *)rtEleAddr );
    RAISE_ERR(rc, RTN);
    
    DbCmmnFreeStmnt( stmntId );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT SelectMemTxnDatTblByMsgSqno(int32 connId, int32 keyValue, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMemTxnDatTblByMsgSqno" );

    int32 stmtId;
    char selectSql[MAX_BUFF_LEN] = {0};

    sprintf(selectSql, "%s WHERE MSG_SQNO = %ld ORDER BY TXN_DAT_SQNO", gSqlSelect, keyValue);

    rc = DbCmmnPrprSql( connId, selectSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextMemTxnDatTblByMsgSqno( BOOL * pFrstFlag, int32 connId, int32 keyValue,
                                            DatCtrlT* pDataOut, char* rtEleAddr , int32 outBuffLen)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextMemTxnDatTblByMsgSqno" );

    static int32 stmntId;

    DbColInfoT dataColInfo = {0};

    if ( * pFrstFlag )
    {
        rc = SelectMemTxnDatTblByMsgSqno(connId, keyValue, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_MEMTXNDATTBL_TOT_COLMN - 1, 
                            gMemTxnDatTblDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    /* get memtxn elem data */
    dataColInfo.colType = DB_COL_BLOB;
    dataColInfo.valSize = outBuffLen;

    rc = DbCmmnGetRow( stmntId, DB_MEMTXNDATTBL_TOT_COLMN, 
                            &dataColInfo, (void *)rtEleAddr );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
