/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "ActiveInfoDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ACTIVEINFO_CNT_NUM         1

#define DB_ACTIVEINFO_TOT_COLMN       (sizeof(gActiveInfoDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ACTIVE_INFO "
"(SET_ID,PRIMARY_HOST,BACKUP_HOST,HA_TIME) VALUES "
"(:set_id,:primary_host,:backup_host,:ha_time) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ACTIVE_INFO ";
static char gSqlSelect[] = "SELECT SET_ID,PRIMARY_HOST,BACKUP_HOST,HA_TIME FROM ACTIVE_INFO ";
static DbColInfoT gActiveInfoDbInfo[] = 
{
    {"SET_ID",    ":set_id",    offsetof(ActiveInfo, setId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"PRIMARY_HOST",    ":primary_host",    offsetof(ActiveInfo, primaryHost),    0,    DB_COL_STRING,    20,  0 },
    {"BACKUP_HOST",    ":backup_host",    offsetof(ActiveInfo, backupHost),    0,    DB_COL_STRING,    20,  0 },
    {"HA_TIME",    ":ha_time",    offsetof(ActiveInfo, haTime),    0,    DB_COL_STRING,    10,  0 },
};

static DbColInfoT gActiveInfoDbCntInfo[] =
{
    {"",                 ":count",           offsetof(ActiveInfoCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( ActiveInfo* pData );
ResCodeT FreeDateTimeType( ActiveInfo* pData );
ResCodeT SelectActiveInfo(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertActiveInfo(int32 connId, ActiveInfo* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertActiveInfo" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gActiveInfoDbInfo,
                            DB_ACTIVEINFO_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateActiveInfoByKey(int32 connId, ActiveInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateActiveInfoByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ACTIVEINFO_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gActiveInfoDbInfo[keyIdx].colFlag,
                                    gActiveInfoDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ACTIVE_INFO SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ACTIVEINFO_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gActiveInfoDbInfo[colIdx].colFlag,
                                    gActiveInfoDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gActiveInfoDbInfo, 
                    DB_ACTIVEINFO_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfActiveInfo(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfActiveInfo" );

    int32       stmtId;
    ActiveInfoCntT    ActiveInfoCnt = {0};
    ActiveInfoCntT *  pActiveInfoCnt = &ActiveInfoCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ACTIVEINFO_CNT_NUM,
                        gActiveInfoDbCntInfo, (void *) pActiveInfoCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = ActiveInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextActiveInfo( BOOL * pFrstFlag, int32 connId, ActiveInfo* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextActiveInfo" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectActiveInfo(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ACTIVEINFO_TOT_COLMN, 
                            gActiveInfoDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectActiveInfo(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
BEGIN_FUNCTION( "SelectActiveInfo" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( ActiveInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( ActiveInfo* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    EXIT_BLOCK();
    RETURN_RESCODE;
}
