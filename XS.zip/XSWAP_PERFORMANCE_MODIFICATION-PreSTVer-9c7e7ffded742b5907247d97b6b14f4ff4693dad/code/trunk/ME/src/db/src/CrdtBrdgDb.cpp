/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CrdtBrdgDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CRDTBRDG_CNT_NUM         1

#define DB_CRDTBRDG_TOT_COLMN       (sizeof(gCrdtBrdgDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CRDT_BRDG "
"(CRDT_BRDG_SRNO,BRDG_ORG_ID,ORG_ID,ST,BRDG_RL_F,BRDG_FEE,CRDT_TERM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:crdt_brdg_srno,:brdg_org_id,:org_id,:st,:brdg_rl_f,:brdg_fee,:crdt_term,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CRDT_BRDG ";
static char gSqlSelect[] = "SELECT CRDT_BRDG_SRNO,BRDG_ORG_ID,ORG_ID,ST,BRDG_RL_F,BRDG_FEE,CRDT_TERM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM CRDT_BRDG ";
static DbColInfoT gCrdtBrdgDbInfo[] = 
{
    {"CRDT_BRDG_SRNO",    ":crdt_brdg_srno",    offsetof(CrdtBrdg, crdtBrdgSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"BRDG_ORG_ID",    ":brdg_org_id",    offsetof(CrdtBrdg, brdgOrgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(CrdtBrdg, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ST",    ":st",    offsetof(CrdtBrdg, st),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_RL_F",    ":brdg_rl_f",    offsetof(CrdtBrdg, brdgRlF),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_FEE",    ":brdg_fee",    offsetof(CrdtBrdg, brdgFee),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRDT_TERM",    ":crdt_term",    offsetof(CrdtBrdg, crdtTerm),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CrdtBrdg, crtTm),    offsetof(CrdtBrdg, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CrdtBrdg, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CrdtBrdg, updTm),    offsetof(CrdtBrdg, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CrdtBrdg, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gCrdtBrdgDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CrdtBrdgCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CrdtBrdg* pData );
ResCodeT FreeDateTimeType( CrdtBrdg* pData );
ResCodeT SelectCrdtBrdg(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCrdtBrdg(int32 connId, CrdtBrdg* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCrdtBrdg" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCrdtBrdgDbInfo,
                            DB_CRDTBRDG_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCrdtBrdgByKey(int32 connId, CrdtBrdg* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCrdtBrdgByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CRDTBRDG_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCrdtBrdgDbInfo[keyIdx].colFlag,
                                    gCrdtBrdgDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CRDT_BRDG SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CRDTBRDG_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCrdtBrdgDbInfo[colIdx].colFlag,
                                    gCrdtBrdgDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCrdtBrdgDbInfo, 
                    DB_CRDTBRDG_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCrdtBrdg(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCrdtBrdg" );

    int32       stmtId;
    CrdtBrdgCntT    CrdtBrdgCnt = {0};
    CrdtBrdgCntT *  pCrdtBrdgCnt = &CrdtBrdgCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CRDTBRDG_CNT_NUM,
                        gCrdtBrdgDbCntInfo, (void *) pCrdtBrdgCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = CrdtBrdgCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCrdtBrdg( BOOL * pFrstFlag, int32 connId, CrdtBrdg* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCrdtBrdg" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCrdtBrdg(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CRDTBRDG_TOT_COLMN, 
                            gCrdtBrdgDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCrdtBrdg(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCrdtBrdg" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CrdtBrdg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CrdtBrdg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
