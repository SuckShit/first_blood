﻿/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OrdrDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ORDR_CNT_NUM         1

#define DB_ORDR_TOT_COLMN       (sizeof(gOrdrDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ORDR "
"(ORDR_ID,ORG_ID,ORDR_SBMT_TP,ORDR_TP,OCO_ID,CNTRCT_NM,NTNL_AMNT,RMNG_NTNL_AMNT,ORDR_PRC,ORDR_AMNT,DL_DIR,ST,TRDR_NM,ORDR_CRT_TM,ORDR_EXPRD_TM,ORDR_ACTV_TM,UPD_TM,UPD_USR_NM,ORG_FULL_NM_CN,VRTL_BRDG_ORDR_F,RQST_ID,USR_LGN_NM_API,ORG_CD,BIL_ID) VALUES "
"(:ordr_id,:org_id,:ordr_sbmt_tp,:ordr_tp,:oco_id,:cntrct_nm,:ntnl_amnt,:rmng_ntnl_amnt,:ordr_prc,:ordr_amnt,:dl_dir,:st,:trdr_nm,:ordr_crt_tm,:ordr_exprd_tm,:ordr_actv_tm,:upd_tm,:upd_usr_nm,:org_full_nm_cn,:vrtl_brdg_ordr_f,:rqst_id,:usr_lgn_nm_api,:org_cd,:bil_id) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ORDR ";
static char gSqlKeySelect[] = "SELECT COUNT(*) FROM ORDR WHERE ORDR_ID = '%s' ";
static char gSqlSelect[] = "SELECT ORDR_ID,ORG_ID,ORDR_SBMT_TP,NVL(ORDR_TP, ' '),NVL(OCO_ID, ' '),CNTRCT_NM,NTNL_AMNT,RMNG_NTNL_AMNT,ORDR_PRC,ORDR_AMNT,DL_DIR,ST,TRDR_NM,ORDR_CRT_TM,ORDR_EXPRD_TM,ORDR_ACTV_TM,UPD_TM,UPD_USR_NM,ORG_FULL_NM_CN,NVL(VRTL_BRDG_ORDR_F, ' '),NVL(RQST_ID, ' '),NVL(USR_LGN_NM_API, ' '),NVL(ORG_CD, ' '),NVL(BIL_ID, ' ') FROM ORDR ";
static DbColInfoT gOrdrDbInfo[] = 
{
    {"ORDR_ID",    ":ordr_id",    offsetof(Ordr, ordrId),    0,    DB_COL_STRING,    50,  0 },
    {"ORG_ID",    ":org_id",    offsetof(Ordr, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORDR_SBMT_TP",    ":ordr_sbmt_tp",    offsetof(Ordr, ordrSbmtTp),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_TP",    ":ordr_tp",    offsetof(Ordr, ordrTp),    0,    DB_COL_STRING,    8,  0 },
    {"OCO_ID",    ":oco_id",    offsetof(Ordr, ocoId),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_NM",    ":cntrct_nm",    offsetof(Ordr, cntrctNm),    0,    DB_COL_STRING,    50,  0 },
    {"NTNL_AMNT",    ":ntnl_amnt",    offsetof(Ordr, ntnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"RMNG_NTNL_AMNT",    ":rmng_ntnl_amnt",    offsetof(Ordr, rmngNtnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"ORDR_PRC",    ":ordr_prc",    offsetof(Ordr, ordrPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"ORDR_AMNT",    ":ordr_amnt",    offsetof(Ordr, ordrAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"DL_DIR",    ":dl_dir",    offsetof(Ordr, dlDir),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(Ordr, st),    0,    DB_COL_STRING,    8,  0 },
    {"TRDR_NM",    ":trdr_nm",    offsetof(Ordr, trdrNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORDR_CRT_TM",    ":ordr_crt_tm",    offsetof(Ordr, ordrCrtTm),    offsetof(Ordr, pOrdrCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"ORDR_EXPRD_TM",    ":ordr_exprd_tm",    offsetof(Ordr, ordrExprdTm),    offsetof(Ordr, pOrdrExprdTm),    DB_COL_DATE,    50,  0 },
    {"ORDR_ACTV_TM",    ":ordr_actv_tm",    offsetof(Ordr, ordrActvTm),    offsetof(Ordr, pOrdrActvTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(Ordr, updTm),    offsetof(Ordr, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(Ordr, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_FULL_NM_CN",    ":org_full_nm_cn",    offsetof(Ordr, orgFullNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"VRTL_BRDG_ORDR_F",    ":vrtl_brdg_ordr_f",    offsetof(Ordr, vrtlBrdgOrdrF),    0,    DB_COL_STRING,    8,  0 },
    {"RQST_ID",    ":rqst_id",    offsetof(Ordr, rqstId),    0,    DB_COL_STRING,    50,  0 },
    {"USR_LGN_NM_API",    ":usr_lgn_nm_api",    offsetof(Ordr, usrLgnNmApi),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_CD",    ":org_cd",    offsetof(Ordr, orgCd),    0,    DB_COL_STRING,    50,  0 },
    {"BIL_ID",    ":bil_id",    offsetof(Ordr, bilId),    0,    DB_COL_STRING,    50,  0 },
};

static DbColInfoT gOrdrDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OrdrCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( Ordr* pData );
ResCodeT FreeDateTimeType( Ordr* pData );
ResCodeT SelectOrdr(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOrdr(int32 connId, Ordr* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOrdr" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOrdrDbInfo,
                            DB_ORDR_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOrdrByKey(int32 connId, Ordr* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrdrByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORDR_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOrdrDbInfo[keyIdx].colFlag,
                                    gOrdrDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORDR SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORDR_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrdrDbInfo[colIdx].colFlag,
                                    gOrdrDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrdrDbInfo, 
                    DB_ORDR_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateCancleOrdr( int32 connId, Ordr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCancleOrdr");

    int32   stmtId;

    char updateSql[DB_COMM_SQL_TOT_LEN]={0};

    sprintf( updateSql, "UPDATE ORDR SET ST='%s', ORDR_ACTV_TM=NULL ,RMNG_NTNL_AMNT=%lf WHERE ORDR_ID='%s' ", pData->st, pData->rmngNtnlAmnt, pData->ordrId );

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfOrdr(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrdr" );

    int32       stmtId;
    OrdrCntT    OrdrCnt = {0};
    OrdrCntT *  pOrdrCnt = &OrdrCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORDR_CNT_NUM,
                        gOrdrDbCntInfo, (void *) pOrdrCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrdrCnt.count;
    
    DbCmmnFreeStmnt( stmtId );

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextOrdr( BOOL * pFrstFlag, int32 connId, Ordr* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrdr" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOrdr(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORDR_TOT_COLMN, 
                            gOrdrDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    if (NOTOK(GET_RESCODE()))
    {
        DbCmmnFreeStmnt( stmntId );
    }
    RETURN_RESCODE;
}

ResCodeT SelectOrdr(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrdr" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchOrdrByKey( int32 connId, char * pKey, BOOL * pFetchFlag )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchOrdrByKey" );

    int32 stmntId;
    OrdrCntT    OrdrCnt = {0};
    OrdrCntT *  pOrdrCnt = &OrdrCnt;
    char updateSql[DB_COMM_SQL_TOT_LEN];
    
    * pFetchFlag = FALSE;

    sprintf( updateSql, gSqlKeySelect, pKey );

    rc = DbCmmnPrprSql( connId, updateSql, &stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORDR_CNT_NUM,
                        gOrdrDbCntInfo, (void *) pOrdrCnt );
    RAISE_ERR(rc, RTN);

    if ( OrdrCnt.count )
    {
        * pFetchFlag = TRUE;
    }

    EXIT_BLOCK( );
    DbCmmnFreeStmnt( stmntId );
    RETURN_RESCODE;
}

ResCodeT FmtDateTimeType( Ordr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->ordrCrtTm, &pData->pOrdrCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->ordrExprdTm, &pData->pOrdrExprdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->ordrActvTm, &pData->pOrdrActvTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( Ordr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pOrdrCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pOrdrExprdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pOrdrActvTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
