/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "db_comm.h"
#include "data_type.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "common_macro.h"
#include "MemTxnTblDb.h"
#include "mem_txn.h"
#include "ocilib.h"
#include "db_comm.h"
/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/
#define INSERT_SQL "INSERT INTO MEM_TXN_%ld_TBL (TXN_ID,TXN_STS,TXN_DAT_CNT,FRST_DAT_SQNO,LST_DAT_SQNO,TXN_TM, DATA_SIZE) VALUES (:txn_id,:txn_sts,:txn_dat_cnt,:frst_dat_sqno,:lst_dat_sqno,:txn_tm,:data_size) "
#define SELECT_SQL "SELECT TXN_ID,TXN_STS,TXN_DAT_CNT,FRST_DAT_SQNO,LST_DAT_SQNO,TXN_TM,DATA_SIZE FROM MEM_TXN_%ld_TBL "

#define DB_MEMTXNTBL_TOT_COLMN       (sizeof(gMemTxnTblDbInfo) / sizeof(DbColInfoT))
/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[MAX_BUFF_LEN] = { 0 };
static char gSqlSelect[MAX_BUFF_LEN] = { 0 };

static DbStmt gInstSttmnt = {0};
static DbStmt gSlctSttmnt = {0};

static DbColInfoT gMemTxnTblDbInfo[] = 
{
    {"TXN_ID",        ":txn_id",        offsetof(MemTxnEntryT, txnId),          0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"TXN_STS",       ":txn_sts",       offsetof(MemTxnEntryT, txnSts),         0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"TXN_DAT_CNT",   ":txn_dat_cnt",   offsetof(MemTxnEntryT, dataCnt),        0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"FRST_DAT_SQNO", ":frst_dat_sqno", offsetof(MemTxnEntryT, frstDataSqno),   0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"LST_DAT_SQNO",  ":lst_dat_sqno",  offsetof(MemTxnEntryT, lstDataSqno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"TXN_TM",        ":txn_tm",        offsetof(MemTxnEntryT, timestamp),      0,    DB_COL_INT64,    sizeof(int32),  0 },
    {"DATA_SIZE",     ":data_size",     offsetof(MemTxnEntryT, dataSize),       0,    DB_COL_INT32,    sizeof(int32),  0 },
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InitMemTxnTblSqlQuery(int32 connId, int32 setId)
{
    BEGIN_FUNCTION( "InitMemTxnTblSqlQuery" );
    ResCodeT rc = NO_ERR;
   
    
    DbConn dbConn;
    
    sprintf(gSqlInsert, INSERT_SQL, setId);
    sprintf(gSqlSelect, SELECT_SQL, setId);
    
    
    rc = ExtGetConnAddr(connId,&dbConn);
    RAISE_ERR(rc, RTN);
    
    rc = ExtCreateSttmnt(&dbConn, &gInstSttmnt);
    RAISE_ERR(rc, RTN);
    
    
    rc = ExtPrprSttmnt(&gInstSttmnt, gSqlInsert);
    RAISE_ERR(rc, RTN);
    
    rc = ExtCreateSttmnt(&dbConn, &gSlctSttmnt);
    RAISE_ERR(rc, RTN);
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT InsertMemTxnTbl(MemTxnEntryT* pMemTxnEntry)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertMemTxnTbl" );
   
    static int32 gTxnId;
    static int32 gTxnSts;
    static int32 gDataCnt;
    static int32 gFrstDataSqno;
    static int32 gLstDataSqno;
    static int32 gDataSize;
    static int64 gTimestamp;
    
    static BOOL bBind = FALSE;
    
    if (!bBind)
    {
        rc = ExtBindInt(&gInstSttmnt, (char *)":txn_id", &gTxnId);
        RAISE_ERR(rc, RTN);
        
        rc = ExtBindInt(&gInstSttmnt, (char *)":txn_sts", &gTxnSts);
        RAISE_ERR(rc, RTN);
        
        rc = ExtBindInt(&gInstSttmnt, (char *)":txn_dat_cnt", &gDataCnt);
        RAISE_ERR(rc, RTN);
        
        rc = ExtBindInt(&gInstSttmnt, (char *)":frst_dat_sqno", &gFrstDataSqno);
        RAISE_ERR(rc, RTN);
        
        rc = ExtBindInt(&gInstSttmnt, (char *)":lst_dat_sqno", &gLstDataSqno);
        RAISE_ERR(rc, RTN);
        
        rc = ExtBindBigInt(&gInstSttmnt, (char *)":txn_tm", &gTimestamp);
        RAISE_ERR(rc, RTN);
        
        rc = ExtBindInt(&gInstSttmnt, (char *)":data_size", &gDataSize);
        RAISE_ERR(rc, RTN);
        
        bBind = TRUE;
    
    }
    
    gTxnId = pMemTxnEntry->txnId;
    gTxnSts = TXN_STS_COMMIT;;
    gDataCnt = pMemTxnEntry->dataCnt;
    gFrstDataSqno = pMemTxnEntry->frstDataSqno;
    gLstDataSqno = pMemTxnEntry->frstDataSqno + pMemTxnEntry->dataCnt - 1;;
    gDataSize = pMemTxnEntry->dataSize;
    gTimestamp = pMemTxnEntry->timestamp;    
    
    rc = ExtExeSql(&gInstSttmnt);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectMemTxnTbl(int32 connId, int32 txnId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMemTxnTbl" );

    int32 stmtId;
    char selectSql[MAX_BUFF_LEN] = {0};

    sprintf(selectSql, "%s WHERE TXN_ID > %ld", gSqlSelect, txnId);

    rc = DbCmmnPrprSql( connId, selectSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextMemTxnTbl( BOOL * pFrstFlag, int32 connId, 
                                int32 txnId, MemTxnEntryT* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextMemTxnTbl" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectMemTxnTbl(connId, txnId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_MEMTXNTBL_TOT_COLMN,
                            gMemTxnTblDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT SelectMemTxnTblByKey(int32 connId, int32 txnId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMemTxnTblByKey" );

    int32 stmtId;
    char selectSql[MAX_BUFF_LEN] = {0};

    sprintf(selectSql, "%s WHERE TXN_ID = %ld", gSqlSelect, txnId);

    rc = DbCmmnPrprSql( connId, selectSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchMemTxnTblByKey(int32 connId,  int32 txnId, MemTxnEntryT* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchMemTxnTblByKey" );

    int32 stmntId;

    rc = SelectMemTxnTblByKey(connId, txnId, &stmntId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_MEMTXNTBL_TOT_COLMN,
                            gMemTxnTblDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

