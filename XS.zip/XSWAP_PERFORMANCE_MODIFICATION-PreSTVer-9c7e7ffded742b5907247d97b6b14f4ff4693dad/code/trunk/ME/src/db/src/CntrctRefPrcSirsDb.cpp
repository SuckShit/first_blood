/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctRefPrcSirsDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CNTRCTREFPRCSIRS_CNT_NUM         1

#define DB_CNTRCTREFPRCSIRS_TOT_COLMN       (sizeof(gCntrctRefPrcSirsDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CNTRCT_REF_PRC_SIRS "
"(CNTRCT_REF_PRC_SRNO,CNTRCT_CD,REF_PRC_DT,REF_PRC,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:cntrct_ref_prc_srno,:cntrct_cd,:ref_prc_dt,:ref_prc,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CNTRCT_REF_PRC_SIRS ";
static char gSqlSelect[] = "SELECT CNTRCT_REF_PRC_SRNO,CNTRCT_CD,REF_PRC_DT,REF_PRC,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM CNTRCT_REF_PRC_SIRS ";
static DbColInfoT gCntrctRefPrcSirsDbInfo[] = 
{
    {"CNTRCT_REF_PRC_SRNO",    ":cntrct_ref_prc_srno",    offsetof(CntrctRefPrcSirs, cntrctRefPrcSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(CntrctRefPrcSirs, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"REF_PRC_DT",    ":ref_prc_dt",    offsetof(CntrctRefPrcSirs, refPrcDt),    offsetof(CntrctRefPrcSirs, pRefPrcDt),    DB_COL_DATE,    50,  0 },
    {"REF_PRC",    ":ref_prc",    offsetof(CntrctRefPrcSirs, refPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctRefPrcSirs, crtTm),    offsetof(CntrctRefPrcSirs, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctRefPrcSirs, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctRefPrcSirs, updTm),    offsetof(CntrctRefPrcSirs, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctRefPrcSirs, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gCntrctRefPrcSirsDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctRefPrcSirsCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctRefPrcSirs* pData );
ResCodeT FreeDateTimeType( CntrctRefPrcSirs* pData );
ResCodeT SelectCntrctRefPrcSirs(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctRefPrcSirs(int32 connId, CntrctRefPrcSirs* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctRefPrcSirs" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctRefPrcSirsDbInfo,
                            DB_CNTRCTREFPRCSIRS_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctRefPrcSirsByKey(int32 connId, CntrctRefPrcSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctRefPrcSirsByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTREFPRCSIRS_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctRefPrcSirsDbInfo[keyIdx].colFlag,
                                    gCntrctRefPrcSirsDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CNTRCT_REF_PRC_SIRS SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTREFPRCSIRS_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctRefPrcSirsDbInfo[colIdx].colFlag,
                                    gCntrctRefPrcSirsDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctRefPrcSirsDbInfo, 
                    DB_CNTRCTREFPRCSIRS_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctRefPrcSirs(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctRefPrcSirs" );

    int32       stmtId;
    CntrctRefPrcSirsCntT    CntrctRefPrcSirsCnt = {0};
    CntrctRefPrcSirsCntT *  pCntrctRefPrcSirsCnt = &CntrctRefPrcSirsCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTREFPRCSIRS_CNT_NUM,
                        gCntrctRefPrcSirsDbCntInfo, (void *) pCntrctRefPrcSirsCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctRefPrcSirsCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCntrctRefPrcSirs( BOOL * pFrstFlag, int32 connId, CntrctRefPrcSirs* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctRefPrcSirs" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctRefPrcSirs(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTREFPRCSIRS_TOT_COLMN, 
                            gCntrctRefPrcSirsDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctRefPrcSirs(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctRefPrcSirs" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CntrctRefPrcSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->refPrcDt, &pData->pRefPrcDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctRefPrcSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pRefPrcDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctRefPrcSirsByName(int32 connId, char * pCntrctName, int32 * pStmtId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctRefPrcSirsByName" );

    int32 stmntId = 0;
    char selectSql[MAX_BUFF_LEN] = {0};
    
    sprintf(selectSql, "%s WHERE CNTRCT_CD = '%s'", gSqlSelect, pCntrctName);
    
    rc = DbCmmnPrprSql( connId, selectSql, &stmntId );
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);
    
    * pStmtId = stmntId;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchCntrctRefPrcSirsByName(int32 connId, char * pCntrctName, CntrctRefPrcSirs* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchCntrctRefPrcSirsByName" );

    int32 stmntId;

    rc = SelectCntrctRefPrcSirsByName(connId, pCntrctName, &stmntId);
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTREFPRCSIRS_TOT_COLMN, 
                            gCntrctRefPrcSirsDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    DbCmmnFreeStmnt( stmntId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
