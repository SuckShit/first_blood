/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CrdtSbfccpDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CRDTSBFCCP_CNT_NUM         1

#define DB_CRDTSBFCCP_TOT_COLMN       (sizeof(gCrdtSbfccpDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CRDT_SBFCCP "
"(CRDT_ID,ORG_ID,CLS_PSTN_F,LMT_PSTN_F,ST,INTL_AMNT,BID_INTL_AMNT,BID_USED_AMNT,BID_HOLD_AMNT,BID_RMN_AMNT,OFR_INTL_AMNT,OFR_USED_AMNT,OFR_HOLD_AMNT,OFR_RMN_AMNT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:crdt_id,:org_id,:cls_pstn_f,:lmt_pstn_f,:st,:intl_amnt,:bid_intl_amnt,:bid_used_amnt,:bid_hold_amnt,:bid_rmn_amnt,:ofr_intl_amnt,:ofr_used_amnt,:ofr_hold_amnt,:ofr_rmn_amnt,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CRDT_SBFCCP ";
static char gSqlSelect[] = "SELECT CRDT_ID,ORG_ID,CLS_PSTN_F,LMT_PSTN_F,ST,INTL_AMNT,BID_INTL_AMNT,BID_USED_AMNT,BID_HOLD_AMNT,BID_RMN_AMNT,OFR_INTL_AMNT,OFR_USED_AMNT,OFR_HOLD_AMNT,OFR_RMN_AMNT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM CRDT_SBFCCP ";
static DbColInfoT gCrdtSbfccpDbInfo[] = 
{
    {"CRDT_ID",    ":crdt_id",    offsetof(CrdtSbfccp, crdtId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(CrdtSbfccp, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CLS_PSTN_F",    ":cls_pstn_f",    offsetof(CrdtSbfccp, clsPstnF),    0,    DB_COL_STRING,    8,  0 },
    {"LMT_PSTN_F",    ":lmt_pstn_f",    offsetof(CrdtSbfccp, lmtPstnF),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(CrdtSbfccp, st),    0,    DB_COL_STRING,    8,  0 },
    {"INTL_AMNT",    ":intl_amnt",    offsetof(CrdtSbfccp, intlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"BID_INTL_AMNT",    ":bid_intl_amnt",    offsetof(CrdtSbfccp, bidIntlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"BID_USED_AMNT",    ":bid_used_amnt",    offsetof(CrdtSbfccp, bidUsedAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"BID_HOLD_AMNT",    ":bid_hold_amnt",    offsetof(CrdtSbfccp, bidHoldAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"BID_RMN_AMNT",    ":bid_rmn_amnt",    offsetof(CrdtSbfccp, bidRmnAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"OFR_INTL_AMNT",    ":ofr_intl_amnt",    offsetof(CrdtSbfccp, ofrIntlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"OFR_USED_AMNT",    ":ofr_used_amnt",    offsetof(CrdtSbfccp, ofrUsedAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"OFR_HOLD_AMNT",    ":ofr_hold_amnt",    offsetof(CrdtSbfccp, ofrHoldAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"OFR_RMN_AMNT",    ":ofr_rmn_amnt",    offsetof(CrdtSbfccp, ofrRmnAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CrdtSbfccp, crtTm),    offsetof(CrdtSbfccp, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CrdtSbfccp, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CrdtSbfccp, updTm),    offsetof(CrdtSbfccp, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CrdtSbfccp, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gCrdtSbfccpDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CrdtSbfccpCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CrdtSbfccp* pData );
ResCodeT FreeDateTimeType( CrdtSbfccp* pData );
ResCodeT SelectCrdtSbfccp(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCrdtSbfccp(int32 connId, CrdtSbfccp* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCrdtSbfccp" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCrdtSbfccpDbInfo,
                            DB_CRDTSBFCCP_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCrdtSbfccpByKey(int32 connId, CrdtSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCrdtSbfccpByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CRDTSBFCCP_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCrdtSbfccpDbInfo[keyIdx].colFlag,
                                    gCrdtSbfccpDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CRDT_SBFCCP SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CRDTSBFCCP_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCrdtSbfccpDbInfo[colIdx].colFlag,
                                    gCrdtSbfccpDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCrdtSbfccpDbInfo, 
                    DB_CRDTSBFCCP_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCrdtSbfccp(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCrdtSbfccp" );

    int32       stmtId;
    CrdtSbfccpCntT    CrdtSbfccpCnt = {0};
    CrdtSbfccpCntT *  pCrdtSbfccpCnt = &CrdtSbfccpCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CRDTSBFCCP_CNT_NUM,
                        gCrdtSbfccpDbCntInfo, (void *) pCrdtSbfccpCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CrdtSbfccpCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCrdtSbfccp( BOOL * pFrstFlag, int32 connId, CrdtSbfccp* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCrdtSbfccp" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCrdtSbfccp(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CRDTSBFCCP_TOT_COLMN, 
                            gCrdtSbfccpDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCrdtSbfccp(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCrdtSbfccp" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CrdtSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CrdtSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
