/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OrdrSirsDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ORDRSIRS_CNT_NUM         1

#define DB_ORDRSIRS_TOT_COLMN       (sizeof(gOrdrSirsDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ORDR_SIRS "
"(ORDR_ID,ORG_ID,ORDR_SBMT_TP,ORDR_TP,OCO_ID,CNTRCT_CD,NTNL_AMNT,RMNG_NTNL_AMNT,ORDR_PRC,ORDR_AMNT,DL_DIR,ST,TRDR_NM,ORDR_CRT_TM,ORDR_EXPRD_TM,ORDR_ACTV_TM,UPD_TM,UPD_USR_NM,ORG_FULL_NM_CN,RQST_ID,USR_LGN_NM_API,ORG_CD) VALUES "
"(:ordr_id,:org_id,:ordr_sbmt_tp,:ordr_tp,:oco_id,:cntrct_cd,:ntnl_amnt,:rmng_ntnl_amnt,:ordr_prc,:ordr_amnt,:dl_dir,:st,:trdr_nm,:ordr_crt_tm,:ordr_exprd_tm,:ordr_actv_tm,:upd_tm,:upd_usr_nm,:org_full_nm_cn,:rqst_id,:usr_lgn_nm_api,:org_cd) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ORDR_SIRS ";
static char gSqlKeySelect[] = "SELECT COUNT(*) FROM ORDR_SIRS WHERE ORDR_ID = '%s' ";
static char gSqlSelect[] = "SELECT ORDR_ID,ORG_ID,ORDR_SBMT_TP,NVL(ORDR_TP, ' '),NVL(OCO_ID, ' '),CNTRCT_CD,NTNL_AMNT,RMNG_NTNL_AMNT,ORDR_PRC,ORDR_AMNT,DL_DIR,ST,TRDR_NM,ORDR_CRT_TM,ORDR_EXPRD_TM,ORDR_ACTV_TM,UPD_TM,UPD_USR_NM,ORG_FULL_NM_CN,NVL(RQST_ID, ' '),NVL(USR_LGN_NM_API, ' '),NVL(ORG_CD, ' ') FROM ORDR_SIRS ";
static DbColInfoT gOrdrSirsDbInfo[] = 
{
    {"ORDR_ID",    ":ordr_id",    offsetof(OrdrSirs, ordrId),    0,    DB_COL_STRING,    50,  0 },
    {"ORG_ID",    ":org_id",    offsetof(OrdrSirs, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORDR_SBMT_TP",    ":ordr_sbmt_tp",    offsetof(OrdrSirs, ordrSbmtTp),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_TP",    ":ordr_tp",    offsetof(OrdrSirs, ordrTp),    0,    DB_COL_STRING,    8,  0 },
    {"OCO_ID",    ":oco_id",    offsetof(OrdrSirs, ocoId),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(OrdrSirs, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"NTNL_AMNT",    ":ntnl_amnt",    offsetof(OrdrSirs, ntnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"RMNG_NTNL_AMNT",    ":rmng_ntnl_amnt",    offsetof(OrdrSirs, rmngNtnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"ORDR_PRC",    ":ordr_prc",    offsetof(OrdrSirs, ordrPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"ORDR_AMNT",    ":ordr_amnt",    offsetof(OrdrSirs, ordrAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"DL_DIR",    ":dl_dir",    offsetof(OrdrSirs, dlDir),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(OrdrSirs, st),    0,    DB_COL_STRING,    8,  0 },
    {"TRDR_NM",    ":trdr_nm",    offsetof(OrdrSirs, trdrNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORDR_CRT_TM",    ":ordr_crt_tm",    offsetof(OrdrSirs, ordrCrtTm),    offsetof(OrdrSirs, pOrdrCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"ORDR_EXPRD_TM",    ":ordr_exprd_tm",    offsetof(OrdrSirs, ordrExprdTm),    offsetof(OrdrSirs, pOrdrExprdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"ORDR_ACTV_TM",    ":ordr_actv_tm",    offsetof(OrdrSirs, ordrActvTm),    offsetof(OrdrSirs, pOrdrActvTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OrdrSirs, updTm),    offsetof(OrdrSirs, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OrdrSirs, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_FULL_NM_CN",    ":org_full_nm_cn",    offsetof(OrdrSirs, orgFullNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"RQST_ID",    ":rqst_id",    offsetof(OrdrSirs, rqstId),    0,    DB_COL_STRING,    50,  0 },
    {"USR_LGN_NM_API",    ":usr_lgn_nm_api",    offsetof(OrdrSirs, usrLgnNmApi),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_CD",    ":org_cd",    offsetof(OrdrSirs, orgCd),    0,    DB_COL_STRING,    50,  0 },
};

static DbColInfoT gOrdrSirsDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OrdrSirsCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( OrdrSirs* pData );
ResCodeT FreeDateTimeType( OrdrSirs* pData );
ResCodeT SelectOrdrSirs(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOrdrSirs(int32 connId, OrdrSirs* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOrdrSirs" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOrdrSirsDbInfo,
                            DB_ORDRSIRS_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOrdrSirsByKey(int32 connId, OrdrSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrdrSirsByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORDRSIRS_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOrdrSirsDbInfo[keyIdx].colFlag,
                                    gOrdrSirsDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORDR_SIRS SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORDRSIRS_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrdrSirsDbInfo[colIdx].colFlag,
                                    gOrdrSirsDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrdrSirsDbInfo, 
                    DB_ORDRSIRS_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfOrdrSirs(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrdrSirs" );

    int32       stmtId;
    OrdrSirsCntT    OrdrSirsCnt = {0};
    OrdrSirsCntT *  pOrdrSirsCnt = &OrdrSirsCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORDRSIRS_CNT_NUM,
                        gOrdrSirsDbCntInfo, (void *) pOrdrSirsCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrdrSirsCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextOrdrSirs( BOOL * pFrstFlag, int32 connId, OrdrSirs* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrdrSirs" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOrdrSirs(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORDRSIRS_TOT_COLMN, 
                            gOrdrSirsDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOrdrSirs(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrdrSirs" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( OrdrSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->ordrCrtTm, &pData->pOrdrCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->ordrExprdTm, &pData->pOrdrExprdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->ordrActvTm, &pData->pOrdrActvTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( OrdrSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pOrdrCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pOrdrExprdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pOrdrActvTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchOrdrSirsByKey( int32 connId, char * pKey, BOOL * pFetchFlag )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchOrdrSirsByKey" );

    int32 stmntId;
    OrdrSirsCntT    OrdrCnt = {0};
    OrdrSirsCntT *  pOrdrCnt = &OrdrCnt;
    char updateSql[DB_COMM_SQL_TOT_LEN];
    
    * pFetchFlag = FALSE;

    sprintf( updateSql, gSqlKeySelect, pKey );

    rc = DbCmmnPrprSql( connId, updateSql, &stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORDRSIRS_CNT_NUM,
                        gOrdrSirsDbCntInfo, (void *) pOrdrCnt );
    RAISE_ERR(rc, RTN);

    if ( OrdrCnt.count )
    {
        * pFetchFlag = TRUE;
    }

    EXIT_BLOCK( );
    RETURN_RESCODE;
}



ResCodeT UpdateCancleOrdrSirs( int32 connId, OrdrSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCancleOrdrSirs");

    int32   stmtId;

    char updateSql[DB_COMM_SQL_TOT_LEN]={0};

    sprintf( updateSql, "UPDATE ORDR_SIRS SET ST='%s', ORDR_ACTV_TM=NULL ,RMNG_NTNL_AMNT=%lf WHERE ORDR_ID='%s' ", pData->st, pData->rmngNtnlAmnt, pData->ordrId );

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}