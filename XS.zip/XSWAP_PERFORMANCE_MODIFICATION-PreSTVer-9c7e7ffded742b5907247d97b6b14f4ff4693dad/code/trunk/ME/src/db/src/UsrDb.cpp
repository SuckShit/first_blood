/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "UsrDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro
**
************************************************************************************************/

#define DB_USR_CNT_NUM                  1

#define DB_USR_TOT_COLMN                (sizeof(gUsrDbInfo) / sizeof(DbColInfoT))
#define DB_USRROLE_JOIN_TOT_COLMN       (sizeof(gResColSelectJn) / sizeof(DbColInfoT))
#define DB_USR_ONLN_JOIN_TOT_COLMN      (sizeof(gResColSelOnlnJn) / sizeof(DbColInfoT))
#define DB_USR_ORG_TOT_COLMN            (sizeof(gResColSelOrgId) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN             200
#define DB_COMM_SQL_TOT_LEN             1000

/***********************************************************************************************
**
**   Structure
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO USR "
"(USR_SRNO,USR_LGN_NM,ORG_ID,NM_DESC,USR_ST,PSWD,PSWD_TM,PSWD_ER_CNT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,SYS_SRC,TEL,FAX_NO,API_F,ORDR_PRVLG_F,ORDR_PRVLG_MDFY_F,ORDR_PRVLG_F_SIRS,ORDR_PRVLG_MDFY_F_SIRS,ORDR_PRVLG_F_SBFCCP,ORDR_PRVLG_MDFY_F_SBFCCP) VALUES "
"(:usr_srno,:usr_lgn_nm,:org_id,:nm_desc,:usr_st,:pswd,:pswd_tm,:pswd_er_cnt,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:sys_src,:tel,:fax_no,:api_f,:ordr_prvlg_f,:ordr_prvlg_mdfy_f,:ordr_prvlg_f_sirs,:ordr_prvlg_mdfy_f_sirs,:ordr_prvlg_f_sbfccp,:ordr_prvlg_mdfy_f_sbfccp) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM USR ";
static char gSqlSelect[] = "SELECT USR_SRNO,USR_LGN_NM,ORG_ID,NM_DESC,USR_ST,NVL(PSWD, ' '),PSWD_TM,PSWD_ER_CNT,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,SYS_SRC,NVL(TEL, ' '),NVL(FAX_NO, ' '),API_F,ORDR_PRVLG_F,ORDR_PRVLG_MDFY_F,ORDR_PRVLG_F_SIRS,ORDR_PRVLG_MDFY_F_SIRS,ORDR_PRVLG_F_SBFCCP,ORDR_PRVLG_MDFY_F_SBFCCP FROM USR ";

static char gSqlSelectJn[] = "select AAA.USR_SRNO,AAA.USR_LGN_NM,AAA.ORG_ID,AAA.NM_DESC,AAA.USR_ST,NVL(AAA.PSWD, ' '),AAA.PSWD_TM,AAA.PSWD_ER_CNT,AAA.CRT_TM,AAA.CRT_USR_NM,AAA.UPD_TM,AAA.UPD_USR_NM,AAA.SYS_SRC,NVL(AAA.TEL, ' '),NVL(AAA.FAX_NO, ' '),AAA.API_F,AAA.ORDR_PRVLG_F,AAA.ORDR_PRVLG_MDFY_F,AAA.ORDR_PRVLG_F_SIRS,AAA.ORDR_PRVLG_MDFY_F_SIRS,AAA.ORDR_PRVLG_F_SBFCCP,AAA.ORDR_PRVLG_MDFY_F_SBFCCP,NVL(BBB.SESN_ID, ' '),BBB.LGN_TP,BBB.LGN_TM,NVL(AAA.ROLE_ID, ' '),nvl(AAA.mkt_tp, ' '),nvl(AAA.ST, ' ') from ( select AA.USR_SRNO,AA.USR_LGN_NM,AA.ORG_ID,AA.NM_DESC,AA.USR_ST,AA.PSWD,AA.PSWD_TM,AA.PSWD_ER_CNT,AA.CRT_TM,AA.CRT_USR_NM,AA.UPD_TM,AA.UPD_USR_NM,AA.SYS_SRC,AA.TEL,AA.FAX_NO,AA.API_F,AA.ORDR_PRVLG_F,AA.ORDR_PRVLG_MDFY_F,AA.ORDR_PRVLG_F_SIRS,AA.ORDR_PRVLG_MDFY_F_SIRS,AA.ORDR_PRVLG_F_SBFCCP,AA.ORDR_PRVLG_MDFY_F_SBFCCP,BB.ROLE_ID,CC.mkt_tp,CC.st from usr AA LEFT JOIN ( select A.usr_lgn_nm,listagg(B.ROLE_ID, ',') within group(order by B.usr_nm) as ROLE_ID from usr A left join usr_role B on A.usr_lgn_nm = B.usr_nm group by A.usr_lgn_nm    ) BB ON AA.usr_lgn_nm = BB.usr_lgn_nm LEFT JOIN(select A.usr_lgn_nm,listagg(NVL(c.mkt_tp, ' '), ',') within group(order by c.mkt_tp) as mkt_tp, listagg(NVL(c.st, ' '), ',') within group(order by c.mkt_tp) as st from usr A left join USR_MKT_PRVLG C on a.usr_lgn_nm = c.usr_lgn_nm group by A.usr_lgn_nm  )CC ON AA.usr_lgn_nm = CC.usr_lgn_nm)AAA left join usr_onln BBB on AAA.usr_lgn_nm = BBB.USR_NM ";

static char gSqlUsrOnlnJnCount[] = "SELECT count(*) FROM USR A RIGHT JOIN USR_ONLN B ON A.USR_LGN_NM = B.USR_NM WHERE B.LGN_TP IN (3, 4) AND ORG_ID IN (SELECT ORG_ID FROM ORG_INFO WHERE CRDT_OPRTR = '%s' AND CRDT_OPRTNG_ST = '1') ";
static char gSqlUsrOnlnJn[] = "SELECT A.ORG_ID, A.USR_LGN_NM FROM USR A RIGHT JOIN USR_ONLN B ON A.USR_LGN_NM = B.USR_NM WHERE B.LGN_TP IN (3, 4) AND ORG_ID IN (SELECT ORG_ID FROM ORG_INFO WHERE CRDT_OPRTR = '%s' AND CRDT_OPRTNG_ST = '1') ORDER BY ORG_ID ";

static char gSqlOtherApiUsrOnlnJnCount[] = "SELECT COUNT(1) FROM USR_ONLN UO, USR U, USR_ROLE UR WHERE UO.USR_NM = U.USR_LGN_NM AND U.ORG_ID = %d AND U.API_F = '1' AND U.USR_LGN_NM <> '%s' AND U.USR_LGN_NM = UR.USR_NM AND UR.ROLE_ID = 6 ";



static DbColInfoT gUsrDbInfo[] =
{
    {"USR_SRNO",    ":usr_srno",    offsetof(Usr, usrSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"USR_LGN_NM",    ":usr_lgn_nm",    offsetof(Usr, usrLgnNm),    0,    DB_COL_STRING,    100,  0 },
    {"ORG_ID",    ":org_id",    offsetof(Usr, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"NM_DESC",    ":nm_desc",    offsetof(Usr, nmDesc),    0,    DB_COL_STRING,    300,  0 },
    {"USR_ST",    ":usr_st",    offsetof(Usr, usrSt),    0,    DB_COL_STRING,    8,  0 },
    {"PSWD",    ":pswd",    offsetof(Usr, pswd),    0,    DB_COL_STRING,    300,  0 },
    {"PSWD_TM",    ":pswd_tm",    offsetof(Usr, pswdTm),    offsetof(Usr, pPswdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"PSWD_ER_CNT",    ":pswd_er_cnt",    offsetof(Usr, pswdErCnt),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(Usr, crtTm),    offsetof(Usr, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(Usr, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(Usr, updTm),    offsetof(Usr, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(Usr, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"SYS_SRC",    ":sys_src",    offsetof(Usr, sysSrc),    0,    DB_COL_STRING,    8,  0 },
    {"TEL",    ":tel",    offsetof(Usr, tel),    0,    DB_COL_STRING,    100,  0 },
    {"FAX_NO",    ":fax_no",    offsetof(Usr, faxNo),    0,    DB_COL_STRING,    100,  0 },
    {"API_F",    ":api_f",    offsetof(Usr, apiF),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_PRVLG_F",    ":ordr_prvlg_f",    offsetof(Usr, ordrPrvlgF),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_PRVLG_MDFY_F",    ":ordr_prvlg_mdfy_f",    offsetof(Usr, ordrPrvlgMdfyF),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_PRVLG_F_SIRS",    ":ordr_prvlg_f_sirs",    offsetof(Usr, ordrPrvlgFSirs),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_PRVLG_MDFY_F_SIRS",    ":ordr_prvlg_mdfy_f_sirs",    offsetof(Usr, ordrPrvlgMdfyFSirs),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_PRVLG_F_SBFCCP",    ":ordr_prvlg_f_sbfccp",    offsetof(Usr, ordrPrvlgFSbfccp),    0,    DB_COL_STRING,    8,  0 },
    {"ORDR_PRVLG_MDFY_F_SBFCCP",    ":ordr_prvlg_mdfy_f_sbfccp",    offsetof(Usr, ordrPrvlgMdfyFSbfccp),    0,    DB_COL_STRING,    8,  0 },
};

static DbColInfoT gUsrDbCntInfo[] =
{
    {"",                 ":count",           offsetof(UsrCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

static DbColInfoT gResColSelectJn[] = {
    {"USR_SRNO",                    ":usr_srno",                offsetof(UsrJoin,usrSrno), 0,         DB_COL_INT32,           sizeof(int32),  0},
    {"USR_LGN_NM",                  ":usr_lgn_nm",              offsetof(UsrJoin,usrLgnNm), 0,        DB_COL_STRING,          100,  0},
    {"ORG_ID",                      ":org_id",                  offsetof(UsrJoin,orgId), 0,           DB_COL_INT32,           sizeof(int32),  0},
    {"NM_DESC",                     ":nm_desc",                 offsetof(UsrJoin,nmDesc), 0,          DB_COL_STRING,          100,  0},
    {"USR_ST",                      ":usr_st",                  offsetof(UsrJoin,usrSt), 0,           DB_COL_STRING,          8,  0},
    {"PSWD",                        ":pswd",                    offsetof(UsrJoin,pswd), 0,            DB_COL_STRING,          300,  0},
    {"PSWD_TM",                     ":pswd_tm",                 offsetof(UsrJoin,pswdTm), 0,          DB_COL_TIMESTAMP,       50,  0},
    {"PSWD_ER_CNT",                 ":pswd_er_cnt",             offsetof(UsrJoin,pswdErCnt), 0,       DB_COL_INT32,           sizeof(int32),  0},
    {"CRT_TM",                      ":crt_tm",                  offsetof(UsrJoin,crtTm), offsetof(UsrJoin,pCrtTm),       DB_COL_TIMESTAMP,       50,  0},
    { "CRT_USR_NM",                 ":crt_usr_nm",              offsetof(UsrJoin,crtUsrNm), 0,        DB_COL_STRING,          100,  0},
    { "UPD_TM",                     ":upd_tm",                  offsetof(UsrJoin,updTm), offsetof(UsrJoin,pUpdTm),       DB_COL_TIMESTAMP,       50,  0},
    { "UPD_USR_NM",                 ":upd_usr_nm",              offsetof(UsrJoin,updUsrNm), 0,        DB_COL_STRING,          100,  0},
    { "SYS_SRC",                    ":sys_src",                 offsetof(UsrJoin,sysSrc), 0,          DB_COL_STRING,          8,  0},
    { "TEL",                        ":tel",                     offsetof(UsrJoin,tel), 0,             DB_COL_STRING,          100,  0},
    { "FAX_NO",                     ":fax_no",                  offsetof(UsrJoin,faxNo), 0,           DB_COL_STRING,          100,  0},
    { "API_F",                      ":api_f",                   offsetof(UsrJoin,apiF), 0,            DB_COL_STRING,          8,  0},
    { "ORDR_PRVLG_F",               ":ordr_prvlg_f",            offsetof(UsrJoin,ordrPrvlgF), 0,      DB_COL_STRING,          8,  0},
    { "ORDR_PRVLG_MDFY_F",          ":ordr_prvlg_mdfy_f",       offsetof(UsrJoin,ordrPrvlgMdfyF), 0,  DB_COL_STRING,          8,  0},
    { "ORDR_PRVLG_F_SIRS",          ":ordr_prvlg_f_sirs",       offsetof(UsrJoin,ordrPrvlgFSirs), 0,          DB_COL_STRING,  8,  0},
    { "ORDR_PRVLG_MDFY_F_SIRS",     ":ordr_prvlg_mdfy_f_sirs",  offsetof(UsrJoin,ordrPrvlgMdfyFSirs), 0,      DB_COL_STRING,  8,  0},
    { "ORDR_PRVLG_F_SBFCCP",        ":ordr_prvlg_f_sbfccp",     offsetof(UsrJoin,ordrPrvlgFSbfccp), 0,         DB_COL_STRING, 8,  0},
    { "ORDR_PRVLG_MDFY_F_SBFCCP",   ":ordr_prvlg_mdfy_f_sbfccp",offsetof(UsrJoin,ordrPrvlgMdfyFSbfccp), 0,    DB_COL_STRING,  8,  0},
    { "SESN_ID",                    ":sesn_id",                 offsetof(UsrJoin,sesnId), 0,                  DB_COL_STRING,  10,  0},
    { "LGN_TP",                     ":lgn_tp",                  offsetof(UsrJoin,lgnTp), 0,                   DB_COL_INT32,   sizeof(int32),  0},
    { "LGN_TM",                     ":lgn_tm",                  offsetof(UsrJoin,lgnTm), offsetof(UsrJoin,pLgnTm),  DB_COL_TIMESTAMP,  30,  0},
    { "ROLE_ID",                    ":role_id",                 offsetof(UsrJoin,roleId), 0,                  DB_COL_STRING,         10,  0},
    { "MKT_TP",                     ":mkt_tp",                  offsetof(UsrJoin,mktTp), 0,                   DB_COL_STRING,         10,  0},
    { "ST",                         ":st",                      offsetof(UsrJoin,mktSt), 0,                   DB_COL_STRING,         10,  0},
};

static DbColInfoT gResColSelOnlnJn[] = {
    {"ORG_ID",                      ":org_id",                  offsetof(UsrJoin,orgId), 0,           DB_COL_INT32,           sizeof(int32),  0},
    {"USR_LGN_NM",                  ":usr_lgn_nm",              offsetof(UsrJoin,usrLgnNm), 0,        DB_COL_STRING,          100,            0},
};

static DbColInfoT gResColSelOrgId[] = {
    {"USR_LGN_NM",    ":usr_lgn_nm",    offsetof(UsrLgnNmT, usrLgnNm),    0,    DB_COL_STRING,    100,  0 },
};

/***********************************************************************************************
**
**   Function Declaration
**
************************************************************************************************/
ResCodeT FmtDateTimeType( Usr* pData );
ResCodeT FreeDateTimeType( Usr* pData );
ResCodeT SelectUsr(int32 connId, int32 * pStmntId);
ResCodeT SelectUsrJoin(int32 connId, int32 * pStmntId);
ResCodeT SelectUsrWithOrgId(int32 connId, int32 orgId, int32 *pStmntId);


/***********************************************************************************************
**
**   Function Implementation
**
************************************************************************************************/

ResCodeT InsertUsr(int32 connId, Usr* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertUsr" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gUsrDbInfo,
                            DB_USR_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextUsrJoin( BOOL * pFrstFlag, int32 connId, UsrJoin* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextUsrJoin" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectUsrJoin(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USRROLE_JOIN_TOT_COLMN,
                            gResColSelectJn, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    else if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }


    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SelectUsrJoin(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectUsrJoin" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelectJn, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT UpdateUsrByKey(int32 connId, Usr* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateUsrByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_USR_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND",
                                    keySql,
                                    gUsrDbInfo[keyIdx].colFlag,
                                    gUsrDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE USR SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_USR_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,",
                                    updateSql,
                                    gUsrDbInfo[colIdx].colFlag,
                                    gUsrDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gUsrDbInfo,
                    DB_USR_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfUsr(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfUsr" );

    int32       stmtId;
    UsrCntT    UsrCnt = {0};
    UsrCntT *  pUsrCnt = &UsrCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USR_CNT_NUM,
                        gUsrDbCntInfo, (void *) pUsrCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextUsr( BOOL * pFrstFlag, int32 connId, Usr* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextUsr" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectUsr(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USR_TOT_COLMN,
                            gUsrDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectUsr(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectUsr" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetResultCntOfOtherApiUsrOnln( int32 connId, int32 iOrgId, char* strUserId, int32* pCntOut )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOtherApiUsrOnln" );

    char inputSql[DB_COMM_SQL_TOT_LEN];

    int32       stmtId;
    UsrCntT     UsrOnlnCnt = {0};
    UsrCntT *   pUsrOnlnCnt = &UsrOnlnCnt;

    memset(inputSql, 0x00, DB_COMM_SQL_TOT_LEN);
    sprintf(inputSql, gSqlOtherApiUsrOnlnJnCount, iOrgId, strUserId);

    rc = DbCmmnPrprSql( connId, inputSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USR_CNT_NUM,
                        gUsrDbCntInfo, (void *) pCntOut );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrOnlnCnt.count;


    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetResultCntOfUsrOnln( int32 connId, char* strRemoveId, int32* pCntOut )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfUsrOnln" );

    char inputSql[DB_COMM_SQL_TOT_LEN];

    int32       stmtId;
    UsrCntT     UsrOnlnCnt = {0};
    UsrCntT *   pUsrOnlnCnt = &UsrOnlnCnt;

    memset(inputSql, 0x00, DB_COMM_SQL_TOT_LEN);
    sprintf(inputSql, gSqlUsrOnlnJnCount, strRemoveId);

    rc = DbCmmnPrprSql( connId, inputSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USR_CNT_NUM,
                        gUsrDbCntInfo, (void *) pCntOut );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrOnlnCnt.count;


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectUsrOnlnJn(int32 connId, char* strRemoveId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectUsrOnlnJn" );

    int32 stmtId;
    char inputSql[DB_COMM_SQL_TOT_LEN];

    memset(inputSql, 0x00, DB_COMM_SQL_TOT_LEN);
    sprintf(inputSql, gSqlUsrOnlnJn, strRemoveId);

    rc = DbCmmnPrprSql( connId, gSqlUsrOnlnJn, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT FetchNextUsrOnlnJn( BOOL * pFrstFlag, int32 connId, char* strRemoveId, UsrOnlnJnT* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextUsrOnlnJn" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectUsrOnlnJn(connId, strRemoveId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USR_ONLN_JOIN_TOT_COLMN,
                            gResColSelOnlnJn, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

// [OrgMarketRoleUpdate] add by lidongwei
ResCodeT GetResultCntOfUsrWithOrgId(int32 connId, int32 orgId, int32* pCntOut)
{
    BEGIN_FUNCTION( "GetResultCntOfUsrWithOrgId" );
    ResCodeT rc = NO_ERR;

    char inputSql[DB_COMM_SQL_TOT_LEN];
    int32     stmtId;
    UsrCntT   UsrCnt = {0};
    UsrCntT*  pUsrCnt = &UsrCnt;

    memset(inputSql, 0x00, DB_COMM_SQL_TOT_LEN);
    sprintf(inputSql, "SELECT COUNT(*) FROM USR U WHERE U.ORG_ID = %d ", orgId);

    rc = DbCmmnPrprSql( connId, inputSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_USR_CNT_NUM,
                        gUsrDbCntInfo, (void *)pUsrCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = UsrCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectUsrWithOrgId(int32 connId, int32 orgId, int32 *pStmntId)
{
    BEGIN_FUNCTION( "SelectUsrWithOrgId" );
    ResCodeT rc = NO_ERR;

    int32 stmtId;
    char inputSql[DB_COMM_SQL_TOT_LEN];

    memset(inputSql, 0x00, DB_COMM_SQL_TOT_LEN);
    sprintf(inputSql, "SELECT U.USR_LGN_NM FROM USR U WHERE U.ORG_ID = %d ", orgId);

    rc = DbCmmnPrprSql( connId, inputSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextUsrWithOrgId( BOOL *pFrstFlag, int32 connId, int32 orgId, char* pDataOut)
{
    BEGIN_FUNCTION( "FetchNextUsrWithOrgId" );
    ResCodeT rc = NO_ERR;

    static int32 stmntId;
    if ( *pFrstFlag ) {
        rc = SelectUsrWithOrgId(connId, orgId, &stmntId);
        RAISE_ERR(rc, RTN);
        *pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_USR_ORG_TOT_COLMN,
                            gResColSelOrgId, (void*)pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR ) {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR ) {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}
// [OrgMarketRoleUpdate] end by lidongwei

ResCodeT FmtDateTimeType( Usr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->pswdTm, &pData->pPswdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( Usr* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pPswdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT DeleteUsr(int32 connId, UsrKey* pKey)
{
    BEGIN_FUNCTION("DeleteUsr");
    ResCodeT rc = NO_ERR;

    int32 stmtId;
    int32 resNum = 0;
    char sql[1000] = {0};

    //make where condition
    strcpy(sql, "DELETE FROM USR WHERE");
    sprintf(sql, "%s USR_SRNO = %d ", sql, pKey->usrSrno);

    rc = DbCmmnPrprSql( connId, sql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
