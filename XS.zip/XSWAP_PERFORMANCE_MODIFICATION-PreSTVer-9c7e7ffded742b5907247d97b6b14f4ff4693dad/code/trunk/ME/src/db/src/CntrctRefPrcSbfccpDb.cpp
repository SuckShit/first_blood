/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctRefPrcSbfccpDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CNTRCTREFPRCSBFCCP_CNT_NUM         1

#define DB_CNTRCTREFPRCSBFCCP_TOT_COLMN       (sizeof(gCntrctRefPrcSbfccpDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CNTRCT_REF_PRC_SBFCCP "
"(CNTRCT_REF_PRC_SRNO,CNTRCT_CD,REF_PRC_DT,REF_PRC,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:cntrct_ref_prc_srno,:cntrct_cd,:ref_prc_dt,:ref_prc,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CNTRCT_REF_PRC_SBFCCP ";
static char gSqlSelect[] = "SELECT CNTRCT_REF_PRC_SRNO,CNTRCT_CD,REF_PRC_DT,REF_PRC,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM CNTRCT_REF_PRC_SBFCCP ";
static DbColInfoT gCntrctRefPrcSbfccpDbInfo[] = 
{
    {"CNTRCT_REF_PRC_SRNO",    ":cntrct_ref_prc_srno",    offsetof(CntrctRefPrcSbfccp, cntrctRefPrcSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(CntrctRefPrcSbfccp, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"REF_PRC_DT",    ":ref_prc_dt",    offsetof(CntrctRefPrcSbfccp, refPrcDt),    offsetof(CntrctRefPrcSbfccp, pRefPrcDt),    DB_COL_DATE,    50,  0 },
    {"REF_PRC",    ":ref_prc",    offsetof(CntrctRefPrcSbfccp, refPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctRefPrcSbfccp, crtTm),    offsetof(CntrctRefPrcSbfccp, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctRefPrcSbfccp, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctRefPrcSbfccp, updTm),    offsetof(CntrctRefPrcSbfccp, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctRefPrcSbfccp, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gCntrctRefPrcSbfccpDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctRefPrcSbfccpCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctRefPrcSbfccp* pData );
ResCodeT FreeDateTimeType( CntrctRefPrcSbfccp* pData );
ResCodeT SelectCntrctRefPrcSbfccp(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctRefPrcSbfccp(int32 connId, CntrctRefPrcSbfccp* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctRefPrcSbfccp" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctRefPrcSbfccpDbInfo,
                            DB_CNTRCTREFPRCSBFCCP_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctRefPrcSbfccpByKey(int32 connId, CntrctRefPrcSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctRefPrcSbfccpByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTREFPRCSBFCCP_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctRefPrcSbfccpDbInfo[keyIdx].colFlag,
                                    gCntrctRefPrcSbfccpDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CNTRCT_REF_PRC_SBFCCP SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTREFPRCSBFCCP_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctRefPrcSbfccpDbInfo[colIdx].colFlag,
                                    gCntrctRefPrcSbfccpDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctRefPrcSbfccpDbInfo, 
                    DB_CNTRCTREFPRCSBFCCP_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctRefPrcSbfccp(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctRefPrcSbfccp" );

    int32       stmtId;
    CntrctRefPrcSbfccpCntT    CntrctRefPrcSbfccpCnt = {0};
    CntrctRefPrcSbfccpCntT *  pCntrctRefPrcSbfccpCnt = &CntrctRefPrcSbfccpCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTREFPRCSBFCCP_CNT_NUM,
                        gCntrctRefPrcSbfccpDbCntInfo, (void *) pCntrctRefPrcSbfccpCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctRefPrcSbfccpCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCntrctRefPrcSbfccp( BOOL * pFrstFlag, int32 connId, CntrctRefPrcSbfccp* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctRefPrcSbfccp" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctRefPrcSbfccp(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTREFPRCSBFCCP_TOT_COLMN, 
                            gCntrctRefPrcSbfccpDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctRefPrcSbfccp(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctRefPrcSbfccp" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CntrctRefPrcSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->refPrcDt, &pData->pRefPrcDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctRefPrcSbfccp* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pRefPrcDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctRefPrcSbfccpByName(int32 connId, char * pCntrctName, int32 * pStmtId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctRefPrcSbfccpByName" );

    int32 stmntId = 0;
    char selectSql[MAX_BUFF_LEN] = {0};
    
    sprintf(selectSql, "%s WHERE CNTRCT_CD = '%s'", gSqlSelect, pCntrctName);
    
    rc = DbCmmnPrprSql( connId, selectSql, &stmntId );
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);
    
    * pStmtId = stmntId;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchCntrctRefPrcSbfccpByName(int32 connId, char * pCntrctName, CntrctRefPrcSbfccp* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchCntrctRefPrcSbfccpByName" );

    int32 stmntId;

    rc = SelectCntrctRefPrcSbfccpByName(connId, pCntrctName, &stmntId);
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTREFPRCSBFCCP_TOT_COLMN, 
                            gCntrctRefPrcSbfccpDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    DbCmmnFreeStmnt( stmntId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
