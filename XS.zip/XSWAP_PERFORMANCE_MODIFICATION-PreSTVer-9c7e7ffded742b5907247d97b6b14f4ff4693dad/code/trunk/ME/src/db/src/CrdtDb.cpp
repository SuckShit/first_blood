/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CrdtDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CRDT_CNT_NUM         1

#define DB_CRDT_TOT_COLMN       (sizeof(gCrdtDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CRDT "
"(CRDT_ID,CRDT_ORG_ID,CRDTD_ORG_ID,INTL_CRDT_AMNT,MKT_ID,CRDT_RL_F,USED_CRDT_AMNT,RMN_CRDT_AMNT,CRDT_TERM,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,USR_UPD_TM) VALUES "
"(:crdt_id,:crdt_org_id,:crdtd_org_id,:intl_crdt_amnt,:mkt_id,:crdt_rl_f,:used_crdt_amnt,:rmn_crdt_amnt,:crdt_term,:st,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:usr_upd_tm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CRDT ";
static char gSqlSelect[] = "SELECT CRDT_ID,CRDT_ORG_ID,CRDTD_ORG_ID,INTL_CRDT_AMNT,MKT_ID,NVL(CRDT_RL_F, ' '),USED_CRDT_AMNT,RMN_CRDT_AMNT,CRDT_TERM,NVL(ST, ' '),CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,USR_UPD_TM FROM CRDT ";
static DbColInfoT gCrdtDbInfo[] = 
{
    {"CRDT_ID",    ":crdt_id",    offsetof(Crdt, crdtId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CRDT_ORG_ID",    ":crdt_org_id",    offsetof(Crdt, crdtOrgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CRDTD_ORG_ID",    ":crdtd_org_id",    offsetof(Crdt, crdtdOrgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"INTL_CRDT_AMNT",    ":intl_crdt_amnt",    offsetof(Crdt, intlCrdtAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"MKT_ID",    ":mkt_id",    offsetof(Crdt, mktId),    0,    DB_COL_STRING,    8,  0 },
    {"CRDT_RL_F",    ":crdt_rl_f",    offsetof(Crdt, crdtRlF),    0,    DB_COL_STRING,    8,  0 },
    {"USED_CRDT_AMNT",    ":used_crdt_amnt",    offsetof(Crdt, usedCrdtAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"RMN_CRDT_AMNT",    ":rmn_crdt_amnt",    offsetof(Crdt, rmnCrdtAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRDT_TERM",    ":crdt_term",    offsetof(Crdt, crdtTerm),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ST",    ":st",    offsetof(Crdt, st),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(Crdt, crtTm),    offsetof(Crdt, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(Crdt, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(Crdt, updTm),    offsetof(Crdt, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(Crdt, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"USR_UPD_TM",    ":usr_upd_tm",    offsetof(Crdt, usrUpdTm),    offsetof(Crdt, pUsrUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
};

static DbColInfoT gCrdtDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CrdtCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( Crdt* pData );
ResCodeT FreeDateTimeType( Crdt* pData );
ResCodeT SelectCrdt(int32 connId, int32* pStmntId);
ResCodeT SelectCrdtBySt(int32 connId, int32* pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCrdt(int32 connId, Crdt* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCrdt" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCrdtDbInfo,
                            DB_CRDT_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT UpdateCrdtByKey(int32 connId, Crdt* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCrdtByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CRDT_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCrdtDbInfo[keyIdx].colFlag,
                                    gCrdtDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CRDT SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CRDT_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCrdtDbInfo[colIdx].colFlag,
                                    gCrdtDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCrdtDbInfo, 
                    DB_CRDT_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfCrdt(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCrdt" );

    int32       stmtId;
    CrdtCntT    CrdtCnt = {0};
    CrdtCntT *  pCrdtCnt = &CrdtCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CRDT_CNT_NUM,
                        gCrdtDbCntInfo, (void *) pCrdtCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = CrdtCnt.count;

    DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfCrdtByKeyRL(int32 connId, Crdt* pData, vectorT *pKeyFlg, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCrdtByKeyRL" );

    int32     stmtId;
    CrdtCntT  CrdtCnt = {0};
    CrdtCntT* pCrdtCnt = &CrdtCnt;
    int32     keyIdx = -1;
    char      keySql[DB_COMM_SQL_KEY_LEN];
    char      selectSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE CRDT_ORG_ID = :crdt_org_id AND CRDT_RL_F = :crdt_rl_f " );

    memset(selectSql, 0x00, sizeof(selectSql));
    sprintf(selectSql, "%s%s", gSqlSelectCount, keySql );

    rc = DbCmmnPrprSql(connId, selectSql, &stmtId);
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindVal(connId, stmtId, gCrdtDbInfo, 
                    DB_CRDT_TOT_COLMN, pKeyFlg, (void *)pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlWithRslt(connId, stmtId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext(connId, stmtId, DB_CRDT_CNT_NUM,
                        gCrdtDbCntInfo, (void *)pCrdtCnt);
    RAISE_ERR(rc, RTN);

    *pCntOut = CrdtCnt.count;

    DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntOfCrdtByKeyAmnt(int32 connId, Crdt* pData, vectorT *pKeyFlg, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCrdtByKeyAmnt" );

    int32     stmtId;
    CrdtCntT  CrdtCnt = {0};
    CrdtCntT* pCrdtCnt = &CrdtCnt;
    char      keySql[DB_COMM_SQL_KEY_LEN];
    char      selectSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE CRDT_ORG_ID = :crdt_org_id AND CRDT_RL_F IS NULL AND RMN_CRDT_AMNT >= :rmn_crdt_amnt " );

    memset(selectSql, 0x00, sizeof(selectSql));
    sprintf(selectSql, "%s%s", gSqlSelectCount, keySql );

    rc = DbCmmnPrprSql(connId, selectSql, &stmtId);
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindVal(connId, stmtId, gCrdtDbInfo, 
                    DB_CRDT_TOT_COLMN, pKeyFlg, (void *)pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlWithRslt(connId, stmtId);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext(connId, stmtId, DB_CRDT_CNT_NUM,
                        gCrdtDbCntInfo, (void *)pCrdtCnt);
    RAISE_ERR(rc, RTN);

    *pCntOut = CrdtCnt.count;

    DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextCrdt( BOOL * pFrstFlag, int32 connId, Crdt* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCrdt" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCrdt(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CRDT_TOT_COLMN, 
                            gCrdtDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FetchNextCrdtBySt(BOOL* pFrstFlag, int32 connId, Crdt* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCrdtBySt" );

    static int32 stmntId;

    if ( *pFrstFlag ) {
        rc = SelectCrdtBySt(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        *pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CRDT_TOT_COLMN, 
                            gCrdtDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCrdt(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCrdt" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCrdtBySt(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCrdtBySt" );

    int32 stmtId;
    char strSql[DB_COMM_SQL_TOT_LEN];
    const char strWhere[] = "WHERE ST = 1 ";

    memset(strSql, 0x00, sizeof(strSql));
    sprintf(strSql, "%s%s", gSqlSelect, strWhere);

    rc = DbCmmnPrprSql( connId, strSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FmtDateTimeType( Crdt* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->usrUpdTm, &pData->pUsrUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( Crdt* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUsrUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
