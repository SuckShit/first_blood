/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "MktStCfgDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_MKTSTCFG_CNT_NUM         1

#define DB_MKTSTCFG_TOT_COLMN       (sizeof(gMktStCfgDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO MKT_ST_CFG "
"(MKT_ST_CFG_ID,MKT_ST,STRT_TM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,NEXT_STRT_TM,SEND_F) VALUES "
"(:mkt_st_cfg_id,:mkt_st,:strt_tm,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:next_strt_tm,:send_f) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM MKT_ST_CFG ";
static char gSqlSelect[] = "SELECT MKT_ST_CFG_ID,MKT_ST,STRT_TM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,NEXT_STRT_TM,SEND_F FROM MKT_ST_CFG ";
static char gSqlSelectByKey[] = "SELECT MKT_ST_CFG_ID,MKT_ST,STRT_TM,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,NEXT_STRT_TM,SEND_F FROM MKT_ST_CFG WHERE MKT_ST_CFG_ID = %lld ";


static DbColInfoT gMktStCfgDbInfo[] = 
{
    {"MKT_ST_CFG_ID",    ":mkt_st_cfg_id",    offsetof(MktStCfg, mktStCfgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MKT_ST",    ":mkt_st",    offsetof(MktStCfg, mktSt),    0,    DB_COL_STRING,    8,  0 },
    {"STRT_TM",    ":strt_tm",    offsetof(MktStCfg, strtTm),    0,    DB_COL_STRING,    50,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(MktStCfg, crtTm),    offsetof(MktStCfg, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(MktStCfg, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(MktStCfg, updTm),    offsetof(MktStCfg, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(MktStCfg, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"NEXT_STRT_TM",    ":next_strt_tm",    offsetof(MktStCfg, nextStrtTm),    0,    DB_COL_STRING,    50,  0 },
    {"SEND_F",    ":send_f",    offsetof(MktStCfg, sendF),    0,    DB_COL_STRING,    8,  0 },
};

static DbColInfoT gMktStCfgDbCntInfo[] =
{
    {"",                 ":count",           offsetof(MktStCfgCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( MktStCfg* pData );
ResCodeT FreeDateTimeType( MktStCfg* pData );
ResCodeT SelectMktStCfg(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertMktStCfg(int32 connId, MktStCfg* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertMktStCfg" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gMktStCfgDbInfo,
                            DB_MKTSTCFG_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateMktStCfgByKey(int32 connId, MktStCfg* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateMktStCfgByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_MKTSTCFG_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gMktStCfgDbInfo[keyIdx].colFlag,
                                    gMktStCfgDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE MKT_ST_CFG SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_MKTSTCFG_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gMktStCfgDbInfo[colIdx].colFlag,
                                    gMktStCfgDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gMktStCfgDbInfo, 
                    DB_MKTSTCFG_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfMktStCfg(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfMktStCfg" );

    int32       stmtId;
    MktStCfgCntT    MktStCfgCnt = {0};
    MktStCfgCntT *  pMktStCfgCnt = &MktStCfgCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_MKTSTCFG_CNT_NUM,
                        gMktStCfgDbCntInfo, (void *) pMktStCfgCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = MktStCfgCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextMktStCfg( BOOL * pFrstFlag, int32 connId, MktStCfg* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextMktStCfg" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectMktStCfg(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_MKTSTCFG_TOT_COLMN, 
                            gMktStCfgDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SelectMktStCfg(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMktStCfg" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetMktStCfgByKey(int32 connId, uint64 ktStCfgId, MktStCfg* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetMktStCfgByKey" );
    int32 stmntId;
    char sqlSelByKey[200];
    
    sprintf(sqlSelByKey, gSqlSelectByKey, ktStCfgId);

    rc = DbCmmnPrprSql( connId, sqlSelByKey, &stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmntId, DB_MKTSTCFG_TOT_COLMN, 
                            gMktStCfgDbInfo, (void *) pDataOut );
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnFreeStmnt(stmntId);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( MktStCfg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( MktStCfg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
