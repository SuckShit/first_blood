/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctInfoSirsDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_CNTRCTINFOSIRS_CNT_NUM         1

#define DB_CNTRCTINFOSIRS_TOT_COLMN       (sizeof(gCntrctInfoSirsDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO cntrct_info_sirs "
"(CNTRCT_INFO_SRNO,CNTRCT_CD,CNTRCT_NM_EN,CNTRCT_NM_CN,CNTRCT_MTH,TERM,DL_PRC_UNIT,AMNT_PER_UNIT,MIN_AMNT_PER_DL,MAX_AMNT_PER_DL,DLVRY_DT,ACTV_DT,EXPRD_DT,EMGCY_F,ST,INTRST_STRT_DT,INTRST_END_DT,INTRST_DT,FRST_INTRST_DT,CALC_ORG,STLE_TP,BNCHMK_RATE,TRDNG_END_TM,INTRST_DAYS_ADJ,PYMNT_DT_ADJ,FXD_INTRST_BID_DLVRY_DT,FXD_INTRST_BID_PYMNT_PRD,FXD_INTRST_BID_INTRST_BNCHMK,FXD_INTRST_BID_INTRST_TP,REF_CNTRCT,FXD_INTRST_OFR_DLVRY_DAY,FRST_INTRST_CNFRM_DT,INTRST_TP,INTRST_SPRD,FXD_INTRST_OFR_PYMNT_PRD,RST_RATE,FXD_INTRST_OFR_INTRST_BNCHMK,MKT_TP,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,CNTRCT_FACE_VL) VALUES "
"(:cntrct_info_srno,:cntrct_cd,:cntrct_nm_en,:cntrct_nm_cn,:cntrct_mth,:term,:dl_prc_unit,:amnt_per_unit,:min_amnt_per_dl,:max_amnt_per_dl,:dlvry_dt,:actv_dt,:exprd_dt,:emgcy_f,:st,:intrst_strt_dt,:intrst_end_dt,:intrst_dt,:frst_intrst_dt,:calc_org,:stle_tp,:bnchmk_rate,:trdng_end_tm,:intrst_days_adj,:pymnt_dt_adj,:fxd_intrst_bid_dlvry_dt,:fxd_intrst_bid_pymnt_prd,:fxd_intrst_bid_intrst_bnchmk,:fxd_intrst_bid_intrst_tp,:ref_cntrct,:fxd_intrst_ofr_dlvry_day,:frst_intrst_cnfrm_dt,:intrst_tp,:intrst_sprd,:fxd_intrst_ofr_pymnt_prd,:rst_rate,:fxd_intrst_ofr_intrst_bnchmk,:mkt_tp,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:cntrct_face_vl) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM cntrct_info_sirs ";
static char gSqlSelect[] = "SELECT CNTRCT_INFO_SRNO,CNTRCT_CD,CNTRCT_NM_EN,CNTRCT_NM_CN,CNTRCT_MTH,TERM,DL_PRC_UNIT,AMNT_PER_UNIT,MIN_AMNT_PER_DL,MAX_AMNT_PER_DL,DLVRY_DT,ACTV_DT,EXPRD_DT,EMGCY_F,ST,INTRST_STRT_DT,INTRST_END_DT,INTRST_DT,FRST_INTRST_DT,CALC_ORG,STLE_TP,BNCHMK_RATE,TRDNG_END_TM,INTRST_DAYS_ADJ,PYMNT_DT_ADJ,FXD_INTRST_BID_DLVRY_DT,FXD_INTRST_BID_PYMNT_PRD,FXD_INTRST_BID_INTRST_BNCHMK,FXD_INTRST_BID_INTRST_TP,REF_CNTRCT,FXD_INTRST_OFR_DLVRY_DAY,FRST_INTRST_CNFRM_DT,INTRST_TP,INTRST_SPRD,FXD_INTRST_OFR_PYMNT_PRD,RST_RATE,FXD_INTRST_OFR_INTRST_BNCHMK,MKT_TP,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,CNTRCT_FACE_VL FROM cntrct_info_sirs ";
static DbColInfoT gCntrctInfoSirsDbInfo[] = 
{
    {"CNTRCT_INFO_SRNO",    ":cntrct_info_srno",    offsetof(CntrctInfoSirs, cntrctInfoSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_CD",    ":cntrct_cd",    offsetof(CntrctInfoSirs, cntrctCd),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_NM_EN",    ":cntrct_nm_en",    offsetof(CntrctInfoSirs, cntrctNmEn),    0,    DB_COL_STRING,    100,  0 },
    {"CNTRCT_NM_CN",    ":cntrct_nm_cn",    offsetof(CntrctInfoSirs, cntrctNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"CNTRCT_MTH",    ":cntrct_mth",    offsetof(CntrctInfoSirs, cntrctMth),    0,    DB_COL_STRING,    50,  0 },
    {"TERM",    ":term",    offsetof(CntrctInfoSirs, term),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DL_PRC_UNIT",    ":dl_prc_unit",    offsetof(CntrctInfoSirs, dlPrcUnit),    0,    DB_COL_STRING,    8,  0 },
    {"AMNT_PER_UNIT",    ":amnt_per_unit",    offsetof(CntrctInfoSirs, amntPerUnit),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"MIN_AMNT_PER_DL",    ":min_amnt_per_dl",    offsetof(CntrctInfoSirs, minAmntPerDl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MAX_AMNT_PER_DL",    ":max_amnt_per_dl",    offsetof(CntrctInfoSirs, maxAmntPerDl),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DLVRY_DT",    ":dlvry_dt",    offsetof(CntrctInfoSirs, dlvryDt),    offsetof(CntrctInfoSirs, pDlvryDt),    DB_COL_DATE,    50,  0 },
    {"ACTV_DT",    ":actv_dt",    offsetof(CntrctInfoSirs, actvDt),    offsetof(CntrctInfoSirs, pActvDt),    DB_COL_DATE,    50,  0 },
    {"EXPRD_DT",    ":exprd_dt",    offsetof(CntrctInfoSirs, exprdDt),    offsetof(CntrctInfoSirs, pExprdDt),    DB_COL_DATE,    50,  0 },
    {"EMGCY_F",    ":emgcy_f",    offsetof(CntrctInfoSirs, emgcyF),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(CntrctInfoSirs, st),    0,    DB_COL_STRING,    8,  0 },
    {"INTRST_STRT_DT",    ":intrst_strt_dt",    offsetof(CntrctInfoSirs, intrstStrtDt),    offsetof(CntrctInfoSirs, pIntrstStrtDt),    DB_COL_DATE,    50,  0 },
    {"INTRST_END_DT",    ":intrst_end_dt",    offsetof(CntrctInfoSirs, intrstEndDt),    offsetof(CntrctInfoSirs, pIntrstEndDt),    DB_COL_DATE,    50,  0 },
    {"INTRST_DT",    ":intrst_dt",    offsetof(CntrctInfoSirs, intrstDt),    offsetof(CntrctInfoSirs, pIntrstDt),    DB_COL_DATE,    50,  0 },
    {"FRST_INTRST_DT",    ":frst_intrst_dt",    offsetof(CntrctInfoSirs, frstIntrstDt),    offsetof(CntrctInfoSirs, pFrstIntrstDt),    DB_COL_DATE,    50,  0 },
    {"CALC_ORG",    ":calc_org",    offsetof(CntrctInfoSirs, calcOrg),    0,    DB_COL_STRING,    300,  0 },
    {"STLE_TP",    ":stle_tp",    offsetof(CntrctInfoSirs, stleTp),    0,    DB_COL_STRING,    8,  0 },
    {"BNCHMK_RATE",    ":bnchmk_rate",    offsetof(CntrctInfoSirs, bnchmkRate),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"TRDNG_END_TM",    ":trdng_end_tm",    offsetof(CntrctInfoSirs, trdngEndTm),    0,    DB_COL_STRING,    50,  0 },
    {"INTRST_DAYS_ADJ",    ":intrst_days_adj",    offsetof(CntrctInfoSirs, intrstDaysAdj),    0,    DB_COL_STRING,    8,  0 },
    {"PYMNT_DT_ADJ",    ":pymnt_dt_adj",    offsetof(CntrctInfoSirs, pymntDtAdj),    0,    DB_COL_STRING,    8,  0 },
    {"FXD_INTRST_BID_DLVRY_DT",    ":fxd_intrst_bid_dlvry_dt",    offsetof(CntrctInfoSirs, fxdIntrstBidDlvryDt),    offsetof(CntrctInfoSirs, pFxdIntrstBidDlvryDt),    DB_COL_DATE,    50,  0 },
    {"FXD_INTRST_BID_PYMNT_PRD",    ":fxd_intrst_bid_pymnt_prd",    offsetof(CntrctInfoSirs, fxdIntrstBidPymntPrd),    0,    DB_COL_STRING,    8,  0 },
    {"FXD_INTRST_BID_INTRST_BNCHMK",    ":fxd_intrst_bid_intrst_bnchmk",    offsetof(CntrctInfoSirs, fxdIntrstBidIntrstBnchmk),    0,    DB_COL_STRING,    8,  0 },
    {"FXD_INTRST_BID_INTRST_TP",    ":fxd_intrst_bid_intrst_tp",    offsetof(CntrctInfoSirs, fxdIntrstBidIntrstTp),    0,    DB_COL_STRING,    8,  0 },
    {"REF_CNTRCT",    ":ref_cntrct",    offsetof(CntrctInfoSirs, refCntrct),    0,    DB_COL_STRING,    50,  0 },
    {"FXD_INTRST_OFR_DLVRY_DAY",    ":fxd_intrst_ofr_dlvry_day",    offsetof(CntrctInfoSirs, fxdIntrstOfrDlvryDay),    offsetof(CntrctInfoSirs, pFxdIntrstOfrDlvryDay),    DB_COL_DATE,    50,  0 },
    {"FRST_INTRST_CNFRM_DT",    ":frst_intrst_cnfrm_dt",    offsetof(CntrctInfoSirs, frstIntrstCnfrmDt),    offsetof(CntrctInfoSirs, pFrstIntrstCnfrmDt),    DB_COL_DATE,    50,  0 },
    {"INTRST_TP",    ":intrst_tp",    offsetof(CntrctInfoSirs, intrstTp),    0,    DB_COL_STRING,    8,  0 },
    {"INTRST_SPRD",    ":intrst_sprd",    offsetof(CntrctInfoSirs, intrstSprd),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"FXD_INTRST_OFR_PYMNT_PRD",    ":fxd_intrst_ofr_pymnt_prd",    offsetof(CntrctInfoSirs, fxdIntrstOfrPymntPrd),    0,    DB_COL_STRING,    8,  0 },
    {"RST_RATE",    ":rst_rate",    offsetof(CntrctInfoSirs, rstRate),    0,    DB_COL_STRING,    8,  0 },
    {"FXD_INTRST_OFR_INTRST_BNCHMK",    ":fxd_intrst_ofr_intrst_bnchmk",    offsetof(CntrctInfoSirs, fxdIntrstOfrIntrstBnchmk),    0,    DB_COL_STRING,    8,  0 },
    {"MKT_TP",    ":mkt_tp",    offsetof(CntrctInfoSirs, mktTp),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctInfoSirs, crtTm),    offsetof(CntrctInfoSirs, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctInfoSirs, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctInfoSirs, updTm),    offsetof(CntrctInfoSirs, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctInfoSirs, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CNTRCT_FACE_VL",    ":cntrct_face_vl",    offsetof(CntrctInfoSirs, cntrctFaceVl),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
};

static DbColInfoT gCntrctInfoSirsDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctInfoSirsCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctInfoSirs* pData );
ResCodeT FreeDateTimeType( CntrctInfoSirs* pData );
ResCodeT SelectCntrctInfoSirs(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctInfoSirs(int32 connId, CntrctInfoSirs* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctInfoSirs" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctInfoSirsDbInfo,
                            DB_CNTRCTINFOSIRS_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctInfoSirsByKey(int32 connId, CntrctInfoSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctInfoSirsByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTINFOSIRS_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctInfoSirsDbInfo[keyIdx].colFlag,
                                    gCntrctInfoSirsDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE cntrct_info_sirs SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTINFOSIRS_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctInfoSirsDbInfo[colIdx].colFlag,
                                    gCntrctInfoSirsDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctInfoSirsDbInfo, 
                    DB_CNTRCTINFOSIRS_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctInfoSirs(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctInfoSirs" );

    int32       stmtId;
    CntrctInfoSirsCntT    CntrctInfoSirsCnt = {0};
    CntrctInfoSirsCntT *  pCntrctInfoSirsCnt = &CntrctInfoSirsCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTINFOSIRS_CNT_NUM,
                        gCntrctInfoSirsDbCntInfo, (void *) pCntrctInfoSirsCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctInfoSirsCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextCntrctInfoSirs( BOOL * pFrstFlag, int32 connId, CntrctInfoSirs* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctInfoSirs" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctInfoSirs(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTINFOSIRS_TOT_COLMN, 
                            gCntrctInfoSirsDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctInfoSirs(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctInfoSirs" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CntrctInfoSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->dlvryDt, &pData->pDlvryDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->actvDt, &pData->pActvDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->exprdDt, &pData->pExprdDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->intrstStrtDt, &pData->pIntrstStrtDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->intrstEndDt, &pData->pIntrstEndDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->intrstDt, &pData->pIntrstDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->frstIntrstDt, &pData->pFrstIntrstDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->fxdIntrstBidDlvryDt, &pData->pFxdIntrstBidDlvryDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->fxdIntrstOfrDlvryDay, &pData->pFxdIntrstOfrDlvryDay);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtDateType( pData->frstIntrstCnfrmDt, &pData->pFrstIntrstCnfrmDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctInfoSirs* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pDlvryDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pActvDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pExprdDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pIntrstStrtDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pIntrstEndDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pIntrstDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pFrstIntrstDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pFxdIntrstBidDlvryDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pFxdIntrstOfrDlvryDay);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeDateType( pData->pFrstIntrstCnfrmDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
