/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "DlDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_DL_CNT_NUM         1

#define DB_DL_TOT_COLMN       (sizeof(gDlDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO DL "
"(DL_ID,CNTRCT_NM,DL_TP,TRDNG_MTHD,FXD_INTRST_BID_ORG_ID,FXD_INTRST_BID_TRDR,FXD_INTRST_BID_TRDR_NM,FXD_INTRST_BID_ORDR_ID,FXD_INTRST_OFR_ORG_ID,FXD_INTRST_OFR_TRDR,FXD_INTRST_OFR_TRDR_NM,FXD_INTRST_OFR_ORDR_ID,NTNL_AMNT,DL_PRC,DL_DT,DL_TM,DL_ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,FXD_INTRST_BID_ORG_NM_CN,FXD_INTRST_OFR_ORG_NM_CN,DL_DIR,BRDG_ORG_DL_DIR,MKR_ORG_ID,FXD_INTRST_BID_ORG_SHORT_NM_CN,FXD_INTRST_OFR_ORG_SHORT_NM_CN,FXD_INTRST_BID_ORG_SHORT_NM_EN,FXD_INTRST_OFR_ORG_SHORT_NM_EN) VALUES "
"(:dl_id,:cntrct_nm,:dl_tp,:trdng_mthd,:fxd_intrst_bid_org_id,:fxd_intrst_bid_trdr,:fxd_intrst_bid_trdr_nm,:fxd_intrst_bid_ordr_id,:fxd_intrst_ofr_org_id,:fxd_intrst_ofr_trdr,:fxd_intrst_ofr_trdr_nm,:fxd_intrst_ofr_ordr_id,:ntnl_amnt,:dl_prc,:dl_dt,:dl_tm,:dl_st,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm,:fxd_intrst_bid_org_nm_cn,:fxd_intrst_ofr_org_nm_cn,:dl_dir,:brdg_org_dl_dir,:mkr_org_id,:fxd_intrst_bid_org_short_nm_cn,:fxd_intrst_ofr_org_short_nm_cn,:fxd_intrst_bid_org_short_nm_en,:fxd_intrst_ofr_org_short_nm_en) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM DL ";
static char gSqlSelect[] = "SELECT DL_ID,CNTRCT_NM,DL_TP,TRDNG_MTHD,FXD_INTRST_BID_ORG_ID,FXD_INTRST_BID_TRDR,FXD_INTRST_BID_TRDR_NM,FXD_INTRST_BID_ORDR_ID,FXD_INTRST_OFR_ORG_ID,FXD_INTRST_OFR_TRDR,FXD_INTRST_OFR_TRDR_NM,FXD_INTRST_OFR_ORDR_ID,NTNL_AMNT,DL_PRC,DL_DT,DL_TM,DL_ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,FXD_INTRST_BID_ORG_NM_CN,FXD_INTRST_OFR_ORG_NM_CN,NVL(DL_DIR, ' '),NVL(BRDG_ORG_DL_DIR, ' '),MKR_ORG_ID,NVL(FXD_INTRST_BID_ORG_SHORT_NM_CN, ' '),NVL(FXD_INTRST_OFR_ORG_SHORT_NM_CN, ' '),NVL(FXD_INTRST_BID_ORG_SHORT_NM_EN, ' '),NVL(FXD_INTRST_OFR_ORG_SHORT_NM_EN, ' ') FROM DL ";
static DbColInfoT gDlDbInfo[] = 
{
    {"DL_ID",    ":dl_id",    offsetof(Dl, dlId),    0,    DB_COL_STRING,    50,  0 },
    {"CNTRCT_NM",    ":cntrct_nm",    offsetof(Dl, cntrctNm),    0,    DB_COL_STRING,    50,  0 },
    {"DL_TP",    ":dl_tp",    offsetof(Dl, dlTp),    0,    DB_COL_STRING,    8,  0 },
    {"TRDNG_MTHD",    ":trdng_mthd",    offsetof(Dl, trdngMthd),    0,    DB_COL_STRING,    8,  0 },
    {"FXD_INTRST_BID_ORG_ID",    ":fxd_intrst_bid_org_id",    offsetof(Dl, fxdIntrstBidOrgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"FXD_INTRST_BID_TRDR",    ":fxd_intrst_bid_trdr",    offsetof(Dl, fxdIntrstBidTrdr),    0,    DB_COL_STRING,    100,  0 },
    {"FXD_INTRST_BID_TRDR_NM",    ":fxd_intrst_bid_trdr_nm",    offsetof(Dl, fxdIntrstBidTrdrNm),    0,    DB_COL_STRING,    300,  0 },
    {"FXD_INTRST_BID_ORDR_ID",    ":fxd_intrst_bid_ordr_id",    offsetof(Dl, fxdIntrstBidOrdrId),    0,    DB_COL_STRING,    50,  0 },
    {"FXD_INTRST_OFR_ORG_ID",    ":fxd_intrst_ofr_org_id",    offsetof(Dl, fxdIntrstOfrOrgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"FXD_INTRST_OFR_TRDR",    ":fxd_intrst_ofr_trdr",    offsetof(Dl, fxdIntrstOfrTrdr),    0,    DB_COL_STRING,    100,  0 },
    {"FXD_INTRST_OFR_TRDR_NM",    ":fxd_intrst_ofr_trdr_nm",    offsetof(Dl, fxdIntrstOfrTrdrNm),    0,    DB_COL_STRING,    300,  0 },
    {"FXD_INTRST_OFR_ORDR_ID",    ":fxd_intrst_ofr_ordr_id",    offsetof(Dl, fxdIntrstOfrOrdrId),    0,    DB_COL_STRING,    50,  0 },
    {"NTNL_AMNT",    ":ntnl_amnt",    offsetof(Dl, ntnlAmnt),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"DL_PRC",    ":dl_prc",    offsetof(Dl, dlPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"DL_DT",    ":dl_dt",    offsetof(Dl, dlDt),    offsetof(Dl, pDlDt),    DB_COL_DATE,    50,  0 },
    {"DL_TM",    ":dl_tm",    offsetof(Dl, dlTm),    offsetof(Dl, pDlTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"DL_ST",    ":dl_st",    offsetof(Dl, dlSt),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(Dl, crtTm),    offsetof(Dl, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(Dl, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(Dl, updTm),    offsetof(Dl, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(Dl, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"FXD_INTRST_BID_ORG_NM_CN",    ":fxd_intrst_bid_org_nm_cn",    offsetof(Dl, fxdIntrstBidOrgNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"FXD_INTRST_OFR_ORG_NM_CN",    ":fxd_intrst_ofr_org_nm_cn",    offsetof(Dl, fxdIntrstOfrOrgNmCn),    0,    DB_COL_STRING,    300,  0 },
    {"DL_DIR",    ":dl_dir",    offsetof(Dl, dlDir),    0,    DB_COL_STRING,    8,  0 },
    {"BRDG_ORG_DL_DIR",    ":brdg_org_dl_dir",    offsetof(Dl, brdgOrgDlDir),    0,    DB_COL_STRING,    8,  0 },
    {"MKR_ORG_ID",    ":mkr_org_id",    offsetof(Dl, mkrOrgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"FXD_INTRST_BID_ORG_SHORT_NM_CN",    ":fxd_intrst_bid_org_short_nm_cn",    offsetof(Dl, fxdIntrstBidOrgShortNmCn),    0,    DB_COL_STRING,    100,  0 },
    {"FXD_INTRST_OFR_ORG_SHORT_NM_CN",    ":fxd_intrst_ofr_org_short_nm_cn",    offsetof(Dl, fxdIntrstOfrOrgShortNmCn),    0,    DB_COL_STRING,    100,  0 },
    {"FXD_INTRST_BID_ORG_SHORT_NM_EN",    ":fxd_intrst_bid_org_short_nm_en",    offsetof(Dl, fxdIntrstBidOrgShortNmEn),    0,    DB_COL_STRING,    100,  0 },
    {"FXD_INTRST_OFR_ORG_SHORT_NM_EN",    ":fxd_intrst_ofr_org_short_nm_en",    offsetof(Dl, fxdIntrstOfrOrgShortNmEn),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gDlDbCntInfo[] =
{
    {"",                 ":count",           offsetof(DlCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( Dl* pData );
ResCodeT FreeDateTimeType( Dl* pData );
ResCodeT SelectDl(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertDl(int32 connId, Dl* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertDl" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gDlDbInfo,
                            DB_DL_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateDlByKey(int32 connId, Dl* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateDlByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_DL_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gDlDbInfo[keyIdx].colFlag,
                                    gDlDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE DL SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_DL_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gDlDbInfo[colIdx].colFlag,
                                    gDlDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gDlDbInfo, 
                    DB_DL_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfDl(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfDl" );

    int32       stmtId;
    DlCntT    DlCnt = {0};
    DlCntT *  pDlCnt = &DlCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_DL_CNT_NUM,
                        gDlDbCntInfo, (void *) pDlCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = DlCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextDl( BOOL * pFrstFlag, int32 connId, Dl* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextDl" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectDl(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_DL_TOT_COLMN, 
                            gDlDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectDl(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
BEGIN_FUNCTION( "SelectDl" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( Dl* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->dlDt, &pData->pDlDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->dlTm, &pData->pDlTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( Dl* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pDlDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pDlTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
