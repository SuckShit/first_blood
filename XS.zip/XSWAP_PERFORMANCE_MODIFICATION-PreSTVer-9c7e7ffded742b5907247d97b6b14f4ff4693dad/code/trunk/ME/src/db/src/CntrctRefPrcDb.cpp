/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "CntrctRefPrcDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/
#define DB_CNTRCTREFPRC_CNT_NUM         1

#define DB_CNTRCTREFPRC_TOT_COLMN       (sizeof(gCntrctRefPrcDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO CNTRCT_REF_PRC "
"(CNTRCT_REF_PRC_SRNO,CNTRCT_NM,REF_PRC_DT,REF_PRC,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:cntrct_ref_prc_srno,:cntrct_nm,:ref_prc_dt,:ref_prc,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM CNTRCT_REF_PRC ";
static char gSqlSelect[] = "SELECT CNTRCT_REF_PRC_SRNO,CNTRCT_NM,REF_PRC_DT,REF_PRC,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM CNTRCT_REF_PRC ";
static DbColInfoT gCntrctRefPrcDbInfo[] = 
{
    {"CNTRCT_REF_PRC_SRNO",    ":cntrct_ref_prc_srno",    offsetof(CntrctRefPrc, cntrctRefPrcSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CNTRCT_NM",    ":cntrct_nm",    offsetof(CntrctRefPrc, cntrctNm),    0,    DB_COL_STRING,    50,  0 },
    {"REF_PRC_DT",    ":ref_prc_dt",    offsetof(CntrctRefPrc, refPrcDt),    offsetof(CntrctRefPrc, pRefPrcDt),    DB_COL_DATE,    50,  0 },
    {"REF_PRC",    ":ref_prc",    offsetof(CntrctRefPrc, refPrc),    0,    DB_COL_DOUBLE,    sizeof(double),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(CntrctRefPrc, crtTm),    offsetof(CntrctRefPrc, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(CntrctRefPrc, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(CntrctRefPrc, updTm),    offsetof(CntrctRefPrc, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(CntrctRefPrc, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gCntrctRefPrcDbCntInfo[] =
{
    {"",                 ":count",           offsetof(CntrctRefPrcCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( CntrctRefPrc* pData );
ResCodeT FreeDateTimeType( CntrctRefPrc* pData );
ResCodeT SelectCntrctRefPrc(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertCntrctRefPrc(int32 connId, CntrctRefPrc* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertCntrctRefPrc" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gCntrctRefPrcDbInfo,
                            DB_CNTRCTREFPRC_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateCntrctRefPrcByKey(int32 connId, CntrctRefPrc* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateCntrctRefPrcByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_CNTRCTREFPRC_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gCntrctRefPrcDbInfo[keyIdx].colFlag,
                                    gCntrctRefPrcDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE CNTRCT_REF_PRC SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_CNTRCTREFPRC_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gCntrctRefPrcDbInfo[colIdx].colFlag,
                                    gCntrctRefPrcDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gCntrctRefPrcDbInfo, 
                    DB_CNTRCTREFPRC_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfCntrctRefPrc(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfCntrctRefPrc" );

    int32       stmtId;
    CntrctRefPrcCntT    CntrctRefPrcCnt = {0};
    CntrctRefPrcCntT *  pCntrctRefPrcCnt = &CntrctRefPrcCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_CNTRCTREFPRC_CNT_NUM,
                        gCntrctRefPrcDbCntInfo, (void *) pCntrctRefPrcCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = CntrctRefPrcCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}




ResCodeT FetchNextCntrctRefPrc( BOOL * pFrstFlag, int32 connId, CntrctRefPrc* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctRefPrc" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectCntrctRefPrc(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTREFPRC_TOT_COLMN, 
                            gCntrctRefPrcDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectCntrctRefPrc(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectCntrctRefPrc" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( CntrctRefPrc* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtDateType( pData->refPrcDt, &pData->pRefPrcDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( CntrctRefPrc* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeDateType( pData->pRefPrcDt);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT SelectCntrctRefPrcByName(int32 connId, char * pCntrctName, int32 * pStmtId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectMemTxnTbl" );

    int32 stmntId = 0;
    char selectSql[MAX_BUFF_LEN] = {0};
    
    sprintf(selectSql, "%s WHERE CNTRCT_NM = '%s'", gSqlSelect, pCntrctName);
    
    rc = DbCmmnPrprSql( connId, selectSql, &stmntId );
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnExcSqlWithRslt( connId, stmntId );
    RAISE_ERR(rc, RTN);
    
    * pStmtId = stmntId;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
    
    
}


ResCodeT FetchCntrctRefPrcByName(int32 connId, char * pCntrctName, CntrctRefPrc* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextCntrctRefPrc" );

    int32 stmntId;

    rc = SelectCntrctRefPrcByName(connId, pCntrctName, &stmntId);
    RAISE_ERR(rc, RTN);
    
    rc = DbCmmnFetchNext( connId, stmntId, DB_CNTRCTREFPRC_TOT_COLMN, 
                            gCntrctRefPrcDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    DbCmmnFreeStmnt( stmntId );
    RAISE_ERR(rc, RTN);


    EXIT_BLOCK();
    RETURN_RESCODE;
}