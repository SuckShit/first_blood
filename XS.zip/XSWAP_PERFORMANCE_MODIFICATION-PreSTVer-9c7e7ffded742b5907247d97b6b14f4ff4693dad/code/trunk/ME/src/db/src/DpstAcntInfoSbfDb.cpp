/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "DpstAcntInfoSbfDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_DPSTACNTINFOSBF_CNT_NUM         1

#define DB_DPSTACNTINFOSBF_TOT_COLMN       (sizeof(gDpstAcntInfoSbfDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO DPST_ACNT_INFO_SBF "
"(DPST_ACNT_SRNO,DPST_ACNT_ID,DPST_ACNT_NO,DPST_ACNT_NM,DPST_ORG,ORG_ID,ACNT_SRNO,DFLT_ACNT,ST,SYS_SRC,CRT_USR_NM,CRT_TM,UPD_USR_NM,UPD_TM) VALUES "
"(:dpst_acnt_srno,:dpst_acnt_id,:dpst_acnt_no,:dpst_acnt_nm,:dpst_org,:org_id,:acnt_srno,:dflt_acnt,:st,:sys_src,:crt_usr_nm,:crt_tm,:upd_usr_nm,:upd_tm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM DPST_ACNT_INFO_SBF ";
static char gSqlSelect[] = "SELECT DPST_ACNT_SRNO,DPST_ACNT_ID,DPST_ACNT_NO,DPST_ACNT_NM,DPST_ORG,ORG_ID,ACNT_SRNO,DFLT_ACNT,ST,SYS_SRC,CRT_USR_NM,CRT_TM,UPD_USR_NM,UPD_TM FROM DPST_ACNT_INFO_SBF ";
static DbColInfoT gDpstAcntInfoSbfDbInfo[] = 
{
    {"DPST_ACNT_SRNO",    ":dpst_acnt_srno",    offsetof(DpstAcntInfoSbf, dpstAcntSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DPST_ACNT_ID",    ":dpst_acnt_id",    offsetof(DpstAcntInfoSbf, dpstAcntId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DPST_ACNT_NO",    ":dpst_acnt_no",    offsetof(DpstAcntInfoSbf, dpstAcntNo),    0,    DB_COL_STRING,    200,  0 },
    {"DPST_ACNT_NM",    ":dpst_acnt_nm",    offsetof(DpstAcntInfoSbf, dpstAcntNm),    0,    DB_COL_STRING,    500,  0 },
    {"DPST_ORG",    ":dpst_org",    offsetof(DpstAcntInfoSbf, dpstOrg),    0,    DB_COL_STRING,    500,  0 },
    {"ORG_ID",    ":org_id",    offsetof(DpstAcntInfoSbf, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ACNT_SRNO",    ":acnt_srno",    offsetof(DpstAcntInfoSbf, acntSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"DFLT_ACNT",    ":dflt_acnt",    offsetof(DpstAcntInfoSbf, dfltAcnt),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(DpstAcntInfoSbf, st),    0,    DB_COL_STRING,    8,  0 },
    {"SYS_SRC",    ":sys_src",    offsetof(DpstAcntInfoSbf, sysSrc),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(DpstAcntInfoSbf, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(DpstAcntInfoSbf, crtTm),    offsetof(DpstAcntInfoSbf, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(DpstAcntInfoSbf, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(DpstAcntInfoSbf, updTm),    offsetof(DpstAcntInfoSbf, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
};

static DbColInfoT gDpstAcntInfoSbfDbCntInfo[] =
{
    {"",                 ":count",           offsetof(DpstAcntInfoSbfCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( DpstAcntInfoSbf* pData );
ResCodeT FreeDateTimeType( DpstAcntInfoSbf* pData );
ResCodeT SelectDpstAcntInfoSbf(int32 connId, int32 * pStmntId);
ResCodeT SelectDpstAcntInfoSbfByKey(int32 connId, int32 * pStmntId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertDpstAcntInfoSbf(int32 connId, DpstAcntInfoSbf* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertDpstAcntInfoSbf" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gDpstAcntInfoSbfDbInfo,
                            DB_DPSTACNTINFOSBF_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateDpstAcntInfoSbfByKey(int32 connId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateDpstAcntInfoSbfByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_DPSTACNTINFOSBF_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gDpstAcntInfoSbfDbInfo[keyIdx].colFlag,
                                    gDpstAcntInfoSbfDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE DPST_ACNT_INFO_SBF SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_DPSTACNTINFOSBF_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gDpstAcntInfoSbfDbInfo[colIdx].colFlag,
                                    gDpstAcntInfoSbfDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gDpstAcntInfoSbfDbInfo, 
                    DB_DPSTACNTINFOSBF_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfDpstAcntInfoSbf(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfDpstAcntInfoSbf" );

    int32       stmtId;
    DpstAcntInfoSbfCntT    DpstAcntInfoSbfCnt = {0};
    DpstAcntInfoSbfCntT *  pDpstAcntInfoSbfCnt = &DpstAcntInfoSbfCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_DPSTACNTINFOSBF_CNT_NUM,
                        gDpstAcntInfoSbfDbCntInfo, (void *) pDpstAcntInfoSbfCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = DpstAcntInfoSbfCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfDpstAcntInfoSbfByKey(int32 connId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("GetResultCntOfDpstAcntInfoSbfByKey");

    int32   stmtId;
    int32   keyIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char selectSql[DB_COMM_SQL_TOT_LEN];
	
	DpstAcntInfoSbfCntT    acntInfoCnt = {0};
    DpstAcntInfoSbfCntT *  pAcntInfoCnt = &acntInfoCnt;

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_DPSTACNTINFOSBF_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gDpstAcntInfoSbfDbInfo[keyIdx].colFlag,
                                    gDpstAcntInfoSbfDbInfo[keyIdx].colName );
    }

    memset( selectSql, 0x00, sizeof(selectSql) );
    strcpy( selectSql, "SELECT COUNT(*) FROM DPST_ACNT_INFO_SBF " );

	strcat(selectSql, keySql );


    rc = DbCmmnPrprSql( connId, selectSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gDpstAcntInfoSbfDbInfo, 
                    DB_DPSTACNTINFOSBF_TOT_COLMN, pKeyFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);
	
	rc = DbCmmnFetchNext( connId, stmtId, DB_DPSTACNTINFOSBF_CNT_NUM,
                        gDpstAcntInfoSbfDbCntInfo, (void *) pAcntInfoCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);


    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);
	
	*pCntOut = acntInfoCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextDpstAcntInfoSbf( BOOL * pFrstFlag, int32 connId, DpstAcntInfoSbf* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextDpstAcntInfoSbf" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectDpstAcntInfoSbf(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_DPSTACNTINFOSBF_TOT_COLMN, 
                            gDpstAcntInfoSbfDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectDpstAcntInfoSbf(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectDpstAcntInfoSbf" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextDpstAcntInfoSbfByKey( BOOL * pFrstFlag, int32 connId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg, DpstAcntInfoSbf* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextDpstAcntInfoSbfByKey" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectDpstAcntInfoSbfByKey(connId, &stmntId, pData, pKeyFlg);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_DPSTACNTINFOSBF_TOT_COLMN, 
                            gDpstAcntInfoSbfDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT SelectDpstAcntInfoSbfByKey(int32 connId, int32 * pStmntId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectDpstAcntInfoSbfByKey" );

    int32 stmtId;
	int32   keyIdx = -1;
	
	char keySql[DB_COMM_SQL_KEY_LEN];
    char selectSql[DB_COMM_SQL_TOT_LEN];
	
    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_DPSTACNTINFOSBF_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gDpstAcntInfoSbfDbInfo[keyIdx].colFlag,
                                    gDpstAcntInfoSbfDbInfo[keyIdx].colName );
    }

    memset( selectSql, 0x00, sizeof(selectSql) );

	sprintf(selectSql, "%s %s", gSqlSelect, keySql );
	

    rc = DbCmmnPrprSql( connId, selectSql, &stmtId );
    RAISE_ERR(rc, RTN);
	
	/* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gDpstAcntInfoSbfDbInfo, 
                    DB_DPSTACNTINFOSBF_TOT_COLMN, pKeyFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);
	
	/* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( DpstAcntInfoSbf* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( DpstAcntInfoSbf* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
