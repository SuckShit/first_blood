/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "SysStRsrcDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_SYSSTRSRC_CNT_NUM         1

#define DB_SYSSTRSRC_TOT_COLMN       (sizeof(gSysStRsrcDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO SYS_ST_RSRC "
"(SYS_ST_ID,RSRC_ID,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:sys_st_id,:rsrc_id,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM SYS_ST_RSRC ";
static char gSqlSelect[] = "SELECT SYS_ST_ID,RSRC_ID,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM SYS_ST_RSRC ";

static char gSqlCountBySysStIdAndRsrcId[] = "SELECT COUNT(1) FROM SYS_ST_RSRC WHERE SYS_ST_ID = %d AND RSRC_ID = %d ";


static DbColInfoT gSysStRsrcDbInfo[] = 
{
    {"SYS_ST_ID",    ":sys_st_id",    offsetof(SysStRsrc, sysStId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"RSRC_ID",    ":rsrc_id",    offsetof(SysStRsrc, rsrcId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(SysStRsrc, crtTm),    offsetof(SysStRsrc, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(SysStRsrc, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(SysStRsrc, updTm),    offsetof(SysStRsrc, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(SysStRsrc, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gSysStRsrcDbCntInfo[] =
{
    {"",                 ":count",           offsetof(SysStRsrcCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( SysStRsrc* pData );
ResCodeT FreeDateTimeType( SysStRsrc* pData );
ResCodeT SelectSysStRsrc(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertSysStRsrc(int32 connId, SysStRsrc* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertSysStRsrc" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gSysStRsrcDbInfo,
                            DB_SYSSTRSRC_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateSysStRsrcByKey(int32 connId, SysStRsrc* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateSysStRsrcByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_SYSSTRSRC_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gSysStRsrcDbInfo[keyIdx].colFlag,
                                    gSysStRsrcDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE SYS_ST_RSRC SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_SYSSTRSRC_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gSysStRsrcDbInfo[colIdx].colFlag,
                                    gSysStRsrcDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gSysStRsrcDbInfo, 
                    DB_SYSSTRSRC_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT GetResultCntBySysStIdAndRsrcId( int32 connId, int32 iSysStId, int32 RsrcId, int32* pCntOut )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntBySysStIdAndRsrcId" );

    char inputSql[DB_COMM_SQL_TOT_LEN];

    int32               stmtId;
    SysStRsrcCntT       SysStRsrcCnt = {0};
    SysStRsrcCntT*      pSysStRsrcCnt = &SysStRsrcCnt;

    memset(inputSql, 0x00, DB_COMM_SQL_TOT_LEN);
    sprintf(inputSql, gSqlCountBySysStIdAndRsrcId, iSysStId, RsrcId);

    rc = DbCmmnPrprSql( connId, inputSql, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_SYSSTRSRC_CNT_NUM,
                        gSysStRsrcDbCntInfo, (void *) pCntOut );
    RAISE_ERR(rc, RTN);

    *pCntOut = SysStRsrcCnt.count;


    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT GetResultCntOfSysStRsrc(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfSysStRsrc" );

    int32       stmtId;
    SysStRsrcCntT    SysStRsrcCnt = {0};
    SysStRsrcCntT *  pSysStRsrcCnt = &SysStRsrcCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_SYSSTRSRC_CNT_NUM,
                        gSysStRsrcDbCntInfo, (void *) pSysStRsrcCnt );
    RAISE_ERR(rc, RTN);

    *pCntOut = SysStRsrcCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextSysStRsrc( BOOL * pFrstFlag, int32 connId, SysStRsrc* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextSysStRsrc" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectSysStRsrc(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_SYSSTRSRC_TOT_COLMN, 
                            gSysStRsrcDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectSysStRsrc(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
BEGIN_FUNCTION( "SelectSysStRsrc" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( SysStRsrc* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( SysStRsrc* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
