/***
Created on sometimes
@author: No One
@version $ID
***/

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Standard C hearder files   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Project Header Files */
#include "data_type.h"
#include "err_lib.h"
#include "common_macro.h"
#include "OrgMktPrvlgDb.h"
#include "bit_lib.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
************************************************************************************************/
/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DB_ORGMKTPRVLG_CNT_NUM         1

#define DB_ORGMKTPRVLG_TOT_COLMN       (sizeof(gOrgMktPrvlgDbInfo) / sizeof(DbColInfoT))
#define DB_COMM_SQL_KEY_LEN     200
#define DB_COMM_SQL_TOT_LEN     1000

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/
static char gSqlInsert[] = "INSERT INTO ORG_MKT_PRVLG "
"(ORG_MKT_PRVLG_SRNO,ORG_ID,MKT_TP,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM) VALUES "
"(:org_mkt_prvlg_srno,:org_id,:mkt_tp,:st,:crt_tm,:crt_usr_nm,:upd_tm,:upd_usr_nm) ";
static char gSqlSelectCount[] = "SELECT COUNT(*) FROM ORG_MKT_PRVLG ";
static char gSqlSelect[] = "SELECT ORG_MKT_PRVLG_SRNO,ORG_ID,MKT_TP,ST,CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM FROM ORG_MKT_PRVLG ";
static DbColInfoT gOrgMktPrvlgDbInfo[] = 
{
    {"ORG_MKT_PRVLG_SRNO",    ":org_mkt_prvlg_srno",    offsetof(OrgMktPrvlg, orgMktPrvlgSrno),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"ORG_ID",    ":org_id",    offsetof(OrgMktPrvlg, orgId),    0,    DB_COL_INT32,    sizeof(int32),  0 },
    {"MKT_TP",    ":mkt_tp",    offsetof(OrgMktPrvlg, mktTp),    0,    DB_COL_STRING,    8,  0 },
    {"ST",    ":st",    offsetof(OrgMktPrvlg, st),    0,    DB_COL_STRING,    8,  0 },
    {"CRT_TM",    ":crt_tm",    offsetof(OrgMktPrvlg, crtTm),    offsetof(OrgMktPrvlg, pCrtTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"CRT_USR_NM",    ":crt_usr_nm",    offsetof(OrgMktPrvlg, crtUsrNm),    0,    DB_COL_STRING,    100,  0 },
    {"UPD_TM",    ":upd_tm",    offsetof(OrgMktPrvlg, updTm),    offsetof(OrgMktPrvlg, pUpdTm),    DB_COL_TIMESTAMP,    50,  0 },
    {"UPD_USR_NM",    ":upd_usr_nm",    offsetof(OrgMktPrvlg, updUsrNm),    0,    DB_COL_STRING,    100,  0 },
};

static DbColInfoT gOrgMktPrvlgDbCntInfo[] =
{
    {"",                 ":count",           offsetof(OrgMktPrvlgCntT, count),    0,    DB_COL_INT32,     sizeof(int32),  0},
};

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/

ResCodeT FmtDateTimeType( OrgMktPrvlg* pData );
ResCodeT FreeDateTimeType( OrgMktPrvlg* pData );
ResCodeT SelectOrgMktPrvlg(int32 connId, int32 * pStmntId);
/***********************************************************************************************
**
**   Function Implementation                                                                           
**
************************************************************************************************/

ResCodeT InsertOrgMktPrvlg(int32 connId, OrgMktPrvlg* pData)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "InsertOrgMktPrvlg" );

    int32   stmtId;

    rc = DbCmmnPrprSql( connId, gSqlInsert, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    /* Bind all values */
    rc = DbCmmnExcBindAllVal( connId, stmtId, gOrgMktPrvlgDbInfo,
                            DB_ORGMKTPRVLG_TOT_COLMN, (void *)pData );
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT UpdateOrgMktPrvlgByKey(int32 connId, OrgMktPrvlg* pData, vectorT * pKeyFlg, vectorT * pColFlg )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION("UpdateOrgMktPrvlgByKey");

    int32   stmtId;
    int32   keyIdx = -1;
    int32   colIdx = -1;

    char keySql[DB_COMM_SQL_KEY_LEN];
    char updateSql[DB_COMM_SQL_TOT_LEN];

    memset( keySql, 0x00, sizeof(keySql) );
    strcpy( keySql, "WHERE " );
    while ( TRUE )
    {
        BitFindFS(pKeyFlg, keyIdx + 1, DB_ORGMKTPRVLG_TOT_COLMN, &keyIdx);
        if (keyIdx == -1)
        {
            keySql[strlen(keySql)-sizeof("AND")] = 0x00;
            break;
        }

        sprintf( keySql, "%s %s = %s AND", 
                                    keySql,
                                    gOrgMktPrvlgDbInfo[keyIdx].colFlag,
                                    gOrgMktPrvlgDbInfo[keyIdx].colName );
    }

    memset( updateSql, 0x00, sizeof(updateSql) );
    strcpy( updateSql, "UPDATE ORG_MKT_PRVLG SET " );

    while ( TRUE )
    {
        BitFindFS(pColFlg, colIdx + 1, DB_ORGMKTPRVLG_TOT_COLMN, &colIdx);
        if (colIdx == -1)
        {
            updateSql[strlen(updateSql)-1] = 0x00;
            sprintf( updateSql, "%s %s", updateSql, keySql );
            break;
        }

        sprintf( updateSql, "%s %s = %s,", 
                                    updateSql,
                                    gOrgMktPrvlgDbInfo[colIdx].colFlag,
                                    gOrgMktPrvlgDbInfo[colIdx].colName );
    }

    rc = DbCmmnPrprSql( connId, updateSql, &stmtId );
    RAISE_ERR(rc, RTN);

    /* Format date or timestamp type */
    rc = FmtDateTimeType( pData );
    RAISE_ERR(rc, RTN);
    /* Merge Vector bit flag */
    *pColFlg = (*pColFlg) | (*pKeyFlg);

    /* Bind all values */
    rc = DbCmmnExcBindVal( connId, stmtId, gOrgMktPrvlgDbInfo, 
                    DB_ORGMKTPRVLG_TOT_COLMN, pColFlg, (void *) pData);
    RAISE_ERR(rc, RTN);

    /* Excute sql */
    rc = DbCmmnExcSqlNoRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    /* Free date and timestamp type mem */
    rc = FreeDateTimeType( pData );
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT GetResultCntOfOrgMktPrvlg(int32 connId, int32* pCntOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "GetResultCntOfOrgMktPrvlg" );

    int32       stmtId;
    OrgMktPrvlgCntT    OrgMktPrvlgCnt = {0};
    OrgMktPrvlgCntT *  pOrgMktPrvlgCnt = &OrgMktPrvlgCnt;

    rc = DbCmmnPrprSql( connId, gSqlSelectCount, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFetchNext( connId, stmtId, DB_ORGMKTPRVLG_CNT_NUM,
                        gOrgMktPrvlgDbCntInfo, (void *) pOrgMktPrvlgCnt );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeStmnt( stmtId );
    RAISE_ERR(rc, RTN);

    *pCntOut = OrgMktPrvlgCnt.count;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FetchNextOrgMktPrvlg( BOOL * pFrstFlag, int32 connId, OrgMktPrvlg* pDataOut)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FetchNextOrgMktPrvlg" );

    static int32 stmntId;

    if ( * pFrstFlag )
    {
        rc = SelectOrgMktPrvlg(connId, &stmntId);
        RAISE_ERR(rc, RTN);

        * pFrstFlag = FALSE;
    }

    rc = DbCmmnFetchNext( connId, stmntId, DB_ORGMKTPRVLG_TOT_COLMN, 
                            gOrgMktPrvlgDbInfo, (void *) pDataOut );
    if ( rc == ERR_DB_OCI_END_OF_RESULTSET_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        THROW_RESCODE(ERR_DB_COMMON_FETCH_END);
    }
    if ( rc != NO_ERR )
    {
        DbCmmnFreeStmnt( stmntId );
        RAISE_ERR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SelectOrgMktPrvlg(int32 connId, int32 * pStmntId)
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "SelectOrgMktPrvlg" );

    int32 stmtId;

    rc = DbCmmnPrprSql( connId, gSqlSelect, &stmtId );
    RAISE_ERR(rc, RTN);

    rc = DbCmmnExcSqlWithRslt( connId, stmtId );
    RAISE_ERR(rc, RTN);

    *pStmntId = stmtId;

    EXIT_BLOCK();
    RETURN_RESCODE;
}



ResCodeT FmtDateTimeType( OrgMktPrvlg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FmtDateTimeType" );

    rc = DbCmmnFmtTimestampType( pData->crtTm, &pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFmtTimestampType( pData->updTm, &pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT FreeDateTimeType( OrgMktPrvlg* pData )
{
    ResCodeT rc = NO_ERR;
    BEGIN_FUNCTION( "FreeDateTimeType" );

    rc = DbCmmnFreeTimestampType( pData->pCrtTm);
    RAISE_ERR(rc, RTN);

    rc = DbCmmnFreeTimestampType( pData->pUpdTm);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;
}
