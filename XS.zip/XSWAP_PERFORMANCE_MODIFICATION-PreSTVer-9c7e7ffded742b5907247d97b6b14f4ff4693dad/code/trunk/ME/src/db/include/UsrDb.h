/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _USR_DB_
#define _USR_DB_

/***********************************************************************************************
**
**   Header Files
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure
**
************************************************************************************************/
typedef struct UsrDbS {
    int32  usrSrno;
    char  usrLgnNm[100];
    int32  orgId;
    char  nmDesc[300];
    char  usrSt[8];
    char  pswd[300];
    char  pswdTm[50];
    DbTimestampTypeT *  pPswdTm;
    int32  pswdErCnt;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  sysSrc[8];
    char  tel[100];
    char  faxNo[100];
    char  apiF[8];
    char  ordrPrvlgF[8];
    char  ordrPrvlgMdfyF[8];
    char  ordrPrvlgFSirs[8];
    char  ordrPrvlgMdfyFSirs[8];
    char  ordrPrvlgFSbfccp[8];
    char  ordrPrvlgMdfyFSbfccp[8];
} Usr;


typedef struct recUsrJoin {
    int32  usrSrno;
    char  usrLgnNm[100];
    int32  orgId;
    char  nmDesc[100];
    char  usrSt[8];
    char  pswd[300];
    char  pswdTm[50];
    int32  pswdErCnt;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  sysSrc[8];
    char  tel[100];
    char  faxNo[100];
    char  apiF[8];
    char  ordrPrvlgF[8];
    char  ordrPrvlgMdfyF[8];
    char  ordrPrvlgFSirs[8];
    char  ordrPrvlgMdfyFSirs[8];
    char  ordrPrvlgFSbfccp[8];
    char  ordrPrvlgMdfyFSbfccp[8];
    BOOL usrOnlnStatus;
    char roleId[10];
    char    sesnId[100];
    int32    lgnTp;
    char    lgnTm[30];
    DbTimestampTypeT *  pLgnTm;
    char    mktTp[10];
    char    mktSt[10];

} UsrJoin;

typedef struct UsrOnlnJnS {
    int32  orgId;
    char  usrLgnNm[100];
}UsrOnlnJnT;

typedef struct UsrCntS {
    int32  count;
} UsrCntT;

typedef struct UsrLgnNmS {
    char  usrLgnNm[100];
} UsrLgnNmT;


typedef struct recUsrKey{
    int32 usrSrno;
}UsrKey;


typedef struct recUsrKeyList{
    int32 keyRow;
    int32* usrSrnoLst;
}UsrKeyLst;
/***********************************************************************************************
**
**   Global Variable
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration
**
************************************************************************************************/
//Insert Method
ResCodeT InsertUsr(int32 connId, Usr* pData);
//ResCodeT UpdateUsrByKey(int32 connId, UsrKey* pKey, Usr* pData, UsrUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertUsr(int32 connId, UsrMulti* pData);
////Update Method
ResCodeT UpdateUsrByKey(int32 connId, Usr* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateUsrByKey(int32 connId, UsrKeyLst* pKeyList, UsrMulti* pData, UsrUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfUsr(int32 connId, int32* pCntOut);
ResCodeT FetchNextUsr( BOOL * pFrstFlag, int32 connId, Usr* pDataOut);

ResCodeT FetchNextUsrJoin( BOOL * pFrstFlag, int32 connId, UsrJoin* pDataOut);

ResCodeT GetResultCntOfOtherApiUsrOnln( int32 connId, int32 iOrgId, char* strUserId, int32* pCntOut );

ResCodeT GetResultCntOfUsrOnln( int32 connId, char* strRemoveId, int32* pCntOut );
ResCodeT FetchNextUsrOnlnJn( BOOL * pFrstFlag, int32 connId, char* strRemoveId, UsrOnlnJnT* pDataOut);

// lidongwei add
ResCodeT GetResultCntOfUsrWithOrgId(int32 connId, int32 orgId, int32* pCntOut);
ResCodeT FetchNextUsrWithOrgId( BOOL *pFrstFlag, int32 connId, int32 orgId, char* pDataOut);
// lidongwei end


ResCodeT DeleteUsr(int32 connId, UsrKey* pKey);
////Delete Method
//ResCodeT DeleteAllUsr(int32 connId);
//ResCodeT DeleteUsr(int32 connId, UsrKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _USR_DB_ */
