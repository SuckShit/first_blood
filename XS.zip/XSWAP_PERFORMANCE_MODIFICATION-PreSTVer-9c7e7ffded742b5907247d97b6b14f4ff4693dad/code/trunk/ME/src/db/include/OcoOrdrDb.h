/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _OCO_ORDR_DB_
#define _OCO_ORDR_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define OCO_ORDR_OCO_ID_IDX     0
#define OCO_ORDR_CLNT_SRNO_IDX     1
#define OCO_ORDR_ST_IDX     2
#define OCO_ORDR_TRDR_NM_IDX     3
#define OCO_ORDR_CRT_TM_IDX     4
#define OCO_ORDR_CRT_USR_NM_IDX     5
#define OCO_ORDR_UPD_TM_IDX     6
#define OCO_ORDR_UPD_USR_NM_IDX     7

#define OCO_ORDR_VECT_LEN     GET_BIT_VECT_LEN(7)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OcoOrdrDbS {
    char  ocoId[50];
    char  clntSrno[50];
    char  st[8];
    char  trdrNm[100];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} OcoOrdr;

typedef struct OcoOrdrCntS {
    int32  count;
} OcoOrdrCntT;


typedef struct recOcoOrdrKey{
    char ocoId[50];
}OcoOrdrKey;


typedef struct recOcoOrdrKeyList{
    int32 keyRow;
    char** ocoIdLst;
}OcoOrdrKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOcoOrdr(int32 connId, OcoOrdr* pData);
//ResCodeT UpdateOcoOrdrByKey(int32 connId, OcoOrdrKey* pKey, OcoOrdr* pData, OcoOrdrUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOcoOrdr(int32 connId, OcoOrdrMulti* pData);
////Update Method
ResCodeT UpdateOcoOrdrByKey(int32 connId, OcoOrdr* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateOcoOrdrByKey(int32 connId, OcoOrdrKeyLst* pKeyList, OcoOrdrMulti* pData, OcoOrdrUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOcoOrdr(int32 connId, int32* pCntOut);
ResCodeT FetchNextOcoOrdr( BOOL * pFrstFlag, int32 connId, OcoOrdr* pDataOut);
////Delete Method
//ResCodeT DeleteAllOcoOrdr(int32 connId);
//ResCodeT DeleteOcoOrdr(int32 connId, OcoOrdrKey* pKey);
ResCodeT FetchOcoOrdrByKey( int32 connId, char * pKey, BOOL * pFetchFlag );
#ifdef _cplusplus
}
#endif

#endif /* _OCO_ORDR_DB_ */
