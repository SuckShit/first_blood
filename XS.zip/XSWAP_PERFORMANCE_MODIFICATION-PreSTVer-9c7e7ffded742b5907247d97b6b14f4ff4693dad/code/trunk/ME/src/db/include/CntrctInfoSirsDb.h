/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _cntrct_info_sirs_DB_
#define _cntrct_info_sirs_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define cntrct_info_sirs_CNTRCT_INFO_SRNO_IDX     0
#define cntrct_info_sirs_CNTRCT_CD_IDX     1
#define cntrct_info_sirs_CNTRCT_NM_EN_IDX     2
#define cntrct_info_sirs_CNTRCT_NM_CN_IDX     3
#define cntrct_info_sirs_CNTRCT_MTH_IDX     4
#define cntrct_info_sirs_TERM_IDX     5
#define cntrct_info_sirs_DL_PRC_UNIT_IDX     6
#define cntrct_info_sirs_AMNT_PER_UNIT_IDX     7
#define cntrct_info_sirs_MIN_AMNT_PER_DL_IDX     8
#define cntrct_info_sirs_MAX_AMNT_PER_DL_IDX     9
#define cntrct_info_sirs_DLVRY_DT_IDX     10
#define cntrct_info_sirs_ACTV_DT_IDX     11
#define cntrct_info_sirs_EXPRD_DT_IDX     12
#define cntrct_info_sirs_EMGCY_F_IDX     13
#define cntrct_info_sirs_ST_IDX     14
#define cntrct_info_sirs_INTRST_STRT_DT_IDX     15
#define cntrct_info_sirs_INTRST_END_DT_IDX     16
#define cntrct_info_sirs_INTRST_DT_IDX     17
#define cntrct_info_sirs_FRST_INTRST_DT_IDX     18
#define cntrct_info_sirs_CALC_ORG_IDX     19
#define cntrct_info_sirs_STLE_TP_IDX     20
#define cntrct_info_sirs_BNCHMK_RATE_IDX     21
#define cntrct_info_sirs_TRDNG_END_TM_IDX     22
#define cntrct_info_sirs_INTRST_DAYS_ADJ_IDX     23
#define cntrct_info_sirs_PYMNT_DT_ADJ_IDX     24
#define cntrct_info_sirs_FXD_INTRST_BID_DLVRY_DT_IDX     25
#define cntrct_info_sirs_FXD_INTRST_BID_PYMNT_PRD_IDX     26
#define cntrct_info_sirs_FXD_INTRST_BID_INTRST_BNCHMK_IDX     27
#define cntrct_info_sirs_FXD_INTRST_BID_INTRST_TP_IDX     28
#define cntrct_info_sirs_REF_CNTRCT_IDX     29
#define cntrct_info_sirs_FXD_INTRST_OFR_DLVRY_DAY_IDX     30
#define cntrct_info_sirs_FRST_INTRST_CNFRM_DT_IDX     31
#define cntrct_info_sirs_INTRST_TP_IDX     32
#define cntrct_info_sirs_INTRST_SPRD_IDX     33
#define cntrct_info_sirs_FXD_INTRST_OFR_PYMNT_PRD_IDX     34
#define cntrct_info_sirs_RST_RATE_IDX     35
#define cntrct_info_sirs_FXD_INTRST_OFR_INTRST_BNCHMK_IDX     36
#define cntrct_info_sirs_MKT_TP_IDX     37
#define cntrct_info_sirs_CRT_TM_IDX     38
#define cntrct_info_sirs_CRT_USR_NM_IDX     39
#define cntrct_info_sirs_UPD_TM_IDX     40
#define cntrct_info_sirs_UPD_USR_NM_IDX     41
#define cntrct_info_sirs_CNTRCT_FACE_VL_IDX     42

#define cntrct_info_sirs_VECT_LEN     GET_BIT_VECT_LEN(42)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctInfoSirsDbS {
    int32  cntrctInfoSrno;
    char  cntrctCd[50];
    char  cntrctNmEn[100];
    char  cntrctNmCn[300];
    char  cntrctMth[50];
    int32  term;
    char  dlPrcUnit[8];
    double  amntPerUnit;
    int32  minAmntPerDl;
    int32  maxAmntPerDl;
    char  dlvryDt[50];
    DbDateTypeT *  pDlvryDt;
    char  actvDt[50];
    DbDateTypeT *  pActvDt;
    char  exprdDt[50];
    DbDateTypeT *  pExprdDt;
    char  emgcyF[8];
    char  st[8];
    char  intrstStrtDt[50];
    DbDateTypeT *  pIntrstStrtDt;
    char  intrstEndDt[50];
    DbDateTypeT *  pIntrstEndDt;
    char  intrstDt[50];
    DbDateTypeT *  pIntrstDt;
    char  frstIntrstDt[50];
    DbDateTypeT *  pFrstIntrstDt;
    char  calcOrg[300];
    char  stleTp[8];
    double  bnchmkRate;
    char  trdngEndTm[50];
    char  intrstDaysAdj[8];
    char  pymntDtAdj[8];
    char  fxdIntrstBidDlvryDt[50];
    DbDateTypeT *  pFxdIntrstBidDlvryDt;
    char  fxdIntrstBidPymntPrd[8];
    char  fxdIntrstBidIntrstBnchmk[8];
    char  fxdIntrstBidIntrstTp[8];
    char  refCntrct[50];
    char  fxdIntrstOfrDlvryDay[50];
    DbDateTypeT *  pFxdIntrstOfrDlvryDay;
    char  frstIntrstCnfrmDt[50];
    DbDateTypeT *  pFrstIntrstCnfrmDt;
    char  intrstTp[8];
    double  intrstSprd;
    char  fxdIntrstOfrPymntPrd[8];
    char  rstRate[8];
    char  fxdIntrstOfrIntrstBnchmk[8];
    char  mktTp[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    double  cntrctFaceVl;
} CntrctInfoSirs;

typedef struct CntrctInfoSirsCntS {
    int32  count;
} CntrctInfoSirsCntT;


typedef struct recCntrctInfoSirsKey{
    int32 cntrctInfoSrno;
}CntrctInfoSirsKey;


typedef struct recCntrctInfoSirsKeyList{
    int32 keyRow;
    int32* cntrctInfoSrnoLst;
}CntrctInfoSirsKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctInfoSirs(int32 connId, CntrctInfoSirs* pData);
//ResCodeT UpdateCntrctInfoSirsByKey(int32 connId, CntrctInfoSirsKey* pKey, CntrctInfoSirs* pData, CntrctInfoSirsUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctInfoSirs(int32 connId, CntrctInfoSirsMulti* pData);
////Update Method
ResCodeT UpdateCntrctInfoSirsByKey(int32 connId, CntrctInfoSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctInfoSirsByKey(int32 connId, CntrctInfoSirsKeyLst* pKeyList, CntrctInfoSirsMulti* pData, CntrctInfoSirsUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctInfoSirs(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctInfoSirs( BOOL * pFrstFlag, int32 connId, CntrctInfoSirs* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctInfoSirs(int32 connId);
//ResCodeT DeleteCntrctInfoSirs(int32 connId, CntrctInfoSirsKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _cntrct_info_sirs_DB_ */
