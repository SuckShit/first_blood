/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _IMIX_MSG_OUT_DB_
#define _IMIX_MSG_OUT_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct ImixMsgOutDbS {
    int32  srcImixCd;
    char  msgF[8];
    char  msg[4000];
    char  msgTm[50];
    DbTimestampTypeT *  pMsgTm;
} ImixMsgOut;

typedef struct ImixMsgOutCntS {
    int32  count;
} ImixMsgOutCntT;


typedef struct recImixMsgOutKey{
    int32 srcImixCd;
}ImixMsgOutKey;


typedef struct recImixMsgOutKeyList{
    int32 keyRow;
    int32* srcImixCdLst;
}ImixMsgOutKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertImixMsgOut(int32 connId, ImixMsgOut* pData);
//ResCodeT UpdateImixMsgOutByKey(int32 connId, ImixMsgOutKey* pKey, ImixMsgOut* pData, ImixMsgOutUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertImixMsgOut(int32 connId, ImixMsgOutMulti* pData);
////Update Method
ResCodeT UpdateImixMsgOutByKey(int32 connId, ImixMsgOut* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateImixMsgOutByKey(int32 connId, ImixMsgOutKeyLst* pKeyList, ImixMsgOutMulti* pData, ImixMsgOutUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfImixMsgOut(int32 connId, int32* pCntOut);
ResCodeT FetchNextImixMsgOut( BOOL * pFrstFlag, int32 connId, ImixMsgOut* pDataOut);
////Delete Method
//ResCodeT DeleteAllImixMsgOut(int32 connId);
//ResCodeT DeleteImixMsgOut(int32 connId, ImixMsgOutKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _IMIX_MSG_OUT_DB_ */
