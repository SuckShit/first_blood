/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _USR_MKT_PRVLG_DB_
#define _USR_MKT_PRVLG_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define USR_MKT_PRVLG_USR_MKT_PRVLG_SRNO_IDX     0
#define USR_MKT_PRVLG_USR_LGN_NM_IDX     1
#define USR_MKT_PRVLG_MKT_TP_IDX     2
#define USR_MKT_PRVLG_ST_IDX     3
#define USR_MKT_PRVLG_CRT_TM_IDX     4
#define USR_MKT_PRVLG_CRT_USR_NM_IDX     5
#define USR_MKT_PRVLG_UPD_TM_IDX     6
#define USR_MKT_PRVLG_UPD_USR_NM_IDX     7

#define USR_MKT_PRVLG_VECT_LEN     GET_BIT_VECT_LEN(7)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct UsrMktPrvlgDbS {
    int32  usrMktPrvlgSrno;
    char  usrLgnNm[100];
    char  mktTp[8];
    char  st[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} UsrMktPrvlg;

typedef struct UsrMktPrvlgCntS {
    int32  count;
} UsrMktPrvlgCntT;


typedef struct recUsrMktPrvlgKey{
    int32 usrMktPrvlgSrno;
}UsrMktPrvlgKey;


typedef struct recUsrMktPrvlgKeyList{
    int32 keyRow;
    int32* usrMktPrvlgSrnoLst;
}UsrMktPrvlgKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertUsrMktPrvlg(int32 connId, UsrMktPrvlg* pData);
//ResCodeT UpdateUsrMktPrvlgByKey(int32 connId, UsrMktPrvlgKey* pKey, UsrMktPrvlg* pData, UsrMktPrvlgUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertUsrMktPrvlg(int32 connId, UsrMktPrvlgMulti* pData);
////Update Method
ResCodeT UpdateUsrMktPrvlgByKey(int32 connId, UsrMktPrvlg* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateUsrMktPrvlgByKey(int32 connId, UsrMktPrvlgKeyLst* pKeyList, UsrMktPrvlgMulti* pData, UsrMktPrvlgUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfUsrMktPrvlg(int32 connId, int32* pCntOut);
ResCodeT FetchNextUsrMktPrvlg( BOOL * pFrstFlag, int32 connId, UsrMktPrvlg* pDataOut);
////Delete Method
//ResCodeT DeleteAllUsrMktPrvlg(int32 connId);
//ResCodeT DeleteUsrMktPrvlg(int32 connId, UsrMktPrvlgKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _USR_MKT_PRVLG_DB_ */
