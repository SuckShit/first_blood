/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CRDT_DB_
#define _CRDT_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CrdtDbS {
    int32   crdtId;
    int32   crdtOrgId;
    int32   crdtdOrgId;
    double  intlCrdtAmnt;
    char    mktId[8];
    char    crdtRlF[8];
    double  usedCrdtAmnt;
    double  rmnCrdtAmnt;
    int32   crdtTerm;
    char    st[8];
    char    crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char    crtUsrNm[100];
    char    updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char    updUsrNm[100];
    char    usrUpdTm[50];
    DbTimestampTypeT *  pUsrUpdTm;
} Crdt;

typedef struct CrdtCntS {
    int32  count;
} CrdtCntT;


typedef struct recCrdtKey{
    int32 crdtId;
}CrdtKey;


typedef struct recCrdtKeyList{
    int32 keyRow;
    int32* crdtIdLst;
}CrdtKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCrdt(int32 connId, Crdt* pData);
//ResCodeT UpdateCrdtByKey(int32 connId, CrdtKey* pKey, Crdt* pData, CrdtUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCrdt(int32 connId, CrdtMulti* pData);
////Update Method
ResCodeT UpdateCrdtByKey(int32 connId, Crdt* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCrdtByKey(int32 connId, CrdtKeyLst* pKeyList, CrdtMulti* pData, CrdtUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCrdt(int32 connId, int32* pCntOut);
ResCodeT GetResultCntOfCrdtByKeyRL(int32 connId, Crdt* pData, vectorT *pKeyFlg, int32* pCntOut);
ResCodeT GetResultCntOfCrdtByKeyAmnt(int32 connId, Crdt* pData, vectorT *pKeyFlg, int32* pCntOut);
ResCodeT FetchNextCrdt( BOOL * pFrstFlag, int32 connId, Crdt* pDataOut);
ResCodeT FetchNextCrdtBySt(BOOL* pFrstFlag, int32 connId, Crdt* pDataOut);
////Delete Method
//ResCodeT DeleteAllCrdt(int32 connId);
//ResCodeT DeleteCrdt(int32 connId, CrdtKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CRDT_DB_ */
