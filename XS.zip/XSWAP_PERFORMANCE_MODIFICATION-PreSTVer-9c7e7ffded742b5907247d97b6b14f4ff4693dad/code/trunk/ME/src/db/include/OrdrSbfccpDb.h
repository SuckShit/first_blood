/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ORDR_SBFCCP_DB_
#define _ORDR_SBFCCP_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define ORDR_SBFCCP_ORDR_ID_IDX     0
#define ORDR_SBFCCP_ORG_ID_IDX     1
#define ORDR_SBFCCP_ORDR_SBMT_TP_IDX     2
#define ORDR_SBFCCP_ORDR_TP_IDX     3
#define ORDR_SBFCCP_OCO_ID_IDX     4
#define ORDR_SBFCCP_CNTRCT_CD_IDX     5
#define ORDR_SBFCCP_NTNL_AMNT_IDX     6
#define ORDR_SBFCCP_RMNG_NTNL_AMNT_IDX     7
#define ORDR_SBFCCP_ORDR_PRC_IDX     8
#define ORDR_SBFCCP_ORDR_AMNT_IDX     9
#define ORDR_SBFCCP_DL_DIR_IDX     10
#define ORDR_SBFCCP_ST_IDX     11
#define ORDR_SBFCCP_TRDR_NM_IDX     12
#define ORDR_SBFCCP_ORDR_CRT_TM_IDX     13
#define ORDR_SBFCCP_ORDR_EXPRD_TM_IDX     14
#define ORDR_SBFCCP_ORDR_ACTV_TM_IDX     15
#define ORDR_SBFCCP_UPD_TM_IDX     16
#define ORDR_SBFCCP_UPD_USR_NM_IDX     17
#define ORDR_SBFCCP_ORG_FULL_NM_CN_IDX     18
#define ORDR_SBFCCP_ORG_CD_IDX     19
#define ORDR_SBFCCP_CLS_PSTN_CD_IDX     20
#define ORDR_SBFCCP_RQST_ID_IDX     21
#define ORDR_SBFCCP_USR_LGN_NM_API_IDX     22

#define ORDR_SBFCCP_VECT_LEN     GET_BIT_VECT_LEN(22)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OrdrSbfccpDbS {
    char  ordrId[50];
    int32  orgId;
    char  ordrSbmtTp[8];
    char  ordrTp[8];
    char  ocoId[50];
    char  cntrctCd[50];
    double  ntnlAmnt;
    double  rmngNtnlAmnt;
    double  ordrPrc;
    double  ordrAmnt;
    char  dlDir[8];
    char  st[8];
    char  trdrNm[100];
    char  ordrCrtTm[50];
    DbTimestampTypeT *  pOrdrCrtTm;
    char  ordrExprdTm[50];
    DbDateTypeT *  pOrdrExprdTm;
    char  ordrActvTm[50];
    DbTimestampTypeT *  pOrdrActvTm;
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  orgFullNmCn[300];
    char  orgCd[50];
    char  clsPstnCd[50];
    char  rqstId[50];
    char  usrLgnNmApi[100];
} OrdrSbfccp;

typedef struct OrdrSbfccpCntS {
    int32  count;
} OrdrSbfccpCntT;


typedef struct recOrdrSbfccpKey{
    char ordrId[50];
}OrdrSbfccpKey;


typedef struct recOrdrSbfccpKeyList{
    int32 keyRow;
    char** ordrIdLst;
}OrdrSbfccpKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOrdrSbfccp(int32 connId, OrdrSbfccp* pData);
//ResCodeT UpdateOrdrSbfccpByKey(int32 connId, OrdrSbfccpKey* pKey, OrdrSbfccp* pData, OrdrSbfccpUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOrdrSbfccp(int32 connId, OrdrSbfccpMulti* pData);
////Update Method
ResCodeT UpdateOrdrSbfccpByKey(int32 connId, OrdrSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateOrdrSbfccpByKey(int32 connId, OrdrSbfccpKeyLst* pKeyList, OrdrSbfccpMulti* pData, OrdrSbfccpUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOrdrSbfccp(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrdrSbfccp( BOOL * pFrstFlag, int32 connId, OrdrSbfccp* pDataOut);
////Delete Method
//ResCodeT DeleteAllOrdrSbfccp(int32 connId);
//ResCodeT DeleteOrdrSbfccp(int32 connId, OrdrSbfccpKey* pKey);
ResCodeT FetchOrdrSbfccpByKey( int32 connId, char * pKey, BOOL * pFetchFlag );
ResCodeT UpdateCancleOrdrSbfccp( int32 connId, OrdrSbfccp* pData );
#ifdef _cplusplus
}
#endif

#endif /* _ORDR_SBFCCP_DB_ */
