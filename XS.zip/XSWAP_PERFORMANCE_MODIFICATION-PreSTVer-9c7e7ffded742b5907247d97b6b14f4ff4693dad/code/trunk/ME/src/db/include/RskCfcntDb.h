/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _RSK_CFCNT_DB_
#define _RSK_CFCNT_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct RskCfcntDbS {
    int32  rskCfcntId;
    int32  orgId;
    char  cntrctNm[50];
    double  rskCfcntVl;
    char  st[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} RskCfcnt;

typedef struct RskCfcntCntS {
    int32  count;
} RskCfcntCntT;


typedef struct recRskCfcntKey{
    int32 rskCfcntId;
}RskCfcntKey;


typedef struct recRskCfcntKeyList{
    int32 keyRow;
    int32* rskCfcntIdLst;
}RskCfcntKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertRskCfcnt(int32 connId, RskCfcnt* pData);
//ResCodeT UpdateRskCfcntByKey(int32 connId, RskCfcntKey* pKey, RskCfcnt* pData, RskCfcntUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertRskCfcnt(int32 connId, RskCfcntMulti* pData);
////Update Method
ResCodeT UpdateRskCfcntByKey(int32 connId, RskCfcnt* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateRskCfcntByKey(int32 connId, RskCfcntKeyLst* pKeyList, RskCfcntMulti* pData, RskCfcntUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfRskCfcnt(int32 connId, int32* pCntOut);
ResCodeT FetchNextRskCfcnt( BOOL * pFrstFlag, int32 connId, RskCfcnt* pDataOut);
////Delete Method
//ResCodeT DeleteAllRskCfcnt(int32 connId);
//ResCodeT DeleteRskCfcnt(int32 connId, RskCfcntKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _RSK_CFCNT_DB_ */
