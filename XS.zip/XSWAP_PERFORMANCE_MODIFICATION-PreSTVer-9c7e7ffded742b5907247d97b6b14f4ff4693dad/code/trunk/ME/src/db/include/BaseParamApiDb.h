/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _BASE_PARAM_API_DB_
#define _BASE_PARAM_API_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define BASE_PARAM_API_BASE_PARAM_ID_IDX     0
#define BASE_PARAM_API_PARAM_NM_IDX     1
#define BASE_PARAM_API_PARAM_VL_IDX     2
#define BASE_PARAM_API_PARAM_NEXT_VL_IDX     3
#define BASE_PARAM_API_MDFY_ST_IDX     4
#define BASE_PARAM_API_PARAM_DESC_IDX     5
#define BASE_PARAM_API_CRT_TM_IDX     6
#define BASE_PARAM_API_CRT_USR_NM_IDX     7
#define BASE_PARAM_API_UPD_TM_IDX     8
#define BASE_PARAM_API_UPD_USR_NM_IDX     9

#define BASE_PARAM_API_VECT_LEN     GET_BIT_VECT_LEN(9)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct BaseParamApiDbS {
    int32  baseParamId;
    char  paramNm[100];
    char  paramVl[100];
    char  paramNextVl[100];
    char  mdfySt[8];
    char  paramDesc[300];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[300];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[300];
} BaseParamApi;

typedef struct BaseParamApiCntS {
    int32  count;
} BaseParamApiCntT;


typedef struct recBaseParamApiKey{
    int32 baseParamId;
}BaseParamApiKey;


typedef struct recBaseParamApiKeyList{
    int32 keyRow;
    int32* baseParamIdLst;
}BaseParamApiKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertBaseParamApi(int32 connId, BaseParamApi* pData);
//ResCodeT UpdateBaseParamApiByKey(int32 connId, BaseParamApiKey* pKey, BaseParamApi* pData, BaseParamApiUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertBaseParamApi(int32 connId, BaseParamApiMulti* pData);
////Update Method
ResCodeT UpdateBaseParamApiByKey(int32 connId, BaseParamApi* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateBaseParamApiByKey(int32 connId, BaseParamApiKeyLst* pKeyList, BaseParamApiMulti* pData, BaseParamApiUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfBaseParamApi(int32 connId, int32* pCntOut);
ResCodeT FetchNextBaseParamApi( BOOL * pFrstFlag, int32 connId, BaseParamApi* pDataOut);
////Delete Method
//ResCodeT DeleteAllBaseParamApi(int32 connId);
//ResCodeT DeleteBaseParamApi(int32 connId, BaseParamApiKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _BASE_PARAM_API_DB_ */
