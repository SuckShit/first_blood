/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ORG_INFO_DB_
#define _ORG_INFO_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OrgInfoDbS {
    int32  orgSrno;
    int32  orgId;
    char  orgCd[50];
    char  orgFullNmCn[300];
    char  orgNmCn[100];
    char  orgFullNmEn[300];
    char  orgNmEn[100];
    char  orgSt[8];
    char  orgTp[300];
    char  orgIrsSt[8];
    char  crdtMthd[8];
    char  crdtUpdMthd[8];
    char  crdtVldOrgF[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  crdtOprtngSt[8];
    char  crdtOprtr[100];
    char  tel[100];
    char  faxNo[100];
    char  lglRprsntv[300];
    char  adrsFrstDesc[300];
    char  adrsScndDesc[300];
    char  brdgOrdrRfrshF[8];
    char  lastBilNoteTm[50];
    DbTimestampTypeT *  pLastBilNoteTm;
} OrgInfo;

typedef struct OrgInfoJoinDbS {
    int32  orgSrno;
    int32  orgId;
    char  orgCd[50];
    char  orgFullNmCn[300];
    char  orgNmCn[100];
    char  orgFullNmEn[300];
    char  orgNmEn[100];
    char  orgSt[8];
    char  orgTp[300];
    char  orgIrsSt[8];
    char  crdtMthd[8];
    char  crdtUpdMthd[8];
    char  crdtVldOrgF[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  crdtOprtngSt[8];
    char  crdtOprtr[100];
    char  tel[100];
    char  faxNo[100];
    char  lglRprsntv[300];
    char  adrsFrstDesc[300];
    char  adrsScndDesc[300];
    char  brdgOrdrRfrshF[8];
    char  lastBilNoteTm[50];
    DbTimestampTypeT *  pLastBilNoteTm;
    char  mktTp[50];
    char  st[50];
} OrgInfoJoinT;

typedef struct OrgInfoCntS {
    int32  count;
} OrgInfoCntT;

typedef struct recOrgInfoKey{
    int32 orgSrno;
}OrgInfoKey;

typedef struct recOrgInfoKeyList{
    int32 keyRow;
    int32* orgSrnoLst;
}OrgInfoKeyLst;

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOrgInfo(int32 connId, OrgInfo* pData);
//ResCodeT UpdateOrgInfoByKey(int32 connId, OrgInfoKey* pKey, OrgInfo* pData, OrgInfoUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOrgInfo(int32 connId, OrgInfoMulti* pData);
////Update Method
ResCodeT UpdateOrgInfoByKey(int32 connId, OrgInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateOrgInfoByKey(int32 connId, OrgInfoKeyLst* pKeyList, OrgInfoMulti* pData, OrgInfoUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOrgInfo(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrgInfo( BOOL * pFrstFlag, int32 connId, OrgInfo* pDataOut);

ResCodeT GetResultCntOfOrgInfoJoinOrgMktPrvlg(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrgInfoJoinOrgMktPrvlg(BOOL* pFrstFlag, int32 connId, OrgInfoJoinT* pDataOut);

////Delete Method
//ResCodeT DeleteAllOrgInfo(int32 connId);
//ResCodeT DeleteOrgInfo(int32 connId, OrgInfoKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _ORG_INFO_DB_ */
