/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_REF_PRC_SIRS_DB_
#define _CNTRCT_REF_PRC_SIRS_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CNTRCT_REF_PRC_SIRS_CNTRCT_REF_PRC_SRNO_IDX     0
#define CNTRCT_REF_PRC_SIRS_CNTRCT_CD_IDX     1
#define CNTRCT_REF_PRC_SIRS_REF_PRC_DT_IDX     2
#define CNTRCT_REF_PRC_SIRS_REF_PRC_IDX     3
#define CNTRCT_REF_PRC_SIRS_CRT_TM_IDX     4
#define CNTRCT_REF_PRC_SIRS_CRT_USR_NM_IDX     5
#define CNTRCT_REF_PRC_SIRS_UPD_TM_IDX     6
#define CNTRCT_REF_PRC_SIRS_UPD_USR_NM_IDX     7

#define CNTRCT_REF_PRC_SIRS_VECT_LEN     GET_BIT_VECT_LEN(7)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctRefPrcSirsDbS {
    int32  cntrctRefPrcSrno;
    char  cntrctCd[50];
    char  refPrcDt[50];
    DbDateTypeT *  pRefPrcDt;
    double  refPrc;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CntrctRefPrcSirs;

typedef struct CntrctRefPrcSirsCntS {
    int32  count;
} CntrctRefPrcSirsCntT;


typedef struct recCntrctRefPrcSirsKey{
    int32 cntrctRefPrcSrno;
}CntrctRefPrcSirsKey;


typedef struct recCntrctRefPrcSirsKeyList{
    int32 keyRow;
    int32* cntrctRefPrcSrnoLst;
}CntrctRefPrcSirsKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctRefPrcSirs(int32 connId, CntrctRefPrcSirs* pData);
//ResCodeT UpdateCntrctRefPrcSirsByKey(int32 connId, CntrctRefPrcSirsKey* pKey, CntrctRefPrcSirs* pData, CntrctRefPrcSirsUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctRefPrcSirs(int32 connId, CntrctRefPrcSirsMulti* pData);
////Update Method
ResCodeT UpdateCntrctRefPrcSirsByKey(int32 connId, CntrctRefPrcSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctRefPrcSirsByKey(int32 connId, CntrctRefPrcSirsKeyLst* pKeyList, CntrctRefPrcSirsMulti* pData, CntrctRefPrcSirsUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctRefPrcSirs(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctRefPrcSirs( BOOL * pFrstFlag, int32 connId, CntrctRefPrcSirs* pDataOut);
ResCodeT FetchCntrctRefPrcSirsByName(int32 connId, char * pCntrctName, CntrctRefPrcSirs* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctRefPrcSirs(int32 connId);
//ResCodeT DeleteCntrctRefPrcSirs(int32 connId, CntrctRefPrcSirsKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_REF_PRC_SIRS_DB_ */
