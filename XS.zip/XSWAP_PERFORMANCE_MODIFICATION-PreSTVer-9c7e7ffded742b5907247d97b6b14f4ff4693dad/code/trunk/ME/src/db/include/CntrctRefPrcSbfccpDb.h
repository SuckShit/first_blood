/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_REF_PRC_SBFCCP_DB_
#define _CNTRCT_REF_PRC_SBFCCP_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CNTRCT_REF_PRC_SBFCCP_CNTRCT_REF_PRC_SRNO_IDX     0
#define CNTRCT_REF_PRC_SBFCCP_CNTRCT_CD_IDX     1
#define CNTRCT_REF_PRC_SBFCCP_REF_PRC_DT_IDX     2
#define CNTRCT_REF_PRC_SBFCCP_REF_PRC_IDX     3
#define CNTRCT_REF_PRC_SBFCCP_CRT_TM_IDX     4
#define CNTRCT_REF_PRC_SBFCCP_CRT_USR_NM_IDX     5
#define CNTRCT_REF_PRC_SBFCCP_UPD_TM_IDX     6
#define CNTRCT_REF_PRC_SBFCCP_UPD_USR_NM_IDX     7

#define CNTRCT_REF_PRC_SBFCCP_VECT_LEN     GET_BIT_VECT_LEN(7)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctRefPrcSbfccpDbS {
    int32  cntrctRefPrcSrno;
    char  cntrctCd[50];
    char  refPrcDt[50];
    DbDateTypeT *  pRefPrcDt;
    double  refPrc;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CntrctRefPrcSbfccp;

typedef struct CntrctRefPrcSbfccpCntS {
    int32  count;
} CntrctRefPrcSbfccpCntT;


typedef struct recCntrctRefPrcSbfccpKey{
    int32 cntrctRefPrcSrno;
}CntrctRefPrcSbfccpKey;


typedef struct recCntrctRefPrcSbfccpKeyList{
    int32 keyRow;
    int32* cntrctRefPrcSrnoLst;
}CntrctRefPrcSbfccpKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctRefPrcSbfccp(int32 connId, CntrctRefPrcSbfccp* pData);
//ResCodeT UpdateCntrctRefPrcSbfccpByKey(int32 connId, CntrctRefPrcSbfccpKey* pKey, CntrctRefPrcSbfccp* pData, CntrctRefPrcSbfccpUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctRefPrcSbfccp(int32 connId, CntrctRefPrcSbfccpMulti* pData);
////Update Method
ResCodeT UpdateCntrctRefPrcSbfccpByKey(int32 connId, CntrctRefPrcSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctRefPrcSbfccpByKey(int32 connId, CntrctRefPrcSbfccpKeyLst* pKeyList, CntrctRefPrcSbfccpMulti* pData, CntrctRefPrcSbfccpUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctRefPrcSbfccp(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctRefPrcSbfccp( BOOL * pFrstFlag, int32 connId, CntrctRefPrcSbfccp* pDataOut);
ResCodeT FetchCntrctRefPrcSbfccpByName(int32 connId, char * pCntrctName, CntrctRefPrcSbfccp* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctRefPrcSbfccp(int32 connId);
//ResCodeT DeleteCntrctRefPrcSbfccp(int32 connId, CntrctRefPrcSbfccpKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_REF_PRC_SBFCCP_DB_ */
