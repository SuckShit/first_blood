/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _cntrct_info_sbfccp_DB_
#define _cntrct_info_sbfccp_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define cntrct_info_sbfccp_CNTRCT_INFO_SRNO_IDX     0
#define cntrct_info_sbfccp_CNTRCT_CD_IDX     1
#define cntrct_info_sbfccp_CNTRCT_NM_EN_IDX     2
#define cntrct_info_sbfccp_CNTRCT_NM_CN_IDX     3
#define cntrct_info_sbfccp_CNTRCT_MTH_IDX     4
#define cntrct_info_sbfccp_TERM_IDX     5
#define cntrct_info_sbfccp_CNTRCT_FACE_VL_IDX     6
#define cntrct_info_sbfccp_CNTRCT_UNDRLYNG_IDX     7
#define cntrct_info_sbfccp_BNCHMK_RATE_IDX     8
#define cntrct_info_sbfccp_DLVRY_DT_IDX     9
#define cntrct_info_sbfccp_ACTV_DT_IDX     10
#define cntrct_info_sbfccp_EXPRD_DT_IDX     11
#define cntrct_info_sbfccp_TRDNG_END_TM_IDX     12
#define cntrct_info_sbfccp_EMGCY_F_IDX     13
#define cntrct_info_sbfccp_ST_IDX     14
#define cntrct_info_sbfccp_STLE_TP_IDX     15
#define cntrct_info_sbfccp_AMNT_PER_UNIT_IDX     16
#define cntrct_info_sbfccp_MIN_AMNT_PER_DL_IDX     17
#define cntrct_info_sbfccp_MAX_AMNT_PER_DL_IDX     18
#define cntrct_info_sbfccp_CRT_TM_IDX     19
#define cntrct_info_sbfccp_CRT_USR_NM_IDX     20
#define cntrct_info_sbfccp_UPD_TM_IDX     21
#define cntrct_info_sbfccp_UPD_USR_NM_IDX     22
#define cntrct_info_sbfccp_CNVRT_RATE_IDX     23
#define cntrct_info_sbfccp_PRC_LMT_IDX     24
#define cntrct_info_sbfccp_CHK_ST_IDX     25
#define cntrct_info_sbfccp_CPN_RATE_IDX     26

#define cntrct_info_sbfccp_VECT_LEN     GET_BIT_VECT_LEN(26)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctInfoSbfccpDbS {
    int32  cntrctInfoSrno;
    char  cntrctCd[50];
    char  cntrctNmEn[100];
    char  cntrctNmCn[300];
    char  cntrctMth[50];
    int32  term;
    double  cntrctFaceVl;
    char  cntrctUndrlyng[8];
    double  bnchmkRate;
    char  dlvryDt[50];
    DbDateTypeT *  pDlvryDt;
    char  actvDt[50];
    DbDateTypeT *  pActvDt;
    char  exprdDt[50];
    DbDateTypeT *  pExprdDt;
    char  trdngEndTm[50];
    char  emgcyF[8];
    char  st[8];
    char  stleTp[8];
    double  amntPerUnit;
    int32  minAmntPerDl;
    int32  maxAmntPerDl;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    double  cnvrtRate;
    double  prcLmt;
    char  chkSt[8];
    double  cpnRate;
} CntrctInfoSbfccp;

typedef struct CntrctInfoSbfccpCntS {
    int32  count;
} CntrctInfoSbfccpCntT;


typedef struct recCntrctInfoSbfccpKey{
    int32 cntrctInfoSrno;
}CntrctInfoSbfccpKey;


typedef struct recCntrctInfoSbfccpKeyList{
    int32 keyRow;
    int32* cntrctInfoSrnoLst;
}CntrctInfoSbfccpKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctInfoSbfccp(int32 connId, CntrctInfoSbfccp* pData);
//ResCodeT UpdateCntrctInfoSbfccpByKey(int32 connId, CntrctInfoSbfccpKey* pKey, CntrctInfoSbfccp* pData, CntrctInfoSbfccpUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctInfoSbfccp(int32 connId, CntrctInfoSbfccpMulti* pData);
////Update Method
ResCodeT UpdateCntrctInfoSbfccpByKey(int32 connId, CntrctInfoSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctInfoSbfccpByKey(int32 connId, CntrctInfoSbfccpKeyLst* pKeyList, CntrctInfoSbfccpMulti* pData, CntrctInfoSbfccpUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctInfoSbfccp(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctInfoSbfccp( BOOL * pFrstFlag, int32 connId, CntrctInfoSbfccp* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctInfoSbfccp(int32 connId);
//ResCodeT DeleteCntrctInfoSbfccp(int32 connId, CntrctInfoSbfccpKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _cntrct_info_sbfccp_DB_ */
