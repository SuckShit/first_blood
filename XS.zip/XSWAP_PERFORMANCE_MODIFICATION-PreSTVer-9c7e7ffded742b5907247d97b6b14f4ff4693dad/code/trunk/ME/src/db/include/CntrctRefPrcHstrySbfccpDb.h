/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_REF_PRC_HSTRY_SBFCCP_DB_
#define _CNTRCT_REF_PRC_HSTRY_SBFCCP_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CNTRCT_REF_PRC_HSTRY_SBFCCP_CNTRCT_REF_PRC_SRNO_IDX     0
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_BTCH_TM_IDX     1
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_CNTRCT_CD_IDX     2
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_REF_PRC_DT_IDX     3
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_REF_PRC_IDX     4
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_CRT_TM_IDX     5
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_CRT_USR_NM_IDX     6
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_UPD_TM_IDX     7
#define CNTRCT_REF_PRC_HSTRY_SBFCCP_UPD_USR_NM_IDX     8

#define CNTRCT_REF_PRC_HSTRY_SBFCCP_VECT_LEN     GET_BIT_VECT_LEN(8)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctRefPrcHstrySbfccpDbS {
    int32  cntrctRefPrcSrno;
    char  btchTm[50];
    DbTimestampTypeT *  pBtchTm;
    char  cntrctCd[50];
    char  refPrcDt[50];
    DbDateTypeT *  pRefPrcDt;
    double  refPrc;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CntrctRefPrcHstrySbfccp;

typedef struct CntrctRefPrcHstrySbfccpCntS {
    int32  count;
} CntrctRefPrcHstrySbfccpCntT;


typedef struct recCntrctRefPrcHstrySbfccpKey{
    int32 cntrctRefPrcSrno;
}CntrctRefPrcHstrySbfccpKey;


typedef struct recCntrctRefPrcHstrySbfccpKeyList{
    int32 keyRow;
    int32* cntrctRefPrcSrnoLst;
}CntrctRefPrcHstrySbfccpKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctRefPrcHstrySbfccp(int32 connId, CntrctRefPrcHstrySbfccp* pData);
//ResCodeT UpdateCntrctRefPrcHstrySbfccpByKey(int32 connId, CntrctRefPrcHstrySbfccpKey* pKey, CntrctRefPrcHstrySbfccp* pData, CntrctRefPrcHstrySbfccpUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctRefPrcHstrySbfccp(int32 connId, CntrctRefPrcHstrySbfccpMulti* pData);
////Update Method
ResCodeT UpdateCntrctRefPrcHstrySbfccpByKey(int32 connId, CntrctRefPrcHstrySbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctRefPrcHstrySbfccpByKey(int32 connId, CntrctRefPrcHstrySbfccpKeyLst* pKeyList, CntrctRefPrcHstrySbfccpMulti* pData, CntrctRefPrcHstrySbfccpUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctRefPrcHstrySbfccp(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctRefPrcHstrySbfccp( BOOL * pFrstFlag, int32 connId, CntrctRefPrcHstrySbfccp* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctRefPrcHstrySbfccp(int32 connId);
//ResCodeT DeleteCntrctRefPrcHstrySbfccp(int32 connId, CntrctRefPrcHstrySbfccpKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_REF_PRC_HSTRY_SBFCCP_DB_ */
