/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ORDR_DB_
#define _ORDR_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OrdrDbS {
    char  ordrId[50];
    int32  orgId;
    char  ordrSbmtTp[8];
    char  ordrTp[8];
    char  ocoId[50];
    char  cntrctNm[50];
    double  ntnlAmnt;
    double  rmngNtnlAmnt;
    double  ordrPrc;
    double  ordrAmnt;
    char  dlDir[8];
    char  st[8];
    char  trdrNm[100];
    char  ordrCrtTm[50];
    DbTimestampTypeT *  pOrdrCrtTm;
    char  ordrExprdTm[50];
    DbDateTypeT *  pOrdrExprdTm;
    char  ordrActvTm[50];
    DbTimestampTypeT *  pOrdrActvTm;
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  orgFullNmCn[300];
    char  vrtlBrdgOrdrF[8];
    char  rqstId[50];
    char  usrLgnNmApi[100];
    char  orgCd[50];
    char  bilId[50];
} Ordr;

typedef struct OrdrCntS {
    int32  count;
} OrdrCntT;


typedef struct recOrdrKey{
    char ordrId[50];
}OrdrKey;


typedef struct recOrdrKeyList{
    int32 keyRow;
    char** ordrIdLst;
}OrdrKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOrdr(int32 connId, Ordr* pData);
//ResCodeT UpdateOrdrByKey(int32 connId, OrdrKey* pKey, Ordr* pData, OrdrUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOrdr(int32 connId, OrdrMulti* pData);
////Update Method
ResCodeT UpdateOrdrByKey(int32 connId, Ordr* pData, vectorT * pKeyFlg, vectorT * pColFlg);
ResCodeT UpdateCancleOrdr( int32 connId, Ordr* pData );
//ResCodeT BatchUpdateOrdrByKey(int32 connId, OrdrKeyLst* pKeyList, OrdrMulti* pData, OrdrUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOrdr(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrdr( BOOL * pFrstFlag, int32 connId, Ordr* pDataOut);
ResCodeT FetchOrdrByKey( int32 connId, char * pKey, BOOL * pFetchFlag );
////Delete Method
//ResCodeT DeleteAllOrdr(int32 connId);
//ResCodeT DeleteOrdr(int32 connId, OrdrKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _ORDR_DB_ */
