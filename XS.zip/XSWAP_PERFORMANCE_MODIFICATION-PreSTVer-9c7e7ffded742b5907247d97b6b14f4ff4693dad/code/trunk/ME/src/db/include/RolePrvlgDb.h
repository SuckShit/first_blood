/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ROLE_PRVLG_DB_
#define _ROLE_PRVLG_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct RolePrvlgDbS {
    int32  rsrcId;
    int32  roleId;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} RolePrvlg;

typedef struct RolePrvlgCntS {
    int32  count;
} RolePrvlgCntT;


typedef struct recRolePrvlgKey{
    int32 rsrcId;
}RolePrvlgKey;


typedef struct recRolePrvlgKeyList{
    int32 keyRow;
    int32* rsrcIdLst;
}RolePrvlgKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertRolePrvlg(int32 connId, RolePrvlg* pData);
//ResCodeT UpdateRolePrvlgByKey(int32 connId, RolePrvlgKey* pKey, RolePrvlg* pData, RolePrvlgUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertRolePrvlg(int32 connId, RolePrvlgMulti* pData);
////Update Method
ResCodeT UpdateRolePrvlgByKey(int32 connId, RolePrvlg* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateRolePrvlgByKey(int32 connId, RolePrvlgKeyLst* pKeyList, RolePrvlgMulti* pData, RolePrvlgUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfRolePrvlg(int32 connId, int32* pCntOut);
ResCodeT FetchNextRolePrvlg( BOOL * pFrstFlag, int32 connId, RolePrvlg* pDataOut);
////Delete Method
//ResCodeT DeleteAllRolePrvlg(int32 connId);
//ResCodeT DeleteRolePrvlg(int32 connId, RolePrvlgKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _ROLE_PRVLG_DB_ */
