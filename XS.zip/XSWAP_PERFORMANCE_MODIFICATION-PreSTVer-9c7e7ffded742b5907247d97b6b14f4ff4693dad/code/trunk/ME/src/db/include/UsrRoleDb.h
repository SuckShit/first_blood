/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _USR_ROLE_DB_
#define _USR_ROLE_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct UsrRoleDbS {
    char  usrNm[100];
    char  roleId[10];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    int32  orgId;
} UsrRole;


typedef struct recUsrRoleInsert {
    char  usrNm[100];
    int32  roleId;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    int32  orgId;
} UsrRoleInsert;



typedef struct UsrRoleCntS {
    int32  count;
} UsrRoleCntT;


typedef struct recUsrRoleKey{
    char usrNm[100];
}UsrRoleKey;


typedef struct recUsrRoleKeyList{
    int32 keyRow;
    char** usrNmLst;
}UsrRoleKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertUsrRole(int32 connId, UsrRoleInsert* pData);
//ResCodeT UpdateUsrRoleByKey(int32 connId, UsrRoleKey* pKey, UsrRole* pData, UsrRoleUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertUsrRole(int32 connId, UsrRoleMulti* pData);
////Update Method
ResCodeT UpdateUsrRoleByKey(int32 connId, UsrRole* pData, vectorT * pKeyFlg, vectorT * pColFlg);
ResCodeT UpdateUsrRoleByKeyEqlValue(int32 connId, UsrRole* pData, vectorT * pKeyFlg, vectorT * pColFlg, char*  addKey);
ResCodeT UpdateUsrRoleByKeyRpt(int32 connId, UsrRole* pKeyData, UsrRoleInsert* pNewData, vectorT * pKeyFlg, vectorT * pColFlg );
//ResCodeT BatchUpdateUsrRoleByKey(int32 connId, UsrRoleKeyLst* pKeyList, UsrRoleMulti* pData, UsrRoleUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfUsrRole(int32 connId, int32* pCntOut);
ResCodeT FetchNextUsrRole( BOOL * pFrstFlag, int32 connId, UsrRole* pDataOut);
////Delete Method
//ResCodeT DeleteAllUsrRole(int32 connId);
//ResCodeT DeleteUsrRole(int32 connId, UsrRoleKey* pKey);
ResCodeT DeleteUsrRole(int32 connId, UsrRoleKey* pKey);
ResCodeT UpdateUsrRoleId(int32 connId, int32 orgId, int32 oldRoleId, int32 newRoleId);

#ifdef _cplusplus
}
#endif

#endif /* _USR_ROLE_DB_ */
