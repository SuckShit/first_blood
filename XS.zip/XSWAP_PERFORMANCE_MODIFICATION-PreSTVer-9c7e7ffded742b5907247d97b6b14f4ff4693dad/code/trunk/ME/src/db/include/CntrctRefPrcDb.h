/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_REF_PRC_DB_
#define _CNTRCT_REF_PRC_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CNTRCT_REF_PRC_CNTRCT_REF_PRC_SRNO_IDX     0
#define CNTRCT_REF_PRC_CNTRCT_NM_IDX     1
#define CNTRCT_REF_PRC_REF_PRC_DT_IDX     2
#define CNTRCT_REF_PRC_REF_PRC_IDX     3
#define CNTRCT_REF_PRC_CRT_TM_IDX     4
#define CNTRCT_REF_PRC_CRT_USR_NM_IDX     5
#define CNTRCT_REF_PRC_UPD_TM_IDX     6
#define CNTRCT_REF_PRC_UPD_USR_NM_IDX     7

#define CNTRCT_REF_PRC_VECT_LEN     GET_BIT_VECT_LEN(7)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctRefPrcDbS {
    int32  cntrctRefPrcSrno;
    char  cntrctNm[50];
    char  refPrcDt[50];
    DbDateTypeT *  pRefPrcDt;
    double  refPrc;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CntrctRefPrc;

typedef struct CntrctRefPrcCntS {
    int32  count;
} CntrctRefPrcCntT;


typedef struct recCntrctRefPrcKey{
    int32 cntrctRefPrcSrno;
}CntrctRefPrcKey;


typedef struct recCntrctRefPrcKeyList{
    int32 keyRow;
    int32* cntrctRefPrcSrnoLst;
}CntrctRefPrcKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctRefPrc(int32 connId, CntrctRefPrc* pData);
//ResCodeT UpdateCntrctRefPrcByKey(int32 connId, CntrctRefPrcKey* pKey, CntrctRefPrc* pData, CntrctRefPrcUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctRefPrc(int32 connId, CntrctRefPrcMulti* pData);
////Update Method
ResCodeT UpdateCntrctRefPrcByKey(int32 connId, CntrctRefPrc* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctRefPrcByKey(int32 connId, CntrctRefPrcKeyLst* pKeyList, CntrctRefPrcMulti* pData, CntrctRefPrcUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctRefPrc(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctRefPrc( BOOL * pFrstFlag, int32 connId, CntrctRefPrc* pDataOut);
ResCodeT FetchCntrctRefPrcByName(int32 connId, char * pCntrctName, CntrctRefPrc* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctRefPrc(int32 connId);
//ResCodeT DeleteCntrctRefPrc(int32 connId, CntrctRefPrcKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_REF_PRC_DB_ */
