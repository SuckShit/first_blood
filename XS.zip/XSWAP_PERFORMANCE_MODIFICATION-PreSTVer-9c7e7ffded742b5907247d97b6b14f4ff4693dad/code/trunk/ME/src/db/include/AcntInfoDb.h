/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ACNT_INFO_DB_
#define _ACNT_INFO_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define ACNT_INFO_ACNT_SRNO_IDX     0
#define ACNT_INFO_ACNT_ID_IDX     1
#define ACNT_INFO_ORG_ID_IDX     2
#define ACNT_INFO_ACNT_FULL_NM_IDX     3
#define ACNT_INFO_ACNT_NO_IDX     4
#define ACNT_INFO_OPNG_BNK_NM_IDX     5
#define ACNT_INFO_STLMNT_BNK_CD_IDX     6
#define ACNT_INFO_DFLT_ACNT_IDX     7
#define ACNT_INFO_ST_IDX     8
#define ACNT_INFO_CRT_TM_IDX     9
#define ACNT_INFO_CRT_USR_NM_IDX     10
#define ACNT_INFO_UPD_TM_IDX     11
#define ACNT_INFO_UPD_USR_NM_IDX     12

#define ACNT_INFO_VECT_LEN     GET_BIT_VECT_LEN(12)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct AcntInfoDbS {
    int32  acntSrno;
    int32  acntId;
    int32  orgId;
    char  acntFullNm[300];
    char  acntNo[100];
    char  opngBnkNm[300];
    char  stlmntBnkCd[100];
    char  dfltAcnt[8];
    char  st[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} AcntInfo;

typedef struct AcntInfoCntS {
    int32  count;
} AcntInfoCntT;


typedef struct recAcntInfoKey{
    int32 acntSrno;
}AcntInfoKey;


typedef struct recAcntInfoKeyList{
    int32 keyRow;
    int32* acntSrnoLst;
}AcntInfoKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertAcntInfo(int32 connId, AcntInfo* pData);
//ResCodeT UpdateAcntInfoByKey(int32 connId, AcntInfoKey* pKey, AcntInfo* pData, AcntInfoUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertAcntInfo(int32 connId, AcntInfoMulti* pData);
////Update Method
ResCodeT UpdateAcntInfoByKey(int32 connId, AcntInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateAcntInfoByKey(int32 connId, AcntInfoKeyLst* pKeyList, AcntInfoMulti* pData, AcntInfoUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfAcntInfo(int32 connId, int32* pCntOut);
ResCodeT FetchNextAcntInfo( BOOL * pFrstFlag, int32 connId, AcntInfo* pDataOut);
////Delete Method
//ResCodeT DeleteAllAcntInfo(int32 connId);
//ResCodeT DeleteAcntInfo(int32 connId, AcntInfoKey* pKey);
ResCodeT GetResultCntOfAcntInfoByKey(int32 connId, AcntInfo* pData, vectorT * pKeyFlg, int32* pCntOut);
ResCodeT FetchNextAcntInfoByKey( BOOL * pFrstFlag, int32 connId, AcntInfo* pData, vectorT * pKeyFlg, AcntInfo* pDataOut);

#ifdef _cplusplus
}
#endif

#endif /* _ACNT_INFO_DB_ */
