/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ORDR_SIRS_DB_
#define _ORDR_SIRS_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define ORDR_SIRS_ORDR_ID_IDX     0
#define ORDR_SIRS_ORG_ID_IDX     1
#define ORDR_SIRS_ORDR_SBMT_TP_IDX     2
#define ORDR_SIRS_ORDR_TP_IDX     3
#define ORDR_SIRS_OCO_ID_IDX     4
#define ORDR_SIRS_CNTRCT_CD_IDX     5
#define ORDR_SIRS_NTNL_AMNT_IDX     6
#define ORDR_SIRS_RMNG_NTNL_AMNT_IDX     7
#define ORDR_SIRS_ORDR_PRC_IDX     8
#define ORDR_SIRS_ORDR_AMNT_IDX     9
#define ORDR_SIRS_DL_DIR_IDX     10
#define ORDR_SIRS_ST_IDX     11
#define ORDR_SIRS_TRDR_NM_IDX     12
#define ORDR_SIRS_ORDR_CRT_TM_IDX     13
#define ORDR_SIRS_ORDR_EXPRD_TM_IDX     14
#define ORDR_SIRS_ORDR_ACTV_TM_IDX     15
#define ORDR_SIRS_UPD_TM_IDX     16
#define ORDR_SIRS_UPD_USR_NM_IDX     17
#define ORDR_SIRS_ORG_FULL_NM_CN_IDX     18
#define ORDR_SIRS_RQST_ID_IDX     19
#define ORDR_SIRS_USR_LGN_NM_API_IDX     20
#define ORDR_SIRS_ORG_CD_IDX     21

#define ORDR_SIRS_VECT_LEN     GET_BIT_VECT_LEN(21)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OrdrSirsDbS {
    char  ordrId[50];
    int32  orgId;
    char  ordrSbmtTp[8];
    char  ordrTp[8];
    char  ocoId[50];
    char  cntrctCd[50];
    double  ntnlAmnt;
    double  rmngNtnlAmnt;
    double  ordrPrc;
    double  ordrAmnt;
    char  dlDir[8];
    char  st[8];
    char  trdrNm[100];
    char  ordrCrtTm[50];
    DbTimestampTypeT *  pOrdrCrtTm;
    char  ordrExprdTm[50];
    DbTimestampTypeT *  pOrdrExprdTm;
    char  ordrActvTm[50];
    DbTimestampTypeT *  pOrdrActvTm;
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  orgFullNmCn[300];
    char  rqstId[50];
    char  usrLgnNmApi[100];
    char  orgCd[50];
} OrdrSirs;

typedef struct OrdrSirsCntS {
    int32  count;
} OrdrSirsCntT;


typedef struct recOrdrSirsKey{
    char ordrId[50];
}OrdrSirsKey;


typedef struct recOrdrSirsKeyList{
    int32 keyRow;
    char** ordrIdLst;
}OrdrSirsKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOrdrSirs(int32 connId, OrdrSirs* pData);
//ResCodeT UpdateOrdrSirsByKey(int32 connId, OrdrSirsKey* pKey, OrdrSirs* pData, OrdrSirsUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOrdrSirs(int32 connId, OrdrSirsMulti* pData);
////Update Method
ResCodeT UpdateOrdrSirsByKey(int32 connId, OrdrSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateOrdrSirsByKey(int32 connId, OrdrSirsKeyLst* pKeyList, OrdrSirsMulti* pData, OrdrSirsUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOrdrSirs(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrdrSirs( BOOL * pFrstFlag, int32 connId, OrdrSirs* pDataOut);
////Delete Method
//ResCodeT DeleteAllOrdrSirs(int32 connId);
//ResCodeT DeleteOrdrSirs(int32 connId, OrdrSirsKey* pKey);
ResCodeT FetchOrdrSirsByKey( int32 connId, char * pKey, BOOL * pFetchFlag );
ResCodeT UpdateCancleOrdrSirs( int32 connId, OrdrSirs* pData );

#ifdef _cplusplus
}
#endif

#endif /* _ORDR_SIRS_DB_ */
