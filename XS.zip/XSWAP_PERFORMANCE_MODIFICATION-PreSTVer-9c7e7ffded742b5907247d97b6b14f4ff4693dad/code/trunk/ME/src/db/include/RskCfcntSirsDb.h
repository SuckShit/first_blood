/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _RSK_CFCNT_SIRS_DB_
#define _RSK_CFCNT_SIRS_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct RskCfcntSirsDbS {
    int32  rskCfcntId;
    int32  orgId;
    char  cntrctCd[50];
    double  rskCfcntVl;
    char  st[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} RskCfcntSirs;

typedef struct RskCfcntSirsCntS {
    int32  count;
} RskCfcntSirsCntT;


typedef struct recRskCfcntSirsKey{
    int32 rskCfcntId;
}RskCfcntSirsKey;


typedef struct recRskCfcntSirsKeyList{
    int32 keyRow;
    int32* rskCfcntIdLst;
}RskCfcntSirsKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertRskCfcntSirs(int32 connId, RskCfcntSirs* pData);
//ResCodeT UpdateRskCfcntSirsByKey(int32 connId, RskCfcntSirsKey* pKey, RskCfcntSirs* pData, RskCfcntSirsUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertRskCfcntSirs(int32 connId, RskCfcntSirsMulti* pData);
////Update Method
ResCodeT UpdateRskCfcntSirsByKey(int32 connId, RskCfcntSirs* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateRskCfcntSirsByKey(int32 connId, RskCfcntSirsKeyLst* pKeyList, RskCfcntSirsMulti* pData, RskCfcntSirsUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfRskCfcntSirs(int32 connId, int32* pCntOut);
ResCodeT FetchNextRskCfcntSirs( BOOL * pFrstFlag, int32 connId, RskCfcntSirs* pDataOut);
////Delete Method
//ResCodeT DeleteAllRskCfcntSirs(int32 connId);
//ResCodeT DeleteRskCfcntSirs(int32 connId, RskCfcntSirsKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _RSK_CFCNT_SIRS_DB_ */
