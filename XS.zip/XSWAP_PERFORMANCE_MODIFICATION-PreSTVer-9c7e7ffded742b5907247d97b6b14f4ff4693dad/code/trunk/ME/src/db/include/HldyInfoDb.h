/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _HLDY_INFO_DB_
#define _HLDY_INFO_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct HldyInfoDbS {
    int32  hldySrno;
    char  mktTp[8];
    char  clndrTp[8];
    int32  yrVl;
    char  hldyDt[50];
    DbDateTypeT *  pHldyDt;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} HldyInfo;

typedef struct HldyInfoCntS {
    int32  count;
} HldyInfoCntT;


typedef struct recHldyInfoKey{
    int32 hldySrno;
}HldyInfoKey;


typedef struct recHldyInfoKeyList{
    int32 keyRow;
    int32* hldySrnoLst;
}HldyInfoKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertHldyInfo(int32 connId, HldyInfo* pData);
//ResCodeT UpdateHldyInfoByKey(int32 connId, HldyInfoKey* pKey, HldyInfo* pData, HldyInfoUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertHldyInfo(int32 connId, HldyInfoMulti* pData);
////Update Method
ResCodeT UpdateHldyInfoByKey(int32 connId, HldyInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateHldyInfoByKey(int32 connId, HldyInfoKeyLst* pKeyList, HldyInfoMulti* pData, HldyInfoUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfHldyInfo(int32 connId, int32* pCntOut);
ResCodeT GetResultCntOfHldyInfoByKey(int32 connId, int32 mktType, int32 clndrType, char* dateStr, int32* pCntOut);
ResCodeT FetchNextHldyInfo( BOOL * pFrstFlag, int32 connId, HldyInfo* pDataOut);
////Delete Method
//ResCodeT DeleteAllHldyInfo(int32 connId);
//ResCodeT DeleteHldyInfo(int32 connId, HldyInfoKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _HLDY_INFO_DB_ */
