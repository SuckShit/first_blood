/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _DL_DB_
#define _DL_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct DlDbS {
    char  dlId[50];
    char  cntrctNm[50];
    char  dlTp[8];
    char  trdngMthd[8];
    int32  fxdIntrstBidOrgId;
    char  fxdIntrstBidTrdr[100];
    char  fxdIntrstBidTrdrNm[300];
    char  fxdIntrstBidOrdrId[50];
    int32  fxdIntrstOfrOrgId;
    char  fxdIntrstOfrTrdr[100];
    char  fxdIntrstOfrTrdrNm[300];
    char  fxdIntrstOfrOrdrId[50];
    double  ntnlAmnt;
    double  dlPrc;
    char  dlDt[50];
    DbDateTypeT *  pDlDt;
    char  dlTm[50];
    DbTimestampTypeT *  pDlTm;
    char  dlSt[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  fxdIntrstBidOrgNmCn[300];
    char  fxdIntrstOfrOrgNmCn[300];
    char  dlDir[8];
    char  brdgOrgDlDir[8];
    int32  mkrOrgId;
    char  fxdIntrstBidOrgShortNmCn[100];
    char  fxdIntrstOfrOrgShortNmCn[100];
    char  fxdIntrstBidOrgShortNmEn[100];
    char  fxdIntrstOfrOrgShortNmEn[100];
} Dl;

typedef struct DlCntS {
    int32  count;
} DlCntT;


typedef struct recDlKey{
    char dlId[50];
}DlKey;


typedef struct recDlKeyList{
    int32 keyRow;
    char** dlIdLst;
}DlKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertDl(int32 connId, Dl* pData);
//ResCodeT UpdateDlByKey(int32 connId, DlKey* pKey, Dl* pData, DlUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertDl(int32 connId, DlMulti* pData);
////Update Method
ResCodeT UpdateDlByKey(int32 connId, Dl* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateDlByKey(int32 connId, DlKeyLst* pKeyList, DlMulti* pData, DlUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfDl(int32 connId, int32* pCntOut);
ResCodeT FetchNextDl( BOOL * pFrstFlag, int32 connId, Dl* pDataOut);
////Delete Method
//ResCodeT DeleteAllDl(int32 connId);
//ResCodeT DeleteDl(int32 connId, DlKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _DL_DB_ */
