/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_BASE_INFO_DB_
#define _CNTRCT_BASE_INFO_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctBaseInfoDbS {
    int32  cntrctSrno;
    char  cntrctNm[50];
    char  cntrctTp[8];
    char  mktId[8];
    char  shrtCntrctNm[50];
    char  lngCntrctNm[50];
    double  shrtAmntRatio;
    double  lngAmntRatio;
    int32  maxAmntPerDl;
    int32  minAmntPerDl;
    int32  dlUnit;
    char  dlPrcUnit[8];
    int32  term;
    char  st[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  termStrng[50];
    int32  brdgSort;
} CntrctBaseInfo;

typedef struct CntrctBaseInfoCntS {
    int32  count;
} CntrctBaseInfoCntT;


typedef struct recCntrctBaseInfoKey{
    int32 cntrctSrno;
}CntrctBaseInfoKey;


typedef struct recCntrctBaseInfoKeyList{
    int32 keyRow;
    int32* cntrctSrnoLst;
}CntrctBaseInfoKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctBaseInfo(int32 connId, CntrctBaseInfo* pData);
//ResCodeT UpdateCntrctBaseInfoByKey(int32 connId, CntrctBaseInfoKey* pKey, CntrctBaseInfo* pData, CntrctBaseInfoUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctBaseInfo(int32 connId, CntrctBaseInfoMulti* pData);
////Update Method
ResCodeT UpdateCntrctBaseInfoByKey(int32 connId, CntrctBaseInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctBaseInfoByKey(int32 connId, CntrctBaseInfoKeyLst* pKeyList, CntrctBaseInfoMulti* pData, CntrctBaseInfoUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctBaseInfo(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctBaseInfo( BOOL * pFrstFlag, int32 connId, CntrctBaseInfo* pDataOut);
ResCodeT FetchNextCntrctBaseInfoBySt( BOOL* pFrstFlag, int32 connId, CntrctBaseInfo* pDataOut);
ResCodeT GetResultCntOfCntrctBaseInfoByKeyRL(int32 connId, CntrctBaseInfo* pData, vectorT *pKeyFlg, int32* pCntOut);
////Delete Method
//ResCodeT DeleteAllCntrctBaseInfo(int32 connId);
//ResCodeT DeleteCntrctBaseInfo(int32 connId, CntrctBaseInfoKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_BASE_INFO_DB_ */
