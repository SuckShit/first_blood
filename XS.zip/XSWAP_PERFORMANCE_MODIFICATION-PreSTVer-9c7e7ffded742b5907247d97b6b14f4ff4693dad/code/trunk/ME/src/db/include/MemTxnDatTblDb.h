/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _MEM_TXN_DAT_TBL_DB_
#define _MEM_TXN_DAT_TBL_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "mem_txn.h"

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/

/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InitMemTxnDatTblSqlQuery(int32 connId, int32 setId);
//ResCodeT InsertMemTxnDatTbl(int32 connId, MemTxnDatTbl* pData);
ResCodeT BatchInsertMemTxnDatTbl(int32 connId, pRtDatCtrlT pDataCtrl, int32 dataCnt, int32 dataSize);
ResCodeT SelectMemTxnDatTbl(int32 connId, int32 * pStmntId);
ResCodeT SelectMemTxnDatTblByKey(int32 connId, int32 keyValue, int32 * pStmntId);
ResCodeT FetchNextMemTxnDatTbl( BOOL * pFrstFlag, int32 connId,
                                    DatCtrlT* pDataOut, char* rtEleAddr);
ResCodeT FetchNextMemTxnDatTblByKey( BOOL *pFrstFlag, int32 connId, int32 keyValue,
                                    DatCtrlT* pDataOut, char* rtEleAddr, int32 outBuffLen );
ResCodeT FetchNextMemTxnDatTblByMsgSqno( BOOL * pFrstFlag, int32 connId, int32 keyValue,
                                            DatCtrlT* pDataOut, char* rtEleAddr , int32 outBuffLen);                                    
#endif /* _MEM_TXN_DAT_TBL_DB_ */
