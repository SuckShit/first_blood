/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _DPST_ACNT_INFO_SBF_DB_
#define _DPST_ACNT_INFO_SBF_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define DPST_ACNT_INFO_SBF_DPST_ACNT_SRNO_IDX     0
#define DPST_ACNT_INFO_SBF_DPST_ACNT_ID_IDX     1
#define DPST_ACNT_INFO_SBF_DPST_ACNT_NO_IDX     2
#define DPST_ACNT_INFO_SBF_DPST_ACNT_NM_IDX     3
#define DPST_ACNT_INFO_SBF_DPST_ORG_IDX     4
#define DPST_ACNT_INFO_SBF_ORG_ID_IDX     5
#define DPST_ACNT_INFO_SBF_ACNT_SRNO_IDX     6
#define DPST_ACNT_INFO_SBF_DFLT_ACNT_IDX     7
#define DPST_ACNT_INFO_SBF_ST_IDX     8
#define DPST_ACNT_INFO_SBF_SYS_SRC_IDX     9
#define DPST_ACNT_INFO_SBF_CRT_USR_NM_IDX     10
#define DPST_ACNT_INFO_SBF_CRT_TM_IDX     11
#define DPST_ACNT_INFO_SBF_UPD_USR_NM_IDX     12
#define DPST_ACNT_INFO_SBF_UPD_TM_IDX     13

#define DPST_ACNT_INFO_SBF_VECT_LEN     GET_BIT_VECT_LEN(13)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct DpstAcntInfoSbfDbS {
    int32  dpstAcntSrno;
    int32  dpstAcntId;
    char  dpstAcntNo[200];
    char  dpstAcntNm[500];
    char  dpstOrg[500];
    int32  orgId;
    int32  acntSrno;
    char  dfltAcnt[8];
    char  st[8];
    char  sysSrc[8];
    char  crtUsrNm[100];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  updUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
} DpstAcntInfoSbf;

typedef struct DpstAcntInfoSbfCntS {
    int32  count;
} DpstAcntInfoSbfCntT;


typedef struct recDpstAcntInfoSbfKey{
    int32 dpstAcntSrno;
}DpstAcntInfoSbfKey;


typedef struct recDpstAcntInfoSbfKeyList{
    int32 keyRow;
    int32* dpstAcntSrnoLst;
}DpstAcntInfoSbfKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertDpstAcntInfoSbf(int32 connId, DpstAcntInfoSbf* pData);
//ResCodeT UpdateDpstAcntInfoSbfByKey(int32 connId, DpstAcntInfoSbfKey* pKey, DpstAcntInfoSbf* pData, DpstAcntInfoSbfUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertDpstAcntInfoSbf(int32 connId, DpstAcntInfoSbfMulti* pData);
////Update Method
ResCodeT UpdateDpstAcntInfoSbfByKey(int32 connId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateDpstAcntInfoSbfByKey(int32 connId, DpstAcntInfoSbfKeyLst* pKeyList, DpstAcntInfoSbfMulti* pData, DpstAcntInfoSbfUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfDpstAcntInfoSbf(int32 connId, int32* pCntOut);
ResCodeT FetchNextDpstAcntInfoSbf( BOOL * pFrstFlag, int32 connId, DpstAcntInfoSbf* pDataOut);
////Delete Method
//ResCodeT DeleteAllDpstAcntInfoSbf(int32 connId);
//ResCodeT DeleteDpstAcntInfoSbf(int32 connId, DpstAcntInfoSbfKey* pKey);
ResCodeT GetResultCntOfDpstAcntInfoSbfByKey(int32 connId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg, int32* pCntOut);
ResCodeT FetchNextDpstAcntInfoSbfByKey( BOOL * pFrstFlag, int32 connId, DpstAcntInfoSbf* pData, vectorT * pKeyFlg, DpstAcntInfoSbf* pDataOut);

#ifdef _cplusplus
}
#endif

#endif /* _DPST_ACNT_INFO_SBF_DB_ */
