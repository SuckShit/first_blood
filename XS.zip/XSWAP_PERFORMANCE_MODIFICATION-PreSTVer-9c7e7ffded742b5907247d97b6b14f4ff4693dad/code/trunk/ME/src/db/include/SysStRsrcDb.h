/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _SYS_ST_RSRC_DB_
#define _SYS_ST_RSRC_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct SysStRsrcDbS {
    int32  sysStId;
    int32  rsrcId;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} SysStRsrc;

typedef struct SysStRsrcCntS {
    int32  count;
} SysStRsrcCntT;


typedef struct recSysStRsrcKey{
    int32 sysStId;
}SysStRsrcKey;


typedef struct recSysStRsrcKeyList{
    int32 keyRow;
    int32* sysStIdLst;
}SysStRsrcKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertSysStRsrc(int32 connId, SysStRsrc* pData);
//ResCodeT UpdateSysStRsrcByKey(int32 connId, SysStRsrcKey* pKey, SysStRsrc* pData, SysStRsrcUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertSysStRsrc(int32 connId, SysStRsrcMulti* pData);
////Update Method
ResCodeT UpdateSysStRsrcByKey(int32 connId, SysStRsrc* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateSysStRsrcByKey(int32 connId, SysStRsrcKeyLst* pKeyList, SysStRsrcMulti* pData, SysStRsrcUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntBySysStIdAndRsrcId( int32 connId, int32 iSysStId, int32 RsrcId, int32* pCntOut );
ResCodeT GetResultCntOfSysStRsrc(int32 connId, int32* pCntOut);
ResCodeT FetchNextSysStRsrc( BOOL * pFrstFlag, int32 connId, SysStRsrc* pDataOut);
////Delete Method
//ResCodeT DeleteAllSysStRsrc(int32 connId);
//ResCodeT DeleteSysStRsrc(int32 connId, SysStRsrcKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _SYS_ST_RSRC_DB_ */
