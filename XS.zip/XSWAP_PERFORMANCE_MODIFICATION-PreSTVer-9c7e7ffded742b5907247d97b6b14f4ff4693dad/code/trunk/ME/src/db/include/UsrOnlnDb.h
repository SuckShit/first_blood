/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _USR_ONLN_DB_
#define _USR_ONLN_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#include "msg_common_value.h"

#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct UsrOnlnDbS {
    char  usrNm[MAX_USR_NM_LENTH];
    char  sesnId[MAX_TOKEN_LENTH];
    int32  lgnTp;
    char  lgnTm[MAX_TIME_LENGTH];
    DbTimestampTypeT *  pLgnTm;
    char  lgnIp[MAX_IP_LENTH];
    char  apiF[MAX_APIF_LENTH];
} UsrOnln;

typedef struct UsrOnlnCntS {
    int32  count;
} UsrOnlnCntT;


typedef struct recUsrOnlnKey{
    char usrNm[MAX_USR_NM_LENTH];
}UsrOnlnKey;


typedef struct recUsrOnlnKeyList{
    int32 keyRow;
    char** usrNmLst;
}UsrOnlnKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertUsrOnln(int32 connId, UsrOnln* pData);
//ResCodeT UpdateUsrOnlnByKey(int32 connId, UsrOnlnKey* pKey, UsrOnln* pData, UsrOnlnUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertUsrOnln(int32 connId, UsrOnlnMulti* pData);
////Update Method
ResCodeT UpdateUsrOnlnByKey(int32 connId, UsrOnln* pData, vectorT * pKeyFlg, vectorT * pColFlg);
ResCodeT UpdateUsrOnlnByKeyEqlValue(int32 connId, UsrOnln* pData, vectorT * pKeyFlg, vectorT * pColFlg, char*  addKey);
//ResCodeT BatchUpdateUsrOnlnByKey(int32 connId, UsrOnlnKeyLst* pKeyList, UsrOnlnMulti* pData, UsrOnlnUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfUsrOnln(int32 connId, int32* pCntOut);
ResCodeT GetCntByUsrNm(int32 connId, char* strUsrNm, int32* pCntOut);
ResCodeT GetCntByApiF(int32 connId, char* apiF, int32* pCntOut);
ResCodeT FetchNextUsrOnln( BOOL * pFrstFlag, int32 connId, UsrOnln* pDataOut);
////Delete Method
ResCodeT DeleteUsrOnln(int32 connId, UsrOnlnKey* pKey);
ResCodeT DeleteApiUsrByFlag(int32 connId, int32 iFlag);
ResCodeT DeleteApiUsrByNameAndFlag(int32 connId, char* name, int32 iFlag);
//ResCodeT DeleteAllUsrOnln(int32 connId);
//ResCodeT DeleteUsrOnln(int32 connId, UsrOnlnKey* pKey);
ResCodeT UpdateUsrOnlnLgnTpl(int32 connId, int32 orgId, int32 oldLgnTp, int32 newLgnTp);

#ifdef _cplusplus
}
#endif

#endif /* _USR_ONLN_DB_ */
