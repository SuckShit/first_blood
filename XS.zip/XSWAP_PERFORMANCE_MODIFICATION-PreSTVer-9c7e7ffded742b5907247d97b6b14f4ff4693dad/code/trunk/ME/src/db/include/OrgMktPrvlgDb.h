/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ORG_MKT_PRVLG_DB_
#define _ORG_MKT_PRVLG_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define ORG_MKT_PRVLG_ORG_MKT_PRVLG_SRNO_IDX     0
#define ORG_MKT_PRVLG_ORG_ID_IDX     1
#define ORG_MKT_PRVLG_MKT_TP_IDX     2
#define ORG_MKT_PRVLG_ST_IDX     3
#define ORG_MKT_PRVLG_CRT_TM_IDX     4
#define ORG_MKT_PRVLG_CRT_USR_NM_IDX     5
#define ORG_MKT_PRVLG_UPD_TM_IDX     6
#define ORG_MKT_PRVLG_UPD_USR_NM_IDX     7

#define ORG_MKT_PRVLG_VECT_LEN     GET_BIT_VECT_LEN(7)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OrgMktPrvlgDbS {
    int32  orgMktPrvlgSrno;
    int32  orgId;
    char  mktTp[8];
    char  st[8];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} OrgMktPrvlg;

typedef struct OrgMktPrvlgCntS {
    int32  count;
} OrgMktPrvlgCntT;


typedef struct recOrgMktPrvlgKey{
    int32 orgMktPrvlgSrno;
}OrgMktPrvlgKey;


typedef struct recOrgMktPrvlgKeyList{
    int32 keyRow;
    int32* orgMktPrvlgSrnoLst;
}OrgMktPrvlgKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOrgMktPrvlg(int32 connId, OrgMktPrvlg* pData);
//ResCodeT UpdateOrgMktPrvlgByKey(int32 connId, OrgMktPrvlgKey* pKey, OrgMktPrvlg* pData, OrgMktPrvlgUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOrgMktPrvlg(int32 connId, OrgMktPrvlgMulti* pData);
////Update Method
ResCodeT UpdateOrgMktPrvlgByKey(int32 connId, OrgMktPrvlg* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateOrgMktPrvlgByKey(int32 connId, OrgMktPrvlgKeyLst* pKeyList, OrgMktPrvlgMulti* pData, OrgMktPrvlgUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOrgMktPrvlg(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrgMktPrvlg( BOOL * pFrstFlag, int32 connId, OrgMktPrvlg* pDataOut);
////Delete Method
//ResCodeT DeleteAllOrgMktPrvlg(int32 connId);
//ResCodeT DeleteOrgMktPrvlg(int32 connId, OrgMktPrvlgKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _ORG_MKT_PRVLG_DB_ */
