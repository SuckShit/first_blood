/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _MKT_ST_CFG_DB_
#define _MKT_ST_CFG_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct MktStCfgDbS {
    int32  mktStCfgId;
    char  mktSt[8];
    char  strtTm[50];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  nextStrtTm[50];
    char  sendF[8];
} MktStCfg;

typedef struct MktStCfgCntS {
    int32  count;
} MktStCfgCntT;


typedef struct recMktStCfgKey{
    int32 mktStCfgId;
}MktStCfgKey;


typedef struct recMktStCfgKeyList{
    int32 keyRow;
    int32* mktStCfgIdLst;
}MktStCfgKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertMktStCfg(int32 connId, MktStCfg* pData);
//ResCodeT UpdateMktStCfgByKey(int32 connId, MktStCfgKey* pKey, MktStCfg* pData, MktStCfgUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertMktStCfg(int32 connId, MktStCfgMulti* pData);
////Update Method
ResCodeT UpdateMktStCfgByKey(int32 connId, MktStCfg* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateMktStCfgByKey(int32 connId, MktStCfgKeyLst* pKeyList, MktStCfgMulti* pData, MktStCfgUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfMktStCfg(int32 connId, int32* pCntOut);
ResCodeT FetchNextMktStCfg( BOOL * pFrstFlag, int32 connId, MktStCfg* pDataOut);

ResCodeT GetMktStCfgByKey(int32 connId, uint64 ktStCfgId, MktStCfg* pDataOut);
////Delete Method
//ResCodeT DeleteAllMktStCfg(int32 connId);
//ResCodeT DeleteMktStCfg(int32 connId, MktStCfgKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _MKT_ST_CFG_DB_ */
