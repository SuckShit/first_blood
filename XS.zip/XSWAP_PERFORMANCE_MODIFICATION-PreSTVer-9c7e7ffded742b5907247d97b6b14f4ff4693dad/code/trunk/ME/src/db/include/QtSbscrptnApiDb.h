/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _QT_SBSCRPTN_API_DB_
#define _QT_SBSCRPTN_API_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define QT_SBSCRPTN_API_QT_SBSCRPTN_API_SRNO_IDX     0
#define QT_SBSCRPTN_API_USR_LGN_NM_IDX     1
#define QT_SBSCRPTN_API_ORG_ID_IDX     2
#define QT_SBSCRPTN_API_ORG_CD_IDX     3
#define QT_SBSCRPTN_API_MKT_TP_IDX     4
#define QT_SBSCRPTN_API_STL_TP_IDX     5
#define QT_SBSCRPTN_API_CNTRCT_CD_IDX     6
#define QT_SBSCRPTN_API_QT_TP_IDX     7
#define QT_SBSCRPTN_API_LVL_IDX     8
#define QT_SBSCRPTN_API_INSTRCTN_SEND_TM_IDX     9
#define QT_SBSCRPTN_API_CRT_TM_IDX     10
#define QT_SBSCRPTN_API_RQST_ID_IDX     11

#define QT_SBSCRPTN_API_VECT_LEN     GET_BIT_VECT_LEN(11)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct QtSbscrptnApiDbS {
    int32  qtSbscrptnApiSrno;
    char  usrLgnNm[300];
    int32  orgId;
    char  orgCd[50];
    char  mktTp[8];
    char  stlTp[8];
    char  cntrctCd[50];
    char  qtTp[8];
    char  lvl[50];
    char  instrctnSendTm[50];
    DbTimestampTypeT *  pInstrctnSendTm;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  rqstId[50];
} QtSbscrptnApi;

typedef struct QtSbscrptnApiCntS {
    int32  count;
} QtSbscrptnApiCntT;


typedef struct recQtSbscrptnApiKey{
    int32 qtSbscrptnApiSrno;
}QtSbscrptnApiKey;


typedef struct recQtSbscrptnApiKeyList{
    int32 keyRow;
    int32* qtSbscrptnApiSrnoLst;
}QtSbscrptnApiKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertQtSbscrptnApi(int32 connId, QtSbscrptnApi* pData);
//ResCodeT UpdateQtSbscrptnApiByKey(int32 connId, QtSbscrptnApiKey* pKey, QtSbscrptnApi* pData, QtSbscrptnApiUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertQtSbscrptnApi(int32 connId, QtSbscrptnApiMulti* pData);
////Update Method
ResCodeT UpdateQtSbscrptnApiByKey(int32 connId, QtSbscrptnApi* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateQtSbscrptnApiByKey(int32 connId, QtSbscrptnApiKeyLst* pKeyList, QtSbscrptnApiMulti* pData, QtSbscrptnApiUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntByUsrAndQttp(int32 connId, char* name, char* mktTp, char* qtTp, int32* pCntOut);
ResCodeT GetResultCntOfQtSbscrptnApi(int32 connId, int32* pCntOut);
ResCodeT FetchNextQtSbscrptnApi( BOOL * pFrstFlag, int32 connId, QtSbscrptnApi* pDataOut);
ResCodeT DeleteQtSbscrptnByUsrAndQttp(int32 connId, char* name, char* mktTp, char* qtTp);
ResCodeT DeleteQtSbscrptnApi(int32 connId, QtSbscrptnApi* pKey);
ResCodeT DeleteAllQtSbscrptnApi(int32 connId);
////Delete Method
//ResCodeT DeleteAllQtSbscrptnApi(int32 connId);
//ResCodeT DeleteQtSbscrptnApi(int32 connId, QtSbscrptnApiKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _QT_SBSCRPTN_API_DB_ */
