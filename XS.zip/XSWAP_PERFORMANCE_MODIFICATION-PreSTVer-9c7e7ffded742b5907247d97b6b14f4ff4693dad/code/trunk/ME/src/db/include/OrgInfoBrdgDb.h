/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ORG_INFO_BRDG_DB_
#define _ORG_INFO_BRDG_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct OrgInfoBrdgDbS {
    int32  orgSrno;
    int32  orgId;
    char  brdgOrgSt[8];
    int32  brdgOrgOrdr;
    char  brdgIntntnF[8];
    char  brdgPrvlgF[8];
    char  brdgPrvlgFNext[8];
    char  mdfySt[8];
    char  brdgPrvlgUpdTm[50];
    DbTimestampTypeT *  pBrdgPrvlgUpdTm;
    char  brdgPrvlgUpdUsrNm[100];
    char  usrLgnNm[100];
    char  dlrUpdTm[50];
    DbTimestampTypeT *  pDlrUpdTm;
    char  dlrUpdUsrNm[100];
    char  crdtOprtngSt[8];
    char  crdtOprtr[100];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} OrgInfoBrdg;

typedef struct OrgInfoBrdgCntS {
    int32  count;
} OrgInfoBrdgCntT;


typedef struct recOrgInfoBrdgKey{
    int32 orgSrno;
}OrgInfoBrdgKey;


typedef struct recOrgInfoBrdgKeyList{
    int32 keyRow;
    int32* orgSrnoLst;
}OrgInfoBrdgKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertOrgInfoBrdg(int32 connId, OrgInfoBrdg* pData);
//ResCodeT UpdateOrgInfoBrdgByKey(int32 connId, OrgInfoBrdgKey* pKey, OrgInfoBrdg* pData, OrgInfoBrdgUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertOrgInfoBrdg(int32 connId, OrgInfoBrdgMulti* pData);
////Update Method
ResCodeT UpdateOrgInfoBrdgByKey(int32 connId, OrgInfoBrdg* pData, vectorT * pKeyFlg, vectorT * pColFlg);
ResCodeT UpdateOrgInfoBrdgByKeyRpt(int32 connId, OrgInfoBrdg* pKeyData, OrgInfoBrdg* pNewData, vectorT * pKeyFlg, vectorT * pColFlg );
//ResCodeT BatchUpdateOrgInfoBrdgByKey(int32 connId, OrgInfoBrdgKeyLst* pKeyList, OrgInfoBrdgMulti* pData, OrgInfoBrdgUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfOrgInfoBrdg(int32 connId, int32* pCntOut);
ResCodeT FetchNextOrgInfoBrdg( BOOL * pFrstFlag, int32 connId, OrgInfoBrdg* pDataOut);
////Delete Method
//ResCodeT DeleteAllOrgInfoBrdg(int32 connId);
//ResCodeT DeleteOrgInfoBrdg(int32 connId, OrgInfoBrdgKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _ORG_INFO_BRDG_DB_ */
