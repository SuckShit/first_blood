/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _ACTIVE_INFO_DB_
#define _ACTIVE_INFO_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct ActiveInfoDbS {
    int32  setId;
    char  primaryHost[20];
    char  backupHost[20];
    char  haTime[10];
} ActiveInfo;

typedef struct ActiveInfoCntS {
    int32  count;
} ActiveInfoCntT;


typedef struct recActiveInfoKey{
    int32 setId;
}ActiveInfoKey;


typedef struct recActiveInfoKeyList{
    int32 keyRow;
    int32* setIdLst;
}ActiveInfoKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertActiveInfo(int32 connId, ActiveInfo* pData);
//ResCodeT UpdateActiveInfoByKey(int32 connId, ActiveInfoKey* pKey, ActiveInfo* pData, ActiveInfoUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertActiveInfo(int32 connId, ActiveInfoMulti* pData);
////Update Method
ResCodeT UpdateActiveInfoByKey(int32 connId, ActiveInfo* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateActiveInfoByKey(int32 connId, ActiveInfoKeyLst* pKeyList, ActiveInfoMulti* pData, ActiveInfoUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfActiveInfo(int32 connId, int32* pCntOut);
ResCodeT FetchNextActiveInfo( BOOL * pFrstFlag, int32 connId, ActiveInfo* pDataOut);
////Delete Method
//ResCodeT DeleteAllActiveInfo(int32 connId);
//ResCodeT DeleteActiveInfo(int32 connId, ActiveInfoKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _ACTIVE_INFO_DB_ */
