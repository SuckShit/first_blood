/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _BASE_PARAM_DB_
#define _BASE_PARAM_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct BaseParamDbS {
    int32  baseParamId;
    char  paramNm[100];
    char  paramVl[100];
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
    char  paramDesc[300];
} BaseParam;

typedef struct BaseParamCntS {
    int32  count;
} BaseParamCntT;


typedef struct recBaseParamKey{
    int32 baseParamId;
}BaseParamKey;


typedef struct recBaseParamKeyList{
    int32 keyRow;
    int32* baseParamIdLst;
}BaseParamKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertBaseParam(int32 connId, BaseParam* pData);
//ResCodeT UpdateBaseParamByKey(int32 connId, BaseParamKey* pKey, BaseParam* pData, BaseParamUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertBaseParam(int32 connId, BaseParamMulti* pData);
////Update Method
ResCodeT UpdateBaseParamByKey(int32 connId, BaseParam* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateBaseParamByKey(int32 connId, BaseParamKeyLst* pKeyList, BaseParamMulti* pData, BaseParamUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfBaseParam(int32 connId, int32* pCntOut);
ResCodeT FetchNextBaseParam( BOOL * pFrstFlag, int32 connId, BaseParam* pDataOut);
////Delete Method
//ResCodeT DeleteAllBaseParam(int32 connId);
//ResCodeT DeleteBaseParam(int32 connId, BaseParamKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _BASE_PARAM_DB_ */
