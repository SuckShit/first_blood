/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_PSTN_SBFCCP_DB_
#define _CNTRCT_PSTN_SBFCCP_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CNTRCT_PSTN_SBFCCP_CNTRCT_PSTN_SRNO_IDX     0
#define CNTRCT_PSTN_SBFCCP_ORG_ID_IDX     1
#define CNTRCT_PSTN_SBFCCP_CNTRCT_CD_IDX     2
#define CNTRCT_PSTN_SBFCCP_NET_PSTN_IDX     3
#define CNTRCT_PSTN_SBFCCP_BID_HOLD_AMNT_IDX     4
#define CNTRCT_PSTN_SBFCCP_OFR_HOLD_AMNT_IDX     5
#define CNTRCT_PSTN_SBFCCP_CRT_TM_IDX     6
#define CNTRCT_PSTN_SBFCCP_CRT_USR_NM_IDX     7
#define CNTRCT_PSTN_SBFCCP_UPD_TM_IDX     8
#define CNTRCT_PSTN_SBFCCP_UPD_USR_NM_IDX     9

#define CNTRCT_PSTN_SBFCCP_VECT_LEN     GET_BIT_VECT_LEN(9)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctPstnSbfccpDbS {
    int32  cntrctPstnSrno;
    int32  orgId;
    char  cntrctCd[50];
    double  netPstn;
    double  bidHoldAmnt;
    double  ofrHoldAmnt;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CntrctPstnSbfccp;

typedef struct CntrctPstnSbfccpCntS {
    int32  count;
} CntrctPstnSbfccpCntT;


typedef struct recCntrctPstnSbfccpKey{
    int32 cntrctPstnSrno;
}CntrctPstnSbfccpKey;


typedef struct recCntrctPstnSbfccpKeyList{
    int32 keyRow;
    int32* cntrctPstnSrnoLst;
}CntrctPstnSbfccpKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctPstnSbfccp(int32 connId, CntrctPstnSbfccp* pData);
//ResCodeT UpdateCntrctPstnSbfccpByKey(int32 connId, CntrctPstnSbfccpKey* pKey, CntrctPstnSbfccp* pData, CntrctPstnSbfccpUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctPstnSbfccp(int32 connId, CntrctPstnSbfccpMulti* pData);
////Update Method
ResCodeT UpdateCntrctPstnSbfccpByKey(int32 connId, CntrctPstnSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctPstnSbfccpByKey(int32 connId, CntrctPstnSbfccpKeyLst* pKeyList, CntrctPstnSbfccpMulti* pData, CntrctPstnSbfccpUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctPstnSbfccp(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctPstnSbfccp( BOOL * pFrstFlag, int32 connId, CntrctPstnSbfccp* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctPstnSbfccp(int32 connId);
//ResCodeT DeleteCntrctPstnSbfccp(int32 connId, CntrctPstnSbfccpKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_PSTN_SBFCCP_DB_ */
