/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _USR_LGN_HSTRY_DB_
#define _USR_LGN_HSTRY_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#include "msg_common_value.h"

#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct UsrLgnHstryDbS {
    int32  lgnSrno;
    char  usrNm[MAX_USR_NM_LENTH];
    char  oprtTp[MAX_OPRT_TP_LENTH];
    char  lgnIp[MAX_IP_LENTH];
    char  oprtTm[MAX_TIME_LENGTH];
    DbTimestampTypeT *  pOprtTm;
} UsrLgnHstry;

typedef struct UsrLgnHstryCntS {
    int32  count;
} UsrLgnHstryCntT;


typedef struct recUsrLgnHstryKey{
    int32 lgnSrno;
}UsrLgnHstryKey;


typedef struct recUsrLgnHstryKeyList{
    int32 keyRow;
    int32* lgnSrnoLst;
}UsrLgnHstryKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertUsrLgnHstry(int32 connId, UsrLgnHstry* pData);
//ResCodeT UpdateUsrLgnHstryByKey(int32 connId, UsrLgnHstryKey* pKey, UsrLgnHstry* pData, UsrLgnHstryUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertUsrLgnHstry(int32 connId, UsrLgnHstryMulti* pData);
////Update Method
ResCodeT UpdateUsrLgnHstryByKey(int32 connId, UsrLgnHstry* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateUsrLgnHstryByKey(int32 connId, UsrLgnHstryKeyLst* pKeyList, UsrLgnHstryMulti* pData, UsrLgnHstryUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfUsrLgnHstry(int32 connId, int32* pCntOut);
ResCodeT FetchNextUsrLgnHstry( BOOL * pFrstFlag, int32 connId, UsrLgnHstry* pDataOut);
////Delete Method
//ResCodeT DeleteAllUsrLgnHstry(int32 connId);
//ResCodeT DeleteUsrLgnHstry(int32 connId, UsrLgnHstryKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _USR_LGN_HSTRY_DB_ */
