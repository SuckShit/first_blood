/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CNTRCT_REF_PRC_HSTRY_SIRS_DB_
#define _CNTRCT_REF_PRC_HSTRY_SIRS_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CNTRCT_REF_PRC_HSTRY_SIRS_CNTRCT_REF_PRC_SRNO_IDX     0
#define CNTRCT_REF_PRC_HSTRY_SIRS_BTCH_TM_IDX     1
#define CNTRCT_REF_PRC_HSTRY_SIRS_CNTRCT_CD_IDX     2
#define CNTRCT_REF_PRC_HSTRY_SIRS_REF_PRC_DT_IDX     3
#define CNTRCT_REF_PRC_HSTRY_SIRS_REF_PRC_IDX     4
#define CNTRCT_REF_PRC_HSTRY_SIRS_CRT_TM_IDX     5
#define CNTRCT_REF_PRC_HSTRY_SIRS_CRT_USR_NM_IDX     6
#define CNTRCT_REF_PRC_HSTRY_SIRS_UPD_TM_IDX     7
#define CNTRCT_REF_PRC_HSTRY_SIRS_UPD_USR_NM_IDX     8

#define CNTRCT_REF_PRC_HSTRY_SIRS_VECT_LEN     GET_BIT_VECT_LEN(8)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CntrctRefPrcHstrySirsDbS {
    int32  cntrctRefPrcSrno;
    char  btchTm[50];
    DbTimestampTypeT *  pBtchTm;
    char  cntrctCd[50];
    char  refPrcDt[50];
    DbDateTypeT *  pRefPrcDt;
    double  refPrc;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CntrctRefPrcHstrySirs;

typedef struct CntrctRefPrcHstrySirsCntS {
    int32  count;
} CntrctRefPrcHstrySirsCntT;


typedef struct recCntrctRefPrcHstrySirsKey{
    int32 cntrctRefPrcSrno;
}CntrctRefPrcHstrySirsKey;


typedef struct recCntrctRefPrcHstrySirsKeyList{
    int32 keyRow;
    int32* cntrctRefPrcSrnoLst;
}CntrctRefPrcHstrySirsKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCntrctRefPrcHstrySirs(int32 connId, CntrctRefPrcHstrySirs* pData);
//ResCodeT UpdateCntrctRefPrcHstrySirsByKey(int32 connId, CntrctRefPrcHstrySirsKey* pKey, CntrctRefPrcHstrySirs* pData, CntrctRefPrcHstrySirsUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCntrctRefPrcHstrySirs(int32 connId, CntrctRefPrcHstrySirsMulti* pData);
////Update Method
ResCodeT UpdateCntrctRefPrcHstrySirsByKey(int32 connId, CntrctRefPrcHstrySirs* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCntrctRefPrcHstrySirsByKey(int32 connId, CntrctRefPrcHstrySirsKeyLst* pKeyList, CntrctRefPrcHstrySirsMulti* pData, CntrctRefPrcHstrySirsUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCntrctRefPrcHstrySirs(int32 connId, int32* pCntOut);
ResCodeT FetchNextCntrctRefPrcHstrySirs( BOOL * pFrstFlag, int32 connId, CntrctRefPrcHstrySirs* pDataOut);
////Delete Method
//ResCodeT DeleteAllCntrctRefPrcHstrySirs(int32 connId);
//ResCodeT DeleteCntrctRefPrcHstrySirs(int32 connId, CntrctRefPrcHstrySirsKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CNTRCT_REF_PRC_HSTRY_SIRS_DB_ */
