/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CRDT_DL_AMNT_DB_
#define _CRDT_DL_AMNT_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CRDT_DL_AMNT_CRDT_SRNO_IDX     0
#define CRDT_DL_AMNT_CRDT_ID_IDX     1
#define CRDT_DL_AMNT_CRDT_ORG_ID_IDX     2
#define CRDT_DL_AMNT_CRDTD_ORG_ID_IDX     3
#define CRDT_DL_AMNT_CNTRCT_NM_IDX     4
#define CRDT_DL_AMNT_DL_AMNT_IDX     5
#define CRDT_DL_AMNT_UPD_TM_IDX     6

#define CRDT_DL_AMNT_VECT_LEN     GET_BIT_VECT_LEN(6)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CrdtDlAmntDbS {
    int32  crdtSrno;
    int32  crdtId;
    int32  crdtOrgId;
    int32  crdtdOrgId;
    char  cntrctNm[50];
    double  dlAmnt;
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
} CrdtDlAmnt;

typedef struct CrdtDlAmntCntS {
    int32  count;
} CrdtDlAmntCntT;


typedef struct recCrdtDlAmntKey{
    int32 crdtSrno;
}CrdtDlAmntKey;


typedef struct recCrdtDlAmntKeyList{
    int32 keyRow;
    int32* crdtSrnoLst;
}CrdtDlAmntKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCrdtDlAmnt(int32 connId, CrdtDlAmnt* pData);
//ResCodeT UpdateCrdtDlAmntByKey(int32 connId, CrdtDlAmntKey* pKey, CrdtDlAmnt* pData, CrdtDlAmntUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCrdtDlAmnt(int32 connId, CrdtDlAmntMulti* pData);
////Update Method
ResCodeT UpdateCrdtDlAmntByKey(int32 connId, CrdtDlAmnt* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCrdtDlAmntByKey(int32 connId, CrdtDlAmntKeyLst* pKeyList, CrdtDlAmntMulti* pData, CrdtDlAmntUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCrdtDlAmnt(int32 connId, int32* pCntOut);
ResCodeT FetchNextCrdtDlAmnt( BOOL * pFrstFlag, int32 connId, CrdtDlAmnt* pDataOut);
////Delete Method
//ResCodeT DeleteAllCrdtDlAmnt(int32 connId);
//ResCodeT DeleteCrdtDlAmnt(int32 connId, CrdtDlAmntKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CRDT_DL_AMNT_DB_ */
