/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _PRCS_TXN_ID_TBL_DB_
#define _PRCS_TXN_ID_TBL_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define PRCS_TXN_IDTBL_SET_ID_IDX     0
#define PRCS_TXN_IDTBL_KEY_VALUE_IDX     1

#define PRCS_TXN_IDTBL_VECT_LEN     GET_BIT_VECT_LEN(1)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct PrcsTxnIdtblDbS {
    int32  setId;
    int32  keyValue;
} PrcsTxnIdtbl;

typedef struct PrcsTxnIdtblCntS {
    int32  count;
} PrcsTxnIdtblCntT;


typedef struct recPrcsTxnIdtblKey{
    int32 setId;
}PrcsTxnIdtblKey;


typedef struct recPrcsTxnIdtblKeyList{
    int32 keyRow;
    int32* setIdLst;
}PrcsTxnIdtblKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertPrcsTxnIdtbl(int32 connId, PrcsTxnIdtbl* pData);
//ResCodeT UpdatePrcsTxnIdtblByKey(int32 connId, PrcsTxnIdtblKey* pKey, PrcsTxnIdtbl* pData, PrcsTxnIdtblUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertPrcsTxnIdtbl(int32 connId, PrcsTxnIdtblMulti* pData);
////Update Method
ResCodeT UpdatePrcsTxnIdtblByKey(int32 connId, PrcsTxnIdtbl* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdatePrcsTxnIdtblByKey(int32 connId, PrcsTxnIdtblKeyLst* pKeyList, PrcsTxnIdtblMulti* pData, PrcsTxnIdtblUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfPrcsTxnIdtbl(int32 connId, int32* pCntOut);
ResCodeT FetchNextPrcsTxnIdtbl( BOOL * pFrstFlag, int32 connId, PrcsTxnIdtbl* pDataOut);
ResCodeT SelectPrcsTxnIdtblByKey(int32 connId, PrcsTxnIdtblKey* pKey, int32* pCntOut);
////Delete Method
//ResCodeT DeleteAllPrcsTxnIdtbl(int32 connId);
//ResCodeT DeletePrcsTxnIdtbl(int32 connId, PrcsTxnIdtblKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _PRCS_TXN_ID_TBL_DB_ */
