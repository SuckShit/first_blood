/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CRDT_SBFCCP_DB_
#define _CRDT_SBFCCP_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

#define CRDT_SBFCCP_CRDT_ID_IDX     0
#define CRDT_SBFCCP_ORG_ID_IDX     1
#define CRDT_SBFCCP_CLS_PSTN_F_IDX     2
#define CRDT_SBFCCP_LMT_PSTN_F_IDX     3
#define CRDT_SBFCCP_ST_IDX     4
#define CRDT_SBFCCP_INTL_AMNT_IDX     5
#define CRDT_SBFCCP_BID_INTL_AMNT_IDX     6
#define CRDT_SBFCCP_BID_USED_AMNT_IDX     7
#define CRDT_SBFCCP_BID_HOLD_AMNT_IDX     8
#define CRDT_SBFCCP_BID_RMN_AMNT_IDX     9
#define CRDT_SBFCCP_OFR_INTL_AMNT_IDX     10
#define CRDT_SBFCCP_OFR_USED_AMNT_IDX     11
#define CRDT_SBFCCP_OFR_HOLD_AMNT_IDX     12
#define CRDT_SBFCCP_OFR_RMN_AMNT_IDX     13
#define CRDT_SBFCCP_CRT_TM_IDX     14
#define CRDT_SBFCCP_CRT_USR_NM_IDX     15
#define CRDT_SBFCCP_UPD_TM_IDX     16
#define CRDT_SBFCCP_UPD_USR_NM_IDX     17

#define CRDT_SBFCCP_VECT_LEN     GET_BIT_VECT_LEN(17)

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CrdtSbfccpDbS {
    int32  crdtId;
    int32  orgId;
    char  clsPstnF[8];
    char  lmtPstnF[8];
    char  st[8];
    double  intlAmnt;
    double  bidIntlAmnt;
    double  bidUsedAmnt;
    double  bidHoldAmnt;
    double  bidRmnAmnt;
    double  ofrIntlAmnt;
    double  ofrUsedAmnt;
    double  ofrHoldAmnt;
    double  ofrRmnAmnt;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CrdtSbfccp;

typedef struct CrdtSbfccpCntS {
    int32  count;
} CrdtSbfccpCntT;


typedef struct recCrdtSbfccpKey{
    int32 crdtId;
}CrdtSbfccpKey;


typedef struct recCrdtSbfccpKeyList{
    int32 keyRow;
    int32* crdtIdLst;
}CrdtSbfccpKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCrdtSbfccp(int32 connId, CrdtSbfccp* pData);
//ResCodeT UpdateCrdtSbfccpByKey(int32 connId, CrdtSbfccpKey* pKey, CrdtSbfccp* pData, CrdtSbfccpUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCrdtSbfccp(int32 connId, CrdtSbfccpMulti* pData);
////Update Method
ResCodeT UpdateCrdtSbfccpByKey(int32 connId, CrdtSbfccp* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCrdtSbfccpByKey(int32 connId, CrdtSbfccpKeyLst* pKeyList, CrdtSbfccpMulti* pData, CrdtSbfccpUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCrdtSbfccp(int32 connId, int32* pCntOut);
ResCodeT FetchNextCrdtSbfccp( BOOL * pFrstFlag, int32 connId, CrdtSbfccp* pDataOut);
////Delete Method
//ResCodeT DeleteAllCrdtSbfccp(int32 connId);
//ResCodeT DeleteCrdtSbfccp(int32 connId, CrdtSbfccpKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CRDT_SBFCCP_DB_ */
