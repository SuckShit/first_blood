/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _CRDT_BRDG_DB_
#define _CRDT_BRDG_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct CrdtBrdgDbS {
    int32  crdtBrdgSrno;
    int32  brdgOrgId;
    int32  orgId;
    char  st[8];
    char  brdgRlF[8];
    double  brdgFee;
    int32  crdtTerm;
    char  crtTm[50];
    DbTimestampTypeT *  pCrtTm;
    char  crtUsrNm[100];
    char  updTm[50];
    DbTimestampTypeT *  pUpdTm;
    char  updUsrNm[100];
} CrdtBrdg;

typedef struct CrdtBrdgCntS {
    int32  count;
} CrdtBrdgCntT;


typedef struct recCrdtBrdgKey{
    int32 crdtBrdgSrno;
}CrdtBrdgKey;


typedef struct recCrdtBrdgKeyList{
    int32 keyRow;
    int32* crdtBrdgSrnoLst;
}CrdtBrdgKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertCrdtBrdg(int32 connId, CrdtBrdg* pData);
//ResCodeT UpdateCrdtBrdgByKey(int32 connId, CrdtBrdgKey* pKey, CrdtBrdg* pData, CrdtBrdgUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertCrdtBrdg(int32 connId, CrdtBrdgMulti* pData);
////Update Method
ResCodeT UpdateCrdtBrdgByKey(int32 connId, CrdtBrdg* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateCrdtBrdgByKey(int32 connId, CrdtBrdgKeyLst* pKeyList, CrdtBrdgMulti* pData, CrdtBrdgUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfCrdtBrdg(int32 connId, int32* pCntOut);
ResCodeT FetchNextCrdtBrdg( BOOL * pFrstFlag, int32 connId, CrdtBrdg* pDataOut);
////Delete Method
//ResCodeT DeleteAllCrdtBrdg(int32 connId);
//ResCodeT DeleteCrdtBrdg(int32 connId, CrdtBrdgKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _CRDT_BRDG_DB_ */
