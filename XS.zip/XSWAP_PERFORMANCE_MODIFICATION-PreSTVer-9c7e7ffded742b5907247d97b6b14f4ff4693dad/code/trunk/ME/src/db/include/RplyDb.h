/***
Created on sometimes
@author: No One
@version $ID
***/

#ifndef _RPLY_DB_
#define _RPLY_DB_

/***********************************************************************************************
**
**   Header Files                                                                               
**
***********************************************************************************************/
/* Project Header Files */
#include "data_type.h"
#include "db_comm.h"
#ifdef _cplusplus
extern "C" {
#endif

/***********************************************************************************************
**
**   Type Defination                                                                            
**
***********************************************************************************************/

/***********************************************************************************************
**
**   Macro                                                                                      
**
************************************************************************************************/

/***********************************************************************************************
**
**   Structure                                                                                  
**
************************************************************************************************/
typedef struct RplyDbS {
    char  rplyKey[52];
    int32  keyValue;
} Rply;

typedef struct RplyCntS {
    int32  count;
} RplyCntT;


typedef struct recRplyKey{
    char rplyKey[52];
}RplyKey;


typedef struct recRplyKeyList{
    int32 keyRow;
    char** rplyKeyLst;
}RplyKeyLst;
/***********************************************************************************************
**
**   Global Variable                                                                            
**
************************************************************************************************/

/***********************************************************************************************
**
**   Function Declaration                                                                           
**
************************************************************************************************/
//Insert Method
ResCodeT InsertRply(int32 connId, Rply* pData);
//ResCodeT UpdateRplyByKey(int32 connId, RplyKey* pKey, Rply* pData, RplyUpdFlag* pUpdFlag, int32 dataCol);
//ResCodeT BatchInsertRply(int32 connId, RplyMulti* pData);
////Update Method
ResCodeT UpdateRplyByKey(int32 connId, Rply* pData, vectorT * pKeyFlg, vectorT * pColFlg);
//ResCodeT BatchUpdateRplyByKey(int32 connId, RplyKeyLst* pKeyList, RplyMulti* pData, RplyUpdFlag* pUpdFlag, int32 dataCol);
////Select Method
ResCodeT GetResultCntOfRply(int32 connId, int32* pCntOut);
ResCodeT FetchNextRply( BOOL * pFrstFlag, int32 connId, Rply* pDataOut);
ResCodeT SelectRplyByKey(int32 connId, RplyKey* pKey, int32* pCntOut);
////Delete Method
//ResCodeT DeleteAllRply(int32 connId);
//ResCodeT DeleteRply(int32 connId, RplyKey* pKey);
#ifdef _cplusplus
}
#endif

#endif /* _RPLY_DB_ */
