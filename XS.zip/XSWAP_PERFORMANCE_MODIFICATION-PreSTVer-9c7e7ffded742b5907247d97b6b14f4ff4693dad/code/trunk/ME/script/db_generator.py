import re
import glob
import os,sys


fileList = []
output = []
sqlQuery = []
columnName = []
columnNameFstUp = []
sqlColumn = []
tempTableNm = [] 
dataType = []
nullable = []
length = []
hFile = []
cFile = []
seq = []
key = []

def h_generator(fileName,tableName):
    sqlTableNm = tableName
    tempTableNm = tableName.split('_')
    tableName = ''
    for f in range(0,len(tempTableNm)):
        tableName = tableName+tempTableNm[f].capitalize()
    print(tableName)
    
    f = open(fileName,'rU')    
    for line in f:
        cells = line.split( "," )
        output.append( ( cells[ 0 ], cells[ 1 ], cells[ 2 ], cells[ 3 ] ,cells[ 4 ]) )
    f.close()
    
    for o in range(1,len(output)):
        columnTemp = output[o][0].replace('"','')
        tempList = columnTemp.split('_')
        columnTemp = tempList[0].lower()
        columnTemp2 = tempList[0].capitalize()
        for oo in range(1,len(tempList)):
        	columnTemp2 = columnTemp2+tempList[oo].capitalize()
        	columnTemp = columnTemp+tempList[oo].capitalize()

        columnNameFstUp.append(columnTemp2)
        columnName.append(columnTemp)
        sqlColumn.append(output[o][0].replace('"',''))
        key.append(output[o][1].replace('"',''))
        dataType.append(output[o][2].replace('"',''))        
        nullable.append(output[o][3].replace('"',''))
        seq.append(output[o][4].replace('"',''))
    print(columnNameFstUp)
    for l in range(0,len(dataType)):
        temp = re.search(r'\d+', dataType[l])
        if temp is None:
            
            length.append(' ')         
        else:
            temp = re.search(r'\d+', re.split('[()]',dataType[l])[1])
            length.append(int(temp.group()))
    #----------------------------------------------------------------------------------------------------------
    #-----------------------------------H File Begining--------------------------------------------------------
    #----------------------------------------------------------------------------------------------------------
    
    #-----------------------------------Include File-----------------------------------------------------------
    hFile.append('/***')
    hFile.append('Created on sometimes')
    hFile.append('@author: No One')
    hFile.append('@version $ID')
    hFile.append('***/\n')
    
    hFile.append('#ifndef _'+sqlTableNm+'_DB_')
    hFile.append('#define _'+sqlTableNm+'_DB_\n')
    
    hFile.append('/***********************************************************************************************')
    hFile.append('**')
    hFile.append('**   Header Files                                                                               ')
    hFile.append('**')
    hFile.append('***********************************************************************************************/')  
    hFile.append('/* Project Header Files */')
    hFile.append('#include "data_type.h"')
    
    hFile.append('#ifdef _cplusplus')
    hFile.append('extern "C" {')
    hFile.append('#endif\n')
    
    hFile.append('/***********************************************************************************************')
    hFile.append('**')
    hFile.append('**   Type Defination                                                                            ')
    hFile.append('**')
    hFile.append('***********************************************************************************************/\n')
    
    hFile.append('/***********************************************************************************************')
    hFile.append('**')
    hFile.append('**   Macro                                                                                      ')
    hFile.append('**')
    hFile.append('************************************************************************************************/\n')
   
    hFile.append('/***********************************************************************************************')
    hFile.append('**')
    hFile.append('**   Structure                                                                                  ')
    hFile.append('**')
    hFile.append('************************************************************************************************/')   
    #-----------------------------------Declare struct----------------------------------------------------------
    hFile.append('typedef struct rec'+tableName+' {')
    for q in range (0,len(columnName)):
        if 'INTEGER' in dataType[q]:
            hFile.append('    int32  '+columnName[q]+';')
        if 'VARCHAR2' in dataType[q]:
            hFile.append("    char  "+columnName[q]+"["+str(length[q])+'];')
        if 'NUMBER' in dataType[q]:
            if ')' not in dataType[q]:
                hFile.append("    double  "+columnName[q]+';')
            else:
                hFile.append('    int32  '+columnName[q]+';')
        if 'FLOAT' in dataType[q]:
            hFile.append("    float  "+columnName[q]+';')
        if 'TIMESTAMP' in dataType[q]:
            hFile.append("    char  "+columnName[q]+'[50];')
        if 'DATE' in dataType[q]:
            hFile.append("    char  "+columnName[q]+"[50];")
        
    hFile.append('} '+tableName+';\n')
    
    hFile.append('typedef struct mulRec'+tableName+'{')
    hFile.append('    int32 dataRow;')
    for k in range(0,len(columnName)):
        if 'VARCHAR2' in dataType[k]:
            hFile.append('    char** '+columnName[k]+'Lst;')
            hFile.append('    int32 '+columnName[k]+'MaxSize;')
        if 'NUMBER' in dataType[k]:
            if ')' not in dataType[k]:
                hFile.append('    double* '+columnName[k]+'Lst;')
            else:
                hFile.append('    int32* '+columnName[k]+'Lst;')
        if 'TIMESTAMP' in dataType[k]:
            hFile.append('    char* '+columnName[k]+'Lst;')
            hFile.append('    int32 '+columnName[k]+'MaxSize;')
        if 'DATE' in dataType[k]:
            hFile.append('    char* '+columnName[k]+'Lst;')
            hFile.append('    int32 '+columnName[k]+'MaxSize;')
    hFile.append('}'+tableName+'Multi;\n')        
    hFile.append('typedef struct rec'+tableName+'UpdateFlag{')
    for kk in range(0, len(columnName)):
        hFile.append('    BOOL b'+columnNameFstUp[kk]+';')
    hFile.append('}'+tableName+'UpdFlag;')
    hFile.append('\n')
    for i in range(0,len(key)):
        if 'Y' in key[i]:
            hFile.append('typedef struct rec'+tableName+'Key{')
            for kk in range(0,len(columnName)):
                if 'Y' in key[kk]:
                    if 'NUMBER' in dataType[kk]:
                        hFile.append('    int32 '+columnName[kk]+';')
                    else:
                        hFile.append('    char '+columnName[kk]+'['+str(length[kk])+']'+';')
            hFile.append('}'+tableName+'Key;')
            hFile.append('\n')
    
            hFile.append('typedef struct rec'+tableName+'KeyList{')
            hFile.append('    int32 keyRow;')
            for kk in range(0,len(columnName)):
                if 'Y' in key[kk]:
                    if 'NUMBER' in dataType[kk]:
                        hFile.append('    int32* '+columnName[kk]+'Lst;')
                    else:
                        hFile.append('    char** '+columnName[kk]+'Lst;')
            hFile.append('}'+tableName+'KeyLst;')
            
    #-----------------------------------Declare function-----------------------------------------------------------
        
    hFile.append('/***********************************************************************************************')
    hFile.append('**')
    hFile.append('**   Global Variable                                                                            ')
    hFile.append('**')
    hFile.append('************************************************************************************************/\n')

    
    hFile.append('/***********************************************************************************************')
    hFile.append('**')
    hFile.append('**   Function Declaration                                                                           ')
    hFile.append('**')
    hFile.append('************************************************************************************************/')
    hFile.append('//Insert Method')
    hFile.append('ResCodeT Insert'+tableName+'(int32 connId, '+tableName+'* pData);')
    hFile.append('ResCodeT BatchInsert'+tableName+'(int32 connId, '+tableName+'Multi* pData);')
    hFile.append('//Update Method')
    hFile.append('ResCodeT Update'+tableName+'ByKey(int32 connId, '+tableName+'Key* pKey, '+tableName+'* pData, '+tableName+'UpdFlag* pUpdFlag, int32 dataCol);')
    hFile.append('ResCodeT BatchUpdate'+tableName+'ByKey(int32 connId, '+tableName+'KeyLst* pKeyList, '+tableName+'Multi* pData, '+tableName+'UpdFlag* pUpdFlag, int32 dataCol);')

    hFile.append('//Select Method')
    hFile.append('ResCodeT GetResultCntOf'+tableName+'(int32 connId, int32* pCntOut);')
    hFile.append('ResCodeT FetchNext'+tableName+'(int32 connId, '+tableName+'* pDataOut);')
    hFile.append('//Delete Method')
    hFile.append('ResCodeT DeleteAll'+tableName+'(int32 connId);')
    hFile.append('ResCodeT Delete'+tableName+'(int32 connId, '+tableName+'Key* pKey);')
    
    
    
    
    hFile.append('#ifdef _cplusplus')
    hFile.append('}')
    hFile.append('#endif\n')
    
    hFile.append('#endif /* _'+sqlTableNm+'_DB_ */') 
             
    h_file = open(tableName+"Db.h","w")
    for h in range(0,len(hFile)):
        h_file.write(hFile[h]+'\n')

    #----------------------------------------------------------------------------------------------------------
    #-----------------------------------Cpp File Begining--------------------------------------------------------
    #----------------------------------------------------------------------------------------------------------

def c_generator(tableName):
    #------------------------------------------------Define Library-------------------------------------------------
    sqlSelect = []
    sqlTableNm = tableName
    tempTableNm = tableName.split('_')
    tableName = ''
    for f in range(0,len(tempTableNm)):
        tableName = tableName+tempTableNm[f].capitalize()
    cFile.append('/***')
    cFile.append('Created on sometimes')
    cFile.append('@author: No One')
    cFile.append('@version $ID')
    cFile.append('***/\n')
    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Header Files                                                                               ')
    cFile.append('**')
    cFile.append('***********************************************************************************************/')
    cFile.append('/* Standard C hearder files   */')
    cFile.append('#include <stdio.h>')
    cFile.append('#include <stdlib.h>')
    cFile.append('#include <string.h>\n')
    cFile.append('/* Project Header Files */')
    cFile.append('#include "dbcomm.h"')
    cFile.append('#include "data_type.h"')
    cFile.append('#include "err_lib.h"')
    cFile.append('#include "common_macro.h"')
    cFile.append('#include "'+tableName+'Db.h"\n')
    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Type Defination                                                                            ')
    cFile.append('**')
    cFile.append('************************************************************************************************/')
    cFile.append('ResCodeT Select'+tableName+'(int32 connId);\n')
    cFile.append('ResCodeT MakeSqlUpdateDataPart(char* pSql, '+tableName+'UpdFlag* pFlag, '+tableName+'* pData, RsltCol* pResCol, int32* pOutCnt);')

    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Macro                                                                                      ')
    cFile.append('**')
    cFile.append('************************************************************************************************/\n')

    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Structure                                                                                  ')
    cFile.append('**')
    cFile.append('************************************************************************************************/\n')

    #-----------------------------------Define Global Variable-----------------------------------------------------------
    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Global Variable                                                                            ')
    cFile.append('**')
    cFile.append('************************************************************************************************/')
    
    cFile.append('static char gSqlInsert[] = "INSERT INTO '+sqlTableNm+' "')
    insColumn = '"('+','.join(sqlColumn)+') VALUES "'
    for ss in range(0,len(seq)):
        if seq[ss] == 'N' or seq[ss] == 'Y':
            sqlSelect.append(':'+sqlColumn[ss].lower())
        else:
            sqlSelect.append(sqlColumn[ss]+'.NEXTVAL')
    insValue = '"('+','.join(sqlSelect)+') ";'
    cFile.append(insColumn)
    cFile.append(insValue)
    cFile.append('static char gSqlDeleteAll[] = "DELETE FROM '+sqlTableNm+' ";')
    
    cFile.append('static char gSqlSelectCount[] = "SELECT COUNT(*) FROM '+sqlTableNm+' ";')

    for i in range(0, len(sqlColumn)):
        if 'VARCHAR2' in dataType[i] and 'Y' in nullable[i]:
            sqlQuery.append('NVL('+sqlColumn[i]+', \' \')')
        else:
            sqlQuery.append(sqlColumn[i])
    selectQuery = ','.join(sqlQuery)
    selectQuery = 'static char gSqlSelect[] = "SELECT '+selectQuery +' FROM '+sqlTableNm+' ";'
    
    cFile.append(selectQuery)
    cFile.append('static RsltCol gResColInsert[] = ')
    cFile.append('{')
    for tt in range(0,len(sqlColumn)):
        if 'VARCHAR2' in dataType[tt]:
            cFile.append('    {'+str(tt+1)+',  "'+sqlColumn[tt]+'",  ":'+sqlColumn[tt].lower()+'",  eVARCHAR2,  0,  0,  0 },')
        if 'NUMBER' in dataType[tt]:
            if 'NUMBER' in dataType[tt] and ')' not in dataType[tt]:
                cFile.append('    {'+str(tt+1)+',  "'+sqlColumn[tt]+'",  ":'+sqlColumn[tt].lower()+'",  eDOUBLE,  0,  0,  0 },')
            else:
                cFile.append('    {'+str(tt+1)+',  "'+sqlColumn[tt]+'",  ":'+sqlColumn[tt].lower()+'",  eINTEGER,  0,  0,  0 },')
        if 'DATE' in dataType[tt]:
            cFile.append('    {'+str(tt+1)+',  "'+sqlColumn[tt]+'",  ":'+sqlColumn[tt].lower()+'",  eDATE,  0,  0,  0 },')
        if 'TIMESTAMP' in dataType[tt]:
            cFile.append('    {'+str(tt+1)+',  "'+sqlColumn[tt]+'",  ":'+sqlColumn[tt].lower()+'",  eTIMESTAMP,  0,  0,  0 },')
    cFile.append('};')
    cFile.append('static int32 gColCntInst = sizeof(gResColInsert)/sizeof(gResColInsert[0]);\n')
    cFile.append('static RsltCol gResColUpdate[] = ')
    cFile.append('{')
    for ttt in range(0,len(sqlColumn)):
        if 'VARCHAR2' in dataType[ttt]:
            cFile.append('    {'+str(ttt+1)+',  "'+sqlColumn[ttt]+'",  ":'+sqlColumn[ttt].lower()+'",  eVARCHAR2,  0,  0,  0 },')
        if 'NUMBER' in dataType[ttt]:
            if 'NUMBER' in dataType[ttt] and ')' not in dataType[ttt]:
                cFile.append('    {'+str(ttt+1)+',  "'+sqlColumn[ttt]+'",  ":'+sqlColumn[ttt].lower()+'",  eDOUBLE,  0,  0,  0 },')
            else:
                cFile.append('    {'+str(ttt+1)+',  "'+sqlColumn[ttt]+'",  ":'+sqlColumn[ttt].lower()+'",  eINTEGER,  0,  0,  0 },')
        if 'DATE' in dataType[ttt]:
            cFile.append('    {'+str(ttt+1)+',  "'+sqlColumn[ttt]+'",  ":'+sqlColumn[ttt].lower()+'",  eDATE,  0,  0,  0 },')
        if 'TIMESTAMP' in dataType[ttt]:
            cFile.append('    {'+str(ttt+1)+',  "'+sqlColumn[ttt]+'",  ":'+sqlColumn[ttt].lower()+'",  eTIMESTAMP,  0,  0,  0 },')
    cFile.append('};')
    cFile.append('static int32 gColCntUpdt = sizeof(gResColUpdate)/sizeof(gResColUpdate[0]);\n')
    
    cFile.append('static RsltCol gResColDelete[] = ')
    cFile.append('{')
    print(key)
    for u in range(0, len(sqlColumn)):
        if 'Y' in key[u]:
            if 'VARCHAR2' in dataType[u]:
                cFile.append('    {'+str(u+1)+',  "'+sqlColumn[u]+'",  ":'+sqlColumn[u].lower()+'",  eVARCHAR2,  0,  0,  0 },')
            if 'NUMBER' in dataType[u]:
                if 'NUMBER' in dataType[u] and ')' not in dataType[u]:
                    cFile.append('    {'+str(u+1)+',  "'+sqlColumn[u]+'",  ":'+sqlColumn[u].lower()+'",  eDOUBLE,  0,  0,  0 },')
                else:
                    cFile.append('    {'+str(u+1)+',  "'+sqlColumn[u]+'",  ":'+sqlColumn[u].lower()+'",  eINTEGER,  0,  0,  0 },')
            if 'DATE' in dataType[u]:
                cFile.append('    {'+str(u+1)+',  "'+sqlColumn[u]+'",  ":'+sqlColumn[u].lower()+'",  eDATE,  0,  0,  0 },')
            if 'TIMESTAMP' in dataType[u]:
                cFile.append('    {'+str(u+1)+',  "'+sqlColumn[u]+'",  ":'+sqlColumn[u].lower()+'",  eTIMESTAMP,  0,  0,  0 },')
    cFile.append('};')
    cFile.append('static int32 gColCntDel = sizeof(gResColDelete)/sizeof(gResColDelete[0]);\n')
    
    
    cFile.append('static RsltCol gResColSelect[] = ')
    cFile.append('{')
    for t in range(0,len(sqlColumn)):
        if 'VARCHAR2' in dataType[t]:
            cFile.append('    {'+str(t+1)+',  "'+sqlColumn[t]+'",  ":'+sqlColumn[t].lower()+'",  eVARCHAR2,  0,  0,  0 },')
        if 'NUMBER' in dataType[t]:
            if 'NUMBER' in dataType[t] and ')' not in dataType[t]:
                cFile.append('    {'+str(t+1)+',  "'+sqlColumn[t]+'",  ":'+sqlColumn[t].lower()+'",  eDOUBLE,  0,  0,  0 },')
            else:
                cFile.append('    {'+str(t+1)+',  "'+sqlColumn[t]+'",  ":'+sqlColumn[t].lower()+'",  eINTEGER,  0,  0,  0 },')
        if 'DATE' in dataType[t]:
            cFile.append('    {'+str(t+1)+',  "'+sqlColumn[t]+'",  ":'+sqlColumn[t].lower()+'",  eDATE,  0,  0,  0 },')
        if 'TIMESTAMP' in dataType[t]:
            cFile.append('    {'+str(t+1)+',  "'+sqlColumn[t]+'",  ":'+sqlColumn[t].lower()+'",  eTIMESTAMP,  0,  0,  0 },')
    cFile.append('};')
    cFile.append('static int32 gColCntSel = sizeof(gResColSelect)/sizeof(gResColSelect[0]);\n')
    
    cFile.append('static int32 gSelectId = 0;')
    cFile.append('static BOOL gSelFlag = FALSE;')


    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Function Declaration                                                                           ')
    cFile.append('**')
    cFile.append('************************************************************************************************/\n')

      
    #-----------------------------------Function Begins-----------------------------------------------------------
      
    cFile.append('/***********************************************************************************************')
    cFile.append('**')
    cFile.append('**   Function Implementation                                                                           ')
    cFile.append('**')
    cFile.append('************************************************************************************************/\n')

    
    #--------------------------------Insert Function--------------------------------------------------
    cFile.append('ResCodeT Insert'+tableName+'(int32 connId, '+tableName+'* pData)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    BEGIN_FUNCTION( '+'"Insert'+tableName+'" );\n')
    
    cFile.append('    ASSERT( pData );')
    cFile.append('    if (!pData) {')
    cFile.append('        TRACE("Fucntion argument is null.");')
    cFile.append('        RAISE_ERR(ERR_INVLD_POINTER, RTN);')
    cFile.append('    }\n')
    for j in range(0,len(columnName)):
        if "VARCHAR2" in dataType[j] or "TIMESTAMP" in dataType[j] or "DATE" in dataType[j]:
            cFile.append('    if (!pData->'+columnName[j]+') strcpy(pData->'+columnName[j]+', " ");')
    cFile.append('\n')
    for ind in range(0,len(columnName)):
        if 'NUMBER' in dataType[ind]:
            cFile.append('    gResColInsert['+str(ind)+'].pDataValue = &pData->'+columnName[ind]+';')        
        else:
            cFile.append('    gResColInsert['+str(ind)+'].pDataValue = pData->'+columnName[ind]+';')
    cFile.append('\n    rc = DbCommSqlSingleExecute(connId, gSqlInsert, gResColInsert, &gColCntInst);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to execute data insert.");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
    
    #-----------------------------------Batch Insert Function---------------------------------------------

    cFile.append('ResCodeT BatchInsert'+tableName+'(int32 connId, '+tableName+'Multi* pData)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    int32 index = 0;')

    cFile.append('    BEGIN_FUNCTION("BatchInsert'+tableName+'");')
    cFile.append('    ASSERT( pData );')
    cFile.append('    if (!pData) {')
    cFile.append('        TRACE("Fucntion argument is null.");')
    cFile.append('        RAISE_ERR(ERR_INVLD_POINTER, RTN);')
    cFile.append('    }\n')
    for n in range(0,len(columnName)):
        if 'NUMBER' in dataType[n]:
            cFile.append('    gResColInsert['+str(n)+'].dataRow = pData->dataRow;')
            cFile.append('    gResColInsert['+str(n)+'].pDataValue = pData->'+columnName[n]+'Lst;\n')
        else:
            cFile.append('    gResColInsert['+str(n)+'].dataRow = pData->dataRow;')
            cFile.append('    gResColInsert['+str(n)+'].maxSize = pData->'+columnName[n]+'MaxSize;')
            cFile.append('    gResColInsert['+str(n)+'].pDataValue = pData->'+columnName[n]+'Lst;\n')
    
    cFile.append('    rc = DbCommSqlBatchExecute(connId, gSqlInsert, gResColInsert, &gColCntInst);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("failed to insert data");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
    
    #----------------------------------Update Function ------------------------------------
    cFile.append('ResCodeT Update'+tableName+'ByKey(int32 connId, '+tableName+'Key* pKey, '+tableName+'* pData, '+tableName+'UpdFlag* pUpdFlag, int32 dataCol)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    char sql[1000];')
    cFile.append('    RsltCol *resCol = NULL;')
    cFile.append('    int32 resNum = 0;\n')
    cFile.append('    int32 cntData = 0;')
    cFile.append('    BEGIN_FUNCTION("Update'+tableName+'ByKey");')
    cFile.append('    ASSERT(pKey && pData && pUpdFlag);')
    cFile.append('    if (!pKey || !pData || !pUpdFlag) {')
    cFile.append('        TRACE("function argument is null");')
    cFile.append('        RAISE_ERR(ERR_INVLD_POINTER,RTN);')
    cFile.append('    }\n')
    cFile.append('    resNum = dataCol+1;')
    cFile.append('    resCol = (RsltCol*)malloc(sizeof(RsltCol)*resNum);')
    cFile.append('    memset(sql, 0, sizeof(sql));')
    cFile.append('    strcpy(sql,"UPDATE '+sqlTableNm+' SET");\n')
    cFile.append('    //make update data\n')
    cFile.append('    rc = MakeSqlUpdateDataPart(sql, pUpdFlag, pData, resCol, &cntData);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to make update data");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')
    cFile.append('    //make where condition')
    cFile.append('    strcat(sql, "WHERE");')
    cFile.append('    sprintf(sql, "%s %s = %s ", sql, gResColUpdate[0].colName, gResColUpdate[0].bndName);')
    cFile.append('    strcpy(resCol[cntData].bndName, gResColUpdate[0].bndName);')
    cFile.append('    resCol[cntData].colType = gResColUpdate[0].colType;')
    if 'NUMBER' in dataType[0]:
        cFile.append('    resCol[cntData].pDataValue = &pKey->'+columnName[0]+';')
    else:
        cFile.append('    resCol[cntData].pDataValue = pKey->'+columnName[0]+';')
    cFile.append('    rc = DbCommSqlSingleExecute(connId, sql, resCol, &resNum);')
    cFile.append('    free(resCol);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to update data.");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')

    
#------------------------------------------------Batch Update----------------------------------------------
    cFile.append('ResCodeT BatchUpdate'+tableName+'ByKey(int32 connId, '+tableName+'KeyLst* pKeyList, '+tableName+'Multi* pData, '+tableName+'UpdFlag* pUpdFlag, int32 dataCol)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    char sql[1000];')
    cFile.append('    RsltCol *resCol = NULL;')
    cFile.append('    int32 resNum = 0;')
    cFile.append('    int32 index = 0;')
    cFile.append('\n')
    cFile.append('    BEGIN_FUNCTION("BatchUpdate'+tableName+'ByKey");')
    cFile.append('    ASSERT( pKeyList && pData &&pUpdFlag);')
    cFile.append('    if (!pKeyList ||!pData || !pUpdFlag) {')
    cFile.append('        TRACE("Function argument is null.");')
    cFile.append('        RAISE_ERR(ERR_INVLD_POINTER, RTN);')
    cFile.append('    }')
    cFile.append('    resNum = dataCol + 1;')
    cFile.append('    resCol = (RsltCol*)malloc(sizeof(RsltCol)*resNum);')
    cFile.append('    memset(sql, 0, sizeof(sql));')
    cFile.append('    strcpy(sql, "UPDATE '+sqlTableNm+' SET");')
    cFile.append('    //make update data\n')
    for n in range(0,len(columnName)):
        cFile.append('    if (pUpdFlag->b'+columnNameFstUp[n]+') {')
        cFile.append('        if (index != 0) {')
        cFile.append('            strcat(sql, ",");')
        cFile.append('        }')
        cFile.append('        sprintf(sql, "%s %s = %s ", sql, gResColUpdate['+str(n)+'].colName, gResColUpdate['+str(n)+'].bndName);')
        cFile.append('        strcpy(resCol[index].bndName, gResColUpdate['+str(n)+'].bndName);')
        cFile.append('        resCol[index].colType = gResColUpdate['+str(n)+'].colType;')
        if 'TIMESTAMP' in dataType[n] or 'DATE' in dataType[n] or 'VARCHAR2' in dataType[n]:
            cFile.append('        resCol[index].maxSize = pData->'+columnName[n]+'MaxSize;')
        cFile.append('        resCol[index].dataRow = pData->dataRow;')
        cFile.append('        resCol[index].pDataValue = pData->'+columnName[n]+'Lst;')
        cFile.append('        index++;')
        cFile.append('    }\n')
    cFile.append('    //make where condition')
    cFile.append('    strcat(sql, "WHERE");')
    cFile.append('    sprintf(sql, "%s %s = %s ", sql, gResColUpdate[0].colName, gResColUpdate[0].bndName);')
    cFile.append('    strcpy(resCol[index].bndName, gResColUpdate[0].bndName);')
    cFile.append('    resCol[index].colType = gResColUpdate[0].colType;')
    cFile.append('    resCol[index].dataRow = pKeyList->keyRow;')
    cFile.append('    resCol[index].pDataValue = pKeyList->'+columnName[0]+'Lst;\n')
    
    cFile.append('    rc = DbCommSqlBatchExecute(connId, sql, resCol, &resNum);')
    cFile.append('    free(resCol);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to delete data.");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
    
    #------------------------------------Delete Function-----------------------------------
    cFile.append('ResCodeT Delete'+tableName+'(int32 connId, '+tableName+'Key* pKey)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    char sql[1000];')
    cFile.append('    RsltCol resCol;\n')
    cFile.append('    int32 resNum = 0;')
    cFile.append('    BEGIN_FUNCTION("Delete'+tableName+'");')
    cFile.append('    ASSERT(pKey);')
    cFile.append('    if (!pKey) {')
    cFile.append('        TRACE("function argument is null.");')
    cFile.append('        RAISE_ERR(ERR_INVLD_POINTER,RTN);')
    cFile.append('    }\n')
    cFile.append('    memset(sql, 0, sizeof(sql));')
    cFile.append('    memset(&resCol, 0, sizeof(RsltCol));')
    cFile.append('    resNum = 1;\n')
    cFile.append('    //make where condition')
    cFile.append('    strcpy(sql, "DELETE FROM '+sqlTableNm+' WHERE");')
    cFile.append('    sprintf(sql, "%s %s = %s ", sql, gResColDelete[0].colName, gResColDelete[0].bndName);')
    cFile.append('    strcpy(resCol.bndName, gResColDelete[0].bndName);')
    cFile.append('    resCol.colType = gResColDelete[0].colType;')
    if 'NUMBER' in dataType[0]:
        cFile.append('    resCol.pDataValue = &pKey->'+columnName[0]+';\n')
    else:
        cFile.append('    resCol.pDataValue = pKey->'+columnName[0]+';\n')
    cFile.append('    rc = DbCommSqlSingleExecute(connId, sql, &resCol, &resNum);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to delete data.");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
#------------------------------------Delete ALL-------------------------------------
    cFile.append('ResCodeT DeleteAll'+tableName+'(int32 connId)')
    cFile.append('{\n')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    RsltCol resCol;')
    cFile.append('    int32 resNum = 0;')
    
    cFile.append('    BEGIN_FUNCTION("DeleteAll'+tableName+'");\n')
    cFile.append('    rc = DbCommSqlSingleExecute(connId, gSqlDeleteAll, &resCol, &resNum);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("failed to delete all data");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
    
    #----------------------------------Result Count Function-----------------------------------------
    cFile.append('ResCodeT GetResultCntOf'+tableName+'(int32 connId, int32* pCntOut)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    int32 iSelId = 0;')
    cFile.append('    RsltCol resCol;')
    cFile.append('    int32 resNum = 0;')
    cFile.append('    BEGIN_FUNCTION( '+'"GetResultCntOf'+tableName+'" );\n')

    cFile.append('    rc = DbCommSqlSelect(connId, gSqlSelectCount, &iSelId);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to select sql count");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')
  
    cFile.append('    resNum = 1;')
    cFile.append('    memset(&resCol,0,sizeof(RsltCol));')
    cFile.append('    resCol.colId = 1;')
    cFile.append('    resCol.colType = eINTEGER;')
    cFile.append('    resCol.pDataValue = pCntOut;') 
    cFile.append('    rc = DbCommSqlFetchNext(connId,iSelId,&resCol,&resNum);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("failed to fetch first result");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')

    cFile.append('EXIT_BLOCK();')
    cFile.append('RETURN_RESCODE;')
    cFile.append('}\n')
    
#--------------------------------------Fetch Next Function---------------------------------------------
    cFile.append('ResCodeT FetchNext'+tableName+'(int32 connId, '+tableName+'* pDataOut)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')

    cFile.append('    BEGIN_FUNCTION( '+'"FetchNext'+tableName+'" );\n')
    
    cFile.append('    if (!gSelFlag) {')
    cFile.append('        rc = Select'+tableName+'(connId);')
    cFile.append('        if (rc != NO_ERR) {')
    cFile.append('            RAISE_ERR(rc, RTN);')
    cFile.append('        }')
    cFile.append('    }\n')

    for qq in range(0,len(columnName)):
        if 'NUMBER' in dataType[qq]:
            cFile.append('    gResColSelect['+str(qq)+'].pDataValue = &pDataOut->'+columnName[qq]+';')
        else:
            cFile.append('    gResColSelect['+str(qq)+'].pDataValue = pDataOut->'+columnName[qq]+';')
    cFile.append('\n')        
    cFile.append('    rc = DbCommSqlFetchNext(connId, gSelectId, gResColSelect, &gColCntSel);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("fetching next record is done");')
    cFile.append('        gSelFlag = FALSE;')
    cFile.append('        SET_RESCODE(rc);')
    cFile.append('        RETURN_RESCODE; ')
    cFile.append('    }')
        
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
#--------------------------------------Select Function---------------------------------------------   
    cFile.append('ResCodeT Select'+tableName+'(int32 connId)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    int32 iSelId = 0;\n')
    
    cFile.append('    BEGIN_FUNCTION( '+'"Select'+tableName+'" );')
    cFile.append('    rc = DbCommSqlSelect(connId, gSqlSelect, &iSelId);')
    cFile.append('    if (rc != NO_ERR) {')
    cFile.append('        TRACE("Failed to execute sql select.");')
    cFile.append('        RAISE_ERR(rc, RTN);')
    cFile.append('    }\n')
    
    cFile.append('    gSelectId = iSelId;')
    cFile.append('    gSelFlag = TRUE;')
    
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}\n')
    
#----------------------------------Make Sql Update Data---------------------------------------
    cFile.append('ResCodeT MakeSqlUpdateDataPart(char* pSql, '+tableName+'UpdFlag* pFlag, '+tableName+'* pData, RsltCol* pResCol, int32* pOutCnt)')
    cFile.append('{')
    cFile.append('    ResCodeT rc = NO_ERR;')
    cFile.append('    int32 index = 0;')
    cFile.append('\n')
    cFile.append('    BEGIN_FUNCTION( "MakeSqlUpdateDataPart" );')
    cFile.append('    ASSERT( pSql && pFlag && pData && pResCol && pOutCnt);')
    cFile.append('    if (!pSql || !pFlag || !pData || !pResCol || !pOutCnt) {')
    cFile.append('        TRACE("Function argument is null.");')
    cFile.append('        RAISE_ERR(ERR_INVLD_POINTER, RTN);')
    cFile.append('    }')
    for n in range(0,len(columnName)):
        cFile.append('    if (pFlag->b'+columnNameFstUp[n]+') {')
        cFile.append('        if (index != 0) {')
        cFile.append('            strcat(pSql, ",");')
        cFile.append('        }')
        cFile.append('        sprintf(pSql, "%s %s = %s ", pSql, gResColUpdate['+str(n)+'].colName, gResColUpdate['+str(n)+'].bndName);')
        cFile.append('        strcpy(pResCol[index].bndName, gResColUpdate['+str(n)+'].bndName);')
        cFile.append('        pResCol[index].colType = gResColUpdate['+str(n)+'].colType;')
        
        if 'NUMBER' in dataType[n]:
            cFile.append('        pResCol[index].pDataValue = &pData->'+columnName[n]+';')
        else:
            cFile.append('        pResCol[index].pDataValue = pData->'+columnName[n]+';')
        cFile.append('        index++;')
        cFile.append('    }\n')
    cFile.append('    *pOutCnt = index;')
    cFile.append('    EXIT_BLOCK();')
    cFile.append('    RETURN_RESCODE;')
    cFile.append('}')
    
    
    
    
    c_file = open(tableName+"Db.cpp","w")
    for h in range(0,len(cFile)):
        c_file.write(cFile[h]+'\n')
    
  
for file in glob.glob("*.csv"):
    fileList.append(file)

for i in range(0,len(fileList)):
    fileName = fileList[i]
    tableName = fileList[i].split('.')[0]
    h_generator(fileName,tableName)
    c_generator(tableName)
    output.clear()
    sqlQuery.clear()
    sqlColumn.clear()
    seq.clear()
    columnName.clear()
    columnNameFstUp.clear()
    sqlColumn.clear()
    dataType.clear()
    nullable.clear()
    length.clear()
    key.clear()
    hFile.clear()
    cFile.clear()
    

    
