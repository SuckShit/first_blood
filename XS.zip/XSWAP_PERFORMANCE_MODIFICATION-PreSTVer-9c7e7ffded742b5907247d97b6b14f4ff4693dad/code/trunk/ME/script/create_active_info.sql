create table ACTIVE_INFO
(
    set_id          NUMBER(10) not null,
    primary_host    VARCHAR2(20) not null,
    backup_host     VARCHAR2(20) not null,
    ha_time         VARCHAR2(10) not null
)

tablespace TS_XSWAP_DATA
    pctfree     10
    initrans    1
    maxtrans    255
    storage
    (
        initial 64
        next    1
        minextents  1
        maxextents  unlimited
    );

alter table ACTIVE_INFO
    add constraint PK_ACTIVE_INFO primary key (set_id)
    using index
    tablespace TS_XSWAP_IND
    pctfree     10
    initrans    2
    maxtrans    255
    storage
    (
        initial 64K
        next    1M
        minextents  1
        maxextents  unlimited
    );
