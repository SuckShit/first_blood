import os
import sys
import codecs
from sys import argv
structNm = []
fileList = []
locationList = []
infoList = []
code = []
def chkSize(path):
  if '.cpp' in path or '.h' in path or '.c' in path:
        fileList.append(path.rsplit('/',1)[1])
        locationList.append(path)
  else:
    for path, subdirs, files in os.walk(path):
      for name in files:
        if ('.h' in name or '.c' in name or '.cpp' in name):
          fileList.append(name)
          locationList.append(os.path.join(path,name))
  for i in range(0,len(locationList)):
    file = codecs.open(locationList[i],'r',encoding = 'utf-8',errors = 'ignore')
    for num,line in enumerate(file,1):
      if "typedef struct" in line:
        structNm.append("struct "+line.split(" ")[2].strip())
        infoList.append(locationList[i].rsplit('/',1)[1]+" "+str(num))


def CodeGen():
  code.append("int32 StructSize(){\n\n")
  code.append("    int32 struSize["+str(len(structNm))+"];\n")
  code.append("    char* struNm["+str(len(structNm))+"];\n")
  for i in range(0,len(structNm)):
    code.append("    int32 res"+str(i)+" = sizeof("+structNm[i]+");\n")
    code.append("    struNm["+str(i)+"] = \""+structNm[i]+"\";\n")
    code.append("    struSize["+str(i)+"] = res"+str(i)+";\n")
    code.append
  code.append("    for(int32 i=0;i<"+str(len(structNm))+";i++){ \n")
  code.append("        if (struSize[i]%8 !=0) { \n")
  code.append("        printf(\"unqualified struct name is %s\",struNm[i]);\n")
  code.append("        }\n    }\n}")
  
  for ii in range (0,len(code)):
    print(code[ii])

  


path = argv[1]
chkSize(path)
CodeGen()