import glob
import os
import codecs
import sys
from lib.prettytable import PrettyTable
import re
from sys import argv

totalLine = []
invalidLine = []
blankLine = []
fileList = []
locationList = []
cFile = []
hFile = []
cppFile = []
cCode = []
cppCode = []
hCode = []
cInCode = []
cppInCode = []
hInCode= []
cBlankCode = []
hBlankCode = []
cppBlankCode = []


def formatChecker(path):

    if '.cpp' in path or '.h' in path or '.c' in path:
        fileList.append(path.rsplit('/',1)[1])
        locationList.append(path)
    else:
        for path, subdirs, files in os.walk(path):
            for name in files:
                if ('.h' in name or '.c' in name or '.cpp' in name) and '.pyc' not in name and '.pb.' not in name and 'test' not in name:
                    fileList.append(name)
                    locationList.append(os.path.join(path,name))
    for q in range(0,len(fileList)):
        if '.cpp' in fileList[q]:
        	  cppFile.append(fileList[q])
        elif '.h' in fileList[q]:
        	  hFile.append(fileList[q])
        elif '.c' in fileList[q]:
        	  cFile.append(fileList[q])
                
    for i in range(0,len(fileList)):
        tempList = []
        tempInvalidList = []
        tempCommList = []
        topLine = []
        errorList = []
        
        fileForTop = codecs.open(locationList[i],'r',encoding = 'utf-8',errors = 'ignore')
        file = codecs.open(locationList[i],'r',encoding = 'utf-8',errors = 'ignore')
        parsing = 'true'
        #print('\n-----------------------------------------------------------Checking ' +fileList[i]+'-------------------------------------------------------------------------\n')
        topLine = []
        
        for t in range(5):
            topLine.append(fileForTop.readlines())
        if '/***' not in topLine[0][0] or 'Created' not in topLine[0][1] or '@author' not in topLine[0][2] or '@version' not in topLine[0][3] or '***/' not in topLine[0][4]:
            print('Header declaration is improper')
            errorList.append('')
              
        for num,line in enumerate(file,1):
            tempList.append(line)
            totalLine.append(line)
            if '*/' in line and '/*' in line and (';' in line or '#define' in line or 'include' in line):
              parsing = 'true'
            else:
              if line.startswith('/*')or line.strip().endswith('*/'):
                parsing = 'false'

            if parsing == 'true':
                if str(line).startswith(' ') and not line.isspace() and not line.strip().startswith('//'):# check whether non-4n spaces in line
                    spaceNum = len(line) - len(line.lstrip())
                    if spaceNum % 4 != 0:
                        print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Non-4n spaces at the beginning',line.strip()))
                        errorList.append('')
                if '\t' in line and not line.isspace() and not line.strip().startswith('//'): # check whether tab in line
                    print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Having Tab in the line',line.strip()))
                    errorList.append('')
                    
                if 'printf' in line and 'sprintf' not in line and 'fprintf' not in line and 'snprintf' not in line and not line.isspace() and not line.strip().startswith('//'):
                    print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Having Printf in line',line.strip()))
                    errorList.append('')
                    
    ##            if '#define' in line: # check macro declaration format
    ##                line = line.lstrip()
    ##                temp = line.split(' ')
    ##                
    ##                if '(' in temp[1]:
    ##                    temp = temp[1].split('(',1)
    ##                    if not temp[0].isupper():
    ##                        print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Illegal Macro Declaration Format',line.strip()))
    ##                elif '"' in temp[1]:
    ##                    temp = temp[1].split('"',1)
    ##                    if not temp[0].isupper():
    ##                        print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Illegal Macro Declaration Format',line.strip()))
    ##                else:
    ##                    if not temp[1].isupper():
    ##                        print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Illegal Macro Declaration Format',line.strip()))
                        
                if (' if' in line or 'else if' in line) and '(' in line and ')' in line and not line.strip().startswith('//'):
                    if not line.split('if',1)[1].startswith(' '):
                        print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'No space after if ',line.strip()))
                        errorList.append('')
                        
                if 'while' in line:
                    if not line.split('while',1)[1].startswith((' '))and not line.strip().startswith('//'):
                        print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'No space after while ',line.strip()))
                        errorList.append('')
                        
                if 'ResCodeT ' in line and '(' in line and ')' in line and not line.strip().startswith('//'):
                    if line.startswith('static'):
                        tempLine = line.replace('static ','')  
                    elif line.startswith('extern'):
                        tempLine = line.replace('extern ','')
                    else:
                        tempLine = line

                    strr = (tempLine.split('(',1)[0].split(' ',1)[1])
                    strr =  re.sub('\d+','',strr)
                    
                    if strr.isalpha():
                        functionName = strr
                    else:
                        functionName = (tempLine.split('ResCodeT',1)[1].lstrip().split('(')[1]).replace('*','').lstrip()
                    functionName = re.sub('\d+','',functionName)
                    if not functionName[0].isupper():
                       print ('File name: %s; Line# %d; Error:%s; Code:%s'%(fileList[i],num,'Invalid Function Name Format',line.strip()))
                       errorList.append('')
                        
            if line.replace(' ','') in ['\n', '\r\n'] or parsing == 'false' or line.strip().startswith('//'):
                invalidLine.append(line)
                tempInvalidList.append(line)
            if line.replace(' ','') in ['\n', '\r\n']:
                blankLine.append(line)
                tempCommList.append(line)
            if line.strip().endswith('*/'):
                parsing = 'true'
        
        if '.c' in fileList[i]:
            for r in range(0,len(tempList)):
                cCode.append(tempList[r])
            for rr in range(0,len(tempInvalidList)):
                cInCode.append(tempInvalidList[rr])
            for rrr in range(0,len(tempCommList)):
                cBlankCode.append(tempCommList[rrr])
        if '.cpp' in fileList[i]:
           
            for r in range(0,len(tempList)):
                cppCode.append(tempList[r])
            for rr in range(0,len(tempInvalidList)):
                cppInCode.append(tempInvalidList[rr])
            for rrr in range(0,len(tempCommList)):
                cppBlankCode.append(tempCommList[rrr])
        if '.h' in fileList[i]:
            for r in range(0,len(tempList)):
                hCode.append(tempList[r])
            for rr in range(0,len(tempInvalidList)):
                hInCode.append(tempInvalidList[rr])
            for rrr in range(0,len(tempCommList)):
                hBlankCode.append(tempCommList[rrr])
        if len(errorList) > 0:
            xtable = PrettyTable(['Finishing checking '+fileList[i]])
            print(xtable)
        
    validLine = len(totalLine)-len(invalidLine)
    tFileAmt = len(cFile)+len(hFile)+len(cppFile)
    
    table = PrettyTable(["Cot/File","H File","CPP File","Overall"])
    table.add_row(["File Amount",str(len(hFile)),str(len(cppFile)),str(len(hFile)+len(cppFile))])
    table.add_row(["Valid Line",str(len(hCode)-len(hInCode)),str(len(cppCode)-len(cppInCode)),str(validLine)])
    table.add_row(["Comment Line",str(len(hInCode)-len(hBlankCode)),str(len(cppInCode)-len(cppBlankCode)),str(len(invalidLine)-len(blankLine))])
    table.add_row(["In Total",str(len(hCode)-len(hBlankCode)),str(len(cppCode)-len(cppBlankCode)),str(len(totalLine)-len(blankLine))])
    print(table)
    
    

path = argv[1]
formatChecker(path)

#print('\nThere are '+str(tFileAmt)+' files in total')
    #print('\nHaving '+str(len(cFile))+' .c Files, having '+str(len(hFile))+' .h files and having '+str(len(cppFile))+' .cpp files' )
    #print('\nValid line amount is '+str(validLine)+', comment or blank line amount is '+str(len(invalidLine)))

