#ifndef ISPTask_H
#define ISPTask_H
//#include "RESETLIST.h"

#include "RESETLIST.h"
#include "SPException.h"
#include <string>
#include <iostream>
#include <occi.h>
#include <iomanip>
#include <map>
#include <list>
#include "ConfigFile.h"
#include "DynamicLoader.h"
#include "SPParam.h"
#include "SpadeTimer.h"
/*
#include "BasicProtocol/AdminMsgDefine.h"
#include "IMIX20/AppMsgDefine.h"
*/

#include "IMIXT10/Comm/MsgDefine.h"
#include "IMIX20/Comm/MsgDefine.h"
#include "IMIX20/ImixMessageFactory.h"

#include "IMIX/BasicProtocol/BasicMessage.h"

#include "CFETS/SessionMessage.h"
#include "CFETS/SessionListener.h"

//#include "SPException.h"
//#include "TServerListener.h"



using namespace oracle::occi;
using namespace std;

typedef list<SPParam*> MsgList;

typedef list<ResultSet*> ResultSetList;

typedef map<string,string> SPNameMap; 

typedef map<Statement*,ResultSetList*>  SMNRSMap;

typedef map<string,ResultSetList*>  RSlistMap;

typedef list<RSlistMap*>  RSlistSet;


typedef list<IMIX::BasicMessage*> SENDMSGLIST;
//#define map<string,MsgList*> ProRetMap

typedef list<SpadeTimer* > TimerList;


class ISPTask
{
public:
	//virtual void ConnectDb(string user,string passwd,string db)=0;
	//virtual void CallProcedure(int msg)=0;
	virtual int OnSPStartPlus(const IMIX::BasicMessage& inMessage,MsgList* SPParamList)=0; 
    virtual int OnSPStopPlus(RESETLIST* RSnMap,SENDMSGLIST* pMSGLIST,MsgList* SPParamList,const IMIX::BasicMessage& inMessage,int ExceptionFlag)=0;
	virtual int ProcessException(SQLException& ex)=0;
	virtual int Initiate(MsgList* SPParamList)=0;
	virtual int DefineTimer(TimerList* lTimerList)=0;
	virtual int OnInitiateStop(RESETLIST* RSnMap)=0;
	virtual ~ISPTask(){};
};




#endif
