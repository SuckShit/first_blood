#pragma once


#include "DEP/Service.h"
#include "DEP/ServiceID.h"
#include "DEP/DEPTimer.h"
#include "SPADEListener.h"
#include "SpadeTimer.h"


using namespace CFETS;


//class ServerTimer;
class SPADEListener;
class ServerTimer : public DEP::DEPTimer {
public:
	
	ServerTimer(SPADEListener* pServerTimer,
		long startTime,
		long endTime,
		long interval,IMIX::BasicMessage* Msg);
	
	virtual ~ServerTimer();
	
	virtual void OnTimer();
	 
	IMIX::BasicMessage* GetMsg();
	
	void SetMsg(IMIX::BasicMessage* Msg);
	
	int GetInterval();
	
	void SetInterval(int Interval);

public:
	ServerTimer* m_pServerTimer;
	SPADEListener* m_pSPADEListener;
	//int m_Id;
	IMIX::BasicMessage* m_inMessage;
	int m_Interval;
	
};

