#ifndef PROCESSXML_H
#define PROCESSXML_H
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>

class ProcessXML
{
public:
    ProcessXML();

	~ProcessXML();

	void parseDoc(char *docname,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);

	void getReference (xmlDocPtr doc, xmlNodePtr cur,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);

	void getInput (xmlDocPtr doc, xmlNodePtr cur,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);

	void getParam (xmlDocPtr doc, xmlNodePtr cur,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);

	void getComponent (xmlDocPtr doc, xmlNodePtr cur,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);

	void getGroup(xmlDocPtr doc, xmlNodePtr cur,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);

	void getField (xmlDocPtr doc, xmlNodePtr cur,const IMIX::BasicMessage& inMessage,MsgList* SPParamList);




};
#endif