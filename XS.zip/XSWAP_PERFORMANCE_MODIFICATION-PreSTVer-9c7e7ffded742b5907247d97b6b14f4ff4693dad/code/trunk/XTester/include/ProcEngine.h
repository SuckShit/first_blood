#ifndef PROCENGINE_H
#define PROCENGINE_H 
//#pragma once
#include "dbdatactrl.h"

#include "ISPTask.h"
//#include "SPException.h"
#include <dbdatactrl.h>
#include <iostream>
//#include <occi.h>
#include <iomanip>
#include "SPHandle.h"
//#include "ProcessXML.h"
#include "UTILITY/logfile.h"
#include "UTILITY/PubFunc.h"
#include "SPADE_error_def.h"
 
//using namespace oracle::occi;
using namespace std;

//typedef map<Statement*,int> SMNRSMap;
typedef map<Statement*,ResultSetList*>  SMNRSMap;

class ProcEngine 
{
public:
   
	ProcEngine(const string& FilePath);
 
   //void ConnectDb(string user,string passwd,string db);

   ~ProcEngine();

   

   int SPStartPlus(const IMIX::BasicMessage& inMessage,MsgList* SPParamList); 

   int CallProcedure(MsgList* Param,DBStruct* pDbCon,RESETLIST* pRESETLIST);
 
  // void SPStart(int msg,string strFuname); 
   
   int SPStopPlus(RESETLIST* RSnMap,SENDMSGLIST* pMSGLIST,MsgList* SPParamList,const IMIX::BasicMessage& inMessage,int ExceptionFlag); 

   int FreeSPResource(RESETLIST* outRSList);

   int Initiate(MsgList* SPParamList);

   int OnInitiateStop(RESETLIST* RSnMap);
	
   int DefineTimer(TimerList* lTimerList);

   int SPStartXML(const IMIX::BasicMessage& inMessage,MsgList* SPParamList,string XmlDoc); 

   int Init();


private:

    //��������so
    map<string,string> * m_plibload;
    map<string,string>::iterator m_libiter;
    ConfigFile m_configFile;
	ISPTask* m_pCommSo;
	DynamicLoader* m_plibMsgAdapter; 
    
	SPHandle* m_pSPHandle;
	string m_SoPath;

	int m_flag;
	

 };


#endif


