#ifndef SPADETIMER_H
#define SPADETIMER_H
#include "CFETS/SessionListener.h"
#include "CFETS/Application.h"
#include "IMIXT10/Comm/MsgDefine.h"
#include "IMIX20/Comm/MsgDefine.h"
#include "IMIX20/ImixMessageFactory.h"

class SpadeTimer
{
public:

	SpadeTimer(IMIX::BasicMessage* iId,int iInterval)
	{
     m_inMessage=iId;
	 m_Interval=iInterval;
       }

	~SpadeTimer();
	 IMIX::BasicMessage* GetMsg();
	 void SetMsg(IMIX::BasicMessage* Id);
	 int GetInterval();
	 void SetInterval(int Interval);
private:
    //int m_Id;
	IMIX::BasicMessage* m_inMessage;
	int m_Interval;
};
#endif