#include "ServerTimer.h"

ServerTimer::ServerTimer(SPADEListener* pSessionListener,
                           long startTime,
                           long endTime,
                           long interval,IMIX::BasicMessage* Msg)
              :DEPTimer(startTime,endTime,interval)
{
    this->m_pSPADEListener = pSessionListener;
	m_inMessage=Msg;
}

ServerTimer::~ServerTimer()
{

}

void ServerTimer::OnTimer()
{
	
	
	// IMIX20::ExecutionReport msgQueryReq;
	// const IMIX::BasicMessage& TimerMsg=(IMIX::BasicMessage)msgQueryReq;
   // (IMIX::BasicMessage) msgQueryReq;

	m_pSPADEListener->OnImixFastSPMsg(*m_inMessage);
		
}

