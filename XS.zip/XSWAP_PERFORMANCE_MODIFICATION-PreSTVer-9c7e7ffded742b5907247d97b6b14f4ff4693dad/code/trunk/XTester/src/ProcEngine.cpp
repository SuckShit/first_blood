/*******************************************************************************
* �鳤ȷ�ϣ���ͩ
* �޸����ڣ�20130731     
* review���ȷ��
*******************************************************************************/
#include "ProcEngine.h"




ProcEngine::ProcEngine(const string& FilePath)
{

	m_plibload=NULL;
	m_plibMsgAdapter=NULL;
	m_pCommSo=NULL;
	m_pSPHandle=NULL;
	m_SoPath=FilePath;
	//cout<<"m_SoPath"<<m_SoPath<<endl;
	


}


int ProcEngine::Init()
{

//ͨ�������ļ���ȡso
	m_plibload=m_configFile.LoadConfig(m_SoPath);
	if(m_plibload!=NULL)
	{
		if((m_libiter=m_plibload->find("sopath"))!=m_plibload->end())
		{
			//cout<<m_libiter->first<<endl;
			m_plibMsgAdapter = new DynamicLoader(m_libiter->second);
			if(m_plibMsgAdapter!=NULL)
				m_pCommSo = (ISPTask*)m_plibMsgAdapter->GetObj();
			    if(m_pCommSo==NULL)
				{
					LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
					return ERROR_CODE(SO_NULL_ERR);
				
				}
                 

		}
	}
	m_pSPHandle=new SPHandle(m_SoPath);
	if(m_pSPHandle==NULL)
	{
		LOG_ERROR(ERROR_CODE(SPHandle_NULL_ERR), ERROR_MSG(SO_NULL_ERR) );
		return ERROR_CODE(SPHandle_NULL_ERR);
	}

	return 0;

}


ProcEngine::~ProcEngine()
{

	if(m_pSPHandle!=NULL)
	{
		delete m_pSPHandle;
		m_pSPHandle=NULL;

	}

	if(m_pCommSo!=NULL)
	{
		delete  m_pCommSo;
		m_pCommSo=NULL;

	}

	if(m_plibMsgAdapter!=NULL)
	{
		delete m_plibMsgAdapter;
		m_plibMsgAdapter=NULL;    
	}

}



int ProcEngine::SPStartPlus(const IMIX::BasicMessage& inMessage,MsgList* SPParamList)
{



	try{
		if(m_pCommSo!=NULL)
			m_flag=m_pCommSo->OnSPStartPlus(inMessage,SPParamList);
		else
		{
			LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
			return ERROR_CODE(SO_NULL_ERR);
		}
	}
	catch (...)//���������쳣
	{
		return -1;
	}

	return m_flag;


}



int  ProcEngine::CallProcedure(MsgList*  Param,DBStruct* pDbCon,RESETLIST* pRESETLIST)
{



	try{
		if(m_pSPHandle!=NULL)
			m_flag=m_pSPHandle->CallProcedure(Param,pDbCon,pRESETLIST);
		else
		{
			LOG_ERROR(ERROR_CODE(SPHandle_NULL_ERR), ERROR_MSG(SPHandle_NULL_ERR) );
			return ERROR_CODE(SPHandle_NULL_ERR);
		}
	}
	catch (SQLException& ex)//����oracle�����쳣
	{
		LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
		return -1;
	}
	catch (...)//���������쳣
	{
		return -1;
	}

	return m_flag;
	//return -1;



}


int ProcEngine::SPStopPlus(RESETLIST* RSList,SENDMSGLIST* pMSGLIST,MsgList* SPParamList,const IMIX::BasicMessage& inMessage,int ExceptionFlag)
{


	try{
		if(m_pCommSo!=NULL)
			m_flag=m_pCommSo->OnSPStopPlus(RSList,pMSGLIST,SPParamList,inMessage,ExceptionFlag);
		else
		{
			LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
			return ERROR_CODE(SO_NULL_ERR);
		}
	}
	catch (SQLException& ex)//����oracle�����쳣
	{
		LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
		return -1;
	}
	catch (...)//���������쳣
	{
		return -1;
	}


	//m_pSPHandle->FreeSPResource(RSList);

	return m_flag;

}

int ProcEngine::FreeSPResource(RESETLIST* outRSList)
{

	try{
		if(m_pCommSo!=NULL)
			m_flag=m_pSPHandle->FreeSPResource(outRSList);
		else
		{
			LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
			return ERROR_CODE(SO_NULL_ERR);
		}
	}
	catch (SQLException& ex)//����oracle�����쳣
	{
		LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
		return -1;
	}
	catch (...)//���������쳣
	{
		return -1;
	}



	return m_flag;
}

int ProcEngine::Initiate(MsgList* SPParamList)
{

	try{
		if(m_pCommSo!=NULL)
			m_flag=m_pCommSo->Initiate(SPParamList);
		else
		{
			LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
			return ERROR_CODE(SO_NULL_ERR);
		}
	}
	catch (...)//���������쳣
	{
		return -1;
	}


	return m_flag;
}

int ProcEngine::OnInitiateStop(RESETLIST* RSnMap)
{


	try{
		if(m_pCommSo!=NULL)
			m_flag=m_pCommSo->OnInitiateStop(RSnMap);
		else
		{
			LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
			return ERROR_CODE(SO_NULL_ERR);
		}
	}
	catch (SQLException& ex)//����oracle�����쳣
	{
		LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
		return -1;
	}
	catch (...)//���������쳣
	{
		return -1;
	}


	return m_flag;
}

int ProcEngine::DefineTimer(TimerList* lTimerList)
{


	try{
		if(m_pCommSo!=NULL)
			m_flag=m_pCommSo->DefineTimer(lTimerList);
		else
		{
			LOG_ERROR(ERROR_CODE(SO_NULL_ERR), ERROR_MSG(SO_NULL_ERR));
			return ERROR_CODE(SO_NULL_ERR);
		}
	}
	catch (SQLException& ex)//����oracle�����쳣
	{
		LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
		return -1;
	}
	catch (...)//���������쳣
	{
		return -1;
	}


	return m_flag;
}


int ProcEngine::SPStartXML(const IMIX::BasicMessage& inMessage,MsgList* SPParamList,string XmlDoc)
{
#if 0
	//����汾����Ҫ���
	ProcessXML cProcessXML(inMessage,SPParamList);

	char * docname;
	char * filename;

	//docname="testquote.xml";

	cProcessXML.parseDoc(const_cast<char*>(XmlDoc.c_str()));

    return 0;
#endif

	return 0;
}
