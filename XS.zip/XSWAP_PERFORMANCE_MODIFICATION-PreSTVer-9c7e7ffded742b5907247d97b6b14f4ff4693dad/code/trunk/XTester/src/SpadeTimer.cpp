#include "SpadeTimer.h"

	

SpadeTimer::~SpadeTimer()
{
    if(m_inMessage!=NULL)
	{
		delete m_inMessage;
	    m_inMessage=NULL;
	}
}


IMIX::BasicMessage* SpadeTimer::GetMsg()
{
	return  m_inMessage;
}


void SpadeTimer::SetMsg(IMIX::BasicMessage* Id)
{
  m_inMessage=Id;
}
	

int SpadeTimer::GetInterval()
{
  return m_Interval;
}
	 
void SpadeTimer::SetInterval(int Interval)
{
  m_Interval=Interval;
}