

#include "dbdatactrl.h"
#include "SPADEListener.h"
#include "IMIXT10/Message/Logon.h"
#include "IMIXT10/Comm/MessageType.h"
#include "DEP/DEPAPIErrorDef.h"

#include "IMIXT10/Comm/MsgDefine.h"
#include "IMIX20/Comm/MsgDefine.h"
#include "IMIX20/ImixMessageFactory.h"
#include "CFETS/SessionMessage.h"
#include "CFETS/SessionListener.h"
#include "IMIX20/Message/DataSet.h"
#include "XAPIPbMessage.h"

#include "IMIX20/Message/UserRequest.h"
#include "IMIX20/Message/NewOrderSingle.h"
#include "IMIX20/Component/Parties.h"
#include "IMIX20/Comm/MessageType.h"
#include "string"
extern "C"
{
#include <stdio.h>
#include <stdlib.h>
}

#define ORG_ID_LEN 6
#define USR_ID_LEN 16

typedef struct UsrLogInfoS
{
    char orgId[ORG_ID_LEN];
    char filler1;
    char usrId[USR_ID_LEN];
} UsrLogInfoT, *pUsrLogInfoT;

typedef struct HdrInfoS
{
    char type[3];
    char filler1;
    char subType[3];
} HdrInfoT, *pHdrInfoT;

typedef struct OrdrInfoS
{
    HdrInfoT    hdr;
    char filler1;
    char msgType;
    char filler2;
    char orgId[ORG_ID_LEN];
    char filler3;
    char usrId[USR_ID_LEN];
    char filler4;
    char execInst[3];
    char filler5;
    char ordType[3];
    char filler6;
    char ordrNo[16];
    char filler7;
    char side[3];
    char filler8;
    char scrtyId[16];
    char filler9;
    char scrtySubType[12];
    char filler10;
    char scrtyType[6];
    char filler11;
    char price[10];
    char filler12;
    char qty[20];
    char filler13;
    char effTime[17];
    char filler14;
    char sts;
    char filler15;
} OrdrInfoT, *pOrdrInfoT;


//
string& trim(string& input)
{
    input.erase(0,input.find_first_not_of(" "));
    input.erase(input.find_last_not_of(" ")+1);
    return input;
}

map<string,string> gUserTokenMap;

int sendCnt;

int gMsgSqno = 100;
FILE* gOrdrFp;
using namespace IMIX20;



int OpenMsgFile()
{
    gOrdrFp = fopen("../data/orderReq.txt","r");
    
    if (!gOrdrFp) {
        printf("Failed");
        exit (0);
    }
    
    char tempString[500];
    //memset(tempString, 0x00, 500); 
    fgets(tempString,500, gOrdrFp);//ignore the first line
    
    return 1;
}

char * GetNxtMsgFromFile(char * pMsgContext)
{
    char * rc = fgets(pMsgContext,500, gOrdrFp);//ignore the first line
    
    return rc;
}


string GetExcInstVal(string& pExcInst)
{
    string val ;
    if (pExcInst == "ADD")
    {
        val = "2";
    }
    
    return val;
}

char GetOrdTypeVal(string& pOrdType)
{
    if (pOrdType == "NOR")
    {
        return '2';
    }
}

char GetSideVal(string& pSide)
{
    if (pSide == "BUY")
    {
        return '1';
    }
}


SPADEListener::SPADEListener(const string& FilePath)
{

    m_pInstance=NULL;
    m_pInstance=new DBDataCtrl;

    // ��ȡЭ�����ͣ���������ʱʹ��
    m_FastProtocol = string( IMIX::FastProtocol );
//    m_SoPath=FilePath;
    m_pSPEngine = NULL;
    

//    m_pTimerList=new TimerList;
//    m_pSPEngine=new ProcEngine(m_SoPath);

    
}

int SPADEListener::PushMessage(SENDMSGLIST* pSendMsgList, IMIX::BasicMessage* pMsg)
{
    if (pSendMsgList && pMsg)
    {
        LOG_DEBUG("PushMessage pMsg=[%s]", pMsg->ToString().c_str());  
        pSendMsgList->push_back(pMsg);
    }
    else
    {
        if (NULL != pMsg)
        {
            delete pMsg;
            pMsg = NULL;
        }

        return 0;
    }

    return 1;
}

int SPADEListener::SendMessage(SENDMSGLIST** pMsgList)
{

    DEP::Service * ptempService;
    SENDMSGLIST::iterator MsgIter;    
    ServiceList::iterator m_ServiceIter;  
    //SetField("SenderSubID",pSession1->m_appName);
    ptempService = const_cast<DEP::Service *>(*m_ServiceList.begin());
        
    LOG_DEBUG("SendMessage pMsg=[%s]", (*(*(*pMsgList)->begin())).ToString().c_str()); 
        
    (ptempService)->Send((*(*(*pMsgList)->begin())));
    
    return    1;

}

void SPADEListener::AddUsrCnt()
{

    SPADEListener::usrCnt++;

}

int SPADEListener::GetUsrCnt()
{

    return SPADEListener::usrCnt;

}

void SPADEListener::AddUsrLgnCnt()
{

    SPADEListener::usrCnt++;

}

int SPADEListener::GetUsrLgnCnt()
{

    return SPADEListener::usrCnt;

}


void SPADEListener::ResetRunMode()
{

    SPADEListener::runMode = 0;

}
void SPADEListener::SetRunMode()
{

    SPADEListener::runMode = 1;

}

int SPADEListener::GetRunMode()
{

    return SPADEListener::runMode;

}

void SPADEListener::SetLgnSts(int sts)
{

    SPADEListener::loginSts = sts;

}

int SPADEListener::IsLgn()
{

    return SPADEListener::loginSts;

}

int SPADEListener::OnLoginStartMessage()
{

    FILE* fp;
    char tempString[500];
    int iField = 0;
    
    fp = fopen("../data/loginReq.txt","r");
    
    if (!fp) {
        printf("Failed");
        exit (0);
    }
    
    pUsrLogInfoT    pUsrLogInfo = NULL;
    
    memset(tempString, 0x00, 500); 
    fgets(tempString,500, fp);//ignore the first line    
    memset(tempString, 0x00, 500); 
    while(fgets(tempString,500, fp)){
        
        IMIX20::UserRequest* message = new IMIX20::UserRequest();
        iField = 0;
        LOG_DEBUG("tempString is : %s\n", tempString);
        
        pUsrLogInfo = (pUsrLogInfoT)tempString;
        
        pUsrLogInfo->filler1 = 0x00;
        
        message->GetHeader()->SetMsgType("BE");//MsgType 35 ("BE")
        message->GetHeader()->SetSenderCompID("RDPServer1");//SenderCompID 49
        message->GetHeader()->SetSendingTime("20170905-08:54:37.672");//SendingTime 52
        message->GetHeader()->SetTargetCompID("BTP1");//TargetCompID 56
        message->GetHeader()->SetDeliverToCompID("BTP");//DeliverToCompID 128
        message->GetHeader()->SetDeliverToSubID("BTP1");//DeliverToSubID 129
        message->GetHeader()->SetOnBehalfOfCompID(pUsrLogInfo->orgId);//OnBehalfOfCompID 115
        message->GetHeader()->SetOnBehalfOfSubID(pUsrLogInfo->usrId);//OnBehalfOfSubID 116
        message->GetHeader()->SetSenderSubID("RDPServer01");//SenderSubID 50
        message->GetHeader()->SetTargetSubID("BTP1");//TargetSubID 57
        message->SetApplUniqueKey("1");//
        
        //E_REQTYPE_LOGIN = 1
        message->SetUserRequestType(1);//UserRequestType 924
        
        message->SetApplSeqNum(1);//ApplSeqNum 1181
        PartyDetailGrp* pPartyDetailGrp = message->GetPartyDetailGrp();
        if ( pPartyDetailGrp != NULL)
        {
            PartyDetailGrp::NoPartyDetails* pNoPartyDetails =  pPartyDetailGrp->AddNoPartyDetails();
            if (pNoPartyDetails != NULL)
            {
                pNoPartyDetails->SetPartyDetailID(pUsrLogInfo->usrId);//PartyDetailID 1691
                pNoPartyDetails->SetPartyDetailRole(11);//PartyDetailRole 1693
            }
        }
        
        message->GetTrailer()->SetCheckSum("070");//CheckSum 10
        LOG_DEBUG("LogOn %s",  message->ToString().c_str());
        
        memset(tempString, 0x00, 500); 
        
        AddUsrCnt();
        
        SENDMSGLIST* pSendMsgList=new SENDMSGLIST;
        PushMessage(pSendMsgList, message);
        
        SendMessage(&pSendMsgList);
    }
    
    fclose(fp);
    return 1;
}



int FmtOrderReqMsg(IMIX20::NewOrderSingle * message, pOrdrInfoT pOrdrInfo)
{

    pOrdrInfo->filler1 = 0x00;
    pOrdrInfo->filler2 = 0x00;
    pOrdrInfo->filler3 = 0x00;
    pOrdrInfo->filler4 = 0x00;
    pOrdrInfo->filler5 = 0x00;
    pOrdrInfo->filler6 = 0x00;
    pOrdrInfo->filler7 = 0x00;
    pOrdrInfo->filler8 = 0x00;
    pOrdrInfo->filler9 = 0x00;
    pOrdrInfo->filler10 = 0x00;
    pOrdrInfo->filler11 = 0x00;
    pOrdrInfo->filler12 = 0x00;
    pOrdrInfo->filler13 = 0x00;
    pOrdrInfo->filler14 = 0x00;
    
    char sMsgType[2] = {0};
        
    IMIX20::Parties *pParties = message->GetParties();
    IMIX20::Parties::NoPartyIDs *pNoPartyIDs = pParties->AddNoPartyIDs();

    
    sMsgType[0] = pOrdrInfo->msgType;  
    message->GetHeader()->SetMsgType(sMsgType);//MsgType 35
    message->GetHeader()->SetSenderCompID("RDPServer1");//SenderCompID 49
    message->GetHeader()->SetSendingTime("20171231-21:00:00.672");//SendingTime 52
    message->GetHeader()->SetTargetCompID("BTP1");//TargetCompID 56
    message->GetHeader()->SetDeliverToCompID("BTP");//DeliverToCompID 128
    message->GetHeader()->SetDeliverToSubID("BTP1");//DeliverToSubID 129
    
    message->GetHeader()->SetOnBehalfOfCompID(pOrdrInfo->orgId);//OnBehalfOfCompID 115
    
    string usrId = pOrdrInfo->usrId;
    message->GetHeader()->SetOnBehalfOfSubID(trim(usrId));//OnBehalfOfSubID 116
    message->GetHeader()->SetSenderSubID("RDPServer01");//SenderSubID 50
    message->GetHeader()->SetTargetSubID("BTP1");//TargetSubID 57
    string efftime = pOrdrInfo->effTime;
    message->SetEffectiveTime(trim(efftime));//EffectiveTime   168
    string exeInst = pOrdrInfo->execInst;
    message->SetExecInst(GetExcInstVal(exeInst));//ExecInst  18
    //strcpy(sType, sOrderItem[12].c_str());
    string ordType = pOrdrInfo->ordType;
    message->SetOrdType(GetOrdTypeVal(ordType));//OrdType   40
    
    string price = pOrdrInfo->price;
    message->SetPrice(trim(price));//Price 44
    
    string qty = pOrdrInfo->qty;
    message->SetOrderQty(trim(qty));//OrderQty 38
    
    string side = pOrdrInfo->side;
    message->SetSide(GetSideVal(side));//54  
    /*
    message->SetTransactTime(sOrderItem[15]);//TransactTime 60
    message->SetSecurityID(sOrderItem[16]);//SecurityID  48
    message->SetSecuritySubType(sOrderItem[17]);//SecuritySubType 762
    message->SetSecurityType(sOrderItem[18]);//SecurityType  167
    message->SetApplToken(pRspMessage->GetApplToken().c_str());//11233 generated after login
    message->SetOrderQty(sOrderItem[19]);//OrderQty 38
    message->SetNoPartyIDs(atoi(sOrderItem[20].c_str()));//NoPartyIDs 453 
    pNoPartyIDs->SetPartyID(sOrderItem[21]);//PartyID 448
    pNoPartyIDs->SetPartyRole(atoi(sOrderItem[22].c_str()));//PartyRole 452
    message->GetTrailer()->SetCheckSum(sOrderItem[23]);//CheckSum 10
    */
            
    message->SetApplSeqNum(++gMsgSqno);//ApplSeqNum 1181
    message->SetTransactTime("200");//TransactTime 60
    
    string cntrctId = pOrdrInfo->scrtyId;
    
    message->SetSecurityID(trim(cntrctId));//SecurityID  48
    
    string subType = pOrdrInfo->scrtySubType;
    message->SetSecuritySubType(trim(subType));//SecuritySubType 762
    
    string cntrctType = pOrdrInfo->scrtyType;
    message->SetSecurityType(trim(cntrctType));//SecurityType  167
    message->SetApplToken(gUserTokenMap[usrId]);//11233 generated after login

    //message->SetNoPartyIDs(1);//NoPartyIDs 453 
    
    pNoPartyIDs->SetPartyID(usrId);//PartyID 448
    pNoPartyIDs->SetPartyRole(11);//PartyRole 452
    message->GetTrailer()->SetCheckSum("070");//CheckSum 10

    LOG_DEBUG("Fmt Ordr %s", message->ToString().c_str());

    return UTILITY::SUCCESS;

}


int SPADEListener::OnOrderBatchSend()
{
    xapi::OrdrReq  order;
        
    char tempString[500];  
    
    
    pOrdrInfoT pOrdrInfo = NULL;
    //memset(strResp, 0x00, sizeof(strResp));
    sendCnt = 0;   
    
    while (fgets(tempString,500, gOrdrFp))
    {
        pOrdrInfo = (pOrdrInfoT)tempString;
        NewOrderSingle* ordrMessage = new NewOrderSingle();
        SENDMSGLIST* pSendMsgList=new SENDMSGLIST;
        
        FmtOrderReqMsg(ordrMessage, pOrdrInfo);

        LOG_DEBUG("Push Order %d ", sendCnt+1);

        PushMessage(pSendMsgList, ordrMessage);
        SendMessage(&pSendMsgList);        
        sendCnt++;
        
        delete ordrMessage;
        delete pSendMsgList;
    }

    LOG_DEBUG("Push Order %d ", sendCnt+1);
  
    LOG_DEBUG (" Batch Order Sent");

    return UTILITY::SUCCESS;

}

int SPADEListener::OnOrderSubmitMessage(char * inputMsgContext)
{
    
    xapi::OrdrReq  order;
    
  
    SENDMSGLIST* pSendMsgList=new SENDMSGLIST;
    pOrdrInfoT pOrdrInfo = NULL;
    //memset(strResp, 0x00, sizeof(strResp));
    sendCnt = 0;

    LOG_DEBUG("Message : %s", inputMsgContext);
    pOrdrInfo = (pOrdrInfoT)inputMsgContext;
    
    NewOrderSingle* ordrMessage = new NewOrderSingle();
    
    FmtOrderReqMsg(ordrMessage, pOrdrInfo);
    

    LOG_DEBUG("Push Order %d ", sendCnt+1);

    PushMessage(pSendMsgList, ordrMessage);

    SendMessage(&pSendMsgList);
    
    delete ordrMessage;

    LOG_INFO (" Order Sent");

    return UTILITY::SUCCESS;

}

//��ʼ�����ݿ�����
int SPADEListener::InitDB()
{
    int initDB=0;
    initDB=m_pInstance->Init(m_SoPath);
    if(initDB!=UTILITY::SUCCESS)
    {
        LOG_ERROR( ERROR_CODE(DB_INIT_ERR), ERROR_MSG(DB_INIT_ERR));
            
        return ERROR_CODE(DB_INIT_ERR);
    }

    if (m_pSPEngine->Init() != UTILITY::SUCCESS) {
        LOG_ERROR( ERROR_CODE(PROCENGINE_INIT_ERR), ERROR_MSG(PROCENGINE_INIT_ERR));
        return ERROR_CODE(PROCENGINE_INIT_ERR);
    }


    return UTILITY::SUCCESS;

}


SPADEListener::~SPADEListener(void)
{
    if(m_pInstance!=NULL)
      delete m_pInstance;

    TimerList::iterator TimerIter;
    //ɾ�������timer����б�
                if(m_pTimerList!=NULL)
                {
                    //if(pTimerList->size()>0)
                    for(TimerIter=m_pTimerList->begin();TimerIter!=m_pTimerList->end();TimerIter++)
                    {  
                        if((*TimerIter)!=NULL)
                        {
                            delete (*TimerIter);
                            *TimerIter=NULL;
                        }

                    }

                    delete m_pTimerList;
                    m_pTimerList=NULL;
                }
             
                if(m_pServerTimer!=NULL)
                {
                    delete m_pServerTimer;

                    m_pServerTimer=NULL;
                }

        if(m_pSPEngine!=NULL)
        {
            delete m_pSPEngine;
            m_pSPEngine=NULL;
        }


}

int CheckOrderResp(void * pInputRsp, IMIX20::ExecutionReport& ordrResp)
{
    int result = 1;
    
    pOrdrInfoT pOrdrInfo = (pOrdrInfoT)pInputRsp;
    
    pOrdrInfo->filler1 = 0x00;
    pOrdrInfo->filler2 = 0x00;
    pOrdrInfo->filler3 = 0x00;
    pOrdrInfo->filler4 = 0x00;
    pOrdrInfo->filler5 = 0x00;
    pOrdrInfo->filler6 = 0x00;
    pOrdrInfo->filler7 = 0x00;
    pOrdrInfo->filler8 = 0x00;
    pOrdrInfo->filler9 = 0x00;
    pOrdrInfo->filler10 = 0x00;
    pOrdrInfo->filler11 = 0x00;
    pOrdrInfo->filler12 = 0x00;
    pOrdrInfo->filler13 = 0x00;
    pOrdrInfo->filler14 = 0x00;
    pOrdrInfo->filler15 = 0x00;
    char sMsgType[2] = {0};
        
    IMIX20::Parties *pParties = ordrResp.GetParties();
 
    sMsgType[0] = pOrdrInfo->msgType;  
    ordrResp.GetHeader()->SetMsgType(sMsgType);//MsgType 35
    
    if(strcmp(ordrResp.GetHeader()->GetMsgType().c_str(),sMsgType ))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong MsgType %s %s",ordrResp.GetHeader()->GetMsgType().c_str(), sMsgType);
        result = 0;
    }

    if(strcmp(ordrResp.GetEffectiveTime().c_str(),pOrdrInfo->effTime ))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong GetEffectiveTime %s %s",ordrResp.GetEffectiveTime().c_str(), pOrdrInfo->effTime);
        result = 0;
    }
    
    string exeInst = GetExcInstVal(exeInst);
    if (strcmp(ordrResp.GetExecInst().c_str(),GetExcInstVal(exeInst).c_str()))
        
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong ExecInst %s %s",ordrResp.GetExecInst().c_str(), pOrdrInfo->execInst);
        result = 0;
    }
    
  
    string ordType = pOrdrInfo->ordType;
    if(ordrResp.GetOrdType() != GetOrdTypeVal(ordType))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong ordType %c %c",ordrResp.GetOrdType(), pOrdrInfo->ordType);
        result = 0;
    }
    
    string price = pOrdrInfo->price;
    if(ordrResp.GetPrice() != trim(price))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong price %s %s",ordrResp.GetPrice().c_str(), trim(price).c_str());
        result = 0;
    }
    
    string qty = pOrdrInfo->qty;
    if(ordrResp.GetOrderQty() != trim(qty))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong qty %s %s",ordrResp.GetOrderQty().c_str(), trim(qty).c_str());
        result = 0;
    }

    string side = pOrdrInfo->side;
    if(ordrResp.GetSide() != GetSideVal(side))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong side %c %c",ordrResp.GetSide(), GetSideVal(side));
        result = 0;
    }


    string scrtyId = pOrdrInfo->scrtyId;
    if(ordrResp.GetSecurityID() != trim(scrtyId))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong scrtyId %s %s",ordrResp.GetSecurityID().c_str(), trim(scrtyId).c_str());
        result = 0;
    }

    string scrtySubType = pOrdrInfo->scrtySubType;
    if(ordrResp.GetSecuritySubType() != trim(scrtySubType))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong scrtySubType %s %s",ordrResp.GetSecuritySubType().c_str(), trim(scrtySubType).c_str());
        result = 0;
    }
    
    string scrtyType = pOrdrInfo->scrtyType;
    if(ordrResp.GetSecurityType() != trim(scrtyType))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong scrtyType %s %s",ordrResp.GetSecurityType().c_str(), trim(scrtyType).c_str());
        result = 0;
    }

    
    string ordrNo = pOrdrInfo->ordrNo;
    if(ordrResp.GetOrderID() != trim(ordrNo))
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong ordrNo %s %s",ordrResp.GetOrderID().c_str(), trim(ordrNo).c_str());
        result = 0;
    }
    
    char ordrSts = pOrdrInfo->sts;
    if(ordrResp.GetOrdStatus() != ordrSts)
    {
        LOG_INFO("!!!!!!!!!!!!!  Wrong ordrSts %c %c",ordrResp.GetOrdStatus(), ordrSts);
        result = 0;
    }

    return result;
}

int SPADEListener::FromApp( const IMIX::BasicMessage& msg, const DEP::Service& service)
{
    bool bRet;  
    char tempString[500];  
    pOrdrInfoT pOrdrInfo;
    IMIX::BasicMessage& baseMsg = const_cast<IMIX::BasicMessage&>(msg);
        
    if (baseMsg.GetHeader()->GetMsgType() == UserResponseMessageID)
    {
        UserResponse usrRsp;
        usrRsp.crack(const_cast<IMIX::BasicMessage&>(msg));

        LOG_INFO("Login Rsp Usr %s Token %s",baseMsg.GetHeader()->GetDeliverToSubID().c_str(), usrRsp.GetApplToken().c_str());
        
        gUserTokenMap.insert(pair<string,string>(baseMsg.GetHeader()->GetDeliverToSubID(),usrRsp.GetApplToken() ));
        
        if (usrRsp.GetApplToken() != "")
        {
            AddUsrLgnCnt();
        }
        
        if (GetUsrCnt() == GetUsrLgnCnt())
        {
            SetLgnSts(1);
            LOG_INFO("============= All %d user login... ", GetUsrLgnCnt() );
        }
        
        if (IsLgn())
        {   
            if (GetRunMode() == 1)
            {
                LOG_DEBUG("Performance testing Mode ");
                OnOrderBatchSend();
            }
            else
            {
                LOG_DEBUG("Normanl testing Mode ");
                GetNxtMsgFromFile(tempString);
                
                OnOrderSubmitMessage(tempString);
            }
        }
    }
    else if (baseMsg.GetHeader()->GetMsgType() == ExecutionReportMessageID)
    {
        ExecutionReport pOrderMsg;
        bRet = pOrderMsg.crack(const_cast<IMIX::BasicMessage&>(msg));
        if (!bRet)
        {
            LOG_ERROR( ERROR_CODE(DB_INIT_ERR), ERROR_MSG(DB_INIT_ERR));
                
            return ERROR_CODE(DB_INIT_ERR);
        }
        
        if(!strcmp(pOrderMsg.GetApplErrorDesc().c_str(),"SUCCESS"))
        {
            LOG_DEBUG("==========FromApp SUCCESS %s",pOrderMsg.ToString().c_str());
        }
        else
        {
            GetNxtMsgFromFile(tempString);
                
            pOrdrInfoT pOrdrInfo = (pOrdrInfoT)tempString;
            pOrdrInfo->hdr.filler1 = 0x00;
            pOrdrInfo->filler1 = 0x00;
            
            if (!strcmp(pOrdrInfo->hdr.type,"Req"))
            {
                LOG_DEBUG("!!!!!!!!!!!!!!  Expecting Response message");
                exit(1);
                
            }       
            else
            {
                if (!strcmp(pOrdrInfo->hdr.subType,"ORD"))
                {
                    if(!CheckOrderResp(pOrdrInfo, pOrderMsg))
                    {
                        LOG_DEBUG("!!!!!!!!!!!!!!  Ordr check failed");
                        exit(1);
                    }
                }
            }
            
            
           
            LOG_DEBUG("==========FromApp pOrderMsg %s",pOrderMsg.ToString().c_str());
        }

    }
    else
    {
        LOG_DEBUG("==========FromApp Unknow Message %s",baseMsg.ToString().c_str());
    }
    
    //return 0;
    return UTILITY::SUCCESS;
}

int SPADEListener::FromAdmin(const IMIX::BasicMessage &inMessage,
                             const  DEP::Service &inService )
{
    //printf(" FromAdmin recv %s\n", inMessage.m_msgBody);    

    LOG_DEBUG("Recive message body:[%s]", inMessage.m_msgBody);

    IMIX::BasicMessage &message = ( IMIX::BasicMessage &)inMessage;
    DEP::Service &service = ( DEP::Service &)inService;
    //  assert( message.GetHeader() != NULL );

    // ��ȡ��ϢID�������ж���Ϣ����
    std::string msgid = message.GetHeader()->GetMsgType();

    // ������Ϣ�Ž��д���,���ӶԲ�ͬ������Ϣ���ж�
    if ( msgid == IMIXT10::LogonMessageID )
    {
        
        return SendLogonMessage(service,message);
    }
    else
        if ( msgid == IMIXT10::LogoutMessageID )
        {

            return SendLogoutMessage(service,message);
        }

    sleep(10000);
    
        return UTILITY::SUCCESS;

}


int SPADEListener::ToApp( const IMIX::BasicMessage& msg, const DEP::Service& service)
{
    LOG_DEBUG("ToApp  send");
    return UTILITY::SUCCESS;
}

int SPADEListener::ToAdmin( const IMIX::BasicMessage& msg, const DEP::Service& service)
{
    LOG_DEBUG("ToAdmin  send");
    return UTILITY::SUCCESS;
}


int SPADEListener::OnLogout( const DEP::Service& service, int type )
{
    AutoLock locker( &m_ClientMutex );
    LOG_DEBUG(" OnLogout recv ");
    //1.����servicelist�����ҵ�service
    //2.ɾ�����Service
    //printf("========= service list size: [%d]. \n", m_ServiceList.size());
    std::list<const DEP::Service*>::iterator iter;
    for(iter=m_ServiceList.begin(); iter!=m_ServiceList.end(); )
    {
        const DEP::Service* pService =  *iter;
        if(pService->GetServiceID() == service.GetServiceID())
        {
            iter = m_ServiceList.erase(iter);
            LOG_INFO("*** Service [%s][%s] logout.", 
                    pService->GetServiceID().getSenderCompID().c_str(),
                    pService->GetServiceID().getSenderSubID().c_str());
        }
        else
        {
            iter++;
        }
    }
    return UTILITY::SUCCESS;
}

int SPADEListener::OnLogon( const DEP::Service& service)
{
    const DEP::ServiceID &stServiceID = ( ( DEP::Service ) service ).GetServiceID();
    LOG_INFO( "[Org:%s, %s]to[Org:%s, %s] Login success",
        stServiceID.getTargetCompID().c_str(),
        stServiceID.getTargetSubID().c_str(),
        stServiceID.getSenderCompID().c_str(),
        stServiceID.getSenderSubID().c_str() );
    AutoLock locker( &m_ClientMutex );
    m_ServiceList.push_back(&service);
    
    
    OpenMsgFile();
    
    SetLgnSts(0);
    
    OnLoginStartMessage();
    
    LOG_DEBUG("Sent Login Request"); 
    
    return UTILITY::SUCCESS;
}

/*
int SPADEListener::OnAccepted( const DEP::Service &service )
{
return UTILITY::SUCCESS;
}*/


#if 1

/*******************************************************************************
* �������� : SPADEListener::SendLogonMessage
* �������� : ����һ����½��Ϣ
* �Ρ����� : DEP::Service &service
* �Ρ����� : IMIXT10::Logon &message
* �� �� ֵ : void
* �������� : 
* ������� : 2013��5��15��
* �޸�����     �޸���    �޸�����
*   ID1        ������    ����½Ӧ����Ϣ��Ϊ��½��Ϣ
*******************************************************************************/

int SPADEListener::SendLogonMessage(DEP::Service &service,
                                    IMIX::BasicMessage& message )
{
    IMIXT10::Logon SendMsg;
    IMIX::BasicHeader *pHeader = SendMsg.GetHeader();
    IMIX::BasicHeader *pMsgHeader = message.GetHeader();

    //assert( pHeader != NULL );
    //assert( pMsgHeader != NULL );

    if(pHeader==NULL || pMsgHeader== NULL)
    {
        LOG_ERROR( ERROR_CODE(IMIX_HEAD_ERR), ERROR_MSG(IMIX_HEAD_ERR));
        return ERROR_CODE(IMIX_HEAD_ERR);

    }

    /**
    *����һ����½Ӧ����Ϣ������½��Ϣ�Ǿ���commserverת���Ĳ���Ҫ�Լ���logon��Ϣ
    *m_SenderSubID��m_SenderCompID��SPADE��ID��GROUPID
    *m_TargetSubID��m_TargetCompID��SenderID
    *m_OnBehalfOfSubID��m_OnBehalfOfCompID��SPADE��ID
    *m_DeliverToSubID��m_DeliverToCompID��OnBehalfID
    */
    

    if(pMsgHeader->GetSenderSubID()!=pMsgHeader->GetOnBehalfOfSubID() && pMsgHeader->GetSenderSubID()!="")
    {
        pHeader->SetTargetCompID( pMsgHeader->GetSenderCompID() );
        pHeader->SetTargetSubID( pMsgHeader->GetSenderSubID() );

        pHeader->SetDeliverToCompID( pMsgHeader->GetOnBehalfOfCompID() );
        pHeader->SetDeliverToSubID( pMsgHeader->GetOnBehalfOfSubID() );

        pHeader->SetOnBehalfOfCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetOnBehalfOfSubID( pMsgHeader->GetTargetSubID() );

        pHeader->SetSenderCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetSenderSubID( pMsgHeader->GetTargetSubID() );

        // SendMsg.SetSessionStatus( LOGONSUCCESSSTATUS );

        LOG_INFO( "Send login message header ",
            pHeader->GetTargetCompID().c_str(),
            pHeader->GetTargetSubID().c_str(),
            pHeader->GetSenderCompID().c_str(),
            pHeader->GetSenderSubID().c_str(),
            pHeader->GetDeliverToCompID().c_str(),
            pHeader->GetDeliverToSubID().c_str(),
            pHeader->GetOnBehalfOfCompID().c_str(),
            pHeader->GetOnBehalfOfSubID().c_str()

            );
        //ShowMessagekey( &SendMsg );
        //  ShowServicekey( service );

        service.Send(SendMsg);    


    }
    return 0;
}
#endif





int SPADEListener::SendLogoutMessage(DEP::Service &service,
                                     IMIX::BasicMessage& message )
{
    IMIXT10::Logout SendMsg;
    IMIX::BasicHeader *pHeader = SendMsg.GetHeader();
    IMIX::BasicHeader *pMsgHeader = message.GetHeader();

    //assert( pHeader != NULL );
    //assert( pMsgHeader != NULL );
    if(pHeader==NULL || pMsgHeader== NULL)
    {
        LOG_ERROR( ERROR_CODE(IMIX_HEAD_ERR), ERROR_MSG(IMIX_HEAD_ERR));
        return ERROR_CODE(IMIX_HEAD_ERR);

    }

    /**
    *����һ����½Ӧ����Ϣ������½��Ϣ�Ǿ���commserverת���Ĳ���Ҫ�Լ���logon��Ϣ
    *m_SenderSubID��m_SenderCompID��SPADE��ID��GROUPID
    *m_TargetSubID��m_TargetCompID��SenderID
    *m_OnBehalfOfSubID��m_OnBehalfOfCompID��SPADE��ID
    *m_DeliverToSubID��m_DeliverToCompID��OnBehalfID
    */
    //cout<<"pMsgHeader->GetSenderSubID()"<<pMsgHeader->GetSenderSubID()<<endl;
    //cout<<"pMsgHeader->GetOnBehalfOfSubID()"<<pMsgHeader->GetOnBehalfOfSubID()<<endl;

    if(pMsgHeader->GetSenderSubID()!=pMsgHeader->GetOnBehalfOfSubID() && pMsgHeader->GetSenderSubID()!="")
    {
        pHeader->SetTargetCompID( pMsgHeader->GetSenderCompID() );
        pHeader->SetTargetSubID( pMsgHeader->GetSenderSubID() );

        pHeader->SetDeliverToCompID( pMsgHeader->GetOnBehalfOfCompID() );
        pHeader->SetDeliverToSubID( pMsgHeader->GetOnBehalfOfSubID() );

        pHeader->SetOnBehalfOfCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetOnBehalfOfSubID( pMsgHeader->GetTargetSubID() );

        pHeader->SetSenderCompID( pMsgHeader->GetTargetCompID() );
        pHeader->SetSenderSubID( pMsgHeader->GetTargetSubID() );

        // SendMsg.SetSessionStatus( LOGONSUCCESSSTATUS );

        LOG_INFO( "��������Ϣ��8����",
            pHeader->GetTargetCompID().c_str(),
            pHeader->GetTargetSubID().c_str(),
            pHeader->GetSenderCompID().c_str(),
            pHeader->GetSenderSubID().c_str(),
            pHeader->GetDeliverToCompID().c_str(),
            pHeader->GetDeliverToSubID().c_str(),
            pHeader->GetOnBehalfOfCompID().c_str(),
            pHeader->GetOnBehalfOfSubID().c_str()

            );

        //  LOG_DEBUG( "���͵�½��Ϣ��message��Service�Ĳ�������" );
        //ShowMessagekey( &SendMsg );
        //  ShowServicekey( service );

        service.Send(SendMsg);    


    }
    return 0;
}

int SPADEListener::OnAccepted( const DEP::Service& )
{
    LOG_DEBUG(" OnAccepted recv ");
    return UTILITY::SUCCESS;
}

int SPADEListener::OnImixFastSPMsg(const IMIX::BasicMessage &inMessage)
{

    std::string sFunctionName = "[OnImixFastSPMsg]: ";
    LOG_DEBUG("%sStart..", sFunctionName.c_str());

    return    UTILITY::SUCCESS;

}

int SPADEListener::SendMsg(SENDMSGLIST** pMsgList)
{

    //����so�ﷵ�صĴ����͵���Ϣ        
    int CountSendMsg;
    DEP::Service * ptempService;
    SENDMSGLIST::iterator MsgIter;    
    //LOG_DEBUG("PushMessage list size: %d", pMsgList->size());

    if(*pMsgList!=NULL)
    {
        LOG_DEBUG("PushMessage list size: %d", (*pMsgList)->size());
        for(MsgIter=(*pMsgList)->begin();MsgIter!=(*pMsgList)->end();MsgIter++)
        {
            //cout<<"((*MsgIter)->GetHeader())->m_TargetCompID"<<((*MsgIter)->GetHeader())->GetTargetCompID()<<endl;

            AutoLock locker( &m_ClientMutex );
            CountSendMsg=0;

            //ConnSession* pSession1 = NULL;
            for( m_ServiceIter=m_ServiceList.begin();m_ServiceIter!=m_ServiceList.end();m_ServiceIter++)
                //        for (list<ConnSession *>::iterator iter = this->m_connectedSessionList.begin();iter != this->m_connectedSessionList.end();++iter)
            {

                //pSession1 = *iter;
                if((*m_ServiceIter)!=NULL)
                {
                    m_ServiceID=(**m_ServiceIter).GetServiceID();
                    //if(strcmp(pSession1->m_targetGroupName.c_str(),(((*MsgIter)->GetHeader())->GetTargetCompID()).c_str())==0)
                    //ֱ������������������ tdps�Լ�rdp�����ӣ����е���Ϣ�ظ���ͨ���㲥�ķ�ʽ
                    if(m_ServiceID.getTargetCompID()==((*MsgIter)->GetHeader())->GetTargetCompID())
                    {        
                        //����TDPS,2������so�����յ�
                        if ((*MsgIter)->GetHeader()->GetDeliverToCompID()=="" && (*MsgIter)->GetHeader()->GetDeliverToSubID()=="")
                        {
                            //SetField("SenderSubID",pSession1->m_appName);
                            (*MsgIter)->GetHeader()->SetSenderSubID(m_ServiceID.getSenderSubID());
                            (*MsgIter)->GetHeader()->SetSenderCompID(m_ServiceID.getSenderCompID());
                            (*MsgIter)->GetHeader()->SetTargetSubID(m_ServiceID.getTargetSubID());
                            // (*MsgIter)->GetHeader()->SetTargetCompID(pSession->m_targetGroupName);
                            (*MsgIter)->GetHeader()->SetOnBehalfOfSubID(m_ServiceID.getOnBehalfOfSubID());
                            (*MsgIter)->GetHeader()->SetOnBehalfOfCompID(m_ServiceID.getOnBehalfOfCompID());
                            (*MsgIter)->GetHeader()->SetDeliverToSubID(m_ServiceID.getDeliverToSubID());
                            (*MsgIter)->GetHeader()->SetDeliverToCompID(m_ServiceID.getDeliverToCompID());
                            CountSendMsg++;
                            //break;
                            ptempService = const_cast<DEP::Service *>(*m_ServiceIter);
                            (ptempService)->Send((*(*MsgIter)));
                        }

                        else//����rdp,���ַ��ĵ�ַͨ��sp��ȡ���ͻ��˵ĵ�ַͨ��session msg��ȡ,��so�������commserverֱ�����ӵ������TargetCompID��so���ã�
                            if ((*MsgIter)->GetHeader()->GetDeliverToCompID()!="" && (*MsgIter)->GetHeader()->GetDeliverToSubID()!="")
                            {
                                (*MsgIter)->GetHeader()->SetSenderSubID(m_ServiceID.getSenderSubID());
                                (*MsgIter)->GetHeader()->SetSenderCompID(m_ServiceID.getSenderCompID());
                                (*MsgIter)->GetHeader()->SetTargetSubID(m_ServiceID.getTargetSubID());
                                //(*MsgIter)->GetHeader()->SetTargetCompID(m_ServiceID.getTargetCompID());//compid�ĵ�ַ��so��䣬Ϊrdp��compid����commserver��TargetCompID
                                (*MsgIter)->GetHeader()->SetOnBehalfOfSubID(m_ServiceID.getOnBehalfOfSubID());
                                (*MsgIter)->GetHeader()->SetOnBehalfOfCompID(m_ServiceID.getOnBehalfOfCompID());
                                CountSendMsg++;
                                //break;
                                ptempService = const_cast<DEP::Service *>(*m_ServiceIter);
                                (ptempService)->Send((*(*MsgIter)));
                            }


                    }
                }



            }



            //  ��ӡ���͵�8���ֶΣ��벻Ҫɾ��

            //cout<<"CountSendMsg"<<CountSendMsg<<endl;
            if(CountSendMsg)
            {
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetSenderSubID()=%s", (*MsgIter)->GetHeader()->GetSenderSubID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetSenderCompID=%s", (*MsgIter)->GetHeader()->GetSenderCompID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetTargetSubID()=%s", (*MsgIter)->GetHeader()->GetTargetSubID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetTargetCompID()=%s", (*MsgIter)->GetHeader()->GetTargetCompID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetOnBehalfOfSubID()=%s", (*MsgIter)->GetHeader()->GetOnBehalfOfSubID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetOnBehalfOfCompID()=%s", (*MsgIter)->GetHeader()->GetOnBehalfOfCompID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetDeliverToCompID()=%s", (*MsgIter)->GetHeader()->GetDeliverToCompID().c_str());
                LOG_DEBUG("(*MsgIter)->GetHeader()->GetDeliverToSubID()=%s", (*MsgIter)->GetHeader()->GetDeliverToSubID().c_str());

                DEP::ServiceID m_ServiceID2;
                m_ServiceID2=ptempService->GetServiceID();
                LOG_DEBUG("m_ServiceID2.getSenderSubID()=%s", m_ServiceID2.getSenderSubID().c_str());
                LOG_DEBUG("m_ServiceID2.getSenderCompID()=%s", m_ServiceID2.getSenderCompID().c_str());
                LOG_DEBUG("m_ServiceID2.getTargetSubID()=%s", m_ServiceID2.getTargetSubID().c_str());
                LOG_DEBUG("m_ServiceID2.getTargetCompID()=%s", m_ServiceID2.getTargetCompID().c_str());
            }
            else//����Ҳ���compid������so��д���󣬱���
            {
                LOG_ERROR( ERROR_CODE(WRONNG_MSG_TARGERCOMPID ), ERROR_MSG(WRONNG_MSG_TARGERCOMPID ));
                //return ERROR_CODE(WRONNG_TARGERCOMPID);

            }


            if(*MsgIter!=NULL)
            {
                (*MsgIter)->Clear();
                delete  *MsgIter;
                *MsgIter=NULL;
            }
        }

        if(*pMsgList!=NULL)
        {
            delete *pMsgList;
            *pMsgList=NULL;

        }
    }


    return    UTILITY::SUCCESS;

}

int SPADEListener::OnImixFastSPMsgXml(const IMIX::BasicMessage &inMessage)
{
    return    UTILITY::SUCCESS;

}

int SPADEListener::Commit(DBStruct* pDbCon)
{

    try{
        pDbCon->m_conn->commit();
    }
    catch (SQLException& ex)//����oracle�����쳣
    {
        LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
        return -1;
    }
    return    UTILITY::SUCCESS;

}

int SPADEListener::RollBack(DBStruct* pDbCon)
{
    try{
        pDbCon->m_conn->rollback();
    }
    catch (SQLException& ex)//����oracle�����쳣
    {
        LOG_ERROR(0, "errno code:%d,error value %s.", ex.getErrorCode(), (ex.getMessage()).c_str());
        return -1;
    }
    return UTILITY::SUCCESS;
}
