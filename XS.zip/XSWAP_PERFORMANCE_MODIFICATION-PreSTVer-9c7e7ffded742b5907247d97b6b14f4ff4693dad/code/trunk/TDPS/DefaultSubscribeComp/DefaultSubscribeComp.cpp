
#include "UTILITY/logfile.h"
#include "DefaultSubscribeComp.h"

#include <stdlib.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <sstream>

using namespace std;
using namespace UTILITY;

DefaultSubscribe::DefaultSubscribe()
{
}

DefaultSubscribe::~DefaultSubscribe()
{
}

int DefaultSubscribe::OnInit(ConfigFile& configure, const string& sec)
{
    return SUCCESS;
}

int DefaultSubscribe::GetMarketDataType(CFETS::SessionMessage *pMsg, std::string &strType,
        int &nReqType)
{
    IMIX20::MarketDataRequest req;
    req.setString(pMsg->m_msgBody, pMsg->m_len);
    
    int bookType = req.GetMDBookType();
    int entryType = atoi(req.GetOrderID().c_str()); 
   /*
   int entryType = 0;
   if (req.HasMDReqGrp())
   {
        IMIX20::MDReqGrp *pReqGrp = req.GetMDReqGrp();
        IMIX20::MDReqGrp::NoMDEntryTypes *pNoMDEntryTypes = pReqGrp->GetNoMDEntryTypes();
        if (pNoMDEntryTypes->HasMDEntryType())
        {
                entryType = pNoMDEntryTypes->GetMDEntryType();
        }
    }
   	*/     
    int reqType = req.GetSubscriptionRequestType();


    // entryType ��char�͵�.
    
 //   entryType -= 48; 

    LOG_DEBUG("Parse subscribe request: RequestType=%d"
            " MDBookType=%d",
            reqType,
            bookType);

    stringstream ss;
    ss << bookType << SUBSCRIBE_TYPE_DELI << entryType;
    strType = ss.str();
		
    // ReqType 
    nReqType = reqType;

    return SUCCESS;
}

string _Int2String(int i)
{
    stringstream ss;
    ss << i;
    return ss.str();
}

int DefaultSubscribe::GetSubscribeRespMsg(CFETS::SessionMessage* pMsg, int code, const string& text)
{
    IMIX20::MarketDataSnapshotFullRefresh rsp;

    rsp.SetApplErrorCode(_Int2String(code));
    rsp.SetApplErrorDesc(text);
    rsp.toBuffer();

    pMsg->setString(rsp.m_msgBody, rsp.m_len);

    return SUCCESS;
}

int DefaultSubscribe::GetType(std::string& type, std::string& subType) const
{
    type = DEFAULT_SUBSCRIBE_TYPE;
    subType = DEFAULT_SUBSCRIBE_SUBTYPE;
    return SUCCESS;
}

Component* Create()
{
    return static_cast<Component *>(new DefaultSubscribe);
}

int GetCompVersion(VersionInfo* pVersionInfo)
{
    return SUCCESS;
}

void Destroy(Component* pComponent)
{
    delete pComponent;
}
