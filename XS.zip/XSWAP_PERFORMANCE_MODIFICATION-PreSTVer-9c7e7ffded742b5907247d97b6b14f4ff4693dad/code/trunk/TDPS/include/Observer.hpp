/*
 * Observer.hpp
 *
 *  Created on: 2013-3-22
 *      Author: ShenDongdong
 */

#ifndef OBSERVER_H_
#define OBSERVER_H_

#include "CFETS/SessionMessage.h"
#include <set>

/// �۲��߽ӿ�
class IObserver
{
public:
    IObserver(){}
    virtual ~IObserver(){}
    virtual void OnNotify(CFETS::SessionMessage* pMsg) = 0;
};

/// �۲�����ӿ�
class ISubject
{
public:
    ISubject(){}
    virtual ~ISubject(){}
	// ֪ͨ�۲���
	virtual void Notify(CFETS::SessionMessage* pMsg) = 0;
	// ���ӹ۲���
	virtual void Attach(IObserver* pObserver) = 0;
	// ɾ���۲���
	virtual void Detach(IObserver* pObserver) = 0;
};

/// �۲�����
class CSubject: public ISubject
{
public:
    // ֪ͨ�۲���
    void Notify(CFETS::SessionMessage* pMsg)
    {
        ObserverMgrItor itor = m_observers.begin();
        for(; itor != m_observers.end(); itor++)
        {
            (*itor)->OnNotify(pMsg);
		}
    }
    // ���ӹ۲���
    void Attach(IObserver* pObserver)
    {
        if(pObserver != NULL)
        {
            m_observers.insert(pObserver);
        }
    }
    // ɾ���۲���
    void Detach(IObserver* pObserver)
    {
        m_observers.erase(pObserver);
    }
    
protected:
    typedef std::set<IObserver*> ObserverMgr;
    typedef ObserverMgr::iterator ObserverMgrItor;
    ObserverMgr m_observers;
};

#endif /* OBSERVER_H_ */
