
#ifndef GLBMACRO_H_
#define GLBMACRO_H_ 1

#include "IMIX20/Comm/MsgDefine.h"
#include "IMIX20/Comm/MessageType.h"
#include "IMIXT10/Comm/MsgDefine.h"
#include "BasicProtocol/BasicMessage.h"
#include "IMIXT10/Comm/MessageType.h"

#define IMIXAPP IMIX20
#define IMIXADMIN IMIXT10

#define IMIX_SEQ_FIELD_NUM 1181
#define GLB_LOCK ((void *)0)

#endif /* GLBMACRO_H_ */
