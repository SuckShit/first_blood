/*
 * Subscriber.h
 *
 *  Created on: 2013-3-29
 *      Author: ShenDongdong
 */

#ifndef SUBSCRIBER_H_
#define SUBSCRIBER_H_

#include <string>
#include "CFETS/SessionMessage.h"
#include "GlbMacro.h"

using std::string;

class IoChannel
{
public:
	virtual ~IoChannel() {};

	virtual const string &ToString() = 0;

	virtual bool operator==(const IoChannel &channel)
	{
		return operator==((IoChannel &)channel);
	}

	virtual bool operator==(IoChannel &channel) = 0;

	virtual int Send(CFETS::SessionMessage *message) = 0;
};

class Subscriber
{
public:
	virtual int OnMessage(unsigned char *message, unsigned int len) = 0;

	virtual int OnMessage(CFETS::SessionMessage *message) = 0;

	virtual const string &ToString() = 0;

	virtual ~Subscriber() {};

	virtual Subscriber *Clone() = 0;

	virtual IoChannel *GetIoChannel() = 0;

	virtual const string &GetCompID() const = 0;

	virtual	const string &GetSubID() const = 0;
};


#endif /* SUBSCRIBER_H_ */
