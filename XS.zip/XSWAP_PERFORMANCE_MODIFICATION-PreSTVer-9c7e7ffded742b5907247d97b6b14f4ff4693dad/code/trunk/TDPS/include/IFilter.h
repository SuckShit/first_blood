/*
 * IFilter.h
 *
 *  Created on: 2013-3-22
 *      Author: ShenDongdong
 */

#ifndef IFILTER_H_
#define IFILTER_H_

#include "CFETS/SessionMessage.h"
#include "Subscriber.h"

#define NAMING_SERVICE_FILTER_PREFIX "/ft/"
/**
 * ���������
 */
class IFilter
{
public:
    IFilter(){}
    virtual ~IFilter(){}
    // ����
	virtual bool DoFilter(Subscriber* pSubscriber, CFETS::SessionMessage* pMsg) = 0;
};



#endif /* IFILTER_H_ */
