#ifndef _SESSION_FILTER__H__
#define _SESSION_FILTER__H__

#include "IFilter.h"

class CSessionFilter : public IFilter
{
public:
    CSessionFilter() {}
    virtual ~CSessionFilter() {}

    bool DoFilter(Subscriber* pSubscriber, CFETS::SessionMessage* pMsg);
};

#endif  /* _SESSION_FILTER__H__ */
