#include "SessionFilter.h"
#include "UTILITY/logfile.h"
#include "BasicProtocol/BasicMessage.h"

bool CSessionFilter::DoFilter(Subscriber* pSubscriber, CFETS::SessionMessage* pMsg)
{
    // ����Ϣת��Ϊ������Ϣ
    IMIX::BasicMessage *msg = (IMIX::BasicMessage*)pMsg;

	if ((pSubscriber->GetCompID() == msg->GetHeader()->GetDeliverToCompID()) && (pSubscriber->GetSubID() == msg->GetHeader()->GetDeliverToSubID()))
    {
        return false;
    }
	
	return true;
}

