/***
Created on June 13, 2017
@author: No One
@version $Id
***/
#ifndef IRS_CODE_CONVERT_TDPS_H
#define IRS_CODE_CONVERT_TDPS_H


//#include "BasicProtocol/BasicMessage.h"
#include <string>
#include "data_type.h"
#include "order_book.h"
#include "TDPSCompGlbMacro.h"

using namespace std;

//add by hct
/*************成交状态******************/
// IMIX
#define E_IMIX_DLST_OK  'F'
#define E_IMIX_DLST_CANCEL  '4'
// IRS
#define E_IRS_DLST_OK  "1"
#define E_IRS_DLST_CANCEL  "2"
#define E_IRS_DLST_STOP  "3"   //完全提前终止

/*************交易方式******************/
// IMIX
#define E_IMIX_TRDMETHOD_MATCH  "7"
// IRS
#define E_IRS_TRDMETHOD_MATCH  "1"

/*************计息天数调整******************/
// IMIX
#define E_IMIX_ACCURAL_DAY_ADJUSTMENT_DAY  '1'
#define E_IMIX_ACCURAL_DAY_ADJUSTMENT_FIXED  '0'
// SIRS
#define E_SIRS_ACCURAL_DAY_ADJUSTMENT_DAY  "2"
#define E_SIRS_ACCURAL_DAY_ADJUSTMENT_FIXED  "1"

/*************清算方式******************/
// IMIX
#define E_IMIX_CLEARING_METHOD_SEPARATE  "13"
#define E_IMIX_CLEARING_METHOD_SHANGHAI  "6"
// SIRS
#define E_SIRS_CLEARING_METHOD_SEPARATE  "1"
#define E_SIRS_CLEARING_METHOD_SHANGHAI  "2"

/*************支付日调整******************/
// IMIX
#define E_IMIX_PAYMENT_DATE_RESET_NEXT_DAY  '2'
#define E_IMIX_PAYMENT_DATE_RESET_AFTER_DAY  '1'
#define E_IMIX_PAYMENT_DATE_RESET_BEFORE_DAY  '0'
// SIRS
#define E_SIRS_PAYMENT_DATE_RESET_NEXT_DAY  "3"
#define E_SIRS_PAYMENT_DATE_RESET_AFTER_DAY  "2"
#define E_SIRS_PAYMENT_DATE_RESET_BEFORE_DAY  "1"

/*************支付周期******************/
// IMIX
#define E_IMIX_PAYMENT_FREQUENCY_EXPIRE  "2"
#define E_IMIX_PAYMENT_FREQUENCY_DAY  "7"
#define E_IMIX_PAYMENT_FREQUENCY_WEEK  "6"
#define E_IMIX_PAYMENT_FREQUENCY_2WEEK "5"
#define E_IMIX_PAYMENT_FREQUENCY_MONTH  "3"
#define E_IMIX_PAYMENT_FREQUENCY_SEASON  "4"
#define E_IMIX_PAYMENT_FREQUENCY_HALF_YEAR  "0"
#define E_IMIX_PAYMENT_FREQUENCY_YEAR  "1"
// SIRS
#define E_SIRS_PAYMENT_FREQUENCY_EXPIRE  "1"
#define E_SIRS_PAYMENT_FREQUENCY_DAY  "2"
#define E_SIRS_PAYMENT_FREQUENCY_WEEK  "3"
#define E_SIRS_PAYMENT_FREQUENCY_2WEEK "4"
#define E_SIRS_PAYMENT_FREQUENCY_MONTH  "5"
#define E_SIRS_PAYMENT_FREQUENCY_SEASON  "6"
#define E_SIRS_PAYMENT_FREQUENCY_HALF_YEAR  "7"
#define E_SIRS_PAYMENT_FREQUENCY_YEAR  "8"

/*************浮动利率重置频率******************/
// IMIX
#define E_IMIX_RESET_FREQUENCY_EXPIRE  "7"
#define E_IMIX_RESET_FREQUENCY_DAY  "6"
#define E_IMIX_RESET_FREQUENCY_WEEK  "5"
#define E_IMIX_RESET_FREQUENCY_2WEEK "3"
#define E_IMIX_RESET_FREQUENCY_MONTH  "4"
#define E_IMIX_RESET_FREQUENCY_SEASON  "0"
#define E_IMIX_RESET_FREQUENCY_HALF_YEAR  "1"
#define E_IMIX_RESET_FREQUENCY_YEAR  "2"
// SIRS
#define E_SIRS_RESET_FREQUENCY_EXPIRE  "1"
#define E_SIRS_RESET_FREQUENCY_DAY  "2"
#define E_SIRS_RESET_FREQUENCY_WEEK  "3"
#define E_SIRS_RESET_FREQUENCY_2WEEK "4"
#define E_SIRS_RESET_FREQUENCY_MONTH  "5"
#define E_SIRS_RESET_FREQUENCY_SEASON  "6"
#define E_SIRS_RESET_FREQUENCY_HALF_YEAR  "7"
#define E_SIRS_RESET_FREQUENCY_YEAR  "8"

/*************计息基准******************/
// IMIX
#define E_IMIX_DAY_COUNT_ACTUAL_365  '3'
#define E_IMIX_DAY_COUNT_ACTUAL_360  '1'
#define E_IMIX_DAY_COUNT_ACTUAL_ACTUAL  '0'
#define E_IMIX_DAY_COUNT_30E_360  'D'
#define E_IMIX_DAY_COUNT_ACTUAL_365F  '5'
// SIRS
#define E_SIRS_DAY_COUNT_ACTUAL_365  "1"
#define E_SIRS_DAY_COUNT_ACTUAL_360  "2"
#define E_SIRS_DAY_COUNT_ACTUAL_ACTUAL  "3"
#define E_SIRS_DAY_COUNT_30E_360  "4"
#define E_SIRS_DAY_COUNT_ACTUAL_365F  "5"

/*************成交类型******************/
// IMIX
#define  E_IMIX_TRDSUBTP_DEFAULT  0				//默认值
#define  E_IMIX_TRDSUBTP_COMBTOCOMB  200		//期差与期差的成交
#define  E_IMIX_TRDSUBTP_COMBTOCOMBIMP  201		//期差与期差内隐的成交
#define  E_IMIX_TRDSUBTP_DIRTODIRIMP  202		//直接与直接外隐的成交
#define  E_IMIX_TRDSUBTP_DIRTODIR  203			//直接与直接的成交
#define  E_IMIX_TRDSUBTP_BRDGTOCOMB  301		//桥单与期差
#define  E_IMIX_TRDSUBTP_DIRTOBRDG  302			//直接与桥单
#define  E_IMIX_TRDSUBTP_BASTOBRDG  303			//基准互换合约实单与桥单成交
#define  E_IMIX_TRDSUBTP_BASTOBAS  204			//基准互换合约实单与基准互换合约实单成交
// IRS
#define  E_IRS_TRDSUBTP_DEFAULT  0					//默认值
#define  E_IRS_TRDSUBTP_COMBTOCOMB  200				//期差与期差的成交
#define  E_IRS_TRDSUBTP_COMBTOCOMBIMP  201			//期差与期差内隐的成交
#define  E_IRS_TRDSUBTP_DIRTODIRIMP  202			//直接与直接外隐的成交
#define  E_IRS_TRDSUBTP_DIRTODIR  203				//直接与直接的成交
#define  E_IRS_TRDSUBTP_BRDGTOCOMB  301				//桥单与期差
#define  E_IRS_TRDSUBTP_DIRTOBRDG  302				//直接与桥单
#define  E_IRS_TRDSUBTP_BASTOBRDG  303				//基准互换合约实单与桥单成交
#define  E_IRS_TRDSUBTP_BASTOBAS  204				//基准互换合约实单与基准互换合约实单成交

/************************************************************************/
/* 数据值定义                                                        */
/************************************************************************/
/*************買賣方向******************/
//IMIX
#define E_IMIX_SIDE_BID  "1"		//表示买
#define E_IMIX_SIDE_ASK  "2"		 //表示卖
// IRS
#define E_IRS_SIDE_BID  "0"			 //买
#define E_IRS_SIDE_ASK  "1"			 //卖


/*************訂單類型******************/
// IMIX
#define E_IMIX_ORDTP_CLICK  "b"     //点击成交
#define E_IMIX_ORDTP_LIMIT  "2"     //限价撮合
#define E_IMIX_ORDTP_NORMAL  "2"    //普通订单
#define E_IMIX_ORDTP_IMP  "e"       //隐含订单
#define E_IMIX_ORDTP_OCO  "b"       //OCO订单
#define E_IMIX_ORDTP_OUTSIDEOCO  "c"//OCO订单
#define E_IMIX_ORDTP_IMPOCO  "f"    //隐含OCO订单
#define E_IMIX_ORDTP_BILORD  "L"    //双边订单
#define E_IMIX_ORDTP_OUTSIDEBILORD  "g" //双边订单

// IRS
#define E_IRS_ORDTP_CLICK  "IOC"    //点击成交
#define E_IRS_ORDTP_LIMIT  "LMT"    //限价撮合
#define E_IRS_ORDTP_NORMAL  "R"     //普通订单
#define E_IRS_ORDTP_IMP  "i"        //隐含订单
#define E_IRS_ORDTP_OCO  "OCO"     //OCO订单
#define E_IRS_ORDTP_IMPOCO  "IOCO"  //隐含OCO订单
#define E_IRS_ORDTP_BIL  "BIL"      //双边订单

/*************订单是否强制执行******************/
// IMIX ExecInst中如果有c字符则为强制执行
#define E_IMIX_ISEXECUTE_TRUE  'c'
// IRS
#define E_IRS_ISEXECUTE_FALSE  "0"
#define E_IRS_ISEXECUTE_TRUE  "1"



//IRS市场状态枚举
enum E_MKT_ST
{
    E_MKT_ST_START = 1,//开市
    E_MKT_ST_OPEN = 2,//开盘
    E_MKT_ST_PAUSE = 3,//休市
    E_MKT_ST_CLOSE = 4,//收盘
    E_MKT_ST_END = 5,//闭市
    E_MKT_ST_CLOSE_IRS = 6,//IRS收盘
};

/************授信方式****************/
#define IMIX_CREDIT_METHOD_AMT  3
#define IMIX_CREDIT_METHOD_RELA  0
// IRS
#define IRS_CREDIT_METHOD_AMT  0//按额度授信
#define IRS_CREDIT_METHOD_RELA  1//按关系授信

/************订单报价单位****************/
#define PRICE_UNIT_VALID  -1//无效值
// IMIX
#define IMIX_PRICE_UNIT_BP  6//BP-Spread
#define IMIX_PRICE_UNIT_PERCENTAGE  1//百分比
// IRS
#define IRS_PRICE_UNIT_BP  0//BP-Spread
#define IRS_PRICE_UNIT_PERCENTAGE  1//百分比

/************合约状态****************/
//IMIX
#define IMIX_CONTRACT_ST_ACTIVE  "1"//激活
#define IMIX_CONTRACT_ST_INACTIVE  "2"//未激活
// IRS
#define IRS_CONTRACT_ST_INACTIVE  "0"//未激活
#define IRS_CONTRACT_ST_ACTIVE  "1"//激活
#define IRS_CONTRACT_ST_UNKNOW  "2"//待确定




#define APP_ERROR_CODE_START 510000
//程序错误码
enum APP_ERROR_CODE
{
    APP_CODE_FAILD = -1,//未知异常
    APP_CODE_SUCCESS = 0,   //成功
    APP_CODE_INCOM_PARAM_ERROR = APP_ERROR_CODE_START + 1,
    APP_CODE_INCOM_MSG_INVALID = APP_ERROR_CODE_START + 2,
    APP_CODE_USER_NOT_LOGON = APP_ERROR_CODE_START + 3,
    APP_CODE_UNKNOW_EXCEPTION = APP_ERROR_CODE_START + 4,
    APP_CODE_HEAP_NEW_ERR = APP_ERROR_CODE_START + 5,
    APP_CODE_IMIXAPI_ERR = APP_ERROR_CODE_START + 6,
    APP_CODE_SPEXEC_ERR = APP_ERROR_CODE_START + 7,
    APP_CODE_SPRET_ERR = APP_ERROR_CODE_START + 8,
    APP_CODE_SPRETSET_ERR = APP_ERROR_CODE_START + 9,
    APP_CODE_ANALYZE_IMIXMSG_ERR = APP_ERROR_CODE_START + 10,
    //APP_CODE_UNHANDLE_MSG = APP_ERROR_CODE_START + 11,
    APP_CODE_REQFUNC_ERR = APP_ERROR_CODE_START + 12,
    APP_CODE_IRSINIT_ERR = APP_ERROR_CODE_START + 13,
    APP_CODE_SQL_EXCEPTION = APP_ERROR_CODE_START + 14,
    APP_CODE_MARKET_ERR = APP_ERROR_CODE_START + 15,
};

// IMIX 消息字段取值，PartyRole的取值
enum PARTY_ROLE
{
    E_PARTY_ROLE_DEAL_USER = 27,        //成交数据消息中订单提交用户标识
    E_PAPTY_ROLE_ANALOGUE_USER = 37, //成交数据消息中的对手方用户标识
    E_PARTY_ROLE_IMPORD_ORG = 13,   //隐含订单消息中订单提交机构标识
    E_PARTY_ROLE_BRDGORD_ORG = 14,  //桥订单标识
    E_PARTY_ROLE_ORD_USER = 11,     //订单状态消息中的订单提交用户标识
    E_PARTY_ROLE_USER = 121,            //统一用户标识
};


/**********************************add by hct *****************************/
/* 买卖方向转换                                                         */
/************************************************************************/
string ImixToIrs_Side(string strIn);
//string IrsToImix_Side(string strIn);
string IrsToImix_Side(int32 intrnlSide);

/************************************************************************/
/* 订单提交类型转换                                                     */
/************************************************************************/
//string ImixToIrs_OrdType(string strIn);
int32 ImixToIrs_OrdType(string strIn);
//string IrsToImix_OrdType(string strIn);
string IrsToImix_OrdType(int32 intrnlOrdTpye);
string IrsToImixOutSide_OrdType(string strIn);
/************************************************************************/
/* 订单提交类型转换                                                     */
/************************************************************************/
string ImixToIrs_IsExec(string strIn);

/************************************************************************/
/* 成交状态转换                                                     */
/************************************************************************/
string ImixToIrs_DealStatus(char cIn);
//char IrsToImix_DealStatus(string strIn);
char IrsToImix_DealStatus(int16 dealSts);
char SIrsToImix_DealStatus(string strIn);
/************************************************************************/
/* 成交类型转换                                                          */
/************************************************************************/
int ImixToIrs_TrdType(int nIn);
int IrsToImix_TrdType(int nIn);

/************************************************************************/
/* 市场状态标识转换                                                     */
/************************************************************************/
int ImixToIrs_MktFlag(int nIn);
int IrsToImix_MktFlag(int nIn);

/************************************************************************/
/* 授信方式                                                     */
/************************************************************************/
int ImixToIrs_CreditMethod(int nIn);
int IrsToImix_CreditMethod(int nIn);
/************************************************************************/
/* 订单状态转换                                                     */
/************************************************************************/
char ImixToIrs_OrdStatus(char cIn);
//char IrsToImix_OrdStatus(char cIn);
char IrsToImix_OrdStatus(int32 intrnlOrdSts);

/************************************************************************/
/* 订单报价单位转换                                                     */
/************************************************************************/
int ImixToIrs_PriceUnit(int nIn);
int IrsToImix_PriceUnit(int nIn);

/************************************************************************/
/* 交易方式转换                                                     */
/************************************************************************/
string ImixToIrs_TrdMethod(string strIn);
string IrsToImix_TrdMethod(string strIn);

/************************************************************************/
/* 合约状态                                                    */
/************************************************************************/
string ImixToIrs_ContractSt(string strIn);
string IrsToImix_ContractSt(string strIn);

// 计息天数调整
char SIrsToImix_AccDayAdjmnt(string strIn);

// 清算方式
string SIrsToImix_ClearingMethod(string strIn);

// 支付日调整
char SIrsToImix_PayDateReset(string strIn);

// 支付周期
string SIrsToImix_PaymentFrequency(string strIn);

// 浮动利率重置频率
string SIrsToImix_ResetFrequency(string strIn);

// 计息基准
char SIrsToImix_DayCount(string strIn);

/************************************
*函数名：StringToChar
*功能： 获取字符串首字符
*参数：
    strIn:  [IN]输入字符串
    cOut:   [OUT]获取到的字符
*返回值:成功，失败
*************************************/
int32 StringToChar(string strIn, char& cOut);
/************************************
*函数名：CharToString
*功能： 将字符转换为字符串
*参数：
    cIn:    [IN]输入字符串
*返回值:字符串
*************************************/
string CharToString(char cIn);
void DoubleToString(double dValue, string& strValue);

void DoubleZToString(double dValue, string& strValue);

void IntToString(int nValue, string& strValue, int nRadix = 10);

int StringToInt(string strValue);

int64 PrefixStringToInt64(string strValue, int32 prefixLen);

int64 StringToInt64(string strValue);
void DoubleToString2(double dValue, string& strValue);

void DoubleToString4(double dValue, string& strValue);
bool IsCombContract(string strContractName);

//基准互换合约
bool IsBasContract(string strContractName);

/*=====================================
* 期差合约名称
======================================*/

#define CONTRACT_COMB_NUM  10
const string CONTRACT_COMB[CONTRACT_COMB_NUM] = {"FR007_1Y*2Y", "FR007_2Y*5Y", "Shibor3M_1Y*2Y", "Shibor3M_2Y*5Y",
                                            "FR007_6M*9M", "FR007_9M*1Y", "FR007_1Y*5Y", "Shibor3M_6M*9M", "Shibor3M_9M*1Y",
                                            "Shibor3M_1Y*5Y"};

/*************市场状态******************/
#define MKT_FLAG_NUM  6
const int IMIX_MKT_FLAGS[MKT_FLAG_NUM] = {7, 2, 8, 3, 9, 6};
const int IRS_MKT_FLAGS[MKT_FLAG_NUM] = {1, 2, 3, 4, 5, 6};

/*************订单状态******************/
//IRS: N- 新订单 2- 有效订单 1- 订单冻结 3- 订单成交 4- 被撤单 0- 订单无效
//IMIX:N- 新订单 0- 有效订单 9- 订单冻结 2- 订单成交 4- 被撤单 C- 订单无效

// IRS
const char E_IRS_ORD_STS_ACTIVE = '0'; //有效
const char E_IRS_ORD_STS_FILLED = '2'; //成交
const char E_IRS_ORD_STS_CANCEL = '4'; //Cancel
const char E_IRS_ORD_STS_FREEZE = '9'; //Freeze


#define ORD_ST_NUM  6
const char IRS_ORD_STATUS[ORD_ST_NUM] = {'N','2', '1', '3', '4', '0'};
const char IMIX_ORD_STATUS[ORD_ST_NUM] = {'N', '0', '9', '2', '4', 'C'};

/****************************************************add by hct *********************/

#endif