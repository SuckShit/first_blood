/***
Created on Aug 29, 2017
@author: Haihua.Chen
@version $Id
***/

#ifndef _GEN_PACT_
#define _GEN_PACT_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define CONTRCT_NAME_LENGTH   50
#define UPDATE_TIME_LENGTH    20
#define MAX_LEVDAT_CNT        20
#define MAX_BEST_TRD_CNT      2
#define ORDR_BEST_SIDE_BUY    0
#define ORDR_BEST_SIDE_SELL   1
#define ORDR_TRD_SIDENO_BUY   0
#define ORDR_TRD_SIDENO_SELL  1
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct LevelDatS{
	int32 ordrSide;   ///��������
	int64 ordrPrc;   ///��������
	int64 ordrAmnt;   ///�ɳɽ���
	int64 ntnlAmnt;   ///���屾��
} LevelDatT, *pLevelDatT;

/*��λ����IMIX*/
typedef struct MktDpthDataS{
		char cntrctName[CONTRCT_NAME_LENGTH];   ///��Լ����
		char updtTime[UPDATE_TIME_LENGTH];   ///�������ʱ��
		LevelDatS levelDat[MAX_LEVDAT_CNT];
} MktDpthDataT, *pMktDpthDataT;



typedef struct BestDataS{
  char cntrctName[CONTRCT_NAME_LENGTH];   ///��Լ����
  char updtTime[UPDATE_TIME_LENGTH];   ///�������ʱ��
  int64 ordrBuyPrc;   ///���򶩵�����
  int64 ordrSelPrc;   ///�����򶩵�����	   
  int64 ordrBuyAmnt;   ///����ɳɽ���
  int64 ordrSelAmnt;   ///������ɳɽ���
  int64 ntnlBuyAmnt;   ///�������屾��
  int64 ntnlSelAmnt;   ///���������屾��  
  int32 nmbrBuyOfOrdr;   ///���򶩵�����
  int32 nmbrSelOfOrdr;   ///�����򶩵�����  
} BestDataT, *pBestDataT;

/*���ż�*/
typedef struct MktBestDataS{
		BestDataT bestData;
	//	BestDataT TrdData[MAX_BEST_TRD_CNT];
} MktBestDataT, *pMktBestDataT;



typedef struct MktTradeDataS{
    int64     openPrc;
    int64     intraPrc;
    int64     HighPrc;
    int64     LowPrc;   
    int64     lastTrdPrc;
    int64     lastAmt;
    int64     lastTrdDatTim;
    int64     lastUpdateTim;
} MktTradeDataT, *pMktTradeDataT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/


 #endif /* _GEN_PACT_ */