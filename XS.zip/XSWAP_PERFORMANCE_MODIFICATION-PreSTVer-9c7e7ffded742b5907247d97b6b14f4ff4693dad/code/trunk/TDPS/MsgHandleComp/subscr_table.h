/***
Created on Aug 29, 2017
@author: Haihua.Chen
@version $Id
***/

#ifndef _SUB_TABLE_
#define _SUB_TABLE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "bit_lib.h"
#include "order_type.h"
#include "common_hash.h"
#include "shm.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

#define MAX_SUB_RCRD_CNT   100
#define SHM_SUB_ORG_NAME               "SHM_SUB_ORG_@@"
#define SHM_SUB_TOPIC_NAME             "SHM_SUB_TOPIC_@@"

#define MAX_TOPIC_NAME_LEN 16

//add by hct		2017.9.19	¶¨ÒåºÏÔ¼»òÕßÊÐ³¡ÀàÐÍµÄ×î´ó³¤¶È
#define MAX_SUB_TYPE_LEN 15
//add by hct		2017.9.19	定义用户ID的最大长度
#define MAX_USR_ID_LEN 32
//#define MAX_TIME_LEN 20
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct SubOrgInfoKeyS
{
	  int64     		orgId;

	  //add by hct		2017.9.19   添加标识订阅类型的字段，主要有合约和市场两种
	  char			subType[MAX_SUB_TYPE_LEN];
	  char			usrID[MAX_USR_ID_LEN];

	  char			topicName[MAX_TOPIC_NAME_LEN];
} SubOrgInfoKeyT, *pSubOrgInfoKeyT;

typedef struct SubOrgInfoS
{
    SubOrgInfoKeyT   subOrgKey;
    //增加时间
    char            	   oprtTm[MAX_TIME_LEN];
    uint32     				prvPos;
    uint32     				nxtPos;
} SubOrgInfoT, *pSubOrgInfoT;

typedef struct TopicKeyS
{
    char     topicName[MAX_TOPIC_NAME_LEN];

    //add by hct		2017.9.19   添加标识订阅类型的字段，主要有合约和市场两种
    char			subType[MAX_SUB_TYPE_LEN];
	
} TopicKeyT, *pTopicKeyT;
 
typedef struct SubTopicS
{
    TopicKeyT  topicKey;
    uint32      frstPos;
    uint32      lstPos;
} SubTopicT, *pSubTopicT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
 ResCodeT SubMgmtShmCreate(int64 orgCnt, int64 topicCnt);
 ResCodeT SubMgmtShmAttach();
 ResCodeT SubMgmtShmDelete();
 ResCodeT SubMgmtShmDetach();
 
 ResCodeT SubTopicAdd(pSubTopicT pSubTopic, uint32 * pPos);
 ResCodeT SubTopicChk(pTopicKeyT pKey, pSubTopicT * ppSubTopic, uint32 * pPos);
 ResCodeT SubTopicUpdtByPos(uint32 pos, pSubTopicT pSubTopic);
 ResCodeT FindSubOrgByTopic(pTopicKeyT pKey,pSubTopicT * ppSubTopic);
 ResCodeT GetCmnHashTopicDataExt(uint32 * pDataPos, void ** ppData);
 //主键增加用户维度，modify by hct 2017.9.27
 ResCodeT SubTopicOrgUserAdd(pSubOrgInfoT pSubOrg, uint32 * pPos);
  
 ResCodeT SubTopicOrgUserChk(pSubOrgInfoKeyT pKey, pSubOrgInfoT * ppSubOrg ,uint32 * pPos);
 
 ResCodeT SubTopicOrgUserUpdtByPos(uint32 pos, pSubOrgInfoT pSubOrg);
 
 ResCodeT SubTopicOrgUserDel(pSubOrgInfoKeyT pKey);

 ResCodeT GetSubOrgUserByPos(uint32 pos, pSubOrgInfoT * ppSubOrg);
 //add by hct ,reset用户订阅行情信息的内存块
 ResCodeT SubOrgInfoShmReset();
 ResCodeT printHashDataSubOrg();
 
 #endif /* _SUB_TABLE_ */