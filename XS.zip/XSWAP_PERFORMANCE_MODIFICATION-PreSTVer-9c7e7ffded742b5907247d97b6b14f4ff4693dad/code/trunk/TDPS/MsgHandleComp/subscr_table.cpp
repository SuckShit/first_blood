/***
Created on Aug 29, 2017
@author: Haihua.Chen
@version $Id
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>       /* define standard i/o functions        */
#include <stdlib.h>      /* define standard library functions    */
#include <string.h>      /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "err_lib.h"
#include "uti_tool.h"
#include "common_hash.h"
#include "shm.h"
#include "subscr_table.h"
#include "order_book.h"
#include "TDPSCompErrorDef.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
static CmnHashHndlT gSubOrgMgmtHshHdl;
static CmnHashHndlT gSubTopicMgmtHshHdl;
 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
 

ResCodeT SubMgmtShmCreate(int64 orgCnt, int64 topicCnt)
{
    BEGIN_FUNCTION("SubMgmtShmCreate");
    ResCodeT rc = NO_ERR;

//create org table    
    HashTableRecInfoT recInfo;
    void *pShmRoot;
    char shmNameOrg[] = SHM_SUB_ORG_NAME;   
    char shmNameTopic[] = SHM_SUB_TOPIC_NAME; 
     
    recInfo.recSize = sizeof(SubOrgInfoT);
    recInfo.keyOffset = offsetof(SubOrgInfoT, subOrgKey);
    recInfo.keySize = sizeof(SubOrgInfoKeyT);
    recInfo.recCnt = orgCnt;
    recInfo.bNeedTimeList = TRUE;    
    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)shmNameOrg), 
                                recInfo, TRUE, &pShmRoot, &gSubOrgMgmtHshHdl);
    RAISE_ERR(rc, RTN);
		
//create topic table
       
    recInfo.recSize = sizeof(SubTopicT);
    recInfo.keyOffset = offsetof(SubTopicT, topicKey);
    recInfo.keySize = sizeof(TopicKeyT);
    recInfo.recCnt = topicCnt;
    recInfo.bNeedTimeList = TRUE;    
    rc = CmnHashTblCreateWithTimeList(GetShmNm((char*)shmNameTopic), 
                                recInfo, TRUE, &pShmRoot, &gSubTopicMgmtHshHdl);
    RAISE_ERR(rc, RTN);
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT SubrMgmtShmAttach()
{
    BEGIN_FUNCTION("SubrMgmtShmAttach");
    ResCodeT rc = NO_ERR;
    
    void *pShmRootOrg;
    char shmNameOrg[] = SHM_SUB_ORG_NAME; 
    char shmNameTopic[] = SHM_SUB_TOPIC_NAME;    
    rc = CmnHashTblAttach(GetShmNm((char*)shmNameOrg), &pShmRootOrg, &gSubOrgMgmtHshHdl);
    RAISE_ERR(rc, RTN);

    void *pShmRootTopic;  
    rc = CmnHashTblAttach(GetShmNm((char*)shmNameTopic), &pShmRootTopic, &gSubTopicMgmtHshHdl);
    RAISE_ERR(rc, RTN);
        
		EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT OrdrMgmtShmDetach()
{
    BEGIN_FUNCTION("OrdrMgmtShmDetach");
    ResCodeT rc = NO_ERR;
    
    char shmNameOrg[] = SHM_SUB_ORG_NAME;
    char shmNameTopic[] = SHM_SUB_TOPIC_NAME;
    rc = ShmDetach((char*)shmNameOrg);
    RAISE_ERR(rc, RTN);

    rc = ShmDetach((char*)shmNameTopic);
    RAISE_ERR(rc, RTN);
    
		EXIT_BLOCK();  
    RETURN_RESCODE;
}

ResCodeT SubMgmtShmDelete()
{
    BEGIN_FUNCTION("SubMgmtShmDelete");
    ResCodeT rc = NO_ERR;
    
    char shmNameOrg[] = SHM_SUB_ORG_NAME;
    char shmNameTopic[] = SHM_SUB_TOPIC_NAME;
    rc = ShmDelete((char*)shmNameOrg);
    RAISE_ERR(rc, RTN);

    rc = ShmDelete((char*)shmNameTopic);
    RAISE_ERR(rc, RTN);
        
		EXIT_BLOCK();  
    RETURN_RESCODE;
}

ResCodeT SubTopicAdd(pSubTopicT pSubTopic, uint32 * pPos)
{
    BEGIN_FUNCTION("SubTopicAdd SubTopic");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    uint32 nodePos;
    pSubTopicT  pTempTopic;
    
    rc = CmnHashCheckDataExt(gSubTopicMgmtHshHdl, (void*)&pSubTopic->topicKey, &isExist, &nodePos, (void**)&pTempTopic);
    RAISE_ERR(rc, RTN);
    
    *pPos = nodePos;
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(NO_ERR);
    }
   
    rc = CmnHashLogData(gSubTopicMgmtHshHdl, pSubTopic, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;	
}


ResCodeT SubTopicChk(pTopicKeyT pKey, pSubTopicT * ppSubTopic,uint32 * pPos)
{
    BEGIN_FUNCTION("SubTopicChk SubTopic");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gSubTopicMgmtHshHdl, (void*)pKey, &isExist, pPos, (void**)ppSubTopic);
    RAISE_ERR(rc, RTN);
    
    if (isExist == FALSE)
    {
        return ERROR_CODE(CMP_SUBTOPIC_CHECK_NOT_EXIT);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SubTopicUpdtByPos(uint32 pos, pSubTopicT pSubTopic)
{
    BEGIN_FUNCTION("OrdrMgmtUpdtByPos SubTopic");
    ResCodeT rc = NO_ERR;

    rc = CmnHashUpdateData(gSubTopicMgmtHshHdl, (void*) pSubTopic, pos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

//Sub_Org_Info	modify by hct 2017.9.20
ResCodeT SubTopicOrgUserAdd(pSubOrgInfoT pSubOrg, uint32 * pPos)
{
    BEGIN_FUNCTION("SubTopicOrgUserAdd OrgInfo");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    uint32 nodePos;
    pSubOrgInfoT  pTempOrg;
    pSubOrgInfoT  pLstOrgInfo;
    uint32 topicPos;
    pSubTopicT pSubTopic;
    TopicKeyT tempTopicKey;
         
    rc = CmnHashCheckDataExt(gSubOrgMgmtHshHdl, (void*)&pSubOrg->subOrgKey, &isExist, &nodePos, (void**)&pTempOrg);
    
    RAISE_ERR(rc, RTN);
    
    *pPos = nodePos;
    
    if (isExist == TRUE)
    {
        THROW_RESCODE(NO_ERR);	
    }
    memset(tempTopicKey.topicName, 0, MAX_TOPIC_NAME_LEN);  
    memcpy(tempTopicKey.topicName,pSubOrg->subOrgKey.topicName,MAX_TOPIC_NAME_LEN);
    //modify by hct 新增联合主键主题type
    memset(tempTopicKey.subType, 0, MAX_SUB_TYPE_LEN);  
    memcpy(tempTopicKey.subType,pSubOrg->subOrgKey.subType,MAX_SUB_TYPE_LEN);        
	
	
    rc = SubTopicChk(&tempTopicKey, &pSubTopic, &topicPos);
    RAISE_ERR(rc, RTN);
    
    if(CMN_LIST_NULL_NODE == pSubTopic->frstPos)
    {
      pSubTopic->frstPos = *pPos;
      pSubTopic->lstPos  = *pPos;
      pSubOrg->prvPos  = CMN_LIST_NULL_NODE;
      pSubOrg->nxtPos  = CMN_LIST_NULL_NODE;
    }
    else
    {
    	
      rc = CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pSubTopic->lstPos,(void**)&pLstOrgInfo);
      RAISE_ERR(rc, RTN);
    	pLstOrgInfo->nxtPos = *pPos;    	
    	pSubOrg->prvPos  = pSubTopic->lstPos;
      pSubOrg->nxtPos  = CMN_LIST_NULL_NODE;
    	
    	pSubTopic->lstPos  = *pPos;
    }
    
    rc = CmnHashLogData(gSubOrgMgmtHshHdl, pSubOrg, nodePos, TRUE, TRUE);
    RAISE_ERR(rc, RTN);       
    
    EXIT_BLOCK();
    RETURN_RESCODE;	
}

ResCodeT SubTopicOrgUserChk(pSubOrgInfoKeyT pKey, pSubOrgInfoT * ppSubOrg, uint32 * pPos)
{
    BEGIN_FUNCTION("OrdrMgmtChk OrgInfo");
    ResCodeT rc = NO_ERR;
    
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gSubOrgMgmtHshHdl, (void*)pKey, &isExist, pPos, (void**)ppSubOrg);
    RAISE_ERR(rc, RTN);

    if (isExist == FALSE)
    {
        return ERROR_CODE(CMP_SUBORG_CHECK_NOT_EXIT);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT SubTopicOrgUserUpdtByPos(uint32 pos, pSubOrgInfoT pSubOrg)
{
    BEGIN_FUNCTION("OrdrMgmtUpdtByPos OrgInfo");
    ResCodeT rc = NO_ERR;

    rc = CmnHashUpdateData(gSubOrgMgmtHshHdl, (void*) pSubOrg, pos);
    RAISE_ERR(rc, RTN);

    EXIT_BLOCK();
    RETURN_RESCODE;

}

ResCodeT SubTopicOrgUserDel(pSubOrgInfoKeyT pKey)
{
    BEGIN_FUNCTION("SubTopicDel OrgInfo");
    BOOL isExist = FALSE;
    uint32 pos;
    pSubOrgInfoT  pTempOrg ,pPrevOrg, pNextOrg;
    uint32 topicPos;
    pSubTopicT pSubTopic;
    TopicKeyT tempTopicKey;
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashCheckDataExt(gSubOrgMgmtHshHdl, (void*)pKey, &isExist, &pos, (void**)&pTempOrg);
	  RAISE_ERR(rc, RTN);
		CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pos,(void**)&pTempOrg);
   	  
    if (isExist == FALSE)
    {
        return ERROR_CODE(CMP_SUBTOPIC_CHECK_NOT_EXIT);
    }
    
    memset(tempTopicKey.topicName, 0, MAX_TOPIC_NAME_LEN); 
    memcpy(tempTopicKey.topicName,pKey->topicName,strlen(pKey->topicName));
    //modify by hct 新增联合主键主题type
    memset(tempTopicKey.subType, 0, MAX_SUB_TYPE_LEN);  
    memcpy(tempTopicKey.subType,pKey->subType,MAX_SUB_TYPE_LEN);    
	
	
    rc = SubTopicChk(&tempTopicKey, &pSubTopic, &topicPos);
    RAISE_ERR(rc, RTN);
       	  	          
    if(pTempOrg->prvPos == CMN_LIST_NULL_NODE)
    {
    	  if(pTempOrg->nxtPos == CMN_LIST_NULL_NODE)
    	  {
          RETURN_RESCODE;
    	  }
    	  CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pTempOrg->nxtPos,(void**)&pNextOrg);
    	  pNextOrg->prvPos = CMN_LIST_NULL_NODE;
        pSubTopic->frstPos = pTempOrg->nxtPos;
    }
    else if(pTempOrg->nxtPos == CMN_LIST_NULL_NODE)
    {
    	  CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pTempOrg->prvPos,(void**)&pPrevOrg);
    	  pPrevOrg->nxtPos = CMN_LIST_NULL_NODE;
    	  pSubTopic->lstPos  = pTempOrg->prvPos;
    }
    else
    {
    	  CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pTempOrg->prvPos,(void**)&pPrevOrg);
    	  CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pTempOrg->nxtPos,(void**)&pNextOrg);
    	  pPrevOrg->nxtPos = pTempOrg->nxtPos;
    	  pNextOrg->prvPos = pTempOrg->prvPos;
    }   
    rc = CmnHashDeleteData(gSubOrgMgmtHshHdl, pos);
    RAISE_ERR(rc, RTN);
      
    EXIT_BLOCK();
    RETURN_RESCODE;
}

//modify by hct 2017.10.29
ResCodeT FindSubOrgByTopic(pTopicKeyT pKey,pSubTopicT * ppSubTopic)
{
    BEGIN_FUNCTION("FindSubOrgByTopic");
    ResCodeT rc = NO_ERR;
    pSubTopicT  pSubTopic;
    //pSubOrgInfoT pSubOrgInfo;
    uint32 topicPos;
    BOOL isExist = FALSE;
    
    rc = CmnHashCheckDataExt(gSubTopicMgmtHshHdl, (void*)pKey, &isExist, &topicPos, (void**)ppSubTopic);

    RAISE_ERR(rc, RTN);
    
    if (isExist == FALSE)
    {
        return ERROR_CODE(CMP_SUBTOPIC_CHECK_NOT_EXIT);
    }

    if(pSubTopic->frstPos == CMN_LIST_NULL_NODE)
    {
    	  return ERROR_CODE(CMP_SUBORG_CHECK_NOT_EXIT);
    }

	/*else
    {
    		CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pSubTopic->frstPos,(void**)&pSubOrgInfo);
    	  printf("topicName:%s , OrgID:%d, prev:%d ,next:%d \n",pSubOrgInfo->subOrgKey.topicName,
    	  	          pSubOrgInfo->subOrgKey.orgId,pSubOrgInfo->prvPos,pSubOrgInfo->nxtPos);    		
    	  while(pSubOrgInfo->nxtPos != CMN_LIST_NULL_NODE)
    	 	{
    	  	CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pSubOrgInfo->nxtPos,(void**)&pSubOrgInfo);
    	  	printf("topicName:%s , OrgID:%d, prev:%d ,next:%d \n",pSubOrgInfo->subOrgKey.topicName,
    	  	          pSubOrgInfo->subOrgKey.orgId,pSubOrgInfo->prvPos,pSubOrgInfo->nxtPos);
    	  }
    	  
    	  
    }*/

    EXIT_BLOCK();
    RETURN_RESCODE;

}



ResCodeT GetSubOrgUserByPos(uint32 pos, pSubOrgInfoT * ppSubOrg)
{
    BEGIN_FUNCTION("GetSubOrgUserByPos");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashReadDataAddrByPos(gSubOrgMgmtHshHdl,pos,(void**)ppSubOrg);
    RAISE_ERR(rc, RTN);
        
    EXIT_BLOCK();
    RETURN_RESCODE;	
}

ResCodeT GetCmnHashTopicDataExt(uint32 * pDataPos, void ** ppData)
{
	  ResCodeT rc = NO_ERR;
	  rc = CmnHashIterDataExt(gSubTopicMgmtHshHdl, pDataPos, ppData);
	  if(rc != NO_ERR)
		{
		    return ERROR_CODE(CMP_SUBTOPIC_CHECK_NOT_EXIT);    
		} 
		 
		return NO_ERR;
}
ResCodeT printHashDataSubOrg()
{
	  ResCodeT rc = NO_ERR;
	  uint32 dataPos = CMN_LIST_NULL_NODE;
	  pSubOrgInfoT pSubOrgInfo;
	  
	  
	  while(TRUE)
		{
			rc = CmnHashIterDataExt(gSubOrgMgmtHshHdl, &dataPos,(void **) &pSubOrgInfo);
			if(dataPos == CMN_LIST_NULL_NODE)
			{
				break;
			}
			printf(">>>>>>>pSubOrgInfo->subOrgKey.orgId : %d\n",pSubOrgInfo->subOrgKey.orgId);
			printf(">>>>>>>pSubOrgInfo->subOrgKey.subType : %s\n",pSubOrgInfo->subOrgKey.subType);
			printf(">>>>>>>pSubOrgInfo->subOrgKey.topicName : %s\n",pSubOrgInfo->subOrgKey.topicName);
			printf(">>>>>>>pSubOrgInfo->subOrgKey.usrID : %s\n",pSubOrgInfo->subOrgKey.usrID);	
	  	}	 
	return NO_ERR;
}

//add by hct ,reset用户订阅行情信息的内存块
ResCodeT SubOrgInfoShmReset()
{
    BEGIN_FUNCTION("SubOrgInfoShmReset");
    ResCodeT rc = NO_ERR;
    
    rc = CmnHashResetTbl(gSubOrgMgmtHshHdl);
    if(rc != NO_ERR)
		{
		    return ERROR_CODE(CMP_RESET_SHM_FAILD);    
		} 
	
	uint32 dataPos = CMN_LIST_NULL_NODE;
	pSubTopicT pSubTopic;
	 		
	while(TRUE)
		{
			rc = GetCmnHashTopicDataExt(&dataPos, (void**) &pSubTopic);
			if(dataPos == CMN_LIST_NULL_NODE)
			{
				break;
			}
			//由于suborg用户订阅表被清干净了，所以行情表关联用户订阅的表的指针信息全部置为 -1
			pSubTopic->frstPos = CMN_LIST_NULL_NODE;
			pSubTopic->lstPos = CMN_LIST_NULL_NODE;	
		}    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}