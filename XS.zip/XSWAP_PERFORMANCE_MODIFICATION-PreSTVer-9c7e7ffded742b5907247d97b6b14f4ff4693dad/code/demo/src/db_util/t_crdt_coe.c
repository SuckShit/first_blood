/***
Created on May 22, 2017

@author: Zhou
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header File*/
#include "../header/dbhelp.h"
#include "../header/common_macro.h"
#include "../db_header/t_crdt_coe.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT DbTCrdtCoeGetAll(TCrdtCoe *pData, int32 *size, int32 *pErrCode){
    BEGIN_FUNCTION( "DbTCrdtCoeGetAll" );

    int32    errCode = 0;
	ResCodeT rc = NO_ERR;
	int32 dataCnt = 0;
	int32 index;
	
	OCI_Connection *ppCn;
	OCI_Statement *ppStmt;
	OCI_Resultset *rs;
	
	char perparedSql[200];
    
	strcpy(perparedSql,"SELECT ");
	strcat(perparedSql,"CNTRCT_SRNO,CRDT_ORG_ID,CRDT_COE");
    strcat(perparedSql," FROM CRDT_COE ");
	
    rc = DbExePrepare(&ppCn, &ppStmt, "SELECT COUNT(*) FROM CRDT_COE");
	RAISE_ERROR(rc,RTN);
	
	if(!OCI_Execute(ppStmt))
    {
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	rs = OCI_GetResultset(ppStmt);
	if(rs == NULL)
    {
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	if(OCI_FetchNext(rs)){
	  dataCnt = OCI_GetInt(rs,1);
	}
	
	if (dataCnt == 0){
	  // No data in table crdt_mgnr
	  RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
	}
//	TCrdtMgnr *pData = *ppData;
	
//	pData = (TCrdtMgnr*)malloc(dataCnt*sizeof(TCrdtMgnr));
//	memset(pData, 0x00, dataCnt*sizeof(TCrdtMgnr));
	
	if(!OCI_ExecuteStmt(ppStmt,perparedSql))
	{
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	rs = OCI_GetResultset(ppStmt);
	
	index = 0;
	while(OCI_FetchNext(rs)){
	  (pData+index)->cntrct_srno = OCI_GetBigInt(rs,1);
	  (pData+index)->crdt_org_id = OCI_GetBigInt(rs,2);
	  (pData+index)->crdt_coe = OCI_GetFloat(rs,3);
	  
	  index++;
	}
	
	*size = index;
	
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/********* Test Code Start ********************/
// int main(int argc,char* argv[]){
  // BEGIN_FUNCTION( "main" );
  // // printf("it works.\n");
  // ResCodeT rc;
  // int64 key;
  // int32 err_code;
  // TCrdtCoe allInfo[1000];
  // int32 count;
  // int index;
  
  // DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");

  // /********* Test Code for GetAll ********************/
  // rc = DbTCrdtCoeGetAll(allInfo, &count, &err_code);
  
  
  // printf("All data get. The count is : %d\n",count);
  // for(index=0;index<count;index++){
    // printf("The cntrct_srno[%d] is : %d\n", index, allInfo[index].cntrct_srno);
    // printf("The crdt_org_id[%d] is : %d\n", index, allInfo[index].crdt_org_id);
    // printf("The crdt_coe[%d] is : %f\n", index, allInfo[index].crdt_coe);
  // }
  /********* Test Code for GetAll ********************/

  
  // /********* Test Code for Update ********************/
  // rc = DbTCrdtMgnrPrepareUpdate();
  // if NOTOK(rc){
    // printf("update preparation failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  // crdtInfo.crdt_id=1;
  // crdtInfo.crdt_org_id=11111;
  // crdtInfo.crdtd_org_id=22222;
  // crdtInfo.intl_crdt_amnt=300.6;
  // crdtInfo.used_crdt_amnt=100.3;
  // crdtInfo.rmn_crdt_amnt=200.3;
  
  // rc = DbTCrdtMgnrUpdate(&crdtInfo, &err_code);
  // if NOTOK(rc){
    // printf("update failed.\n");
  // }
  
  // crdtInfo.crdt_id=2;
  // crdtInfo.crdt_org_id=22222;
  // crdtInfo.crdtd_org_id=33333;
  // crdtInfo.intl_crdt_amnt=1500;
  // crdtInfo.used_crdt_amnt=700;
  // crdtInfo.rmn_crdt_amnt=800;
  
  // rc = DbTCrdtMgnrUpdate(&crdtInfo, &err_code);
  // if NOTOK(rc){
    // printf("update failed.\n");
  // }
  
  // DbCommit(&err_code);
  // /********* Test Code for Update ********************/
  
  
  
  // /********* Test Code for Select ********************/
  // rc = DbTCrdtMgnrPrepareQuery();
  // if NOTOK(rc){
    // printf("query preparation failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  
  // rc = DbTCrdtMgnrQuery(11111,22222,&crdtInfo,&err_code);
  // if NOTOK(rc){
    // printf("select failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  
  // printf("The crdt_id is : %d\n", crdtInfo.crdt_id);
  // printf("The crdt_org_id is : %d\n", crdtInfo.crdt_org_id);
  // printf("The crdtd_org_id is : %d\n", crdtInfo.crdtd_org_id);
  // printf("The intl_crdt_amnt is : %f\n", crdtInfo.intl_crdt_amnt);
  // printf("The used_crdt_amnt is : %f\n", crdtInfo.used_crdt_amnt);
  // printf("The rmn_crdt_amnt is : %f\n", crdtInfo.rmn_crdt_amnt);
  
  // rc = DbTCrdtMgnrQuery(22222,33333,&crdtInfo,&err_code);
  // if NOTOK(rc){
    // printf("select failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  
  // printf("The crdt_id is : %d\n", crdtInfo.crdt_id);
  // printf("The crdt_org_id is : %d\n", crdtInfo.crdt_org_id);
  // printf("The crdtd_org_id is : %d\n", crdtInfo.crdtd_org_id);
  // printf("The intl_crdt_amnt is : %f\n", crdtInfo.intl_crdt_amnt);
  // printf("The used_crdt_amnt is : %f\n", crdtInfo.used_crdt_amnt);
  // printf("The rmn_crdt_amnt is : %f\n", crdtInfo.rmn_crdt_amnt);
  // /********* Test Code for Select ********************/
  // free(allInfo);
  // DbDestroy();
// }
/********* Test Code End ********************/