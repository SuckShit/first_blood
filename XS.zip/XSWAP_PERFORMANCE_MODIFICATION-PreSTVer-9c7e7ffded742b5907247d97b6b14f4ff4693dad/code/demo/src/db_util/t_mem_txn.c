/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <string.h>
/* Project Header File*/
#include "../header/dbhelp.h"
#include "../header/common_macro.h"
#include "../db_header/t_mem_txn.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct dbMemTxn {
	big_int txn_id;
	big_int set_id;
    big_int start_seq_no;
    big_int end_seq_no;

} DbMemTxnT, *pDbMemTxnT;

typedef struct dbMemTxnInd {
	boolean txn_id;
	boolean set_id;
    boolean start_seq_no;
    boolean end_seq_no;

} DbMemTxnIndT,*pDbMemTxnIndT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT DbMemTxnInsert( MemTxnT *pData, int32 *pErrCode){
    BEGIN_FUNCTION( "DbMemTxnInsert" );
	ResCodeT rc = NO_ERR;
    int32    errCode = 0;

    DbMemTxnT baseInfo;
    DbMemTxnIndT baseInd;
    memset(&baseInfo, 0x00, sizeof(baseInfo));
    memset(&baseInd, 0x00, sizeof(baseInd));
	baseInfo.txn_id=pData->txn_id;
	baseInfo.set_id=pData->set_id;
    baseInfo.start_seq_no=pData->start_seq_no;
    baseInfo.end_seq_no=pData->end_seq_no;


	char sqlStr[2042];
	sprintf(sqlStr,"insert into MEM_TXN "
			"(TXN_ID ,SET_ID, START_SEQ_NO, END_SEQ_NO)"
			" values (%d,%d,  '%d','%d'  )"
			, baseInfo.txn_id, baseInfo.set_id, baseInfo.start_seq_no,baseInfo.end_seq_no);

    TRACE(sqlStr);

    rc = DbExecutCmd(sqlStr, &errCode);
    if(NOTOK(rc))
    {
        //TRACE("DbMemInsert execute= %d\n", errCode);
    }
    RAISE_ERROR(rc, RTN);
    EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT DbMemTxnDelete( int64 key, int32 *pErrCode);
ResCodeT DbMemTxnUpdate( int64 key , MemTxnT *pData, int32 *pErrCode);
ResCodeT DbMemTxnQuery(int64 key, MemTxnT *pData, int32 *pErrCode){

}