/***
Created on May 17, 2017

@author: Zhou
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header File*/
#include "../header/dbhelp.h"
#include "../header/common_macro.h"
#include "../db_header/t_crdt_mgnr.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct CRDT_MGNR_ind_t {
	boolean crdt_id;
	boolean crdt_org_id;
	boolean crdtd_org_id;
	boolean intl_crdt_amnt;
	boolean used_crdt_amnt;
	boolean rmn_crdt_amnt;
} CRDT_MGNR_ind_t;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static big_int param_crdt_org_id;
static big_int param_crdtd_org_id;
static double param_intl_crdt_amnt;
static double param_used_crdt_amnt;
static double param_rmn_crdt_amnt;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT DbTCrdtMgnrPrepareUpdate(){
    BEGIN_FUNCTION( "DbTCrdtMgnrPrepareUpdate" );

	char perparedSql[200];
	ResCodeT rc;
	
	OCI_Connection *ppCn;
	OCI_Statement *ppStmt;
    
	strcpy(perparedSql,"UPDATE CRDT_MGNR ");
	strcat(perparedSql,"SET INTL_CRDT_AMNT= :intl_crdt_amnt,USED_CRDT_AMNT= :used_crdt_amnt,RMN_CRDT_AMNT= :rmn_crdt_amnt");
	strcat(perparedSql," WHERE CRDT_ORG_ID= :crdt_org_id AND CRDTD_ORG_ID= :crdtd_org_id");
	
	
    rc = DbExePrepare(&ppCn, &ppStmt, perparedSql);
    if(NOTOK(rc))
    {
        TRACE("DbExePrepare failed.rc = %d\n" $$ rc);
		RAISE_ERROR(rc, RTN);
    }
	
	OCI_BindDouble(ppStmt, ":intl_crdt_amnt", &param_intl_crdt_amnt);
	OCI_BindDouble(ppStmt, ":used_crdt_amnt", &param_used_crdt_amnt);
	OCI_BindDouble(ppStmt, ":rmn_crdt_amnt", &param_rmn_crdt_amnt);
	OCI_BindBigInt(ppStmt, ":crdt_org_id", &param_crdt_org_id);
	OCI_BindBigInt(ppStmt, ":crdtd_org_id", &param_crdtd_org_id);

	
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT DbTCrdtMgnrUpdate(TCrdtMgnr *pData, int32 *pErrCode){
    BEGIN_FUNCTION( "DbTCrdtMgnrUpdate" );

    int32    errCode = 0;
	ResCodeT rc;
    
	param_intl_crdt_amnt = pData->intl_crdt_amnt;
	param_used_crdt_amnt = pData->used_crdt_amnt;
	param_rmn_crdt_amnt = pData->rmn_crdt_amnt;
	param_crdt_org_id = pData->crdt_org_id;
	param_crdtd_org_id = pData->crdtd_org_id;
	
    rc = DbExecutCmdByBind(&errCode);
    if(NOTOK(rc))
    {
        TRACE("DbExecutCmdByBind failed.errcode = %d\n" $$ errCode);
		RAISE_ERROR(rc, RTN);
    }
	
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT DbTCrdtMgnrPrepareQuery(){
    BEGIN_FUNCTION( "DbTCrdtMgnrPrepareQuery" );

	OCI_Connection *ppCn;
	OCI_Statement *ppStmt;
	
	ResCodeT rc;
	
	char perparedSql[200];
    
	strcpy(perparedSql,"SELECT ");
	strcat(perparedSql,"CRDT_ID,CRDT_ORG_ID,CRDTD_ORG_ID,INTL_CRDT_AMNT,USED_CRDT_AMNT,RMN_CRDT_AMNT");
    strcat(perparedSql," FROM CRDT_MGNR ");
	strcat(perparedSql," WHERE ");
	strcat(perparedSql," CRDT_ORG_ID = :crdt_org_id AND CRDTD_ORG_ID = :crdtd_org_id ");
	
	
    rc = DbExePrepare(&ppCn, &ppStmt, perparedSql);
    if(NOTOK(rc))
    {
        TRACE("DbExePrepare failed.rc = %d\n" $$ rc);
		RAISE_ERROR(rc, RTN);
    }
	
	OCI_BindBigInt(ppStmt, ":crdt_org_id", &param_crdt_org_id);
	OCI_BindBigInt(ppStmt, ":crdtd_org_id", &param_crdtd_org_id);
	
    EXIT_BLOCK();
    RETURN_RESCODE;

}


ResCodeT DbTCrdtMgnrQuery(int64 crdtOrgId, int64 crdtTdOrgId, TCrdtMgnr *pData, int32 *pErrCode){
    BEGIN_FUNCTION( "DbTCrdtMgnrQuery" );

    int32    errCode = 0;
	CRDT_MGNR_ind_t crdtMgnrInd;
	ResCodeT rc;
	NumColTypeT colTypes[6];
	
	memset(pData, 0x00, sizeof(TCrdtMgnr));
    memset(&crdtMgnrInd, 0x00, sizeof(CRDT_MGNR_ind_t));
	
	param_crdt_org_id = crdtOrgId;
	param_crdtd_org_id = crdtTdOrgId;
	
	colTypes[0].colIndex = 1;
	colTypes[0].numType = OCI_NUM_UINT;
	colTypes[1].colIndex = 2;
	colTypes[1].numType = OCI_NUM_BIGUINT;
	colTypes[2].colIndex = 3;
	colTypes[2].numType = OCI_NUM_BIGUINT;
	colTypes[3].colIndex = 4;
	colTypes[3].numType = OCI_NUM_DOUBLE;
	colTypes[4].colIndex = 5;
	colTypes[4].numType = OCI_NUM_DOUBLE;
	colTypes[5].colIndex = 6;
	colTypes[5].numType = OCI_NUM_DOUBLE;
	
    rc = DbExeQueryWithNumInfo(pData, &crdtMgnrInd, colTypes, 6, &errCode);
    if(NOTOK(rc))
    {
        TRACE("DbExeQuery failed.errcode = %d\n" $$ errCode);
		RAISE_ERROR(rc, RTN);
    }
	
    EXIT_BLOCK();
    RETURN_RESCODE;
	
}


ResCodeT DbTCrdtMgnrGetAll(TCrdtMgnr *pData, int32 *size, int32 *pErrCode){
    BEGIN_FUNCTION( "DbTCrdtMgnrGetAll" );

    int32    errCode = 0;
	CRDT_MGNR_ind_t crdtMgnrInd;
	ResCodeT rc;
	NumColTypeT colTypes[6];
	int32 dataCnt = 0;
	int32 index;
	
	OCI_Connection *ppCn;
	OCI_Statement *ppStmt;
	OCI_Resultset *rs;
	
	char perparedSql[200];
    
	strcpy(perparedSql,"SELECT ");
	strcat(perparedSql,"CRDT_ID,CRDT_ORG_ID,CRDTD_ORG_ID,INTL_CRDT_AMNT,USED_CRDT_AMNT,RMN_CRDT_AMNT");
    strcat(perparedSql," FROM CRDT_MGNR ");
	
    rc = DbExePrepare(&ppCn, &ppStmt, "SELECT COUNT(*) FROM CRDT_MGNR");
	RAISE_ERROR(rc,RTN);
	
	if(!OCI_Execute(ppStmt))
    {
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	rs = OCI_GetResultset(ppStmt);
	if(rs == NULL)
    {
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	if(OCI_FetchNext(rs)){
	  dataCnt = OCI_GetInt(rs,1);
	}
	
	if (dataCnt == 0){
	  // No data in table crdt_mgnr
	  RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
	}
//	TCrdtMgnr *pData = *ppData;
	
//	pData = (TCrdtMgnr*)malloc(dataCnt*sizeof(TCrdtMgnr));
//	memset(pData, 0x00, dataCnt*sizeof(TCrdtMgnr));
	
	if(!OCI_ExecuteStmt(ppStmt,perparedSql))
	{
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	rs = OCI_GetResultset(ppStmt);
	
	index = 0;
	while(OCI_FetchNext(rs)){
	  (pData+index)->crdt_id = OCI_GetInt(rs,1);
	  (pData+index)->crdt_org_id = OCI_GetBigInt(rs,2);
	  (pData+index)->crdtd_org_id = OCI_GetBigInt(rs,3);
	  (pData+index)->intl_crdt_amnt = OCI_GetDouble(rs,4);
	  (pData+index)->used_crdt_amnt = OCI_GetDouble(rs,5);
	  (pData+index)->rmn_crdt_amnt = OCI_GetDouble(rs,6);
	  
	  index++;
	}
	
	*size = index;
	
    EXIT_BLOCK();
    RETURN_RESCODE;
}


/********* Test Code Start ********************/
// int main(int argc,char* argv[]){
  // BEGIN_FUNCTION( "main" );
  // // printf("it works.\n");
  // ResCodeT rc;
  // int64 key;
  // int32 err_code;
  // TCrdtMgnr crdtInfo;
  // TCrdtMgnr *allInfo;
  // int32 count;
  // int index;
  
  // DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");

  // /********* Test Code for GetAll ********************/
  // rc = DbTCrdtMgnrGetAll(&allInfo, &count, &err_code);
  
  // printf("All data get. The count is : %d\n",count);
  // for(index=0;index<count;index++){
    // printf("The crdt_id[%d] is : %d\n", index, (allInfo+index)->crdt_id);
    // printf("The crdt_org_id[%d] is : %d\n", index, (allInfo+index)->crdt_org_id);
    // printf("The crdtd_org_id[%d] is : %d\n", index, (allInfo+index)->crdtd_org_id);
    // printf("The intl_crdt_amnt[%d] is : %f\n", index, (allInfo+index)->intl_crdt_amnt);
    // printf("The used_crdt_amnt[%d] is : %f\n", index, (allInfo+index)->used_crdt_amnt);
    // printf("The rmn_crdt_amnt[%d] is : %f\n", index, (allInfo+index)->rmn_crdt_amnt);
  // }
  // /********* Test Code for GetAll ********************/

  
  // /********* Test Code for Update ********************/
  // rc = DbTCrdtMgnrPrepareUpdate();
  // if NOTOK(rc){
    // printf("update preparation failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  // crdtInfo.crdt_id=1;
  // crdtInfo.crdt_org_id=11111;
  // crdtInfo.crdtd_org_id=22222;
  // crdtInfo.intl_crdt_amnt=300.6;
  // crdtInfo.used_crdt_amnt=100.3;
  // crdtInfo.rmn_crdt_amnt=200.3;
  
  // rc = DbTCrdtMgnrUpdate(&crdtInfo, &err_code);
  // if NOTOK(rc){
    // printf("update failed.\n");
  // }
  
  // crdtInfo.crdt_id=2;
  // crdtInfo.crdt_org_id=22222;
  // crdtInfo.crdtd_org_id=33333;
  // crdtInfo.intl_crdt_amnt=1500;
  // crdtInfo.used_crdt_amnt=700;
  // crdtInfo.rmn_crdt_amnt=800;
  
  // rc = DbTCrdtMgnrUpdate(&crdtInfo, &err_code);
  // if NOTOK(rc){
    // printf("update failed.\n");
  // }
  
  // DbCommit(&err_code);
  // /********* Test Code for Update ********************/
  
  
  
  // /********* Test Code for Select ********************/
  // rc = DbTCrdtMgnrPrepareQuery();
  // if NOTOK(rc){
    // printf("query preparation failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  
  // rc = DbTCrdtMgnrQuery(11111,22222,&crdtInfo,&err_code);
  // if NOTOK(rc){
    // printf("select failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  
  // printf("The crdt_id is : %d\n", crdtInfo.crdt_id);
  // printf("The crdt_org_id is : %d\n", crdtInfo.crdt_org_id);
  // printf("The crdtd_org_id is : %d\n", crdtInfo.crdtd_org_id);
  // printf("The intl_crdt_amnt is : %f\n", crdtInfo.intl_crdt_amnt);
  // printf("The used_crdt_amnt is : %f\n", crdtInfo.used_crdt_amnt);
  // printf("The rmn_crdt_amnt is : %f\n", crdtInfo.rmn_crdt_amnt);
  
  // rc = DbTCrdtMgnrQuery(22222,33333,&crdtInfo,&err_code);
  // if NOTOK(rc){
    // printf("select failed. The rc is : %d\n",rc);
	// exit(1);
  // }
  
  // printf("The crdt_id is : %d\n", crdtInfo.crdt_id);
  // printf("The crdt_org_id is : %d\n", crdtInfo.crdt_org_id);
  // printf("The crdtd_org_id is : %d\n", crdtInfo.crdtd_org_id);
  // printf("The intl_crdt_amnt is : %f\n", crdtInfo.intl_crdt_amnt);
  // printf("The used_crdt_amnt is : %f\n", crdtInfo.used_crdt_amnt);
  // printf("The rmn_crdt_amnt is : %f\n", crdtInfo.rmn_crdt_amnt);
  // /********* Test Code for Select ********************/
  // free(allInfo);
  // DbDestroy();
// }
/********* Test Code End ********************/