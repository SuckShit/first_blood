/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <string.h>
/* Project Header File*/
#include "../header/dbhelp.h"
#include "../header/common_macro.h"
#include "../db_header/t_mem_data.h"
#include "ocilib.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct dbMemData {
	big_int sequence_no;
	big_int aset;
	big_int data_type;
	OCI_Lob *data;

} DbMemDataT,*pDbMemDataT;

typedef struct dbMemDataInd {
	boolean sequence_no;
	boolean aset;
	boolean data_type;
	boolean data;

} DbMemDataIndT,*pDbTMemDataIndT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
OCI_Connection * pCn;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT DbMemDataBatchInsert( int32 rcrdCnt, int * seqNoArry, int * setIdArry, int * dataTypeArry,char* dataCharArry, int32 dataSize){

    BEGIN_FUNCTION( "DbMemDataBatchInsert" );

    OCI_Statement * pStmt;
    OCI_Connection * pCn;
    static char sqlStr_5[] = "insert into MEM_DATA"
            "(SEQUENCE_NO ,ASET,DATA_TYPE,DATA)"
            " values (:SEQUENCE_NO, :ASET ,:DATA_TYPE ,:DATA) ";

    DbExePrepare(&pCn, &pStmt, sqlStr_5);

    OCI_BindArraySetSize(pStmt, rcrdCnt);
    OCI_BindArrayOfInts(pStmt, OTEXT(":SEQUENCE_NO"), (int *)seqNoArry, 0);
    OCI_BindArrayOfInts(pStmt, OTEXT(":ASET"), (int *)setIdArry, 0);
    OCI_BindArrayOfInts(pStmt, OTEXT(":DATA_TYPE"), (int *)dataTypeArry, 0);
    OCI_BindArrayOfStrings(pStmt, OTEXT(":DATA"), (otext *)dataCharArry,dataSize,0 );

    OCI_Execute(pStmt);
    //OCI_Commit(pCn);

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT DbMemDataInsert( MemDataT *pData, int32 *pErrCode){

    BEGIN_FUNCTION( "DbMemDataInsert" );
	ResCodeT rc = NO_ERR;
    int32    errCode = 0;

    DbMemDataT baseInfo;
    DbMemDataIndT baseInd;
    memset(&baseInfo, 0x00, sizeof(baseInfo));
    memset(&baseInd, 0x00, sizeof(baseInd));

	baseInfo.sequence_no=pData->sequence_no;
	baseInfo.aset=pData->set;
	baseInfo.data_type=pData->data_type;

	baseInfo.data=pData->data;

	char sqlStr[2042];
	sprintf(sqlStr,"insert into MEM_DATA "
			"(SEQUENCE_NO ,ASET,DATA_TYPE, DATA)"
			" values (%d,%d,%d,  :data  )"
			, baseInfo.sequence_no, baseInfo.aset,baseInfo.data_type);

    //printf(sqlStr);

    rc = DbExecutCmdBlob(sqlStr,"data",  baseInfo.data, pData->data, pData->lengthOfBlob, &errCode);
    if(NOTOK(rc))
    {
        //TRACE("DbMemDataInsert execute= %d\n", errCode);
    }
    RAISE_ERROR(rc, RTN);
    EXIT_BLOCK();
    RETURN_RESCODE;
}
ResCodeT DbMemataDelete( int64 key, int32 *pErrCode);
ResCodeT DbMemDataUpdate( int64 key , MemDataT *pData, int32 *pErrCode);
ResCodeT DbMemDataQuery(int64 key, MemDataT *pData, int32 *recodeSize, int32 *pErrCode){
 /*   BEGIN_FUNCTION( "DbMemDataQuery" );
    ResCodeT rc = NO_ERR;
    int32    errCode = 0;

    DbMemDataT baseInfo;
    DbMemDataIndT baseInd;
    memset(&baseInfo, 0x00, sizeof(baseInfo));
    memset(&baseInd, 0x00, sizeof(baseInd));

    char sqlStr[2042];
    sprintf(sqlStr,"select sequence_no, aset , data_type , data from MEM_DATA where rownum = 1");
                  //  "where SEQUENCE_NO = %d  and ASET= %d and DATA_TYPE = %d "
               //   "where rownum = 1 ");
           // , pData->sequence_no, pData->set, pData->data_type> );
    //printf("%s\n" , sqlStr);
    rc = DbExeQuery(&sqlStr,  &baseInfo, :wq&baseInd, &errCode);
    if(baseInd.sequence_no == TRUE){
        pData->sequence_no = baseInfo.sequence_no;
        //printf("record has value\n");
        //printf(baseInfo.sequence_no);printf("\n");
        //printf(baseInfo.aset);printf("\n");
        //printf(baseInfo.data_type);printf("\n");
        //printf("record has value\n");
        //printf(pData->sequence_no);
    }
    if(baseInd.aset == TRUE){
        pData->set = baseInfo.aset;
    }
    if(baseInd.data_type == TRUE){
        pData->data_type = baseInfo.data_type;
    }
    //need to convert OCI_Lob to void *
//    if(baseInd.data == TRUE){
//        unsigned int charCount;//actually not useful
//        OCI_LobRead2(baseInfo.data, pData->data,&charCount, &(pData->lengthOfBlob) );
//
//    }
*/

   BEGIN_FUNCTION( "DbMemDataQuery" );

    int32    errCode = 0;
	ResCodeT rc;
	int32 dataCnt = 0;
	int32 index;
	
	OCI_Connection *ppCn;
	OCI_Statement *ppStmt;
	OCI_Resultset *rs;

	char perparedSql[200];
    
	*recodeSize = 0;
	strcpy(perparedSql,"select sequence_no, aset , data_type , data from MEM_DATA where rownum <= 100");
	rc = DbExePrepare(&ppCn, &ppStmt, perparedSql);
	
	if(!OCI_Execute(ppStmt))
	{
      *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
      RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
	rs = OCI_GetResultset(ppStmt);
	
	index = 0;
	while(OCI_FetchNext(rs)){
	  (pData+index)->sequence_no = OCI_GetBigInt(rs,1);
	  (pData+index)->set = OCI_GetBigInt(rs,2);
	  (pData+index)->data_type = OCI_GetBigInt(rs,3);
	  (pData+index)->data = (void *)OCI_GetString(rs,4);
	  (pData+index)->lengthOfBlob  = 9;
 	  
	  index++;
	}
	
	*recodeSize = index;
	
    EXIT_BLOCK();
    RETURN_RESCODE;

}


