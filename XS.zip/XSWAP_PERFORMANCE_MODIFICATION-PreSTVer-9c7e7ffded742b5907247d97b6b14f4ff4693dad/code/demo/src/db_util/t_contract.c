/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <string.h>
/* Project Header File*/
#include "../header/dbhelp.h"
#include "../header/common_macro.h"
#include "../db_header/t_contract.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct CNTRCT_BASE_INFO_t {
	big_int cntrct_srno;
	otext *cntrct_nm;
	otext *cntrct_tp;
	otext *mkt_id;
	otext *shrt_cntrct_nm;
	otext *lng_cntrct_nm;
	big_int shrt_amnt_ratio;
	big_int lng_amnt_ratio;
	big_int max_amnt_per_dl;
	big_int min_amnt_per_dl;

	big_int dl_unit;
	otext *dl_prc_unit;
	big_int term;
	otext *st;
	OCI_Date *crt_tm;
	otext *crt_usr_nm;
	OCI_Date *upd_tm;
	otext *upd_usr_nm;
	otext *term_strng;
	big_int brdg_sort;
} CNTRCT_BASE_INFO_t;

typedef struct CNTRCT_BASE_INFO_ind_t {
	boolean cntrct_srno;
	boolean cntrct_nm;
	boolean cntrct_tp;
	boolean mkt_id;
	boolean shrt_cntrct_nm;
	boolean lng_cntrct_nm;
	boolean shrt_amnt_ratio;
	boolean lng_amnt_ratio;
	boolean max_amnt_per_dl;
	boolean min_amnt_per_dl;

	boolean dl_unit;
	boolean dl_prc_unit;
	boolean term;
	boolean st;
	boolean crt_tm;
	boolean crt_usr_nm;
	boolean upd_tm;
	boolean upd_usr_nm;
	boolean term_strng;
	boolean brdg_sort;

} CNTRCT_BASE_INFO_ind_t;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT DbTContractInsert( TContract *pData, int32 *pErrCode){
	printf("dbtcontract insert begin...\n");
	ResCodeT rc = NO_ERR;
    int32    errCode = 0;
    CNTRCT_BASE_INFO_t baseInfo;
	baseInfo.cntrct_srno=pData->cntrct_srno;
	baseInfo.cntrct_nm=pData->cntrct_nm;
	baseInfo.cntrct_tp=pData->cntrct_tp;
	baseInfo.mkt_id=pData->mkt_id;

    CNTRCT_BASE_INFO_ind_t baseInd;
    
    BEGIN_FUNCTION( "DbTContractInsert" );
    
    rc = DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");
    RAISE_ERROR(rc, RTN);
    
    //memset(&baseInfo, 0x00, sizeof(baseInfo));
    //memset(&baseInd, 0x00, sizeof(baseInd));

	//char sqlStr[100]= "insert into CNTRCT_BASE_INFO (CNTRCT_SRNO ,CNTRCT_NM) values (";

	char sqlStr[200];
	sprintf(sqlStr,"insert into CNTRCT_BASE_INFO "
			"(CNTRCT_SRNO ,CNTRCT_NM, CNTRCT_TP, MKT_ID,    MAX_AMNT_PER_DL,MIN_AMNT_PER_DL,DL_UNIT,DL_PRC_UNIT,TERM,ST, CRT_TM,CRT_USR_NM,UPD_TM,UPD_USR_NM,TERM_STRNG,BRDG_SORT)"
			" values (%d,'%s',   '%s'  ,'%s' ,     1000, 5,500000,3,1,3,'17-JAN-15 04.06.47.000000 PM','IRSINIT','13-DEC-16 09.10.16.004386 AM','mscshj','1Y',25)"
			, baseInfo.cntrct_srno, baseInfo.cntrct_nm, baseInfo.cntrct_tp, baseInfo.mkt_id);

	printf("%s\n",sqlStr);
	//strcat(sqlStr, baseInfo.cntrct_srno);
	//strcat(sqlStr, " , '");
	//strcat(sqlStr, baseInfo.cntrct_nm);
	//strcat(sqlStr, "')");

	//printf("%s",sqlStr);

    rc = DbExecutCmd(&sqlStr, &errCode);
    if(NOTOK(rc))
    {
        printf("errcode execute= %d\n", errCode);
    }
    RAISE_ERROR(rc, RTN);
	rc= DbCommit(&errCode);
	if(NOTOK(rc))
	{
		printf("errcode commit = %d\n", errCode);
	}

    printf("cntrct_srno: %d \n", baseInfo.cntrct_srno);
    printf("shrt_amnt_ratio %d\n", baseInfo.shrt_amnt_ratio);
	printf("cntrct_srno %d\n", pData->cntrct_srno);
	printf("cntrct_nm %s\n", pData->cntrct_nm);
    EXIT_BLOCK();
    ResCodeT DbDestroy();
    RETURN_RESCODE;
}
ResCodeT DbTContractContractDelete( int key, int32 *pErrCode);
ResCodeT DbTContractUpdate( int key , TContract *pData, int32 *pErrCode);
ResCodeT DbTContractQuery(int key, TContract *pData, int32 *pErrCode);