/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _ERR_CODE_
#define _ERR_CODE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define NO_ERR          1


#define ERR_MSG_NOT_FOUND                           10001



/** Link List Error Section **/
#define ERR_INVLD_KEY_CMP_FUNC                      40001
#define ERR_OBJ_NOT_IN_LINKED_LIST                  40002
#define ERR_ITEM_ALREADY_EXIST_IN_LINKED_LIST       40003
#define ERR_DUPLICATE_OBJ_IN_LINKED_LIST            40004
#define ERR_ITEM_NOT_BELONG_TO_LINKED_LIST          40005
#define ERR_INVLD_SORT_TYPE                         40006
#define ERR_INVLD_OBJ_CMP_FUNC                      40007
#define ERR_INVLD_GET_KEY_FUNC                      40008
#define ERR_INVLD_STATIC_LINK_LIST_MODE             40009
#define ERR_INVLD_STATIC_LINK_LIST_ADDRESS          40010
#define ERR_INVLD_STATIC_LINK_LIST_SLOT_SIZE        40011
#define ERR_INVLD_OFFSET_VALUE_OF_STATIC_LINK_LIST_HEAD 10012
#define ERR_INVLD_MEM_FILE_FUNC                     40013
#define ERR_INVLD_PTR_TO_SLOT_ID                    40014
#define ERR_DUPLICATE_KEY_IN_LINKED_LIST            40015
#define ERR_OUT_OF_MEMORY                           40016
#define ERR_OBK_NOT_ENOUGH_BUFFER                   40017
#define ERR_OBK_NULL_POINTER                        40018

/** Matcher Error Section **/
#define ERR_MATCHER_VECTOR_ERR                      40101
#define ERR_OBK_SET_ODRBK_FULL                      40102
#define ERR_MATCHER_BST_ORD_ERR                     40103
#define ERR_OBK_FREEORDER_FAIL                      40104
#define ERR_INVLD_SET_ID                            40105

/** Share memory section **/
#define ERR_ARCH_MSG_EMPTY_SLOT_ERR                 40201
#define ERR_ARCH_SHM_OVERFLOW                       40202
#define ERR_ARCH_SHM_INVALID_PARAM                  40203
#define ERR_ARCH_ATTACH_MSG_CACHE                   40204
#define ERR_ARCH_CREA_MSG_CACHE                     40205


/** File section **/
#define ERR_OPEN_ERR_LOG_ERR                        40301


/** App Shl section **/

#define ERR_APP_EPOLL_ADD_ERR                       40401
#define ERR_APP_EPOLL_WAIT_ERR                      40402

/** Memory Txn section **/
#define ERR_EXCEED_MAX_TXN_ID                       40501
/** HashTable section **/
#define ERR_MSG_HASHTABLE_DUPILICATE                40601
#define ERR_MSG_HASHTABLE_NOT_FOUND                 40602
/** database section **/
#define ERR_DB_OCI_INIT_ERR                         40701
#define ERR_DB_OCI_CONN_ERR                         40702
#define ERR_DB_OCI_NOT_INIT                         40703
#define ERR_DB_OCI_CREATE_STATE_ERR                 40704
#define ERR_DB_OCI_EXE_ERR                          40705

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _ERR_CODE_ */
