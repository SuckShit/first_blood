
#if !defined(_BIT_LIB_)
#define _BIT_LIB_

#include <linux/limits.h>
#include "data_type.h"


#define __UINT64_MAX  18446744073709551615u
#define __INT64_MAX   9223372036854775807
#define __INT64_MIN   (-__INT64_MAX - 1)

#define vectorT	    uint64
#define VECTOR_MAX  __UINT64_MAX

#define VECTOR_BASE      (8 * sizeof(vectorT))
#define BIT_IDX_INVALID  -1
#define BIT_IDX_INVALID_US  0xFFFF



/* check the state of the given bit in the bit vector */
int32 BitCheck (vectorT *bits, int32 index);

int32 BitCheckus (vectorT *bits, uint16 index);

/* find the first bit clear in the given bit range */
void BitFindFC (vectorT *bits, int32 first, int32 last, int32 *index);
void BitFindFCus (vectorT *bits, uint16 first, uint16 last,
                  uint16 *index);

/* find the first bit set in the given bit range */
void BitFindFS (vectorT *bits, int32 first, int32 last, int32 *index);
void BitFindFSus (vectorT *bits, uint16 first, uint16 last, 
                  uint16 *index);

/* find the last bit clear in the given bit range */
void BitFindLC (vectorT *bits, int32 first, int32 last, int32 *index);
void BitFindLCus (vectorT *bits, uint16 first, uint16 last, 
                  uint16 *index);

/* find the last bit set in the given bit range */
void BitFindLS (vectorT *bits, int32 first, int32 last, int32 *index);
void BitFindLSus (vectorT *bits, uint16 first, uint16 last, 
                  uint16 *index);

/* reset the given bit */
void BitReset (vectorT *bits, int32 index);
void BitResetus (vectorT *bits, uint16 index);

/* set the given bit */
void BitSet (vectorT *bits, int32 index);
void BitSetus (vectorT *bits, uint16 index);

#endif
