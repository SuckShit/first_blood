/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _APP_SHL_
#define _APP_SHL_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "msg.h"
#include "errlib.h"
#include "bitlib.h"
#include "fifo_queue.h"
#include "ipclib.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct CallBackCtxS
{
    int32 sendFlg;
} CallBackCtxT, *pCallBackCtxT;

typedef ResCodeT (*AppCallBackT)(pMsgStructT pReq, pMsgStructT pRsp, int64 timestamp, pCallBackCtxT pCtx);

typedef ResCodeT (*AppDoneCallBackT)();
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT AppShlInit(int32 setId, char *pPrcsName, int32 inputQHndl, int32 outputQHndl, pFifoInfoT inputBuff, pFifoInfoT outputBuff, 
            int32 txnSize, AppCallBackT fAppCallBack, AppDoneCallBackT fAppDoneCallBack);
ResCodeT AppShlRun();

ResCodeT AppShlShutDown();

#endif /* _APP_SHL_ */
