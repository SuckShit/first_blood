/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _ORDER_BOOk_
#define _ORDER_BOOk_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "../header/data_type.h"
#include "../header/osslist.h"
#include "../header/errlib.h"
#include "../header/order_type.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_ORD_NO_LIST_OF_PRDCT    2000
#define MAX_ENTY_LIST_OF_PRDCT    1000

/* Bit flag Order Side. */
#define ORDR_SIDE_BUY  1
#define ORDR_SIDE_SELL 2
#define ORDR_SIDE_NONE 0


#define ODBK_SHM_NO_SLOT        ((ShmSlotIdT) -1)

#define VALID_ORDERF4PRCLEADT_SIZE offsetof(OrderF4PrcLeadT, filler)

#ifndef NULL_SLOT_ID
#define NULL_SLOT_ID(slotId)    ((slotId) == NULL_SLOT)
#endif


#ifndef INIT_REG_LIST
#define INIT_REG_LIST(pListReg)\
    do\
    {\
        (pListReg)->frmUList.counter = 0; \
        (pListReg)->frmPrcLderList.counter = 0; \
        (pListReg)->frmUAOList.counter = 0; \
        (pListReg)->frmEntyList.counter = 0; \
        (pListReg)->frmOrdrNoList.counter = 0; \
    } while (0)
#endif


#define INIT_STATIC_LIST_ENTRY(ptr)\
    do {(ptr)->next = NULL_SLOT; (ptr)->prev = NULL_SLOT;} while (0)

#ifndef INIT_ORDER_TECH_PART
#define INIT_ORDER_TECH_PART(pAddO)\
    do\
    {\
        pOrderT pOrder = (pOrderT)(pAddO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.unrO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.unrAuOaO);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.ordNo);\
        INIT_STATIC_LIST_ENTRY(&(pOrder)->orderT.entyNo);\
        (pOrder)->orderT.priceLdr = NULL_SLOT;\
        (pOrder)->orderT.free = 0;\
    } while (0)
#endif

#ifndef INIT_PRC_LDER_FUNC_PART
#define INIT_PRC_LDER_FUNC_PART(pPrcLder, sortingType, exePrc, prdctId)\
    do\
    {\
        memset(&(pPrcLder)->orderF, 0x00, VALID_ORDERF4PRCLEADT_SIZE);\
        (pPrcLder)->orderF.odrBkSortingType = (sortingType);\
        (pPrcLder)->orderF.ordrExePrc = (exePrc);\
        (pPrcLder)->orderF.prdctId = (prdctId);\
        (pPrcLder)->orderF.ordrNo = ((uint64)-1);\
        CalcuPri4PrcLder(&(pPrcLder)->orderF);\
    } while (0)
#endif



#ifndef IS_EMPTY_PRC_LDER
#define IS_EMPTY_PRC_LDER(pPrcLder)\
    IS_EMPTY_SLIST(&((pPrcLder)->orderT.unrAuOaO))
#endif
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
/* Order Sorting Type. */
typedef short OrdBkSortingT;                    /* P/T or P/Q/T. */


typedef struct tagBstGrp
{
    int64 bstBuyLmtPrc;
    int64 bstSellLmtPrc;
    int64 bstBuyMktQty;
    int64 bstSellMktQty;
    int64 bstBuyLmtQty;
    int64 bstSellLmtQty;
} BstGrpT, *pBstGrpT;

typedef struct tagRegListS
{
    frameSListT frmUList;
    frameSListT frmPrcLderList;
 		frameSListT frmUAOList;
    frameSListT frmOrdrNoList;
    frameSListT frmEntyList;
}RegListT, *p64RegListT;

typedef struct OrderKeyS
{
    uint32      prdctId; /* Product Id */
    uint32      orderNo; /* Order Number */
} OrderKeyT, *pOrderKeyT;

typedef struct OrderRcrdS
{
    OrderKeyT       	orderKey;
    int64               exePrc;
    int64               orderEntTime;
    int64               orderExpTime;
    int64               orderTxnTime;
    int64               orderQty;
    int64               orderExeQty;
   	int16               orderSide;
   	int16               orderSts;
    int32               filler;
} OrderRcrdT, *pOrderRcrdT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
#ifdef __cplusplus
extern "C"{
#endif
ResCodeT OrderAdd(  pOrderT *ppAddO );

ResCodeT OrdBookShmAttach(int32 setId);

ResCodeT OrdBookShmCreate(int32 setId, int32 nmbrOfPrdct, int64 ordBookSize);

ResCodeT OrderCreate( const int32 prdctId, pOrderT *pOrderCreate);

ResCodeT OrderDelete( pOrderT *pDelOrder,
                const int64 tranTime);

ResCodeT GetBest( const int32 prdctId, int32 oSide, pOrderT *pBestO );

ResCodeT GetBstPrc(    int32            prdctId,
    int32            buySellSide,
                   pBstGrpT       pBstGrp);
ResCodeT OrdBookGetOrdr( int32 setId, int32 slotId,  pOrderT *pBkOrdr );
#ifdef __cplusplus
}
#endif    
				   
#endif /* _ORDER_BOOk_ */
