
#ifndef __OS_LINK_LIST_H__
#define __OS_LINK_LIST_H__

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* Standard C header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "errlib.h"

struct tagOsLinkListNode;
struct tagOsLinkList;

typedef struct tagOsLinkListNode
{
    struct tagOsLinkListNode *next;
    struct tagOsLinkListNode *prev;
    struct tagOsLinkList *linkList;
    void *enclosingObject;
    /* pointer to the enclosed object. This field must be set correctly before
    an item is added to a linked list. */
}osLinkListNodeT, *pOsLinkListNodeT;

typedef enum{
    NON_SORTED = 0,
    ASCENDING,
    DESCENDING
}SORT_TYPE;

/*******************************************************************************
 *Description:  compare two keys or objects. If linked list a sorted one, the
 *              comparison function must have non-zero return values.
 *Parameters:
 *  obj1    IN  the pointer to the first  object to be compared.
 *  obj2    IN  the pointer to the second object to be compared.
 *Return Values:
 *  =0  two objects are equal
 *  >0  object1 is greater than object2
 *  <0  object1 is smaller than object2
 ******************************************************************************/
typedef long (*CompareFuncT)(void *obj1, void *obj2);

/* obtain the key for the given enclosed object */
/*******************************************************************************
 *Description: get key for an enclosed object. The mapping of an object to a
 *      key must be strictly unique!
 *Parameters:
 *  obj IN  the object to be mapped.
 *Return Values:
 *  NON-NULL pointer to the mapped key
 ******************************************************************************/
typedef void* (*GetKeyFuncT)(void *obj);

typedef struct tagOsLinkList
{
    osLinkListNodeT *head;
    unsigned long sortType;
    unsigned long numEntries;
    BOOL allowDuplicateKey;
    /*
        TRUE: The linked list allows duplicate keys or objects to exist. even
        so , it's not guaranteed that the item added sooner to the linked list
        will be placed closer or farther to the linked list head than the one
        add later.
        FALSE: The linked list doesn't allow duplicate key to exist
    */
    CompareFuncT CompareFunc;
    CompareFuncT CompareKeyFunc;
    GetKeyFuncT GetKeyFunc;
}osLinkListT, *pOsLinkListT;

/*---------------------------------MACRO--------------------------------------*/
/* It's not recommended to use the below macros to manipulate linked list */
/*
#define GetLinkListHead(pOsLinkList)    (pOsLinkList)->head

#define GetNextItemFromLinkList(next, pOsLinkList, pOsLinkListNode)         \
                ASSERT(pOsLinkList && pOsLinkListNode)                      \
                ASSERT(pOsLinkList == (pOsLinkListNode)->linkList)          \
                (next) = (pOsLinkListNode)->next;
*/

/* access link fields via osLinkListIterT rather than directly */

/*---------------------------------External Interfaces------------------------*/

/******************************************************************************
 * Description:   Initialize a linked list.
 * Parameters:
 *      sortType    IN  sort type of the link list to be created.
 *      allowDuplicateKey   IN  allow duplicate keys to exist in the linked
 *          list.
 *      CompareFunc IN  pointer to the function to compare two link list nodes.
 *      CompareKeyFunc  IN  pointer to the function used to compare two keys.
 *      GetKeyFunc  IN  pointer to function used to obtain a key for the given
 *                      object.
 *      pOsLinkList OUT pointer to the link list to be initialized.
 *
 *      sortType can be one of the three pre-defined sort types: NON_SORTED,
 *      ASCENDING or DESCENDING.
 *      The linked list provides searching function either by a given enclosed
 *      object or by a give key. For the former case, CompareFunc must be
 *      provided for sorted linked list and FindItemInLinkList() is used to
 *      search for an item; for the latter case, CompareKeyFunc and GetKeyFunc
 *      must be provided and FindItemByKeyInLinkList() is used to search for an
 *      item. Of course, two search methods can be used simultaneously as long
 *      as all three functions are provided.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to initialize a linked list.
 ******************************************************************************/
ResCodeT InitLinkList(SORT_TYPE sortType,
                        BOOL allowDuplicateKey,
                        CompareFuncT CompareFunc,
                        CompareFuncT CompareKeyFunc,
                        GetKeyFuncT GetKeyFunc,
                        pOsLinkListT pOsLinkList);

/******************************************************************************
 * Description:   Add an item to a linked list.
 * Parameters:
 *      pOsLinkListNode IN  item to be added
 *      pOsLinkList IN  pointer to the link list
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to add an item to a linked list.
 *****************************************************************************/
ResCodeT AddItemToLinkList(pOsLinkListNodeT pOsLinkListNode,
                        pOsLinkListT pOsLinkList);


/******************************************************************************
 * Description:   Add an item to a linked list.
 * Parameters:
 *      pOsLinkListNode IN  item to be added
 *      pOsLinkList IN  pointer to the link list
 *      ppOsLinkListNode    OUT pointer to the item that is found in the list.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to add an item to a linked list.
 *****************************************************************************/
ResCodeT AddItemToLinkListExt(pOsLinkListNodeT pOsLinkListNode,
                        pOsLinkListT pOsLinkList,
                        pOsLinkListNodeT *ppOsLinkListNode);



/******************************************************************************
 * Description:   Remove an item from a linked list. The function doesn't
 *          release the storage of the removed item.
 * Parameters:
 *      pOsLinkListNode IN  item to be removed.
 *      pOsLinkList IN  pointer to the link list
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to remove an item from the linked list.
 *****************************************************************************/
ResCodeT RemoveItemFromLinkList(pOsLinkListNodeT pOsLinkListNode,
                            pOsLinkListT pOsLinkList);

/*******************************************************************************
 * Description:   Find an item in a linked list for a given enclosed object.
 * Parameters:
 *      object  IN  The enclosed object of wanted linked list item.
 *      pOsLinkList IN  pointer to the link list
 *      ppOsLinkListNode    OUT Write to the found linked list item.
 *
 *      This function searches for an item with a given enclosed object. The
 *      CompareFunc for the linked list must be provided.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT FindItemInLinkList(void *object,
                            pOsLinkListT pOsLinkList,
                            pOsLinkListNodeT *ppOsLinkListNode);

/*******************************************************************************
 * Description:   Find an item in a linked list for a given key.
 * Parameters:
 *      key IN  The key of the wanted linked list item.
 *      pOsLinkList IN  pointer to the link list.
 *      ppOsLinkListNode    OUT Write to the found linked list item.
 *
 *      This function searches for an item with a given key. The CompareKeyFunc
 *      and GetKeyFunc must be provided.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT FindItemByKeyInLinkList(void *key,
                            pOsLinkListT pOsLinkList,
                            pOsLinkListNodeT *ppOsLinkListNode);

/******************************************************************************
 * Description:   Destroy a linked list. The function won't release the storage
 *      all items occupied. Therefore the caller should take care of memory
 *      release.
 * Parameters:
 *      pOsLinkList IN  pointer to the link list to be initialized.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to destroy a link list.
 *****************************************************************************/
ResCodeT DestroyLinkList(pOsLinkListT pOsLinkList);

/*---------------------------------Internal Interfaces------------------------*/
/*******************************************************************************
 * Description:   Find an item in a linked list. The function is internally used
 *      by the module and can't be called externally.
 * Parameters:
 *      searchByKey IN  Flag indicating search method. A TRUR value indicates
 *                      searching by a given key, otherwise by an given object.
 *      context IN  The search context, either a key or an object.
 *      pOsLinkList IN  pointer to the link list to be initialized.
 *      ppOsLinkListNode    OUT Write to the found linked list item.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
static ResCodeT InternalFindItemInLinkList(BOOL searchByKey,
                            void *context,
                            pOsLinkListT pOsLinkList,
                            pOsLinkListNodeT *ppOsLinkListNode);


/*----------------ITERATING STRUCTURE FOR LINKED LIST ------------------------*/
typedef struct tagOsLinkListIter
{
    osLinkListT *linkList;
    osLinkListNodeT *curr;
}osLinkListIterT, *pOsLinkListIterT;

typedef ResCodeT (*ProcessLinkListNodeFuncT)(void *pOsLinkListNode,
                                            void *context);

ResCodeT InitLinkListIter(pOsLinkListIterT pOsLinkListIter,
                        pOsLinkListT pOsLinkList);
ResCodeT DestroyLinkListIter(pOsLinkListIterT pOsLinkListIter);
ResCodeT LinkListIterGetHead(pOsLinkListIterT pOsLinkListIter,
                        pOsLinkListNodeT *pHead);
ResCodeT LinkListIterGetNext(pOsLinkListIterT pOsLinkListIter,
                        pOsLinkListNodeT *pNext);
ResCodeT LinkListIterReset(pOsLinkListIterT pOsLinkListIter);
ResCodeT LinkListIter(pOsLinkListIterT pOsLinkListIter,
                    ProcessLinkListNodeFuncT ProcessLinkListNodeFunc,
                    void *context, /* parameter for the function */
                    BOOL stopOnError);

#if defined(__cplusplus) || defined(c_plusplus)
} /* close scope of 'extern  declaration which encloses file. */
#endif

#endif /* __OS_LINK_LIST_H__ */

/*----------------------------------------------------------------------------*/
/* End of file osqueue.h */
/*----------------------------------------------------------------------------*/
/* DO NOT ADD ANYTHING AFTER THIS LINE */
