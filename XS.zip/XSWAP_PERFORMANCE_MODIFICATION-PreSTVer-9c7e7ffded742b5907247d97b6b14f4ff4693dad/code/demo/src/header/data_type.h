/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _DATA_TYPE_
#define _DATA_TYPE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/


/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef int16_t int16;
typedef u_int16_t uint16;
typedef int32_t int32;
typedef u_int32_t uint32;
typedef int64_t int64;
typedef u_int64_t uint64;

typedef int16  BOOL;

typedef void *   pVoidT;

#define vectorT     uint64

#define VECTOR_BASE      (8 * sizeof(vectorT))

#ifndef vectorT
#define vectorT     uint64
#endif
typedef vectorT             *pVectorT;


typedef uint32 ShmSlotIdT;

#define MAX_INT64       0x7fffffffffffff

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define NO_ERR          1

#define TRUE        1
#define FALSE       0
 
//#define NULL        0
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _DATA_TYPE_ */
