/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _MSG_STRUCT_
#define _MSG_STRUCT_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "../header/data_type.h"
#include "../header/common_macro.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_MSG_LEN        2048
#define MSG_HDR_LEN        (sizeof(MsgHdrT))
#define MSG_BODY_LEN        ((MAX_MSG_LEN) - (MSG_HDR_LEN))

#define MSG_TYPE_ORD_ADD 		1
#define MSG_TYPE_ORD_DEL 		2
#define MSG_TYPE_ORD_BRDG   3
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MsgHdrS
{
    int16 msgLen;
    int16 msgType;
    int16 fromNode;
    int16 toNode;   
    ShmSlotIdT  slotNo;   
} MsgHdrT, *pMsgHdrT;

typedef struct MsgStructS
{
    MsgHdrT     msgHdr;
    char        msgBody[MSG_BODY_LEN];
} MsgStructT, *pMsgStructT;




typedef struct OrdrReqS
{
    int64       ordrExePrc;
    int64       ordrExpDat;
    int64       ordrQty;
    int32       ordrSide;
    int32       prdctId;
    int32       entyIdxNo;
    int32       usrIdxNo;
    int32       ordrType;
    int32       filler;
} OrdrReqT, *pOrdrReqT;



typedef struct OrdrRspS
{
    int64       ordrExePrc;
    int64       ordrQty;
    int64       tradeQty;
    int64       ordrNo;
    int32       ordrSide;
    int32       prdctId;
    int32       entyIdxNo;
    int32       usrIdxNo;
    int32       ordrType;
    int32       filler;
} OrdrRspT, *pOrdrRspT;

typedef struct PrdctMktDataS
{
    int64       lstTrdPrc; //todo get last price
    int64       opnPrc;
} PrdctMktDataT, *pPrdctMktDataT;


typedef struct TradeTag
{
    int32     setId;
    int32     prdctId;
    int32     entyIdxNo;
    int32     usrIdxNo;
    int16     ordrSide;
    int16     ordrType;
    int32     tranType;

    uint64        dateLstUpdDat;
    uint64        tranDatTim;
    uint64        tranIdNo;
    uint64        ordrNo;
    int64         tradMtchPrc;
    int64   trdQty;
    int64   mktVal;
    int64   ordrExePrc;
    uint64        ordrEntTim;
    uint64        ordrExpDat;
    int64   ordrQty;
    int64   ordrExeQty;
    int64   remPeakQty;
    int64   peakSizeQty;
    int64   totAucQty;
    char   ordrPrtFilCod;
    char    filler[7];
} TradeT, *pTradeT;



/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

#endif /* _MSG_STRUCT_ */
