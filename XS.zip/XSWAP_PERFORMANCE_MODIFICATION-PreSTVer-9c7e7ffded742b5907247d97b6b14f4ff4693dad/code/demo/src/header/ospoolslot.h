
#ifndef _OS_POOL_SLOT_H_
#define _OS_POOL_SLOT_H_

#include "bitlib.h"



typedef struct tagPoolSlot
{
    vectorT *vect;
    int32 max;
    int32 poolSize;
    int32 *inBufIndex;
    int32 *outBufIndex;
    int32* inBuffer;
    int32* outBuffer;
}PoolSlotT, *pPoolSlotT;

ResCodeT InitPoolSlot(pPoolSlotT poolSlot,                        
                 const int32 poolSize);
ResCodeT RequestPoolSlot(pPoolSlotT poolSlot,
                 int32 *slotNo);
ResCodeT FreePoolSlot(pPoolSlotT poolSlot,
                 const int32 slotNo);
ResCodeT AllocPoolSlot(pPoolSlotT poolSlot,
         const int32 slotNo);
ResCodeT DeallocPoolSlot(pPoolSlotT poolSlot,
                int32 *slotNo);

#endif
