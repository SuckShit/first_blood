/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _DB_HELP_HEADER_
#define _DB_HELP_HEADER_

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "data_type.h"
#include "errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef enum
{
    DB_ADD = 0,
    DB_UPDATE,
    DB_SELECT,
}DbExeType;


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define DB_HELPER_MAX      200
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct NumColType
{
    uint32 colIndex;
    uint32 numType;
}NumColTypeT;

 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT DbInit(char *pAddr, char *pUser, char *pPasswd);
ResCodeT DbExecutCmd(char *pSql, int32 *pErrCode);

ResCodeT DbExeQuery(char *pSql, void *pData, void *pDes, int32 *pErrCode);
ResCodeT DbCommit(int32 *pErrCode);
ResCodeT DbRollback(int32 *pErrCode);
ResCodeT DbDestroy();

ResCodeT DbExecutCmdByBind(int32 *pErrCode);

ResCodeT DbExePrepare(OCI_Connection ** pCn, OCI_Statement ** ppStmt, char *pSql);
ResCodeT DbExeQueryWithNumInfo(void *pData, void *pDes, NumColTypeT *colTypes, int32 numColCnt, int32 *pErrCode);

ResCodeT DbExecutCmdBlob(char *pSql, otext* blobName, OCI_Lob * blobData ,void* pData ,unsigned int lengthOfLob, int32 *pErrCode);
#endif /* _DB_HELP_HEADER_ */