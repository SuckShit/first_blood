/***
Created on May 08, 2017

@author: Brian.Ping
***/
#ifndef __OS_STATIC_LIST_H__
#define __OS_STATIC_LIST_H__

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* Standard C header files */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "errlib.h"
#include "oslinklist.h"

/* whether to re-initialize the deleted entry */


#ifndef THROW_RESCODE_ON_COND
#define THROW_RESCODE_ON_COND(errCode, cond)\
    if (cond)\
    {\
        THROW_RESCODE(errCode); \
    }
#endif

#ifndef NON_NULL_SLOT
#define NON_NULL_SLOT(slotId)   ((slotId) != NULL_SLOT)
#endif

#ifndef BREAK_ON_COND
#define BREAK_ON_COND(cond)\
    if (cond)\
    {\
        break;\
    }
#endif

#ifndef CONTINUE_ON_COND
#define CONTINUE_ON_COND(cond)\
    if (cond)\
    {\
        continue;\
    }
#endif


#ifndef EXECUTE_ON_COND
#define EXECUTE_ON_COND(state, cond)\
    do { if (cond) {state;}} while (0)
#endif

#ifndef EXECUTE_ON_2_COND
#define EXECUTE_ON_2_COND(state1, state2, cond)\
    do\
    {\
        if (cond)\
        {\
            (state1);\
        }\
        else\
        {\
            (state2);\
        }\
    } while (0)
#endif


#define REINIT_SLIST_ENTRY_AFTER_DEL    0
#define DIRTY(ptr)  SET_PTR_VALUE(ptr, 1)

typedef struct tagOsSListEntry
{
    ShmSlotIdT next;
    ShmSlotIdT prev;
}osSListEntryT, pOsSListEntryT;

#pragma required_pointer_size save
#pragma required_pointer_size 64


#define MAX_LOG_ITEM_SLIST  3

typedef struct tagLogItemSList
{
    ShmSlotIdT slotNo;
    char filler[4];
    osSListEntryT data;
}logItemSListT, *p64LogItemSListT;

typedef struct tagFrameSList
{
    int32 counter;
    char filler[4];
    logItemSListT logItem[MAX_LOG_ITEM_SLIST];
}frameSListT, *p64FrameSListT;



typedef osSListEntryT *p64OsSListEntryT;
typedef ShmSlotIdT  *p64ShmSlotIdT;
typedef char *p64CharT;
typedef void *p64VoidT;
typedef uint64 *p64UInt64T;

#pragma required_pointer_size restore

typedef struct tagOsSListMode
{
    /* pointer to the head structure. NB: It is not a part of the list, and
    also doesn't have the same data type as the list entries */
    p64OsSListEntryT pListHead;
    /* root address of the static list in the share memory */
    p64CharT pRoot;
    /* the size of each slot (entry) */
    uint16 slotSize;
    /* the offset of list entry structure from the beginning of slot entry */
    uint16 listEntryOffset;
    /* the offset of key from the beginning of slot entry */
    uint16 keyOffset;
    /* the offset of slot ID structure from the beginning of list entry */
    uint16 slotIdOffset;
    /* key comparison function */
    int32 (*CompareKeyFunc)(p64VoidT obj1, p64VoidT obj2);
    /* list sort type: can be NON_SORTED, ASCENDING or DESCENDING. refer to
    oslinklist. h */
    uint16 sortType;
    /* Is duplicate key allowed in the list? even duplicate keys are allowed,
    duplicate objs are not. that means same record can't be inserted more than
    once */
    char allowDuplicateKey;
    char useMemFile;    /* Is memory file used for extended slot number ? If
    so, we have to provide the slot limitation for memory and file
    respectively. */
    ResCodeT (*GetRecFunc)(ShmSlotIdT slotId, p64VoidT *out);
    ResCodeT (*WriteRecFunc)(p64VoidT rec);

    p64FrameSListT theFrame;

}osSListModeT, *pOsSListModeT;

#pragma required_pointer_size save
#pragma required_pointer_size 64

typedef const osSListModeT *const_p64OsSListModeT;
typedef osSListModeT *p64OsSListModeT;

#pragma required_pointer_size restore


#define INIT_STATIC_LIST_ENTRY(ptr)\
    do {(ptr)->next = NULL_SLOT; (ptr)->prev = NULL_SLOT;} while (0)

#define INIT_STATIC_LIST(name, pListHead, pRoot, slotSize, listEntryOffset, \
    keyOffset, slotIdOffset, CompareKeyFunc, sortType, allowDuplicateKey)\
    osSListModeT name = {(pListHead), (p64CharT)(pRoot), (slotSize), \
        (listEntryOffset), (keyOffset), (slotIdOffset), (CompareKeyFunc), \
        (sortType),(allowDuplicateKey), 0, NULL, NULL}

/* define a static list that uses memory files. */
#define INIT_STATIC_LIST_EXT(name, pListHead, pRoot, slotSize, listEntryOffset,\
    keyOffset, slotIdOffset, CompareKeyFunc, sortType, allowDuplicateKey, \
    useMemFile, GetRecFunc, WriteRecFunc)\
    osSListModeT name = {(pListHead), (p64CharT)(pRoot), (slotSize), \
        (listEntryOffset), (keyOffset), (slotIdOffset), (CompareKeyFunc), \
        (sortType),(allowDuplicateKey), (useMemFile), (GetRecFunc), \
        (WriteRecFunc)}

#ifndef IS_EMPTY_SLIST
#define IS_EMPTY_SLIST(pHeadEntry)\
    (*(p64UInt64T)(pHeadEntry) == (uint64)-1 )
#endif

#ifndef IN_VALID_SLIST
#define IN_VALID_SLIST(pListEntry)  !IS_EMPTY_SLIST(pListEntry)
#endif


/******************************************************************************
 * Description:   Insert an entry into the specified static linked list. If the
 * list is sorted, then scan forwards from the head of the list to find the
 * insertion position; otherwise insert it before the head item;
 * NB: same record can't be inserted more than once. according to configuration,
 * different entries with same key can or can't be inserted. for non-sorted list
 * , the function won't check the possibility of duplicate keys. Before
 * inserting, be sure that the list entry has been initialized by calling
 * INIT_STATIC_LIST_ENTRY(), otherwise insertion will fail!
 * Parameters:
 *  pOsSListMode    IN  control information for the list.
 *  rec IN  The entry to be inserted.
 *  pHeadDirty  OUT flag to indicate the head of the list has been changed.
 *              (can be NULL)
 *  pTailDirty      OUT flag to indicate the tail of the list has been changed.
 *              (can be NULL)
 *  out OUT Write to the found linked list item in case duplicate obj exists.
 *  tryInsert   IN  indicate trying to rathan than actually insert the entry. if
 *                  TRUE, then fill the slot ID of the prv entry in pPrevSlotId
 *  pPrevSlotId OUT If tryInsert == TRUE, then return the slot ID of the
 *              previous slot ID.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert the item to the list.
 ******************************************************************************/
ResCodeT InsertSListEntryFromHead(const_p64OsSListModeT pOsSListMode,
p64VoidT rec, BOOL *pHeadDirty, BOOL *pTailDirty, p64VoidT *out, BOOL tryInsert,
p64ShmSlotIdT pPrevSlotId);


/******************************************************************************
 * Description:   Insert an entry into the specified static linked list. If the
 * list is sorted, then scan backwards from the tail of the list to find the
 *  insertion; otherwise insert it before the head item;
 * NB: for sorted lists, same record can't be inserted more than once. but for
 * non-sorted lists, the function won't check. so be careful with non-sorted
 * list! Before inserting, be sure that the list entry has been initialized by
 * calling INIT_STATIC_LIST_ENTRY(), otherwise insertion will fail!
 * Parameters:
 *  pOsSListMode    IN  control information for the list.
 *  rec IN  The entry to be inserted.
 *  pHeadDirty  OUT flag to indicate the head of the list has been changed.
 *              (can be NULL)
 *  pTailDirty      OUT flag to indicate the tail of the list has been changed.
 *              (can be NULL)
 *  out OUT Write to the found linked list item in case duplicate obj exists.
 *  tryInsert   IN  indicate trying to rathan than actually insert the entry. if
 *                  TRUE, then fill the slot ID of the prv entry in pPrevSlotId
 *  pPrevSlotId OUT If tryInsert == TRUE, then return the slot ID of the
 *              previous slot ID.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to insert the item to the list.
 ******************************************************************************/
ResCodeT InsertSListEntryFromTail(const_p64OsSListModeT pOsSListMode,
p64VoidT rec, BOOL *pHeadDirty, BOOL *pTailDirty, p64VoidT *out, BOOL tryInsert,
p64ShmSlotIdT pPrevSlotId);

/******************************************************************************
 * Description:   Remove an entry from the specified linked list.
 * Parameters:
 *  pOsSListMode    IN  control information for the list.
 *  rec IN  The entry to be removed.
 *  pHeadDirty  OUT flag to indicate the head of the list has been changed.
 *              (can be NULL)
 *  pTailDirty      OUT flag to indicate the tail of the list has been changed.
 *              (can be NULL)
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to delete an entry from the list.
 ******************************************************************************/
ResCodeT DelSListEntry(const_p64OsSListModeT pOsSListMode, p64VoidT rec, BOOL
*pHeadDirty, BOOL *pTailDirty);


/*******************************************************************************
 * Description:   Find an item in the specified static linked list.
 * Parameters:
 *      pOsSListMode    IN  control information for the list.
 *      key IN  the key to find the rec.
 *      out OUT Write to the found linked list item.
 *      This function searches for an item with a given key.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT FindSListEntryByKey(const_p64OsSListModeT pOsSListMode, p64VoidT key,
p64VoidT *out);

/******************************************************************************
 * Description:   Iterate over the specified static linked list.
 *  pOsSListMode    IN  control information for the list.
 *  ProcessLinkListNodeFunc IN  The function to process each entry.
 *  stopOnError IN  Flag to indicate whether to stop processing when error
 *                  occurs.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to delete an entry from the list.
 ******************************************************************************/
ResCodeT IterateSList(const_p64OsSListModeT pOsSListMode,
    ResCodeT (*ProcessLinkListNodeFunc)(p64VoidT pListNode, p64VoidT context),
    p64VoidT context, BOOL stopOnError);
ResCodeT GetSListHead(const_p64OsSListModeT pOsSListMode, p64VoidT *out);
ResCodeT GetSListTail(const_p64OsSListModeT pOsSListMode, p64VoidT *out);

ResCodeT GetSListNext(const_p64OsSListModeT pOsSListMode, 
                      p64VoidT *out, 
                      ShmSlotIdT *curr);

/******************************************************************************
 * Description:   Update reference to the slot number of the specified record.
 * this function is used when a record is re-assinged another memory storage,
 * such as a slot in a paging file or another block of memory, and update all
 * reference to the original slot number. be noted that when this function is
 * called,
 * the  slot number filled in the record remains the same as the original one.
 *  pOsSListMode    IN  control information for the list.
 *  rec IN   The impacted record whose slot number is re-assigned.
 *  newSlot IN  The new slot number assigned to the impacted record.
 *  pHeadDirty  OUT Write to 1 when the list head is changed.
 *  pTailHead   OUT Write to 1 when the list tail is changed.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to delete an entry from the list.
 ******************************************************************************/
 
ResCodeT SListUpdateRef(const_p64OsSListModeT pOsSListMode,
                        const p64VoidT rec,
                        const ShmSlotIdT oldSlot,
                        BOOL *pHeadDirty,
                        BOOL *pTailDirty);


/******************************************************************************
 * Description:   Rollback whatever changes have been made to the specified
 *  static linked list.
 *  The interface will scan backwards the frame data of the static linked list,
 *  and rollback each change made to the linked list one by one.
 * Parameters:
 *  pOsSListMode    IN  control information for the list.
 * Return Value         :
 *  NO_ERR:     Successful
 *  ERR_<DSCR>: fail to insert the item to the list.
 ******************************************************************************/
ResCodeT SListRollBack(const_p64OsSListModeT pOsSListMode);


#if defined(__cplusplus) || defined(c_plusplus)
} /* close scope of 'extern  declaration which encloses file. */
#endif

#endif /* __OS_STATIC_LIST_H__ */

/*----------------------------------------------------------------------------*/
/* End of file osqueue.h */
/*----------------------------------------------------------------------------*/
/* DO NOT ADD ANYTHING AFTER THIS LINE */

