#include "errlib.h"
/******************************************************************************
 **
 ** Macro
 ** 
******************************************************************************/
#define ERR_PIPE_FILE_ALREADY_EXIST       50001
#define ERR_PIPE_FILE_CREATE_FAILURE      50002
#define ERR_PIPE_FOR_READ_OPEN_FAILURE    50003
#define ERR_PIPE_FOR_WRITE_OPEN_FAILURE   50004
#define ERR_PIPE_READ_DATA_ERROR          50005
#define ERR_PIPE_WRITE_DATA_ERROR         50006
#define ERR_PIPE_READ_NO_DATA						  50007

#define FIFO_BLOCK_MODE                   0
#define FIFO_NON_BLOCK_MODE               1

#define FIFO_OPEN_FOR_READ                0
#define FIFO_OPEN_FOR_WRITE               1
#define FIFO_OPEN_FOR_RDWR                2

#ifdef __cplusplus
extern "C"{
#endif

ResCodeT IPCCreate(const char *fifoname,mode_t mode);
ResCodeT IPCOpen(const char *fifoname,int mode,int block,int* fd);
ResCodeT IPCSend(int fd,const void *buffer,int size);
ResCodeT IPCReceive(int fd,void *buffer,int size);
ResCodeT IPCClose(int fd);

#ifdef __cplusplus
}
#endif