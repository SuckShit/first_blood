/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _MSG_CACHE_
#define _MSG_CACHE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "../header/data_type.h"
#include "../header/common_macro.h"
#include "errlib.h"
#include "bitlib.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
typedef int32     ShmHandleT;
typedef uint32    ShmSlotIdT;

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_MSG_LEN        2048
#define SHM_NORMAL         NO_ERR
#define SHM_NO_SLOT -1  /*indicate no free slot in shared memory*/
#define SHM_FIRST_HANDLE 1

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MsgDataS
{
    char           msgData[MAX_MSG_LEN];      
} MsgDataT, *pMsgDataT;

typedef struct MsgCacheSlotS
{
    int64           timstmp;      /* Timestamp of when the req is passed in */
    int32            pairedSlotId; /* The slot ID of paired response */
    int32            slotId;       /* This slot's slot ID */
    int32           destNode;     /* destination node */
    int32           filler;
    MsgDataT       msgBody;      /* Message in the slot */
} MsgCacheSlotT, *pMsgCacheSlotT;

typedef struct ShmAdminTag
{
    /*the name of global section*/
    char secName[SHM_NAME_LEN];
    /* the size of application administration structure*/
    uint64 appAdminSize;
    /* the size of each data element to be stored in shared memory*/
    uint64 elemSize;
    /*the amount of elements */
    uint64 elemCount;
    /*the first byte including free bit in element bit masks*/
    int64 firstFreeByte;
    /* the amount of allocated slots*/
    ShmSlotIdT allocatedCount;
    int32 filler; /*unused only for alignment*/
    /*the starting address of element bit mask array*/
    vectorT bitMask[1];
} ShmAdminT, *pShmAdminT;



typedef struct ShmInfoTag
{
    /*indicate whether this element is used (0 unused,1 used)*/
    int16  flag;
    /* filler */
    char   filler03[6];
    /* ptr to the starting address of shared memory */
    unsigned char*  pShm;
    /* pointer to the starting address of application administration area*/
    unsigned char*  pAppAdmin;
    /* pointer to the starting address of data area*/
    unsigned char*  pData;
    /* which is used to store the status of the lock of
    the corresponding section*/
//    LOCK_STATUS_BLOCK  mutex_status_block;
    /* the name of shared memory*/
    char secName[SHM_NAME_LEN];
    /* pool size and its lower and upper limits for this shared memory, if any*/
    int32 poolSize;
    int32 poolLowLimit;
    int32 poolUpLimit;
    /* the array of pooled slots, with get/put pointer */
    int32 poolGetPos;
    int32 poolPutPos;
    int32 poolCnt;
    ShmSlotIdT *pool;
    /* below 2 variables are used to track the slot that has the largest search
    count in the OA hash table */
    uint32 maxTryCnt;
    uint32 poolCycle;
    uint32 maxTryCntWithinPoolCycle;
    uint32 filler;
    /* each avaible slot's hash index into the below OA hash table */
    uint32 *hashIdx;
    uint64 actualSize;
}  ShmInfoT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
#ifdef __cplusplus
extern "C"{
#endif

ResCodeT MsgDelete         (int32                       slotId);
ResCodeT MsgRsrvSlot       (int32                    *  pSlotId,
                            pMsgCacheSlotT        *  ppSlot);
ResCodeT MsgCreateCache    (int32        slotNum);
ResCodeT MsgRsrvSlotsPaired(int32                    *  pSlotId,
                            pMsgCacheSlotT        *  ppReqSlot,
                            pMsgCacheSlotT        *  ppRespSlot);
ResCodeT MsgInit(int32        slotNum);
ResCodeT MsgGetMsg         (int32                       slotId,
                            pMsgDataT            *  ppMsg);
ResCodeT MsgGetSlotRsp(int32                   slotId,
                            pMsgCacheSlotT        *  ppRespSlot);    
ResCodeT MsgGetSlot         (int32                       slotId,
                            pMsgCacheSlotT            *  ppMsg);  

#ifdef __cplusplus
}
#endif
							
#endif /* _MSG_CACHE_ */
