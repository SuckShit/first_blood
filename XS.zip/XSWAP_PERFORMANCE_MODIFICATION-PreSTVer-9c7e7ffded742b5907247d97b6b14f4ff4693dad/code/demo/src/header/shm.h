/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _SHM_LIB_
#define _SHM_LIB_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define SHM_ID_MSG_CACHE     0x000003e9   /* Message cache*/
#define SHM_ID_ORD_BK_ONE    0x000004e9		/* matcher 1 orderbook */
#define SHM_ID_ORD_BK_TWO    0x000005e9		/* matcher 2 orderbook */

#define SHM_SHL_IN_BUFF_ONE 	0x000006e9	/* matcher 1 input buffer */
#define SHM_SHL_IN_BUFF_TWO  	0x000007e9  /* matcher 2 input buffer */

#define SHM_SHL_OUT_BUFF_ONE 	0x000008e9  /* matcher 1 output buffer */
#define SHM_SHL_OUT_BUFF_TWO  0x000009e9  /* matcher 2 output buffer */ 

#define SHM_MEM_TXN_ID  			0x000019e9  /* memory txn  */ 

#define SHM_MEM_CREDIT_ID  			0x000029e9  /* credit  manage memory */ 
#define SHM_MEM_CREDIT_COE_ID  			0x000039e9  /* credit COE manage memory */ 

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
void  shmCreate(char** shmHandle, int id ,int size);
void  shmRead(char* shmHandle, int index, int recordSize, char* record);
void  shmWrite(char* shmHandle, int index, int recordSize, char* record);


#endif /* _SHM_LIB_ */
