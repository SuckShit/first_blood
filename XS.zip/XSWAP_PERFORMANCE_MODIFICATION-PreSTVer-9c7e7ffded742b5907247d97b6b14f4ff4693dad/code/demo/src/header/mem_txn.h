/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _MEM_TXN_
#define _MEM_TXN_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "errlib.h"
#include "bitlib.h"
/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_DATA_LEN        240 /* need to put in config in the future */

#define TXN_ID_NO_SQNO -1  /*indicate no squence no */

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MemTxnCtrlS
{
    int64 currTxnId;
    int64 commitTxnId;
    int64 maxTxnId;
} MemTxnCtrlT, *pMemTxnCtrlT;

typedef struct MemTxnDataHdrS
{
    int32           dataSqno;     
    int32           nextDataSqno;     
    int16           dataType; 
    int16           dataLen;   
    char            filler[4];
} MemTxnDataHdrT, *pMemTxnDataHdrT;

typedef struct MemTxnEntryS
{  
    int64               txnId;
    int32               txnSts;
    int32               dataCnt;     
    int64               frstDataSqno; /* Link the first data sqno / slot */
} MemTxnEntryT, *pMemTxnEntryT;

typedef struct MemTxnDataCtrlS
{
    int32       dataSize;
    int32       dataTtlCnt;
    int32       usedSlotCnt;
    int32       nextDataSlot;
} MemTxnDataCtrlT, *pMemTxnDataCtrlT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
#ifdef __cplusplus
extern "C"{
#endif
ResCodeT MemTxnShmCreate (int32 totVolumn, int32 dataSize);
ResCodeT MemTxnShmAttach (int32 set);
ResCodeT MemTxnStart(int64* pTxnId, int64 * pTimestamp);
ResCodeT MemTxnCommit();
ResCodeT MemTxnAddData(int32 dataType, void * pData, int32 dataLen);
ResCodeT MemReadTxnData(int32 txnId, int32 * pDataType, void ** ppData, int32 * pDataLen,int64 *pCursor);
ResCodeT MemTxnGetTxnEnty(int32 txnId, pMemTxnEntryT pTxnEntry);
ResCodeT MemTxnGetTxnCtrl(pMemTxnCtrlT pTxnCtrl);
#ifdef __cplusplus
}
#endif
   
#endif /* _MEM_TXN_ */
