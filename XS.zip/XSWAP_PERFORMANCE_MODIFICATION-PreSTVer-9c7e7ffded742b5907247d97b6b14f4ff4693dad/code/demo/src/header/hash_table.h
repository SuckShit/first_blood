/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _HASH_TBL_
#define _HASH_TBL_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct  HashNode_Struct
{
   char* sKey;
   int   nValue;
   struct  HashNode_Struct* pNext;
}HashNodeT, *pHashNodeT;

typedef struct  HashTable_Struct
{
   int   maxSize;
   pHashNodeT pHead[20000];
}HashTableT, *pHashTableT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT HashTableCreate(int size, pHashTableT table);
ResCodeT hashTableInsertNode(pHashTableT table, char* sKey, int nValue);
ResCodeT hashTableLookUp(pHashTableT table, char* sKey, pHashNodeT node);
ResCodeT hashTableRemoveNode(pHashTableT table, char* sKey);


#endif /* _HASH_TBL_ */
