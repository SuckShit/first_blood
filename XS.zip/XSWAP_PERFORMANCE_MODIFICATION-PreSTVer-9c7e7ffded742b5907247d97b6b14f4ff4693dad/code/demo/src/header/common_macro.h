/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _COMM_MACRO_
#define _COMM_MACRO_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_SET_CNT         3
#define MAX_PRDCT_CNT         1000
#define MAX_SLOT_CNT				50000
#define MAX_ORDR_VOLM				50000
#define DB_INST "200.31.155.145:1521/xswapdb"
#define DB_NAME "xswap"
#define DB_PWD "xswap"

//config



#ifndef NULL_SLOT
#define NULL_SLOT   (ShmSlotIdT)-1
#endif

#define IPC_CON_2_MATCH										"IPC_CON_2_MATCH_%lld.pipe"
#define IPC_MATCH_2_CON										"IPC_MATCH_2_CON_%lld.pipe"

//#define IPC_CM_2_MATCH										"IPC_CON_2_MATCH_%lld.pipe"
//#define IPC_MATCH_2_CM										"IPC_MATCH_2_CM_%lld.pipe"


#define IPC_CM_2_MATCH										"IPC_CM_2_MATCH.pipe"
#define IPC_MATCH_2_CM										"IPC_MATCH_2_CM.pipe"

#define WKSG_LIT_BUY                      'B'
#define WKSG_LIT_SELL                     'S'
#define WKSG_LIT_MARKETABLE               'M'
#define WKSG_LIT_YES                      'Y'
#define WKSG_LIT_NO                       'N' 


#define SHM_NAME_LEN        128


#define ADDRESS_ADD_OFFSET(_prt_, _offset_) ((uint64)(_prt_) + (uint64)(_offset_))
#define ADDRESS_MINUS_OFFSET(_prt_, _offset_) ((uint64)(_prt_) - (uint64)(_offset_))

#define MIN(x,y)     ((x) < (y)?(x):(y))
#define MAX(x,y)     ((x) > (y)?(x):(y))

#define GET_BIT_VECT_LEN(_cnt_)    (((_cnt_) + 1 + VECTOR_BASE - 1)/ VECTOR_BASE)

#ifndef offsetof
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif

#ifndef MALLOC
#define MALLOC(_ptr_, _size_)\
do\
{\
    (_ptr_) = (void *)malloc(_size_);\
    if (!_ptr_)\
    {\
    }\
} while(0);
#endif

#ifndef GET_SET_ID
#define GET_SET_ID( _prdctId_)   (((_prdctId_%2) == 0) ? 2:1)
#endif
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _COMM_MACRO_ */
