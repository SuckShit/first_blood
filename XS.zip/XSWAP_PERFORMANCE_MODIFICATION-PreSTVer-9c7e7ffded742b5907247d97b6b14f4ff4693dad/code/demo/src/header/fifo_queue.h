#include "errlib.h"

/******************************************************************************
 **
 ** Macro
 ** 
******************************************************************************/
#define ERR_QUEUE_CREATE_FAILURE          51001
#define ERR_QUEUE_DESTROY_FAILURE         51002
#define ERR_QUEUE_IS_FULL                 51003
#define ERR_QUEUE_IS_EMPTY                51004
#define ERR_QUEUE_NOT_EXIST               51005

#define MAX_QUEUE_NUMBER                  1000
#define QUEUE_POOL_SHM_KEY                -12345
#define QUEUE_POOL_NULL_KEY               -99999

typedef struct fifoInfo{
//  void* shm;     // shared memory address
  int shmid;     // shared memory id
  int size;      // queue size
  int node_size; // the size of the element
  int putP;      // the position to write
  int getP;      // the position to read
  int free;      // free size
  int key;       // queue key
} FifoInfoT, *pFifoInfoT;

typedef struct fifoLocalAddrInfo{
  int key;       // queue key (all processes shared)
  void* shm;     // shared memory address (per process)
  int shmid;     // shared memory id 
} FifoLocalAddrInfoT;

typedef struct testData{
  int size;
  char value[20];
} TestDataT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
//FifoInfoT queuePool[MAX_QUEUE_NUMBER];
static FifoLocalAddrInfoT gAddrInfo[MAX_QUEUE_NUMBER];

static int gPoolShmid = -1;
static pFifoInfoT gPoolShm;

/******************************************************************************
Method Declaration
******************************************************************************/
ResCodeT GetQueueInfo(int queue_key,pFifoInfoT* queueInfo);
ResCodeT CreateFifoQueue(int queue_key,int node_size,int queue_size,pFifoInfoT* fifoQue);
ResCodeT GetFromFifoQueue(pFifoInfoT fifoQue,void* buffer);
ResCodeT PutIntoFifoQueue(pFifoInfoT fifoQue,void *buffer);
ResCodeT DestroyFifoQueue(pFifoInfoT fifoQue);
ResCodeT GetStatusOfFifoQueue(pFifoInfoT fifoQue);


