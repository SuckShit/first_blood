/***
Created on May 17, 2017

@author: Brian.Ping
***/

#ifndef _CREDT_LIB_
#define _CREDT_LIB_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "common_macro.h"
#include "errlib.h"
#include "bitlib.h"
#include "../header/dbhelp.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MSG_TYPE_CHECK        1
#define MSG_TYPE_UPDATE       2

#define CM_SELF 				TRUE 
#define CM_NO_SELF 			FALSE 
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct CrdtMsgS
{
    int32 msgType;
    int32 rtnCode;
    int32 crdtEntyNo;
    int32 trgtEntyNo;
    int64 totalCrdtAmnt;
    int64 usdCrdtAmnt;
    int64 avaCrdtAmnt;
} CrdtMsgT, *pCrdtMsgT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT CrdtLibInit (BOOL bIsCmFlg);
ResCodeT CreateCreditHashTable ();

/* the following is for matcher */
ResCodeT CrdtLibCheckRemoteCrdtInfo (pCrdtMsgT pReqCrdt);
ResCodeT CrdtLibUpdtRemoteCrdtInfo (pCrdtMsgT pReqCrdt);

/* the following is for credit management   */
ResCodeT CrdtLibReadReq (pCrdtMsgT pReqCrdt);
ResCodeT CrdtLibSendRsp (pCrdtMsgT pReqCrdt);
ResCodeT CrdtLibPrcsReq (pCrdtMsgT pReqCrdt);
ResCodeT CrdtLibCheckLocalCrdtInfo (pCrdtMsgT pReqCrdt);
ResCodeT CrdtLibUpdateLocalCrdtInfo (pCrdtMsgT pReqCrdt);
#endif /* _CREDT_LIB_ */
