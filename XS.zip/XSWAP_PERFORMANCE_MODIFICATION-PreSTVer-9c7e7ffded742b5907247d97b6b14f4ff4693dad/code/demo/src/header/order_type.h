/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _ORDER_TYPE_
#define _ORDER_TYPE_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "data_type.h"
#include "osslist.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct OrderFS /* 8 8 4 4 8 8 8 8 8 1 7 8 8 = 96*/
{
    int64       ordrExePrc;
    int32       ordrSide;
    int32       prdctId;
    int64       ordrNo;
    int64       ordrEntTim;
    int64       ordrExpDat;
    int64       tranTime;
    int64       ordrQty;
    int64       remPkQty;
    int32       entyIdxNo;
    int64       ordrExeQty;
    int64       ordrApplyPrc;
    int64       ordrMtchPrc;
    int16       ordrType;
    char        ordrSts; /* 'Y' indicates FROZEN */
    char        filler[1];
    int32				brdgFee;
    int32				filler1;
}OrderFT, *pOrderFT;

/* OrderFT for price leader */
/* OrderF4PrcLeadT and OrderFT should have the same size */

typedef struct OrderF4PrcLeadS /* 8 4 4 4 8 4 4 4 56 = 96*/
{
    int64       ordrExePrc;
    int32       ordrSide;
    int32       prdctId;
    int64       ordrNo;
    int64       ordrPri; /* order priority used to sorting of price leader */
    int32       odrBkSortingType;
    int32       cntUnrO;
    int32       totUnrO;
    int32       cntUnrAuOaO;
    int32       totUnrAuOaO;
    char        filler[60];
}OrderF4PrcLeadT, *pOrderF4PrcLeadT;

typedef struct OrderTS /* 8 8 8 4 4 4 12 = 48*/
{
    osSListEntryT   unrO;
    osSListEntryT   unrAuOaO;
    osSListEntryT   ordNo;
    osSListEntryT   entyNo;

    ShmSlotIdT      priceLdr;
    ShmSlotIdT      slotNo;

    int32           free;
    char            filler[12];
}OrderTT, *pOrderTT;

/* OrderTT for price leader */
/* OrderT4PrcLeadT and OrderTT should have the same size */
typedef struct OrderT4PrcLeadS /* 8 8 8 4 4 8 4 4 = 48*/
{
    osSListEntryT   unrO;
    osSListEntryT   unrAuOaO;
    osSListEntryT   ordNo;
    osSListEntryT   entyNo;

    ShmSlotIdT      priceLdr;
    ShmSlotIdT      slotNo;

    osSListEntryT   prcLder;

    int32           free;
    int32           filler;

}OrderT4PrcLeadT, *pOrderT4PrcLeadT;


typedef struct OrderS
{
    OrderFT orderF;
    OrderTT orderT;
}OrderT, *pOrderT;


typedef struct Order4PrcLeadS
{
    OrderF4PrcLeadT orderF;
    OrderT4PrcLeadT orderT;
}Order4PrcLeadT, *pOrder4PrcLeadT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



#endif /* _ORDER_TYPE_ */
