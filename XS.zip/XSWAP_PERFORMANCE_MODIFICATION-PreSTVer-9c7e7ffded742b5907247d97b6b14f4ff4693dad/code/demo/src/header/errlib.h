/***
Created on May 08, 2017

@author: Brian.Ping
***/
#if !defined(_ERRLIB_)
#define _ERRLIB_


/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

#include "../header/data_type.h"
#include "../header/err_cod.h"

/* -------------------------------------------------------------------------- */
/* -------- CONSTANTS ------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* to separate variable parameters of RAISE_ERROR */
#define $$ ,

/* return flag for RAISE_ERRORxxx() macros */
#define RTN                1
#define NORTN              0

/* parmFlag for RaiseErrorxxx() functions, It is not recommended for the caller
 to use RaiseErrorxxx() functions directly. Use RAISE_ERROR() macros instead. */
/* passed variable parameters should be used to combine a full description */
#define PARM                1
/* passed variable parameters should be discarded,just use the constant part of
   of error description */
#define NOPARM              0

/* 4 error severity: fatal/error/warning/information */
#define ES_FAT_ERR                      4
#define ES_ERR                          3
#define ES_WRN                          2
#define ES_INFO                         1

#define MAX_DESCRIPTION_LENGTH          81

/* keep some define in obsolete raerr003.h for compatiability with old API */
/* SYER-STATUS-IDS */
#define SYER_DBIO_ERROR        "DBIO"
#define SYER_FAI_ERROR         "FAI "
#define SYER_SYSS_ERROR        "SYSS"
#define SYER_APPLIC_ERROR      "APPL"
#define SYER_OCOP_ERROR        "OCOP"
#define SYER_SECU_ERROR        "SECU"
#define SYER_NF_SECU_ERROR     "NFSE"


#define ERROR_SEV_INFORMATION  "[INFORMATION] "
#define ERROR_SEV_WARNING      "[WARNING] "
#define ERROR_SEV_ERROR        "[ERROR] "
#define ERROR_SEV_FATAL_ERROR  "[FATAL ERROR] "


static char errInfMap[ES_FAT_ERR + 1][16] =
{
    "",                         /* map the inexistent error severity */
    ERROR_SEV_INFORMATION,      /* ES_INFO */
    ERROR_SEV_WARNING,          /* ES_WRN  */
    ERROR_SEV_ERROR,            /* ES_ERR  */
    ERROR_SEV_FATAL_ERROR       /* ES_FAT_ERR */
};

/* SYER-PROGRAM-TYPES */
#define SYER_PROG_BATCH_TYP     'B'
#define SYER_PROG_ASYN_TYP      'A'
#define SYER_PROG_SYNC_TYP      'S'
#define SYER_PROG_ONLINE_TYP    'O'

/* SYER-INITIALIZE-FLAGS */
#define SYER_FAI_ALL             0
#define SYER_FAI_DATA            1
#define SYER_NON_FAI_ALL         2
#define SYER_NON_FAI_DATA        3

/* keep some define in obsolete arch_message.h for compatiability with old API*/
#define FAT 'F'  /* fatal message */
#define IMP 'I'  /* important message */
#define GEN 'G'  /* general message */
#define INF 'N'  /* information message */

/* to indicate it is an invalid OpenVMS system return code */
#define NO_INFO   -181166



/* -------------------------------------------------------------------------- */
/* -------- MACROS ---------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* description                                                                */



#define BEGIN_FUNCTION(functionName)                \
    ResCodeT __rc = NO_ERR;                         \
    ResCodeT __errorCode = NO_ERR;                  \
    long __sysResultCod = 1;                        \
    const char *fctName = functionName;             \
    const char *sctName = NULL


#define SECTION(sectionName)                        \
    sctName = sectionName;

#define EXIT_BLOCK()                                \
    el_exitblock:

#define THROW_RESCODE(_rc_)\
do\
{\
    __rc = (_rc_);\
    goto el_exitblock;\
} while (0);

#define SET_RESCODE(_rc_)\
    __rc = (_rc_);

#define RETURN_RESCODE                              \
    return __rc;

#define OK(_rc_)    ((_rc_) == NO_ERR)

#define NOTOK(_rc_) ((_rc_) != NO_ERR)

#define RAISE_ERROR(_errorCode_,_rtnFlag_)\
do\
{\
    __errorCode = (_errorCode_);\
    if ((__errorCode) != NO_ERR)\
    {\
        __rc = __errorCode;\
        RaiseError(__errorCode,__FILE__,__LINE__,fctName,sctName,NOPARM);\
        if ((_rtnFlag_) == RTN)\
        {\
            goto el_exitblock;\
        }\
    }\
} while (0);


#define RAISE_ERROR_PARM(errorCode,rtnFlag,parms)   \
    __errorCode = (errorCode);                      \
    if ((__errorCode) != NO_ERR)                    \
    {                                               \
        __rc = __errorCode;                         \
        RaiseError(__errorCode,__FILE__,__LINE__,fctName,sctName,PARM,parms); \
        if (rtnFlag == RTN)                          \
        {                                           \
            goto el_exitblock;                      \
        }                                           \
    }


#define GET_RESCODE() (__rc)


#define TEST_RESCODE_CHECK(_rc_, _str_)\
do\
{\
    if (OK(_rc_))\
    {\
        printf("PASS, %.20s\n", _str_);\
    }\
    else\
    {\
        printf("ERR %lld, %.20s\n",_rc_ , _str_);\
    }\
} while (0);

#define TEST_DONE()\
do\
{\
    printf("Func %s done\n",fctName);\
} while (0);

#if defined(__DEBUG)
  #define ASSERT(s)                                 \
    if (!(s))                                        \
    {                                               \
      TRACE("ASSERT FAILED");                       \
      exit(1);                                      \
    }
#else
    #define ASSERT(s)
#endif

#if defined(__DEBUG)
  #define TRACE(s)  \
    TraceLog(__FILE__,__LINE__,fctName,sctName,s);
#else
    #define TRACE(s)
#endif

#if defined(__DEBUG)
  #define TRACE_PARM(s,parms)  \
    TraceLog(__FILE__,__LINE__,fctName,sctName,s,parms);
#else
    #define TRACE_PARM(s,parms)
#endif

#define GET_VMS_EXIT_CODE(rc) ((NOTOK(rc))?2:1)



/* description                                                                */
typedef int32 ResCodeT;

/* the format of a record in error table */
typedef struct ErrorInfoTag
{
    ResCodeT    errorCode;
    int32         severity;
    /* English constant error description */
    char        EnglDscr[MAX_DESCRIPTION_LENGTH + 1]; 
    /* Chinese constant error description */
    char        ChnDscr[MAX_DESCRIPTION_LENGTH + 1];   

    /* default action */
    int32         defAction;
    /* raised counter */
    uint64 cntRaised;
    uint64 totalRaised;
    int64          lstLogTime;
} ErrorInfoT;


/* -------------------------------------------------------------------------- */
/* -------- GLOBAL FUNCTIONS DECLARATION ------------------------------------ */
/* -------------------------------------------------------------------------- */
/* -- Short Usage Description                                                 */
/*  Handle an error by looking up the error table.
 *  Parameters           : errorCode : IN - the error code
 *                         fileName  : IN - the file name where error occurs
 *                         lineNo    : IN - the line number where error occurs
 *                         fctName   : IN - function name where error occurs
 *                         sctName   : IN - section name where error occurs
 *                         parmFlag  : IN - to indicate if passed variable
 *                                          parameters should be used
 *                         ...       : IN - the variable parameters as dynamic
 *                                          error description
 *  Returns              : NO_ERR - succeed
 *                         ERR_ARCH_EL_NOERRORCODE - cannot find the error code
 *                         ERR_ARCH_EL_DSCRTRUNC - the result str is truncated
*/
#ifdef __cplusplus
extern "C"{
#endif
ResCodeT RaiseError(const ResCodeT errorCode,const char *fileName,
                    const int lineNo,const char *fctName,const char *sctName,
                    int parmFlag,...);
#ifdef __cplusplus
}
#endif    

#endif
