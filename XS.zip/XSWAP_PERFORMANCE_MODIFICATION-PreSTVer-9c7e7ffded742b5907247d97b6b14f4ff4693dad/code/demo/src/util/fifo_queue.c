/******************************************************************************
 **
 ** Header File
 ** 
******************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/shm.h>

/* Project related header files */
#include "../header/fifo_queue.h"
#include "../header/errlib.h"
#include "../header/common_macro.h"


/******************************************************************************
 **
 ** Function Implementation
 ** 
******************************************************************************/
ResCodeT GetQueueInfo(int queue_key,pFifoInfoT *queueInfo){
  BEGIN_FUNCTION("GetQueueInfo");
  ResCodeT rc;
  int existFlag;
  int shmid;
  int index;
  int searchIndex;
  int freeIndex;
  void* shm;
  pFifoInfoT pQueuePool;
  pFifoInfoT pQueueSearch;
  
  // get the pool manager address
  shmid = shmget((key_t)QUEUE_POOL_SHM_KEY,0,0);
  if (shmid >= 0){
    // the queue pool shared memory has already existed
	//printf("pool memory already exist\n");
	
	// If the gPoolShmid doesn't exit(pool manager shared memory was created by other process)
	if (gPoolShmid == -1){
	  gPoolShmid = shmid;
	  
	  shm = shmat(shmid,NULL,0);
	  
	  gPoolShm = (pFifoInfoT)shm;
	  
	  // init the share memory local address information array
	  for (index=0;index<MAX_QUEUE_NUMBER;index++){
	    gAddrInfo[index].key = QUEUE_POOL_NULL_KEY;
	    gAddrInfo[index].shm = NULL;
	    gAddrInfo[index].shmid = -1;
	  }
	  
	  //printf("In GetQueueInfo, when Pool SHM was created by other Process, the gPoolShmid is :%d\n",gPoolShmid);
	  //printf("In GetQueueInfo, when Pool SHM was created by other Process, the gPoolShm is :%d\n",gPoolShm);
	}
  }else{
    // The pool manager shared memory has not been created,so create it.
    // init the pool array
	FifoInfoT queuePool[MAX_QUEUE_NUMBER];
	
	for (index=0;index<MAX_QUEUE_NUMBER;index++){
      // initiate the info of node in queuePool
      queuePool[index].key = QUEUE_POOL_NULL_KEY;
      queuePool[index].shmid = -1;
      queuePool[index].getP =0;
      queuePool[index].putP = 0;
      queuePool[index].size = 0;
      queuePool[index].node_size = 0;
      queuePool[index].free = 0;
    }
	
	// init the share memory local address information array
	for (index=0;index<MAX_QUEUE_NUMBER;index++){
	  gAddrInfo[index].key = QUEUE_POOL_NULL_KEY;
	  gAddrInfo[index].shm = NULL;
	  gAddrInfo[index].shmid = -1;
	}
	
    // get the queue pool shared memory
    shmid = shmget((key_t)QUEUE_POOL_SHM_KEY,sizeof(FifoInfoT)*MAX_QUEUE_NUMBER,0666|IPC_CREAT);
	gPoolShmid = shmid;
	//printf("in get queue.shmid_info=%d\n",shmid);
    if (shmid < 0){
      THROW_RESCODE(ERR_QUEUE_CREATE_FAILURE)
    }
	
	shm = shmat(shmid,NULL,0);
	gPoolShm = (pFifoInfoT)shm;
	//printf("in get queue.shm_info=%d\n",shm);
	pQueuePool = (pFifoInfoT)shm;
	
	// copy the initial pool data into shared memory
	for (index=0;index<MAX_QUEUE_NUMBER;index++){
	  memcpy(pQueuePool+index,&queuePool[index],sizeof(FifoInfoT));
	  //printf("in get queue.pQueuePool+index=%d\n",pQueuePool+index);
	}
	
	// since it's the first time that pool manager memory is created,
	// Just throw the exception of "ERR_QUEUE_NOT_EXIST" and exit.
	THROW_RESCODE(ERR_QUEUE_NOT_EXIST)
  }
  
  //printf("get here!!gPoolShm:%d\n",gPoolShm);
  pQueueSearch = gPoolShm;
  
  existFlag = -1;
  for (index=0;index<MAX_QUEUE_NUMBER;index++){
    if ((pQueueSearch + index)->key != QUEUE_POOL_NULL_KEY){
	  if ((pQueueSearch + index)->key == queue_key){
	    *queueInfo = pQueueSearch + index;
		existFlag = 1;
		//printf("get here!!Inner444:%d\n",(*queueInfo)->key);
		break;
	  }
	}
  }

  if (existFlag == -1){
    //printf("flag is zeor!!");
    THROW_RESCODE(ERR_QUEUE_NOT_EXIST)
  }
  
  searchIndex = -1;
  // Search the free node in SHM Local Address Array.
  for (index=0;index<MAX_QUEUE_NUMBER;index++){
    
    if (gAddrInfo[index].key == queue_key){
	    searchIndex = index;
		break;
	}
  }
  
  if (searchIndex == -1){
    // queue_key has not created corresponding record in gAddrInfo Array.So create it.
	// Search the free node in SHM Local Address Array.
    for (index=0;index<MAX_QUEUE_NUMBER;index++){
      //printf("the key in loop index is :%d\n",gAddrInfo[index].key);
      if (gAddrInfo[index].key == QUEUE_POOL_NULL_KEY){
	      freeIndex = index;
		  //printf("hit the :%d\n",index);
		  break;
	  }
    }
	
	//printf("freeIndex is:%d\n",freeIndex);
	
	// First attach the SHM of queue_key
	// Create the share memory
    shmid = shmget((key_t)queue_key,0,0);
  
    if (shmid == -1){
      // shared memory creation failed.
	  //printf("in GetQueueInfo, queue memory could not get.\n");
	  THROW_RESCODE(ERR_QUEUE_CREATE_FAILURE)
    }
  
    // shared memory attach
    shm = shmat(shmid,NULL,0);
  
    if (shm == (void*)-1){
      // Attach failed.
	  //printf("in GetQueueInfo, queue memory could not attach.\n");
	  THROW_RESCODE(ERR_QUEUE_CREATE_FAILURE)
    }
	
	// set the value
	gAddrInfo[freeIndex].key = queue_key;
	gAddrInfo[freeIndex].shmid = shmid;
	gAddrInfo[freeIndex].shm = shm;
  }
  
  EXIT_BLOCK()
  RETURN_RESCODE
}


ResCodeT CreateFifoQueue(int queue_key,int node_size,int queue_size,pFifoInfoT *fifoQue){
  BEGIN_FUNCTION("CreateFifoQueue");
  ResCodeT rc;
  int shmid;
  int shmid_info;
  int total_size;
  void* shm;
  void* shm_info;
  pFifoInfoT pQueueSearch;
  int index,searchIndex;
  int flag;
  
  total_size = node_size * queue_size;
  //printf("total_size=%d\n",total_size);
  shm = NULL;
  shm_info = NULL;
  
  // Create the share memory
  shmid = shmget((key_t)queue_key,total_size,0666|IPC_CREAT);
  
  //printf("after shmget.\n");
  if (shmid == -1){
    // shared memory creation failed.
	//printf("in create queue, queue memory not created.\n");
	THROW_RESCODE(ERR_QUEUE_CREATE_FAILURE)
  }
  
  // shared memory attach
  shm = shmat(shmid,NULL,0);
  
  //printf("after shmat.shmid=%d\n",shmid);
  //printf("after shmat.shm=%d\n",shm);
  if (shm == (void*)-1){
    // Attach failed.
	//printf("in create queue, queue memory not attached.\n");
	THROW_RESCODE(ERR_QUEUE_CREATE_FAILURE)
  }
  
  pQueueSearch = gPoolShm;
  
  //printf("before loop.\n");
  flag = 0;
  
  // Search the free node in Queue Info Pool.
  for (index=0;index<MAX_QUEUE_NUMBER;index++){
    //printf("search address:%d.\n",pQueueSearch);
    
    if ((pQueueSearch + index)->key == QUEUE_POOL_NULL_KEY){
	    *fifoQue = pQueueSearch + index;
		break;
	}
  }
  
  // Search the free node in SHM Local Address Array.
  for (index=0;index<MAX_QUEUE_NUMBER;index++){
    
    if (gAddrInfo[index].key == QUEUE_POOL_NULL_KEY){
	    searchIndex = index;
		break;
	}
  }
  
  //printf("after loop.\n");
  // initiate the info of node in queuePool
  (*fifoQue)->key = queue_key;
  (*fifoQue)->shmid = shmid;
  (*fifoQue)->getP =0;
  (*fifoQue)->putP = 0;
  (*fifoQue)->size = queue_size;
  (*fifoQue)->node_size = node_size;
  (*fifoQue)->free = queue_size;
  
  gAddrInfo[searchIndex].key = queue_key;
  gAddrInfo[searchIndex].shmid = shmid;
  gAddrInfo[searchIndex].shm = shm;
  
  //printf("the fifoQue addr is :%d\n",*fifoQue);
  //printf("right after the init of fifoQue,the key is :%d\n",(*fifoQue)->key);
  //printf("the searchIndex is :%d\n",searchIndex);
  
  EXIT_BLOCK()
  RETURN_RESCODE
}


ResCodeT GetFromFifoQueue(pFifoInfoT fifoQue,void* buffer){
  BEGIN_FUNCTION("GetFromFifoQueue");
  ResCodeT rc;
  int key;
  int index;
  int searchIndex;
  
  key = fifoQue->key;
  
  // find the corresponding element in SHM local address array.
  for (index = 0;index < MAX_QUEUE_NUMBER;index++){
    if (gAddrInfo[index].key == key){
	  searchIndex = index;
      break;
	}
  }
  
  //printf("in Get Method, the searchIndex is :%d\n",searchIndex);
  
  if (fifoQue->free == fifoQue->size){
    // The Queue is empty
	THROW_RESCODE(ERR_QUEUE_IS_EMPTY)
  }
  
  //printf("in Get Method, the start addr is :%d\n",gAddrInfo[searchIndex].shm);
  //printf("in Get Method, the offset is :%d\n",fifoQue->getP*fifoQue->node_size);
  //printf("in Get Method, the date to be get is at the address :%d\n",gAddrInfo[searchIndex].shm + fifoQue->getP*fifoQue->node_size);
  
  // Get data
  memcpy(buffer,gAddrInfo[searchIndex].shm + fifoQue->getP*fifoQue->node_size,fifoQue->node_size);
  
  fifoQue->getP++;
  if (fifoQue->getP == fifoQue->size){
    // the Get position has reach the end of the queue,so jump to the head of the queue
	fifoQue->getP = 0;
  }
  
  fifoQue->free++;
  
  EXIT_BLOCK()
  RETURN_RESCODE
}


ResCodeT PutIntoFifoQueue(pFifoInfoT fifoQue,void *buffer){
  BEGIN_FUNCTION("PutIntoFifoQueue");
  ResCodeT rc;
  int key;
  int index;
  int searchIndex;
  
  key = fifoQue->key;
  
  // find the corresponding element in SHM local address array.
  for (index = 0;index < MAX_QUEUE_NUMBER;index++){
    if (gAddrInfo[index].key == key){
	  searchIndex = index;
      break;
	}
  }
  
  //printf("in Put Method, the searchIndex is :%d\n",searchIndex);
  
  if (fifoQue->free == 0){
    // The Queue is full
	THROW_RESCODE(ERR_QUEUE_IS_FULL)
  }
  
  //printf("in Put Method, the start addr is :%d\n",gAddrInfo[searchIndex].shm);
  //printf("in Put Method, the offset is :%d\n",fifoQue->putP*fifoQue->node_size);
  //printf("in Put Method, the date to be put is at the address :%d\n",gAddrInfo[searchIndex].shm + fifoQue->putP*fifoQue->node_size);
  
  // Write the data into the queue
  memcpy(gAddrInfo[searchIndex].shm + fifoQue->putP*fifoQue->node_size,buffer,fifoQue->node_size);
  
  fifoQue->putP++;
  if (fifoQue->putP == fifoQue->size){
    // the Put position has reach the end of the queue,so jump to the head of the queue
	fifoQue->putP = 0;
  }
  
  fifoQue->free--;
  
  EXIT_BLOCK()
  RETURN_RESCODE
}


ResCodeT DestroyFifoQueue(pFifoInfoT fifoQue){
  BEGIN_FUNCTION("DestroyFifoQueue");
  ResCodeT rc;
  int key;
  int index;
  int searchIndex;
  
  key = fifoQue->key;
  //printf("in Destroy, the key is :%d\n",key);
  // find the corresponding element in SHM local address array.
  for (index = 0;index < MAX_QUEUE_NUMBER;index++){
    if (gAddrInfo[index].key == key){
	  searchIndex = index;
      break;
	}
  }
  
  //printf("in Destroy, the searchIndex is :%d\n",searchIndex);
  
  if (shmdt(gAddrInfo[searchIndex].shm) == -1){
    // shared memory detach failed
	THROW_RESCODE(ERR_QUEUE_DESTROY_FAILURE)
  }
  
  if (shmctl(gAddrInfo[searchIndex].shmid,IPC_RMID,0) == -1){
    // shared memory detach failed
	THROW_RESCODE(ERR_QUEUE_DESTROY_FAILURE)
  }

  // initiate the corresponding element in quemeManager
  fifoQue->key = QUEUE_POOL_NULL_KEY;
  fifoQue->shmid = -1;
  fifoQue->getP =0;
  fifoQue->putP = 0;
  fifoQue->size = 0;
  fifoQue->node_size = 0;
  fifoQue->free = 0;
  
  // initiate the corresponding element in SHM local address array.
  gAddrInfo[searchIndex].key = QUEUE_POOL_NULL_KEY;
  gAddrInfo[searchIndex].shmid = -1;
  gAddrInfo[searchIndex].shm = NULL;
  
  EXIT_BLOCK()
  RETURN_RESCODE
}


ResCodeT GetStatusOfFifoQueue(pFifoInfoT fifoQue){
  BEGIN_FUNCTION("GetStatusOfFifoQueue");
  ResCodeT rc;
  
  if (fifoQue->free == 0){
    // The Queue is full
	THROW_RESCODE(ERR_QUEUE_IS_FULL)
  }
  
  if (fifoQue->free == fifoQue->size){
    // The Queue is empty
	THROW_RESCODE(ERR_QUEUE_IS_EMPTY)
  }

  EXIT_BLOCK()
  RETURN_RESCODE
}


