#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>

void  shmCreate(char** shmHandle, int id ,int size)
{
    int shmid;
    char* shm;

    shmid = shmget((key_t)id, size, 0666|IPC_CREAT);
    shm = shmat(shmid, (void*)0, 0);
    *shmHandle = (char*)shm;
}

void  shmRead(char* shmHandle, int index, int recordSize, char* record)
{
    char* shmTmp;
    shmTmp = shmHandle + index;
    memcpy(record, shmTmp ,  recordSize);
}

void  shmWrite(char* shmHandle, int index, int recordSize, char* record)
{
   char* shmTmp;
   shmTmp = shmHandle + index; 
   memcpy(shmTmp , record,  recordSize);
}

/*
int main()
{
  char*  shm;
  char*  shmTmp;
  int id = 12;
  int i = 100;
  int k = 101;

  int j = 0;
  int shmid;

  shmCreate(&shm, 1234, sizeof(int) * 2);

  shmTmp= (int*)shm + 1; 
  shmWrite(shm,0,sizeof(int), &i);
  shmWrite(shmTmp,0,sizeof(int), &k);

  shmRead(shm,0,sizeof(int), &j);
  printf("result1: %d\n", j);
  j= 0;
  
  shmRead(shmTmp,0,sizeof(int), &j);
  printf("result2: %d\n", j);

    return 0;

}
*/