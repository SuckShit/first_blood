/******************************************************************************
 **
 ** Header File
 ** 
******************************************************************************/
/* Standard C header files */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

/* Project related header files */
#include "../header/ipclib.h"
#include "../header/errlib.h"



/******************************************************************************
 **
 ** Function Implementation
 ** 
******************************************************************************/
ResCodeT IPCCreate(const char *fifoname,mode_t mode){

  BEGIN_FUNCTION("IPCCreate");
  ResCodeT rc;

  if( access(fifoname, F_OK) == -1)
  {
    if (rc=mkfifo(fifoname,mode) < 0){
        if (errno == EEXIST){
	      //File already exist
	      THROW_RESCODE(ERR_PIPE_FILE_ALREADY_EXIST)
	    }
	
	// Named Pipe creation failed.
	THROW_RESCODE(ERR_PIPE_FILE_CREATE_FAILURE)
    }
  }
  EXIT_BLOCK()
  RETURN_RESCODE
}

ResCodeT IPCOpen(const char *fifoname,int mode,int block,int* fd){

  BEGIN_FUNCTION("IPCOpen");
  
  if (mode == FIFO_OPEN_FOR_READ){
    if (block == FIFO_BLOCK_MODE){
	  *fd = open(fifoname,O_RDWR);
	}else{
	  *fd = open(fifoname,O_RDWR|O_NONBLOCK);
	}
  } else {
    if (block == FIFO_BLOCK_MODE){
	  *fd = open(fifoname,O_RDWR);
	}else{
	  *fd = open(fifoname,O_RDWR|O_NONBLOCK);
	}
  }
  
  if (*fd < 0){
    //Named Pipe open failed
	if (mode == FIFO_OPEN_FOR_READ){
	  THROW_RESCODE(ERR_PIPE_FOR_READ_OPEN_FAILURE)
	} else {
	  THROW_RESCODE(ERR_PIPE_FOR_WRITE_OPEN_FAILURE)
	}
  }
  
  EXIT_BLOCK()
  RETURN_RESCODE
}


ResCodeT IPCSend(int fd,const void *buffer,int size){

  BEGIN_FUNCTION("IPCSend");
  ResCodeT rc;
  
  if (write(fd,buffer,size) < 0){
    //write error
	THROW_RESCODE(ERR_PIPE_WRITE_DATA_ERROR)
  }
  
  EXIT_BLOCK()
  RETURN_RESCODE
}

ResCodeT IPCReceive(int fd,void *buffer,int size){

  BEGIN_FUNCTION("IPCReceive");
  
  //memset(buffer,0,size);
  int32 readLen = read(fd,buffer,size);
  if ( readLen< 0){
    //read error
    
    if  (errno == EAGAIN)
    {
    		THROW_RESCODE(ERR_PIPE_READ_NO_DATA);
   	}
		THROW_RESCODE(ERR_PIPE_READ_DATA_ERROR)
  }
  if  (readLen == 0)
  {
 			THROW_RESCODE(ERR_PIPE_READ_NO_DATA);
  }
  EXIT_BLOCK()
  RETURN_RESCODE
}

ResCodeT IPCClose(int fd){

  BEGIN_FUNCTION("IPCClose");
    
  close(fd);
  
  EXIT_BLOCK()
  RETURN_RESCODE
}