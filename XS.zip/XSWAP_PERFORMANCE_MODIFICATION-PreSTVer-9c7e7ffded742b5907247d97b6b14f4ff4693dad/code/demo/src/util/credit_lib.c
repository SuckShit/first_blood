/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "../header/shm.h"
#include "../header/credit_lib.h"
#include "../header/ipclib.h"
#include "../header/hash_table.h"
#include "../db_header/t_crdt_mgnr.h"
#include "../header/dbhelp.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static   int32  gOutQHndl;
static   int32	gInQHndl;
HashTableT gHashTable;
char*   gpCrditShm;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT CreateCreditHashTable()
{
    BEGIN_FUNCTION( "CreateCreditHashTable" );
		    ResCodeT rc = NO_ERR;
	TCrdtMgnr  TotalCreditInfo[10000];
	TCrdtMgnr*  pTmp;
	int32  CreditCnt = 0;
	int32  ErrCode;
	int32  Cnt;
	char Key1[10];
	char Key2[10];
	char Key[20];
	TCrdtMgnr * tmpHdl = NULL;
	
	//授信内存构造
	rc = DbTCrdtMgnrGetAll(&TotalCreditInfo[0], &CreditCnt, &ErrCode);
		RAISE_ERROR( rc, RTN );

	shmCreate((void *)&gpCrditShm, SHM_MEM_CREDIT_ID, CreditCnt * sizeof(TCrdtMgnr));

	rc = HashTableCreate(10000, &gHashTable);
		RAISE_ERROR( rc, RTN );
	
	tmpHdl = (TCrdtMgnr*)gpCrditShm;
	pTmp = &TotalCreditInfo[0];
	for(Cnt =0; Cnt< CreditCnt; Cnt++)
	{
		memset(Key1,0,10);
		memset(Key2,0,10);
		memset(Key,0,20);

		sprintf(Key1,"%d-", pTmp->crdt_org_id);
		sprintf(Key2,"%d", pTmp->crdtd_org_id);
		strcpy(Key,Key1);
		strcat(Key,Key2);
		
		memcpy(tmpHdl,pTmp, sizeof(TCrdtMgnr));
		
		rc = hashTableInsertNode(&gHashTable, Key, Cnt);
		RAISE_ERROR( rc, RTN );
		
		pTmp++;
		tmpHdl++;
	}
	
	EXIT_BLOCK();
    RETURN_RESCODE;;
}

static ResCodeT CallCmServices (void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "CallCmServices" );
		    ResCodeT rc = NO_ERR;
		rc = IPCSend(gOutQHndl,pData,dataLen);
		RAISE_ERROR( rc, RTN );
		TRACE("Send to CM " );
		rc = IPCReceive(gInQHndl,pData,dataLen);
		RAISE_ERROR( rc, RTN );
		TRACE("Get from CM " );
    EXIT_BLOCK();
    RETURN_RESCODE;;
}


ResCodeT CrdtLibInit (BOOL bIsCmFlg)
{
    BEGIN_FUNCTION( "CrdtLibInit" );
        ResCodeT rc = NO_ERR;
    if (bIsCmFlg)
    {
    		rc =  CrdtLibInitForCm ();
				RAISE_ERROR( rc, RTN );
   	}
   	else
		{
				rc =  CrdtLibInitForMatcher ();
				RAISE_ERROR( rc, RTN );
		}

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT CrdtLibInitForCm ()
{
    BEGIN_FUNCTION( "CrdtLibInitForCm" );
		    ResCodeT rc = NO_ERR;
		rc = IPCOpen(IPC_CM_2_MATCH,FIFO_OPEN_FOR_WRITE,FIFO_BLOCK_MODE,&gOutQHndl);
		RAISE_ERROR( rc, RTN );
		TRACE("CM Open Send %s Done" $$ IPC_CM_2_MATCH);
	
		rc = IPCOpen(IPC_MATCH_2_CM,FIFO_OPEN_FOR_READ,FIFO_BLOCK_MODE,&gInQHndl);
		RAISE_ERROR( rc, RTN );
		TRACE("CM  Open Read %s Done" $$ IPC_MATCH_2_CM);
   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT CrdtLibInitForMatcher ()
{
    BEGIN_FUNCTION( "CrdtLibInitForMatcher" );
		    ResCodeT rc = NO_ERR;
		rc = IPCOpen(IPC_CM_2_MATCH,FIFO_OPEN_FOR_READ,FIFO_BLOCK_MODE,&gInQHndl);
		RAISE_ERROR( rc, RTN );
		TRACE("Open Read %s Done" $$ IPC_CM_2_MATCH);
	
		rc = IPCOpen(IPC_MATCH_2_CM,FIFO_OPEN_FOR_WRITE,FIFO_BLOCK_MODE,&gOutQHndl);
		RAISE_ERROR( rc, RTN );
		TRACE("Open Send %s Done" $$ IPC_MATCH_2_CM);

   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}


ResCodeT CrdtLibCheckRemoteCrdtInfo (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibCheckRemoteCrdtInfo" );
		    ResCodeT rc = NO_ERR;
		pReqCrdt->msgType = MSG_TYPE_CHECK;
		
		TRACE("Send get request %lld - %lld " $$ pReqCrdt->crdtEntyNo $$ pReqCrdt->trgtEntyNo);
		rc = CallCmServices(pReqCrdt,sizeof(CrdtMsgT));
		RAISE_ERROR( rc, RTN );
		TRACE("Get %lld-%lld-%lld " $$ pReqCrdt->totalCrdtAmnt $$ pReqCrdt->usdCrdtAmnt $$ pReqCrdt->avaCrdtAmnt);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT CrdtLibCheckLocalCrdtInfo (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibCheckLocalCrdtInfo" );
		    ResCodeT rc = NO_ERR;
		//todo get from memory
		TCrdtMgnr  CreditInfo;
		HashNodeT Node;
		TCrdtMgnr * tmpHdl;
		char Key1[10];
		char Key2[10];
		char Key[20];

		memset(Key1,0,10);
		memset(Key2,0,10);
		memset(Key,0,20);

		//makeup hashkey 
		sprintf(Key1,"%d-", pReqCrdt->crdtEntyNo);
		sprintf(Key2,"%d", pReqCrdt->trgtEntyNo);

		strcpy(Key,Key1);
		strcat(Key,Key2);

		//using hashkey,find the shm index
		rc = hashTableLookUp(&gHashTable, Key, &Node);
		if(NOTOK(rc))
		{
			pReqCrdt->totalCrdtAmnt = 0;
			pReqCrdt->usdCrdtAmnt = 0;
			pReqCrdt->avaCrdtAmnt= 0;
			TRACE("hashTableLookUp NOT FOUND ");
			 THROW_RESCODE(rc);
		}
		
		//using shm index,get the credit information
		tmpHdl = (TCrdtMgnr*)gpCrditShm;
		tmpHdl = tmpHdl + Node.nValue;
		memcpy(&CreditInfo,tmpHdl, sizeof(TCrdtMgnr));

		pReqCrdt->totalCrdtAmnt = tmpHdl->intl_crdt_amnt;
		pReqCrdt->usdCrdtAmnt = tmpHdl->used_crdt_amnt;
		pReqCrdt->avaCrdtAmnt= tmpHdl->rmn_crdt_amnt;
		
		pReqCrdt->rtnCode = NO_ERR;
		
		TRACE("Get SHM %lld-%lld-%lld " $$ pReqCrdt->totalCrdtAmnt $$ pReqCrdt->usdCrdtAmnt $$ pReqCrdt->avaCrdtAmnt);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT CrdtLibUpdateLocalCrdtInfo (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibUpdateLocalCrdtInfo" );
		    ResCodeT rc = NO_ERR;
		//todo update memory
		TCrdtMgnr  CreditInfo;
		HashNodeT Node;
		int32  ErrCode;
		TCrdtMgnr * tmpHdl;
		char Key1[10];
		char Key2[10];
		char Key[20];
		static int64 cnt = 0;

		memset(Key1,0,10);
		memset(Key2,0,10);
		memset(Key,0,20);

		//makeup hashkey 
		sprintf(Key1,"%d-", pReqCrdt->crdtEntyNo);
		sprintf(Key2,"%d", pReqCrdt->trgtEntyNo);
		strcat(Key,Key1);
		strcat(Key,Key2);		
		
		TRACE("Looking for key %10s " $$ Key );


		//using hashkey,find the shm index
		rc = hashTableLookUp(&gHashTable, Key, &Node);
			RAISE_ERROR( rc, RTN );
		
		//using shm index,update the credit information
		tmpHdl = (TCrdtMgnr*)gpCrditShm + Node.nValue;
		//tmpHdl->intl_crdt_amnt = pReqCrdt->totalCrdtAmnt;
		tmpHdl->used_crdt_amnt = tmpHdl->used_crdt_amnt + pReqCrdt->avaCrdtAmnt;
		tmpHdl->rmn_crdt_amnt = tmpHdl->rmn_crdt_amnt - pReqCrdt->avaCrdtAmnt;

#ifndef TEST_APP        
		//sql prepare
		rc = DbTCrdtMgnrPrepareUpdate();
			RAISE_ERROR( rc, RTN );

		//sql execute	
		rc = DbTCrdtMgnrUpdate(tmpHdl, &ErrCode);
			RAISE_ERROR( rc, RTN );
		
		cnt++;
		
		
		if (cnt == 500)
		{
			cnt = 0;
			DbCommit(&ErrCode);
			RAISE_ERROR( rc, RTN );
		}

		//commit
		
#endif
		pReqCrdt->rtnCode = NO_ERR;
		
		TRACE("Update SHM&DB %lld-%lld-%lld " $$ tmpHdl->intl_crdt_amnt $$ tmpHdl->used_crdt_amnt $$ tmpHdl->rmn_crdt_amnt);

    EXIT_BLOCK();
    if(OK(GET_RESCODE()))
    {
    		
   	}
    RETURN_RESCODE;;
}


ResCodeT CrdtLibReadReq (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibReadReq" );
		    ResCodeT rc = NO_ERR;
		rc = IPCReceive(gInQHndl,pReqCrdt,sizeof(CrdtMsgT));
		RAISE_ERROR( rc, RTN );
		TRACE("Get from Matcher %lld " $$  sizeof(CrdtMsgT));
		
    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT CrdtLibSendRsp (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibSendReq" );
		    ResCodeT rc = NO_ERR;
		rc = IPCSend(gOutQHndl,pReqCrdt,sizeof(CrdtMsgT));
		RAISE_ERROR( rc, RTN );
		TRACE("Send to Matcher %lld " $$  sizeof(CrdtMsgT));
		
    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT CrdtLibPrcsReq (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibCheckRemoteCrdtInfo" );
		    ResCodeT rc = NO_ERR;
		TRACE("Get Msg Tyep %lld " $$ pReqCrdt->msgType);
		if (pReqCrdt->msgType == MSG_TYPE_CHECK)
		{		
			 	rc = CrdtLibCheckLocalCrdtInfo (pReqCrdt);
			 	if (rc == ERR_MSG_HASHTABLE_NOT_FOUND)
				{
					SET_RESCODE(NO_ERR);
				}
				else
				{
					RAISE_ERROR( rc, RTN );
				}
		}
		else if (pReqCrdt->msgType == MSG_TYPE_UPDATE)
		{
			 	rc = CrdtLibUpdateLocalCrdtInfo (pReqCrdt);
			 	RAISE_ERROR( rc, RTN );
		}

    EXIT_BLOCK();
    RETURN_RESCODE;;
}


ResCodeT CrdtLibUpdtRemoteCrdtInfo (pCrdtMsgT pReqCrdt)
{
    BEGIN_FUNCTION( "CrdtLibUpdtRemoteCrdtInfo" );
    ResCodeT rc = NO_ERR;
		
		pReqCrdt->msgType = MSG_TYPE_UPDATE;
		
		TRACE("Send get request %lld - %lld " $$ pReqCrdt->crdtEntyNo $$ pReqCrdt->trgtEntyNo);
		rc = CallCmServices(pReqCrdt,sizeof(CrdtMsgT));
		RAISE_ERROR( rc, RTN );
		TRACE("Get %lld-%lld-%lld " $$ pReqCrdt->totalCrdtAmnt $$ pReqCrdt->usdCrdtAmnt $$ pReqCrdt->avaCrdtAmnt);

    EXIT_BLOCK();
    RETURN_RESCODE;;
}


