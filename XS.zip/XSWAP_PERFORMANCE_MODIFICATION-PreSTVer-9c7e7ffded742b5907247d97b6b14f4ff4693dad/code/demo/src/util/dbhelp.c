/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */

/* Project Header File*/
#include "../header/dbhelp.h"
#include "../header/common_macro.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/



/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static OCI_Connection *gpCnn = NULL;
static BOOL           gDbInit = FALSE;
static OCI_Statement * gStmt = NULL;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
void Db_errhandler(OCI_Error *err)
{
    //TRACE("Init oci library err");
}

ResCodeT DbInit(char *pAddr, char *pUser, char *pPasswd)
{
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION( "DbInit" );
    ASSERT( pAddr && pUser && pPasswd );
    
    if(!OCI_Initialize(Db_errhandler, NULL, OCI_ENV_DEFAULT | OCI_ENV_CONTEXT))
    {
        TRACE("init oci err");
        
        RAISE_ERROR( ERR_DB_OCI_INIT_ERR, RTN );
    }
    
    gpCnn = OCI_ConnectionCreate(pAddr, pUser, pPasswd, OCI_SESSION_DEFAULT);
    if(gpCnn == NULL)
    {
        TRACE("create oci connection err");
        
        RAISE_ERROR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    
    gStmt = OCI_StatementCreate(gpCnn);
    if(gStmt == NULL)
    {
        TRACE("create statement err");
        
        RAISE_ERROR( ERR_DB_OCI_CONN_ERR, RTN );
    }
    gDbInit = TRUE;
    
    EXIT_BLOCK();
    rc = GET_RESCODE();
    if(NOTOK(rc))
    {
        if(gpCnn != NULL)
        {
            OCI_ConnectionFree(gpCnn);
            gpCnn = NULL;
        }

        OCI_Cleanup();
    }
    RETURN_RESCODE;
}/* End of DbInit */

ResCodeT DbDestroy()
{
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION( "DbDestroy" );
    
	if(gStmt != NULL)
	{
		OCI_StatementFree(gStmt);
		gStmt = NULL;
	}
	
    if(gpCnn != NULL)
    {
        OCI_ConnectionFree(gpCnn);
        gpCnn = NULL;
    }
    
    OCI_Cleanup();
    
    gDbInit = FALSE;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of DbDestroy */

ResCodeT DbExecutCmd(char *pSql, int32 *pErrCode)
{
    ResCodeT rc = NO_ERR;
    OCI_Statement *pState = NULL;
    
    BEGIN_FUNCTION( "DbExecutCmd" );
    
    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }
    
    pState = OCI_StatementCreate(gpCnn);
    if(pState == NULL)
    {
        RAISE_ERROR(ERR_DB_OCI_CREATE_STATE_ERR, RTN);
    }
    
    if(!OCI_Prepare(pState, pSql))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_Execute(pState))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    OCI_StatementFree(pState);
    pState = NULL;
    
    EXIT_BLOCK();
    rc = GET_RESCODE();
    if(NOTOK(rc))
    {
        if(pState != NULL)
        {
            OCI_StatementFree(pState);
            pState = NULL;
        }
    }
    RETURN_RESCODE;
}/* End of DbExecutCmd */

ResCodeT DbExecutCmdBlob(char *pSql, otext* blobName, OCI_Lob * blobData , void* pData, unsigned int lengthOfLob, int32 *pErrCode)
{
    ResCodeT rc = NO_ERR;
    OCI_Statement *pState = NULL;

    BEGIN_FUNCTION( "DbExecutCmd" );

    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }

    pState = OCI_StatementCreate(gpCnn);
    if(pState == NULL)
    {
        RAISE_ERROR(ERR_DB_OCI_CREATE_STATE_ERR, RTN);
    }

    if(!OCI_Prepare(pState, pSql))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }

    //blobData=OCI_LobCreate(gpCnn,OCI_BLOB);
    //OCI_LobWrite(blobData,pData,lengthOfLob);

    if(!OCI_BindString(pState, blobName, pData,lengthOfLob))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }

    if(!OCI_Execute(pState))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }

    OCI_StatementFree(pState);
    pState = NULL;

    EXIT_BLOCK();
    rc = GET_RESCODE();
    if(NOTOK(rc))
    {
        if(pState != NULL)
        {
            OCI_StatementFree(pState);
            pState = NULL;
        }
    }
    RETURN_RESCODE;
}/* End of DbExecutCmd */


ResCodeT DbExecutCmdByBind(int32 *pErrCode)
{
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION( "DbExecutCmdByBind" );
    
    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }
    
    if(!OCI_Execute(gStmt))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of DbExecutCmdByBind */


ResCodeT DbExePrepare(OCI_Connection ** ppCn, OCI_Statement ** ppStmt, char *pSql)
{
    ResCodeT rc = NO_ERR;
    
    BEGIN_FUNCTION( "DbExePrepare" );
    
    if(!OCI_Prepare(gStmt, pSql))
    {
        RAISE_ERROR(OCI_ErrorGetOCICode(OCI_GetLastError()), RTN);
    }
    
    * ppCn = gpCnn;
   	* ppStmt = gStmt;
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of DbExeQuery */

ResCodeT DbExeQuery(char *pSql, void *pData, void *pDes, int32 *pErrCode)
{
    ResCodeT rc = NO_ERR;
    OCI_Statement *pState = NULL;
    OCI_Resultset *PRsSet = NULL;
    
    BEGIN_FUNCTION( "DbExecutCmd" );
    
    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }
    
    pState = OCI_StatementCreate(gpCnn);
    if(pState == NULL)
    {
        RAISE_ERROR(ERR_DB_OCI_CREATE_STATE_ERR, RTN);
    }
    
    if(!OCI_Prepare(pState, pSql))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_Execute(pState))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    PRsSet = OCI_GetResultset(pState);
    if(PRsSet == NULL)
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_FetchNext(PRsSet))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_GetStruct(PRsSet, pData, pDes))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    OCI_StatementFree(pState);
    pState = NULL;
    
    EXIT_BLOCK();
    rc = GET_RESCODE();
    if(NOTOK(rc))
    {
        if(pState != NULL)
        {
            OCI_StatementFree(pState);
            pState = NULL;
        }
    }
    RETURN_RESCODE;
}/* End of DbExeQuery */


ResCodeT DbExeQueryWithNumInfo(void *pData, void *pDes, NumColTypeT *colTypes, int32 numColCnt, int32 *pErrCode)
{
    ResCodeT rc = NO_ERR;
    OCI_Resultset *PRsSet = NULL;
    int index = 0;
	
    BEGIN_FUNCTION( "DbExeQueryWithNumInfo" );
    
    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }
    
    if(!OCI_Execute(gStmt))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }

    PRsSet = OCI_GetResultset(gStmt);
    if(PRsSet == NULL)
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }

	for (index=0;index<numColCnt;index++)
	{
	  OCI_SetStructNumericType(PRsSet, colTypes[index].colIndex, colTypes[index].numType);
	}

    if(!OCI_FetchNext(PRsSet))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }

    if(!OCI_GetStruct(PRsSet, pData, pDes))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
	
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of DbExeQueryWithNumInfo */


ResCodeT DbCommit(int32 *pErrCode)
{
    BEGIN_FUNCTION( "DbCommit" );
    
    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }
    
    if(!OCI_Commit(gpCnn))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of DbCommit */

ResCodeT DbRollback(int32 *pErrCode)
{
    BEGIN_FUNCTION( "DbRollback" );
    
    if(!gDbInit)
    {
        RAISE_ERROR(ERR_DB_OCI_NOT_INIT, RTN);
    }
    
    if(!OCI_Rollback(gpCnn))
    {
        *pErrCode = OCI_ErrorGetOCICode(OCI_GetLastError());
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of DbRollback */


ResCodeT DbBatchInsert( int32 rcrdCnt, int * seqNoArry, int * setIdArry, int * dataTypeArry, char * dataArry, int32 dataSize){

    BEGIN_FUNCTION( "DbBatchInsert" );
    ResCodeT rc = NO_ERR;
    int32    errCode = 0;
    OCI_Statement * pStmt;
    OCI_Connection * pCn;
   

    static char sqlStr[] = "insert into MEM_DATA_1 (SEQUENCE_NO,ASET,DATA_TYPE) values (:seqno,:set,:datatype)";
    
    if(!OCI_Prepare(gStmt, sqlStr))
    {
        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    OCI_Lob   **tab_lob  = OCI_LobArrayCreate(pCn,  OCI_BLOB, rcrdCnt);
    
    TRACE(sqlStr);
    
    if(!OCI_BindArraySetSize(gStmt, rcrdCnt))
    {
        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        printf("OCI_BindArraySetSize");
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_BindArrayOfInts(gStmt, ":seqno", (int *)seqNoArry, 0))
    {
        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        printf("OCI_BindArrayOfInts  seqno");
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_BindArrayOfInts(gStmt, ":set", (int *)setIdArry, 0))
    {
        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        printf("OCI_BindArrayOfInts  set");
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
    if(!OCI_BindArrayOfInts(gStmt, ":datatype", (int *)dataTypeArry, 0))
    {
        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        printf("OCI_BindArrayOfInts  datatype");
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
    
     OCI_Error      *err;
    if(!OCI_Execute(gStmt))
    {
        printf("Number of DML array errors : %d\n", OCI_GetBatchErrorCount(gStmt));

        err = OCI_GetBatchError(gStmt);

        while (err)
        {
            printf("Error at row %d : %s\n", OCI_ErrorGetRow(err), OCI_ErrorGetString(err));

            err = OCI_GetBatchError(gStmt);
        }
    }

    printf("row inserted : %d\n", OCI_GetAffectedRows(gStmt));
    
    if(!OCI_Commit(gpCnn))
    {
        TRACE(OCI_ErrorGetString(OCI_GetLastError()));
        printf("OCI_Commit");
        RAISE_ERROR(ERR_DB_OCI_EXE_ERR, RTN);
    }
		;
			
    TRACE("Row inserted : %u" && OCI_GetAffectedRows(gStmt));
//		
//		 /* free objects */
//    OCI_LobArrayFree(tab_lob);
//    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
