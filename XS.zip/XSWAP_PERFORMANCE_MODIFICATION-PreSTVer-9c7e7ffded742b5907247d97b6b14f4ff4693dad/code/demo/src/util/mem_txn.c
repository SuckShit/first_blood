/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "../header/msg_cache.h"
#include "../header/mem_txn.h"
#include "../header/shm.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define TXN_STS_OPEN      1
#define TXN_STS_COMMIT    2

#define GET_TXN_ENTY_BY_ID( _txnId_) \
    ADDRESS_ADD_OFFSET(gTxnAccess.pEntryRoot, sizeof(MemTxnEntryT) * ((_txnId_) -1))

#define GET_TXN_DATA_BY_SLOT( _SlotId_)\
    ADDRESS_ADD_OFFSET(gTxnAccess.pDataRoot, (sizeof(MemTxnDataHdrT) + gTxnAccess.pDataCtrl->dataSize)* (_SlotId_))

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MemTxnAccessS
{
    int32               setId;
    pMemTxnCtrlT        pTxnCtrl;
    pMemTxnEntryT       pEntryRoot;
    
    pMemTxnDataCtrlT    pDataCtrl;
    pMemTxnDataHdrT     pDataRoot;

} MemTxnAccessT, *pMemTxnAccessT;


/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static MemTxnAccessT gTxnAccess = {0};
static int64 gTimestamp = 19000000;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT ShmFreeSlot(ShmHandleT handle, ShmSlotIdT slot);

/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT MemTxnShmCreate (int32 totVolumn, int32 dataSize)
{
    BEGIN_FUNCTION( "MemTxnShmCreate" );
    int64 memTxnAreaSize = 0;
    int64 setTxnAreaSize = 0;
    int64 memDataAreaSize =0;
    int64 setDataAreaSize = 0;
    void * pRoot;
    void * pTxnAreaRoot;
    void * pDataAreaRoot;
    pMemTxnCtrlT pCurrCtrl; 
    pMemTxnDataCtrlT pCurrDataCtrl;
        
    /*Calcuate Memory txn area size*/
    /* create memeory txn are for each set, each one will have one control area and mutiple entry record. */
    setTxnAreaSize = sizeof(MemTxnCtrlT) + ( totVolumn * sizeof(MemTxnEntryT));   

    memTxnAreaSize = setTxnAreaSize * MAX_SET_CNT;
    
    /*Calcuate Memory data area size*/
    /* create memeory data are for each set,  each one will have one control area and mutiple entry record.. */
    setDataAreaSize = sizeof(MemTxnDataCtrlT) + (totVolumn * (sizeof(MemTxnDataHdrT) + dataSize));
    memDataAreaSize = setDataAreaSize * MAX_SET_CNT;
    
    
    shmCreate((char **)&pRoot, SHM_MEM_TXN_ID ,memTxnAreaSize + memDataAreaSize);
   
    
    pTxnAreaRoot = pRoot;
    pCurrCtrl = pTxnAreaRoot;
    
    pDataAreaRoot = (void *)ADDRESS_ADD_OFFSET( pCurrCtrl, memTxnAreaSize);
    pCurrDataCtrl = pDataAreaRoot;
    int32 i = 0;
    for (i=0; i<MAX_SET_CNT; i++)
    {
        pCurrCtrl->maxTxnId = totVolumn;
        pCurrCtrl->currTxnId = 0;
        pCurrCtrl->commitTxnId = 0;
        pCurrCtrl = (pMemTxnCtrlT)ADDRESS_ADD_OFFSET( pCurrCtrl, setTxnAreaSize);
        
        pCurrDataCtrl->dataSize = dataSize;
        pCurrDataCtrl->dataTtlCnt = totVolumn;
        pCurrDataCtrl = (pMemTxnDataCtrlT)ADDRESS_ADD_OFFSET( pCurrDataCtrl, setDataAreaSize);
    }
   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}


ResCodeT MemTxnShmAttach(int32 set)
{
    BEGIN_FUNCTION( "MemTxnShmAttach" );
    int64 memTxnAreaSize = 0;
    int64 setTxnCrtlOffset = 0;
    int64 memDataAreaSize =0;
    int64 setDataAreaSize = 0;
    void * pRoot;
    pMemTxnCtrlT pTxnAreaRoot;
    pMemTxnDataCtrlT pDataAreaRoot;
    int64 totalCnt; 
    pMemTxnCtrlT pCurrCtrl, pRootCtrl; 
    pMemTxnDataCtrlT pCurrDataCtrl;
    
    //attach share memory, and get root
    shmCreate((char **)&pRoot, SHM_MEM_TXN_ID ,0);
    
    gTxnAccess.setId = set;
    
    pRootCtrl = (pMemTxnCtrlT)pRoot;
    totalCnt = pRootCtrl->maxTxnId;
    
    setTxnCrtlOffset = sizeof(MemTxnCtrlT) + (totalCnt * sizeof(MemTxnEntryT));
    memTxnAreaSize = setTxnCrtlOffset * MAX_SET_CNT;
    
    gTxnAccess.pTxnCtrl = (pMemTxnCtrlT)ADDRESS_ADD_OFFSET(pRoot, setTxnCrtlOffset * (set-1));
    gTxnAccess.pEntryRoot = (pMemTxnEntryT)ADDRESS_ADD_OFFSET(gTxnAccess.pTxnCtrl, sizeof(MemTxnCtrlT));
    
    pDataAreaRoot = (pMemTxnDataCtrlT)ADDRESS_ADD_OFFSET(pRoot, memTxnAreaSize);
    
    setDataAreaSize = sizeof(MemTxnDataCtrlT) + (totalCnt * (sizeof(MemTxnDataHdrT) + pDataAreaRoot->dataSize));
    
    gTxnAccess.pDataCtrl = (pMemTxnDataCtrlT)ADDRESS_ADD_OFFSET(pDataAreaRoot, setDataAreaSize * (set-1));
    gTxnAccess.pDataRoot = (pMemTxnDataHdrT)ADDRESS_ADD_OFFSET(gTxnAccess.pDataCtrl, sizeof(MemTxnDataCtrlT));
   
    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT MemTxnStart(int64* pTxnId, int64 * pTimestamp)
{
    BEGIN_FUNCTION( "MemTxnStart" );
    pMemTxnEntryT pTxnEntry = NULL;
    
    
    * pTimestamp = gTimestamp++;
    
    gTxnAccess.pTxnCtrl->currTxnId = gTxnAccess.pTxnCtrl->commitTxnId+1;
    
    * pTxnId = gTxnAccess.pTxnCtrl->currTxnId;
    
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(gTxnAccess.pTxnCtrl->currTxnId);

    pTxnEntry->txnId = gTxnAccess.pTxnCtrl->currTxnId;
    pTxnEntry->txnSts = TXN_STS_OPEN;
    pTxnEntry->dataCnt = 0;   
    
    pTxnEntry->frstDataSqno = SHM_NO_SLOT;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MemTxnCommit()
{
    BEGIN_FUNCTION( "MemTxnCommit" );
    pMemTxnEntryT pTxnEntry = NULL;
    ResCodeT rc = NO_ERR;
    
   
    pTxnEntry = (pMemTxnEntryT)GET_TXN_ENTY_BY_ID(gTxnAccess.pTxnCtrl->currTxnId);
    if (pTxnEntry->txnId != gTxnAccess.pTxnCtrl->currTxnId )
    {
       RAISE_ERROR( rc, RTN); 
    }
    gTxnAccess.pTxnCtrl->commitTxnId =gTxnAccess.pTxnCtrl->currTxnId;
    pTxnEntry->txnSts = TXN_STS_COMMIT;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT MemReadTxnData(int32 txnId, int32 * pDataType, void ** ppData, int32 * pDataLen,int64 *pCursor)
{
    BEGIN_FUNCTION( "MemReadTxnData" );
    ResCodeT rc = NO_ERR;
    pMemTxnDataHdrT pTxnDataHdr = NULL;
    int64 tempCursor = 0;
    pMemTxnEntryT pTxnEntry = NULL;
        
    void * pDataAddr = NULL;
    
    if (txnId > gTxnAccess.pTxnCtrl->maxTxnId)
    {
        RAISE_ERROR( ERR_EXCEED_MAX_TXN_ID, RTN); 
    }

    pTxnEntry = (pMemTxnEntryT) GET_TXN_ENTY_BY_ID(txnId);
    
    if (pTxnEntry->dataCnt == 0)
    {
    	 THROW_RESCODE( ERR_MSG_NOT_FOUND ); 
    }
       
    if (*pCursor == 0) /* Start from the begining */
    {
        pTxnDataHdr = (pMemTxnDataHdrT)GET_TXN_DATA_BY_SLOT(pTxnEntry->frstDataSqno);
        
    }
    else
    {
    	
    		if (*pCursor == TXN_ID_NO_SQNO)
        {
            THROW_RESCODE( ERR_MSG_NOT_FOUND ); //end of txn
        }
        pTxnDataHdr = (pMemTxnDataHdrT)GET_TXN_DATA_BY_SLOT(*pCursor);
    }
    
    tempCursor = pTxnDataHdr->nextDataSqno;
    
    
    
    pDataAddr = (void *)ADDRESS_ADD_OFFSET(pTxnDataHdr, sizeof(MemTxnDataHdrT));
    
    * ppData = pDataAddr;
    * pDataLen = pTxnDataHdr->dataLen;
    * pDataType = pTxnDataHdr->dataType;
    *pCursor = tempCursor;
    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT MemTxnGetTxnEnty(int32 txnId, pMemTxnEntryT pTxnEntry)
{
    BEGIN_FUNCTION( "MemTxnGetTxnEnty" );
    ResCodeT rc = NO_ERR;
    pMemTxnEntryT pTmpTxnEntry = NULL;
        
 		

    pTmpTxnEntry = (pMemTxnEntryT) GET_TXN_ENTY_BY_ID(txnId);
    
    memcpy(pTxnEntry, pTmpTxnEntry, sizeof(MemTxnEntryT));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MemTxnGetTxnCtrl(pMemTxnCtrlT pTxnCtrl)
{
    BEGIN_FUNCTION( "MemTxnGetTxnCtrl" );
    ResCodeT rc = NO_ERR;
    pMemTxnCtrlT pTmpTxnCtrl = NULL;

    memcpy(pTxnCtrl, gTxnAccess.pTxnCtrl, sizeof(MemTxnCtrlT));

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MemTxnAddData(int32 dataType, void * pData, int32 dataLen)
{
    BEGIN_FUNCTION( "MemTxnAddData" );
    ResCodeT rc = NO_ERR;
    pMemTxnDataHdrT pTxnDataHdr = NULL;
    void * pDataAddr = NULL;
    pMemTxnEntryT pTxnEntry = NULL;
    
    pTxnDataHdr = (pMemTxnDataHdrT)GET_TXN_DATA_BY_SLOT(gTxnAccess.pDataCtrl->nextDataSlot);
    
    pDataAddr = (void *)ADDRESS_ADD_OFFSET(pTxnDataHdr, sizeof(MemTxnDataHdrT));
    
    memcpy(pDataAddr, pData, dataLen);
    
    pTxnDataHdr->dataSqno = gTxnAccess.pDataCtrl->nextDataSlot;
    pTxnDataHdr->dataLen = dataLen;
    pTxnDataHdr->dataType = dataType;
    pTxnDataHdr->nextDataSqno = SHM_NO_SLOT;
    
    pTxnEntry = (pMemTxnEntryT) GET_TXN_ENTY_BY_ID(gTxnAccess.pTxnCtrl->currTxnId);
		if (pTxnEntry->dataCnt == 0)
		{
				pTxnEntry->frstDataSqno = pTxnDataHdr->dataSqno;
		}
    
    pTxnEntry->dataCnt ++;
    
    if (pTxnDataHdr->dataSqno)
		{
				int64 preDataSqno = pTxnDataHdr->dataSqno -1;
				
				pTxnDataHdr = (pMemTxnDataHdrT)GET_TXN_DATA_BY_SLOT(preDataSqno);
    
    		pDataAddr = (void *)ADDRESS_ADD_OFFSET(pTxnDataHdr, sizeof(MemTxnDataHdrT));
    		
    		pTxnDataHdr->nextDataSqno = gTxnAccess.pDataCtrl->nextDataSlot;
				
		}

    gTxnAccess.pDataCtrl->nextDataSlot++;
    gTxnAccess.pDataCtrl->usedSlotCnt++;
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}
