/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <time.h>  
#include <stdarg.h>  
/* Project Header File*/
#include "../header/data_type.h"
#include "../header/errlib.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/


/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/



/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
FILE * fp = NULL;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT RaiseError(const ResCodeT errorCode,const char *fileName,
                    const int lineNo,const char *fctName,const char *sctName,
                    int parmFlag,...)
{
    char errMsg[1024] = {0};
    if(fp == NULL)
    {
        if ((fp=fopen("log.err", "a+")) == NULL)
        {
            printf("Open Error log failed !");
            return ERR_OPEN_ERR_LOG_ERR;
        }
    }
    time_t now;
    struct tm *timenow;
    
    time(&now);
    timenow = localtime(&now);
    
    
    sprintf(errMsg,"%s:%s:%lld:%s Error:%lld\n", asctime(timenow), fileName,lineNo, fctName, errorCode);
    
    fwrite(errMsg,strlen(errMsg),1,fp);
    
    return NO_ERR;
}

ResCodeT TraceLog(char *fileName,int lineNo,char * fctName,char * sctName,char * format, ...)
{
		char tmp[2048+1];
		char buffer[2048+1];
    va_list params;
    va_start(params, format);
    
    vsprintf(tmp, format, params);
    tmp[2048] = '\0';
    snprintf(buffer,2048, "%10.10s %5d %15.15s %s",fileName, lineNo,fctName , tmp );
    buffer[2048] = '\0';
    
    va_end(params);
    printf("%s\n",  buffer);

    return NO_ERR;
}
