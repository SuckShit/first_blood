/***
Created on May 08, 2017

@author: Kong
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include "../header/err_cod.h"

/* Project Header File*/
#include "../header/errlib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "../header/hash_table.h"

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/


/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT HashTableCreate(int size, pHashTableT table)
{
    BEGIN_FUNCTION( "HashTableCreate" );
    ASSERT( table);

	ResCodeT rc = NO_ERR;
	
    table->maxSize = size;
    memset(table->pHead, 0, sizeof(pHashNodeT) * size );

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT HashTableHashValue(char* sKey, unsigned int* value)
{
    BEGIN_FUNCTION( "HashTableCreate" );
    ASSERT(sKey);
    ASSERT(value);

    const unsigned char *p = (const unsigned char*)sKey;
    unsigned int h = *p;
    if(h)
    {
        for(p +=1; *p != '\0'; ++p)
	    h = (h << 5) - h + *p;
    }
	
    *value = h;

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT hashTableInsertNode(pHashTableT table, char* sKey, int nValue)
{
    unsigned int val = 0;

    BEGIN_FUNCTION( "hashTableInsertNode" );
    ASSERT(table);
    ASSERT(sKey);

    HashTableHashValue(sKey, &val);
    unsigned int pos = val % table->maxSize;
    pHashNodeT pHead = table->pHead[pos];
    while(pHead)
    {
         if(strcmp(pHead->sKey,sKey) == 0)
	 {
	     // return  0;
              RAISE_ERROR(ERR_MSG_HASHTABLE_DUPILICATE,RTN );
        }

	 pHead = pHead->pNext;
    }
     
    pHashNodeT pNewNode = (pHashNodeT )malloc(sizeof(HashNodeT));
     memset(pNewNode, 0, sizeof(HashNodeT));
    pNewNode->sKey = (char*)malloc(sizeof(char) * (strlen(sKey)+ 1));
    strcpy(pNewNode->sKey, sKey);
    pNewNode->nValue = nValue;
	   
    pNewNode->pNext = table->pHead[pos];

    table->pHead[pos]= pNewNode;

    EXIT_BLOCK();
    RETURN_RESCODE;
}  
            

ResCodeT hashTableLookUp(pHashTableT table, char* sKey, pHashNodeT node)
{
    unsigned int val;

    BEGIN_FUNCTION( "hashTableLookUp" );
    ASSERT(table);
    ASSERT(sKey);
    ASSERT(node);

    HashTableHashValue(sKey, &val);
    unsigned int pos = val % table->maxSize;

    if(table->pHead[pos])
    {
       pHashNodeT pHead = table->pHead[pos];
	while(pHead)
	{
	   if(strcmp(pHead->sKey,sKey) == 0)
	   {
              memcpy(node, pHead, sizeof(HashNodeT) );

				THROW_RESCODE(NO_ERR);
	   }

          pHead = pHead->pNext;			
    	}
    }

    THROW_RESCODE(ERR_MSG_HASHTABLE_NOT_FOUND);
	
	EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT hashTableRemoveNode(pHashTableT table, char* sKey)
{
    unsigned int val = 0;
    BEGIN_FUNCTION( "hashTableRemoveNode" );
    ASSERT(table);
    ASSERT(sKey);
/*
    HashTableHashValue(sKey, &val);
    unsigned int pos = val % table->maxSize;
    if(table->pHead[pos])
    {
       pHashNodeT pHead = table->pHead[pos];
	   pHashNodeT pLast = NULL;
	   pHashNodeT pRemove = NULL;
       while(pHead)
	{
	   if(strcmp(pHead->sKey,sKey) == 0)
	   {
                pRemove = pHead;
                break;
	   }
            pLast = pHead;
            pHead = pHead->pNext;			
    	}
    }

     if(pRemove)
     {
         if(pLast)
         {
              pLast->pNext = pRemove->pNext;
         }
         else
         {

              table->pHead[pos] = NULL;
         }

     }ELSE
     {
          RAISE_ERROR(ERR_MSG_HASHTABLE_NOT_FOUND, RTN);
     }

 */
    EXIT_BLOCK();
    RETURN_RESCODE;
}

//			  
//int main()
//{
//       HashTable  table;
//	HashNode  node;
//	
//	memset(&table, 0, sizeof(HashTable));	
//	memset(&node, 0, sizeof(HashNode));	
//	
//	HashTableCreate(10000, &table);
//
//	char *key1 = "ss11";
//	char *key2 = "sfs11";
//	char *key3 = "srs11";
//
//	hashTableInsertNode(&table, key1, 1);
//	hashTableInsertNode(&table, key2, 2);
//	hashTableInsertNode(&table, key3, 3);
//	
//	hashTableLookUp(&table, key3, &node);
//	printf("result: %d\n", node.nValue);
//
//	memset(&node, 0, sizeof(HashNode));	 
//	 
//	hashTableLookUp(&table, key1, &node);
//	printf("result2: %d\n", node.nValue);
//
//    return 1;	
//}