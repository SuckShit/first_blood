/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "../header/msg_cache.h"
#include "../header/shm.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define SHM_INFO_COUNT 100

#define SHM_GET_BITMASK(pStart,slot) \
    (((ShmAdminT*)(pStart))->bitMask[(slot)/VECTOR_BASE] & \
    ((vectorT)1 << ((slot) %  VECTOR_BASE)))

#define SHM_GET_ADMIN_SIZE(pStart) \
    ((((ShmAdminT*)(pStart))->elemCount /  VECTOR_BASE)*sizeof(vectorT) \
    + sizeof(ShmAdminT))

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/



/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static ShmInfoT gShmInfo[SHM_INFO_COUNT];
/* The shared memory handle of the Message Cache */
static ShmHandleT          msgCacheHndl;
static uint32 gShmFreeHandle = SHM_FIRST_HANDLE;
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT ShmFreeSlot(ShmHandleT handle, ShmSlotIdT slot);
static ResCodeT ShmAllocateHandle(ShmAdminT * pShm, ShmHandleT * handle,
                                                    uint64 rtnLen );
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

static void ShmSetMask(ShmAdminT* pShm, ShmSlotIdT slot, int value)
{
    BEGIN_FUNCTION( "ShmSetMask" );
    ASSERT( pShm );
    if (!value) /*set bit to 0*/
    {
        pShm->bitMask[slot/VECTOR_BASE] &=  (~((vectorT)1<<(slot%VECTOR_BASE)));
    }
    else        /*set bit to 1*/
    {
        pShm->bitMask[slot/VECTOR_BASE] |=  ((vectorT)1<<(slot%VECTOR_BASE));
    }
    EXIT_BLOCK();
    return;
}

ResCodeT ShmGet(ShmHandleT handle,ShmSlotIdT slot,void** element)
{

    BEGIN_FUNCTION("ShmGet");

    ShmAdminT* pShm;
    /*validate input parameters;*/

    pShm = (ShmAdminT*)gShmInfo[handle].pShm;

    /*check if the given slot is used, here the lock isn't used*/

    *element = gShmInfo[handle].pData + pShm->elemSize*slot;

    EXIT_BLOCK();
    return SHM_NORMAL;

}


static int32 ShmFindNextByte(ShmAdminT * pShm)
{
    BEGIN_FUNCTION( "ShmFindNextByte" );
    ASSERT( pShm );
    int32 len,i;
    if (pShm->firstFreeByte == SHM_NO_SLOT)
    {
        return SHM_NO_SLOT;
    }

    /*Get the length of bit mask array*/
    len = pShm->elemCount/VECTOR_BASE +1 ;
    for(i = pShm->firstFreeByte; i< len; i++)
    {
        if (pShm->bitMask[i] != VECTOR_MAX)
        {
            return i;   /*find the next free byte*/
        }
    }
    EXIT_BLOCK();
    return SHM_NO_SLOT;

}

static ResCodeT MsgGetPairedSlotId( int32             orig,
                                    int32           * paired)
{
    /* Result code */
    ResCodeT result = NO_ERR;
    /* Temp slot entry */
    pMsgCacheSlotT pSlotEntry;

    BEGIN_FUNCTION("MsgGetPairedSlotId");
    ASSERT(paired);

    //memset(&pSlotEntry, 0, sizeof(pMsgCacheSlotT));
    if (orig != SHM_NO_SLOT && orig != 0)
    {
        result = ShmGet(msgCacheHndl, orig, (void *)&pSlotEntry);
        if (result != NO_ERR)
        {
            return result;
        }
        *paired = pSlotEntry->pairedSlotId;
        return NO_ERR;
    }
    else
    {
        return ERR_ARCH_MSG_EMPTY_SLOT_ERR;
    }
    EXIT_BLOCK();
    return NO_ERR;
} /* End of MsgGetPairedSlotId */

ResCodeT MsgDelete         (int32                       slotId)
{
    BEGIN_FUNCTION( "MsgDelete" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    int32 pairedSlotId = SHM_NO_SLOT;

    pMsgCacheSlotT pSlotEntry;

    /* If the input slot ID is not empty, then try to free its paired slot (if
       it has) and the input slot itself, else returns error. */
    TRACE("Try to delete slotId [%d]" $$ slotId);


    if (slotId != SHM_NO_SLOT && slotId != 0)
    {
        /* handle the paired slot */
        result = MsgGetPairedSlotId(slotId, &pairedSlotId);
        if (result == NO_ERR &&
            pairedSlotId != SHM_NO_SLOT)
        {
            /* reset the pairedSlotId value before call ShmFreeSlot */
            result = ShmGet(msgCacheHndl, pairedSlotId, (void *)&pSlotEntry);
            if (NOTOK(result))
            {
                RAISE_ERROR( result, NORTN);
            }
            /* before processing, validate the slots are paired */
            else if (pSlotEntry->pairedSlotId == slotId)
            {
                pSlotEntry->pairedSlotId = SHM_NO_SLOT;
                result = ShmFreeSlot(msgCacheHndl, pairedSlotId);
                if (NOTOK(result))
                {
                    RAISE_ERROR( result, NORTN );
                }
                TRACE("Paired slotId [%d] deleted!" $$ pairedSlotId);
            }
        }

        /* reset the pairedSlotId value before call ShmFreeSlot */
        result = ShmGet(msgCacheHndl, slotId, (void *)&pSlotEntry);
        if (NOTOK(result))
        {
            RAISE_ERROR( result, NORTN );
        }
        else
        {
            pSlotEntry->pairedSlotId = SHM_NO_SLOT;
            result = ShmFreeSlot(msgCacheHndl, slotId);
            if (result != NO_ERR)
            {
                RAISE_ERROR( result, RTN );
            }
            TRACE("SlotId [%d] deleted!" $$ slotId);
        }
    }
    else
    {
        RAISE_ERROR( ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgDelete */

ResCodeT ShmReserveSlot(ShmHandleT handle, ShmSlotIdT* pSlot)
{
    ShmAdminT* pShm;
    int32 rtn = ERR_ARCH_SHM_OVERFLOW;
    BEGIN_FUNCTION("ShmReserveSlot");
    ASSERT( pSlot );

    /*get the pointer to shared memory administration area according to handle*/
    pShm = (ShmAdminT*)gShmInfo[handle].pShm;

    /*get the lock for the specified shared memory;*/
    // if (ShmGetMutexLock(&gShmInfo[handle].mutex_status_block) != SHM_NORMAL)
    // {
    //     /*error handling;*/
    //     RAISE_ERROR_PARM(ERR_ARCH_SHM_SYSTEM, NORTN,
    //                      gShmInfo[handle].secName);
    //     return ERR_ARCH_SHM_SYSTEM;
    // }

    /*get free slot*/
    if ( pShm->firstFreeByte != SHM_NO_SLOT)
    {
        int32 i,index;
        /*find the free bit in the int*/
        for(i=0;i<VECTOR_BASE;i++)
        {
            if (!(pShm->bitMask[pShm->firstFreeByte] & (((vectorT) 1) << i)))
            {
                /*set the bit found to 1*/
                pShm->bitMask[pShm->firstFreeByte] |=   (((vectorT) 1) <<i);
                break;
            }
        }

        /*compute the slot number*/
        *pSlot = pShm->firstFreeByte* VECTOR_BASE + i;
        /*update firstFreeByte to point to next free bit*/
        pShm->firstFreeByte = ShmFindNextByte(pShm);
         pShm->allocatedCount ++;
         rtn = SHM_NORMAL;
   }


    // /*free the lock*/
    // if (ShmFreeMutexLock(&gShmInfo[handle].mutex_status_block) != SHM_NORMAL)
    // {
    //     /*error handling;*/
    //     RAISE_ERROR_PARM(ERR_ARCH_SHM_SYSTEM, NORTN,
    //                      gShmInfo[handle].secName);
    //     return ERR_ARCH_SHM_SYSTEM;
    // }

    EXIT_BLOCK();
    return rtn;

}

ResCodeT MsgRsrvSlot       (int32                    *  pSlotId,
                            pMsgCacheSlotT        *  ppSlot)
{
    BEGIN_FUNCTION( "MsgRsrvSlot" );

    /* Temp result code for reserving. */
    ResCodeT result = NO_ERR;
    ResCodeT rc2    = NO_ERR;

    ShmSlotIdT slotId = SHM_NO_SLOT;

    ASSERT(pSlotId && ppSlot);

    /* Reserve the slot */
    result = ShmReserveSlot(msgCacheHndl, &slotId);
    if (result != NO_ERR)
    {
        RAISE_ERROR( result, RTN );
    }
    TRACE("Single Slot [%d] reserved!" $$ slotId);

    /* Get the slot */
    result = ShmGet(msgCacheHndl, slotId, (void *)ppSlot);
    if (result != NO_ERR)
    {
        rc2 = ShmFreeSlot(msgCacheHndl, slotId);
        RAISE_ERROR( rc2, NORTN );
        RAISE_ERROR( result, RTN );
    }

    (*ppSlot)->pairedSlotId = SHM_NO_SLOT;


    /* Return the pointer to the slot ID. */
    *pSlotId = (int32)slotId;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgRsrvSlot */


ResCodeT ShmCreate(int32  shmId, int32 elemSize, int64 cnt, int32 adminSize, void ** ppRoot , ShmHandleT * handle)
{
    BEGIN_FUNCTION( "ShmCreate" );
    int32 alignAdminSize;

    /* Temp result code */
    ResCodeT result = NO_ERR;
    
    int64 size = sizeof(ShmAdminT) + (cnt/VECTOR_BASE)*sizeof(vectorT);
    
    if ((adminSize%8) == 0)
    {
        alignAdminSize = adminSize;
    }
    else
    {
        alignAdminSize = (adminSize/8 +1)*8;
    }
    
    int64 totalSize = size + alignAdminSize + elemSize * cnt;
    
    shmCreate((char **)ppRoot, shmId ,totalSize);
    memset(*ppRoot, 0x00, totalSize);
    pShmAdminT pShmAdmin = (pShmAdminT) (*ppRoot);
    
    pShmAdmin->bitMask[cnt/VECTOR_BASE] = VECTOR_MAX << (cnt % VECTOR_BASE);
    pShmAdmin->firstFreeByte = 0;
    pShmAdmin->elemCount = cnt;
    pShmAdmin->elemSize = elemSize;
    pShmAdmin->appAdminSize = alignAdminSize;
    pShmAdmin->allocatedCount = 0;
    
    ShmAllocateHandle((ShmAdminT *)pShmAdmin,handle,totalSize);
    

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgCreateCache */


ResCodeT MsgCreateCache    (int32        slotNum)
{
    BEGIN_FUNCTION( "MsgCreateCache" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    
    char * pRoot  = NULL;

    /* Temp slot structure */
    pMsgCacheSlotT pSlot, pTmpSlot;
    int32             tmpSltId = 0;

    /* Temp counter for initializing slots */
    int32 i = 0;
    memset(&pSlot, 0, sizeof(pMsgCacheSlotT));
    
    
    result = ShmCreate(SHM_ID_MSG_CACHE, sizeof(MsgCacheSlotT), slotNum, 0, (void **)&pRoot , &msgCacheHndl);
    if (result != NO_ERR)
    {
        RAISE_ERROR( ERR_ARCH_CREA_MSG_CACHE, RTN );
    }

    //todo get shm
    /* Create the Message Cache and set the handle for it */
    // result = ShmCreate(adapt_name(MSG_CACHE_NAME),
    //                    (unsigned __int64)sizeof(MsgCacheSlotT),
    //                    slotNum,
    //                    MSG_CACHE_ADMIN_SIZE,
    //                    &msgCacheHndl);
    // if (result != NO_ERR)
    // {
    //     RAISE_ERROR( ERR_ARCH_CREA_MSG_CACHE, RTN );
    // }

    // /* Get the starting address of the first slot. */
    // result = ShmGetAppDataRoot(msgCacheHndl, (void *)&pSlot);
    // if (result != NO_ERR)
    // {
    //     RAISE_ERROR( ERR_ARCH_CREA_MSG_CACHE, RTN );
    // }
    pSlot = (pMsgCacheSlotT)pRoot;
    /* Set the constant part of each slot. */
    for (; i < slotNum; i++)
    {

        pSlot->slotId  = i;
        /* by default, the pairedSlotId is set to SHM_NO_SLOT */
        pSlot->pairedSlotId  = SHM_NO_SLOT;
        pSlot++;
    }
    
    int32 slottmpId;
    pMsgCacheSlotT        pTmp11Slot = NULL;
		MsgRsrvSlot(&slottmpId, &pTmp11Slot);
		
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgCreateCache */

ResCodeT ShmFreeSlot(ShmHandleT handle, ShmSlotIdT slot)
{
    ShmAdminT* pShm;
    BEGIN_FUNCTION("ShmFreeSlot");


    pShm = (ShmAdminT*)gShmInfo[handle].pShm;
    /*check if the given slot is used, here the lock isn't used*/
    if (slot >= pShm->elemCount)
    {
        return ERR_ARCH_SHM_INVALID_PARAM;
    }


    /*get the lock*/
    // if (ShmGetMutexLock(&gShmInfo[handle].mutex_status_block) != SHM_NORMAL)
    // {
    //     /*error handling;*/
    //     RAISE_ERROR_PARM(ERR_ARCH_SHM_SYSTEM, NORTN, gShmInfo[handle].secName);
    //     return ERR_ARCH_SHM_SYSTEM;
    // }

    /*check if the slot is used*/
    if (SHM_GET_BITMASK(pShm, slot))
    {
        ShmSetMask(pShm, slot, 0);
        if ((pShm->firstFreeByte > (slot/VECTOR_BASE)) ||
            (pShm->firstFreeByte == SHM_NO_SLOT))
        {
            pShm->firstFreeByte = slot/VECTOR_BASE;
        }

        pShm->allocatedCount--;
    }

    /*free the lock*/
    // if (ShmFreeMutexLock(&gShmInfo[handle].mutex_status_block) != SHM_NORMAL)
    // {
    //     /*error handling;*/
    //     RAISE_ERROR_PARM(ERR_ARCH_SHM_SYSTEM, NORTN, gShmInfo[handle].secName);
    //     return ERR_ARCH_SHM_SYSTEM;
    // }

    EXIT_BLOCK();
    return SHM_NORMAL;
}


static int ShmFindNextHandle()
{
    BEGIN_FUNCTION( "ShmFindNextHandle" );
    int i;

    /*The hanlde "0" is prone to error, the valid handle should be from 1 */
    for(i=SHM_FIRST_HANDLE; i< SHM_INFO_COUNT; i++)
    {
        if (gShmInfo[i].flag !=1)

        {
            return i;
        }
    }
    EXIT_BLOCK();
    return i;
}

static ResCodeT ShmAllocateHandle(ShmAdminT * pShm, ShmHandleT * handle,
                                                    uint64 rtnLen )
{
    BEGIN_FUNCTION("ShmAllocateHandle");

    /*set info block*/
    strncpy(gShmInfo[gShmFreeHandle].secName, pShm->secName,SHM_NAME_LEN);
    gShmInfo[gShmFreeHandle].pShm = (unsigned char*)pShm;
    gShmInfo[gShmFreeHandle].pAppAdmin = (unsigned char*)pShm
        + SHM_GET_ADMIN_SIZE(pShm);
    gShmInfo[gShmFreeHandle].pData =gShmInfo[gShmFreeHandle].pAppAdmin
        + pShm->appAdminSize;
    gShmInfo[gShmFreeHandle].flag = 1;

    /* Initialize to use no slot pool */
    gShmInfo[gShmFreeHandle].poolSize       = 0;
    gShmInfo[gShmFreeHandle].poolLowLimit   = 0;
    gShmInfo[gShmFreeHandle].poolUpLimit    = 0;
    gShmInfo[gShmFreeHandle].pool           = NULL;
    gShmInfo[gShmFreeHandle].poolGetPos     = 0;
    gShmInfo[gShmFreeHandle].poolPutPos     = 0;
    gShmInfo[gShmFreeHandle].poolCnt        = 0;

    gShmInfo[gShmFreeHandle].actualSize     = rtnLen;
    /*create a mutex lock for the  shared section*/
    // if (ShmCreateMutexLock(pShm->secName,
    //         &gShmInfo[gShmFreeHandle].mutex_status_block) != SHM_NORMAL)
    // {
    //     /*error handling ;*/

    //     return ERR_ARCH_SHM_SYSTEM;
    // }

    /*allocate handle*/
    *handle = gShmFreeHandle;

    /*get the next free handle*/
    gShmFreeHandle = ShmFindNextHandle() ;

    EXIT_BLOCK();
    return SHM_NORMAL;
}

//ResCodeT ShmTryAttach ( int32 shmId, ShmHandleT * handle,
//                        int iLogErrors )
//{
//    void* section_adr;
//    int64 rtnLen;
//    char * pRoot
//
//    BEGIN_FUNCTION("ShmTryAttach");
//
//    /*attach a section*/
//    //todo get attached
//    
//    //shmCreate(&pRoot, shmId ,0);
//    
//    
////    ShmAllocateHandle((ShmAdminT *)pRoot,handle,rtnLen);
//
//    EXIT_BLOCK();
//    return SHM_NORMAL;
//}

//ResCodeT ShmAtach (int32 shmId, ShmHandleT * handle)
//{
//    void* section_adr;
//    BEGIN_FUNCTION("ShmAttach");
//    ASSERT(secName && handle );
//
//    RAISE_ERROR_PARM ( ShmTryAttach ( shmId, handle, 1 ), RTN, secName );
//
//    EXIT_BLOCK();
//    RETURN_RESCODE;
//}

ResCodeT ShmAtach(int32  shmId, int32 elemSize, int64 cnt, int32 adminSize, void ** ppRoot , ShmHandleT * handle)
{
    BEGIN_FUNCTION( "ShmCreate" );
    int32 alignAdminSize;

    /* Temp result code */
    ResCodeT result = NO_ERR;
    
    int64 size = sizeof(ShmAdminT) + (cnt/VECTOR_BASE)*sizeof(vectorT);
    
    if ((adminSize%8) == 0)
    {
        alignAdminSize = adminSize;
    }
    else
    {
        alignAdminSize = (adminSize/8 +1)*8;
    }
    
    int64 totalSize = size + alignAdminSize + elemSize * cnt;
    
    shmCreate((char **)ppRoot, shmId ,totalSize);
    
    pShmAdminT pShmAdmin = (pShmAdminT) (*ppRoot);

    ShmAllocateHandle((ShmAdminT *)pShmAdmin,handle,totalSize);
   
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgCreateCache */

ResCodeT MsgInit(int32        slotNum)
{
    BEGIN_FUNCTION( "MsgCreateCache" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    
    char * pRoot  = NULL;

    /* Temp slot structure */
    pMsgCacheSlotT pSlot, pTmpSlot;
    int32             tmpSltId = 0;

    /* Temp counter for initializing slots */
    int32 i = 0;
    memset(&pSlot, 0, sizeof(pMsgCacheSlotT));
    
    
    result = ShmAtach(SHM_ID_MSG_CACHE, sizeof(MsgCacheSlotT), slotNum, 0, (void **)&pRoot , &msgCacheHndl);
    if (result != NO_ERR)
    {
        RAISE_ERROR( ERR_ARCH_CREA_MSG_CACHE, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgCreateCache */


//ResCodeT MsgInit           ()
//{
//    BEGIN_FUNCTION( "MsgInit" );
//
//    /* Result code for attaching the Message Cache and initializing the
//       Asynchronous Counter Lock */
//    ResCodeT result = NO_ERR;
//
//    int i = 0;
//
//    ASSERT(devId);
//
//
//    // todo fix the 
//    result = ShmAttach(SHM_ID_MSG_CACHE, &msgCacheHndl);
//    if (result != NO_ERR)
//    {
//          RAISE_ERROR( ERR_ARCH_ATTACH_MSG_CACHE, RTN );
//    }
//
//    EXIT_BLOCK();
//    RETURN_RESCODE;
//} /* End of MsgInit */

ResCodeT MsgGetSlot         (int32                       slotId,
                            pMsgCacheSlotT            *  ppMsg)
{
    BEGIN_FUNCTION( "MsgGetMsg" );

    /* Temp result code */
    ResCodeT result = NO_ERR;

    /* Temp slot entry */
    pMsgCacheSlotT pSlotEntry;

    ASSERT(ppMsg);
    memset(&pSlotEntry, 0, sizeof(pMsgCacheSlotT));
    /* If the slot is not empty, then get the message from the Message Cache,
       else return error. */
    if (slotId != SHM_NO_SLOT && slotId != 0)
    {
        result = ShmGet(msgCacheHndl, slotId, (void *)&pSlotEntry);
        if (result != NO_ERR)
        {
            RAISE_ERROR( result, RTN );
        }
        *ppMsg = pSlotEntry;
    }
    else
    {
        RAISE_ERROR( ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgGetMsg */


ResCodeT MsgGetMsg         (int32                       slotId,
                            pMsgDataT            *  ppMsg)
{
    BEGIN_FUNCTION( "MsgGetMsg" );

    /* Temp result code */
    ResCodeT result = NO_ERR;

    /* Temp slot entry */
    pMsgCacheSlotT pSlotEntry;

    ASSERT(ppMsg);
    memset(&pSlotEntry, 0, sizeof(pMsgCacheSlotT));
    /* If the slot is not empty, then get the message from the Message Cache,
       else return error. */
    if (slotId != SHM_NO_SLOT && slotId != 0)
    {
        result = ShmGet(msgCacheHndl, slotId, (void *)&pSlotEntry);
        if (result != NO_ERR)
        {
            RAISE_ERROR( result, RTN );
        }
        *ppMsg = &(pSlotEntry->msgBody);
    }
    else
    {
        RAISE_ERROR( ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN );
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgGetMsg */

ResCodeT MsgRsrvSlotsPaired(int32                    *  pSlotId,
                            pMsgCacheSlotT        *  ppReqSlot,
                            pMsgCacheSlotT        *  ppRespSlot)
{
    BEGIN_FUNCTION( "MsgRsrvSlotsPaired" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    ResCodeT rc2    = NO_ERR;
    /* Temp slot ID */
    ShmSlotIdT reqSlotId = SHM_NO_SLOT;
    ShmSlotIdT respSlotId = SHM_NO_SLOT;

    ASSERT(pSlotId && ppReqSlot && ppRespSlot);

    /* Reserve the slots */
    result = ShmReserveSlot(msgCacheHndl, &reqSlotId);
    if (!OK(result))
    {
        RAISE_ERROR( result, RTN );
    }
    TRACE("PairedSlot [%d] reserved!" $$ reqSlotId);

    result = ShmReserveSlot(msgCacheHndl, &respSlotId);
    if (result != NO_ERR)
    {
        rc2 = ShmFreeSlot(msgCacheHndl, reqSlotId);
        RAISE_ERROR(rc2, NORTN);
        RAISE_ERROR( result, RTN );
    }
    TRACE("PairedSlot [%d] reserved!" $$ respSlotId);

    /* Get the slots */
    result = ShmGet(msgCacheHndl, reqSlotId, (void *)ppReqSlot);
    if (result != NO_ERR)
    {
        rc2 = ShmFreeSlot(msgCacheHndl, reqSlotId);
        RAISE_ERROR(rc2, NORTN);
        rc2 = ShmFreeSlot(msgCacheHndl, respSlotId);
        RAISE_ERROR(rc2, NORTN);
        RAISE_ERROR(result, RTN );
    }

    result = ShmGet(msgCacheHndl, respSlotId, (void *)ppRespSlot);
    if (result != NO_ERR)
    {
        rc2 = ShmFreeSlot(msgCacheHndl, reqSlotId);
        RAISE_ERROR( rc2, NORTN );
        rc2 = ShmFreeSlot(msgCacheHndl, respSlotId);
        RAISE_ERROR( rc2, NORTN );
        RAISE_ERROR( result, RTN );
    }


    /* Link the pair of slots */
    (*ppReqSlot)->slotId = (int32)reqSlotId;
    (*ppRespSlot)->slotId = (int32)respSlotId;
    
    (*ppReqSlot)->pairedSlotId = (int32)respSlotId;
    (*ppRespSlot)->pairedSlotId = (int32)reqSlotId;
    TRACE("PairedSlot req[%d]<=>rsp[%d] reserved!" $$ reqSlotId $$ respSlotId);


    /* Return the pointer to the slot ID. */
    *pSlotId = (int32)reqSlotId;

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgRsrvSlotsPaired */


ResCodeT MsgGetSlotRsp(int32                   slotId,
                            pMsgCacheSlotT        *  ppRespSlot)
{
    BEGIN_FUNCTION( "MsgGetSlotRsp" );

    /* Temp result code */
    ResCodeT result = NO_ERR;
    ResCodeT rc2    = NO_ERR;
    /* Temp slot ID */
    ShmSlotIdT pairedSlotId = SHM_NO_SLOT;
    
    pMsgCacheSlotT pSlotEntry;
		
		if (slotId != SHM_NO_SLOT && slotId != 0)
		{
				result = MsgGetPairedSlotId(slotId, &pairedSlotId);
				RAISE_ERROR(result, RTN);
				
				if (pairedSlotId == SHM_NO_SLOT)
				{
						RAISE_ERROR(ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN);
				}
				
				result = ShmGet(msgCacheHndl, pairedSlotId, (void *)&pSlotEntry);
        if (result != NO_ERR)
        {
            RAISE_ERROR(ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN);
        }
				
				*ppRespSlot = pSlotEntry;
				
		}
		else
		{
				RAISE_ERROR(ERR_ARCH_MSG_EMPTY_SLOT_ERR, RTN);
		}
    

    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End of MsgRsrvSlotsPaired */