/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
#include <errno.h> 
/* Project Header File*/
#include "../header/common_macro.h"
#include "../header/app_shl.h"
#include "../header/msg_cache.h"
#include "../db_header/t_mem_data.h"
#include "../db_header/t_mem_txn.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
#define MAX_PRCS_NAME_LEN   32
#define QUEUE_TYPE_MAX      10

#define RAISE_READ_MSG_ERR(_err_, _bRtn_)\
do\
{\
    if ((_err_) == ERR_MSG_NOT_FOUND)\
    {\
        THROW_RESCODE(_err_);\
    }\
    else\
    {\
        RAISE_ERROR(_err_, _bRtn_);\
    }\
} while (0);
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct ShlRunInfoS
{   /* Static Area */
    char    prcsName[MAX_PRCS_NAME_LEN];
    int32   inputQHndl;
    int32   outputQHndl;
    int32   txnSize;
    AppCallBackT fAppCallBack;
		AppDoneCallBackT	 fAppDoneCallBack;
    pFifoInfoT inputBuff;
    pFifoInfoT outputBuff;
    int32		setId;
    
    /* Dynamic Area */
    BOOL    bHasMsg;
    BOOL    bRunFlg;
    int32   prcsMsgCnt;
    int64       txnId;
    int64	  timestamp;
    ShmSlotIdT reqSlot;
    ShmSlotIdT rspSlot;
} ShlRunInfoT, *pShlRunInfoT;

typedef struct ShlPrcsCtxS
{   
    int32 sendFlg;
    ShmSlotIdT  rspSlotNo;
} ShlPrcsCtxT, *pShlPrcsCtxT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
ShlRunInfoT gShlRunInfo = {0};

int32 gWaitFd = -1;



/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT ShlInitWaitQueue(int32 inputQFd)
{
    BEGIN_FUNCTION( "ShlInitWaitQueue" );
    struct epoll_event waitEvent;
    ResCodeT rc = NO_ERR;
    
    gWaitFd = epoll_create(QUEUE_TYPE_MAX);
    if (gWaitFd < 0)
    {
        RAISE_ERROR( ERR_OPEN_ERR_LOG_ERR, RTN );
    } 
    
    waitEvent.events = EPOLLIN| EPOLLRDHUP|EPOLLERR|EPOLLHUP;
    waitEvent.data.fd = inputQFd;
    
    if (epoll_ctl(gWaitFd,EPOLL_CTL_ADD, inputQFd, &waitEvent))
    {
        RAISE_ERROR( ERR_APP_EPOLL_ADD_ERR, RTN );
    }
    
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlInitWaitQueue */

ResCodeT ShlHiber()
{
    BEGIN_FUNCTION( "ShlHiber" );
    struct epoll_event waitEvent[QUEUE_TYPE_MAX];

    ResCodeT rc = NO_ERR;
    
    rc = epoll_wait(gWaitFd, waitEvent,QUEUE_TYPE_MAX,10);
    
//    if (rc<0 && rc != EINTR)
//    {
//        RAISE_ERROR( ERR_APP_EPOLL_WAIT_ERR, RTN );
//    }
//    else if (rc == 0)
//    {
//        //todo timeout
//    }
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlHiber */

ResCodeT ShlWakeUp()
{
    BEGIN_FUNCTION( "ShlWakeUp" );

    ResCodeT rc = NO_ERR;
    
    //wait_up_interruptible(gWaitQueue);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlWakeUp */

ResCodeT ShlReadMsgFromQ(pMsgStructT* ppReq, pMsgStructT* ppRsp, pShlPrcsCtxT pShlPrcsCtx)
{
    BEGIN_FUNCTION( "ShlReadMsgFromQ" );
    char buffer[MSG_BODY_LEN];
    
    pMsgCacheSlotT pReqMsgSlot =NULL;
    pMsgCacheSlotT pRspMsgSlot =NULL;
    
    static MsgStructT sReq;
    static MsgStructT sRsp;
    
    pMsgStructT pTmpReq = NULL;
    
    struct epoll_event waitEvent[QUEUE_TYPE_MAX];

    ResCodeT rc = NO_ERR;
    
    ShmSlotIdT  reqSlot;
    
    if (gShlRunInfo.prcsMsgCnt >= gShlRunInfo.txnSize)
    {
        //gShlRunInfo.prcsMsgCnt = 0;
        TRACE("Txn Full %lld" $$ gShlRunInfo.prcsMsgCnt);
        THROW_RESCODE(ERR_MSG_NOT_FOUND);
    }

    TRACE("GET MSG cnt to %lld" $$ gShlRunInfo.prcsMsgCnt);
    
//    rc = GetFromFifoQueue(gShlRunInfo.inputBuff,buffer);
//    if (rc == ERR_MSG_NOT_FOUND) 
//    {
//    		int32 i = 0;
//        for (i = 0; i< gShlRunInfo.txnSize; i++ )
//        {
//	        rc = IPCReceive(gShlRunInfo.inputQHndl,buffer,gShlRunInfo.inputBuff->node_size);
//	        if (OK(rc))
//	       	{
//	       		rc  = PutIntoFifoQueue(gShlRunInfo.inputBuff,buffer);
//	       		RAISE_ERROR( rc, RTN );
//	       	}
//	       	else
//	       	{
//	       		break;
//	       	}
//	        RAISE_ERROR( rc, RTN );
//	      }
//    }
//    RAISE_READ_MSG_ERR(rc, RTN);
    
    rc = IPCReceive(gShlRunInfo.inputQHndl,buffer,gShlRunInfo.inputBuff->node_size);
    if (rc == ERR_PIPE_READ_NO_DATA)
   	{
   		 	
   		 	THROW_RESCODE(ERR_MSG_NOT_FOUND);
   	}
   	RAISE_ERROR( rc, RTN );

    if (gShlRunInfo.inputBuff->node_size == sizeof(ShmSlotIdT))
    {
    		gShlRunInfo.reqSlot = *((ShmSlotIdT *)buffer);
    		rc = MsgGetSlot(gShlRunInfo.reqSlot, &pReqMsgSlot);
    		RAISE_ERROR( rc, RTN );
    		*ppReq 	= (pMsgStructT)&pReqMsgSlot->msgBody;
    		
    		rc = MsgGetSlotRsp(gShlRunInfo.reqSlot, &pRspMsgSlot);
    		RAISE_ERROR( rc, RTN );
    		*ppRsp 	= (pMsgStructT)&pRspMsgSlot->msgBody;
    		
    }
    else
  	{
  			gShlRunInfo.reqSlot = SHM_NO_SLOT;
  			pTmpReq = (pMsgStructT)buffer;
  			*ppReq 	= (pMsgStructT)&sReq;
  			*ppRsp 	= (pMsgStructT)&sRsp;
  			
  			memcpy(*ppReq,pTmpReq, pTmpReq->msgHdr.msgLen );
  	}
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlReadMsgFromQ */

ResCodeT ShlStartTxn(int64 *pTxnId, int64 * timestamp)
{
    BEGIN_FUNCTION( "ShlStartTxn" );
    ResCodeT rc = NO_ERR;
    
    rc = MemTxnStart(pTxnId, timestamp);
		RAISE_ERROR(rc, RTN);
    
    TRACE("MemTxnStart done <%lld>" $$ *pTxnId);
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlStartTxn */

ResCodeT ShlReadNextMsg(pMsgStructT* ppReq, pMsgStructT* ppRsp, pShlPrcsCtxT pShlPrcsCtx)
{
    BEGIN_FUNCTION( "ShlReadNextMsg" );
    


    ResCodeT rc = NO_ERR;
  
    rc = ShlReadMsgFromQ(ppReq, ppRsp, pShlPrcsCtx);
    if (OK(rc))
    {
        gShlRunInfo.prcsMsgCnt++;
    }
    RAISE_READ_MSG_ERR(rc, RTN);
    
    if (gShlRunInfo.prcsMsgCnt == 1)
    {
			  rc = ShlStartTxn(&gShlRunInfo.txnId, &gShlRunInfo.timestamp);
			  RAISE_ERROR( rc, RTN );
		}
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlReadNextMsg */


ResCodeT ShlPrcsNextMsg(pMsgStructT pReq, pMsgStructT pRsp, pShlPrcsCtxT pShlPrcsCtx)
{
    BEGIN_FUNCTION( "ShlPrcsNextMsg" );

    ResCodeT rc = NO_ERR;
    CallBackCtxT ctx;
  
    //validate the input message
    ctx.sendFlg = 0;
    
    rc = gShlRunInfo.fAppCallBack(pReq, pRsp, gShlRunInfo.timestamp, &ctx);
    RAISE_ERROR( rc, NORTN );
    pShlPrcsCtx->sendFlg = ctx.sendFlg;
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlPrcsNextMsg */


ResCodeT ShlSendRsp(pShlPrcsCtxT pPrcsCtx, pMsgStructT pRsp)
{
    BEGIN_FUNCTION( "ShlSendRsp" );
    ResCodeT rc = NO_ERR;
    
    if (SHM_NO_SLOT == gShlRunInfo.reqSlot) 
    {
    		rc  = PutIntoFifoQueue(gShlRunInfo.outputBuff,(void *)pRsp);
				RAISE_ERROR( rc, RTN );
    }
    else
    {
    		rc  = PutIntoFifoQueue(gShlRunInfo.outputBuff,(void *)&gShlRunInfo.reqSlot);
				RAISE_ERROR( rc, RTN );
   	}

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlSendRsp */

ResCodeT ShlPrcsMsg(pShlRunInfoT pRunInfo)
{
    BEGIN_FUNCTION( "ShlPrcsMsg" );
    pMsgStructT pReq = NULL, pRsp = NULL;
    ShlPrcsCtxT     shlPrcsCtx;  
    shlPrcsCtx.sendFlg = 0;
      

    ResCodeT rc = NO_ERR;
    
    rc = ShlReadNextMsg(&pReq, &pRsp, &shlPrcsCtx);
    RAISE_READ_MSG_ERR(rc, RTN);
    
    rc = ShlPrcsNextMsg(pReq, pRsp, &shlPrcsCtx);
    RAISE_ERROR( rc, NORTN );

    EXIT_BLOCK();
    if (shlPrcsCtx.sendFlg)
    {
        rc = ShlSendRsp(&shlPrcsCtx, pRsp);
        RAISE_ERROR( rc, NORTN );
    }
    RETURN_RESCODE;
}/* End of ShlPrcsMsg */

ResCodeT ShlCommitTxn(pShlRunInfoT pRunInfo)
{
    BEGIN_FUNCTION( "ShlCommitTxn" );
    ResCodeT rc = NO_ERR;
    TRACE("ShlCommitTxn start txnSize %lld" $$ pRunInfo->prcsMsgCnt);
    if (pRunInfo->fAppDoneCallBack)
    {
    		rc = pRunInfo->fAppDoneCallBack();
    		RAISE_ERROR( rc, RTN );
    		TRACE("fAppDoneCallBack done");
    }
    int32 dataType = 0;
    void * pData = NULL;
    int32 dataLen = 0;
    int64 cursor = 0;
    
	static int32 currentSeq = 0;
    int32 dataCnt = 0;
		int32 dbErrCode = 0;
    MemDataT dbMemData;
		MemTxnT dbMemTxn;
		
		
		//prepare Data
    static int seqNo[7000];
    static int setId[7000];
    static int dataType1[7000];
    static  char dataCharArray[7000][300+1];
   
    do
    {
    		rc = MemReadTxnData(pRunInfo->txnId, &dataType, &pData, &dataLen,&cursor);
    		if (rc == ERR_MSG_NOT_FOUND)
    		{
    				break;
    		}
    		
    		seqNo[dataCnt] = currentSeq+1;
    		setId[dataCnt] = pRunInfo->setId;
    		dataType1[dataCnt] = dataType;
    		
    		memcpy(&dataCharArray[dataCnt], pData, dataLen);
    		dataCnt++;
			currentSeq++;

    } while(TRUE);
#ifndef TEST_APP 		
		rc = DbMemDataBatchInsert( dataCnt, seqNo,setId,dataType1,dataCharArray, 300);
		if (NOTOK(rc))
    {
    		TRACE("Failed!!! DB DATA Insert %lld cnt" $$ dataCnt  );
    }
    RAISE_ERROR( rc, NORTN );
//    do
//    {
//    		rc = MemReadTxnData(pRunInfo->txnId, &dataType, &pData, &dataLen,&cursor);
//    		if (rc == ERR_MSG_NOT_FOUND)
//    		{
//    				break;
//    		}
//    		dataCnt++;
//    		RAISE_ERROR( rc, RTN );
//#ifndef TEST_APP       		
//    		dbMemData.sequence_no = dataCnt;
//		    dbMemData.set = pRunInfo->setId;
//		    dbMemData.data_type = dataType;
//		    //char strtme[]= "aaaa";
//		    //dbMemData.data = strtme;
//			dbMemData.data = pData;
//			dbMemData.lengthOfBlob = dataLen;
//		    TRACE("DB DATA Insert %lld,type %lld" $$ dbMemData.sequence_no  $$ dbMemData.data_type = dataType );
//		    //rc = DbMemDataInsert( &dbMemData, &dbErrCode);
//		    //if (NOTOK(rc))
//		    //{
//		    //		TRACE("Failed!!! DB DATA Insert %lld,type %lld" $$ dbMemData.sequence_no  $$ dbMemData.data_type = dataType );
//		    //}
//		    //RAISE_ERROR( rc, NORTN );
//#endif		    
//    }while(TRUE);

    

    
    dbMemTxn.txn_id = pRunInfo->txnId;
    dbMemTxn.set_id = pRunInfo->setId ;
    dbMemTxn.start_seq_no = dataCnt;
    dbMemTxn.end_seq_no = dataCnt;
    TRACE("DB TXN Insert %lld, id %lld, cnt %lld" $$ dbMemTxn.txn_id $$ dbMemTxn.set_id $$ dbMemTxn.start_seq_no );
    rc = DbMemTxnInsert( &dbMemTxn, &dbErrCode);
    if (NOTOK(rc))
    {
    		TRACE("Failed!!! DB TXN Insert %lld, id %lld, cnt %lld" $$ dbMemTxn.txn_id $$ dbMemTxn.set_id $$ dbMemTxn.start_seq_no );
    }
    RAISE_ERROR( rc, NORTN );
    
  
    rc = DbCommit(&dbErrCode);
    TRACE("DB return %lld" $$ dbErrCode );
		RAISE_ERROR( rc, RTN );
		
		SET_RESCODE(NO_ERR);
#endif
    rc = MemTxnCommit();
    RAISE_ERROR( rc, RTN );
    TRACE("MemTxnCommit done");
    
    rc = ShlSendBuffRsp();
    RAISE_ERROR( rc, RTN );
    TRACE("ShlSendBuffRsp done");
    gShlRunInfo.prcsMsgCnt = 0;
		
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlCommitTxn */

ResCodeT AppShlInit(int32 setId, char *pPrcsName, int32 inputQHndl, int32 outputQHndl, pFifoInfoT inputBuff, pFifoInfoT outputBuff, 
            int32 txnSize, AppCallBackT fAppCallBack, AppDoneCallBackT fAppDoneCallBack)
{
    BEGIN_FUNCTION( "AppShlInit" );

    ResCodeT rc = NO_ERR;
    
    memcpy(gShlRunInfo.prcsName, pPrcsName,strlen(pPrcsName));
    gShlRunInfo.prcsName[MAX_PRCS_NAME_LEN];
    gShlRunInfo.inputQHndl = inputQHndl;
    gShlRunInfo.outputQHndl = outputQHndl;
    gShlRunInfo.txnSize = txnSize;
    gShlRunInfo.fAppCallBack = fAppCallBack;
    gShlRunInfo.fAppDoneCallBack = fAppDoneCallBack;
		gShlRunInfo.inputBuff = inputBuff;
		gShlRunInfo.outputBuff = outputBuff;
		gShlRunInfo.setId = setId;
		
	
    /* Dynamic Area */
    gShlRunInfo.bRunFlg = TRUE;
    gShlRunInfo.prcsMsgCnt = 0;
    gShlRunInfo.bHasMsg = FALSE;
    //todo 
    
    rc = ShlInitWaitQueue(inputQHndl);
  	RAISE_ERROR( rc, RTN );
    
    rc =  MsgInit(MAX_SLOT_CNT);
    RAISE_ERROR( rc, RTN );
    // init send buffer queue and input buffer queue;
    
#ifndef TEST_APP        
    rc = DbInit(DB_INST, DB_NAME, DB_PWD);
    RAISE_ERROR(rc, RTN);
#endif   

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlInit */

ResCodeT ShlSendBuffRsp()
{
    BEGIN_FUNCTION( "ShlSendBuffRsp" );
    ResCodeT rc = NO_ERR;
    char buffer[MSG_BODY_LEN];

   	do
   	{
   		rc = GetFromFifoQueue(gShlRunInfo.outputBuff,buffer);
   		
   		if(NOTOK(rc))
   		{
   			break;
   		}
   		
   		rc = IPCSend(gShlRunInfo.outputQHndl,buffer,gShlRunInfo.outputBuff->node_size);
   		RAISE_ERROR( rc, NORTN );
   	}while(TRUE);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of ShlSendBuffRsp */


ResCodeT AppShlRun()
{
    BEGIN_FUNCTION( "AppShlRun" );
		struct epoll_event waitEvent[QUEUE_TYPE_MAX];
    ResCodeT rc = NO_ERR;

    do
    {
        //todo
		    rc = epoll_wait(gWaitFd, waitEvent,QUEUE_TYPE_MAX,2);

		    if (rc<0 && rc != EINTR)
		    {
		        RAISE_ERROR( ERR_APP_EPOLL_WAIT_ERR, RTN );
		    }
		    else if  (rc<0 && rc == EINTR)
		    {
			//printf("epoll_wait = %ld\n", rc);
		    		continue;
		   	}
		    else if (rc == 0)
		    {
			//printf("epoll_wait = %ld\n", rc);
		        //todo timeout
		        //printf("timeout\n");
		    }
		    else
		   	{
						do
		        {
				//printf("gShlRunInfo = %ld\n", gShlRunInfo.prcsMsgCnt);
		        	rc = ShlPrcsMsg(&gShlRunInfo);
	          	RAISE_ERROR( rc, NORTN );
		        }while (rc != ERR_MSG_NOT_FOUND);
		   			
		   	}
        
        
        
        SET_RESCODE(NO_ERR);
        
        if (gShlRunInfo.prcsMsgCnt)
        {
        
		//printf("ShlCommitTxn start\n", rc);
	        rc = ShlCommitTxn(&gShlRunInfo);
//printf("ShlCommitTxn end\n", rc);    
		RAISE_ERROR( rc, RTN );
	        
		//printf("ShlSendBuffRsp start\n", rc);
	        rc = ShlSendBuffRsp();
	//printf("ShlSendBuffRsp end\n", rc);    
        RAISE_ERROR( rc, RTN );
	      }
        
        //ShlHiber();

    }while (gShlRunInfo.bRunFlg);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of AppShlRun */
            
            