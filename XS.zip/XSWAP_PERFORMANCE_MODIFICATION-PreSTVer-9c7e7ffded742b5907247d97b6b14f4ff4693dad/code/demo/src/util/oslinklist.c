
#include "../header/oslinklist.h"
#include "../header/err_cod.h"
/*---------------------------------GLOBAL VARIABLES---------------------------*/

/*---------------------------------IMPLEMENTATION-----------------------------*/
/* DEFAULT object comparison function provided for non-sorted linked list. */
long DEFAULT_COMPARE_FUNC(void *obj1, void *obj2)
{
    BEGIN_FUNCTION("DEFAULT_COMPARE_FUNC");
    ASSERT(TRUE);
    return obj1 != obj2;
    EXIT_BLOCK();
}

/******************************************************************************
 * Description:   Initialize a linked list.
 * Parameters:
 *      sortType    IN  sort type of the link list to be created.
 *      allowDuplicateKey   IN  allow duplicate keys to exist in the linked
 *          list.
 *      CompareFunc IN  pointer to the function to compare two link list nodes.
 *      CompareKeyFunc  IN  pointer to the function used to compare two keys.
 *      GetKeyFunc  IN  pointer to function used to obtain a key for the given
 *                      object.
 *      pOsLinkList OUT pointer to the link list to be initialized.
 *
 *      sortType can be one of the three pre-defined sort types: NON_SORTED,
 *      ASCENDING or DESCENDING.
 *      The linked list provides searching function either by a given enclosed
 *      object or by a give key. For the former case, CompareFunc must be
 *      provided for sorted linked list and FindItemInLinkList() is used to
 *      search for an item; for the latter case, CompareKeyFunc and GetKeyFunc
 *      must be provided and FindItemByKeyInLinkList() is used to search for an
 *      item. Of course, two search methods can be used simultaneously as long
 *      as all three functions are provided.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to initialize a linked list.
 ******************************************************************************/
ResCodeT InitLinkList(SORT_TYPE sortType,
                        BOOL allowDuplicateKey,
                        CompareFuncT CompareFunc,
                        CompareFuncT CompareKeyFunc,
                        GetKeyFuncT GetKeyFunc,
                        pOsLinkListT pOsLinkList)
{
    BEGIN_FUNCTION("InitLinkList");

    ASSERT(pOsLinkList)

    if (sortType > DESCENDING)
    {
        THROW_RESCODE(ERR_INVLD_SORT_TYPE)
    }
    if (sortType == NON_SORTED && !CompareFunc)
    {
        /* if necessary, provides a default CompareFunc for non-sorted link
        list*/
        CompareFunc = DEFAULT_COMPARE_FUNC;
    }
    if (!CompareFunc && !CompareKeyFunc)
    {
        /* must provided at least one search method */
        THROW_RESCODE(ERR_INVLD_OBJ_CMP_FUNC)
    }
    if (CompareKeyFunc && !GetKeyFunc)
    {
        /* if want to search an obj by a given key, then GetKeyFunc must be
        provided */
        THROW_RESCODE(ERR_INVLD_GET_KEY_FUNC)
    }

    pOsLinkList->head = NULL;
    pOsLinkList->sortType = sortType;
    pOsLinkList->CompareFunc = CompareFunc;
    pOsLinkList->CompareKeyFunc = CompareKeyFunc;
    pOsLinkList->GetKeyFunc = GetKeyFunc;
    pOsLinkList->numEntries = 0;
    pOsLinkList->allowDuplicateKey = allowDuplicateKey;

    EXIT_BLOCK()
    RETURN_RESCODE
}


/******************************************************************************
 * Description:   Add an item to a linked list.
 * Parameters:
 *      pOsLinkListNode IN  item to be added
 *      pOsLinkList IN  pointer to the link list
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to add an item to a linked list.
 *****************************************************************************/
ResCodeT AddItemToLinkList(pOsLinkListNodeT pOsLinkListNode,
                        pOsLinkListT pOsLinkList)
{
    BEGIN_FUNCTION("AddItemToLinkList");
    EXIT_BLOCK()
    return AddItemToLinkListExt(pOsLinkListNode, pOsLinkList, NULL);

}

/******************************************************************************
 * Description:   Remove an item from a linked list. The function doesn't
 *          release the storage of the removed item.
 * Parameters:
 *      pOsLinkListNode IN  item to be removed.
 *      pOsLinkList IN  pointer to the link list
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to remove an item from the linked list.
 *****************************************************************************/
ResCodeT RemoveItemFromLinkList(pOsLinkListNodeT pOsLinkListNode,
                            pOsLinkListT pOsLinkList)
{
    BEGIN_FUNCTION("RemoveItemFromLinkList");

    ASSERT(pOsLinkListNode && pOsLinkList)

    if (pOsLinkListNode->linkList != pOsLinkList)
    {
        THROW_RESCODE(ERR_ITEM_NOT_BELONG_TO_LINKED_LIST)
    }

    if (pOsLinkListNode->prev)
    {
        pOsLinkListNode->prev->next = pOsLinkListNode->next;
    }
    if (pOsLinkListNode->next)
    {
        pOsLinkListNode->next->prev = pOsLinkListNode->prev;
    }
    if (pOsLinkList->head == pOsLinkListNode)
    {
        pOsLinkList->head = pOsLinkListNode->next;
    }

    EXIT_BLOCK()
    if (OK(GET_RESCODE()))
    {
        pOsLinkListNode->prev = NULL;
        pOsLinkListNode->next = NULL;
        pOsLinkListNode->linkList = NULL;
        (pOsLinkList)->numEntries--;
    }
    RETURN_RESCODE
}

/*******************************************************************************
 * Description:   Find an item in a linked list for a given enclosed object.
 * Parameters:
 *      object  IN  The enclosed object of wanted linked list item.
 *      pOsLinkList IN  pointer to the link list
 *      ppOsLinkListNode    OUT Write to the found linked list item.
 *
 *      This function searches for an item with a given enclosed object. The
 *      CompareFunc for the linked list must be provided.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT FindItemInLinkList(void *object,
                            pOsLinkListT pOsLinkList,
                            pOsLinkListNodeT *ppOsLinkListNode)
{
    BEGIN_FUNCTION("FindItemInLinkList");

    ASSERT(object && pOsLinkList && ppOsLinkListNode)

    if (!pOsLinkList->CompareFunc)
    {
        THROW_RESCODE(ERR_INVLD_OBJ_CMP_FUNC)
    }

    RAISE_ERROR( InternalFindItemInLinkList(FALSE,
                        object,
                        pOsLinkList,
                        ppOsLinkListNode),
                    RTN)

    EXIT_BLOCK()
    RETURN_RESCODE
}

/*******************************************************************************
 * Description:   Find an item in a linked list for a given key.
 * Parameters:
 *      key IN  The key of the wanted linked list item.
 *      pOsLinkList IN  pointer to the link list.
 *      ppOsLinkListNode    OUT Write to the found linked list item.
 *
 *      This function searches for an item with a given key. The CompareKeyFunc
 *      and GetKeyFunc must be provided.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT FindItemByKeyInLinkList(void *key,
                            pOsLinkListT pOsLinkList,
                            pOsLinkListNodeT *ppOsLinkListNode)
{
    BEGIN_FUNCTION("FindItemByKeyInLinkList");

    ASSERT(key && pOsLinkList && ppOsLinkListNode)

    if (!pOsLinkList->CompareKeyFunc || !pOsLinkList->GetKeyFunc)
    {
        THROW_RESCODE(ERR_INVLD_KEY_CMP_FUNC)
    }

    RAISE_ERROR( InternalFindItemInLinkList(TRUE,
                        key,
                        pOsLinkList,
                        ppOsLinkListNode),
                    RTN)

    EXIT_BLOCK()
    RETURN_RESCODE
}

/*******************************************************************************
 * Description:   Find an item in a linked list. The function is internally used
 *      by the module and can't be called externally.
 * Parameters:
 *      searchByKey IN  Flag indicating search method. A TRUR value indicates
 *                      searching by a given key, otherwise by an given object.
 *      context IN  The search context, either a key or an object.
 *      pOsLinkList IN  pointer to the link list to be initialized.
 *      ppOsLinkListNode    OUT Write to the found linked list item.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to find an item in the linked list.
 ******************************************************************************/
ResCodeT InternalFindItemInLinkList(BOOL searchByKey,
                            void *context,
                            pOsLinkListT pOsLinkList,
                            pOsLinkListNodeT *ppOsLinkListNode)
{

    /* all parameters have been verified by the callers. so it's unnecessary to
    check parameters any more. */
    pOsLinkListNodeT curr;
    int sign, cmpSts;

    BEGIN_FUNCTION("InternalFindItemInLinkList");
    ASSERT(ppOsLinkListNode);

    curr = pOsLinkList->head;
    /*sign = pOsLinkList->sortType == ASCENDING ? 1 : -1;*/
    cmpSts = -1;
    while (curr)
    {
        if (searchByKey)
        {
            /* search by the given key */
            cmpSts = pOsLinkList->CompareKeyFunc(
                        pOsLinkList->GetKeyFunc(curr->enclosingObject),
                        context)/* * sign*/;
        }
        else
        {
            /* search by the given object */
            cmpSts = pOsLinkList->CompareFunc(curr->enclosingObject, context)
                        /** sign*/;
        }
        if (pOsLinkList->sortType == DESCENDING)
        {
            cmpSts = -cmpSts;
        }
        if (
            /* found! */
            cmpSts == 0 ||
            /* for sorted linked list, the item can't be found in the list */
            (pOsLinkList->sortType != NON_SORTED && cmpSts > 0 )
            )
        {
            break;
        }
        curr = curr->next;
    }

    if (cmpSts == 0)
    {
        /* found! */
        *ppOsLinkListNode = curr;
    }
    else
    {
        /* not found! */
        THROW_RESCODE(ERR_OBJ_NOT_IN_LINKED_LIST)
    }

    EXIT_BLOCK()
    if (NOTOK(GET_RESCODE()))
    {
        *ppOsLinkListNode = NULL;
    }
    RETURN_RESCODE
}

/******************************************************************************
 * Description:   Destroy a linked list. The function won't release the storage
 *      all items occupied. Therefore the caller should take care of memory
 *      release.
 * Parameters:
 *      pOsLinkList IN  pointer to the link list to be initialized.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to destroy a link list.
 *****************************************************************************/
ResCodeT DestroyLinkList(pOsLinkListT pOsLinkList)
{
    BEGIN_FUNCTION("DestroyLinkList");
    pOsLinkListNodeT last, curr;

    ASSERT(pOsLinkList)

    curr = pOsLinkList->head;
    while (curr)
    {
        last = curr;
        curr = curr->next;
        last->prev = NULL;
        last->next = NULL;
        last->linkList = NULL;
        (pOsLinkList->numEntries)--;
    }

    ASSERT(pOsLinkList->numEntries == 0)
    pOsLinkList->head = NULL;
    pOsLinkList->CompareFunc = NULL;
    pOsLinkList->CompareKeyFunc = NULL;
    pOsLinkList->GetKeyFunc = NULL;

    EXIT_BLOCK()
    RETURN_RESCODE
}

ResCodeT InitLinkListIter(pOsLinkListIterT pOsLinkListIter,
                        pOsLinkListT pOsLinkList)
{
    BEGIN_FUNCTION("InitLinkListIter");

    ASSERT(pOsLinkListIter && pOsLinkList)

    pOsLinkListIter->linkList = pOsLinkList;
    pOsLinkListIter->curr = pOsLinkList->head;

    EXIT_BLOCK()
    RETURN_RESCODE
}


ResCodeT DestroyLinkListIter(pOsLinkListIterT pOsLinkListIter)
{
    BEGIN_FUNCTION("DestroyLinkListIter");

    ASSERT(pOsLinkListIter)
    memset(pOsLinkListIter, 0x00, sizeof (osLinkListIterT));

    EXIT_BLOCK()
    RETURN_RESCODE
}

ResCodeT LinkListIterGetHead(pOsLinkListIterT pOsLinkListIter,
                        pOsLinkListNodeT *pHead)
{
    BEGIN_FUNCTION("LinkListIterGetHead");

    ASSERT(pOsLinkListIter && pHead)
    *pHead = pOsLinkListIter->linkList->head;

    EXIT_BLOCK()
    RETURN_RESCODE
}


ResCodeT LinkListIterGetNext(pOsLinkListIterT pOsLinkListIter,
                        pOsLinkListNodeT *pNext)
{
    BEGIN_FUNCTION("LinkListIterGetNext");


    ASSERT(pOsLinkListIter && pNext)

    if (pOsLinkListIter->curr)
    {
        pOsLinkListIter->curr = pOsLinkListIter->curr->next;
    }
    *pNext = pOsLinkListIter->curr;

    EXIT_BLOCK()
    RETURN_RESCODE
}

ResCodeT LinkListIterReset(pOsLinkListIterT pOsLinkListIter)
{
    BEGIN_FUNCTION("LinkListIterReset");

    ASSERT(pOsLinkListIter && pOsLinkListIter->linkList)

    pOsLinkListIter->curr = pOsLinkListIter->linkList->head;

    EXIT_BLOCK()
    RETURN_RESCODE
}

ResCodeT LinkListIter(pOsLinkListIterT pOsLinkListIter,
                    ProcessLinkListNodeFuncT ProcessLinkListNodeFunc,
                    void *context,
                    BOOL stopOnError)
{
    BEGIN_FUNCTION("LinkListIter");
    ResCodeT rc;
    pOsLinkListNodeT curr;

    ASSERT(pOsLinkListIter && pOsLinkListIter->linkList &&
        ProcessLinkListNodeFunc)

    curr = pOsLinkListIter->linkList->head;
    while (curr)
    {
        pOsLinkListNodeT victim = curr;
        /* get next item before calling the processing routine, therefore,
        the victim can be deleted in the routine. */
        curr = curr->next;
        if (NOTOK(rc = ProcessLinkListNodeFunc(victim, context)) && stopOnError)
        {
            THROW_RESCODE(rc)
        }
    }

    EXIT_BLOCK()
    RETURN_RESCODE
}


/******************************************************************************
 * Description:   Add an item to a linked list.
 * Parameters:
 *      pOsLinkListNode IN  item to be added
 *      pOsLinkList IN  pointer to the link list
 *      ppOsLinkListNode    OUT pointer to the item that is found in the list.
 * Return Value         :
 *      NO_ERR:     Successful
 *      ERR_<DSCR>: fail to add an item to a linked list.
 *****************************************************************************/
ResCodeT AddItemToLinkListExt(pOsLinkListNodeT pOsLinkListNode,
                        pOsLinkListT pOsLinkList,
                        pOsLinkListNodeT *ppOsLinkListNode)
{
    BEGIN_FUNCTION("AddItemToLinkListExt");

    pOsLinkListNodeT last, curr;

    ASSERT(pOsLinkListNode && pOsLinkList && pOsLinkListNode->enclosingObject)

    if (pOsLinkListNode->linkList == pOsLinkList)
    {
        /* The node has been added to the linked list. */
        THROW_RESCODE(ERR_ITEM_ALREADY_EXIST_IN_LINKED_LIST)
    }

    last = NULL;
    curr = pOsLinkList->head;

    /* for NON_SORTED case, we have remember the last and curr position, and
    the new item will be inserted between last and curr. so here we continue
    with sorted cases and find the right position */
    if (pOsLinkList->sortType != NON_SORTED)
    {
        /* sorted linked list, find the position to insert the new item */
        int cmpSts = -1;

        while (curr)
        {
            if (pOsLinkList->CompareKeyFunc)
            {
                cmpSts = pOsLinkList->CompareKeyFunc(
                            pOsLinkList->GetKeyFunc(curr->enclosingObject),
                            pOsLinkList->GetKeyFunc(
                                pOsLinkListNode->enclosingObject));
            }
            else
            {
                cmpSts = pOsLinkList->CompareFunc(
                            curr->enclosingObject,
                            pOsLinkListNode->enclosingObject);
            }
            if (pOsLinkList->sortType == DESCENDING)
            {
                cmpSts = -cmpSts;
            }
            if (cmpSts >= 0)
            {
                break;
            }
            else
            {
                last = curr;
                curr = curr->next;
            }
        }
        if (!cmpSts && !pOsLinkList->allowDuplicateKey)
        {
            /* duplicate objects or keys are not allowed in the linked list */
            if (ppOsLinkListNode)
            {
                *ppOsLinkListNode = curr;
            }
            THROW_RESCODE(ERR_DUPLICATE_OBJ_IN_LINKED_LIST)
            /* if duplicate keys are allowed in the linked list, we continue to
            insert it. as has done in the search algorithm, item later inserted
            with duplicate key is placed prior to the one sooner inserted,
            indicating the item later added will be sooner found. */
        }
    }
    pOsLinkListNode->prev = last;
    pOsLinkListNode->next = curr;
    if (!last)
    {   /* the item is the first one in the list */
        pOsLinkList->head = pOsLinkListNode;
    }
    else
    {   /* last != NULL */
        last->next = pOsLinkListNode;
    }
    if (curr)
    {
        curr->prev = pOsLinkListNode;
    }

    EXIT_BLOCK()
    if (OK(GET_RESCODE()))
    {
        pOsLinkListNode->linkList = pOsLinkList;
        (pOsLinkList->numEntries)++;
    }
    RETURN_RESCODE
}
