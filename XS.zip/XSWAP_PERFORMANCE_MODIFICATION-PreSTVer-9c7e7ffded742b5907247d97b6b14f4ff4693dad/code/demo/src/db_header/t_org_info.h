/***
Created on May 15, 2017

@author: Zhou
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

 /******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct TOrgInfo {
	int64 org_srno;
	int64 org_id;
	char org_cd[50];
	char org_full_nm_cn[300];
	char org_nm_cn[100];
	char org_full_nm_en[300];
	char org_nm_en[100];
	char org_st[8];
	char org_tp[300];
	char org_irs_st[8];
	char crdt_mthd[8];
	char crdt_upd_mthd[8];
	char crdt_vld_org_f[8];
	OCI_Date *crt_tm;
	char crt_usr_nm[100];
	OCI_Date *upd_tm;
	char upd_usr_nm[100];
	char crdt_oprtng_st[8];
	char crdt_oprtr[100];
	char tel[100];
	char fax_no[100];
	char lgl_rprsntv[300];
	char adrs_frst_desc[300];
	char adrs_scnd_desc[300];
	char brdg_ordr_rfrsh_f[8];
	OCI_Date *last_bil_note_tm;

} TOrgInfo;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

// ResCodeT DbTOrgInfoInsert(TOrgInfo *pData, int32 *pErrCode);
// ResCodeT DbTOrgInfoDelete(int64 key, int32 *pErrCode);
// ResCodeT DbTOrgInfoUpdate(int64 key , TOrgInfo *pData, int32 *pErrCode);
// ResCodeT DbTOrgInfoQuery(int64 key, TOrgInfo *pData, int32 *pErrCode);
ResCodeT DbTOrgInfoGetAll(TOrgInfo *pData, int32 *size, int32 *pErrCode);