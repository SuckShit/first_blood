/***
Created on May 17, 2017

@author: Zhou
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

 /******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct TCrdtCoe {
	int64 cntrct_srno;
	int64 crdt_org_id;
	float crdt_coe;

} TCrdtCoe;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
// ResCodeT DbTCrdtMgnrPrepareQuery();
// ResCodeT DbTCrdtMgnrPrepareUpdate();
// ResCodeT DbTCrdtMgnrUpdate(TCrdtMgnr *pData, int32 *pErrCode);
// ResCodeT DbTCrdtMgnrQuery(int64 crdtOrgId, int64 crdtTdOrgId, TCrdtMgnr *pData, int32 *pErrCode);
ResCodeT DbTCrdtCoeGetAll(TCrdtCoe *pData, int32 *size, int32 *pErrCode);
