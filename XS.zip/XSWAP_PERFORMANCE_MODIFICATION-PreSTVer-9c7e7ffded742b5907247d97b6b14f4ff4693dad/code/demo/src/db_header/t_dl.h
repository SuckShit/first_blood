/***
Created on May 15, 2017

@author: Zhou
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

 /******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct TDeal {
	char dl_id[50];
	char cntrct_nm[50];
	char dl_tp[8];
	char trdng_mthd[8];
	int64 fxd_intrst_bid_org_id;
	char fxd_intrst_bid_trdr[100];
	char fxd_intrst_bid_trdr_nm[300];
	char fxd_intrst_bid_ordr_id[50];
	int64 fxd_intrst_ofr_org_id;
	char fxd_intrst_ofr_trdr[100];
	char fxd_intrst_ofr_trdr_nm[300];
	char fxd_intrst_ofr_ordr_id[50];
	double ntnl_amnt;
	double dl_prc;
	OCI_Date *dl_dt;
	OCI_Date *dl_tm;
	char dl_st[8];
	OCI_Date *crt_tm;
	char crt_usr_nm[100];
	OCI_Date *upd_tm;
	char upd_usr_nm[100];
	char fxd_intrst_bid_org_nm_cn[300];
	char fxd_intrst_ofr_org_nm_cn[300];
	char dl_dir[8];
	char brdg_org_dl_dir[8];
	int64 mkr_org_id;
	char fxd_intrst_bid_org_short_nm_cn[100];
	char fxd_intrst_ofr_org_short_nm_cn[100];
	char fxd_intrst_bid_org_short_nm_en[100];
	char fxd_intrst_ofr_org_short_nm_en[100];
	
} TDeal;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

// ResCodeT DbTDealInsert(TDeal *pData, int32 *pErrCode);
// ResCodeT DbTDealDelete(char *key, int32 *pErrCode);
// ResCodeT DbTDealUpdate(char *key , TDeal *pData, int32 *pErrCode);
// ResCodeT DbTDealQuery(char *key, TDeal *pData, int32 *pErrCode);
ResCodeT DbTDealGetAll(TDeal *pData, int32 *size, int32 *pErrCode);