/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _T_MEM_TXN_
#define _T_MEM_TXN_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "t_common.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct memTxn {

	 int64 txn_id;
	 int64 set_id;
     int64 start_seq_no;
     int64 end_seq_no;
} MemTxnT, *pMemTxnT;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

#ifdef __cplusplus
extern "C"{
#endif
ResCodeT DbMemTxnInsert( MemTxnT *pData, int32 *pErrCode);
ResCodeT DbMemTxnDelete( int64 key, int32 *pErrCode);
ResCodeT DbMemTxnUpdate( int64 key , MemTxnT *pData, int32 *pErrCode);
ResCodeT DbMemTxnQuery(int64 key, MemTxnT *pData, int32 *pErrCode);
#ifdef __cplusplus
}
#endif 

#endif /* _MEM_TXN_HEADER_ */