/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _T_CONTRACT_
#define _T_CONTRACT_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "t_common.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct TContract {
	int64 cntrct_srno;
	char cntrct_nm[28];
	char cntrct_tp[8];
	char mkt_id[8];
	char shrt_cntrct_nm[50];
	char lng_cntrct_nm[50];
	int32  shrt_amnt_ratio;
	int  lng_amnt_ratio;
	int  max_amnt_per_dl;
	int  min_amnt_per_dl;

	int  dl_unit;
	char dl_prc_unit[8];
	int  term;
	char st[8];
	char crt_tm[SIZE_STR+1];
	char crt_usr_nm[100];
	char upd_tm[SIZE_STR+1];
	char upd_usr_nm[100];
	char term_strng[50];
	int  brdg_sort;
} TContract;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT DbTContractInsert( TContract *pData, int32 *pErrCode);
ResCodeT DbTContractContractDelete( int key, int32 *pErrCode);
ResCodeT DbTContractUpdate( int key , TContract *pData, int32 *pErrCode);
ResCodeT DbTContractQuery(int key, TContract *pData, int32 *pErrCode);


#endif /* _DB_HELP_HEADER_ */