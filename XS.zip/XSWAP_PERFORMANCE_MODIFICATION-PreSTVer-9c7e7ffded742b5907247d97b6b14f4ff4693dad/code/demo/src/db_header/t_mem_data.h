/***
Created on May 08, 2017

@author: Brian.Ping
***/

#ifndef _T_MEM_DATA_
#define _T_MEM_DATA_
/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"
#include "t_common.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct memData {

	 int64 sequence_no;
	 int64 set;
	 int64 data_type;
	 void *data;
     unsigned int lengthOfBlob;
}MemDataT, *pMemDataT;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
#ifdef __cplusplus
extern "C"{
#endif
ResCodeT DbMemDataInsert( MemDataT *pData, int32 *pErrCode);
ResCodeT DbMemDataDelete( int64 key, int32 *pErrCode);
ResCodeT DbMemDataUpdate( int64 key , MemDataT *pData, int32 *pErrCode);
ResCodeT DbMemDataQuery(int64 key, MemDataT *pData, int32 *recodernum, int32 *pErrCode);

ResCodeT DbMemDataBatchInsert( int32 rcrdCnt, int * seqNoArry, int * setIdArry, int * dataTypeArry,char *dataCharArry, int32 dataSize);

#ifdef __cplusplus
}
#endif    


#endif /* _MEM_DATA_HEADER_ */