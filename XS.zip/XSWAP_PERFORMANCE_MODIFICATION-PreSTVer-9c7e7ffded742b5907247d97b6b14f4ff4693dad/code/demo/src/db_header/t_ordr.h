/***
Created on May 15, 2017

@author: Zhou
***/

/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "ocilib.h"
#include "../header/data_type.h"
#include "../header/errlib.h"

/*****************************************************************************
 **
 ** Type Defination
 **
 *****************************************************************************/


/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

 /******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
 typedef struct TOrdr {
	char ordr_id[50];
	int64 org_id;
	char ordr_sbmt_tp[8];
	char ordr_tp[8];
	char oco_id[50];
	char cntrct_nm[50];
	double ntnl_amnt;
	double rmng_ntnl_amnt;
	double ordr_prc;
	double ordr_amnt;
	char dl_dir[8];
	char st[8];
	char trdr_nm[100];
	OCI_Date *ordr_crt_tm;
	OCI_Date *ordr_exprd_tm;
	OCI_Date *ordr_actv_tm;
	OCI_Date *upd_tm;
	char upd_usr_nm[100];
	char org_full_nm_cn[300];
	char vrtl_brdg_ordr_f[8];
	char rqst_id[50];
	char usr_lgn_nm_api[100];
	char org_cd[50];
	char bil_id[50];

} TOrdr;


 /*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

// ResCodeT DbTOrdrInsert(TOrdr *pData, int32 *pErrCode);
// ResCodeT DbTOrdrDelete(char *key, int32 *pErrCode);
// ResCodeT DbTOrdrUpdate(char *key , TOrdr *pData, int32 *pErrCode);
// ResCodeT DbTOrdrQuery(char *key, TOrdr *pData, int32 *pErrCode);
ResCodeT DbTOrdrGetAll(TOrdr *pData, int32 *size, int32 *pErrCode);