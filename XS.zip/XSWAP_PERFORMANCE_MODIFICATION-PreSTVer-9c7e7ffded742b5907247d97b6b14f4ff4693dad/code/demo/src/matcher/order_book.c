/***
Created on May 08, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "../header/order_book.h"
#include "../header/osslist.h"
#include "../header/order_type.h"
#include "../header/common_macro.h"
#include "../header/ospoolslot.h"
#include "../header/shm.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/* Product Control Area Type. */
typedef struct PrdctCtrlS
{
    uint32  cntBuy;
    uint32  cntSell;

    ShmSlotIdT     bstBuyO;
    ShmSlotIdT     bstSellO;
    ShmSlotIdT     lstBuyO;
    ShmSlotIdT     lstSellO;

    osSListEntryT prcLderBuyO;
    osSListEntryT prcLderSellO;

    OrdBkSortingT  odrBkSortingType;
   
    uint16 state;
    uint16 statusMask;

    /* the index of the set shared hash table, which stores all heads of linked
    lists of orderNo for the instrument. it will be filled during loading set
    memory */
    uint32 ordrNoListIdx;

    uint32 entyListIdx;

} PrdctCtrlT, *pPrdctCtrlT;

typedef struct OrdBookCtxS
{
    int32       setId;
    PrdctCtrlT * pPrdctCtrl;
    RegListT *  pListRegister;
    RegListT    listRegister;
    p64OsSListEntryT pPrcLderList;
} OrdBookCtxT, *pOrdBookCtxT;

typedef struct OrdBookShmAccessS
{
    int64       memSize;   
    int32       maxOrdCnt;
    int32       maxPrdctCnt;
    pVectorT    pPrdctIdVect;
    PrdctCtrlT * pPrdctCtrlRoot;
    pVectorT    pOrdBookVect;
    pOrderT     pOrdBookRoot;
    int32 ordrNoListCnt;
    int32 entyListCnt;
    p64OsSListEntryT pRtOrdNoSearchVct;
    p64OsSListEntryT pRtEntySearchVct;
} OrdBookShmAccessT, *pOrdBookShmAccessT;

typedef enum
{
    U_LIST = 0,
    UAO_LIST,
    PRICE_LEADER_LIST,
    ENTY_NO_LIST,
    ORDR_NO_LIST
}OrdBkListModeT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static OrdBookShmAccessT gOrdBookShmAccess[MAX_SET_CNT] = {0};
static OrdBookCtxT       gOrdBookCtx = {0};
static PoolSlotT         gSetPoolSlot[MAX_SET_CNT];
static int64             gPooledSlotSize = 500;


static int32 PriceLeaderKeyCmp(pVoidT key1, pVoidT key2);
static int32 TimeOrderKeyCmp(pVoidT key1, pVoidT key2);

static osSListModeT listMode[] = {
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.unrO    ),
    offsetof(OrderT, orderF.ordrEntTim), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   ASCENDING,  1, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.unrAuOaO    ),
    offsetof(OrderT, orderF.ordrEntTim), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   ASCENDING,  1, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(Order4PrcLeadT, orderT.prcLder ),
    offsetof(Order4PrcLeadT, orderF.ordrPri), offsetof(OrderT, orderT.slotNo),
/* price leader always reside in memory */
    PriceLeaderKeyCmp, DESCENDING, 0, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.entyNo),
    offsetof(OrderT, orderF.ordrNo), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   NON_SORTED,  0, 0, NULL, NULL},
{NULL, NULL, sizeof (OrderT), offsetof(OrderT,    orderT.ordNo),
    offsetof(OrderT, orderF.ordrNo), offsetof(OrderT, orderT.slotNo),
    TimeOrderKeyCmp,   NON_SORTED,  0, 0, NULL, NULL}
};




#ifndef NXT_PRC_LDER
#define NXT_PRC_LDER(_pNxtPrcLder_, _set_)\
    do\
    {\
        ShmSlotIdT _nxtPriceLder_ = (_pNxtPrcLder_)->orderT.prcLder.next;\
        if (NON_NULL_SLOT(_nxtPriceLder_))\
        {\
            (_pNxtPrcLder_) = \
                (pOrder4PrcLeadT)&gOrdBookShmAccess[_set_].pOrdBookRoot[_nxtPriceLder_];\
        }\
        else\
        {\
            (_pNxtPrcLder_) = NULL;\
        }\
    } while (0)
#endif
/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

static void UpdateBstLstOrders(pPrdctCtrlT myInstCtrl,
                        BOOL fBuySide, pOrderT pRtOrderbook)
{
    BEGIN_FUNCTION("UpdateBstLstOrders");
    ShmSlotIdT prcLderSlot;
    pOrder4PrcLeadT pPrcLder;

    if (fBuySide)
    {

        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderBuyO.next))
        {
            myInstCtrl->bstBuyO = -1;
        }
        else
        {
            myInstCtrl->bstBuyO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.next;
        }

        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderBuyO.prev))
        {
            myInstCtrl->lstBuyO = -1;
        }
        else
        {
            myInstCtrl->lstBuyO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.prev;
        }
    }
    else
    {
        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderSellO.next))
        {
            myInstCtrl->bstSellO = -1;
        }
        else
        {
            myInstCtrl->bstSellO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.next;
        }

        if (NULL_SLOT_ID(prcLderSlot = myInstCtrl->prcLderSellO.prev))
        {
            myInstCtrl->lstSellO = -1;
        }
        else
        {
            myInstCtrl->lstSellO =
            ((pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot])->orderT.unrAuOaO.prev;
        }
    }

    EXIT_BLOCK();
}

ResCodeT OrdBookGetOrdr( int32 setId, int32 slotId,  pOrderT *pBkOrdr )
{
    BEGIN_FUNCTION( "OrdBookGetOrdr" );
    ResCodeT rc = NO_ERR;
		pOrderT pRtOrderbook =NULL;

    ASSERT(pBkOrdr);
		
		
    pRtOrderbook = gOrdBookShmAccess[setId].pOrdBookRoot;
    *pBkOrdr = &pRtOrderbook[slotId];

    
    EXIT_BLOCK();
    RETURN_RESCODE;
} /* End - OrdBookGetOrdr. */
static ResCodeT CalcuPri4PrcLder(pOrderF4PrcLeadT pPrcLder)
{
    BEGIN_FUNCTION("CalcuPri4PrcLder");

    int32 oSide;
    int64 ordPri;

    oSide = pPrcLder->ordrSide;
    ordPri = pPrcLder->ordrExePrc << 1;
    EXECUTE_ON_COND(ordPri = -ordPri, ORDR_SIDE_SELL == oSide);
    /* MKTOL orders with 0 price should be considered MARKT ones. */
    //todo fix the logic

//     if (MTCH_PRTY_PCT == pPrcLder->odrBkSortingType) 
//     {
//         ordPri ++;
//     }

    /* we can see that for sell side orders, their priority is always
    negative, and zero for market order */
    pPrcLder->ordrPri = ordPri;

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* END - CalcuPri4PrcLder */

static int32 PriceLeaderKeyCmp(pVoidT key1, pVoidT key2)
{
    BEGIN_FUNCTION("PriceLeaderKeyCmp");

    int64 prcDiff = *(uint64 *)key1 - *(uint64 *)key2;

    ASSERT(key1 && key2);
    /* NB: prcDiff is possibly a 64bit positive integer but the return code is
    a long type, and when type cast to long, prcDiff is possibly become a
    negative one! so watch out this! */
    return (int32)(prcDiff ? (prcDiff > 0 ? 1 : -1) : prcDiff);
    EXIT_BLOCK();
}/* END - PriceLeaderKeyCmp */

static int32 TimeOrderKeyCmp(pVoidT key1, pVoidT key2)
{
    BEGIN_FUNCTION("TimeOrderKeyCmp");
    int64 timeDiff = *(uint64 *)key1 - *(uint64 *)key2;

    ASSERT(key1 && key2);

    /* NB: timeDiff is possibly a 64bit positive integer but the return code is
    a int32 type, and when type cast to int32, timeDiff is possibly become a
    negative one! so watch out this! */
    return (int32)(timeDiff ? (timeDiff > 0 ? 1 : -1) : timeDiff);
    EXIT_BLOCK();
}/* END - TimeOrder3KeyCmp */


ResCodeT MapOrdBookShmAccess(int32 setId, pVoidT pRoot, pOrdBookShmAccessT pShmAccess)
{
    BEGIN_FUNCTION("MapOrdBookShmAccess");
    ResCodeT                rc = NO_ERR;
 
    pShmAccess->pPrdctIdVect = (pVectorT)ADDRESS_ADD_OFFSET( pRoot, sizeof(OrdBookShmAccessT));

    pShmAccess->pPrdctCtrlRoot =  (pPrdctCtrlT)ADDRESS_ADD_OFFSET( pShmAccess->pPrdctIdVect, 
                                            GET_BIT_VECT_LEN(pShmAccess->maxPrdctCnt));

    pShmAccess->pOrdBookVect =  (pVectorT)ADDRESS_ADD_OFFSET( pShmAccess->pPrdctCtrlRoot, 
                                            (pShmAccess->maxPrdctCnt* sizeof(PrdctCtrlT)));

    pShmAccess->pOrdBookRoot = (pOrderT)ADDRESS_ADD_OFFSET( pShmAccess->pOrdBookVect, 
                                            GET_BIT_VECT_LEN(pShmAccess->maxOrdCnt));
    
    
    
    
    pShmAccess->pRtOrdNoSearchVct = (p64OsSListEntryT)ADDRESS_ADD_OFFSET( pShmAccess->pOrdBookRoot, 
                                            (sizeof(OrderT)*pShmAccess->maxOrdCnt ));
                                            
                                            
    pShmAccess->pRtEntySearchVct = (p64OsSListEntryT)ADDRESS_ADD_OFFSET( pShmAccess->pRtOrdNoSearchVct, 
                                            (sizeof(osSListEntryT)*pShmAccess->maxPrdctCnt*MAX_ORD_NO_LIST_OF_PRDCT));
                                                                                   
    p64OsSListEntryT pCurrListEnty = pShmAccess->pRtOrdNoSearchVct;
    int32 i = 0;
    int64 elemCnt  = pShmAccess->maxPrdctCnt*MAX_ORD_NO_LIST_OF_PRDCT;
    
    for (i = 0; i < elemCnt; i++)
    {
    	 INIT_STATIC_LIST_ENTRY(pCurrListEnty);
    	 
    	 pCurrListEnty = (p64OsSListEntryT)ADDRESS_ADD_OFFSET(pCurrListEnty, sizeof(osSListEntryT));
    }
    
    pCurrListEnty = pShmAccess->pRtEntySearchVct;
    elemCnt  = pShmAccess->maxPrdctCnt*MAX_ENTY_LIST_OF_PRDCT;
    for (i = 0; i < elemCnt; i++)
    {
    	 INIT_STATIC_LIST_ENTRY(pCurrListEnty);
    	 
    	 pCurrListEnty = (p64OsSListEntryT)ADDRESS_ADD_OFFSET(pCurrListEnty, sizeof(osSListEntryT));
    }
        
    rc =  InitPoolSlot(&gSetPoolSlot[setId], gPooledSlotSize);     
    RAISE_ERROR(rc, RTN);
                                 
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrdBookShmCreate(int32 setId, int32 nmbrOfPrdct, int64 ordBookSize)
{
    BEGIN_FUNCTION("OrdBookShmCreate");
    ResCodeT                rc = NO_ERR;
    pVoidT                  pRoot = NULL;
    pOrdBookShmAccessT      pShmAccess = NULL;
    int32                   shmId = 0;

    int64 prdctAreaSize, ordBookAreaSize, totalMemSize = 0, prdctVectSize =0,ordBookVectSize = 0;
    int64 ordrNoListCntAreaSize, entyListCntAreaSize;

    prdctAreaSize = nmbrOfPrdct * sizeof(PrdctCtrlT);
    ordBookAreaSize = ordBookSize * sizeof(OrderT);

    prdctVectSize = GET_BIT_VECT_LEN(nmbrOfPrdct);
    ordBookVectSize = GET_BIT_VECT_LEN(ordBookSize);
    
    ordrNoListCntAreaSize = sizeof(osSListEntryT)*nmbrOfPrdct*MAX_ORD_NO_LIST_OF_PRDCT;
    
    entyListCntAreaSize = sizeof(osSListEntryT)*nmbrOfPrdct*MAX_ENTY_LIST_OF_PRDCT;

    totalMemSize = sizeof(OrdBookShmAccessT) + prdctVectSize + prdctAreaSize + ordBookAreaSize + ordBookVectSize + ordrNoListCntAreaSize + entyListCntAreaSize;
    
    if (setId == 1)
    {
        shmId = SHM_ID_ORD_BK_ONE;
    }
    else
    {
        shmId = SHM_ID_ORD_BK_TWO;
    }
    
    gOrdBookCtx.setId = setId;
    
    shmCreate((char **)&pRoot, shmId ,totalMemSize);
    
    memset(pRoot, 0x00, totalMemSize);
    
    pShmAccess = (pOrdBookShmAccessT)pRoot;

    pShmAccess->memSize = totalMemSize;
    pShmAccess->maxOrdCnt = ordBookSize;
    pShmAccess->maxPrdctCnt = nmbrOfPrdct;

    memcpy(&gOrdBookShmAccess[setId], pShmAccess, sizeof(OrdBookShmAccessT));

    rc = MapOrdBookShmAccess(setId, pRoot, &gOrdBookShmAccess[setId]);
    RAISE_ERROR(rc, RTN);
    
    int32 prdctId = 0;
    pPrdctCtrlT  pCurrPrdctCtrl = NULL;
    pCurrPrdctCtrl = gOrdBookShmAccess[setId].pPrdctCtrlRoot;
    for (prdctId = 0; prdctId<pShmAccess->maxPrdctCnt; prdctId ++)
    {
    		pCurrPrdctCtrl->cntBuy = 0;
    		pCurrPrdctCtrl->cntSell = 0;
		    pCurrPrdctCtrl->bstBuyO = ODBK_SHM_NO_SLOT;
		    pCurrPrdctCtrl->bstSellO = ODBK_SHM_NO_SLOT;
		    pCurrPrdctCtrl->lstBuyO = ODBK_SHM_NO_SLOT;
		    pCurrPrdctCtrl->lstSellO = ODBK_SHM_NO_SLOT;
				INIT_STATIC_LIST_ENTRY(&pCurrPrdctCtrl->prcLderBuyO);
				INIT_STATIC_LIST_ENTRY(&pCurrPrdctCtrl->prcLderSellO);
    		pCurrPrdctCtrl->odrBkSortingType = 1;
   
		    pCurrPrdctCtrl->state;
		    pCurrPrdctCtrl->statusMask;

	    /* the index of the set shared hash table, which stores all heads of linked
	    lists of orderNo for the instrument. it will be filled during loading set
	    memory */
//	    uint32 ordrNoListIdx;
//	
//	    uint32 entyListIdx;
				pCurrPrdctCtrl =  (pPrdctCtrlT)ADDRESS_ADD_OFFSET( pCurrPrdctCtrl, sizeof(PrdctCtrlT));
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT OrdBookShmAttach(int32 setId)
{
    BEGIN_FUNCTION("OrdBookShmAttach");
    ResCodeT                rc = NO_ERR;
    pVoidT                  pRoot = NULL;
    pOrdBookShmAccessT      pShmAccess = NULL;
    int32                   shmId = 0;

    if (setId == 1)
    {
        shmId = SHM_ID_ORD_BK_ONE;
    }
    else
    {
        shmId = SHM_ID_ORD_BK_TWO;
    }
    gOrdBookCtx.setId = setId;
    shmCreate((char **)&pRoot, shmId ,0);

    memcpy(&gOrdBookShmAccess[setId], pRoot, sizeof(OrdBookShmAccessT));

    rc = MapOrdBookShmAccess(setId, pRoot, &gOrdBookShmAccess[setId]);
    RAISE_ERROR(rc, RTN);
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT OrdBkNextFreeSlot( ShmSlotIdT *oNxtSlt , pOrdBookCtxT pOrdBookCtx)
{
    BEGIN_FUNCTION( "OrdBkNextFreeSlot" );
    ResCodeT rcFNFS = NO_ERR;
    char lckOk = 0;
    int32 bitIdx, startIdx, endIdx;
    ResCodeT rc = NO_ERR;
    pOrderT  oCO;
    BOOL openStatus = TRUE;
    BOOL errStatus = FALSE;
    uint32 firstSlot = NULL_SLOT;
    uint32 lastSlot = NULL_SLOT;

    int32 set = pOrdBookCtx->setId;

		

    pPoolSlotT poolSlot = &gSetPoolSlot[set];
    rc = RequestPoolSlot(poolSlot, (int32*)oNxtSlt);
    TRACE(" Slot %lld RequestPoolSlot, rc %lld" $$ oNxtSlt $$ rc);
    if (ERR_OBK_NOT_ENOUGH_BUFFER == rc)
    {
        int32 slotNo = -1;
        int32 i;

        for (i = 0; i < poolSlot->poolSize; i++)
        {
            BitFindFC(gOrdBookShmAccess[set].pOrdBookVect, slotNo + 1,
                gOrdBookShmAccess[set].maxOrdCnt - 1, &slotNo);
            BREAK_ON_COND(-1 == slotNo);

            oCO = &( gOrdBookShmAccess[set].pOrdBookRoot[slotNo] );
//            if ( CHECK_ORDR_SLOT_OPEN(oCO) )
//            {
//                openStatus = FALSE;
//                /* 一旦出现错误, 设置报错信息标志, 在退出函数调用时留痕 */
//                i--;
//                errStatus = TRUE;
//            }
//            else
//            {
//                SET_ORDR_SLOT_OPEN(oCO);
//            }
            /* 记录第一个申请到的订单簿槽, 在报错时使用 */
            if ( firstSlot == NULL_SLOT )
            {
                firstSlot = slotNo;
            }
            BitSet(gOrdBookShmAccess[set].pOrdBookVect, slotNo);
            

           // TRACE("Slot %lld allocates to pool slot" $$ slotNo);

            /* 当且仅当该订单位置可用时, 才将此位置加入到本地的pool */
            if ( openStatus )
            {
                RAISE_ERROR(AllocPoolSlot(poolSlot, slotNo), RTN);
            }
            /* 否则不做操作, 然后重置可用标记, 但报错留痕 */
            else
            {
                RAISE_ERROR_PARM(ERR_MATCHER_VECTOR_ERR, NORTN,
                        set
                        $$ oCO->orderF.prdctId
                        $$ slotNo
                        $$ oCO->orderT.priceLdr );
                openStatus = TRUE;
            }
        }
        /* 记录第一个申请到的订单簿槽, 在报错时使用 */
        if ( lastSlot == NULL_SLOT )
        {
            lastSlot = slotNo;
        }
        THROW_RESCODE(RequestPoolSlot(poolSlot, (int32*)oNxtSlt));
    }
    else
    {
        TRACE("GetSlotFromPool slot %lld" $$ *oNxtSlt);
        THROW_RESCODE(rc);
    }


    EXIT_BLOCK();
    /* 如果申请过程中出错, 输出此次申请的第一个和最后一个位置 */
//    if (errStatus)
//    {
//        rc = GET_RESCODE();
//        RAISE_ERROR_PARM(ERR_MATCHER_VECTOR_ERR, NORTN,
//                set
//                $$ -1
//                $$ firstSlot
//                $$ lastSlot );
//        SET_RESCODE(rc);
//    }

    if (ERR_OBK_NOT_ENOUGH_BUFFER == GET_RESCODE())
    {
        SET_RESCODE(ERR_OBK_SET_ODRBK_FULL);
    }

    RETURN_RESCODE;
} /* End - OrdBkNextFreeSlot. */

ResCodeT OrderCreate( const int32 prdctId, pOrderT *pOrderCreate)
{
    BEGIN_FUNCTION("OrderCreate");
    ResCodeT rc = NO_ERR;
    int32 set = 0;
    ShmSlotIdT    nextFreeSlot = ODBK_SHM_NO_SLOT;
    pOrderT  oCreateOrd = NULL;
    
    set = GET_SET_ID(prdctId);
    
    if (set != gOrdBookCtx.setId)
    {
        RAISE_ERROR(ERR_INVLD_SET_ID,RTN);
    }

    gOrdBookCtx.pPrdctCtrl = (pPrdctCtrlT)&gOrdBookShmAccess[set].pPrdctCtrlRoot[prdctId];

    /* Get slot no. for new order. */
    rc = OrdBkNextFreeSlot(&nextFreeSlot, &gOrdBookCtx);
    RAISE_ERROR( rc, RTN );

    /* Create order in orderbook. */
    oCreateOrd = &( gOrdBookShmAccess[set].pOrdBookRoot[nextFreeSlot] );

    /* Initialise all the functional fields to their default values. */
    memset(&(oCreateOrd->orderF), 0x00, sizeof (OrderFT));

    /* Numerical, time, qty and prc fields. */

    /* Initialise all the technical fields to their default values. */

    /* OBSS fields. */
    INIT_ORDER_TECH_PART(oCreateOrd);

    /* Sundry fields. */
    oCreateOrd->orderT.slotNo    = nextFreeSlot;   /* Create orders' slot no. */

    /* Set pointer to new order in the Orderbook Memory Area. */
    *pOrderCreate = oCreateOrd;


    EXIT_BLOCK();
    RETURN_RESCODE;   
}


static ResCodeT OrdBkTechConnectOrder(pOrderT pAddO,
                BOOL obssDirty,
                BOOL ordNoDirty,
                BOOL entyDirty,
                pOrder4PrcLeadT pPrcLder,
                p64OsSListEntryT pEntyNoList,
                p64OsSListEntryT pOrdNoList,
                pOrdBookShmAccessT pShmAccess,
                pOrdBookCtxT pCtx)
{
    BEGIN_FUNCTION("OrdBkTechConnectOrder");
    ResCodeT rc = NO_ERR;
    int32 oSide; 
    ResCodeT (*InsertFunc)(const_p64OsSListModeT, p64VoidT, BOOL*, BOOL*,
    p64VoidT*, BOOL, p64ShmSlotIdT);
    ShmSlotIdT prcLderSlot = NULL_SLOT;

    uint32 prdctId = pAddO->orderF.prdctId;

    ASSERT(pAddO);

    if (pPrcLder)
    {
        TRACE("WithPrcLdr ## prdctId:%d|slot:%lld"
            $$ prdctId
            $$ pAddO->orderT.slotNo);
    }
    else
    {
        TRACE("NullPrcLder ## prdctId:%d|slot:%lld"
            $$ prdctId
            $$ pAddO->orderT.slotNo);
    }

    oSide = pAddO->orderF.ordrSide;
    /* if not rollback, add the order to the list tail, while for rollback, add
    the order to the list head */
    InsertFunc = InsertSListEntryFromTail;
    if (pPrcLder)
    {
        prcLderSlot = pPrcLder->orderT.slotNo;
    }

    if (obssDirty)
    {
        
        /* new price leader is ready now. just add it to....*/
        /* special processing of price leader */
        listMode[PRICE_LEADER_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[PRICE_LEADER_LIST].pListHead = pCtx->pPrcLderList;
        listMode[PRICE_LEADER_LIST].theFrame=&pCtx->pListRegister->frmPrcLderList;
        if (IS_EMPTY_PRC_LDER(pPrcLder))
        {
            TRACE("begin insert price leader");
            rc = InsertSListEntryFromHead(&listMode[PRICE_LEADER_LIST],
                pPrcLder, NULL, NULL, NULL, 0, NULL);
        }
        RAISE_ERROR(rc, RTN);

        listMode[U_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[U_LIST].pListHead = &pPrcLder->orderT.unrO;
        listMode[U_LIST].theFrame = &pCtx->pListRegister->frmUList;
        TRACE("begin insert U list with slotNo %05d"
            $$ pAddO->orderT.slotNo);
        rc = InsertFunc(&listMode[U_LIST], pAddO, NULL, NULL, NULL, 0, NULL);
        RAISE_ERROR(rc, RTN);
        
       	listMode[UAO_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[UAO_LIST].pListHead = &pPrcLder->orderT.unrAuOaO;
        listMode[UAO_LIST].theFrame = &pCtx->pListRegister->frmUAOList;
				rc = InsertFunc(&listMode[UAO_LIST], pAddO, NULL, NULL, NULL, 0, NULL);
        RAISE_ERROR(rc, RTN);
        
        /* add reference to the price leader */
        pAddO->orderT.priceLdr = prcLderSlot;
    }/* end obssDirty */

    if (ordNoDirty)
    {
        listMode[ORDR_NO_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[ORDR_NO_LIST].pListHead = pOrdNoList;
        listMode[ORDR_NO_LIST].theFrame = &pCtx->pListRegister->frmOrdrNoList;
        
        rc = InsertSListEntryFromHead(&listMode[ORDR_NO_LIST], pAddO, NULL, NULL,
                NULL, 0, NULL);
        RAISE_ERROR(rc, RTN);
    }

    if (entyDirty)
    {
        listMode[ENTY_NO_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[ENTY_NO_LIST].pListHead = pEntyNoList;
        listMode[ENTY_NO_LIST].theFrame = &pCtx->pListRegister->frmEntyList;
        
        rc = InsertSListEntryFromHead(&listMode[ENTY_NO_LIST], pAddO, NULL, NULL,
                NULL, 0, NULL);
        RAISE_ERROR(rc, RTN);
    }
		TRACE("Tech Connect Order book done");
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkTechConnectOrder */


static ResCodeT OrdBkOrdCntQtyAdjust(int32 ordrSide, int64 qty,
                int64 remPkQty,
                pOrder4PrcLeadT pPrcLder,
                BOOL add,
                pOrdBookCtxT pCtx )
{
    BEGIN_FUNCTION("OrdBkOrdCntQtyAdjust");

    BOOL buySide = ORDR_SIDE_BUY == ordrSide;
    int64 adjustQty, adjustCnt, adjustQty4IceO;

    adjustQty = add ? qty : -qty;
    adjustCnt = add ? 1 : -1;
	
   
    ASSERT(pPrcLder);
    THROW_RESCODE_ON_COND(ERR_OBK_NULL_POINTER, !pPrcLder);
    EXECUTE_ON_2_COND(pCtx->pPrdctCtrl->cntBuy += adjustCnt,
        pCtx->pPrdctCtrl->cntSell += adjustCnt, buySide);
    do
    {


        pPrcLder->orderF.cntUnrO += adjustCnt;
        pPrcLder->orderF.totUnrO += adjustQty;
        BREAK_ON_COND(TRUE);
    } while (0);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkOrdCntQtyAdjust. */

ResCodeT OrderAdd(  pOrderT *ppAddO )
{
    BEGIN_FUNCTION("OrderAdd");
    ResCodeT rc = NO_ERR;
    pOrderT pAddO = NULL;
    ShmSlotIdT slotId;
    int32   set, oSide;
    pOrder4PrcLeadT pPrcLder = NULL;
    p64OsSListEntryT pOrdNoList = NULL;
    p64OsSListEntryT pEntyNoList = NULL;

    pVoidT pRoot = NULL;
    BOOL buySide;


    pAddO = *ppAddO;
    slotId = pAddO->orderT.slotNo;
    oSide = pAddO->orderF.ordrSide;

    int32 prdctId = pAddO->orderF.prdctId;
    
    set = GET_SET_ID(prdctId);
    
    if (set != gOrdBookCtx.setId)
    {
        RAISE_ERROR(ERR_INVLD_SET_ID,RTN);
    }

    gOrdBookCtx.pPrdctCtrl = &gOrdBookShmAccess[set].pPrdctCtrlRoot[prdctId];

    pOrderT pRtOrderbook = (pOrderT)gOrdBookShmAccess[set].pOrdBookRoot;
    pRoot = (pVoidT)pRtOrderbook;

    oSide =  pAddO->orderF.ordrSide;
    buySide = ORDR_SIDE_BUY == oSide;

    gOrdBookCtx.pListRegister = &gOrdBookCtx.listRegister;
    INIT_REG_LIST(gOrdBookCtx.pListRegister);

    /* find the price leader */
    /* firstly initialize a price leader */
    gOrdBookCtx.pPrcLderList = buySide ? &gOrdBookCtx.pPrdctCtrl->prcLderBuyO :
        &gOrdBookCtx.pPrdctCtrl->prcLderSellO;
    ShmSlotIdT prcLderSlot = NULL_SLOT;

    Order4PrcLeadT prcLder;
    pOrder4PrcLeadT pTmpPrcLder = &prcLder;
    INIT_ORDER_TECH_PART((pOrderT)pTmpPrcLder);
    pTmpPrcLder->orderT.slotNo = NULL_SLOT;

    OrdBkSortingT odrBkSortingType = gOrdBookCtx.pPrdctCtrl->odrBkSortingType;
    int64 ordrExePrc = pAddO->orderF.ordrExePrc;
    INIT_PRC_LDER_FUNC_PART(pTmpPrcLder, odrBkSortingType,ordrExePrc,prdctId);

    listMode[PRICE_LEADER_LIST].pRoot = pRoot;
    listMode[PRICE_LEADER_LIST].pListHead = gOrdBookCtx.pPrcLderList;
     /* try to find the insertion position */
    rc = FindSListEntryByKey(&listMode[PRICE_LEADER_LIST],
       &pTmpPrcLder->orderF.ordrPri, (p64VoidT*)&pPrcLder);
    if (ERR_OBJ_NOT_IN_LINKED_LIST == rc)
    {	
        TRACE("Try find price leader");
        RAISE_ERROR(OrdBkNextFreeSlot(&prcLderSlot,&gOrdBookCtx),RTN);
        pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];

        memcpy(pPrcLder, pTmpPrcLder, sizeof (Order4PrcLeadT));
        pPrcLder->orderT.slotNo = prcLderSlot;
        //SET_ORDR_SLOT_OPEN(pPrcLder);

    }
    else
    {
       RAISE_ERROR(rc, RTN);
       prcLderSlot = pPrcLder->orderT.slotNo;

    }

    int32 bucketNo = pAddO->orderF.ordrNo % MAX_ORD_NO_LIST_OF_PRDCT;
    pOrdNoList = &gOrdBookShmAccess[set].pRtOrdNoSearchVct[prdctId + bucketNo];
   
    pEntyNoList = &gOrdBookShmAccess[set].pRtEntySearchVct[prdctId + pAddO->orderF.entyIdxNo];

    TRACE("begin OrdBkTechConnectOrder");

    RAISE_ERROR(OrdBkTechConnectOrder(pAddO, TRUE, TRUE, TRUE, pPrcLder, pEntyNoList, pOrdNoList,&gOrdBookShmAccess[set],
                    &gOrdBookCtx), RTN);

    EXIT_BLOCK();
    if (OK(GET_RESCODE()))
    {
        RAISE_ERROR(OrdBkOrdCntQtyAdjust(oSide, pAddO->orderF.ordrQty,
            pAddO->orderF.remPkQty, pPrcLder, 1, &gOrdBookCtx), NORTN);
        //pRtInstLocatIdx[prdctId].counter++; todo fix this

        UpdateBstLstOrders(gOrdBookCtx.pPrdctCtrl, buySide, gOrdBookShmAccess[set].pOrdBookRoot);

    }
    RETURN_RESCODE;   
}

static ResCodeT OrdBkTechDisconnectOrder(pOrderT pDelO,
                BOOL obssDirty,
                BOOL ordNoDirty,
                BOOL entyDirty,
                pOrder4PrcLeadT pPrcLder,
                p64OsSListEntryT pEntyNoList,
                p64OsSListEntryT pOrdNoList,
                pOrdBookShmAccessT pShmAccess,
                pOrdBookCtxT pCtx)
{
    BEGIN_FUNCTION("OrdBkTechDisconnectOrder");
    ResCodeT rc = NO_ERR;
    ShmSlotIdT prcLderSlot;
 
    unsigned short dbgprdctId = pDelO->orderF.prdctId;


    ASSERT(pDelO);

    if (pPrcLder)
    {
        prcLderSlot = pPrcLder->orderT.slotNo;

        TRACE("DelPrcld ## prdctId:%d|slot:%lld"
            $$ dbgprdctId
            $$ pDelO->orderT.slotNo);
    }
    else
    {
        TRACE("DelOrdSlot ## prdctId:%d|slot:%lld"
            $$ dbgprdctId
            $$ pDelO->orderT.slotNo);
    }

    if (obssDirty)
    {


        listMode[U_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[U_LIST].pListHead = &pPrcLder->orderT.unrO;
        listMode[U_LIST].theFrame = &pCtx->pListRegister->frmUList;
        rc = DelSListEntry(&listMode[U_LIST], pDelO, NULL, NULL);
        RAISE_ERROR(rc, RTN);
        
        listMode[UAO_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[UAO_LIST].pListHead = &pPrcLder->orderT.unrAuOaO;
        listMode[UAO_LIST].theFrame = &pCtx->pListRegister->frmUAOList;
        rc = DelSListEntry(&listMode[UAO_LIST], pDelO, NULL, NULL);
        RAISE_ERROR(rc, RTN);


        listMode[PRICE_LEADER_LIST].pRoot =  (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[PRICE_LEADER_LIST].pListHead = pCtx->pPrcLderList;
        listMode[PRICE_LEADER_LIST].theFrame =
            &pCtx->pListRegister->frmPrcLderList;
        
        if (IS_EMPTY_PRC_LDER(pPrcLder))
        {
            rc = DelSListEntry(&listMode[PRICE_LEADER_LIST], pPrcLder, NULL,
                NULL);
        }
        RAISE_ERROR(rc, RTN);
    }

    if (ordNoDirty)
    {
        listMode[ORDR_NO_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[ORDR_NO_LIST].pListHead = pOrdNoList;
        listMode[ORDR_NO_LIST].theFrame = &pCtx->pListRegister->frmOrdrNoList;
        rc = DelSListEntry(&listMode[ORDR_NO_LIST], pDelO, NULL, NULL);
        RAISE_ERROR(rc, RTN);
    }

    if (entyDirty)
    {
        listMode[ENTY_NO_LIST].pRoot = (p64CharT)pShmAccess->pOrdBookRoot;
        listMode[ENTY_NO_LIST].pListHead = pEntyNoList;
        listMode[ENTY_NO_LIST].theFrame = &pCtx->pListRegister->frmEntyList;
        TRACE("begin delete pbu list");
        rc = DelSListEntry(&listMode[ENTY_NO_LIST], pDelO, NULL, NULL);
        RAISE_ERROR(rc, RTN);
    }

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - OrdBkTechDisconnectOrder */


ResCodeT FreeOrder( pOrderT *pFreeOrder )
{
    ResCodeT rc = NO_ERR;

    BEGIN_FUNCTION( "FreeOrder" );

    int32 set;
    pOrderT  pFreeO;
    ShmSlotIdT oFree;
    ASSERT( pFreeOrder );

    pFreeO = *pFreeOrder;

    set = GET_SET_ID(pFreeO->orderF.prdctId);

    /* Slot no. of order to be freed. */
    oFree = pFreeO->orderT.slotNo;

    pFreeO->orderT.free = 0;

    if (!BitCheck((uint64 *)gOrdBookShmAccess[set].pOrdBookRoot, oFree))
    {
        TRACE("slotno:%lld" $$ oFree);
        RAISE_ERROR_PARM(ERR_OBK_FREEORDER_FAIL, NORTN, oFree);
        return NO_ERR;
    }
    // RESET_ORDR_SLOT_OPEN(pFreeO);
    BitReset((uint64 *)gOrdBookShmAccess[set].pOrdBookRoot, oFree);

    /* 确保将删除的订单free位一定是1 */
    pFreeO->orderT.free = 1;

    /* Free order pointer should no longer exist. */
    *pFreeOrder = NULL;

    EXIT_BLOCK();

    RETURN_RESCODE;
} /* End - FreeOrder. */


ResCodeT OrderDelete( pOrderT *pDelOrder,
                const int64 tranTime)
{
    BEGIN_FUNCTION("OrderDelete");
    ResCodeT rc = NO_ERR;
    pOrderT pDelO;
    ShmSlotIdT prcLderSlot = NULL_SLOT, modBucket = NULL_SLOT;
    pOrder4PrcLeadT pPrcLder = NULL;
    p64OsSListEntryT pOrdNoList = NULL;
    p64OsSListEntryT pEntyNoList = NULL;
    int32 setId = 0;
    int32 oSide = 0;
    BOOL    buySide;
    char obssDirty, ordNoDirty;
    pPrdctCtrlT instCtrl = NULL;
    pOrderT pRtOrderbook = NULL;


    ASSERT(pDelOrder);

    pDelO = *pDelOrder;
    prcLderSlot = pDelO->orderT.priceLdr;
		int32 prdctId= pDelO->orderF.prdctId;
    setId = GET_SET_ID(pDelO->orderF.prdctId);
    
    if (setId != gOrdBookCtx.setId)
    {
        RAISE_ERROR(ERR_INVLD_SET_ID,RTN);
    }
    
 
    pRtOrderbook = gOrdBookShmAccess[setId].pOrdBookRoot;
    oSide  = pDelO->orderF.ordrSide;
    buySide = ORDR_SIDE_BUY == oSide;
    instCtrl = gOrdBookCtx.pPrdctCtrl;


    int32 bucketNo = pDelO->orderF.ordrNo % MAX_ORD_NO_LIST_OF_PRDCT;
    pOrdNoList = &gOrdBookShmAccess[setId].pRtOrdNoSearchVct[prdctId + bucketNo];
   
    pEntyNoList = &gOrdBookShmAccess[setId].pRtEntySearchVct[prdctId + pDelO->orderF.entyIdxNo];

    TRACE("begin OrdBkTechConnectOrder");
    

    gOrdBookCtx.pListRegister = &gOrdBookCtx.listRegister;
    INIT_REG_LIST(gOrdBookCtx.pListRegister);


    TRACE("FindPrcLdr ## prdctId:%d|setId:%d|prcLderSlot:%lld|ordSlot:%lld"
            $$ pDelO->orderF.prdctId $$ setId
            $$ prcLderSlot $$ pDelO->orderT.slotNo);

    /* find the price leader */
    prcLderSlot = pDelO->orderT.priceLdr;
    pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];
    gOrdBookCtx.pPrcLderList = buySide ? &instCtrl->prcLderBuyO :
        &instCtrl->prcLderSellO;

    pDelO->orderF.tranTime = tranTime;

    RAISE_ERROR(OrdBkTechDisconnectOrder(pDelO, TRUE, TRUE,
        TRUE, pPrcLder, pEntyNoList, pOrdNoList, &gOrdBookShmAccess[setId],&gOrdBookCtx), RTN);

    EXIT_BLOCK();

    if (OK(GET_RESCODE()))
    {
        RAISE_ERROR(OrdBkOrdCntQtyAdjust(oSide, pDelO->orderF.ordrQty,
            pDelO->orderF.remPkQty, pPrcLder, 0, &gOrdBookCtx), NORTN);
        /*free the slot occupied by the deleted order and update information .*/
        //todo fix this logic, what is counter?
        //pRtInstLocatIdx[prdctId].counter++;

        RAISE_ERROR(FreeOrder(pDelOrder), NORTN);
        if (pPrcLder && IS_EMPTY_PRC_LDER(pPrcLder))
        {

            RAISE_ERROR(FreeOrder((pOrderT *)&pPrcLder), NORTN);
        }

        UpdateBstLstOrders(instCtrl, buySide, gOrdBookShmAccess[setId].pOrdBookRoot);
    }
    
    RETURN_RESCODE;
}/* End - OrderDelete */

ResCodeT GetBest( const int32 prdctId, int32 oSide, pOrderT *pBestO )
{
    BEGIN_FUNCTION( "GetBest" );
    ResCodeT rc = NO_ERR;
    BOOL buySide;
    int32 set;
    ShmSlotIdT slotId = NULL_SLOT, priceLder = NULL_SLOT;
    pOrderT pRtOrderbook = NULL;
    pOrder4PrcLeadT pPrcLder = NULL;
    pPrdctCtrlT instCtrl = NULL;


    ASSERT(pBestO);

    set = GET_SET_ID(prdctId);
    
    if (set != gOrdBookCtx.setId)
    {
        RAISE_ERROR(ERR_INVLD_SET_ID,RTN);
    }
    

    pRtOrderbook = gOrdBookShmAccess[set].pOrdBookRoot;
    instCtrl = gOrdBookCtx.pPrdctCtrl;

    buySide = ORDR_SIDE_BUY == oSide;

    /* No best order yet, return NULL pointer. */
    *pBestO = NULL;

    priceLder = buySide ? instCtrl->prcLderBuyO.next :
        instCtrl->prcLderSellO.next;
    EXECUTE_ON_COND(pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[priceLder],
        NON_NULL_SLOT(priceLder));

    while (pPrcLder)
    {

        /* U list */
        slotId = pPrcLder->orderT.unrO.next;

        BREAK_ON_COND(NON_NULL_SLOT(slotId));
        NXT_PRC_LDER(pPrcLder,set);
    }

    EXIT_BLOCK();

    if (OK(GET_RESCODE()) && NON_NULL_SLOT(slotId))
    {
        *pBestO = &pRtOrderbook[slotId];

        if ( prdctId != 0 && prdctId != (*pBestO)->orderF.prdctId )
        {
            RAISE_ERROR_PARM(ERR_MATCHER_BST_ORD_ERR, NORTN,
                set $$ prdctId $$ (*pBestO)->orderF.prdctId $$ slotId);
        }
    }
    RETURN_RESCODE;
} /* End - GetBest. */



ResCodeT GetBstGrp(const int32 prdctId,
                const int32 oSide,
                pBstGrpT pBstGrp)
{
    BEGIN_FUNCTION("GetBstGrp");
    ResCodeT rc = NO_ERR;
    ShmSlotIdT prcLderSlot = NULL_SLOT;
    pOrder4PrcLeadT pPrcLder = NULL;
    int16 offset, ordrSide;
    int32 setId;
    pPrdctCtrlT instCtrl;
    pOrderT pRtOrderbook;

    ASSERT(pBstGrp);

    setId = GET_SET_ID(prdctId);
    
    instCtrl = gOrdBookCtx.pPrdctCtrl;
    memset(pBstGrp, 0x00, sizeof (BstGrpT));
    pRtOrderbook = gOrdBookShmAccess[setId].pOrdBookRoot;

    offset = 0;



    /* 0 for buy side and 1 for sell side */
    ordrSide = ORDR_SIDE_SELL == oSide;
    do
    {
        /* get best group */
        prcLderSlot = ((&instCtrl->prcLderBuyO)[ordrSide]).next;
        if (NON_NULL_SLOT(prcLderSlot))
        {
            pPrcLder = (pOrder4PrcLeadT)&pRtOrderbook[prcLderSlot];
            if (!pPrcLder->orderF.ordrExePrc)
            {
                (&pBstGrp->bstBuyMktQty)[ordrSide] =
                    (&pPrcLder->orderF.totUnrO)[offset];
                NXT_PRC_LDER(pPrcLder,setId);
            }
            /*we only interest in particular trading restrictions*/
            while (pPrcLder && !(&pPrcLder->orderF.totUnrO)[offset] )
            {
                NXT_PRC_LDER(pPrcLder,setId);
            }
            if (pPrcLder)
            {
                (&pBstGrp->bstBuyLmtPrc)[ordrSide] =
                    pPrcLder->orderF.ordrExePrc;
                (&pBstGrp->bstBuyLmtQty)[ordrSide] =
                    (&pPrcLder->orderF.totUnrO)[offset];
                NXT_PRC_LDER(pPrcLder,setId);
            }
            /* it's possible that next price leader with the same limit price
            while lower priority because of PQT/PT sorting configuration. */
            if (pPrcLder &&
                (&pBstGrp->bstBuyLmtPrc)[ordrSide] ==
                 pPrcLder->orderF.ordrExePrc                &&
                (&pPrcLder->orderF.totUnrO)[offset] )
            {
                (&pBstGrp->bstBuyLmtQty)[ordrSide] +=
                    (&pPrcLder->orderF.totUnrO)[offset];
            }
        }
        ordrSide = !ordrSide;
    } while (ORDR_SIDE_NONE == oSide && ordrSide);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End - GetBstGrp */


ResCodeT GetBstPrc(    int32            prdctId,
    int32            buySellSide,
                   pBstGrpT       pBstGrp)
{
    BEGIN_FUNCTION("GetBstPrc");
    ResCodeT        rc = NO_ERR;

    rc = GetBstGrp(prdctId, buySellSide, pBstGrp);
    RAISE_ERROR(rc, RTN);
    RETURN_RESCODE;

    EXIT_BLOCK();
}


static ResCodeT OrdBkUpdOrdExeQty ( pOrderFT pUpdO,
                                    pOrder4PrcLeadT pPrcLder,
                                    int64 exeQty )
{
    BEGIN_FUNCTION ( "OrdBkUpdOrdExeQty" );

    int64 tmpQty;

    tmpQty = pUpdO->ordrQty - pUpdO->remPkQty;
    pUpdO->ordrExeQty += exeQty;
    pUpdO->ordrQty -= exeQty;


    pPrcLder->orderF.totUnrO -= exeQty;
        

    EXIT_BLOCK();
    RETURN_RESCODE;
}                               /* End - OrdBkUpdOrdExeQty */

ResCodeT OrdBkModOrdrQty ( pOrderT modOrdr,
                            int64 exeQty,
                            int64 tranTime)
{
    BEGIN_FUNCTION ( "OrdBkModOrdrQty" );
    pOrder4PrcLeadT pPrcLder = NULL;
    ShmSlotIdT prcLderSlot = NULL_SLOT;
    pOrderT pRtOrderbook = NULL;
    

    ASSERT( modOrdr );

    int32 prdctId = modOrdr->orderF.prdctId;
    int32 setId = GET_SET_ID(prdctId);
  

    pRtOrderbook = gOrdBookShmAccess[setId].pOrdBookRoot;

    prcLderSlot = modOrdr->orderT.priceLdr;
    pPrcLder = ( pOrder4PrcLeadT ) & pRtOrderbook[prcLderSlot];
    
    /* change the order */
    modOrdr->orderF.tranTime = tranTime;
    RAISE_ERROR ( OrdBkUpdOrdExeQty ( &modOrdr->orderF, pPrcLder, exeQty ),
                        RTN );

    EXIT_BLOCK();
    RETURN_RESCODE;
}                               /* End - OrdBkModOrdrQty */


ResCodeT OrdBkUpdOrdQty ( pOrderFT oldOrdr,
                            pOrder4PrcLeadT pPrcLder,
                             pOrderFT newOrdr)
{
    BEGIN_FUNCTION ( "OrdBkUpdOrdQty" );
  	
  	int64 qtyChg;
  	qtyChg = newOrdr->ordrQty - oldOrdr->ordrQty;
  	
  	pPrcLder->orderF.totUnrO += qtyChg; 

    EXIT_BLOCK();
    RETURN_RESCODE;
}                               /* End - OrdBkModOrdrQty */


//
//static void UpdateBstLstOrders(pPrdctCtrlT myInstCrtl, BOOL fBuySide, pOrderT pOrdBkRoot)
//{
//		BEGIN_FUNCTION ( "UpdateBstLstOrders" );
//		
//		ShmSlotIdT 	prcLderSlot;
//		pOrder4PrcLeadT pPrcLder = NULL;
//		
//		
//		if (fBuySide)
//		{
//				if (NULL_SLOT_ID(prcLderSlot = myInstCrtl->prcLderBuyO.next))
//				{
//					myInstCrtl->bstBuyO = -1;
//				}
//				else
//				{
//					myInstCrtl->bstBuyO = ((pOrder4PrcLeadT)pOrdBkRoot[prcLderSlot])->orderT.unrO.next;
//				}
//				
//				if (NULL_SLOT_ID(prcLderSlot = myInstCrtl->prcLderBuyO.prev))
//				{
//					myInstCrtl->bstBuyO = -1;
//				}
//				else
//				{
//					myInstCrtl->bstBuyO = ((pOrder4PrcLeadT)pOrdBkRoot[prcLderSlot])->orderT.unrO.prev;
//				}
//				
//		}
//		else
//		{
//				if (NULL_SLOT_ID(prcLderSlot = myInstCrtl->prcLderSellO.next))
//				{
//					myInstCrtl->bstSellO = -1;
//				}
//				else
//				{
//					myInstCrtl->bstSellO = ((pOrder4PrcLeadT)pOrdBkRoot[prcLderSlot])->orderT.unrO.next;
//				}
//				
//				if (NULL_SLOT_ID(prcLderSlot = myInstCrtl->prcLderSellO.prev))
//				{
//					myInstCrtl->bstSellO = -1;
//				}
//				else
//				{
//					myInstCrtl->bstSellO = ((pOrder4PrcLeadT)pOrdBkRoot[prcLderSlot])->orderT.unrO.prev;
//				}
//				
//		}
//		
//		EXIT_BLOCK();
//    RETURN_RESCODE;
//    
//}

ResCodeT OrdBkModOrdr ( pOrderT * pOldOrdr,
                        pOrderFT pNewOrdr)
{
    BEGIN_FUNCTION ( "OrdBkModOrdr" );
    ResCodeT rc = NO_ERR;
    pOrderT oldOrdr = NULL;
    char entTimDirty = 0, trdResDirty = 0, prcDirty = 0, ordNoDirty = 0,
        qtyDirty = 0, obssDirty = 0, remQtyDirty = 0;
   
    ShmSlotIdT oModBucket = NULL_SLOT, nModBucket = NULL_SLOT,
        slotId = NULL_SLOT, prcLderSlot = NULL_SLOT, newPrcLderSlot = NULL_SLOT;
    p64OsSListEntryT pOrdNoList = NULL, pNewOrdNoList = NULL;

    p64OsSListEntryT pPbuNoList = NULL, pNewPbuNoList = NULL;

    pOrder4PrcLeadT pPrcLder = NULL, pNewPrcLder = NULL;

    ASSERT( pOldOrdr && pNewOrdr );
    oldOrdr = *pOldOrdr;
    
    int32 ordrSide = oldOrdr->orderF.ordrSide;
    int32 prdctId = pNewOrdr->prdctId;
    int32 buySide = ORDR_SIDE_BUY == ordrSide;

    /* NB: change of any of the following 4 flags will result in the change of
       the order's position on the linked lists of orderbook */
    entTimDirty = oldOrdr->orderF.ordrEntTim != pNewOrdr->ordrEntTim;
    /* NB: cases for change of price leader */
    /* 1. orders with NON-FP trade restriction: price change */
    /* 2. orders with FP trdRes change to NON-FP trdRes */
    prcDirty = oldOrdr->orderF.ordrExePrc != pNewOrdr->ordrExePrc;
    ordNoDirty = oldOrdr->orderF.ordrNo != pNewOrdr->ordrNo;
    qtyDirty = oldOrdr->orderF.ordrQty > pNewOrdr->ordrQty ||
        oldOrdr->orderF.remPkQty != pNewOrdr->remPkQty ||
        ( oldOrdr->orderF.ordrQty - oldOrdr->orderF.remPkQty ) !=
        ( pNewOrdr->ordrQty - pNewOrdr->remPkQty );
    obssDirty = entTimDirty || prcDirty;

    /* set the context of order book lib */
    int32 setId = GET_SET_ID(prdctId);
    
    pOrderT pRtOrderbook = gOrdBookShmAccess[setId].pOrdBookRoot;
    
    gOrdBookCtx.pPrdctCtrl = &gOrdBookShmAccess[setId].pPrdctCtrlRoot[prdctId];
    
    
    p64CharT pRoot = ( p64CharT ) pRtOrderbook;
    gOrdBookCtx.pPrcLderList = buySide ? &gOrdBookCtx.pPrdctCtrl->prcLderBuyO : &gOrdBookCtx.pPrdctCtrl->prcLderSellO;

    prcLderSlot = oldOrdr->orderT.priceLdr;
    pPrcLder = ( pOrder4PrcLeadT ) & pRtOrderbook[prcLderSlot];


    if ( !obssDirty && !ordNoDirty )
    {
        if ( qtyDirty )
        {
            RAISE_ERROR ( OrdBkUpdOrdQty ( &oldOrdr->orderF, pPrcLder,
                                                pNewOrdr ), RTN );
        }
        /* change the order.... */
        memcpy ( &oldOrdr->orderF, pNewOrdr, sizeof ( OrderFT ) );
        THROW_RESCODE ( NO_ERR );
    }

    /* store frame data for roll back purpose */
    if ( prcDirty )
    {
  
//            newPrcLderSlot = pMlModOrdr->newPrcLder;
//            pNewPrcLder = ( pOrder4PrcLeadT ) & pRtOrderbook[newPrcLderSlot];
//            if ( pMlModOrdr->fNewPrcLder )
//            {
//                if ( CHECK_ORDR_SLOT_OPEN ( pNewPrcLder ) )
//                {
//                    RAISE_ERROR_PARM ( ERR_MATCHER_VECTOR_ERR, RTN,
//                                        setId
//                                        $$ pNewPrcLder->orderF.isix
//                                        $$ newPrcLderSlot
//                                        $$ pNewPrcLder->orderT.priceLdr );
//                    SET_RESCODE ( NO_ERR );
//                }
//                SET_ORDR_SLOT_OPEN ( pNewPrcLder );
//                BitSet ( vSetShm[setId].pRtOrdBkVect, newPrcLderSlot );
//                vSetShm[setId].pRtOrdBkVectIdx->usedMem++;
//                INIT_ORDER_TECH_PART ( pNewPrcLder );
//                pNewPrcLder->orderT.slotNo = newPrcLderSlot;
//                INIT_PRC_LDER_FUNC_PART ( pNewPrcLder,
//                                            instCtrl->odrBkSortingType, newMask,
//                                            pNewOrdr->ordrExePrc, isix );
//            }
    }
    else
    {
        /* price leader not changed, but still need to provide one! */
            newPrcLderSlot = prcLderSlot;
            pNewPrcLder = pPrcLder;
    }

                    
    if ( ordNoDirty )
    {
        
        int32 oldBucketNo = oldOrdr->orderF.ordrNo % MAX_ORD_NO_LIST_OF_PRDCT;
        int32 newBucketNo = pNewOrdr->ordrNo % MAX_ORD_NO_LIST_OF_PRDCT;

        pOrdNoList =
            &gOrdBookShmAccess[setId].pRtOrdNoSearchVct[prdctId + oldBucketNo];
        pNewOrdNoList =
            &gOrdBookShmAccess[setId].pRtOrdNoSearchVct[prdctId + newBucketNo];

    }

    gOrdBookCtx.pListRegister = &gOrdBookCtx.listRegister;
    INIT_REG_LIST ( gOrdBookCtx.pListRegister );
    INIT_REG_LIST ( gOrdBookCtx.pListRegister + 1 );
   
    /* disconnect the order from the OBSS and other related lists. */
    RAISE_ERROR ( OrdBkTechDisconnectOrder ( oldOrdr, TRUE, TRUE,
                        TRUE,  pPrcLder,
                        NULL, pOrdNoList, &gOrdBookShmAccess[setId],&gOrdBookCtx ), RTN );
    /*no PBU change in order modify */
    if ( obssDirty )
    {
        /* need to update inside market information . */
        RAISE_ERROR ( OrdBkOrdCntQtyAdjust
                            ( ordrSide, oldOrdr->orderF.ordrQty,
                                oldOrdr->orderF.remPkQty, pPrcLder, 0 ,&gOrdBookCtx), RTN );

        EXECUTE_ON_COND ( RAISE_ERROR ( FreeOrder ( ( pOrderT * ) &
                                                        pPrcLder ), RTN ),
                            pPrcLder && pNewPrcLder != pPrcLder
                            && IS_EMPTY_PRC_LDER ( pPrcLder ) );
    }

    /* connect the order to OBSS and other related lists. */
    /* change the functional part of the order */
    memcpy ( &oldOrdr->orderF, pNewOrdr, sizeof ( OrderFT ) );
    gOrdBookCtx.pListRegister = &gOrdBookCtx.listRegister;
    RAISE_ERROR ( OrdBkTechConnectOrder ( oldOrdr, TRUE, TRUE,
                        TRUE, pNewPrcLder,
                        NULL, pNewOrdNoList, &gOrdBookShmAccess[setId],
                    &gOrdBookCtx ), RTN );
    if ( obssDirty )
    {
        /* need to update inside market information. */
        RAISE_ERROR ( OrdBkOrdCntQtyAdjust
                            ( ordrSide, oldOrdr->orderF.ordrQty,
                                oldOrdr->orderF.remPkQty,
                                pNewPrcLder, 1 , &gOrdBookCtx), RTN );
    }

    UpdateBstLstOrders ( gOrdBookCtx.pPrdctCtrl, buySide, gOrdBookShmAccess[setId].pOrdBookRoot );

    EXIT_BLOCK();
    RETURN_RESCODE;
}                               /* End - OrdBkModOrdr */