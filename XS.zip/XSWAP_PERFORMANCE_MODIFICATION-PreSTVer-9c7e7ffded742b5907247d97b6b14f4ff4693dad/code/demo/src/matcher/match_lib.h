/***
Created on May 13, 2017

@author: Brian.Ping
***/

#ifndef _MATCH_LIB_
#define _MATCH_LIB_



/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header files*/
#include "../header/data_type.h"
#include "../header/osslist.h"
#include "../header/errlib.h"
#include "../header/order_type.h"
#include "../db_header/t_crdt_coe.h"

/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/
/*command code*/
#define ACTN_ADD_CMD     0x0
#define ACTN_CHG_CMD     0x1
#define ACTN_DEL_CMD     0x2
#define ACTN_BOOK_CMD    0x3
#define ACTN_CNCL_CMD    0x4
#define ACTN_CMD_COD_MSK 0X7   /*command code MASK*/
        
/* maintenance code*/
#define ACTN_ADD_MNT     0x0
#define ACTN_CHG_MNT     0x8
#define ACTN_DEL_MNT     0x10
#define ACTN_MATCH_MNT   0x18
#define ACTN_PRT_FIL_MNT 0x20
#define ACTN_CANCEL_MNT  0x28
#define ACTN_EXE_MNT     0x30
#define ACTN_TRG_MNT     0x38
#define ACTN_INSERT_MNT  0x40
/*** SIR R2020 BEGIN */
#define ACTN_STACHG_MNT  0x48
/*** SIR R2020 END */
#define ACTN_MAINT_MSK   0x78  /* maintenance code MASK*/

/* audit trail flag*/
#define ACTN_AUD_YES     0x0
#define ACTN_AUD_NO      0x80
#define ACTN_AUD_MSK     0X80  /* audit trail flag MASK*/

/* order confirmation flag*/
#define ACTN_CONF_ORDER    0x0
#define ACTN_CONF_QUOTE  0x100
#define ACTN_CONF_NO     0x200
#define ACTN_CONF_MSK    0x300 /* order confirmation flag MASK*/ 

/*physical order book flag*/
#define ACTN_ORDR_BK_YES 0x0
#define ACTN_ORDR_BK_NO  0x400
#define ACTN_ORDR_BK_MSK 0x400 /* physical order book flag MASK*/ 

/* Return a specific attribute from actn mask. */
#define GET_ACTN_CMD( aMask ) ( ( aMask ) & ACTN_CMD_COD_MSK )
#define GET_ACTN_MAINT( aMask ) ( ( aMask ) & ACTN_MAINT_MSK )
#define GET_ACTN_ADTTRL( aMask ) ( ( aMask ) & ACTN_AUD_MSK )
#define GET_ACTN_ORDRCFM( aMask ) ( ( aMask ) & ACTN_CONF_MSK )
#define GET_ACTN_ORDR_BK( aMask ) ( ( aMask ) & ACTN_ORDR_BK_MSK )

#define WKSG_LIT_NO_MTCH                  ' '    /* No match code */
#define WKSG_LIT_PRT_FIL                  'P'    /* Order partially filled */
#define WKSG_LIT_FULL_MTCH                'F'    /* Order fully matched */

/* Bit flag Trading Restriction. */
#define ORDR_TRDRESTR_OA  0x0           /* Opening Auction Only. */
#define ORDR_TRDRESTR_AU  0x10          /* Auction Only. */
#define ORDR_TRDRESTR_SU  0x20          /* Accept Surplus. */
#define ORDR_TRDRESTR_FP  0x30          /* Fixed Price. */
#define ORDR_TRDRESTR_NO  0x40          /* None. */
#define ORDR_TRDRESTR_MSK 0x70          /* Trading Restriction mask. */

#define DATA_TYPE_OC 1          /* Order Confirmation */
#define DATA_TYPE_TC 2          /* Trade Confirmation */


#define MAX_BRDG_ORDR_CNT 1000
#define BRDG_FEE 1   

#define BRDG_CASE_TYPE_TWO_WAY 2
#define BRDG_CASE_TYPE_ONE_WAY 1
/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

typedef struct rymtchTag
{
    uint64      ordrNoOld;
    int64       tradePrc;
    uint64      actnSeqNum;
    char      ordrPrtFilCod;
    char      filler[7];
} rymtchT, *pRymtchT;

typedef struct HoldTag
{
    int16 bstBkPrc;       /* ���������Ŷ����۸� */
    int16 mktQty;         /* �м۶������� */
    int16 lstTrdQty;      /* �ϱȳɽ����� */
    int16 trdPrc;         /* �ɽ��۸� */
    int16 mtchId;         /* ������к� */
    int16 totalTrdQty;    /* �ܼƳɽ�����*/
    int16 totalNumOfTrd;  /* �ܼƳɼ�����*/
    int16 trnover;        /* �ܼƳɽ����*/
} HoldT;


typedef struct BrdgOrdrElemS
{
    int64       ordrExePrc;
    int32       ordrSide;
    int32       prdctId;
    int64       ordrQty;
		int64       ordrNo;
    int32				entyIdx;
    int32				brdgFee;
    int32				slotId;
    int32				filler;
} BrdgOrdrElemT;

typedef struct BrdgOrdrInfoS
{
    int64						    caseType;
    BrdgOrdrElemT       buyBrdgOrdr;
    BrdgOrdrElemT       sellBrdgOrdr;;
} BrdgOrdrInfoT;

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static BrdgOrdrInfoT gBrdgOrdrList[MAX_BRDG_ORDR_CNT]  = {0};
static int32				gBrdgOrdrCnt = 0;

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
ResCodeT OrderAdd(  pOrderT *ppAddO );

ResCodeT OrdBookShmAttach(int32 setId);

ResCodeT OrdBookShmCreate(int32 setId, int32 nmbrOfPrdct, int64 ordBookSize);

ResCodeT OrderCreate( const int32 prdctId, pOrderT *pOrderCreate);

ResCodeT OrderDelete( pOrderT *pDelOrder,
                const int64 tranTime);

ResCodeT GetBest( const int32 prdctId, int32 oSide, pOrderT *pBestO );

ResCodeT DoCreateOrder(pOrderT pOrder, pOrderT * ppOrder);

ResCodeT CreateCoeHash();
ResCodeT GetCoe(TCrdtCoe* pCoe,TCrdtCoe* pCoe2);


ResCodeT PrcsOrdrBrdgReq(int64 timestamp);

#endif /* _MATCH_LIB_ */
