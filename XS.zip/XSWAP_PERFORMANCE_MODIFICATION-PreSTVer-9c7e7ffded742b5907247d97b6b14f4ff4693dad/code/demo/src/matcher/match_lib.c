/***
Created on May 13, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "../header/order_book.h"
#include "../header/osslist.h"
#include "../header/order_type.h"
#include "../header/common_macro.h"
#include "../header/order_book.h"
#include "../header/shm.h"
#include "../header/msg.h"
#include "../header/credit_lib.h"
#include "match_lib.h"
#include "../header/hash_table.h"
//#include "../db_header/t_crdt_coe.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/
typedef struct MaintFlagTag
{
    char prcModFlg;     //价格修改标签
    char scopeIncrFlg;  // 订单属性修改标签
    char mktblFlg;      // 可转市价标签
    char ordrWrtblFlg;  // 订单可入订单簿标签
}MaintFlagT, *pMaintFlagT;


typedef struct MatcherAccessS {
    int32 setId;
    int32 blockOrdersNumber;              /* 主撮合器MP处理订单数 */
    float sleepTime;                    /* 主撮合器无订单空跑时间 */
    int32 maxEventsInOnePhase;            /* 主撮合器MP最大事件数 */
    int32 execRestr;                      /* 执行限制标签 */
    int32 maxOrderInAuction;             /* 集合竞价最大订单数 */
    BOOL techTraceEnable;
    int32 filler;    
} MatcherAccessT;


typedef struct MaintTag
{
    BOOL partialFill;       /* 是否部分撮合 */
    char marketable;        /* 是否可以报价转市价? */
    char filler[3];
} MaintT;

typedef struct InstitutionS
{   
    int64 entyId;
    int64  brdgFee;
} InstitutionT, *pInstitutionT;

#define BRDG_ENTY_IDX_NO 3
/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/
static int32 gOrdrNo[MAX_PRDCT_CNT] = {0};

static int32 gTrdrNo[MAX_PRDCT_CNT] = {0};

static MatcherAccessT gMatcherAccess = {0}; //todo

static gOldNumber = 0;
HashTableT gCoeHashTable;
char*   gpCrditCoeShm;

static InstitutionT gEntyLst[4] = { {1,1}, {2,1}, {3,1}, {4,1}};

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/

ResCodeT TxnAddOrdr ( pOrderT * ordr,
                        uint16 actnMask,
                        pRymtchT rymtch );
ResCodeT TxnLogOrdr ( pOrderT ordr,
                        uint16 actnMask,
                        pRymtchT rymtch );
static ResCodeT DoCheckCredit ( pOrderT pBuyOrder, pCrdtMsgT pBuyCredit,
                                pOrderT pSellOrder, pCrdtMsgT pSellCredit);
static ResCodeT DoUpdateCredit (pCrdtMsgT pBuyCredit,
                                pCrdtMsgT pSellCredit);								
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
ResCodeT DoCreateOrder(pOrderT pOrder, pOrderT * ppOrder)
{
    BEGIN_FUNCTION("DoCreateOrder");
    ResCodeT                rc = NO_ERR;
    
    pOrderT pTempOrder = NULL;
    
    rc = OrderCreate( pOrder->orderF.prdctId, &pTempOrder);
    RAISE_ERROR(rc, RTN);
    
    if (pTempOrder)
    {
        memcpy(&pTempOrder->orderF, &pOrder->orderF, sizeof(OrderFT));
        
        * ppOrder = pTempOrder;
    }
    else
    {
        RAISE_ERROR(ERR_OBK_SET_ODRBK_FULL, RTN);
    }
    
    
    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT CheckOrderMarketable(pOrderT pOrder, char *mktblFlg,
                                int64 * pTranTime )
{
    BEGIN_FUNCTION("CheckOrderMarketable");
    ResCodeT                rc = NO_ERR;
    int32 buySellSide;
    int32 ordrSide = pOrder->orderF.ordrSide;
    BstGrpT bstGrp;
    int32 prdctId = pOrder->orderF.prdctId;
    
    /* orderbook 最优价格组 */
    if ( ordrSide == ORDR_SIDE_BUY )
    {
        buySellSide = ORDR_SIDE_SELL;
    }
    else
    {
        buySellSide = ORDR_SIDE_BUY;
    }

    rc = GetBstPrc ( prdctId, buySellSide, &bstGrp );
    RAISE_ERROR( rc, RTN );
	  TRACE("Best Buy %lld - %lld, Sell %lld - %lld" $$ bstGrp.bstBuyLmtPrc
	  				$$ bstGrp.bstBuyLmtPrc
	  				$$ bstGrp.bstSellLmtPrc
	  				$$ bstGrp.bstSellLmtQty);
    if ( !pOrder->orderF.ordrExePrc )
        /* 市价订单, 市价转限价检验 */
    {
        if ( ordrSide == ORDR_SIDE_BUY &&
                ( bstGrp.bstSellLmtQty > 0 &&
                    bstGrp.bstSellLmtPrc != 0 ||
                    bstGrp.bstSellMktQty > 0 ) ||
                    ordrSide == ORDR_SIDE_SELL &&
                ( bstGrp.bstBuyLmtQty > 0 &&
                    bstGrp.bstBuyLmtPrc != 0 || bstGrp.bstBuyMktQty > 0 ) )
        {
            *mktblFlg = WKSG_LIT_MARKETABLE;
            pOrder->orderF.ordrApplyPrc = ordrSide == ORDR_SIDE_BUY ?
                            bstGrp.bstSellLmtPrc : bstGrp.bstBuyLmtPrc;
        }
    }
    else
        // 限价订单
    {
        if ( ordrSide == ORDR_SIDE_BUY &&
                ( pOrder->orderF.ordrExePrc >= bstGrp.bstSellLmtPrc &&
                    bstGrp.bstSellLmtPrc != 0 ||
                    bstGrp.bstSellMktQty > 0 ) ||
                    ordrSide == ORDR_SIDE_SELL &&
                ( pOrder->orderF.ordrExePrc <= bstGrp.bstBuyLmtPrc &&
                    bstGrp.bstBuyLmtPrc != 0 || bstGrp.bstBuyMktQty > 0 ) )
        {
            *mktblFlg = WKSG_LIT_MARKETABLE;
        }
    }
   
    EXIT_BLOCK();
    RETURN_RESCODE;

}

static void PopRltrade ( pOrderT order,
                            pOrderT pBkOrdr,
                            TradeT * rltrade,
                            int64 * timeStamp )
{
    BEGIN_FUNCTION ( "PopRltrade" );

    ASSERT ( order && rltrade && timeStamp )
    
    rltrade->dateLstUpdDat = *timeStamp;
    rltrade->tranDatTim = *timeStamp;
    rltrade->ordrEntTim = order->orderF.ordrEntTim;
    rltrade->ordrQty = order->orderF.ordrQty;
    rltrade->ordrExePrc = order->orderF.ordrExePrc;


    rltrade->ordrExeQty = order->orderF.ordrExeQty;
    rltrade->prdctId = order->orderF.prdctId;

    //TODO
    rltrade->ordrSide = order->orderF.ordrSide;
    rltrade->ordrNo = order->orderF.ordrNo;
//    rltrade->peakSizeQty = order->orderF.peakSizeQty;
    rltrade->remPeakQty = order->orderF.remPkQty;
    rltrade->entyIdxNo = order->orderF.entyIdxNo;
    rltrade->totAucQty = 0;


    rltrade->ordrType = order->orderF.ordrType;

    EXIT_BLOCK (  );
}


ResCodeT TxnDelOrdr ( pOrderT * order,
                        const int64 tranTime,
                        const uint16 actnMask,
                        pRymtchT rymtch )
{
    ResCodeT rc = NO_ERR;
    pOrderT ordr = *order;


    BEGIN_FUNCTION ( "TxnDelOrdr" );

    ASSERT ( ordr && rymtch );

    //GET_SEQ_NUMBER ( actnMask, rymtch->actnSeqNum );
		rc = MemTxnAddData(DATA_TYPE_OC, (void *) ordr, sizeof(OrderT));
   	RAISE_ERROR ( rc, RTN );
   	TRACE("Delete Order No %lld" $$ (*order)->orderF.ordrNo);
    rc = OrderDelete ( order, tranTime);
    RAISE_ERROR ( rc, RTN );

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}                               /* TxnDelOrdr */

ResCodeT TxnLogTrd ( const pTradeT rltrade,
                    uint64 oldOrdrNo,
                    uint16 actnMask,
                    BOOL bGetSeqNo )
{
    BEGIN_FUNCTION ( "TxnLogTrd" );
    ResCodeT rc = NO_ERR;

    int i;

    //todo
    ASSERT ( rltrade );
    
    rc = MemTxnAddData(DATA_TYPE_TC, (void *) rltrade, sizeof(TradeT));
   	RAISE_ERROR ( rc, RTN );
		TRACE(" ==add Trade %lld" $$ rltrade->tranIdNo);
    EXIT_BLOCK (  );
    RETURN_RESCODE;

}                               /* TxnLogTrd */

static ResCodeT PartialMtch ( TradeT * pRltradeRec,
                                pPrdctMktDataT pPrdctMktData,
                                pOrderT pIncOrdr,
                                pOrderT pBkOrdr,
                                int64 * timeStamp)
{
    BEGIN_FUNCTION ( "PartialMtch" );
    ResCodeT rc;
    uint16 actnMask, setId;
    OrderT hldgOrdr;
    OrderT hldgInOrdr;
    rymtchT rymtch;
    int64 tmpQty;

    ASSERT ( pIncOrdr && pBkOrdr && pRltradeRec && timeStamp && pPrdctMktData )
    int32 prdctId = pIncOrdr->orderF.prdctId;
    tmpQty = pBkOrdr->orderF.ordrQty;
    pIncOrdr->orderF.ordrExeQty += tmpQty;
    pIncOrdr->orderF.ordrQty -= tmpQty;

    /* 更新输入订单的参数 */
    pRltradeRec->ordrPrtFilCod = WKSG_LIT_YES;
    /* 由输入订单组织成交信息 */
    PopRltrade ( pIncOrdr, pBkOrdr, pRltradeRec, timeStamp );
    /* 获得撮合Set号 */
    setId = GET_SET_ID(prdctId);

    actnMask = ACTN_BOOK_CMD | ACTN_PRT_FIL_MNT | ACTN_AUD_YES |
        ACTN_CONF_NO | ACTN_ORDR_BK_NO;
    /*记录成交信息到 WP */
    rc = TxnLogTrd ( pRltradeRec, gOldNumber, actnMask, TRUE );
    RAISE_ERROR( rc, RTN );

    memcpy ( &hldgInOrdr, pIncOrdr, sizeof ( OrderT ) );
    memcpy ( &hldgOrdr, pBkOrdr, sizeof ( OrderT ) );
    hldgInOrdr.orderF.ordrMtchPrc = hldgOrdr.orderF.ordrMtchPrc;

    //todo update credit

    /* 由输入订单记录撮合信息 */
    rymtch.ordrNoOld = pIncOrdr->orderF.ordrNo;
    rymtch.ordrPrtFilCod = WKSG_LIT_PRT_FIL;
    rymtch.tradePrc = pRltradeRec->tradMtchPrc;
    actnMask = ACTN_ADD_CMD | ACTN_PRT_FIL_MNT | ACTN_AUD_YES |
        ACTN_CONF_NO | ACTN_ORDR_BK_NO;

    rc = TxnLogOrdr ( pIncOrdr, actnMask, &rymtch );
    RAISE_ERROR( rc, RTN );

    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
        ACTN_CONF_NO | ACTN_ORDR_BK_NO;

    OrderT tmpOrder;

    memcpy ( &tmpOrder, pBkOrdr, sizeof ( OrderFT ) );
    tmpOrder.orderF.ordrExeQty += tmpOrder.orderF.ordrQty;
    tmpOrder.orderF.ordrQty = tmpOrder.orderF.remPkQty = 0;
    tmpOrder.orderF.tranTime = *timeStamp;
    pRltradeRec->ordrPrtFilCod = WKSG_LIT_NO;
    PopRltrade ( &tmpOrder, pIncOrdr, pRltradeRec, timeStamp );
    /* 记录成交撮合信息 */
    rymtch.ordrNoOld = pBkOrdr->orderF.ordrNo;
    rymtch.ordrPrtFilCod = WKSG_LIT_FULL_MTCH;
    rymtch.tradePrc = pRltradeRec->tradMtchPrc;
    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_YES |
        ACTN_CONF_NO | ACTN_ORDR_BK_YES;
    /* 撮合后删除订单 */
    rc = TxnDelOrdr ( &pBkOrdr, *timeStamp, actnMask, &rymtch );
    RAISE_ERROR( rc, RTN );

    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
        ACTN_CONF_NO | ACTN_ORDR_BK_NO;
    rc = TxnLogTrd ( pRltradeRec, 0, actnMask, TRUE );
    RAISE_ERROR( rc, RTN );

    //tod update trade credit

    EXIT_BLOCK (  );

    RETURN_RESCODE;
}


ResCodeT ModQty ( pOrderT oldOrdr,
                    int64 exeQty,
                    int64 exePrc,
                    int64 tranTime,
                    uint16 actnMask )
{
    BEGIN_FUNCTION ( "ModQty" );
    ResCodeT rc = NO_ERR;

    ASSERT ( oldOrdr );

    RAISE_ERROR ( OrdBkModOrdrQty ( oldOrdr, exeQty, tranTime), RTN );


    EXIT_BLOCK (  );
    RETURN_RESCODE;
}


static ResCodeT FullMtch ( TradeT * pRltradeRec,
                            pPrdctMktDataT pPrdctMktData,
                            pOrderT pIncOrdr,
                            pOrderT pBkOrdr,
                            int64 * timeStamp)
{

    BEGIN_FUNCTION ( "FullMtch" );
    ResCodeT rc;
    uint16 actnMask, setId;
    OrderT hldgOrdr;
    OrderT hldgInOrdr;
    int64 exeQty;
    rymtchT rymtch;
    int32 prdctId = pIncOrdr->orderF.prdctId;


    ASSERT ( pIncOrdr && pBkOrdr && pRltradeRec && timeStamp && pPrdctMktData )

    /* 成交后修改输入订单的参数 */
    exeQty = pIncOrdr->orderF.ordrQty;
    pIncOrdr->orderF.ordrExeQty += pIncOrdr->orderF.ordrQty;
    pIncOrdr->orderF.ordrQty = 0;
    pIncOrdr->orderF.remPkQty = 0;

    memcpy ( &hldgOrdr, pBkOrdr, sizeof ( OrderT ) );
    memcpy ( &hldgInOrdr, pIncOrdr, sizeof ( OrderT ) );
    hldgInOrdr.orderF.ordrMtchPrc = hldgOrdr.orderF.ordrMtchPrc;


    /*组合成交信息 rltrade */
    pRltradeRec->ordrPrtFilCod = WKSG_LIT_NO;
    PopRltrade ( pIncOrdr, pBkOrdr, pRltradeRec, timeStamp );

    setId = GET_SET_ID(prdctId);
    

    actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
        ACTN_CONF_NO | ACTN_ORDR_BK_NO;
    /* 记录成交信息 */
    rc = TxnLogTrd ( pRltradeRec, gOldNumber, actnMask, TRUE );
    RAISE_ERROR( rc, RTN );
    /*write the trade into the working page */

//todo Update credit


    if ( pBkOrdr->orderF.ordrQty == exeQty )
        /* 订单簿对手方订单完全撮合 */
    {
        /* 由于是完全撮合， 就不需要调用ModQty()，修改订单的量 */
        OrderT tmpOrder;

        memcpy ( &tmpOrder, pBkOrdr, sizeof ( OrderFT ) );
        tmpOrder.orderF.ordrExeQty += tmpOrder.orderF.ordrQty;
        tmpOrder.orderF.ordrQty = tmpOrder.orderF.remPkQty = 0;
        tmpOrder.orderF.tranTime = *timeStamp;
        pRltradeRec->ordrPrtFilCod = WKSG_LIT_NO;
        PopRltrade ( &tmpOrder, pIncOrdr, pRltradeRec, timeStamp );
        /*fill rltrade with pBkOrdr */
        rymtch.ordrNoOld = pBkOrdr->orderF.ordrNo;
        rymtch.ordrPrtFilCod = WKSG_LIT_FULL_MTCH;
        rymtch.tradePrc = pRltradeRec->tradMtchPrc;
        actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_YES |
            ACTN_CONF_NO | ACTN_ORDR_BK_YES;
        /* 由于是完全撮合， 需要将该订单从订单簿中剔除 */

        rc = TxnDelOrdr ( &pBkOrdr, *timeStamp, actnMask, &rymtch );
        RAISE_ERROR( rc, RTN );


        /* 执行撮合后，记录成交信息wp中 */
        actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
            ACTN_CONF_NO | ACTN_ORDR_BK_NO;
        rc = TxnLogTrd ( pRltradeRec, 0, actnMask, TRUE );

    }                           /*end if 成交簿订单完全撮合 */
    else                        /* 成交簿订单部分撮合，输入订单完全撮合 */
    {
        /* 更新成交簿的订单 */
        actnMask = ACTN_BOOK_CMD | ACTN_PRT_FIL_MNT | ACTN_AUD_YES |
            ACTN_CONF_NO | ACTN_ORDR_BK_YES;
        /* 订单簿订单部分撮合， 修改剩余订单数量 */
        rc = ModQty ( pBkOrdr,
                        exeQty, pRltradeRec->tradMtchPrc, *timeStamp,
                        actnMask );
        RAISE_ERROR( rc, RTN );
        pRltradeRec->ordrPrtFilCod = WKSG_LIT_YES;
        PopRltrade ( pBkOrdr, pIncOrdr, pRltradeRec, timeStamp );

        actnMask = ACTN_BOOK_CMD | ACTN_MATCH_MNT | ACTN_AUD_NO |
            ACTN_CONF_NO | ACTN_ORDR_BK_NO;
        rc = TxnLogTrd ( pRltradeRec, 0, actnMask, TRUE );
        RAISE_ERROR( rc, RTN );

    }                           /*end if 订单簿订单部分撮合 */

    /* 撮合后根据结果 更新持仓 */

// update credit todo

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}


static void CalcPotExecPrc ( uint16 bkSide,
                                pOrderT pIncOrdr,
                                pOrderT pBkOrdr,
                                HoldT * hold,
                                pTradeT pRltradeRec,
                                pPrdctMktDataT pPrdctMktData)
{

    BEGIN_FUNCTION ( "CalcPotExecPrc" );
    BstGrpT bstGrp;

    /* 获得订单簿中最优价格组 */
    GetBstGrp ( pIncOrdr->orderF.prdctId, ORDR_TRDRESTR_NO | ORDR_SIDE_NONE,
                &bstGrp );
    /*SECTION("INITPRC"); */
    /*如果订单簿中只有限价订单， 最优价格就是对手方订单簿中的最优价格 */
    ASSERT ( pIncOrdr && pBkOrdr && hold && pRltradeRec && pPrdctMktData )
    
    pRltradeRec->tradMtchPrc = pBkOrdr->orderF.ordrExePrc;
    if ( bkSide == ORDR_SIDE_BUY )
    {
        hold->bstBkPrc = bstGrp.bstBuyLmtPrc;
        hold->mktQty = bstGrp.bstBuyMktQty;
    }
    else
    {
        hold->bstBkPrc = bstGrp.bstSellLmtPrc;
        hold->mktQty = bstGrp.bstSellMktQty;
    }

    /*SECTION("CALCPRC_MVM"); */

    /* 如果输入的订单和订单簿中的市价订单撮合
       *  可考虑两个价格
       *  1: 上比成交价
       *  订单簿最优限价订单的价格
     */
    // if ( GET_ORDR_TYPE ( pIncOrdr->orderF.orderMask ) == ORDR_TYPE_MARKT &&
    //         hold->mktQty > 0 )
    //     /* 市价 对 市价 */
    // {
    //     /* 订单簿中有限价订单 */
    //     if ( hold->bstBkPrc )
    //     {
    //         if ( bkSide == ORDR_SIDE_SELL )
    //         {
    //             pRltradeRec->tradMtchPrc =
    //                 pRmseri2Rec->lstTrdPrc < hold->bstBkPrc
    //                 ? pRmseri2Rec->lstTrdPrc : hold->bstBkPrc;
    //             /* 卖: 上比成交价， 订单簿最优价取 小 */
    //         }
    //         else                /*bkSide = buy */
    //         {
    //             pRltradeRec->tradMtchPrc =
    //                 pRmseri2Rec->lstTrdPrc < hold->bstBkPrc
    //                 ? hold->bstBkPrc : pRmseri2Rec->lstTrdPrc;
    //             /* 买:  上比成交价， 订单簿最优价取 大 */
    //         }
    //     }
    //     else                    /* 订单簿中只有市价订单 */
    //     {
    //         pRltradeRec->tradMtchPrc = pRmseri2Rec->lstTrdPrc;
    //         /* 取参考价格, 上比成交价 */
    //     }
    //     return;
    // }                           /* market vs market done */

    /*SECTION("CALCPRC_LVM"); */
    // 输入订单与订单簿市价订单撮合
    // 参考3个价格
    // 1: 最新成交价
    // 2: 订单簿最优限价
    // 3: 输入限价订单的价格
    if (  hold->mktQty > 0 )
        /* 限价 对 市价 */
    {
        /* pIncOrdr->ordBuyCod == WKSG_LIT_BUY */
        if ( bkSide == ORDR_SIDE_SELL )
        {
            /* 订单簿中没有限价订单 */
            if ( !hold->bstBkPrc )
            {
                pRltradeRec->tradMtchPrc =
                    pIncOrdr->orderF.ordrExePrc < pPrdctMktData->lstTrdPrc
                    ? pIncOrdr->orderF.ordrExePrc : pPrdctMktData->lstTrdPrc;
                /* 最新成交价格，订单价格 取小 */
            }
            else                /*订单簿中有限价订单，参考订单簿最优限价 */
            {
                pRltradeRec->tradMtchPrc =
                    MIN ( MIN ( pIncOrdr->orderF.ordrExePrc,
                                pPrdctMktData->lstTrdPrc ), hold->bstBkPrc );
            }
        }                       /*end if bkSide == ORDR_SIDE_SELL */
        else                    /*bkSdie = BUY */
        {
            if ( !hold->bstBkPrc )  /* 订单簿中无限价订单 */
            {
                pRltradeRec->tradMtchPrc =
                    pIncOrdr->orderF.ordrExePrc < pPrdctMktData->lstTrdPrc
                    ? pPrdctMktData->lstTrdPrc : pIncOrdr->orderF.ordrExePrc;
                /* 最新成交价格，订单价格 取大 */
            }
            else                /*订单簿中有限价订单，参考订单簿最优限价 */
            {
                pRltradeRec->tradMtchPrc =
                    MAX ( MAX ( pIncOrdr->orderF.ordrExePrc,
                                pPrdctMktData->lstTrdPrc ), hold->bstBkPrc );
            }                   /*end else consider limit order prc */
        }                       /*end bkSide BUY */
    }                           /*limit vs market over */
    EXIT_BLOCK (  );
}


ResCodeT PerformMtchg ( pOrderT pIncOrdr,
                        pPrdctMktDataT pPrdctMktData,
                        uint64 ordrNoOld,
                        int64 * timeStamp)
{
    BEGIN_FUNCTION ( "PerformMtchg" );
    ResCodeT rc;

    uint16 bkSide = 0;
    uint16 tmpSetId = 0;

    int32 tempMask = 0, trdResMask = 0;
    MaintT maint;
    HoldT hold = { 0 };
    pOrderT pBkOrdr;
    TradeT rltrade;
    int64 tmpQty;
    int64 tmpTrnover;
    BOOL bIsPobb = FALSE;
    long currentMktDepth;
    int64 crntPrc, lstPrc;
    int64 underPrvsCls = 0;
	CrdtMsgT BuyCredit;
	CrdtMsgT SellCredit;
	
    ASSERT ( pIncOrdr && pPrdctMktData && timeStamp ) SECTION ( "MAIN" );


    int32 prdctId = pIncOrdr->orderF.prdctId;
    int32 setId = GET_SET_ID(prdctId);
    int32 ordrSide = pIncOrdr->orderF.ordrSide;

    gOldNumber = ordrNoOld;
    /* 设置成交信息 */
    memset ( &rltrade, 0x00, sizeof ( TradeT ) );

	memset(&BuyCredit, 0x00, sizeof(CrdtMsgT));
	memset(&SellCredit, 0x00, sizeof(CrdtMsgT));
	
    rltrade.setId = setId;
    rltrade.prdctId = prdctId;

    
    //rltrade.trnTypId = 'F';
    //rltrade.trdTyp = TRD_TYP_NGTS;
    //memset ( rltrade.actnSeqNum, 0x0, ACTN_SEQ_NUM_LEN );
    
    bkSide =  (ordrSide == ORDR_SIDE_SELL)? ORDR_SIDE_BUY:ORDR_SIDE_SELL;
    
    
    //bkSide = ORDR_SIDE_SELL ^ ordrSide;

    hold.trnover = 0;
    maint.partialFill = TRUE;
    maint.marketable = WKSG_LIT_MARKETABLE;

    /* 获得指定的最优订单 */

    tempMask = bkSide;
    rc = GetBest ( prdctId, tempMask, &pBkOrdr );
    RAISE_ERROR( rc, RTN );
   
    

    if ( pBkOrdr )
    {
				pOrderT pBuyOrder, pSellOrder;
		//jiangjun
		lstPrc = crntPrc = pBkOrdr->orderF.ordrExePrc;
    currentMktDepth = 1;
 				
				if (ordrSide ==  ORDR_SIDE_SELL)
				{
						pBuyOrder = pIncOrdr;
						pSellOrder = pBkOrdr;
				}
				else
				{
						pBuyOrder = pBkOrdr;
						pSellOrder = pIncOrdr;
				}

        rc  = DoCheckCredit ( pBuyOrder, &BuyCredit,
                              pSellOrder, &SellCredit);
        RAISE_ERROR( rc, RTN );
		/* no credit */
		if (BuyCredit.avaCrdtAmnt == 0 && SellCredit.avaCrdtAmnt == 0)
        {
			THROW_RESCODE(NO_ERR);
		}
        while ( maint.partialFill && maint.marketable == WKSG_LIT_MARKETABLE )
        {
            /* 计算潜在的成交价格 */
            /* 连续交易 */
            CalcPotExecPrc ( bkSide,
                                pIncOrdr, pBkOrdr, &hold, &rltrade,
                                pPrdctMktData );

            pIncOrdr->orderF.ordrMtchPrc = rltrade.tradMtchPrc;
            pBkOrdr->orderF.ordrMtchPrc = rltrade.tradMtchPrc;


            /*检查 每天/内存 阶段 最低和最高价格 */
            //todo 
            // if ( rltrade.tradMtchPrc > pPrdctMktData->dlyHghPrc )
            // {
            //     pPrdctMktData->dlyHghPrc = rltrade.tradMtchPrc;
            // }
            // if ( rltrade.tradMtchPrc < pPrdctMktData->dlyLowPrc )
            // {
            //     pPrdctMktData->dlyLowPrc = rltrade.tradMtchPrc;
            // }

            rltrade.tranIdNo = ++gTrdrNo[setId];

            /* 执行数量 */
            tmpQty = pBkOrdr->orderF.ordrQty;

            /*订单只可以与订单簿部分撮合 */
            if ( tmpQty < pIncOrdr->orderF.ordrQty )
            {
                /* 撮合数量，实际撮合量 */
                rltrade.trdQty = tmpQty;

                /*更新成交数量， 模块数据 */
                hold.totalTrdQty += tmpQty;
                /* 总成交次数 */
                hold.totalNumOfTrd++;
                /* 执行部分撮合 */
                rc = PartialMtch ( &rltrade, pPrdctMktData, pIncOrdr,
                                    pBkOrdr, timeStamp );
                RAISE_ERROR( rc, RTN );
            }
            else                /*订单可与订单簿中的订单完全撮合 */
            {
                /* 撮合数量，就是订单数量 */
                rltrade.trdQty = pIncOrdr->orderF.ordrQty;
                hold.totalTrdQty += pIncOrdr->orderF.ordrQty;
                hold.totalNumOfTrd++;
                /* 执行完全撮合 */
                rc = FullMtch ( &rltrade, pPrdctMktData,
                                pIncOrdr, pBkOrdr, timeStamp );
                RAISE_ERROR( rc, RTN );

                maint.partialFill = FALSE;
            }

            /* 计算成交金额 */
           //tmpTrnover = MULT ( rltrade.tradMtchPrc, 5, rltrade.trdQty, 3, 5 );
 						tmpTrnover = rltrade.tradMtchPrc *rltrade.trdQty;
 						
            if ( tmpTrnover > 0 )
            {
                hold.trnover += tmpTrnover;
            }
            else
            {
                hold.trnover = tmpTrnover * 10;
            }
            /*TRADE, 更新最新成交价 */
            /* 成交价更新 */
            pPrdctMktData->lstTrdPrc = rltrade.tradMtchPrc;
            if ( !pPrdctMktData->opnPrc )
            {
                /*最近一次开盘价 ，开盘竞价阶段 */
                pPrdctMktData->opnPrc = pPrdctMktData->lstTrdPrc;
            }


            if ( maint.partialFill )   /* 尚未完全撮合 */
            {
                /* 获得订单簿另外最优对手订单 */
                rc = GetBest ( prdctId, tempMask, &pBkOrdr );
                RAISE_ERROR( rc, RTN );
                if ( pBkOrdr )  /* 获得该订单 */
                {
                    /* 订单可转市价 */
                    uint64 * timeStamp1 =
                                    (uint64 *)timeStamp;
                    rc = CheckOrderMarketable ( pIncOrdr, &maint.marketable,
                                                timeStamp1 );
                    RAISE_ERROR( rc, RTN );
                    crntPrc = pBkOrdr->orderF.ordrExePrc;
                    /* 输入的市价或者市价转限价订单，
                       需要检查最大 市价订单允许深度 */
                    if ( !pIncOrdr->orderF.ordrExePrc && crntPrc != lstPrc )
                    {
                        currentMktDepth++;
                        lstPrc = crntPrc;
                        if ( currentMktDepth > 5 )
                        {
                            maint.marketable = WKSG_LIT_NO;
                        }
                    }
                }
                else
                {
                    maint.marketable = WKSG_LIT_NO;
                }
            }                   /*end if partial match */
        }                       /*end while partialFill and marketable */
        
        rc = DoUpdateCredit(&BuyCredit, &SellCredit);
		
        RAISE_ERROR( rc, RTN );
        
        
    }/*end if (pBkOrdr) */

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}


static ResCodeT CheckOrderWritable ( pOrderT pOrder,
                                        MaintFlagT * pMaintFlag )
{
    BEGIN_FUNCTION ( "CheckOrderWritable" );
    ResCodeT rc = NO_ERR;
    uint16 ordrExeRestrMask = 0;
    uint16 ordrTypeMask = 0;

    SECTION ( "CheckOrderWritable" );
    ASSERT (  pOrder && pMaintFlag )
    

    pMaintFlag->ordrWrtblFlg = WKSG_LIT_YES;
    

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT TxnLogOrdr ( pOrderT ordr,
                        uint16 actnMask,
                        pRymtchT rymtch )
{
    BEGIN_FUNCTION ( "MlLogOrdr" );
    ResCodeT rc = NO_ERR;

		rc = MemTxnAddData(DATA_TYPE_OC, (void *) ordr, sizeof(OrderT));
   	RAISE_ERROR ( rc, RTN );
    //GET_SEQ_NUMBER ( actnMask, rymtch->actnSeqNum );
		TRACE("add Order %lld" $$ ordr->orderF.ordrNo);
    EXIT_BLOCK (  );
    RETURN_RESCODE;

}   

static ResCodeT DoCheckCredit ( pOrderT pBuyOrder, pCrdtMsgT pBuyCredit,
                                pOrderT pSellOrder, pCrdtMsgT pSellCredit)
{
BEGIN_FUNCTION ( "DoCheckCredit" );
    ResCodeT rc = NO_ERR;
    
    TCrdtCoe  sBuyCoe;
		TCrdtCoe  sSellCoe;
	
    pBuyCredit->crdtEntyNo = pBuyOrder->orderF.entyIdxNo;
    pBuyCredit->trgtEntyNo = pSellOrder->orderF.entyIdxNo;
    rc = CrdtLibCheckRemoteCrdtInfo (pBuyCredit);
		RAISE_ERROR( rc, RTN );
    pSellCredit->crdtEntyNo = pSellOrder->orderF.entyIdxNo;
    pSellCredit->trgtEntyNo = pBuyOrder->orderF.entyIdxNo;
    rc = CrdtLibCheckRemoteCrdtInfo (pSellCredit);
		RAISE_ERROR( rc, RTN );
		sBuyCoe.cntrct_srno = pBuyOrder->orderF.prdctId;
		sBuyCoe.crdt_org_id = pBuyOrder->orderF.entyIdxNo;
		sSellCoe.cntrct_srno = pSellOrder->orderF.prdctId;
		sSellCoe.crdt_org_id = pSellOrder->orderF.entyIdxNo;
	
		rc = GetCoe(&sBuyCoe, &sSellCoe);
    RAISE_ERROR ( rc, RTN );
	
	int32 prdctId =  pSellOrder->orderF.prdctId;
	
		if ((pBuyCredit->avaCrdtAmnt < (pBuyOrder->orderF.ordrExePrc * pBuyOrder->orderF.ordrQty * sBuyCoe.crdt_coe) ) 
					|| 
				(pSellCredit->avaCrdtAmnt < (pSellOrder->orderF.ordrExePrc * pSellOrder->orderF.ordrQty * sSellCoe.crdt_coe) ))
		{		
				TRACE("avaAmt %lld ordPrc %lld $$ Qty %lld coe %lld" 
						$$ pBuyCredit->avaCrdtAmnt $$ pBuyOrder->orderF.ordrExePrc $$ pBuyOrder->orderF.ordrQty $$ sBuyCoe.crdt_coe);
				if (gBrdgOrdrList[prdctId].caseType == 0)
				{
					gBrdgOrdrList[prdctId].buyBrdgOrdr.ordrExePrc = pBuyOrder->orderF.ordrExePrc;
					gBrdgOrdrList[prdctId].buyBrdgOrdr.ordrSide  =  pBuyOrder->orderF.ordrSide;
					gBrdgOrdrList[prdctId].buyBrdgOrdr.prdctId = pBuyOrder->orderF.prdctId;
					gBrdgOrdrList[prdctId].buyBrdgOrdr.ordrQty  = pBuyOrder->orderF.ordrQty;
					gBrdgOrdrList[prdctId].buyBrdgOrdr.ordrNo  = pBuyOrder->orderF.ordrNo;
					gBrdgOrdrList[prdctId].buyBrdgOrdr.entyIdx =  pBuyOrder->orderF.entyIdxNo;
					gBrdgOrdrList[prdctId].buyBrdgOrdr.slotId =  pBuyOrder->orderT.slotNo;
					
					gBrdgOrdrList[prdctId].sellBrdgOrdr.ordrExePrc = pSellOrder->orderF.ordrExePrc;
					gBrdgOrdrList[prdctId].sellBrdgOrdr.ordrSide  =  pSellOrder->orderF.ordrSide;
					gBrdgOrdrList[prdctId].sellBrdgOrdr.prdctId = pSellOrder->orderF.prdctId;
					gBrdgOrdrList[prdctId].sellBrdgOrdr.ordrQty  = pSellOrder->orderF.ordrQty;
					gBrdgOrdrList[prdctId].sellBrdgOrdr.ordrNo  = pSellOrder->orderF.ordrNo;
					gBrdgOrdrList[prdctId].sellBrdgOrdr.entyIdx = pSellOrder->orderF.entyIdxNo;
					gBrdgOrdrList[prdctId].sellBrdgOrdr.slotId =  pSellOrder->orderT.slotNo;
					
					gBrdgOrdrList[prdctId].caseType = BRDG_CASE_TYPE_TWO_WAY;
					
					TRACE("Need do bridge logic later prdct %lld Sell Ord %lld Buy Ord %lld" $$ prdctId $$ pSellOrder->orderF.ordrNo $$ pBuyOrder->orderF.ordrNo);
				}
				

		}else
		{
				pBuyCredit->avaCrdtAmnt = (pBuyOrder->orderF.ordrExePrc * pBuyOrder->orderF.ordrQty * sBuyCoe.crdt_coe) ;
				pSellCredit->avaCrdtAmnt = (pSellOrder->orderF.ordrExePrc * pSellOrder->orderF.ordrQty * sSellCoe.crdt_coe) ;
		}

    EXIT_BLOCK();
    RETURN_RESCODE;
}

static ResCodeT DoUpdateCredit (pCrdtMsgT pBuyCredit,
                                pCrdtMsgT pSellCredit)
{

    BEGIN_FUNCTION ( "DoUpdateCredit" );
    ResCodeT rc = NO_ERR;
    
	TRACE("BUY AVA %lld SELL AVA %lld " $$ pBuyCredit->avaCrdtAmnt $$ pSellCredit->avaCrdtAmnt);
			
	if (pBuyCredit->crdtEntyNo != 0 && pBuyCredit->trgtEntyNo != 0 )
	{
		rc = CrdtLibUpdtRemoteCrdtInfo (pBuyCredit);
		RAISE_ERROR ( rc, NORTN );
	}
	
	if (pSellCredit->crdtEntyNo != 0 && pSellCredit->trgtEntyNo != 0 )
	{
		rc = CrdtLibUpdtRemoteCrdtInfo (pSellCredit);
		RAISE_ERROR ( rc, NORTN );
	}

    EXIT_BLOCK();
    RETURN_RESCODE;
}



static ResCodeT DoMatchOrder ( pOrderT pOrder,
                                uint16 actnMask,
                                rymtchT * pRymtch,
                                pPrdctMktDataT pPrdctMktData,
                                int64 * tranTime,
                                char modFlg,
                                pOrderT * pCurrOrder)
{

    BEGIN_FUNCTION ( "DoMatchOrder" );
    ResCodeT rc = NO_ERR;
    int64 remainPeakQty;
    uint16 localActnMask;
    uint16 setId;
    OrderFT newOrder;


    int32 prdctId = pOrder->orderF.prdctId;


    SECTION ( "DoMatchOrder" );
    ASSERT ( pOrder && pRymtch && pPrdctMktData && tranTime )


    localActnMask = 0;
    localActnMask |= actnMask;
    localActnMask |= ACTN_ADD_MNT;
    localActnMask |= ACTN_AUD_YES;
    localActnMask |= ACTN_CONF_NO;
    localActnMask |= ACTN_ORDR_BK_NO;

    /* 记录订单 */
    rc = TxnLogOrdr ( pOrder, localActnMask, pRymtch );
    RAISE_ERROR( rc, RTN );

    /* 执行撮合 */
    rc = PerformMtchg ( pOrder, pPrdctMktData, pRymtch->ordrNoOld, tranTime );
    RAISE_ERROR( rc, RTN );
    pOrder->orderF.tranTime = *tranTime;
    
    setId = GET_SET_ID(prdctId);

    /* 订单未撮合数量 */
    if ( pOrder->orderF.ordrQty > 0 )
    {
        /* WP */
        localActnMask = 0;
        localActnMask |= actnMask;
        localActnMask |= ACTN_PRT_FIL_MNT;
        localActnMask |= ACTN_AUD_YES;
        localActnMask |= ACTN_CONF_NO;
        localActnMask |= ACTN_ORDR_BK_NO;
        pRymtch->ordrPrtFilCod = WKSG_LIT_NO_MTCH;
        pRymtch->tradePrc = pPrdctMktData->lstTrdPrc;
        /* 无撮合记录该订单 */
        if ( !pOrder->orderF.ordrExeQty )
        {
            rc = TxnLogOrdr ( pOrder, localActnMask, pRymtch );
            RAISE_ERROR( rc, RTN );

        }

        localActnMask = 0;
        localActnMask |= actnMask;
        localActnMask |= ACTN_ADD_MNT;
        localActnMask |= ACTN_AUD_NO;
        localActnMask |= !pOrder->orderF.ordrExeQty ?
            ACTN_CONF_NO : ACTN_CONF_ORDER;
        localActnMask |= ACTN_ORDR_BK_YES;

        pRymtch->ordrPrtFilCod = WKSG_LIT_PRT_FIL;

        if ( modFlg == WKSG_LIT_YES )
        {
            rc = TxnLogOrdr ( pOrder, localActnMask, pRymtch );
            RAISE_ERROR( rc, RTN );
            if ( ACTN_CONF_ORDER == GET_ACTN_ORDRCFM(localActnMask) )
            {
                //todo send order confirmation
            }


            localActnMask = 0;
            localActnMask |= actnMask;
            localActnMask |= ACTN_ADD_MNT;
            localActnMask |= ACTN_AUD_NO;
            localActnMask |= ACTN_CONF_NO;
            localActnMask |= ACTN_ORDR_BK_NO;
            memcpy ( &newOrder, &pOrder->orderF, sizeof ( OrderFT ) );
            rc = TxnModOrdr ( pCurrOrder, &newOrder, localActnMask,
                                pRymtch );
            RAISE_ERROR( rc, RTN );

        }
        else
        {

            /* 新增订单 */
            rc = TxnAddOrdr ( &pOrder, localActnMask, pRymtch );
            RAISE_ERROR( rc, RTN );


            if ( ACTN_CONF_ORDER == GET_ACTN_ORDRCFM(localActnMask) )
            {
                //todo send order confirmation
            }

        }
    }
    else                        /*when pOrder->orderF.ordrQty <= 0 */
    {
        //　全部撮合, 不需要在做其他操作, 只记录该订单和成交信息即可
        /* WP */
        localActnMask = 0;
        localActnMask |= actnMask;
        localActnMask |= ACTN_MATCH_MNT;
        localActnMask |= ACTN_AUD_YES;
        localActnMask |= ACTN_CONF_ORDER;
        localActnMask |= ACTN_ORDR_BK_NO;

        pRymtch->ordrPrtFilCod = WKSG_LIT_FULL_MTCH;
        pRymtch->tradePrc = pPrdctMktData->lstTrdPrc;
        /* 记录该订单 */
        rc = TxnLogOrdr ( pOrder, localActnMask, pRymtch );
        RAISE_ERROR( rc, RTN );

        {
            //todo send order confirmation
        }

    }                           /*end if pOrder->orderF.ordrQty > 0 */

    EXIT_BLOCK();
    RETURN_RESCODE;
}


ResCodeT TxnAddOrdr ( pOrderT * ordr,
                        uint16 actnMask,
                        pRymtchT rymtch )
{
    BEGIN_FUNCTION ( "TxnAddOrdr" );
    ResCodeT rc = NO_ERR;

    ASSERT ( ordr && rymtch );
    
    rc = MemTxnAddData(DATA_TYPE_OC, (void *) ordr, sizeof(OrderT));
   	RAISE_ERROR ( rc, RTN );
    //todo Update Order Mask for matcher prty
    //rc = UpdateOdrMask4MatchPrty ( *ordr, pRmseri2 );
    TRACE("add Order\n");
		TRACE("Add Order No %lld" $$ (*ordr)->orderF.ordrNo);
    //GET_SEQ_NUMBER ( actnMask, rymtch->actnSeqNum );


    RAISE_ERROR ( OrderAdd ( ordr ), RTN );

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}   


ResCodeT TxnModOrdr ( pOrderT * pOldOrdr,
                        pOrderFT pNewOrdrF,
                        pRymtchT rymtch )
{
    BEGIN_FUNCTION ( "TxnModOrdr" );
    ResCodeT rc = NO_ERR;

    ASSERT ( pOldOrdr && rymtch );
   
    //todo Update Order Mask for matcher prty
    //rc = UpdateOdrMask4MatchPrty ( *ordr, pRmseri2 );
    //RAISE_ERROR ( rc, RTN );

    //GET_SEQ_NUMBER ( actnMask, rymtch->actnSeqNum );


    RAISE_ERROR ( OrdBkModOrdr ( pOldOrdr, pNewOrdrF), RTN );

    EXIT_BLOCK (  );
    RETURN_RESCODE;
}   

ResCodeT ProcessOrderAdd(pOrderT pOrder, int64 timestamp, pOrdrRspT pOrderRsp)
{
    BEGIN_FUNCTION("DoCreateOrder");
    ResCodeT                rc = NO_ERR;
    int32 prdctId = 0;
    MaintFlagT maintFlag;
    rymtchT rymtch;

    PrdctMktDataT  prdctMktData;
    
    prdctId = pOrder->orderF.ordrNo; 
    /* Gen order number*/
    pOrder->orderF.ordrNo = ++gOrdrNo[prdctId];
    
    pOrder->orderF.ordrEntTim = timestamp;
    pOrder->orderF.tranTime = timestamp;


    /*----------------初始化订单交易信息 rymtch----------------*/
    rymtch.ordrPrtFilCod = WKSG_LIT_NO_MTCH;
    rymtch.tradePrc = 0;

    rc = CheckOrderMarketable ( pOrder, &maintFlag.mktblFlg,
        &timestamp);
    RAISE_ERROR( rc, RTN );

    rc = CheckOrderWritable ( pOrder, &maintFlag );
    RAISE_ERROR( rc, RTN );

    /*----------------           订单的执行处理逻辑           ----------------*/
    /* 当前订单可以撮合, 执行相关订单的撮合逻辑 */
    int32 actnMask = 0;
    if ( maintFlag.mktblFlg == WKSG_LIT_MARKETABLE )
    {
		printf("CANNOT matcher: pOrder->orderF.side = %ld\n",  pOrder->orderF.ordrSide);
        
        actnMask |= ACTN_ADD_CMD;

        /* 订单撮合  */
        rc = DoMatchOrder ( pOrder,
                            actnMask, &rymtch, &prdctMktData, &timestamp, WKSG_LIT_NO,
                            NULL );
        RAISE_ERROR( rc, RTN );

        /* 无剩余就撤单 */
        if ( pOrder->orderF.ordrQty == 0 )
        {

            rc = FreeOrder ( &pOrder );
            RAISE_ERROR( rc, RTN );
        }
    }
    /* 当前订单不可以撮合 */
    else
    {

		printf("CANNOT matcher: pOrder->orderF.side = %ld\n",  pOrder->orderF.ordrSide);
		
        /* 订单需要进入订单簿 */
        if ( maintFlag.ordrWrtblFlg == WKSG_LIT_YES )
        {
            /* 准备订单的action mask */
            actnMask = 0;
            actnMask |= ACTN_ADD_CMD;
            actnMask |= ACTN_ADD_MNT;
            actnMask |= ACTN_AUD_YES;
            actnMask |= ACTN_CONF_ORDER;
            actnMask |= ACTN_ORDR_BK_YES;

            /* 将订单放入订单簿 */
            rc = TxnAddOrdr ( &pOrder, actnMask, &rymtch );
            RAISE_ERROR( rc, RTN );

            // rc = FmtOrderMsg2WP( pOrder, actnMask, &rymtch,
            //                 ML_ADD_ORDR,
            //                 APP_SET_BIZ_OTO,
            //                 pCtx );
            // RAISE_ERROR( rc, RTN );
            
            
            //check if this is the best order, if it is them market 
        }
        /* 订单不进入订单簿 */
        else
        {
            /* 准备订单的action mask */
            actnMask = 0;
            actnMask |= ACTN_ADD_CMD;
            actnMask |= ACTN_ADD_MNT;
            actnMask |= ACTN_AUD_YES;
            actnMask |= ACTN_CONF_NO;
            actnMask |= ACTN_ORDR_BK_NO;


            /* 记录该订单 */
            rc = TxnLogOrdr ( pOrder, actnMask, &rymtch );
            RAISE_ERROR( rc, RTN );

            /* 准备订单的action mask */
            actnMask = 0;
            actnMask |= ACTN_ADD_CMD;
            actnMask |= ACTN_CANCEL_MNT;
            actnMask |= ACTN_AUD_YES;
            actnMask |= ACTN_CONF_ORDER;
            actnMask |= ACTN_ORDR_BK_NO;
            /* 记录该订单的撤销操作 */
            rc = TxnLogOrdr ( pOrder, actnMask, &rymtch );
            RAISE_ERROR( rc, RTN );

            /* 对于未撮合的订单需要删除之前已经执行的持仓修改操作 */
            // rc = CmnUpdHldg ( UPD_HLDG_TXN_ORD_OPT_DEL,
            //                     pOrder, pPrdctMktData, pOrder->orderF.ordrQty,
            //                     timeStamp );
            // RAISE_ERROR( rc, RTN );
            /* 删除未撮合的订单 */

            //int64 leaveQty = pOptReq->ordCom.quantity - pOrder->orderF.ordrExeQty;
            rc = FreeOrder ( &pOrder );
            RAISE_ERROR( rc, RTN );
        }
    }                           /* End of 订单执行逻辑 */
    /*----------------      组织并格式化响应消息中的数据      ----------------*/

    EXIT_BLOCK();

    /* 复制入当前的订单响应数据 */
    //FormatRespText ( pReq, &optrsp, pTranTime );

    rc = GET_RESCODE (  );

    if ( OK ( rc ) )
    {	
    		TRACE("Format response");
//    		pOrderRsp->ordrNo = pOrder->orderF.ordrNo; 
//    		pOrderRsp->ordrExePrc = pOrder->orderF.ordrExePrc;
//    		pOrderRsp->ordrSide = pOrder->orderF.ordrSide;
    }
    else
    {
        // rc = AppShlRollbackNum(__ORD_NUM);
        // RAISE_ERROR(rc, NORTN);

        // memset ( optrsp.orderNo, 0x00, OPT_ORDERNO_LEN );
        // optrsp.ordRejCod = SHL_GET_COMPL_CODE ( rtn );
        // optrsp.execType = '8';
        // optrsp.ordStatus = '8';
        // CONV_BIN_2_ASC( optrsp.ordRejCodStr, RTN_COD_LEN,
        //                 "%-ld", optrsp.ordRejCod );
    }

    // if ( orderTypeMask != ORDR_TYPE_LIMIT )
    // {
    //     if ( pOrder )
    //     {
    //         optrsp.remQty = pOrder->orderF.ordrQty;
    //         optrsp.price2 = pOrder->orderF.ordrExePrc;
    //     }
    //     else
    //     {
    //         optrsp.remQty = leaveQty;
    //         optrsp.price2 = 0;
    //     }
    // }


    // memcpy ( pRsp->data, &optrsp, sizeof ( rnoptrspT ) );
    // pRsp->rrHdr.complCod = SHL_GET_COMPL_CODE ( rtn );
    // pRsp->arHdr.msgLen += sizeof ( rnoptrspT );

    /* 对于架构性错误在日志中记录当前处理的订单信息 */
    RETURN_RESCODE;;
}



ResCodeT MatchBrdgOrdr(pOrderT pBrdgOrder , int32 bkOrdrSlotNo, int64 timestamp)
{
    BEGIN_FUNCTION("MatchBrdgOrdr");
    ResCodeT                rc = NO_ERR;
    OrderT tempOrder;
    pOrderT  pBkOrdr  = NULL;
    
    PrdctMktDataT  prdctMktData;
    
    TradeT rltrade;
    int32 i = 0;
    int32 prdctId = 0;
		CrdtMsgT BuyCredit;
		CrdtMsgT SellCredit;

		//calc trading price
		rltrade.setId = GET_SET_ID(pBrdgOrder->orderF.prdctId);
    
    rc = OrdBookGetOrdr(rltrade.setId, bkOrdrSlotNo, &pBkOrdr);
    RAISE_ERROR( rc, RTN);
    
    /* 设置成交信息 */
    //memset ( &rltrade, 0x00, sizeof ( TradeT ) );
		TRACE(" === Matching bridge order");
    
    rltrade.prdctId = pBrdgOrder->orderF.prdctId;
		
		rltrade.tradMtchPrc	 = pBrdgOrder->orderF.ordrExePrc+ pBrdgOrder->orderF.brdgFee;
					
		pBrdgOrder->orderF.ordrMtchPrc = rltrade.tradMtchPrc;
    pBkOrdr->orderF.ordrMtchPrc = rltrade.tradMtchPrc;
    
    rltrade.tranIdNo = ++gTrdrNo[rltrade.setId];

      /* 执行数量 */
    int64  tmpQty = pBkOrdr->orderF.ordrQty;

      
    /* 撮合数量，就是订单数量 */
    rltrade.trdQty = pBrdgOrder->orderF.ordrQty;

    /* 执行完全撮合 */
    rc = FullMtch ( &rltrade,&prdctMktData,
                    pBrdgOrder, pBkOrdr, &timestamp );
    RAISE_ERROR( rc, RTN );

	
    
	int64 amount = pBrdgOrder->orderF.ordrExeQty * rltrade.tradMtchPrc;
		  
		  /* bridge order is buyer */
		  if (pBrdgOrder->orderF.ordrSide == ORDR_SIDE_BUY)
		  {
			BuyCredit.crdtEntyNo = 0;
			BuyCredit.trgtEntyNo = 0;

			SellCredit.crdtEntyNo = pBkOrdr->orderF.entyIdxNo;
			SellCredit.trgtEntyNo = pBrdgOrder->orderF.entyIdxNo;
			SellCredit.avaCrdtAmnt = amount;
		  }else
		  {
			BuyCredit.crdtEntyNo = pBkOrdr->orderF.entyIdxNo;
			BuyCredit.trgtEntyNo = pBrdgOrder->orderF.entyIdxNo;
			BuyCredit.avaCrdtAmnt = amount;

			SellCredit.crdtEntyNo = 0;
			SellCredit.trgtEntyNo = 0;
		  }
		
		
		
		TRACE(" === Bridge Price %lld QTy %lld" $$ rltrade.tradMtchPrc $$ pBrdgOrder->orderF.ordrExeQty);	
		rc = DoUpdateCredit(&BuyCredit, &SellCredit);

  	RAISE_ERROR( rc, RTN );



    EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT PrcsOrdrBrdgReq(int64 timestamp)
{
    BEGIN_FUNCTION("PrcsOrdrBrdgReq");
    ResCodeT                rc = NO_ERR;
    OrderT tempOrder;
    pOrderT  pBrdgOrder = NULL;
    pOrderT  pBkOrdr  = NULL;
    
    PrdctMktDataT  prdctMktData;
    
    TradeT rltrade;
    int32 i = 0;
    int32 prdctId = 0;

    // 7,9,11 prdct Id for bridge order
    for (i=7; i< 12; i=i+2)
    {
		if (gBrdgOrdrList[i].caseType == 0)
		{
			continue; 
		}
		
		tempOrder.orderF.ordrExePrc =  gBrdgOrdrList[i].buyBrdgOrdr.ordrExePrc;
		tempOrder.orderF.ordrQty =  gBrdgOrdrList[i].buyBrdgOrdr.ordrQty;
		//tempOrder.orderF.ordrExeQty =  gBrdgOrdrList[i].buyBrdgOrdr.ordrQty;
		tempOrder.orderF.prdctId =  gBrdgOrdrList[i].buyBrdgOrdr.prdctId;
		tempOrder.orderF.ordrSide = 
				(gBrdgOrdrList[i].buyBrdgOrdr.ordrSide == ORDR_SIDE_BUY)? 
						ORDR_SIDE_SELL:ORDR_SIDE_BUY;
			if (tempOrder.orderF.ordrSide  == ORDR_SIDE_BUY)
			{
					tempOrder.orderF.brdgFee = -(BRDG_FEE);
			}
			else
		  {
				tempOrder.orderF.brdgFee = BRDG_FEE;
		  }
		  
			rc = DoCreateOrder (&tempOrder,&pBrdgOrder);
		RAISE_ERROR( rc, RTN);
			pBrdgOrder->orderF.entyIdxNo = BRDG_ENTY_IDX_NO;
		
			rc = MatchBrdgOrdr(pBrdgOrder ,gBrdgOrdrList[i].buyBrdgOrdr.slotId, timestamp);
			RAISE_ERROR( rc, RTN);
			
			
			tempOrder.orderF.ordrExePrc =  gBrdgOrdrList[i].sellBrdgOrdr.ordrExePrc;
		tempOrder.orderF.ordrQty =  gBrdgOrdrList[i].sellBrdgOrdr.ordrQty;
		//tempOrder.orderF.ordrExeQty =  gBrdgOrdrList[i].sellBrdgOrdr.ordrQty;
		tempOrder.orderF.prdctId =  gBrdgOrdrList[i].sellBrdgOrdr.prdctId;
		tempOrder.orderF.ordrSide = 
				(gBrdgOrdrList[i].sellBrdgOrdr.ordrSide == ORDR_SIDE_BUY)? 
						ORDR_SIDE_SELL:ORDR_SIDE_BUY;

			tempOrder.orderF.brdgFee = 0;

			rc = DoCreateOrder (&tempOrder,&pBrdgOrder);
		RAISE_ERROR( rc, RTN);
		   pBrdgOrder->orderF.entyIdxNo = BRDG_ENTY_IDX_NO;
		
			rc = MatchBrdgOrdr(pBrdgOrder ,gBrdgOrdrList[i].sellBrdgOrdr.slotId, timestamp);
			RAISE_ERROR( rc, RTN);
			
	    gBrdgOrdrList[i].caseType = 0;
   	}
	
	gBrdgOrdrCnt = 0;


    EXIT_BLOCK();
    RETURN_RESCODE;;
}
ResCodeT CreateCoeHash()
{
    BEGIN_FUNCTION( "CreateCoeHash" );
		    ResCodeT rc = NO_ERR;

	TCrdtCoe   TotalCoeInfo[10000];
	TCrdtCoe*  pTmp;
	TCrdtCoe* tmpHdl;
	int32  CoeCnt = 0;
	int32  ErrCode;
	int32  Cnt;
	char Key1[10];
	char Key2[10];
	char Key[20];
	
	//授信安全系数内存构造
	rc = DbTCrdtCoeGetAll(&TotalCoeInfo[0], &CoeCnt, &ErrCode);
		RAISE_ERROR( rc, RTN );

	shmCreate((void *)&gpCrditCoeShm, SHM_MEM_CREDIT_COE_ID, CoeCnt * sizeof(TCrdtCoe));

	rc = HashTableCreate(10000, &gCoeHashTable);
		RAISE_ERROR( rc, RTN );

	tmpHdl = (TCrdtCoe*)gpCrditCoeShm;
	pTmp = TotalCoeInfo;
	for(Cnt =0; Cnt< CoeCnt; Cnt++)
	{
		memset(Key1,0,10);
		memset(Key2,0,10);
		memset(Key,0,20);

		sprintf(Key1,"%d-", pTmp->cntrct_srno);
		sprintf(Key2,"%d", pTmp->crdt_org_id);
		strcpy(Key,Key1);
		strcat(Key,Key2);
		
		memcpy(tmpHdl,pTmp, sizeof(TCrdtCoe));
		
		rc = hashTableInsertNode(&gCoeHashTable, Key, Cnt);
		RAISE_ERROR( rc, RTN );
		
		pTmp++;
		tmpHdl++;
	}

	EXIT_BLOCK();
    RETURN_RESCODE;;
}

ResCodeT GetCoe(TCrdtCoe* pCoe, TCrdtCoe* pCoe2)
{
    BEGIN_FUNCTION( "GetCoe" );
		    ResCodeT rc = NO_ERR;
		//todo get from memory
		TCrdtCoe  CreditInfo;
		HashNodeT Node;
		TCrdtCoe * tmpHdl;
		char Key1[10];
		char Key2[10];
		char Key[20];

		memset(Key1,0,10);
		memset(Key2,0,10);
		memset(Key,0,20);

		//makeup hashkey 
		sprintf(Key1,"%d-", pCoe->cntrct_srno);
		sprintf(Key2,"%d", pCoe->crdt_org_id);

		strcpy(Key,Key1);
		strcat(Key,Key2);

		//using hashkey,find the shm index
		rc = hashTableLookUp(&gCoeHashTable, Key, &Node);
			RAISE_ERROR( rc, RTN );
		
		//using shm index,get the credit information
		tmpHdl = (TCrdtCoe*)gpCrditCoeShm;
		tmpHdl = tmpHdl + Node.nValue;
		memcpy(&CreditInfo,tmpHdl, sizeof(TCrdtCoe));

		pCoe->crdt_coe = tmpHdl->crdt_coe;
		
		TRACE("Get SHM %lld " $$ pCoe->crdt_coe);

		memset(Key1,0,10);
		memset(Key2,0,10);
		memset(Key,0,20);

		//makeup hashkey 
		sprintf(Key1,"%d-", pCoe2->cntrct_srno);
		sprintf(Key2,"%d", pCoe2->crdt_org_id);

		strcpy(Key,Key1);
		strcat(Key,Key2);

		//using hashkey,find the shm index
		rc = hashTableLookUp(&gCoeHashTable, Key, &Node);
			RAISE_ERROR( rc, RTN );
		
		//using shm index,get the credit information
		tmpHdl = (TCrdtCoe*)gpCrditCoeShm;
		tmpHdl = tmpHdl + Node.nValue;
		memcpy(&CreditInfo,tmpHdl, sizeof(TCrdtCoe));

		pCoe2->crdt_coe = tmpHdl->crdt_coe;
		
		TRACE("Get SHM %lld " $$ pCoe2->crdt_coe);
		
		
    EXIT_BLOCK();
    RETURN_RESCODE;;
}
