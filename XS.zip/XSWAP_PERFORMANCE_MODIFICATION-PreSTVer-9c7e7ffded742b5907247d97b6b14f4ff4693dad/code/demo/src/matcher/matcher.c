/***
Created on May 12, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
#include <stdarg.h>     
/* Project Header File*/
#include "../header/common_macro.h"
#include "../header/app_shl.h"
#include "match_lib.h"
#include "../header/shm.h"
#include "../header/credit_lib.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/

ResCodeT FormatOrderAdd(pOrdrReqT pReq, pOrderT pOrder)
{
    BEGIN_FUNCTION( "FormatOrderAdd" );

 
    pOrder->orderF.ordrExePrc = pReq->ordrExePrc;
    pOrder->orderF.ordrSide  = pReq->ordrSide;
    pOrder->orderF.prdctId = pReq->prdctId;
    pOrder->orderF.ordrNo = 0;
    pOrder->orderF.ordrExeQty = 0;
    pOrder->orderF.ordrEntTim = 0;
    pOrder->orderF.ordrExpDat = 0;
    pOrder->orderF.tranTime = 0;;
    pOrder->orderF.ordrQty = pReq->ordrQty;
    pOrder->orderF.remPkQty = 0;;
    pOrder->orderF.entyIdxNo = pReq->entyIdxNo;
    pOrder->orderF.ordrApplyPrc = 0;;
    pOrder->orderF.ordrMtchPrc = 0;;
    pOrder->orderF.ordrType = pReq->ordrType;
    //todo 
    //pOrder->orderF.ordrSts = '';



    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT ProcessOrd(int32 msgType, pOrdrReqT pReq, pOrdrRspT pRsp,int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "ProcessOrd" );
    ResCodeT rc = NO_ERR;
    OrderT tempOrder;
    pOrderT pOrder = NULL;
    
    //Add Order
    
    


    if ( msgType == MSG_TYPE_ORD_ADD )
    {
       			rc = FormatOrderAdd ( pReq, &tempOrder );
            RAISE_ERROR( rc, RTN);

				    /* ?????????, ????????? */
				    rc = DoCreateOrder ( &tempOrder, &pOrder );
				    RAISE_ERROR( rc, RTN);
				    
       			rc = ProcessOrderAdd(pOrder, timestamp, pRsp);
       			RAISE_ERROR( rc, RTN);
    }
    //DELETE ORDER
    else if (msgType == MSG_TYPE_ORD_DEL)
    {
        pOrder = NULL;
        
//        rc = ProcessOrderDelete(pOrder, timestamp, pRsp);
//        RAISE_ERROR( rc, RTN);
    }
	


    EXIT_BLOCK();
    RETURN_RESCODE;
}

ResCodeT MatcherCallBack(pMsgStructT pReq, pMsgStructT pRsp,int64 timestamp, pCallBackCtxT pCtx)
{
    BEGIN_FUNCTION( "MatcherCallBack" );
static int64 perfCnt  = 0;
    static struct timeval tBegin, tEnd;
    if (perfCnt == 0)
   	{
   			gettimeofday(&tBegin, NULL);
   			printf("start time %lld %lld \n", tBegin.tv_sec, tBegin.tv_usec);
   	}
    
    perfCnt++;
     //printf("current line %ld\n", perfCnt);
       
    ResCodeT rc = NO_ERR;
    pOrdrReqT  pOrdrReq = (pOrdrReqT)pReq->msgBody;
    pOrdrRspT  pOrdrRsp = (pOrdrRspT)pRsp->msgBody;

		memcpy(&pRsp->msgHdr, &pReq->msgHdr, sizeof(MsgHdrT));
		pRsp->msgHdr.msgLen =  sizeof(OrdrRspT);

    if (MSG_TYPE_ORD_ADD == pReq->msgHdr.msgType)
    {
 	// printf(" pOrdrReqT->ordrExePrc = %ld \n", pOrdrReq->ordrExePrc);
	// printf(" pOrdrReqT->ordrQty = %ld \n", pOrdrReq->ordrQty);
	// printf(" pOrdrReqT->ordrSide = %ld \n", pOrdrReq->ordrSide);
	// printf(" pOrdrReqT->entyIdxNo = %ld \n", pOrdrReq->entyIdxNo);
	// printf(" pOrdrReqT->prdctId = %ld \n", pOrdrReq->prdctId);


 pCtx->sendFlg = 1;
        rc = ProcessOrd(pReq->msgHdr.msgType, pOrdrReq, pOrdrRsp, timestamp, pCtx);
        RAISE_ERROR(rc, RTN);
        
        TRACE("ProcessOrd done");
        
       
    } 
    else if (MSG_TYPE_ORD_BRDG == pReq->msgHdr.msgType)
    {
    	  pCtx->sendFlg = 0;
    	  rc = PrcsOrdrBrdgReq(timestamp);
    	  RAISE_ERROR(rc, RTN);
    }
    
    



    
    EXIT_BLOCK();
    if (perfCnt%1000 == 0)
    {
    	printf("Total %lld \n", perfCnt);
    }
    
    if (perfCnt % 5000 == 0)
    {	
    		gettimeofday(&tEnd, NULL);
   			printf("End time %lld %lld \n", tEnd.tv_sec, tEnd.tv_usec);
    		
    		int64 delta = 1000000L*(tEnd.tv_sec - tBegin.tv_sec ) + (tEnd.tv_usec - tBegin.tv_usec ) ;
    		
    		printf("Total %lld \n", delta);
   	}
   	
    RETURN_RESCODE;
}

ResCodeT MatcherDoneCallBack()
{
    BEGIN_FUNCTION( "MatcherDoneCallBack" );




    EXIT_BLOCK();
    RETURN_RESCODE;
}


int32 main(int32 argc, char * argv[])
{
    BEGIN_FUNCTION( "main" );
    ResCodeT rc = NO_ERR;
    int32 setId = 0;
    
    int32 outputQHndl;
    int32	inputQHndl;
    
   	setId = atoi(argv[1]);
   	if (! setId)
  	{
  		RAISE_ERROR( ERR_INVLD_SET_ID, RTN );
  	}
  	
  	TRACE("Get Set %d" $$ setId);

		char buffer[128]= {0};
		
		sprintf(buffer, IPC_CON_2_MATCH, setId);
	
		rc = IPCCreate(buffer,0666);
		TRACE("Creat %s %lld" $$ buffer $$ rc);
		RAISE_ERROR( rc, RTN );

		rc = IPCOpen(buffer,FIFO_OPEN_FOR_READ,FIFO_NON_BLOCK_MODE,&inputQHndl);
		TRACE("Open %s %lld" $$ buffer $$ rc);
		RAISE_ERROR( rc, RTN );
		
		TRACE("Open %s Done" $$ buffer);
		
		memset(buffer, 0x00,128 );
		sprintf(buffer, IPC_MATCH_2_CON, setId);
	
		rc = IPCCreate(buffer,0666);
		TRACE("Creat %s %lld" $$ buffer $$ rc);
		RAISE_ERROR( rc, RTN );

	    rc = IPCOpen(buffer,FIFO_OPEN_FOR_WRITE,FIFO_BLOCK_MODE,&outputQHndl);
		TRACE("Open %s %lld" $$ buffer $$ rc);
		RAISE_ERROR( rc, RTN );
		TRACE("Open %s Done" $$ buffer);
		
		TRACE("Init CrdtLibInit");
		rc = CrdtLibInit (FALSE);
		RAISE_ERROR( rc, RTN );
		
		int32 inputShmId, outputShmId ;
		if (setId == 1)
		{
				inputShmId = SHM_SHL_IN_BUFF_ONE;
				outputShmId = SHM_SHL_OUT_BUFF_ONE;
		}
		else
		{
				inputShmId = SHM_SHL_IN_BUFF_TWO;
				outputShmId = SHM_SHL_OUT_BUFF_TWO;
		}
	 
		
		pFifoInfoT inputBuff;
    pFifoInfoT outputBuff;
    
    rc = GetQueueInfo(inputShmId,&inputBuff);
  	if NOTOK(rc)
  	{
  			rc = CreateFifoQueue(inputShmId,sizeof(ShmSlotIdT),1000,&inputBuff);
				RAISE_ERROR( rc, RTN );
  	}
  	TRACE("FIFO done" );
		rc = GetQueueInfo(outputShmId,&outputBuff);
		if NOTOK(rc)
  	{
				rc = CreateFifoQueue(outputShmId,sizeof(ShmSlotIdT),1000,&outputBuff);
				RAISE_ERROR( rc, RTN );
		}
		  	  
    rc = MemTxnShmAttach(setId);
		RAISE_ERROR( rc, RTN );
		TRACE("MemTxnShmAttach Done" );
		rc =OrdBookShmAttach(setId);
		RAISE_ERROR( rc, RTN );
    	
    rc = AppShlInit(setId, "Matcher", inputQHndl, outputQHndl, inputBuff,outputBuff,
            1000, 
            (AppCallBackT)MatcherCallBack, 
            (AppDoneCallBackT)MatcherDoneCallBack);
    RAISE_ERROR( rc, RTN );

	rc = CreateCoeHash();
		RAISE_ERROR( rc, RTN );
		TRACE("CreateCoeHash Done" );

    TRACE("Start to run" );
		rc = AppShlRun();
		RAISE_ERROR( rc, RTN );
		
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of main */

            
            