/***
Created on May 17, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
#include <stdarg.h>     
/* Project Header File*/
#include "../header/common_macro.h"
#include "../header/app_shl.h"
#include "../header/shm.h"
#include "../header/credit_lib.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/


int32 main(int32 argc, char * argv[])
{
    BEGIN_FUNCTION( "main" );
    ResCodeT rc = NO_ERR;
    int32 setId = 0;
    
    rc = CrdtLibInit (TRUE);
    RAISE_ERROR( rc, RTN );
	
	//database init
  	rc = DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");
    RAISE_ERROR( rc, RTN );

    rc = CreateCreditHashTable();
    RAISE_ERROR( rc, RTN );

   	CrdtMsgT reqCrdt;
		do
		{
				TRACE("Start to read request");
				rc = CrdtLibReadReq (&reqCrdt);
				RAISE_ERROR( rc, RTN );
				
				rc = CrdtLibPrcsReq (&reqCrdt);
				RAISE_ERROR( rc, RTN );
				
				rc = CrdtLibSendRsp (&reqCrdt);
				RAISE_ERROR( rc, RTN );
				
				
		} while(1);


    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of main */

            
            