/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */

/* Project Header File*/
#include "../src/header/mem_txn.h"
#include "../src/header/data_type.h"
#include "../src/header/common_macro.h"

ResCodeT PrintMemTxnEnty(int32 set, int32 txnId){
  BEGIN_FUNCTION( "PrintMemTxnEnty" );
  
  ResCodeT rc;
  
  pMemTxnEntryT pTxnEntry;
  
  rc = MemTxnShmAttach(set);
  
  if NOTOK(rc){
    RAISE_ERROR(rc, RTN);
  }
  
  pTxnEntry = (pMemTxnEntryT)malloc(sizeof(MemTxnEntryT));
  
  rc = MemTxnGetTxnEnty(txnId, pTxnEntry);
  if NOTOK(rc){
    RAISE_ERROR(rc, RTN);
  }
  
  TRACE("txnId = %d\n" $$ pTxnEntry->txnId);
  TRACE("txnSts = %d\n" $$ pTxnEntry->txnSts);
  TRACE("dataCnt = %d\n" $$ pTxnEntry->dataCnt);
  TRACE("frstDataSqno = %d\n" $$ pTxnEntry->frstDataSqno);
  
  EXIT_BLOCK();
  RETURN_RESCODE;
}

ResCodeT PrintMemTxnCtrl(){
  BEGIN_FUNCTION( "PrintMemTxnCtrl" );
  
  ResCodeT rc;
  pMemTxnCtrlT pTxnCtrl;
  
  pTxnCtrl = (pMemTxnCtrlT)malloc(sizeof(MemTxnCtrlT));
  
  rc = MemTxnGetTxnCtrl(pTxnCtrl);
  if NOTOK(rc){
    RAISE_ERROR(rc, RTN);
  }
  
  TRACE("currTxnId = %d\n" $$ pTxnCtrl->currTxnId);
  TRACE("commitTxnId = %d\n" $$ pTxnCtrl->commitTxnId);
  TRACE("maxTxnId = %d\n" $$ pTxnCtrl->maxTxnId);
  
  EXIT_BLOCK();
  RETURN_RESCODE;

}

int main(int argc, char* argv[]){
  BEGIN_FUNCTION( "main" );
  
  int32 setId;
  int32 txtId;
  
  
  if (argc < 3){
    printf("Usage: print_memtxn_info setId txtId");
	exit(1);
  }
  
  // setId is set to 1 for test
  setId = 1;
  
  sscanf(argv[2],"%d",&txtId);
  
  PrintMemTxnEnty(setId, txtId);
  PrintMemTxnCtrl();
  
  EXIT_BLOCK();
  RETURN_RESCODE;
  
}