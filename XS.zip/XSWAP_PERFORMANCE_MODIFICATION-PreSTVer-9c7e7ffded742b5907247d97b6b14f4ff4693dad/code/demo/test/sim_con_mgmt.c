/***
Created on May 12, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
/* Project Header File*/
#include "../src/header/common_macro.h"
#include "../src/header/app_shl.h"
#include "../src/header/shm.h"
#include "../src/header/msg_cache.h"
#include "../src/header/msg.h"
#include "../src/header/order_book.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/


int32 main(int32 argc, char * argv[])
{
    BEGIN_FUNCTION( "main" );
    ResCodeT rc = NO_ERR;
    int32 setId = 1;
    
    int32 outputQHndl;
    int32	inputQHndl;
    
    rc =  IPCCreate(IPC_CM_2_MATCH,0666);
		RAISE_ERROR( rc, RTN );

		
		rc =  IPCCreate(IPC_MATCH_2_CM,0666);
		RAISE_ERROR( rc, RTN );

    
    MemTxnShmCreate (MAX_ORDR_VOLM, 1024);
      
 
		char buffer[128]= {0};
		sprintf(buffer, IPC_CON_2_MATCH, setId);
		rc =  IPCCreate(buffer,0666);
		RAISE_ERROR( rc, RTN );


		rc = IPCOpen(buffer,FIFO_OPEN_FOR_WRITE,FIFO_BLOCK_MODE,&outputQHndl);
		RAISE_ERROR( rc, RTN );
		
		memset(buffer, 0x00,128 );
		sprintf(buffer, IPC_MATCH_2_CON, setId);
		rc =  IPCCreate(buffer,0666);
		RAISE_ERROR( rc, RTN );

		rc = IPCOpen(buffer,FIFO_OPEN_FOR_READ,FIFO_NON_BLOCK_MODE,&inputQHndl);
		RAISE_ERROR( rc, RTN );
		
		int32 slotId = SHM_NO_SLOT;
		
		pMsgCacheSlotT pReqSlot = NULL;
		pMsgCacheSlotT pRspSlot = NULL;
		
		rc = MsgCreateCache(MAX_SLOT_CNT);
    RAISE_ERROR( rc, RTN );
    
		rc =  MsgInit(MAX_SLOT_CNT);
		RAISE_ERROR( rc, RTN );
		
		rc = OrdBookShmCreate(1, MAX_PRDCT_CNT, MAX_ORDR_VOLM);
		RAISE_ERROR( rc, RTN );
		
		printf(" OrderFT %d OrderF4PrcLeadT %d OrderTT %d OrderT4PrcLeadT %d " ,sizeof(OrderFT),
		sizeof(OrderF4PrcLeadT),
		sizeof(OrderTT),
		sizeof(OrderT4PrcLeadT) );
		
		char inputBuffer[20];
		do
		{
			printf("Please input cnt:\n");
			if (fgets(inputBuffer,20,stdin) == NULL)
				printf("get input");
				
			int32 cnt = atoi(inputBuffer);
			printf(" %lld\n", cnt);
			
			printf("Please input order side 1 or 2:\n");
			if (fgets(inputBuffer,20,stdin) == NULL)
				printf("get input ");
				
			int32 buySellSide = atoi(inputBuffer);
			printf("get buy or sell %lld\n", cnt);
			
			int32 i = 0;
			for (i=0; i<cnt; i++)
			{
					rc = MsgRsrvSlotsPaired(&slotId,&pReqSlot,&pRspSlot);
					RAISE_ERROR( rc, RTN );
					
					printf("reserv paired success\n");
					
					pMsgStructT pReq = (pMsgStructT)&(pReqSlot->msgBody);
					
					pReq->msgHdr.msgLen = sizeof(OrdrReqT) + sizeof(MsgHdrT);
					pReq->msgHdr.msgType = MSG_TYPE_ORD_ADD;
					pReq->msgHdr.slotNo = slotId;
					
					pOrdrReqT pOrdrReq = (pOrdrReqT)pReq->msgBody;
					
					pOrdrReq->ordrExePrc = 110;
			    pOrdrReq->ordrExpDat = 120;
			    pOrdrReq->ordrQty  =  130;
			    pOrdrReq->ordrSide = 1;
			    pOrdrReq->prdctId = 7;
			    pOrdrReq->entyIdxNo =1;
			    pOrdrReq->usrIdxNo =12;
			    pOrdrReq->ordrType = 1;
					
					printf("BUy format order success\n");
					
					rc = IPCSend(outputQHndl,(char *)&slotId,sizeof(ShmSlotIdT));
					RAISE_ERROR( rc, NORTN );
					
					printf("send slot %lld success\n", slotId);
					
					
					rc = MsgRsrvSlotsPaired(&slotId,&pReqSlot,&pRspSlot);
					RAISE_ERROR( rc, RTN );
					
					printf("reserv paired success\n");
					
					pReq = (pMsgStructT)&(pReqSlot->msgBody);
					
					pReq->msgHdr.msgLen = sizeof(OrdrReqT) + sizeof(MsgHdrT);
					pReq->msgHdr.msgType = MSG_TYPE_ORD_ADD;
					pReq->msgHdr.slotNo = slotId;
					
					pOrdrReq = (pOrdrReqT)pReq->msgBody;
					
					pOrdrReq->ordrExePrc = 110;
			    pOrdrReq->ordrExpDat = 120;
			    pOrdrReq->ordrQty  =  130;
			    pOrdrReq->ordrSide = 2;
			    pOrdrReq->prdctId = 7;
			    pOrdrReq->entyIdxNo =2;
			    pOrdrReq->usrIdxNo =12;
			    pOrdrReq->ordrType = 1;
					
					printf("Sell format order success\n");
					
					rc = IPCSend(outputQHndl,(char *)&slotId,sizeof(ShmSlotIdT));
					RAISE_ERROR( rc, NORTN );
					
					printf("send slot %lld success\n", slotId);
			}
			
			printf("Start receive\n");
			int32 getCnt  = 0;
			for (i=0; i<cnt; i++)
			{
					rc = IPCReceive(inputQHndl,(char *)&slotId,sizeof(ShmSlotIdT));
					RAISE_ERROR( rc, NORTN );
					getCnt++;
					
					rc = MsgDelete(slotId);
					RAISE_ERROR( rc, NORTN );
			}	
			printf("Get total %lld success\n", getCnt);
			
		} while(1);

    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of main */

            
            