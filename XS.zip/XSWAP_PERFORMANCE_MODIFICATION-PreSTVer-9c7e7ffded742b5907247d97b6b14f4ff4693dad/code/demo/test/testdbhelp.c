/***
Created on May 12, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
#include <time.h>
#include <math.h>
#include <inttypes.h>

/* Project Header File*/
#include "../src/header/common_macro.h"
#include "../src/header/dbhelp.h"
#include "../src/db_header/t_mem_txn.h"
#include "../src/db_header/t_mem_data.h"
#include "../src/db_header/t_contract.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/




/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/




void TestMemDataInsert(){
    //BEGIN_FUNCTION( "TestMemData" );
    //ResCodeT rc = NO_ERR;
    //Init db
//    rc=DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");
//    RAISE_ERROR(rc, RTN);
//    //prepare Data
//    MemDataT record;
//    record.sequence_no=199;
//    record.set=22;
//    record.data_type=22;
//    unsigned char data[1824];
//
//    memcpy(data, &record, sizeof(MemDataT));
//
//    record.data=data;
//    record.lengthOfBlob=sizeof(MemDataT);
//
//    //insert record
//    int32 errCode;
//    int i=0;
//
//    for (; i <1 ; ) {
//        record.sequence_no=11+i;
//        rc = DbMemDataInsert(&record , &errCode);
//        RAISE_ERROR(rc, RTN);
//        i++;
//    }
//
//
//    //commit
//    rc= DbCommit(&errCode);
//    if(NOTOK(rc))
//    {
//        TRACE(errCode);
//    }
//    RAISE_ERROR(rc, RTN);
//    //final
    //EXIT_BLOCK();
    //RETURN_RESCODE;

}

void TestMemDataInsertBatch(int original){
    //BEGIN_FUNCTION( "TestMemDataInsertBatch" );
//    ResCodeT rc = NO_ERR;
//    //Init db
////    rc=DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");
////    RAISE_ERROR(rc, RTN);
//    //prepare Data
//
//
//    int seqNo[1000]; //1>i++
//    int setId[1000]; //1
//    int dataType[1000]; //1
//    char data[100000];
//
//    int i=0;
//    int offset=0;
//    for(i = 0; i < 1000; i++){
//        seqNo[i]=(i+original*1000); //1>i++
//        setId[i]=(i+original*1000); //1
//        dataType[i]=(i+original*1000); //1
//        memset(&data[offset],0x56,100);
//        offset=offset+100;
//
//    }
//
//
//    DbMemDataBatchInsert( 1000, seqNo,setId,dataType,data, 100);
//
//
//
//    //commit
////    int32 errCode;
////    rc= DbCommit(&errCode);
////    if(NOTOK(rc))
////    {
////        TRACE(errCode);
////    }
////    RAISE_ERROR(rc, RTN);
//    //final
    ///EXIT_BLOCK();
    //RETURN_RESCODE;

}
void TestMemDataQuery(){
    //BEGIN_FUNCTION( "TestMemData" );
    //ResCodeT rc = NO_ERR;
    //Init db
//    rc=DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");
//    RAISE_ERROR(rc, RTN);
//
//    MemDataT record;
//    record.sequence_no=11;
//    record.set=22;
//    record.data_type=22;
//
//    unsigned char data[1824];
//    record.data=data;
//
//    //query record
//    int32 errCode;
//    int64 key=11;
//
//    rc = DbMemDataQuery(key, &record , &errCode);
//    RAISE_ERROR(rc, RTN);
//
//    printf(record.sequence_no);printf("\n");
//    printf(record.set);printf("\n");
//    printf(record.data_type);printf("\n");
//    MemDataT* blobData =record.data;printf("\n");
//    printf("\n");
//    printf(blobData->sequence_no);printf("\n");
//    printf(blobData->set);printf("\n");
//    printf(blobData->data_type);printf("\n");
//    printf("\n");
//    printf(record.lengthOfBlob);printf("\n");
//
//
//    //final
//    DbDestroy();
    //EXIT_BLOCK();
    //RETURN_RESCODE;
}
void TestMemTxn(){
    //BEGIN_FUNCTION( "TestMemTxn" );
//    ResCodeT rc = NO_ERR;
//    //Init db
//    rc=DbInit("200.31.155.145:1521/xswapdb", "xswap", "xswap");
//    RAISE_ERROR(rc, RTN);
//    //prepare Data
//    MemTxnT record;
//    record.txn_id=199;
//    record.set_id=22;
//    record.start_seq_no=100;
//    record.end_seq_no=101;
//
//
//    //insert record
//    int32 errCode;
//    int i=0;
//
//    for (; i <1 ; ) {
//        record.txn_id=1000+i;
//        rc = DbMemTxnInsert(&record , &errCode);
//        RAISE_ERROR(rc, RTN);
//        i++;
//    }
//
//
//    //commit
//    rc= DbCommit(&errCode);
//    if(NOTOK(rc))
//    {
//        TRACE(errCode);
//    }
//    RAISE_ERROR(rc, RTN);
    //final
   // EXIT_BLOCK();
    //RETURN_RESCODE;

}


long long current_timestamp(){

    //struct timeval te;
//    gettimeofday(&te, NULL); //get current time
//    long long miliseconds=te.tv_sec*1000LL + te.tv_usec/1000;
//    //printf("msds:%lld\n", miliseconds);
//    return miliseconds;
}
int32 main(int32 argc, char * argv[])
{
//    BEGIN_FUNCTION( "main" );
//	//TestContract();
//    long long begin =current_timestamp();
////    int i=0;
////    for (; i <1 ; i++) {
////        TestMemDataInsertBatch(i);
////    }
//    TestMemDataInsertBatch(0);
//    //TestMemDataInsertBatch(1);
//    long long end = current_timestamp();
//    long long diff=end -begin;
//    printf("diff (ms):%lld\n", diff);
//    //TestMemTxn();
//    //TestMemDataQuery();

   // EXIT_BLOCK();
    //RETURN_RESCODE;
}


