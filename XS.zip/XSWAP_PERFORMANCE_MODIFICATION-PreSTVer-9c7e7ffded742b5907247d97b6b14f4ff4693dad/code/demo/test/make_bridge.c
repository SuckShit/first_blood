/***
Created on May 12, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
/* Project Header File*/
#include "../src/header/common_macro.h"
#include "../src/header/app_shl.h"
#include "../src/header/shm.h"
#include "../src/header/msg_cache.h"
#include "../src/header/msg.h"
#include "../src/header/order_book.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/
/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
int32 main(int32 argc, char * argv[])
{
    BEGIN_FUNCTION( "main" );
    int32 setId = 1;
	int32 slotId;
		pMsgCacheSlotT pReqSlot = NULL;
		pMsgCacheSlotT pRspSlot = NULL;
    
    int32 outputQHndl;
    int32 inputQHndl;
		char buffer[128]= {0};
		sprintf(buffer, IPC_CON_2_MATCH, setId);
	
		IPCOpen(buffer,FIFO_OPEN_FOR_WRITE,FIFO_BLOCK_MODE,&outputQHndl);

		MsgInit(MAX_SLOT_CNT);


		MsgRsrvSlotsPaired(&slotId,&pReqSlot,&pRspSlot);
					
		printf("reserv paired success\n");
					
		pMsgStructT pReq = (pMsgStructT)&(pReqSlot->msgBody);
					
		pReq->msgHdr.msgLen = sizeof(OrdrReqT) + sizeof(MsgHdrT);
		pReq->msgHdr.msgType = 3; // MSG_TYPE_ORD_BRDG   3
		pReq->msgHdr.slotNo = slotId;
					
		pOrdrReqT pOrdrReq = (pOrdrReqT)pReq->msgBody;
					
		pOrdrReq->ordrExePrc = 0;
		pOrdrReq->ordrExpDat = 0;
		pOrdrReq->ordrQty  =  0;
		pOrdrReq->ordrSide = 0;
		pOrdrReq->prdctId = 0;
		pOrdrReq->entyIdxNo =0;
		pOrdrReq->usrIdxNo =0;
		pOrdrReq->ordrType = 0;
					
		printf("BUy format order success\n");
		
	while(1)
	{
		sleep(2);
		
		IPCSend(outputQHndl,(char *)&slotId,sizeof(ShmSlotIdT));
					
		printf("send slot %lld success\n", slotId);	
	}

  return 1;
}
