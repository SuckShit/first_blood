/***
Created on May 12, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
/* Project Header File*/
#include "../src/header/common_macro.h"
#include "../src/header/msg_cache.h"
#include "../src/header/msg.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
int32 main(int32 argc, char * argv[])
{
    BEGIN_FUNCTION( "test_msg_cache" );
    ResCodeT rc = NO_ERR;
    
    pMsgStructT pData;
    
    rc = MsgCreateCache(1000);
    TEST_RESCODE_CHECK(rc, "msg cache create");
    
    
    
    rc = MsgInit(1000);
    TEST_RESCODE_CHECK(rc, "msg cache init");
    
    int32 slot;
    
    pMsgCacheSlotT pReqSlot;
    pMsgCacheSlotT pRspSlot;
        
    rc = MsgRsrvSlotsPaired(&slot,&pReqSlot,&pRspSlot);
    TEST_RESCODE_CHECK(rc, "get parie");
    
    printf("slot %lld, pairid %lld\n", pReqSlot->slotId, pReqSlot->pairedSlotId);
    
    rc = MsgRsrvSlotsPaired(&slot,&pReqSlot,&pRspSlot);
    TEST_RESCODE_CHECK(rc, "get parie");
    
    pData = (pMsgStructT)&pReqSlot->msgBody;
    
    pData->msgHdr.msgLen =1112;
    
    printf("slot %lld, pairid %lld\n", pReqSlot->slotId, pReqSlot->pairedSlotId);
    
    
    rc = MsgGetMsg(pReqSlot->slotId,(pMsgDataT            *)&pData);
    TEST_RESCODE_CHECK(rc, "get message addr");
                             
    printf("MsgLen %lld\n", pData->msgHdr.msgLen);
                            
    rc =  MsgDelete(pReqSlot->slotId);
    TEST_RESCODE_CHECK(rc, "free slot");
    
    
    sleep(300);
    
    TEST_DONE();
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of main */

            
            