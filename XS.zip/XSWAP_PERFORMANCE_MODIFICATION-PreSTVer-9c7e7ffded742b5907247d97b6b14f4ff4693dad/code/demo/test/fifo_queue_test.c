#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/shm.h>
#include "fifo_queue.h"
#include "errlib.h"

int main(int argc, char* argv[]){
  int queueKey;
  ResCodeT rc;
  pFifoInfoT queueInfo;
  int shmid;
  void* shm;
  TestDataT data1,data2;
  TestDataT data3;
  
  queueKey = 12345;
  
  data1.size=10;
  strcpy(data1.value , "123456789");
  data2.size=20;
  strcpy(data2.value , "abcdefg");
  
  printf("the size of FifoInfoT is :%d\n",sizeof(FifoInfoT));
  rc = GetQueueInfo(queueKey,&queueInfo);
  
  if NOTOK(rc){
    printf("the rc is:%d\n",rc);
    printf("has no queue of the key\n");
	printf("the size of TestDataT is :%d\n",sizeof(TestDataT));
	rc = CreateFifoQueue(queueKey,sizeof(TestDataT),10,&queueInfo);
	printf("the addr of queue info:%d\n",queueInfo);
	printf("the key of queue info:%d\n",queueInfo->key);
	if NOTOK(rc){
	  printf("fifo queue creation failed.\n");
	} else {
	  rc = GetStatusOfFifoQueue(queueInfo);
	  printf("the status of queue is:%d\n",rc);
	  rc = PutIntoFifoQueue(queueInfo,&data1);
	  rc = PutIntoFifoQueue(queueInfo,&data2);
	  // if NOTOK(rc){
	    // printf("fifo queue put failed.\n");
	  // }else{
	  
      rc = GetFromFifoQueue(queueInfo,&data3);
	  if NOTOK(rc){
	    printf("fifo queue get failed.\n");
	  }else{
	    printf("the value is:%s\n",data3.value);
	  }
	  
	  rc = GetFromFifoQueue(queueInfo,&data3);
	  printf("the value is:%s\n",data3.value);
	  // }
	  
	  rc = DestroyFifoQueue(queueInfo);
	  // if NOTOK(rc){
	    // printf("fifo queue status destroy failed.\n");
	  // }
	}
  } else {
    printf("Put Test, the key of queueInfo is :%d\n",queueInfo->key);
    rc = GetFromFifoQueue(queueInfo,&data3);
	if NOTOK(rc){
	  printf("fifo queue get failed.\n");
	}else{
	  printf("the value is:%s\n",data3.value);
	}
	rc = GetFromFifoQueue(queueInfo,&data3);
	printf("the value is:%s\n",data3.value);
  }
  
  // shmid = shmget((key_t)12345,0,0);
  // shm = shmat(shmid,NULL,0);
  // shmdt(shm);
  // shmctl(shmid,IPC_RMID,0);
  
  shmid = shmget((key_t)QUEUE_POOL_SHM_KEY,sizeof(FifoInfoT)*MAX_QUEUE_NUMBER,0666|IPC_CREAT);
  if (shmid < 0){
    printf("Queue Pool share memory doesn't seem to be created!!\n");
	exit(1);
  }
  printf("when destroy, shmid_info=%d\n",shmid);
  // shm = shmat(shmid,0,0);
  // if (shmdt((void*)gPoolShm) == -1){
    // printf("Queue Pool share memory detach failed!!\n");
	// exit(1);
  // }
  printf("when destroy, shm_info=%d\n",gPoolShm);
  if (shmctl(shmid,IPC_RMID,0) == -1){
    printf("Queue Pool share memory delete failed!!\n");
	exit(1);
  }
  
  
}