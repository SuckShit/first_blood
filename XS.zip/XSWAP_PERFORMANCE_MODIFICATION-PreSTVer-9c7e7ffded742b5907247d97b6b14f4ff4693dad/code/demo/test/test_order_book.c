/***
Created on May 12, 2017

@author: Brian.Ping
***/


/*****************************************************************************
 **
 **  Header File
 **
 *****************************************************************************/
/* Standard C header files */
#include <stdio.h>                  /* define standard i/o functions        */
#include <stdlib.h>                 /* define standard library functions    */
#include <string.h>                 /* define string handling functions     */
#include <sys/epoll.h>             /* define wait handling functions     */
/* Project Header File*/
#include "../src/header/common_macro.h"
#include "../src/header/order_book.h"
#include "../src/header/msg.h"
/*****************************************************************************
 **
 ** Macro
 **
 *****************************************************************************/

/******************************************************************************
 **
 **  Structure
 **
 ******************************************************************************/

/*****************************************************************************
 **
 ** Global Variable
 **
 *****************************************************************************/

/*****************************************************************************
 **
 ** Function Declaration
 **
 *****************************************************************************/



/*****************************************************************************
 **
 ** Function Implementation
 **
 *****************************************************************************/
int32 main(int32 argc, char * argv[])
{
    BEGIN_FUNCTION( "test_order_book" );
    ResCodeT rc = NO_ERR;

    
    rc = OrdBookShmCreate(1, 100, 1000);
    TEST_RESCODE_CHECK(rc, "Create order Book ");
                             
    rc = OrdBookShmAttach(1);
    TEST_RESCODE_CHECK(rc, "Attach order Book");
    
    pOrderT pOrder = NULL;
    
    rc = OrderCreate( 1, &pOrder);
    TEST_RESCODE_CHECK(rc, "Create order 1");
    
    pOrder->orderF.ordrNo = 12;
    pOrder->orderF.prdctId = 1;
    pOrder->orderF.ordrSide = ORDR_SIDE_BUY;
    pOrder->orderF.ordrExePrc = 1981;

    rc = OrderAdd(&pOrder);
    TEST_RESCODE_CHECK(rc, "Add  order 1");
    
    pOrderT pOrderBest = NULL;
    
    rc =  GetBest( 1,ORDR_SIDE_BUY, &pOrderBest );
    TEST_RESCODE_CHECK(rc, "Get Best  order 1");
    
    
    printf("OrdNo %lld, prdct %lld, Side %lld Price %lld\n",  pOrderBest->orderF.ordrNo,  pOrderBest->orderF.prdctId, pOrderBest->orderF.ordrSide, pOrderBest->orderF.ordrExePrc);
    
    TEST_DONE();
    EXIT_BLOCK();
    RETURN_RESCODE;
}/* End of main */

            
            